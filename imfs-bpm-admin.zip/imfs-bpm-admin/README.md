# BPM Admin

This is the BPM Admin application


## How to run this project?

Setup:
Set the following environment variables for the database and LDAP server (please reach out to a BPM developer to get creds):  
(in Windows using "set var val" or "set /M var val" or export in *NIX or use Windows UI. If using IntelliJ, you will need to restart IntelliJ to pick up new environment variables)  
spring.datasource.bpm.url  
spring.datasource.bpm.username  
spring.datasource.bpm.password   
ldap.url  
ldap.password  
ldap.username  

To build:
```
mvn clean install
```

To run:
```
mvn spring-boot:run
```

To debug (Windows):
```
mvn spring-boot:run -D"spring-boot.run.jvmArguments"="-Xdebug -Xrunjdwp:transport=dt_socket,server=y,suspend=y,address=5005"
```
To debug (non-Windows/Git Bash)
```
mvn spring-boot:run -Dspring-boot.run.jvmArguments="-Xdebug -Xrunjdwp:transport=dt_socket,server=y,suspend=y,address=5005"
```