//Common javascripts
//

function disableFormElements(formName){
	//NOTE: This function does not disable types - hidden, button, submit. 
	form = document.getElementById(formName);
	//alert(form);
	var count = form.length;
	for (i=0; i<count; i++) {
		var element = form.elements[i];
		 //alert(element.type);
		if (element.type == "text"){ 
		    element.disabled=true; 
		}
		if (element.type == "textarea"){ 
		    element.disabled=true; 
		}
		if (element.type == "checkbox"){ 
		    element.disabled=true; 
		}
		if (element.type == "radio"){ 
		    element.disabled=true; 
		}
		if (element.type == "select-one"){ 
		    element.disabled=true; 
		}
	} 
}