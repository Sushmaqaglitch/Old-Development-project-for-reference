package com.healthpartners.app.bpm.impl;

import com.healthpartners.app.bpm.common.BPMAdminConstants;
import com.healthpartners.app.bpm.dao.*;
import com.healthpartners.app.bpm.dto.*;
import com.healthpartners.app.bpm.exception.BPMException;
import com.healthpartners.app.bpm.iface.MemberService;
import com.healthpartners.service.bpm.common.BPMConstants;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.sql.Date;
import java.sql.SQLTimeoutException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;

@Service
public class MemberServiceImpl implements MemberService {


    private final PersonDAO personDAO;

    private final LookUpValueDAO lookUpValueDAO;

    private final ActivityDAO activityDAO;

    private final ContractDAO contractDAO;

    private final ProcessingStatusLogDAO processingStatusLogDAO;

    private final ActivityEventLogDAO activityEventLogDAO;

    private final QualificationOverrideDAO qualificationOverrideDAO;

    protected final Log logger = LogFactory.getLog(this.getClass());

    public MemberServiceImpl(PersonDAO personDAO, LookUpValueDAO lookUpValueDAO, ActivityDAO activityDAO, ContractDAO contractDAO, ProcessingStatusLogDAO processingStatusLogDAO, ActivityEventLogDAO activityEventLogDAO, QualificationOverrideDAO qualificationOverrideDAO) {
        this.personDAO = personDAO;
        this.lookUpValueDAO = lookUpValueDAO;
        this.activityDAO = activityDAO;
        this.contractDAO = contractDAO;
        this.processingStatusLogDAO = processingStatusLogDAO;
        this.activityEventLogDAO = activityEventLogDAO;
        this.qualificationOverrideDAO = qualificationOverrideDAO;
    }

    public Collection<PersonActivityContributionPending> getPersonActivityNonEmployerSponsoredContributionsPending(PersonActivityIncentiveSearch lPersonActivityIncentiveSearch) throws BPMException, DataAccessException {
        return personDAO.getPersonActivityNonEmployerSponsoredContributionsPending(lPersonActivityIncentiveSearch);
    }

    public Collection<PersonActivityContributionPending> getPersonActivityEmployerSponsoredContributionsPending(PersonActivityIncentiveSearch lPersonActivityIncentiveSearch) throws BPMException, DataAccessException {
        return personDAO.getPersonActivityEmployerSponsoredContributionsPending(lPersonActivityIncentiveSearch);
    }

    public Collection<LookUpValueCode> getLUVCodesByGroup(String group) throws DataAccessException {
        return lookUpValueDAO.getLUVCodesByGroup(group);
    }

    public LookUpValueCode getLUVCodeByGroupNValue(String group, String value) throws DataAccessException {
        return lookUpValueDAO.getLUVCodeByGroupNValue(group, value);
    }

    public void kickStartBatchProcessOnOpenshift(String urlRestEndpointCommand) throws IOException {
        int ret = 0;

        ProcessBuilder processBuilder = new ProcessBuilder(urlRestEndpointCommand.split(" "));
        Process process = processBuilder.start();
        try {
            ret = process.waitFor();
        } catch (InterruptedException exception) {
            logger.error("Error!  Interruption Exception error" + exception.getMessage());
        }

        int exitValue = process.exitValue();
        logger.info("Curl command kicked off.  Process exit value returned is " + exitValue);
        logger.info("Wait for return code is " + ret);
        //process.destroy();
    }

    public void insertManualExemptionForMember(Integer personDemographicsID, Integer personID,
                                               Integer businessProgramID, Integer contractNo, String exemptionReason,
                                               Calendar issueDate, String approverUser, String userId, Integer pProgramIncentiveOptionID)
            throws DataAccessException, IOException {

        qualificationOverrideDAO.insertManualExemptionForMember(personDemographicsID, personID,
                businessProgramID, contractNo, exemptionReason, issueDate, approverUser,
                userId, pProgramIncentiveOptionID);

        // put in message
//		StatusCalculationCommand statusCalculationCommand = new StatusCalculationCommand();
//		statusCalculationCommand.setEtlMembershipUpdateCommand();
//		statusCalculationCommand.setProcessIDForEtlMembershipUpdateCommand(BPMAdminConstants.BPM_ADMIN_MEMBERSHIP_UPDATE_PRCS_ID);
//		statusCalculationCommand.setOnePersonCommand(personDemographicsID);
//		statusCalculationJmsSender.sendJMS(statusCalculationCommand);

        //BPM-926 - hit openshift rest endpoint and pass in command to kick off service.
        LookUpValueCode luvMemberUpdateRestEndpoint = (LookUpValueCode)
                getLUVCodeByGroupNValue(BPMAdminConstants.OS_REST_URL_COMMAND, BPMAdminConstants.OS_URL_KS_MEMBERSHIP_UPDATE);
        String urlMemberUpdateRestEndpointCommand = luvMemberUpdateRestEndpoint.getLuvDesc() + personDemographicsID.toString();
        try {
            kickStartBatchProcessOnOpenshift(urlMemberUpdateRestEndpointCommand);
        } catch (IOException e) {
            throw e;
        }

    }


    public int updateMemberStatus(Integer pPersonID, Integer pProgramID, Integer pNewStatus, String pUserID, Integer pProgramIncentiveOptionID)
            throws BPMException, DataAccessException
    {
        return personDAO.updateMemberStatus(pPersonID, pProgramID, pNewStatus, pUserID, pProgramIncentiveOptionID);
    }

    @Override
    public int updateMemberStatusByCodeValue(Integer pPersonID, Integer pProgramID, Integer pGroupID, String pNewStatus, String pUserID) throws DataAccessException {
        return personDAO.updateMemberStatusByCodeValue(pPersonID, pProgramID, pGroupID, pNewStatus, pUserID);
    }

    @Override
    public Collection<MemberProgramActivity> getActivityHistory(String memberID, Date qualificationStartDate) throws BPMException, DataAccessException {
        Integer personID = personDAO.getPersonID(memberID);
        return activityDAO.getActivityHistory(personID, qualificationStartDate);
    }

    @Override
    public MemberDetail getMemberDetail(String memberID, Date qualificationStartDate) throws BPMException, DataAccessException {
        Integer personID = personDAO.getPersonID(memberID);
        MemberDetail lMemberDetail = personDAO.getMemberDetail(personID, qualificationStartDate);

        ArrayList<MemberProgramDetail> lMemberProgramDetails = null;

        if (lMemberDetail != null) {
            lMemberProgramDetails = (ArrayList<MemberProgramDetail>) personDAO.getMemberProgramDetails(personID, qualificationStartDate);
            lMemberDetail.setMemberProgramDetails(lMemberProgramDetails);
        }

        if (lMemberProgramDetails != null) {
            for (int i = 0; i < lMemberProgramDetails.size(); i++) {
                if (lMemberProgramDetails.get(i).isContractStatusCalcDatePassed()) {
                    if (BPMAdminConstants.BPM_ADMIN_CONTRACT_STATUS_QUALIFIED.equalsIgnoreCase(lMemberProgramDetails.get(i).getContractStatusCodeValue())) {
                        // If the status is qualified, set the status calc date to false to
                        // disable editing on the Member Updates page.
                        lMemberProgramDetails.get(i).setContractStatusCalcDatePassed(false);
                    }
                }

                if (lMemberProgramDetails.get(i).isMemberStatusCalcDatePassed()) {
                    if (BPMAdminConstants.BPM_ADMIN_MEMBER_STATUS_QUALIFIED.equalsIgnoreCase(lMemberProgramDetails.get(i).getMemberProgramStatusCodeValue())) {
                        // If the status is qualified, set the status calc date to false to
                        // disable editing on the Member Updates page.
                        lMemberProgramDetails.get(i).setMemberStatusCalcDatePassed(false);
                    }
                }
            }
        }

        return lMemberDetail;
    }

    @Override
    public Collection<BaselineHistory> getBaselineHistory(String pMemberID, Integer pContractNo, java.sql.Date pProgramEffetiveDate, String pEligibilityHistoryResults) {
        return contractDAO.getBaselineHistory(pMemberID, pContractNo, pProgramEffetiveDate, pEligibilityHistoryResults);
    }

    /**
     * Retrieve member demographics only.
     *
     * @param memberID
     * @param qualificationStartDate
     * @return
     * @throws BPMException
     * @throws DataAccessException
     */
    @Override
    public MemberDetail getMemberDemographicsOnly(String memberID, Date qualificationStartDate)
            throws BPMException, DataAccessException {
        Integer personID = personDAO.getPersonID(memberID);
        MemberDetail lMemberDetail = personDAO.getMemberDetail(personID, qualificationStartDate);

        return lMemberDetail;
    }

    @Override
    public Collection<String> getMemberIDFromPersonDetails(String firstName,
                                                           String middleInitial, String lastName, String gender,
                                                           java.sql.Date dateOfBirth) throws DataAccessException, BPMException {

        return personDAO.getMemberIDFromPersonDetails(firstName, middleInitial, lastName, gender, dateOfBirth);
    }

    @Override
    public Collection<String> getMemberIDByContractNo(Integer pContractNo) throws DataAccessException {
        return contractDAO.getMemberIDByContractNo(pContractNo);
    }

    @Override
    public Collection<LookUpValueCode> getActivityEventFilteredOutReasons() throws DataAccessException {
        return getLUVCodesByGroup(BPMConstants.BPM_ACTIVITY_EVENT_FILTERD_OUT_RSN);
    }

    @Override
    public ArrayList<MemberProgramDetail> selectPersonProgramRelationship(String pMemberID) throws BPMException, DataAccessException {
        return personDAO.selectPersonProgramRelationship(pMemberID);
    }

    @Override
    public Collection<MemberDetail> getRelatedMemberDetail(String memberID, Date qualificationStartDate) throws BPMException, DataAccessException {
        return personDAO.getRelatedMemberDetails(memberID);
    }

    @Override
    public Collection<MemberProcessingStatusLog> getPendingPersonsFromProcessingStatusLog(int pProcessID) throws BPMException, DataAccessException {
        return processingStatusLogDAO.getPendingPersonsFromProcessingStatusLog(pProcessID);
    }

    @Override
    public int[] deleteProcessingStatusLogRecords(Collection<Long> processLogIDs) throws BPMException, DataAccessException {
        return processingStatusLogDAO.deleteProcessingStatusLogRecords(processLogIDs);
    }

    @Override
    public ArrayList<PersonContractHist> getMemberContractsHistory(
            String memberId, String contractNo, Date programEffectiveDate, String groupNo, String luvContractHistResultCodeValue)
            throws DataAccessException, SQLTimeoutException {

        ArrayList<PersonContractHist> memberContractsHistory = personDAO.getPersonContractsHistory(memberId, contractNo, programEffectiveDate, groupNo, luvContractHistResultCodeValue);

        return memberContractsHistory;
    }

    @Override
    public Collection<CDHPFulfillmentTrackingRecycle> getPersonCDHPFulfillsRecycle(
            String memberId, String groupNo, String contractNo, Date recycleStatusDate, Integer recycleStatusId, String programName)
            throws DataAccessException {

        Collection<CDHPFulfillmentTrackingRecycle> memberContractsRecycle = personDAO.getPersonCDHPFulfillsRecycle(memberId, groupNo, contractNo, recycleStatusDate, recycleStatusId, programName);

        return memberContractsRecycle;
    }

    @Override
    public int updatePersonCDHPFulfillRecycle(CDHPFulfillmentTrackingRecycle pCDHPFulfillmentTrackingRecycle) throws BPMException, DataAccessException {
        return personDAO.updatePersonCDHPFulfillRecycle(pCDHPFulfillmentTrackingRecycle);
    }

    @Override
    public int updateMemberProgramActivityIncentiveModifyDate(Integer personDemographicsID, Integer programID, Integer activityID, String userID) throws DataAccessException {
        return personDAO.updateMemberProgramActivityIncentiveModifyDate(personDemographicsID, programID, activityID, userID);
    }

    @Override
    public CDHPFulfillmentTrackingRecycle getPersonCDHPFulfillRecycle(Integer recycleID) throws DataAccessException {
        CDHPFulfillmentTrackingRecycle memberContractRecycle = personDAO.getPersonCDHPFulfillRecycle(recycleID);

        return memberContractRecycle;
    }

    @Override
    public MemberDetail getMemberDetail(String memberID, Integer programID) throws BPMException, DataAccessException {
        Integer personID = personDAO.getPersonID(memberID);
        return personDAO.getMemberDetail(personID, programID);
    }

    @Override
    public Collection<MemberDetail> getRelatedMemberDetail(String memberID) throws BPMException, DataAccessException {
        return personDAO.getRelatedMemberDetails(memberID);
    }

    @Override
    public Collection<PersonContractRecycle> getMemberContractsRecycle(String memberId, String groupNo, String contractNo, Date recycleStatusDate, Integer recycleStatusId, String programName) throws DataAccessException {
        Collection<PersonContractRecycle> memberContractsRecycle = personDAO.getPersonContractsRecycle(memberId, groupNo, contractNo, recycleStatusDate, recycleStatusId, programName);
        return memberContractsRecycle;
    }

    @Override
    public int updatePersonContractRecycle(PersonContractRecycle pPersonContractRecycle) throws BPMException, DataAccessException {
        return personDAO.updatePersonContractRecycle(pPersonContractRecycle);
    }

    @Override
    public int updateMemberProgramStatusContractStatusDate(Integer personId, Integer programId) throws BPMException, DataAccessException {
        return personDAO.updateMemberProgramStatusContractStatusDate(personId, programId);
    }

    public int updateContractProgramStatus(Integer pProgramID, Integer pContractNo, Integer pNewStatus, String pUserID, Integer pProgramIncentiveOptionID)
            throws BPMException, DataAccessException
    {
        return contractDAO.updateContractProgramStatus(pProgramID, pContractNo, pNewStatus, pUserID, pProgramIncentiveOptionID);
    }

    @Override
    public PersonContractRecycle getMemberContractRecycle(Integer recycleID) throws DataAccessException {
        PersonContractRecycle memberContractRecycle = personDAO.getPersonContractRecycle(recycleID);
        return memberContractRecycle;
    }

    public Collection<Integer> getNumberOfProcessingStatusLogPending()
            throws DataAccessException
    {
        return processingStatusLogDAO.getNumberOfProcessingStatusLogPending();
    }

    public Collection<Integer> getNumberOfProcessingStatusLogInProcess()
            throws DataAccessException
    {
        return this.processingStatusLogDAO.getNumberOfProcessingStatusLogInProcess();
    }
    public Collection<Integer> getNumberOfActivityEventLog(String pProcessingStatus)
            throws DataAccessException
    {
        return activityEventLogDAO.getNumberOfActivityEventLog(pProcessingStatus);
    }
    public long insertPersonProcessingStatus(Integer personId,
                                             Integer processId, String processingStatusValue, String userId)
            throws BPMException, DataAccessException {
        return processingStatusLogDAO.insertPersonProcessingStatusLog(personId,
                processId, processingStatusValue, userId);
    }

    public Collection<MemberProgramDetail> getTermedMemberProgramHistoryDetails(
            String memberID, Date qualificationStartDate)
    {
        Integer personID = personDAO.getPersonID(memberID);
        return personDAO.getTermedMemberProgramHistoryDetails(personID, qualificationStartDate);
    }

    public LookUpValueCode getLUVCodeByID(Integer pLUVID)
            throws DataAccessException
    {
        return lookUpValueDAO.getLUVCodeById(pLUVID);
    }

    public int updateParticipationEndDate(Integer pPersonDemographicsID, Integer pProgramID, java.sql.Date pParticipationEndDate)
            throws DataAccessException
    {
        return this.personDAO.updateParticipationEndDate(pPersonDemographicsID, pProgramID, pParticipationEndDate);
    }

    public int updateFilteredActivities(String pMemberID, Date pInsertDate, Integer pGroupID, Integer pActivityID, String pActivityStatusToProcess, String pProcessingStatus)
    {
        return activityEventLogDAO.updateFilteredActivities(pMemberID, pInsertDate, pGroupID, pActivityID, pActivityStatusToProcess, pProcessingStatus);
    }

    public Collection<Activity> getEmployerAdminsterdActivities()
            throws DataAccessException, BPMException {

        return activityDAO.getEmployerAdminsterdActivities();
    }


}