package com.healthpartners.app.bpm.form;

import com.healthpartners.app.bpm.dto.EmployerGroup;
import com.healthpartners.app.bpm.dto.ProgramType;

import java.util.ArrayList;

public class CopyToYearForm extends BaseForm {
    private String businessProgramType;
    private String businessProgramName;

    private String businessProgramTypeName;

    private Integer groupID;
    private Integer subgroupID;
    private String groupNo;
    private String groupName;
    private String siteIDSiteName;

    private String[] groupStartDates;
    private String[] selectedSubgroups;
    private String qualificationStartDate;

    private ArrayList<ProgramType> programTypes = new ArrayList<>();
    private ArrayList<EmployerGroup> employerSubGroups = new ArrayList<>();

    public Integer getGroupID() {
        return groupID;
    }

    public void setGroupID(Integer groupID) {
        this.groupID = groupID;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public String getGroupNo() {
        return groupNo;
    }

    public void setGroupNo(String groupNo) {
        this.groupNo = groupNo;
    }

    public Integer getSubgroupID() {
        return subgroupID;
    }

    public void setSubgroupID(Integer subgroupID) {
        this.subgroupID = subgroupID;
    }

    public String getBusinessProgramName() {
        return businessProgramName;
    }

    public void setBusinessProgramName(String businessProgramName) {
        this.businessProgramName = businessProgramName;
    }

    public String getBusinessProgramType() {
        return businessProgramType;
    }

    public void setBusinessProgramType(String businessProgramType) {
        this.businessProgramType = businessProgramType;
    }

    public String getSiteIDSiteName() {
        return siteIDSiteName;
    }

    public void setSiteIDSiteName(String siteIDSiteName) {
        this.siteIDSiteName = siteIDSiteName;
    }

    public String getBusinessProgramTypeName() {
        return businessProgramTypeName;
    }

    public void setBusinessProgramTypeName(String businessProgramTypeName) {
        this.businessProgramTypeName = businessProgramTypeName;
    }

    public String[] getGroupStartDates() {
        return groupStartDates;
    }

    public void setGroupStartDates(String[] groupStartDates) {
        this.groupStartDates = groupStartDates;
    }


    public final String[] getSelectedSubgroups() {
        return selectedSubgroups;
    }


    public final void setSelectedSubgroups(String[] selectedSubgroups) {
        this.selectedSubgroups = selectedSubgroups;
    }

	public String getQualificationStartDate() {
		return qualificationStartDate;
	}

	public void setQualificationStartDate(String qualificationStartDate) {
		this.qualificationStartDate = qualificationStartDate;
	}

    public ArrayList<ProgramType> getProgramTypes() {
        return programTypes;
    }

    public void setProgramTypes(ArrayList<ProgramType> programTypes) {
        this.programTypes = programTypes;
    }

    public ArrayList<EmployerGroup> getEmployerSubGroups() {
        return employerSubGroups;
    }

    public void setEmployerSubGroups(ArrayList<EmployerGroup> employerSubGroups) {
        this.employerSubGroups = employerSubGroups;
    }
}
