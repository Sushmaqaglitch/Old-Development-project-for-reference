package com.healthpartners.app.bpm.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

import static java.util.Objects.requireNonNull;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    private final Environment env;

    public SecurityConfig(Environment env) {
        this.env = env;
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        // @formatter:off
        http
                .authorizeHttpRequests(authorize -> authorize.requestMatchers(
                                new AntPathRequestMatcher("/health"),
                                new AntPathRequestMatcher("/prometheus")).permitAll()
                        .requestMatchers("/favicon.ico", "/css/**", "/images/**", "/js/**", "/error", "/WEB-INF/tags/**", "/WEB-INF/view/**")
                        .permitAll()
                        .anyRequest().authenticated()
                )
                .formLogin((form) -> form
                        .loginPage("/login")
                        .permitAll()
                        .successHandler(authenticationSuccessHandler())
                        .failureUrl("/login-error")
                )
                .logout((logout) -> logout
                        .logoutRequestMatcher(new AntPathRequestMatcher("/logout"))
                        .logoutSuccessUrl("/login")
                        .deleteCookies("JSESSIONID")
                        .invalidateHttpSession(true)
                        .clearAuthentication(true)
                        .invalidateHttpSession(true))
                .sessionManagement(httpSecuritySessionManagementConfigurer -> httpSecuritySessionManagementConfigurer
                        .invalidSessionUrl("/login"))
                .headers(httpSecurityHeadersConfigurer -> httpSecurityHeadersConfigurer.cacheControl(cacheControlConfig -> cacheControlConfig.disable()));
        // @formatter:on
        return http.build();
    }

    @Autowired
    public void configure(AuthenticationManagerBuilder auth) throws Exception {
        auth
                .ldapAuthentication()
                .userDnPatterns("uid={0},ou=people")
                .userSearchFilter("sAMAccountName={0}")
                .groupSearchBase("OU=DLGroups")
                .groupSearchFilter("(member={0})")
                .contextSource()
                    .managerDn(requireNonNull(env.getProperty("ldap.username")))
                    .managerPassword(requireNonNull(env.getProperty("ldap.password")))
                    .url(requireNonNull(env.getProperty("ldap.url")));
    }

    @Bean
    public AuthenticationSuccessHandler authenticationSuccessHandler() {
        return new BPMAdminAuthenticationSuccessHandler();
    }
}
