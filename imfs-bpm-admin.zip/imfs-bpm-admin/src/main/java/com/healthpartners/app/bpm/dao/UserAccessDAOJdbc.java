package com.healthpartners.app.bpm.dao;

import com.healthpartners.app.bpm.dto.LookUpValueCode;
import com.healthpartners.app.bpm.dto.UserAccess;
import com.healthpartners.app.bpm.exception.BPMException;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import jakarta.annotation.PostConstruct;
import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Collection;
@Repository
@Transactional(timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
public class UserAccessDAOJdbc extends JdbcDaoSupport implements UserAccessDAO {
	private static final String selectDistinctUserNames = "SELECT DISTINCT BPM_USR_ID, BPM_USR_NM FROM USR_ENV  ORDER BY BPM_USR_ID";
	private static final String selectUserAccessList = "SELECT BPM_USR_ID, BPM_USR_NM, ENV_LU_ID, lu_val, lu_desc FROM USR_ENV, luv " +
			"            WHERE lower(BPM_USR_ID) = lower(?) AND ENV_LU_ID = lu_id";
	private static final String insertUserAccess = "INSERT INTO USR_ENV " +
			"(BPM_USR_ID, BPM_USR_NM, ENV_LU_ID, INSERT_TS, INSERT_USR_ID, MODIFY_TS, MODIFY_USR_ID) " +
			"VALUES (?, ?, ?, SYSDATE, ?, SYSDATE, ?)";
	private static final String deleteUserAccess = "DELETE FROM USR_ENV WHERE BPM_USR_ID = ?";
	private static final String updateUserAccess = "UPDATE USR_ENV SET BPM_USR_NM = ?, MODIFY_USR_ID = ?, MODIFY_TS = SYSDATE WHERE BPM_USR_ID = ? AND ENV_LU_ID = ?";

	private final DataSource dataSource;

	public UserAccessDAOJdbc (DataSource dataSource) {
		this.dataSource = dataSource;
	}


	@PostConstruct
	private void initialize() {
		setDataSource(dataSource);
	}

	@Override
	public Collection<UserAccess> getUserAccessList(String lUserName)
			throws BPMException, DataAccessException {
		final ArrayList<UserAccess> lUserAccessList = new ArrayList<UserAccess>();
		final ArrayList<LookUpValueCode> lEnvironments = new ArrayList<LookUpValueCode>();
		final UserAccess lUserAccess = new UserAccess();

		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[]{lUserName};
		int types[] = new int[]{Types.VARCHAR};

		template.query(selectUserAccessList, params, types, new RowCallbackHandler() {
			public void processRow(ResultSet rs) throws SQLException {
				LookUpValueCode lLookUpValueCode = new LookUpValueCode();

				lLookUpValueCode.setLuvId(rs.getInt("ENV_LU_ID"));
				lLookUpValueCode.setLuvVal(rs.getString("lu_val"));
				lLookUpValueCode.setLuvDesc(rs.getString("lu_desc"));
				lEnvironments.add(lLookUpValueCode);
				lUserAccess.setUserEnvironments(lEnvironments);
			}
		});

		lUserAccessList.add(lUserAccess);

		return lUserAccessList;
	}
	@Override
	public Collection<UserAccess> getUserAccessList()
			throws BPMException, DataAccessException {
		final ArrayList<UserAccess> lUserAccessList = new ArrayList<UserAccess>();

		JdbcTemplate template = getJdbcTemplate();
		template.query(selectDistinctUserNames, new RowCallbackHandler() {
			public void processRow(ResultSet rs) throws SQLException {
				UserAccess lUserAccess = new UserAccess();

				lUserAccess.setUserName(rs.getString("BPM_USR_ID"));
				lUserAccess.setUserFullName(rs.getString("BPM_USR_NM"));
				lUserAccessList.add(lUserAccess);
			}
		});

		for (int i = 0; i < lUserAccessList.size(); i++) {
			final ArrayList<LookUpValueCode> lEnvironments = new ArrayList<LookUpValueCode>();

			Object params[] = new Object[]{lUserAccessList.get(i).getUserName()};
			int types[] = new int[]{Types.VARCHAR};

			template.query(selectUserAccessList, params, types, new RowCallbackHandler() {
				public void processRow(ResultSet rs) throws SQLException {
					LookUpValueCode lLookUpValueCode = new LookUpValueCode();

					lLookUpValueCode.setLuvId(rs.getInt("ENV_LU_ID"));
					lLookUpValueCode.setLuvVal(rs.getString("lu_val"));
					lLookUpValueCode.setLuvDesc(rs.getString("lu_desc"));
					lEnvironments.add(lLookUpValueCode);
				}
			});

			lUserAccessList.get(i).setUserEnvironments(lEnvironments);
		}

		return lUserAccessList;
	}

	/**
	 * Insert into the BPM_USR_ENV table. Insert one row for each environment the user has access to.
	 *
	 * @param pUserAccess
	 * @param pUserID
	 * @return
	 * @throws DataAccessException
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Override
	public int insertUserAccess(UserAccess pUserAccess, String pModifyUserID)
			throws DataAccessException {
		JdbcTemplate template = getJdbcTemplate();
		int rowInserted = 0;

		for (int i = 0; i < pUserAccess.getUserEnvironments().size(); i++) {
			Object params[] = new Object[]{pUserAccess.getUserName(), pUserAccess.getUserFullName(),
					((ArrayList<LookUpValueCode>) pUserAccess.getUserEnvironments()).get(i).getLuvId(),
					pModifyUserID, pModifyUserID};

			int types[] = new int[]{Types.VARCHAR,
					Types.VARCHAR, Types.INTEGER,
					Types.VARCHAR, Types.VARCHAR};

			rowInserted = template.update(insertUserAccess, params, types);
		}

		return rowInserted;
	}

	/**
	 * Delete the access of the given user to the specified environment.
	 *
	 * @param pUserLoginName
	 * @param pEnvironmentLUID
	 * @return
	 * @throws DataAccessException
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Override
	public int deleteUserAccess(String pUserLoginName)
			throws DataAccessException {
		JdbcTemplate template = getJdbcTemplate();
		int rowInserted = 0;

		Object params[] = new Object[]{pUserLoginName};
		int types[] = new int[]{Types.VARCHAR};

		rowInserted = template.update(deleteUserAccess, params, types);

		return rowInserted;
	}

	/**
	 * Delete all rows for this user, and insert one row for each environment this user has
	 * access to.
	 *
	 * @param pUserLoginName
	 * @param pEnvironmentLUID
	 * @return
	 * @throws DataAccessException
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Override
	public int updateUserAccess(UserAccess pUserAccess, String pModifyUserID)
			throws DataAccessException {
		JdbcTemplate template = getJdbcTemplate();
		int rowInserted = 0;

		this.deleteUserAccess(pUserAccess.getUserName());

		rowInserted = this.insertUserAccess(pUserAccess, pModifyUserID);

		return rowInserted;
	}
}
