package com.healthpartners.app.bpm.dto;

import java.io.Serializable;

public class PackageActivity implements Serializable {
    static final long serialVersionUID = 0L;

    private Integer packageID;
    private Integer activityID;
    private String activityName;
    private String activityDesc;
    private String activityType;
    private String activityTypeDesc;
    private String sourceSystemActivityID;

    public Integer getActivityID() {
        return activityID;
    }

    public void setActivityID(Integer activityID) {
        this.activityID = activityID;
    }

    public Integer getPackageID() {
        return packageID;
    }

    public void setPackageID(Integer packageID) {
        this.packageID = packageID;
    }

    public String getActivityName() {
        return activityName;
    }

    public void setActivityName(String activityName) {
        this.activityName = activityName;
    }

    public String getActivityDesc() {
        return activityDesc;
    }

    public void setActivityDesc(String activityDesc) {
        this.activityDesc = activityDesc;
    }


    public String getActivityType() {
        return activityType;
    }

    public void setActivityType(String activityType) {
        this.activityType = activityType;
    }

    public String getActivityTypeDesc() {
        return activityTypeDesc;
    }

    public void setActivityTypeDesc(String activityTypeDesc) {
        this.activityTypeDesc = activityTypeDesc;
    }

    public String getSourceSystemActivityID() {
        return sourceSystemActivityID;
    }

    public void setSourceSystemActivityID(String sourceSystemActivityID) {
        this.sourceSystemActivityID = sourceSystemActivityID;
    }
}
