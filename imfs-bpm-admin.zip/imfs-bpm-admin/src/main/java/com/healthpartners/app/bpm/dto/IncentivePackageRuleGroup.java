package com.healthpartners.app.bpm.dto;

import com.healthpartners.app.bpm.common.BPMAdminUtils;

import java.io.Serializable;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

/**
 * 
 * @author jxbourbour
 * 
 */
public class IncentivePackageRuleGroup implements Serializable 
{
	static final long serialVersionUID = 0L;

	private Integer incentivePackageRuleGroupID;
	private String incentivePackageRuleGroupName;
	private String incentivePackageRuleGroupInfo;
	private String incentivePackageRuleGroupDesc;
	private Date effectiveDate;
	private Date endDate;
	private boolean used;

	private String effectiveDateString;
	private String endDateString;

	private List<IncentivePackageRuleRequirement> incentivePackageRuleRequirements = new ArrayList<IncentivePackageRuleRequirement>();

	public IncentivePackageRuleGroup() {
		super();
	}

	public Integer getIncentivePackageRuleGroupID() {
		return incentivePackageRuleGroupID;
	}

	public void setIncentivePackageRuleGroupID(Integer incentivePackageRuleGroupID) {
		this.incentivePackageRuleGroupID = incentivePackageRuleGroupID;
	}

	public String getIncentivePackageRuleGroupName() {
		return incentivePackageRuleGroupName;
	}

	public void setIncentivePackageRuleGroupName(
			String incentivePackageRuleGroupName) {
		this.incentivePackageRuleGroupName = incentivePackageRuleGroupName;
	}

	public String getIncentivePackageRuleGroupInfo() {
		return incentivePackageRuleGroupInfo;
	}

	public void setIncentivePackageRuleGroupInfo(
			String incentivePackageRuleGroupInfo) {
		this.incentivePackageRuleGroupInfo = incentivePackageRuleGroupInfo;
	}

	public String getIncentivePackageRuleGroupDesc() {
		return incentivePackageRuleGroupDesc;
	}

	public void setIncentivePackageRuleGroupDesc(
			String incentivePackageRuleGroupDesc) {
		this.incentivePackageRuleGroupDesc = incentivePackageRuleGroupDesc;
	}	

	public boolean isUsed() {
		return used;
	}

	public void setUsed(boolean used) {
		this.used = used;
	}

	public final Date getEffectiveDate() {
		return effectiveDate;
	}

	public final void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
		effectiveDateString = BPMAdminUtils.formatDateMMddyyyy(effectiveDate);
	}

	public final Date getEndDate() {
		return endDate;
	}

	public final void setEndDate(Date endDate) {
		this.endDate = endDate;
		endDateString = BPMAdminUtils.formatDateMMddyyyy(endDate);
	}

	public final String getEffectiveDateString() {
		return effectiveDateString;
	}

	public final void setEffectiveDateString(String effectiveDateString) {
		this.effectiveDateString = effectiveDateString;
		effectiveDate = BPMAdminUtils.getSqlDateFromString(effectiveDateString);
	}

	public final String getEndDateString() {
		return endDateString;
	}

	public final void setEndDateString(String endDateString) {
		this.endDateString = endDateString;
		endDate = BPMAdminUtils.getSqlDateFromString(endDateString);
	}

	public List<IncentivePackageRuleRequirement> getIncentivePackageRuleRequirements() {
		return incentivePackageRuleRequirements;
	}

	public void setIncentivePackageRuleRequirements(
			List<IncentivePackageRuleRequirement> incentivePackageRuleRequirements) {
		this.incentivePackageRuleRequirements = incentivePackageRuleRequirements;
	}

	public boolean isPersistent() {
		return incentivePackageRuleGroupID != null && incentivePackageRuleGroupID > 0;
	}	
		
}
