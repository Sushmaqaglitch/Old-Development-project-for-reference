package com.healthpartners.app.bpm.dao;

import com.healthpartners.app.bpm.dto.*;
import com.healthpartners.app.bpm.exception.BPMException;
import org.springframework.dao.DataAccessException;

import java.sql.Date;
import java.util.ArrayList;
import java.util.Collection;

public interface ActivityDAO {
	Collection<Activity> selectActivities();
	Collection<Activity> selectAllActivities();
	Collection<Activity> selectExpiredActivities();

	Activity selectActivity(int activityId);

	int deleteActivity(Integer activityID) throws DataAccessException;

	int updateActivity(Activity lActivity) throws DataAccessException;

	int insertActivity(Activity lActivity) throws DataAccessException;

	Collection<EligibleActivity> getEligibleActivities(Integer programID) throws BPMException, DataAccessException;

	Collection<Activity> getAvailableActivities(Integer programID) throws BPMException, DataAccessException;

	int deleteEligibleActivities(Integer programID) throws BPMException, DataAccessException;

	int deleteProgramCheckmark(Integer programID)
			throws BPMException, DataAccessException;

	void insertEligibleActivity(EligibleActivity pEligibleActivity, String lUserID) throws BPMException, DataAccessException;

	Collection<AuthCode> selectExtendedAuthCodes(final Integer pProgramID) throws DataAccessException;

	void updateExtendedAuthCode(AuthCode pAuthCode, String pUserID) throws DataAccessException;

	Collection<AuthCode> selectExtendedAuthCode(final Integer pProgramID, final String pAuthCode);

	void insertExtendedAuthCode(AuthCode pAuthCode, String pUserID);

	ArrayList<Integer> getCheckmarkEligibleActivities(Integer pQualificationCheckmarkID, Integer pProgramID) throws DataAccessException;

	void updateEligibleActivity(EligibleActivity pEligibleActivity, String lUserID) throws BPMException, DataAccessException;

	Collection<EligibleActivity> getEligibleActivity(Integer pProgramID, Integer pActivityID, java.sql.Date qualificationEarlyStartDate);

	boolean isEligibleActivityUsedByParticipant(EligibleActivity pEligibleActivity);

	int deleteEligibleActivityByStartDate(Integer programID, Integer activityID, java.sql.Date startDate) throws BPMException, DataAccessException;

	ArrayList<Activity>  getActivityDefinitionsByType(int activityTypeID);

	void deleteExtendedAuthCodes(Integer pProgramID) throws DataAccessException;

	Collection<MemberProgramActivity> getActivityHistory(Integer personID, Date qualificationStartDate) throws DataAccessException;

    ArrayList<ExtEmployerActivity> getExtEmployerActivities() throws DataAccessException;
	Collection<Activity> getEmployerAdminsterdActivities() throws DataAccessException;
	Collection<Activity> selectActivitiesWithMemberAndTransactionDate(String memberId, Date transactionDate);
}
