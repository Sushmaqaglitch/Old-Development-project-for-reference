package com.healthpartners.app.bpm.dto;

import java.io.Serializable;
import java.util.ArrayList;

public class ActivityIncentiveRequirement implements Serializable
{	
	static final long serialVersionUID = 0L;
	
	private Integer programID;
	private Integer groupID;
	private Integer groupRequirementID;	
	private Integer quantity;
	private Integer incentiveOptionID;
	
	
	ArrayList<ActivityIncentiveDetail> activityIncentiveDetails;
	ArrayList<ActivityIncentiveDetail> activityIncentiveDetailsToRemove;
	
	boolean registered;
	

	public ArrayList<ActivityIncentiveDetail> getActivityIncentiveDetails() {
		return activityIncentiveDetails;
	}
	public void setActivityIncentiveDetails(
			ArrayList<ActivityIncentiveDetail> activityIncentiveDetails) {
		this.activityIncentiveDetails = activityIncentiveDetails;
	}
	public Integer getQuantity() {
		return quantity;
	}
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
	public Integer getGroupID() {
		return groupID;
	}
	public void setGroupID(Integer groupID) {
		this.groupID = groupID;
	}
	public Integer getGroupRequirementID() {
		return groupRequirementID;
	}
	public void setGroupRequirementID(Integer groupRequirementID) {
		this.groupRequirementID = groupRequirementID;
	}
	public Integer getIncentiveOptionID() {
		return incentiveOptionID;
	}
	public void setIncentiveOptionID(Integer incentiveOptionID) {
		this.incentiveOptionID = incentiveOptionID;
	}
	public Integer getProgramID() {
		return programID;
	}
	public void setProgramID(Integer programID) {
		this.programID = programID;
	}
	public ArrayList<ActivityIncentiveDetail> getActivityIncentiveDetailsToRemove() {
		return activityIncentiveDetailsToRemove;
	}
	public void setActivityIncentiveDetailsToRemove(
			ArrayList<ActivityIncentiveDetail> activityIncentiveDetailsToRemove) {
		this.activityIncentiveDetailsToRemove = activityIncentiveDetailsToRemove;
	}
	public boolean isRegistered() {
		return registered;
	}
	public void setRegistered(boolean registered) {
		this.registered = registered;
	}
	
	
	
}
