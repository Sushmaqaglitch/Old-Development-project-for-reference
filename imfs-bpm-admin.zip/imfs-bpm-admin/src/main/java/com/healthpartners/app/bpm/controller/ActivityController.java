package com.healthpartners.app.bpm.controller;

import com.healthpartners.app.bpm.common.BPMAdminConstants;
import com.healthpartners.app.bpm.common.BPMAdminUtils;
import com.healthpartners.app.bpm.dto.Activity;
import com.healthpartners.app.bpm.dto.LookUpValueCode;
import com.healthpartners.app.bpm.exception.BPMException;
import com.healthpartners.app.bpm.form.SaveActivityForm;
import com.healthpartners.app.bpm.iface.BusinessProgramService;
import com.healthpartners.app.bpm.session.UserSession;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.core.convert.ConversionService;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.Valid;
import java.io.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

@Controller
public class ActivityController extends BaseController implements Validator {

    private static final String REQUIRED = "required";

    protected final Log logger = LogFactory.getLog(getClass());

    private final ConversionService conversionService;
    private final BusinessProgramService businessProgramService;

    private String delimiter = ",";

    public ActivityController(ConversionService conversionService, BusinessProgramService businessProgramService) {
        this.conversionService = conversionService;
        this.businessProgramService = businessProgramService;
    }

    @GetMapping("/defineActivity")
    public String loadDefineActivity(ModelMap modelMap) {
        try {
            loadActivities(modelMap);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return "defineActivity";
    }

    @GetMapping("/downloadActivityList")
    public void downloadActivityList(HttpServletRequest request, HttpServletResponse response) throws IOException {
        UserSession sessionBean = getUserSession();
        request.setAttribute("activities", sessionBean.getActivities());
        response.setHeader("Content-Type", "text/csv");
        response.setHeader("Content-Disposition", "attachment;filename=\"report.csv\"");
        writeCsv(sessionBean.getActivities(), response.getOutputStream());
    }

    //    @DeleteMapping("/deleteActivity")
    @PostMapping("/deleteActivity")
    public String deleteActivity(@RequestParam(value = "activityID") Integer activityID, ModelMap modelMap, HttpServletRequest request, Locale locale, RedirectAttributes ra) {
        try {
            Activity activityCode = businessProgramService.selectActivity(activityID);
            buildDeleteMessage(locale, ra, activityCode);
            businessProgramService.deleteActivity(activityID);
            loadActivities(modelMap);
        } catch (Exception e) {
            logger.error(e);
            createErrorMessageOnModel(modelMap, getStackTrace(e));
        }

        return "redirect:defineActivity";
    }

    @GetMapping("/addActivity")
    public String loadAddActivity(Map<String, Object> model) throws BPMException {
        Collection<LookUpValueCode> activityTypes = businessProgramService.getActivityTypeCodes();
        SaveActivityForm saveActivityForm = new SaveActivityForm();
        saveActivityForm.setActionType("add");
        saveActivityForm.setLuvActivityTypes(activityTypes);
        saveActivityForm.setCost(BPMAdminUtils.convertDoubleToDecimalFormattedString(Double.valueOf(0)));
        model.put("saveActivityForm", saveActivityForm);

        return "editActivity";
    }

    @PostMapping("/addActivity")
    public String processAddActivitySubmit(@Valid SaveActivityForm saveActivityForm, BindingResult result, ModelMap model, HttpServletRequest request) {
        Activity activity = new Activity();
        String view = saveActivity(saveActivityForm, activity, result, model);
        return view;
    }

    @GetMapping("/editActivity")
    public String loadEditActivity(@RequestParam("activityID") Integer activityId, Map<String, Object> model) throws BPMException {
        Collection<LookUpValueCode> activityTypes = businessProgramService.getActivityTypeCodes();
        Activity activity = businessProgramService.selectActivity(activityId);
        SaveActivityForm saveActivityForm = new SaveActivityForm();
        saveActivityForm.setActionType("edit");
        saveActivityForm.setActivityID(activity.getActivityID());
        saveActivityForm.setSourceSystemActivityID(activity.getSourceActivityID());
        saveActivityForm.setLuvActivityTypes(activityTypes);
        saveActivityForm.setLuvActivityTypeCodeId(activity.getActivityTypeCodeID());
        saveActivityForm.setName(activity.getName());
        saveActivityForm.setDuration(activity.getDuration());
        saveActivityForm.setHostSource(activity.getSource());
        DateFormat df = new SimpleDateFormat("MM/dd/yyyy");
        saveActivityForm.setEffectiveDate(df.format(activity.getEffectiveDate()));
        saveActivityForm.setEndDate(df.format(activity.getEndDate()));
        saveActivityForm.setWebLink(activity.getWebLink());
        saveActivityForm.setDescription(activity.getDescription());
        saveActivityForm.setCost(activity.getCost());
        model.put("saveActivityForm", saveActivityForm);

        return "editActivity";
    }

    @PostMapping("/saveActivity")
    public String processEditActivitySubmit(@Valid SaveActivityForm saveActivityForm, BindingResult result, ModelMap model) throws BPMException {
        Activity activity;
        if (saveActivityForm.getActivityID() == null || saveActivityForm.getActivityID() == 0) {
            activity = new Activity();
        } else {
            activity = businessProgramService.selectActivity(saveActivityForm.getActivityID());
        }

        String view = saveActivity(saveActivityForm, activity, result, model);
        return view;
    }

    private String saveActivity(SaveActivityForm saveActivityForm, Activity activity, BindingResult result, ModelMap modelMap) {
        try {
            validate(saveActivityForm,result);
            if (result.hasErrors()) {
                Collection<LookUpValueCode> activityTypes = businessProgramService.getActivityTypeCodes();
                saveActivityForm.setLuvActivityTypes(activityTypes);
                modelMap.put("saveActivityForm", saveActivityForm);
                return "editActivity";
            }

            LookUpValueCode activityTypeCode = businessProgramService.getActivityTypeCodeById(conversionService.convert(saveActivityForm.getLuvActivityTypeCodeId(), Integer.class));
            activity.setSourceActivityID(saveActivityForm.getSourceSystemActivityID());
            activity.setActivityTypeCodeID(conversionService.convert(saveActivityForm.getLuvActivityTypeCodeId(), Integer.class));
            activity.setName(saveActivityForm.getName());
            activity.setDuration(saveActivityForm.getDuration());
            activity.setSource(saveActivityForm.getHostSource());
            activity.setCost(saveActivityForm.getCost());
            activity.setWebLink(saveActivityForm.getWebLink());
            activity.setDescription(saveActivityForm.getDescription());
            activity.setUserId(getAuthenticatedUserName());
            activity.setEffectiveDate(BPMAdminUtils.getSqlDateFromString(saveActivityForm.getEffectiveDate()));
            activity.setEndDate(BPMAdminUtils.getSqlDateFromString(saveActivityForm.getEndDate()));
            activity.setActivityTypeCodeID(activityTypeCode.getLuvId());

            if (isDuplicateActivity(activity.getActivityID(), activity.getSourceActivityID())) {
                String errorMessage = getMessageSource().getMessage("errors.duplicate.activity", new Object[]{"Duplicate Activity"}, Locale.getDefault());
                result.rejectValue("sourceSystemActivityID", REQUIRED, errorMessage);
                Collection<LookUpValueCode> activityTypes = businessProgramService.getActivityTypeCodes();
                saveActivityForm.setLuvActivityTypes(activityTypes);
                modelMap.put("saveActivityForm", saveActivityForm);
                return "editActivity";
            }

            // Save here (update will check for insert or update in the DAO)
            businessProgramService.updateActivity(activity);

            ArrayList<Activity> lActivities = (ArrayList<Activity>) businessProgramService.selectAllActivities();
            ArrayList<Activity> lExpiredActivities = (ArrayList<Activity>) businessProgramService.selectExpiredActivities();
            //sessionBean.reset();
            modelMap.put("activities", lActivities);
            modelMap.put("expiredActivities", lExpiredActivities);
            getUserSession().setActivities(lActivities);
        } catch (Exception e) {
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
            // Add error stack trace on the request, to be hidden in html.
            createErrorMessageOnModel(modelMap, getStackTrace(e));

            return "redirect:errors";
        }

        return "redirect:defineActivity";
    }

    private void loadActivities(ModelMap modelMap) throws BPMException {
        ArrayList<Activity> lActivities = (ArrayList<Activity>) businessProgramService.selectAllActivities();
        ArrayList<Activity> lExpiredActivities = (ArrayList<Activity>) businessProgramService.selectExpiredActivities();
        modelMap.put("activities", lActivities);
        modelMap.put("expiredActivities", lExpiredActivities);
        UserSession userSession = getUserSession();
        userSession.setActivities(lActivities);
    }

    private void buildDeleteMessage(Locale locale, RedirectAttributes ra, Activity activityCode) {
        String identifier = activityCode.getSourceActivityID();
        String message = getMessageSource().getMessage("messages.activityDeleted", new Object[]{identifier}, locale);
        List<String> messages = new ArrayList<>();
        messages.add(message);
        ra.addFlashAttribute("messages", messages);
    }

    private void writeCsv(Collection<Activity> lActivitys, OutputStream output) throws IOException {
        BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(output, "UTF-8"));
        formatHeaderNWrite(writer);

        for (Activity lActivity : lActivitys) {
            formatDetailNWrite(writer, lActivity);
        }

        closeFileWriter(writer);
    }

    public void closeFileWriter(BufferedWriter writer) {
        try {
            writer.flush();
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void formatHeaderNWrite(BufferedWriter writer) throws IOException {
        writer.append("Activity ID");
        writer.append(delimiter);

        writer.append("Activity Type Code");
        writer.append(delimiter);

        writer.append("Source System Activity ID");
        writer.append(delimiter);

        writer.append("Activity Name");
        writer.append(delimiter);

        writer.append("Duration");
        writer.append(delimiter);

        writer.append("Host Source");
        writer.append(delimiter);

        writer.append("Activity Description");
        writer.append(delimiter);

        writer.append("Effective Date");
        writer.append(delimiter);

        writer.append("End Date");
        writer.append(delimiter);

        writer.append("Insert Date");
        writer.append(delimiter);

        writer.append("Insert User");
        writer.append(delimiter);

        writer.append("Modify Date");
        writer.append(delimiter);

        writer.append("Modify User");
        writer.append(delimiter);

        writer.newLine();
    }


    private void formatDetailNWrite(BufferedWriter writer, Activity lActivity) throws IOException {
        //Internal Activity ID
        writer.append(String.valueOf(lActivity.getActivityID()));
        writer.append(delimiter);

        //Activity Type Code
        writer.append(lActivity.getActivityTypeDesc());
        writer.append(delimiter);

        //Source System Activity ID
        if (lActivity.getSourceActivityID().startsWith("0")) {
            writer.append("'");
        }
        writer.append(lActivity.getSourceActivityID());
        writer.append(delimiter);

        //Activity name
        String name = lActivity.getName().replaceAll(",", "");
        writer.append(name);
        writer.append(delimiter);

        //Duration
        writer.append(String.valueOf(lActivity.getDuration()));
        writer.append(delimiter);

        //Host Source
        writer.append(lActivity.getSource());
        writer.append(delimiter);

        //Activity Description
        String description = lActivity.getDescription().replaceAll(",", "").replace("\n", "").replace("\r", "");
        writer.append(description);
        writer.append(delimiter);

        if (lActivity.getEffectiveDate() != null) {
            writer.append(BPMAdminUtils.formatDateMMddyyyy(lActivity.getEffectiveDate()));
            writer.append(delimiter);
        } else if (lActivity.getEffectiveDate() == null) {
            writer.append("");
            writer.append(delimiter);
        }
        if (lActivity.getEndDate() != null) {
            writer.append(BPMAdminUtils.formatDateMMddyyyy(lActivity.getEndDate()));
            writer.append(delimiter);
        } else if (lActivity.getEndDate() == null) {
            writer.append("");
            writer.append(delimiter);
        }

        //Insert Date
        if (lActivity.getInsertDate() != null) {
            writer.append(BPMAdminUtils.formatDateMMddyyyy(lActivity.getInsertDate()));
            writer.append(delimiter);
        } else if (lActivity.getInsertDate() == null) {
            writer.append("");
            writer.append(delimiter);
        }

        //Insert User
        writer.append(lActivity.getInsertUser());
        writer.append(delimiter);

        //Modify Date
        if (lActivity.getModifyDate() != null) {
            writer.append(BPMAdminUtils.formatDateMMddyyyy(lActivity.getModifyDate()));
            writer.append(delimiter);
        } else if (lActivity.getModifyDate() == null) {
            writer.append("");
            writer.append(delimiter);
        }

        //Modify User
        if (lActivity.getModifyUser() != null) {
            writer.append(lActivity.getModifyUser());
            writer.append(delimiter);
        } else if (lActivity.getModifyUser() == null) {
            writer.append("");
            writer.append(delimiter);
        }

        writer.newLine();
    }

    protected String getStackTrace(Throwable t) {
        StringWriter stringWritter = new StringWriter();
        PrintWriter printWritter = new PrintWriter(stringWritter, true);
        t.printStackTrace(printWritter);
        printWritter.flush();
        stringWritter.flush();
        return stringWritter.toString();
    }

    private String getAuthenticatedUserName() {
        String userName = null;

        Authentication auth = SecurityContextHolder.getContext()
                .getAuthentication();
        if (auth != null) {
            userName = auth.getName();
        }

        return userName;
    }

    @Override
    public boolean supports(Class<?> clazz) {
        return SaveActivityForm.class.isAssignableFrom(clazz);
    }

    @Override
    public void validate(Object target, Errors errors) {
        SaveActivityForm form = (SaveActivityForm) target;

        getValidationSupport().validateNotSpecialChar("sourceSystemActivityID", form.getSourceSystemActivityID(), errors, new Object[]{"Source System Activity ID"});
        getValidationSupport().validateNotSpecialChar("hostSource", form.getHostSource(), errors, new Object[]{"Host Source"});
        getValidationSupport().validateNotSpecialChar("name", form.getName(), errors, new Object[]{"Activity Name"});
        getValidationSupport().validateNotSpecialChar("webLink", form.getWebLink(), errors, new Object[]{"URL"});
        getValidationSupport().validateNotSpecialChar("description", form.getDescription(), errors, new Object[]{"Description"});

        boolean isValidEffectiveDate = validateNotDate(form.getEffectiveDate());
        if (!isValidEffectiveDate) {
            String errorMessage = getMessageSource().getMessage("errors.date", new Object[]{"Activity Effective Date"}, Locale.getDefault());
            errors.rejectValue("effectiveDate", REQUIRED, errorMessage);
        }

        boolean isValidEndDate = validateNotDate(form.getEndDate());
        if (!isValidEndDate) {
            String errorMessage = getMessageSource().getMessage("errors.date", new Object[]{"Activity End Date"}, Locale.getDefault());
            errors.rejectValue("endDate", REQUIRED, errorMessage);
        }

        if (isValidEffectiveDate && isValidEndDate) {
            if(!validateBeforeOrEqual(form.getEffectiveDate(), form.getEndDate())) {
                String errorMessage = getMessageSource().getMessage("errors.beforethisdate", new Object[]{"Activity Effective Date","Activity End Date"}, Locale.getDefault());
                errors.rejectValue("effectiveDate", REQUIRED, errorMessage);
            }
        }
    }

    protected boolean isDuplicateActivity(Integer activityID, String activitySourceId) throws Exception {
        boolean result = false;
        try {
            ArrayList<Activity> lActivities = (ArrayList<Activity>)
                    businessProgramService.getActivities();

            Iterator<Activity> iter = lActivities.iterator();
            while (iter.hasNext()) {
                Activity activity = (Activity) iter.next();
                if (activity.getSourceActivityID().equals(activitySourceId)) {
                    // Creating a brand new activity with the same source activity ID or
                    // saving a different one with the same source activity ID.
                    if (activityID == null || (activity.getActivityID().intValue() != activityID.intValue())) {
                        result = true;
                    }
                }
            }

        } catch (Exception e) {
            logger.error("An unexpected error has occurred in SaveActivity.validateDuplicateActivity: " + e.getMessage(), e);
            throw new Exception(e);
        }

        return result;
    }

    protected boolean validateNotDate(String fieldValue) {
        boolean result = true;

        if (StringUtils.isNotEmpty(fieldValue)) {
            try {
                SimpleDateFormat fmt = new SimpleDateFormat(
                        BPMAdminConstants.HP_BPM_ADMIN_UI_COMMON_DATE_FORMAT);
                java.util.Date lParsedDateDate = fmt.parse(fieldValue.trim());
                // If was successfully parsed. So check the day and month ranges.
                result = BPMAdminUtils.isDateValid(fieldValue.trim());

            } catch (Exception ne) {
                result = false;
            }
        } else {
            result = false;
        }

        return result;
    }

    public boolean validateBeforeOrEqual(String fieldValue, String referenceDate) {
        boolean validDate = false;
        try {
            SimpleDateFormat fmt = new SimpleDateFormat(BPMAdminConstants.HP_BPM_ADMIN_UI_COMMON_DATE_FORMAT);
            Date lActivityStatusDate = fmt.parse(fieldValue.trim());
            Date lReferenceDate = fmt.parse(referenceDate.trim());
            if (lActivityStatusDate.before(lReferenceDate) || lActivityStatusDate.equals(lReferenceDate)) {
                validDate = true;
            }
        } catch (Exception ne) {
            validDate = false;
        }

        return validDate;
    }
}
