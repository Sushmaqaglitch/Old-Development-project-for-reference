package com.healthpartners.app.bpm.controller;

import com.healthpartners.app.bpm.common.BPMAdminConstants;
import com.healthpartners.app.bpm.common.BPMAdminUtils;
import com.healthpartners.app.bpm.common.BPMPagination;
import com.healthpartners.app.bpm.dto.*;
import com.healthpartners.app.bpm.dto.*;
import com.healthpartners.app.bpm.exception.BPMException;
import com.healthpartners.app.bpm.form.PersonContractRecycleSearchForm;
import com.healthpartners.app.bpm.form.SavePersonContractRecycleForm;
import com.healthpartners.app.bpm.iface.MemberService;
import com.healthpartners.app.bpm.pageable.PageablePersonContractRecycle;
import com.healthpartners.app.bpm.session.UserSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.ArrayList;
import java.util.Iterator;

@Controller
public class PersonContractRecycleEditController extends BaseController implements Validator {

    private final MemberService memberService;


    public PersonContractRecycleEditController(MemberService memberService) {
        this.memberService = memberService;
    }

    @GetMapping("/editPersonContractRecycle")
    public String load(@RequestParam(name = "recycleId") String recycleId, @RequestParam(name = "memberId") String memberId, ModelMap modelMap) throws BPMException {
        try {
            populateFormForEdit(modelMap, recycleId, memberId);
        } catch (Exception e) {
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
            modelMap.put("errorMsg", getStackTrace(e));
        }

        return "editPersonContractRecycle";
    }

    @PostMapping("/savePersonContractRecycle")
    public String submitSave(@ModelAttribute("savePersonContractRecycleForm") SavePersonContractRecycleForm form, ModelMap modelMap, BindingResult result, RedirectAttributes ra) throws Exception {
        try {
            validate(form, result);
            if (result.hasErrors()) {
                modelMap.put("memberDetail", getUserSession().getMemberDetail());
                modelMap.put("relatedMemberDetailList", getUserSession().getRelatedMemberDetailList());
                modelMap.put("personContractRecycle", getUserSession().getPersonContractRecycle());
                modelMap.put("recycleStatusCodes", getUserSession().getRecycleStatusCodes());
            }

            save(form, modelMap);
            return redirectBackToSearch(ra);

        } catch (Exception e) {
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
            // Add error stack trace on the request, to be hidden in html.
            modelMap.put("errorMsg", getStackTrace(e));
        }

        return "editPersonContractRecycle";
    }

    @PostMapping(value = "/savePersonContractRecycle", params = "back")
    public String submitBack(@ModelAttribute("savePersonContractRecycleForm") SavePersonContractRecycleForm form, RedirectAttributes ra) {
        return redirectBackToSearch(ra);
    }

    private String redirectBackToSearch(RedirectAttributes ra) {
        PersonContractRecycleSearchForm personContractFulfillRecycleSearchForm = new PersonContractRecycleSearchForm();
        ra.addFlashAttribute("personContractFulfillRecycleSearchForm", personContractFulfillRecycleSearchForm);
        return "redirect:personContractRecycleSearch";
    }

    private void populateFormForEdit(ModelMap modelMap, String recycleId, String memberId) throws BPMException {
        SavePersonContractRecycleForm form = new SavePersonContractRecycleForm();
        modelMap.put("savePersonContractRecycleForm", form);

        PersonContractRecycle personContractRecycle = memberService.getMemberContractRecycle(Integer.valueOf(recycleId));

        MemberDetail memberDetail = memberService.getMemberDetail(memberId, personContractRecycle.getProgramId());

        ArrayList<MemberDetail> lRelatedMemberDetailList = (ArrayList<MemberDetail>) memberService.getRelatedMemberDetail(memberId);
        if (memberDetail == null) {
            createNoResultsFoundMessageOnModel(modelMap);
        }

        ArrayList<LookUpValueCode> lLuvRecycleStatusCodes = getUserSession().getRecycleStatusCodes();

        //Lookup recycle status id description.
        Iterator<LookUpValueCode> iter = lLuvRecycleStatusCodes.iterator();
        while (iter.hasNext()) {
            LookUpValueCode lookupValueCode = iter.next();
            if (lookupValueCode.getLuvId().equals(personContractRecycle.getRecycleStatusId())) {
                personContractRecycle.setRecycleStatusId(lookupValueCode.getLuvId());
                personContractRecycle.setRecycleStatus(lookupValueCode.getLuvVal());
            }
        }

        getUserSession().setMemberDetail(memberDetail);
        getUserSession().setRelatedMemberDetailList(lRelatedMemberDetailList);
        getUserSession().setPersonContractRecycle(personContractRecycle);

        modelMap.put("memberDetail", memberDetail);
        modelMap.put("relatedMemberDetailList", lRelatedMemberDetailList);
        modelMap.put("personContractRecycle", personContractRecycle);
        modelMap.put("recycleStatusCodes", lLuvRecycleStatusCodes);

        form.setReason(personContractRecycle.getReasonDesc());
    }

    private void save(SavePersonContractRecycleForm lSavePersonContractRecycleForm, ModelMap modelMap) throws BPMException {
        String lUserID = getUserSessionSupport().getAuthenticatedUsername();

        ArrayList<LookUpValueCode> lLuvRecycleStatusCodes = getUserSession().getRecycleStatusCodes();
        lSavePersonContractRecycleForm.setRecycleStatusCodes(lLuvRecycleStatusCodes);

        PersonContractRecycle lPersonContractRecycle = getUserSession().getPersonContractRecycle();
        lPersonContractRecycle.setRecycleId(Integer.valueOf(lSavePersonContractRecycleForm.getRecycleId()));
        lPersonContractRecycle.setApproverUserId(lUserID);
        lPersonContractRecycle.setApproverUserId(lSavePersonContractRecycleForm.getApprover());
        lPersonContractRecycle.setReasonDesc(lSavePersonContractRecycleForm.getReason());
        lPersonContractRecycle.setRecycleStatusId(Integer.valueOf(lSavePersonContractRecycleForm.getRecycleStatusId()));

        memberService.updatePersonContractRecycle(lPersonContractRecycle);

        //update contract status date so person contract comes over with the membership feed process.
        memberService.updateMemberProgramStatusContractStatusDate(lPersonContractRecycle.getPersonNumber(), lPersonContractRecycle.getProgramId());

        PersonContractRecycle personContractRecycle = memberService.getMemberContractRecycle(Integer.valueOf(lSavePersonContractRecycleForm.getRecycleId()));
        modelMap.put("personContractRecycle", personContractRecycle);

        getUserSession().setRecycleStatusCodes(lLuvRecycleStatusCodes);

        // After having saved the changes, retrieve a fresh list of recycles using the same criteria that
        // were used before. This way the records that were changed will not re-appear on the screen.
        RecycleSearchCriteria lRecycleSearchCriteria = getUserSession().getRecycleSearchCriteria();
        String lRecycleStatusDateString = lRecycleSearchCriteria.getRecycleStatusDateString();
        java.sql.Date lRecycleDate = null;
        Integer lRecycleStatusIdInt = 0;
        if (lRecycleSearchCriteria.getRecycleStatusID() != null && BPMAdminUtils.isValueInteger(lRecycleSearchCriteria.getRecycleStatusID())) {
            lRecycleStatusIdInt = Integer.valueOf(lRecycleSearchCriteria.getRecycleStatusID());
        }

        if (lRecycleStatusDateString != null && lRecycleStatusDateString.length() > 0) {
            lRecycleDate = BPMAdminUtils.convertStringToSqlDate(lRecycleStatusDateString, BPMAdminConstants.HP_BPM_ADMIN_UI_COMMON_DATE_FORMAT);
        }
        ArrayList<PersonContractRecycle> lPersonContractsRecycle =
                (ArrayList<PersonContractRecycle>) memberService.getMemberContractsRecycle(lRecycleSearchCriteria.getMemberID()
                        , lRecycleSearchCriteria.getGroupNo()
                        , lRecycleSearchCriteria.getContractNo()
                        , lRecycleDate
                        , lRecycleStatusIdInt
                        , lRecycleSearchCriteria.getProgramName());

        getUserSession().setPersonContractsRecycle(lPersonContractsRecycle);
        boolean newDTOList = true;
        // Set actionType to empty string to start pagination from the beginning.
        String actionType = "";
        setPersonContractRecyclePagination(modelMap, getUserSession(), actionType, newDTOList);

        ArrayList<PersonContractRecycle> personContractsRecyclePerPage = getUserSession().getPersonContractsRecyclePerPage();
        ArrayList<PersonContractRecycle> personContractsRecycle = getUserSession().getPersonContractsRecycle();

        modelMap.put("recycleStatusCodes", lLuvRecycleStatusCodes);
        modelMap.put("personContractsRecycle", personContractsRecyclePerPage);

        setAttributesForPaginationOnModel(modelMap, personContractsRecycle.size(), getUserSession().getPagination());
    }

    private void setPersonContractRecyclePagination(ModelMap modelMap, UserSession sessionBean, String actionType, boolean newDTOList) {
        ArrayList<PersonContractRecycle> lPersonContractsRecycleList = sessionBean.getPersonContractsRecycle();

        /**
         * Create a Pageable wrapper for the array list.
         * Create a Pagination object and point it to the wrapper.
         */
        BPMPagination pagination = sessionBean.getPaginationMap().get(PERSON_CONTRACT_RECYCLE_LIST);
        PageablePersonContractRecycle lPPR = null;
        if (pagination == null || newDTOList) {
            lPPR = new PageablePersonContractRecycle(lPersonContractsRecycleList);
            lPPR.addRowNumber();
            pagination = new BPMPagination(lPPR, new ArrayList<Object>(lPersonContractsRecycleList));
            sessionBean.getPaginationMap().put(PERSON_CONTRACT_RECYCLE_LIST, pagination);
        }

        ArrayList<PersonContractRecycle> lPersonContractsRecyclePerPage = (ArrayList<PersonContractRecycle>) determineNextOrBackAction(actionType, pagination);
        setAttributesForPaginationOnModel(modelMap, lPersonContractsRecycleList.size(), pagination);
        sessionBean.setPagination(pagination);

        modelMap.put("personContractsRecycle", lPersonContractsRecyclePerPage);
        sessionBean.setPersonContractsRecyclePerPage(lPersonContractsRecyclePerPage);
    }

    @Override
    public boolean supports(Class<?> clazz) {
        return SavePersonContractRecycleForm.class.isAssignableFrom(clazz);
    }

    @Override
    public void validate(Object target, Errors errors) {
        SavePersonContractRecycleForm form = (SavePersonContractRecycleForm) target;

        getValidationSupport().validateRequiredFieldIsNotEmpty("reason", form.getReason(), errors, new Object[]{"Reason"});
        getValidationSupport().validateRequiredFieldIsNotEmpty("approver", form.getApprover(), errors, new Object[]{"Approver"});

        getValidationSupport().validateRequiredFieldIsNotEmpty("recycleStatusId", form.getRecycleStatusId(), errors, new Object[]{"Recycle Status Id"});

        Iterator<LookUpValueCode> iter = (Iterator<LookUpValueCode>) getUserSession().getRecycleStatusCodes().iterator();
        while (iter.hasNext()) {
            LookUpValueCode lookupValueCode = iter.next();
            if (lookupValueCode.getLuvVal().equals(BPMAdminConstants.BPM_LUV_RECYCLE_STATUS_RELEASED)) {
                if (lookupValueCode.getLuvId().equals(Integer.valueOf(form.getRecycleStatusId()))) {
                    recycleReleaseNotAllowedError("recycleStatusId", errors);
                }
            }
        }
    }

    private boolean recycleReleaseNotAllowedError(String fieldName, Errors errors) {
        String errorMessage = getMessage("errors.releasedNotAllowedForUpdate", null);
        errors.rejectValue(fieldName, REQUIRED, errorMessage);
        return true;
    }

}
