package com.healthpartners.app.bpm.dto;

import com.healthpartners.app.bpm.common.BPMAdminConstants;
//import com.healthpartners.service.bpm.common.BPMConstants;
import com.healthpartners.service.bpm.common.BPMConstants;
import com.healthpartners.service.bpm.dto.MemberActivity;
import com.healthpartners.service.bpm.dto.QualificationOverride;
//import com.healthpartners.service.bpm.dto.QualificationOverride;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collection;
import java.util.Iterator;

/**
 * @author mxthoutam
 * 
 */
public class MemberProgramDetail implements Serializable {

    static final long serialVersionUID = 0L;

    private Integer personDemographicsID;
    private Integer personID;

    private String memberID;

    private Integer programID;

    private Integer contractNumber;

    private Integer contractStatusCodeID;
    private String contractStatusCodeValue;

    private Integer memberProgramStatusCodeID;
    private String memberProgramStatusCodeValue;

    private String programName;

    private String programTypeCodeID;

    private java.sql.Date qualificationWindowStartDate;

    private java.sql.Date qualificationWindowEndDate;

    private String groupNumber;

    private String groupName;

    private String siteNumber;

    private String siteName;

    private java.sql.Date newHireDate;

    private java.sql.Date memberStatusDate;
    private java.sql.Date contractStatusDate;

    private String relationshipCode;

    private java.sql.Date participationEndDate;
    private String participationEndDateString;
    private java.sql.Date contractEndDate;

    private int programStatusCodeID;
    private String programStatusCodeValue;
    private String programStatusDesc;

    private java.sql.Date lastPushDate;
    private java.sql.Date statusCalcEndDate;
    private boolean memberStatusCalcDatePassed;
    private boolean contractStatusCalcDatePassed;

    private String participationCodeValue;
    private String participationCodeDesc;

    private java.sql.Date effectiveDate;
    private java.sql.Date endDate;

    private String healthPlanCode;
    private String healthPlanDesc;

    private String externalID;
    private String employeeIndicator;
    private java.sql.Date eligibleHireDate;

    private String qualificationCheckmarkName;

    private java.sql.Date coverageDate;

    private Collection<QualificationOverride> memberExemptions;

    private Collection<MemberProgramActivity> memberActivities;

    private Collection<MemberProgramActivity> memberActivitiesNoDups;

    private Collection<MemberActivity> personProgramActivities;

    private Collection<PersonActivityIncentive> personActivityIncentives;

    private Collection<ContractProgramIncentive> contractProgramIncentives;

    private Collection<MemberProgramIncentiveTO> memberProgramIncentives;

    private Collection<MemberStatusDetail> memberStatusDetails;

    private Collection<MemberPackage> memberPackages;

    SimpleDateFormat fmt = new SimpleDateFormat(
            BPMAdminConstants.HP_BPM_ADMIN_UI_COMMON_DATE_FORMAT);

    String qualificationWindowStartDateFormat;
    String qualificationWindowEndDateFormat;


    public MemberProgramDetail() {
        super();
    }

    public Integer getContractNumber() {
        return contractNumber;
    }

    public void setContractNumber(Integer contractNumber) {
        this.contractNumber = contractNumber;
    }

    public String getContractStatusCodeValue() {
        return contractStatusCodeValue;
    }

    public void setContractStatusCodeValue(String contractStatusCodeValue) {
        this.contractStatusCodeValue = contractStatusCodeValue;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public String getGroupNumber() {
        return groupNumber;
    }

    public void setGroupNumber(String groupNumber) {
        this.groupNumber = groupNumber;
    }

    public String getMemberID() {
        return memberID;
    }

    public void setMemberID(String memberID) {
        this.memberID = memberID;
    }

    public String getMemberProgramStatusCodeValue() {
        return memberProgramStatusCodeValue;
    }

    public void setMemberProgramStatusCodeValue(
            String memberProgramStatusCodeValue) {
        this.memberProgramStatusCodeValue = memberProgramStatusCodeValue;
    }

    public Integer getPersonID() {
        return personID;
    }

    public void setPersonID(Integer personID) {
        this.personID = personID;
    }

    public Integer getProgramID() {
        return programID;
    }

    public void setProgramID(Integer programID) {
        this.programID = programID;
    }

    public String getProgramName() {
        return programName;
    }

    public void setProgramName(String programName) {
        this.programName = programName;
    }

    public String getProgramTypeCodeID() {
        return programTypeCodeID;
    }

    public void setProgramTypeCodeID(String programTypeCodeID) {
        this.programTypeCodeID = programTypeCodeID;
    }

    public java.sql.Date getQualificationWindowEndDate() {
        return qualificationWindowEndDate;
    }

    public void setQualificationWindowEndDate(
            java.sql.Date qualificationWindowEndDate) {
        this.qualificationWindowEndDate = qualificationWindowEndDate;
    }

    public java.sql.Date getQualificationWindowStartDate() {
        return qualificationWindowStartDate;
    }

    public void setQualificationWindowStartDate(
            java.sql.Date qualificationWindowStartDate) {
        this.qualificationWindowStartDate = qualificationWindowStartDate;
    }


    public String getSiteName() {
        return siteName;
    }

    public void setSiteName(String siteName) {
        this.siteName = siteName;
    }

    public String getSiteNumber() {
        return siteNumber;
    }

    public void setSiteNumber(String siteNumber) {
        this.siteNumber = siteNumber;
    }

    public Collection<QualificationOverride> getMemberExemptions() {
        return memberExemptions;
    }

    public void setMemberExemptions(
            Collection<QualificationOverride> memberExemptions) {
        this.memberExemptions = memberExemptions;
    }

    public String getApproverUser() {
        String approverUser = null;
        if (getManualExemption() != null) {
            approverUser = getManualExemption().getApproverUserId();
        }
        return approverUser;
    }

    public String getExemptionReason() {
        String exemptionReason = null;
        if (getManualExemption() != null) {
            exemptionReason = getManualExemption().getReasonCode();
        }
        return exemptionReason;
    }

    public Calendar getExemptionDate()
    {
        Calendar exemptionDate = null;
        if (getManualExemption() != null) {
            exemptionDate = getManualExemption().getIssueDate();
        }
        return exemptionDate;
    }

    public QualificationOverride getManualExemption() {
        QualificationOverride exemption = null;

        if (memberExemptions != null) {
            Iterator<QualificationOverride> itr = memberExemptions.iterator();
            while (itr.hasNext()) {
                QualificationOverride memberExemption = itr.next();
                if (BPMConstants.OVERRIDE_CODE_MANUAL_EXEMPTION
                        .equalsIgnoreCase(memberExemption.getOverrideCode())) {
                    exemption = memberExemption;
                    break;
                }
            }
        }
        return exemption;
    }

    public MemberProgramActivity getManualActivityStatusOverride(String activityEventName) {
        MemberProgramActivity activityStatusOverride = null;

        if (memberActivitiesNoDups != null) {
            Iterator<MemberProgramActivity> itr = memberActivitiesNoDups.iterator();
            while (itr.hasNext()) {
                MemberProgramActivity memberActivityStatusOverride = itr.next();
                if (memberActivityStatusOverride.getActivityName().equals(activityEventName)) {
                    if (BPMConstants.OVERRIDE_CODE_MANUAL_ACTIVITYSTATUSOVERRIDE
                            .equalsIgnoreCase(memberActivityStatusOverride.getWaiveFlag())
                            || BPMConstants.PROCESSING_STATUS_ACTV_EXMPT.equalsIgnoreCase(memberActivityStatusOverride.getWaiveFlag())
                    )
                    {
                        activityStatusOverride = memberActivityStatusOverride;
                        break;
                    }
                }
            }
        }
        return activityStatusOverride;
    }



    public Collection<MemberProgramActivity> getMemberActivities() {
        return memberActivities;
    }

    public void setMemberActivities(
            Collection<MemberProgramActivity> memberActivities) {
        this.memberActivities = memberActivities;
    }

    public final java.sql.Date getNewHireDate() {
        return newHireDate;
    }

    public final void setNewHireDate(java.sql.Date newHireDate) {
        this.newHireDate = newHireDate;
    }

    public java.sql.Date getMemberStatusDate() {
        return memberStatusDate;
    }

    public void setMemberStatusDate(java.sql.Date memberStatusDate) {
        this.memberStatusDate = memberStatusDate;
    }

    public java.sql.Date getContractStatusDate() {
        return contractStatusDate;
    }

    public void setContractStatusDate(java.sql.Date contractStatusDate) {
        this.contractStatusDate = contractStatusDate;
    }

    public final String getRelationshipCode() {
        return relationshipCode;
    }

    public final void setRelationshipCode(String relationshipCode) {
        this.relationshipCode = relationshipCode;
    }

    public final java.sql.Date getParticipationEndDate() {
        return participationEndDate;
    }

    public final void setParticipationEndDate(java.sql.Date participationEndDate) {
        this.participationEndDate = participationEndDate;
    }

    public Collection<MemberProgramActivity> getMemberActivitiesNoDups() {
        return memberActivitiesNoDups;
    }

    public void setMemberActivitiesNoDups(
            Collection<MemberProgramActivity> memberActivitiesNoDups) {
        this.memberActivitiesNoDups = memberActivitiesNoDups;
    }

    public String getQualificationWindowStartDateFormat() {
        return qualificationWindowStartDateFormat;
    }

    public void setQualificationWindowStartDateFormat(
            String qualificationWindowStartDateFormat) {
        this.qualificationWindowStartDateFormat = qualificationWindowStartDateFormat;
    }

    public String getQualificationWindowEndDateFormat() {
        return qualificationWindowEndDateFormat;
    }

    public void setQualificationWindowEndDateFormat(
            String qualificationWindowEndDateFormat) {
        this.qualificationWindowEndDateFormat = qualificationWindowEndDateFormat;
    }

    public final Collection<MemberActivity> getPersonProgramActivities() {
        return personProgramActivities;
    }

    public final void setPersonProgramActivities(
            Collection<MemberActivity> personProgramActivities) {
        this.personProgramActivities = personProgramActivities;
    }

    public int getProgramStatusCodeID() {
        return programStatusCodeID;
    }

    public void setProgramStatusCodeID(int programStatusCodeID) {
        this.programStatusCodeID = programStatusCodeID;
    }

    public String getProgramStatusCodeValue() {
        return programStatusCodeValue;
    }

    public void setProgramStatusCodeValue(String programStatusCodeValue) {
        this.programStatusCodeValue = programStatusCodeValue;
    }

    public String getProgramStatusDesc() {
        return programStatusDesc;
    }

    public void setProgramStatusDesc(String programStatusDesc) {
        this.programStatusDesc = programStatusDesc;
    }

    public final java.sql.Date getLastPushDate() {
        return lastPushDate;
    }

    public final void setLastPushDate(java.sql.Date lastPushDate) {
        this.lastPushDate = lastPushDate;
    }

    public final java.sql.Date getContractEndDate() {
        return contractEndDate;
    }

    public final void setContractEndDate(java.sql.Date contractEndDate) {
        this.contractEndDate = contractEndDate;
    }

    public final java.sql.Date getStatusCalcEndDate() {
        return statusCalcEndDate;
    }

    public final void setStatusCalcEndDate(java.sql.Date statusCalcEndDate) {
        this.statusCalcEndDate = statusCalcEndDate;
    }



    public final boolean isContractStatusCalcDatePassed() {
        return contractStatusCalcDatePassed;
    }

    public final void setContractStatusCalcDatePassed(
            boolean contractStatusCalcDatePassed) {
        this.contractStatusCalcDatePassed = contractStatusCalcDatePassed;
    }

    public final boolean isMemberStatusCalcDatePassed() {
        return memberStatusCalcDatePassed;
    }

    public final void setMemberStatusCalcDatePassed(
            boolean memberStatusCalcDatePassed) {
        this.memberStatusCalcDatePassed = memberStatusCalcDatePassed;
    }

    public final Integer getContractStatusCodeID() {
        return contractStatusCodeID;
    }

    public final void setContractStatusCodeID(Integer contractStatusCodeID) {
        this.contractStatusCodeID = contractStatusCodeID;
    }

    public final Integer getMemberProgramStatusCodeID() {
        return memberProgramStatusCodeID;
    }

    public final void setMemberProgramStatusCodeID(Integer memberProgramStatusCodeID) {
        this.memberProgramStatusCodeID = memberProgramStatusCodeID;
    }

    public final String getParticipationCodeValue() {
        return participationCodeValue;
    }

    public final void setParticipationCodeValue(String participationCodeValue) {
        this.participationCodeValue = participationCodeValue;
    }

    public final String getParticipationCodeDesc() {
        return participationCodeDesc;
    }

    public final void setParticipationCodeDesc(String participationCodeDesc) {
        this.participationCodeDesc = participationCodeDesc;
    }

    public final java.sql.Date getEffectiveDate() {
        return effectiveDate;
    }

    public final void setEffectiveDate(java.sql.Date effectiveDate) {
        this.effectiveDate = effectiveDate;
    }

    public final java.sql.Date getEndDate() {
        return endDate;
    }

    public final void setEndDate(java.sql.Date endDate) {
        this.endDate = endDate;
    }

    public Integer getPersonDemographicsID() {
        return personDemographicsID;
    }

    public void setPersonDemographicsID(Integer personDemographicsID) {
        this.personDemographicsID = personDemographicsID;
    }

    public Collection<PersonActivityIncentive> getPersonActivityIncentives() {
        return personActivityIncentives;
    }

    public void setPersonActivityIncentives(
            Collection<PersonActivityIncentive> personActivityIncentives) {
        this.personActivityIncentives = personActivityIncentives;
    }

    public Collection<ContractProgramIncentive> getContractProgramIncentives() {
        return contractProgramIncentives;
    }

    public void setContractProgramIncentives(
            Collection<ContractProgramIncentive> contractProgramIncentives) {
        this.contractProgramIncentives = contractProgramIncentives;
    }

    public String getHealthPlanCode() {
        return healthPlanCode;
    }

    public void setHealthPlanCode(String healthPlanCode) {
        this.healthPlanCode = healthPlanCode;
    }

    public String getHealthPlanDesc() {
        return healthPlanDesc;
    }

    public void setHealthPlanDesc(String healthPlanDesc) {
        this.healthPlanDesc = healthPlanDesc;
    }

    public final String getExternalID() {
        return externalID;
    }

    public final void setExternalID(String externalID) {
        this.externalID = externalID;
    }

    public final String getEmployeeIndicator() {
        return employeeIndicator;
    }

    public final void setEmployeeIndicator(String employeeIndicator) {
        this.employeeIndicator = employeeIndicator;
    }

    public final java.sql.Date getEligibleHireDate() {
        return eligibleHireDate;
    }

    public final void setEligibleHireDate(java.sql.Date eligibleHireDate) {
        this.eligibleHireDate = eligibleHireDate;
    }

    public String getQualificationCheckmarkName() {
        return qualificationCheckmarkName;
    }

    public void setQualificationCheckmarkName(String qualificationCheckmarkName) {
        this.qualificationCheckmarkName = qualificationCheckmarkName;
    }



    public java.sql.Date getCoverageDate() {
        return coverageDate;
    }

    public void setCoverageDate(java.sql.Date coverageDate) {
        this.coverageDate = coverageDate;
    }


    public Collection<MemberProgramIncentiveTO> getMemberProgramIncentives() {
        return memberProgramIncentives;
    }

    public void setMemberProgramIncentives(
            Collection<MemberProgramIncentiveTO> memberProgramIncentives) {
        this.memberProgramIncentives = memberProgramIncentives;
    }

    public String getParticipationEndDateString() {
        return participationEndDateString;
    }

    public void setParticipationEndDateString(String participationEndDateString) {
        this.participationEndDateString = participationEndDateString;
    }

    public Collection<MemberStatusDetail> getMemberStatusDetails() {
        return memberStatusDetails;
    }

    public void setMemberStatusDetails(
            Collection<MemberStatusDetail> memberStatusDetails) {
        this.memberStatusDetails = memberStatusDetails;
    }

    public Collection<MemberPackage> getMemberPackages() {
        return memberPackages;
    }

    public void setMemberPackages(Collection<MemberPackage> memberPackages) {
        this.memberPackages = memberPackages;
    }


}
