package com.healthpartners.app.bpm.service;

import com.healthpartners.app.bpm.common.BPMAdminConstants;
import com.healthpartners.app.bpm.common.BPMAdminUtils;
import com.healthpartners.app.bpm.common.ValidationSupport;
import com.healthpartners.app.bpm.dto.BusinessProgram;
import com.healthpartners.app.bpm.dto.ProgramIncentiveOption;
import com.healthpartners.app.bpm.form.SaveProgramForm;
import com.healthpartners.app.bpm.iface.BusinessProgramService;
import com.healthpartners.service.bpm.common.BPMConstants;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Service;
import org.springframework.validation.Errors;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

@Service
public class ProgramValidationService {

    private SimpleDateFormat fmt = new SimpleDateFormat(BPMAdminConstants.HP_BPM_ADMIN_UI_COMMON_DATE_FORMAT);

    protected final Log logger = LogFactory.getLog(getClass());

    private final ValidationSupport validationSupport;
    private final BusinessProgramService businessProgramService;

    public ProgramValidationService(ValidationSupport validationSupport, BusinessProgramService businessProgramService) {
        this.validationSupport = validationSupport;
        this.businessProgramService = businessProgramService;
    }

    public void validateSaveProgram(SaveProgramForm form, Errors errors) {
        getValidationSupport().validateNotZero("programStatusCodeID", String.valueOf(form.getProgramStatusCodeID()), errors, new Object[]{"Program Status"});
        getValidationSupport().validateNotZero("familyParticipationRequirement", String.valueOf(form.getFamilyParticipationRequirement()), errors, new Object[]{"ParticipationRequirement Status"});
        getValidationSupport().validateNotSpecialChar("additionalGroupProgramInfo", form.getAdditionalGroupProgramInfo(), errors, new Object[]{"Additional Program Info"});
        getValidationSupport().validateDateFormat("qualificationWindowStartDate", form.getQualificationWindowStartDate(), errors, new Object[]{"Qualification Start Date"});
        getValidationSupport().validateDateFormat("qualificationWindowEndDate", form.getQualificationWindowEndDate(), errors, new Object[]{"Qualification End Date"});
        getValidationSupport().validateDateFormat("newHireDate", form.getNewHireDate(), errors, new Object[]{"New Hire Date"});
        getValidationSupport().validateDateFormat("releaseDate", form.getReleaseDate(), errors, new Object[]{"Release Date"});
        getValidationSupport().validateDateFormat("effectiveDate", form.getEffectiveDate(), errors, new Object[]{"Effective Date"});
        getValidationSupport().validateDateFormat("endDate", form.getEndDate(), errors, new Object[]{"End Date"});

        validateMembershipActivationDate(errors, form);
        validateQualificationPeriodWithinProgramYear(errors, form);
        validateQualificationEndDateNotBeforeQualificationStartDate(errors, form);
        validateProgramEffectiveDateIfMembersExist(errors, form);
        getValidationSupport().validateAfter("newHireDate", form.getNewHireDate(), form.getEffectiveDate(), errors, new Object[]{"Program-Year Effective Date"});
        getValidationSupport().validateNotZero("familyParticipationRequirement", String.valueOf(form.getFamilyParticipationRequirement()), errors, new Object[]{"Participation Requirement"});
        getValidationSupport().validateNotZero("programStatusCodeID", String.valueOf(form.getProgramStatusCodeID()), errors, new Object[]{"Program Status"});

        if (form.getStatusCalcEndDate() != null && form.getStatusCalcEndDate().length() > 0) {
            getValidationSupport().validateAfter("statusCalcEndDate", form.getStatusCalcEndDate(), form.getEffectiveDate(), errors, new Object[]{"Program-Year Effective Date"});
        }

        if (form.getContributionStartDate() != null && form.getContributionStartDate().length() > 0) {
            getValidationSupport().validateAfter("contributionStartDate", form.getContributionStartDate(), form.getEffectiveDate(), errors, new Object[]{"Program-Year Effective Date"});
            getValidationSupport().validateBeforeOrEqual("contributionStartDate", form.getContributionStartDate(), form.getEndDate(), "Program Effective Date", errors, new Object[]{"Package End Date"});
        }

        if (form.getContributionEndDate() != null && form.getContributionEndDate().length() > 0) {
            getValidationSupport().validateAfter("contributionEndDate", form.getContributionEndDate(), form.getEffectiveDate(), errors, new Object[]{"Program-Year Effective Date"});
            getValidationSupport().validateDateFormat("contributionStartDate", form.getContributionStartDate(), errors, new Object[]{"Contribution Start Date"});
            getValidationSupport().validateAfter("contributionEndDate", form.getContributionEndDate(), form.getContributionStartDate(), errors, new Object[]{"Contribution Start Date"});
        }

        /*** Commenting out check for existing programs to allow multiple business programs for same site and year. Please find more info in BPM-782*/
        //checkForExistingPrograms(saveProgramForm, lActionMessages );
        try {
            checkForExistingGroupSitesWithOverlappingProgramYear(form, errors);
            checkIncentiveTypesAndContributionDates(form, errors);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * If an Incentive Option exists for the business program and it is of Incented Status Type of
     * ACTIVITY_PKG_BASED or MULTI_ACTIVITY,
     * then Contribution Start Date and Contribution End Date need to be populated.
     *
     * @param pSaveProgramForm
     * @param errors
     * @throws Exception
     */
    private void checkIncentiveTypesAndContributionDates(SaveProgramForm pSaveProgramForm, Errors errors) throws Exception {
        Integer lProgramID = pSaveProgramForm.getProgramID();

        // Existing Program
        if (lProgramID > 0) {
            ArrayList<ProgramIncentiveOption> lProgramIncentiveOptions = (ArrayList<ProgramIncentiveOption>)
                    businessProgramService.getProgramIncentiveOptions(lProgramID);

            for (ProgramIncentiveOption lProgramIncentiveOption : lProgramIncentiveOptions) {
                if (BPMAdminConstants.BPM_LUV_INCENTIVE_STATUS_MULTI_ACTIVITY.equals(lProgramIncentiveOption.getIncentedStatusTypeCode())
                        || BPMAdminConstants.BPM_LUV_INCENTIVE_STATUS_ACTIVITY_PKGE_BASED.equals(lProgramIncentiveOption.getIncentedStatusTypeCode())) {

                    if (pSaveProgramForm.getContributionStartDate() == null || pSaveProgramForm.getContributionStartDate().length() <= 0) {
                        getValidationSupport().validateRequiredFieldIsNotEmpty("contributionStartDate", pSaveProgramForm.getContributionStartDate(), errors, new Object[]{"Contribution Start Date"});
                    }

                    if (pSaveProgramForm.getContributionEndDate() == null || pSaveProgramForm.getContributionEndDate().length() <= 0) {
                        getValidationSupport().validateRequiredFieldIsNotEmpty("contributionEndDate", pSaveProgramForm.getContributionEndDate(), errors, new Object[]{"Contribution End Date"});
                    }
                }
            }
        }
    }

    private void validateMembershipActivationDate(Errors errors, SaveProgramForm form) {
        // membership activation date can be null until it's communicated to us from membership.
        if (form.getMembershipActivationDate() != null && form.getMembershipActivationDate().trim().length() > 0) {
            boolean lValidDate = getValidationSupport().validateDateFormat("membershipActivationDate", form.getMembershipActivationDate(), errors, new Object[]{"Membership Activation Date"});
            boolean lOnlyNumeric = getValidationSupport().validateOnlyNumericsInDate("membershipActivationDate", form.getMembershipActivationDate(), errors, new Object[]{"Membership Activation Date"});

            // EV 19271 Membership Process Date should be greater than the
            // qualification period end date and less than or equal to the Program Year end date.
            if (form.getQualificationWindowEndDate() != null && lValidDate && lOnlyNumeric) {
                getValidationSupport().validateAfter("membershipActivationDate", form.getMembershipActivationDate(), form.getQualificationWindowEndDate(), errors, new Object[]{"Membership Activation Date", "Qualification End Date"});
            }
            if (form.getEndDate() != null && lValidDate && lOnlyNumeric) {
                getValidationSupport().validateBeforeOrEqual("membershipActivationDate", form.getMembershipActivationDate(), form.getEndDate(), "programEndDate", errors, new Object[]{"Program End Date"});
            }

            //EI 18723 - validation removed
			/*if(lValidDate && lOnlyNumeric)
			{
			    validateNotBeforeToday("membershipActivationDate", membershipActivationDate, "Membership Activation Date");
			    validateNotAfterDate("membershipActivationDate", membershipActivationDate, "Membership Activation Date", endDate);
			}*/
        }
    }

    private void validateQualificationPeriodWithinProgramYear(Errors errors, SaveProgramForm form) {
        getValidationSupport().validateNotOutsideDateRange("qualificationWindowStartDate", form.getQualificationWindowStartDate(), form.getEffectiveDate(), form.getEndDate(), errors, new Object[]{"Qualification Start Date", "Program-Year Effective Date", "Program-Year End Date"});
        getValidationSupport().validateNotOutsideDateRange("qualificationWindowEndDate", form.getQualificationWindowEndDate(), form.getEffectiveDate(), form.getEndDate(), errors, new Object[]{"Qualification End Date", "Program-Year Effective Date", "Program-Year End Date"});
    }

    private void validateQualificationEndDateNotBeforeQualificationStartDate(Errors errors, SaveProgramForm form) {
        getValidationSupport().validateBeforeOrEqual("qualificationWindowStartDate", form.getQualificationWindowStartDate(), form.getQualificationWindowEndDate(), "qualificationEndDate", errors, new Object[]{"Qualification Start Date", "Qualification End Date"});
    }

    private void validateProgramEffectiveDateIfMembersExist(Errors errors, SaveProgramForm form) {
        getValidationSupport().validateProgramDateChangeNotAllowedIfMembersExist("programWindowEffectiveDateBefore", form.getProgramWindowEffectiveDateBefore(), form.getEffectiveDate(), form.getNumberOfMembers(), errors, new Object[]{"Qualification Start Date"});
    }
    private void validateProgramEndDateIfMembersExist(String beforeEndDate, String afterEndDate, String numberOfMembers, Errors errors) {
        validateProgramDateChangeNotAllowedIfMembersExist("programWindowEndDateBefore", beforeEndDate, "Program End Date ", afterEndDate, numberOfMembers, errors);
    }

    private boolean validateProgramDateChangeNotAllowedIfMembersExist(String fieldElement, String beforeDate, String messageAppender, String afterDate, String numberOfMembers, Errors errors) {
        boolean dateChangeNotAllowed = false;

        try {
            SimpleDateFormat fmt = new SimpleDateFormat(BPMAdminConstants.HP_BPM_ADMIN_UI_COMMON_DATE_FORMAT);

            //Allow date change when before date null.  Usually the result of a copy performed off of another business program.
            //In this case, there is no before date to compare against when detecting a date change.
            if (beforeDate == null) {
                return dateChangeNotAllowed;
            }

            java.util.Date lBeforeDate = fmt.parse(beforeDate.trim());
            java.util.Date lAfterDate = fmt.parse(afterDate.trim());

            //if participants exist and date change detected, do not allow the program date change.
            if (Integer.parseInt(numberOfMembers) > 0) {
                if (!lBeforeDate.equals(lAfterDate)) {
                    dateChangeNotAllowed = true;
                }
            }
        } catch (Exception ne) {
            getValidationSupport().addValidationFailureMessage(fieldElement, errors, "errors.participantsenrolled", null);
        }

        //if date change
        if (dateChangeNotAllowed) {
            getValidationSupport().addValidationFailureMessage(fieldElement, errors, "errors.participantsenrolled", null);
        }
        return dateChangeNotAllowed;

    }

    private void checkForExistingGroupSitesWithOverlappingProgramYear(SaveProgramForm pSaveProgramForm, Errors errors) throws Exception {
        java.util.Date lEffectiveDate = fmt.parse(pSaveProgramForm.getEffectiveDate());

        Integer lGroupID = pSaveProgramForm.getGroupID();
        Integer lSubgroupID = pSaveProgramForm.getSubgroupID();

        boolean lExists = false;

        ArrayList<BusinessProgram> lBusinessPrograms = (ArrayList<BusinessProgram>) businessProgramService.getBusinessPrograms(lGroupID, lSubgroupID);

        for (int i = 0; i < lBusinessPrograms.size(); i++) {
            // If a business_program for the same group-site-year exists, and it's not this program:
            if (BPMAdminConstants.BUS_PROGRAM_ACTVTN_ACTIVE.equalsIgnoreCase(lBusinessPrograms.get(i).getProgramStatusCodeValue())
                    && lBusinessPrograms.get(i).getProgramID() != pSaveProgramForm.getProgramID().intValue()) {
                // If a business_program for the same group-site-year exists but different program types (ex. SmartSteps or HIP) and the qualification period overlaps with a program other than
                // classic JW, new JW, or HB program, then display error.
                if (isNonJW_HB_Programs(lBusinessPrograms.get(i))) {
                    boolean qualificationPeriodOverlaps = checkForProgramYearOverlappingWithOtherProgramTypes(lBusinessPrograms.get(i), pSaveProgramForm);
                    if (qualificationPeriodOverlaps) {
                        getValidationSupport().addValidationFailureMessage("effectiveDate", errors, "errors.qualPeriodOverlaps",
                                new Object[]{lBusinessPrograms.get(0).getEmployerGroup().getGroupNumber(),
                                        lBusinessPrograms.get(0).getEmployerGroup().getSiteNumber(),
                                        lBusinessPrograms.get(0).getProgramName()});

                        lExists = true;
                        break;
                    }
                }
            }
        }
    }

    //Determine if HIP or SS program type.
    private boolean isNonJW_HB_Programs(BusinessProgram lBusinessProgram) {
        boolean nonJW_HB_Program = false;

        if (lBusinessProgram.getProgramTypeCodeID().equals(BPMConstants.PROGRAM_TYPE_CODE_HIP) ||
                lBusinessProgram.getProgramTypeCodeID().equals(BPMConstants.PROGRAM_TYPE_CODE_SMART_STEPS)) {
            nonJW_HB_Program = true;
        }

        return nonJW_HB_Program;
    }

    private boolean checkForProgramYearOverlappingWithOtherProgramTypes(BusinessProgram businessProgram, SaveProgramForm pSaveProgramForm) throws ParseException {
        java.util.Date formBusProgUtilEffDate = null;
        java.util.Date formBusProgUtilEndDate = null;
        boolean programPeriodOverlaps = false;

        try {
            SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
            formBusProgUtilEffDate = formatter.parse(pSaveProgramForm.getEffectiveDate());
            formBusProgUtilEndDate = formatter.parse(pSaveProgramForm.getEndDate());
        } catch (ParseException pe) {
            logger.error("An unexpected error has occured: " + pe.getMessage(), pe);
            throw pe;
        }
        java.util.Date busProgUtilEffDate = BPMAdminUtils.getUtilDateFromSqlDate(businessProgram.getEffectiveDate());
        java.util.Date busProgUtilEndDate = BPMAdminUtils.getUtilDateFromSqlDate(businessProgram.getEndDate());

        if (isBetweenDates(formBusProgUtilEffDate, busProgUtilEffDate, busProgUtilEndDate) ||
                isBetweenDates(formBusProgUtilEndDate, busProgUtilEffDate, busProgUtilEndDate)) {
            programPeriodOverlaps = true;
        }

        return programPeriodOverlaps;
    }

    /*
     * Method takes a program date from the form and determines if it's within the program effective and end date of
     * of the same group site year with different program type which can only be HIP or Smartsteps.
     */
    private boolean isBetweenDates(java.util.Date formBusProgUtilDate, java.util.Date busProgUtilEffDate, java.util.Date busProgUtilEndDate) {
        boolean betweenDates = false;

        if (formBusProgUtilDate.equals(busProgUtilEffDate)) {
            betweenDates = true;
        } else if (formBusProgUtilDate.equals(busProgUtilEndDate)) {
            betweenDates = true;
        } else if (formBusProgUtilDate.after(busProgUtilEffDate) &&
                formBusProgUtilDate.before(busProgUtilEndDate)) {
            betweenDates = true;
        }

        return betweenDates;
    }

    public ValidationSupport getValidationSupport() {
        return validationSupport;
    }
}
