package com.healthpartners.app.bpm.dto;

import com.healthpartners.app.bpm.common.BPMAdminUtils;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public final class MemberProgramRowMapper implements RowMapper
{	
	public MemberProgramDetail mapRow(ResultSet rs, int rowNum) throws SQLException 
	{
		MemberProgramDetail memberProgramDetail = new MemberProgramDetail();
		
		
		memberProgramDetail.setPersonID(rs.getInt("prsn_id"));
		memberProgramDetail.setPersonDemographicsID(rs.getInt("prsn_dmgrphcs_id"));
		memberProgramDetail.setMemberID(rs.getString("HP_MEM_ID"));
		memberProgramDetail.setProgramID(rs.getInt("biz_pgm_id"));
		memberProgramDetail.setContractNumber(rs.getInt("contract_no"));								
		//memberProgramDetail.setContractStatusCodeValue(rs
		//		.getString("cntr_stat_val"));
		//memberProgramDetail.setMemberProgramStatusCodeValue(rs
		//		.getString("pers_stat_val"));
		memberProgramDetail.setProgramTypeCodeID(rs
				.getString("pgm_tp_cd_id"));
		memberProgramDetail.setProgramName(rs
				.getString("BIZ_PGM_NM"));
		memberProgramDetail.setQualificationWindowStartDate(rs
				.getDate("QUALFCTN_START_DT"));
		memberProgramDetail.setQualificationWindowEndDate(rs
				.getDate("QUALFCTN_END_DT"));
		memberProgramDetail.setEffectiveDate(rs.getDate("eff_dt"));
		memberProgramDetail.setEndDate(rs.getDate("pgm_end_dt"));
		// Group Number and Site Number are grp_ds.grp_no and
		// subgrp_ds.site_id_no
		memberProgramDetail.setGroupNumber(rs
				.getString("GRP_NO"));
		memberProgramDetail.setGroupName(rs
				.getString("group_name"));
		memberProgramDetail.setSiteNumber(rs
				.getString("site_id_no"));
		memberProgramDetail.setSiteName(rs
				.getString("site_name"));
		memberProgramDetail.setNewHireDate(rs
				.getDate("NEW_HIRE_DT"));
		//memberProgramDetail.setMemberStatusDate(rs
		//		.getDate("member_status_date"));
		//memberProgramDetail.setContractStatusDate(rs
		//		.getDate("contract_status_date"));
		memberProgramDetail.setRelationshipCode(rs.getString("rel_txt"));
		
		memberProgramDetail.setParticipationCodeDesc(rs.getString("program_participation_desc"));
		
		memberProgramDetail.setParticipationEndDate(rs.getDate("PARTICIPATION_END_DT"));
		
		if(rs.getDate("PARTICIPATION_END_DT") != null)
		{
			memberProgramDetail.setParticipationEndDateString(BPMAdminUtils.formatDateMMddyyyy(rs.getDate("PARTICIPATION_END_DT")));
		}
		else
		{
			memberProgramDetail.setParticipationEndDateString(null);
		}
		
		memberProgramDetail.setProgramStatusCodeID(rs.getInt("biz_pgm_stat_cd_id"));
		memberProgramDetail.setProgramStatusCodeValue(rs.getString("program_status_val"));
		memberProgramDetail.setProgramStatusDesc(rs.getString("program_status_desc"));
		memberProgramDetail.setLastPushDate(rs.getDate("last_push_date"));
		memberProgramDetail.setContractEndDate(rs.getDate("contract_end_dt"));
		memberProgramDetail.setStatusCalcEndDate(rs.getDate("STAT_CALC_END_DT"));
		
//		memberProgramDetail.setMemberProgramStatusCodeID(rs.getInt("stat_cd_id"));
//		memberProgramDetail.setContractStatusCodeID(rs.getInt("cntr_stat_cd_id"));
		
		memberProgramDetail.setHealthPlanCode(rs.getString("health_plan_code"));
		memberProgramDetail.setHealthPlanDesc(rs.getString("health_plan_desc"));
		
		//memberProgramDetail.setQualificationCheckmarkName(rs.getString("QUALFCTN_CHKMRK_NM"));
		
		memberProgramDetail.setCoverageDate(rs.getDate("CVRGE_EFF_DT"));
		
		
		
		memberProgramDetail.setExternalID(rs.getString("EXT_EMP_ID_NO"));
		memberProgramDetail.setEmployeeIndicator(rs.getString("EMPLOYEE_FLG"));
		memberProgramDetail.setEligibleHireDate(rs.getDate("ELIG_HIRE_DT"));
		
		
		if(rs.getString("stat_calc_date_passed").equalsIgnoreCase("Y"))
		{
		    memberProgramDetail.setMemberStatusCalcDatePassed(true);
		    memberProgramDetail.setContractStatusCalcDatePassed(true);
		}
		else
		{
			memberProgramDetail.setMemberStatusCalcDatePassed(false);
			memberProgramDetail.setContractStatusCalcDatePassed(false);
		}
							
        
		return memberProgramDetail;
                      
	}
}