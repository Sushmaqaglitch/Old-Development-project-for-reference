package com.healthpartners.app.bpm.controller;

import com.healthpartners.app.bpm.common.BPMAdminConstants;
import com.healthpartners.app.bpm.common.BPMAdminUtils;
import com.healthpartners.app.bpm.common.BPMPagination;
import com.healthpartners.app.bpm.dao.CDHPFulfillmentRptDAO;
import com.healthpartners.app.bpm.dto.CDHPFulfillmentSearch;
import com.healthpartners.app.bpm.dto.CDHPFulfillmentTrackingReportHist;
import com.healthpartners.app.bpm.dto.EmployerGroup;
import com.healthpartners.app.bpm.dto.LookUpValueCode;
import com.healthpartners.app.bpm.exception.BPMException;
import com.healthpartners.app.bpm.form.CDHPFulfillmentSearchForm;
import com.healthpartners.app.bpm.iface.BusinessProgramService;
import com.healthpartners.app.bpm.iface.LookUpValueService;
import com.healthpartners.app.bpm.pageable.PageableCDHPFulfillmentTrackingReportHist;
import com.healthpartners.app.bpm.session.UserSession;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.util.*;

@Controller
public class CDHPFulfillmentSearchController extends BaseController implements Validator {

    private static final String delimiter = ",";

    private final BusinessProgramService businessProgramService;
    private final LookUpValueService lookUpValueService;
    private final CDHPFulfillmentRptDAO cdhpFulfillmentRptDAO;


    public CDHPFulfillmentSearchController(BusinessProgramService businessProgramService, LookUpValueService lookUpValueService, CDHPFulfillmentRptDAO cdhpFulfillmentRptDAO) {
        this.businessProgramService = businessProgramService;
        this.lookUpValueService = lookUpValueService;
        this.cdhpFulfillmentRptDAO = cdhpFulfillmentRptDAO;
    }

    @GetMapping("/CDHPFulfillmentSearch")
    public String loadCDHPFulfillmentSearch(ModelMap modelMap) throws BPMException {
        CDHPFulfillmentSearchForm form = new CDHPFulfillmentSearchForm();
        modelMap.put("cdhpFulfillmentSearchForm", form);
        try {
            form.setActionType(ACTION_SEARCH);
            loadFormSelects(form);
            if (getUserSession().getCdhpFulfillmentTrackingReportHistList() != null &&
                    getUserSession().getCdhpFulfillmentTrackingReportHistList().size() > 0) {
                getUserSession().getCdhpFulfillmentTrackingReportHistList().clear();
            }
            setAttributesBackAndNextButtonsOnModel(modelMap, null);

        } catch (Exception e) {
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
            modelMap.put("errorMsg", getStackTrace(e));
        }
        return "CDHPFulfillmentSearch";
    }

    @PostMapping("/CDHPFulfillmentSearch")
    public String submitCDHPFulfillmentSearch(@ModelAttribute("cdhpFulfillmentSearchForm") CDHPFulfillmentSearchForm form, BindingResult result, ModelMap modelMap) throws Exception {
        try {
            form.setActionType(ACTION_SEARCH);
            validate(form, result);
            loadFormSelects(form);
            if (!result.hasErrors()) {
                performSearch(form, modelMap);
            }
        } catch (Exception e) {
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
            modelMap.put("errorMsg", getStackTrace(e));
        }
        return "CDHPFulfillmentSearch";
    }

    @PostMapping(value = "/CDHPFulfillmentSearch", params = "next")
    public String submitNext(@ModelAttribute("cdhpFulfillmentSearchForm") CDHPFulfillmentSearchForm form, ModelMap modelMap) throws Exception {
        form.setActionType(ACTION_PAGE_FORWARD);
        loadFormSelects(form);
        handlePaginationActions(form, modelMap);
        return "CDHPFulfillmentSearch";
    }

    @PostMapping(value = "/CDHPFulfillmentSearch", params = "back")
    public String submitBack(@ModelAttribute("cdhpFulfillmentSearchForm") CDHPFulfillmentSearchForm form, ModelMap modelMap) throws Exception {
        form.setActionType(ACTION_PAGE_BACK);
        loadFormSelects(form);
        handlePaginationActions(form, modelMap);
        return "CDHPFulfillmentSearch";
    }

    @PostMapping(value = "/CDHPFulfillmentSearch", params = "download")
    public String submitDownload(@ModelAttribute("cdhpFulfillmentSearchForm") CDHPFulfillmentSearchForm form,
                                 HttpServletRequest request, HttpServletResponse response) throws Exception {
        form.setActionType(ACTION_DOWNLOAD_CONTRIBUTIONS_PAGE);
        handleDownload(form, request, response);
        loadFormSelects(form);
        return "CDHPFulfillmentSearch";
    }

    @PostMapping(value = "/CDHPFulfillmentSearch", params = "backToGroupList")
    public String submitBackToGroupList(@ModelAttribute("cdhpFulfillmentSearchForm") CDHPFulfillmentSearchForm form, HttpServletRequest request) throws Exception {
        form.setActionType(ACTION_BACK_TO_GROUP_LIST);
        form.setGroupName(getUserSession().getGroupName());
        backToGroupList(request, form);
        return "CDHPFulfillmentSearch";
    }

    private void loadFormSelects(CDHPFulfillmentSearchForm form) throws BPMException {
        if (CollectionUtils.isEmpty(getUserSession().getCdhpTableTypes())) {
            ArrayList<LookUpValueCode> luvProductTypes = (ArrayList<LookUpValueCode>) lookUpValueService.getLUVCodesByGroup(BPMAdminConstants.GROUP_PRODUCT_TYPE);
            ArrayList<LookUpValueCode> luvCdhpTableTypes = (ArrayList<LookUpValueCode>) lookUpValueService.getLUVCodesByGroup(BPMAdminConstants.CDHP_TABLE_TYPE_FULFILL);
            getUserSession().setProductTypes(luvProductTypes);
            getUserSession().setCdhpTableTypes(luvCdhpTableTypes);
        }
        form.setLuvProductTypes(getUserSession().getProductTypes());
        form.setLuvCdhpTableTypes(getUserSession().getCdhpTableTypes());
    }

    private void performSearch(CDHPFulfillmentSearchForm lCDHPFulfillmentSearchForm, ModelMap modelMap) throws Exception {
        if (StringUtils.isNotEmpty(lCDHPFulfillmentSearchForm.getGroupName()) || EMPLOYER_GROUPS_LIST.equals(lCDHPFulfillmentSearchForm.getWhichList())) {
            searchByGroupName(modelMap, lCDHPFulfillmentSearchForm);
        } else {
            search(modelMap, lCDHPFulfillmentSearchForm);
        }
    }

    protected void searchByGroupName(ModelMap modelMap, CDHPFulfillmentSearchForm lCDHPFulfillmentHistSearchForm) throws Exception {
        boolean newDTOList = false;
        String actionType = lCDHPFulfillmentHistSearchForm.getActionType();
        ArrayList<EmployerGroup> lEmployerGroupsPerPage = null;
        getUserSession().getCdhpFulfillmentTrackingReportHistList().clear();

        ArrayList<EmployerGroup> lEmployerGroups = getUserSession().getEmployerGroups();
        if (lEmployerGroups == null || actionType.equals(ACTION_SEARCH)) {
            lEmployerGroups = (ArrayList<EmployerGroup>) businessProgramService.getGroupsByName(lCDHPFulfillmentHistSearchForm.getGroupName());
            getUserSession().setEmployerGroups(lEmployerGroups);
            newDTOList = true;
        }

        //Pagination code begins here.
        setEmployerGroupPaginationOnModel(modelMap, getUserSession(), actionType, newDTOList);
        //Pagination code ends here.

        getUserSession().setEmployerGroups(lEmployerGroups);
        getUserSession().setEmployerGroupsPerPage(lEmployerGroupsPerPage);
        getUserSession().setCdhpFulfillmentSearchForm(lCDHPFulfillmentHistSearchForm);
        getUserSession().setGroupName(lCDHPFulfillmentHistSearchForm.getGroupName());
        lCDHPFulfillmentHistSearchForm.setGroupName(getUserSession().getGroupName());

        if (lEmployerGroups.size() <= 0) {
            String message = getMessage("messages.info", new Object[]{"No results found for the given search attribute(s)"});
            List<String> messages = new ArrayList<>();
            messages.add(message);
            modelMap.put("messages", messages);
        }
    }

    /**
     * Search member exemptions given the group ID.
     *
     * @param modelMap
     * @param lCDHPFulfillmentHistSearchForm
     * @throws Exception
     */
    protected void search(ModelMap modelMap, CDHPFulfillmentSearchForm lCDHPFulfillmentHistSearchForm) throws Exception {
        boolean newDTOList = false;
        String actionType = lCDHPFulfillmentHistSearchForm.getActionType();

        ArrayList<CDHPFulfillmentTrackingReportHist> lCDHPFulfillmentTrackingReportHistList = getUserSession().getCdhpFulfillmentTrackingReportHistList();

        if (lCDHPFulfillmentTrackingReportHistList == null || actionType.equals(ACTION_SEARCH) || actionType.equals(ACTION_SITE_SEARCH)) {
            CDHPFulfillmentSearch lCDHPFulfillmentSearch = setCDHPFulfillmentSearch(lCDHPFulfillmentHistSearchForm);
            if (lCDHPFulfillmentHistSearchForm.getCdhpTableType().equals(BPMAdminConstants.CDHP_TABLE_TYPE_FULFILL_HIST)) {
                lCDHPFulfillmentTrackingReportHistList = (ArrayList<CDHPFulfillmentTrackingReportHist>) cdhpFulfillmentRptDAO.getCDHPFulfillmentTrackingReportHist(lCDHPFulfillmentSearch);
            } else {
                lCDHPFulfillmentTrackingReportHistList = (ArrayList<CDHPFulfillmentTrackingReportHist>) cdhpFulfillmentRptDAO.getCDHPFulfillmentTrackingReport(lCDHPFulfillmentSearch);
            }

            getUserSession().setCdhpFulfillmentTrackingReportHistList(lCDHPFulfillmentTrackingReportHistList);
            newDTOList = true;
        }

        //Pagination code begins here.
        String lWhichList = null;
        String lRequestAttribute = null;
        if (lCDHPFulfillmentHistSearchForm.getCdhpTableType().equals(BPMAdminConstants.CDHP_TABLE_TYPE_FULFILL_HIST)) {
            lWhichList = CDHP_FULFILL_HISTORIES_LIST;
            lRequestAttribute = "cdhpFulfillHistories";
        } else {
            lWhichList = CDHP_FULFILL_CONTRACTS_LIST;
            lRequestAttribute = "cdhpFulfillContracts";
        }

        if (actionType.equals(ACTION_SITE_SEARCH)) {
            actionType = ACTION_SEARCH;
        }

        setCDHPFulfillmentTrackingReportPagination(modelMap, getUserSession(), actionType, newDTOList, lWhichList, lRequestAttribute);
        //Pagination code ends here.


        if (lCDHPFulfillmentTrackingReportHistList.size() <= 0) {
            String message = getMessage("messages.info", new Object[]{"No results found for the given search attribute(s)"});
            List<String> messages = new ArrayList<>();
            messages.add(message);
            modelMap.put("messages", messages);
        }

        getUserSession().setCdhpFulfillmentSearchForm(lCDHPFulfillmentHistSearchForm);
        if (getUserSession().getEmployerGroups() != null && getUserSession().getEmployerGroups().size() > 0) {
            modelMap.put("groupNameExists", BPMAdminConstants.BPM_ADMIN_TRUE);
        }
    }

    private CDHPFulfillmentSearch setCDHPFulfillmentSearch(CDHPFulfillmentSearchForm lCDHPFulfillmentHistSearchForm) {
        CDHPFulfillmentSearch lCDHPFulfillmentSearch = new CDHPFulfillmentSearch();
        lCDHPFulfillmentSearch.setContractNo(lCDHPFulfillmentHistSearchForm.getContractNumber());
        lCDHPFulfillmentSearch.setGroupName(lCDHPFulfillmentHistSearchForm.getGroupName());
        lCDHPFulfillmentSearch.setGroupNo(lCDHPFulfillmentHistSearchForm.getGroupNumber());
        lCDHPFulfillmentSearch.setMemberNo(lCDHPFulfillmentHistSearchForm.getMemberNumber());
        lCDHPFulfillmentSearch.setProductType(lCDHPFulfillmentHistSearchForm.getProductType());
        lCDHPFulfillmentSearch.setSiteNo(lCDHPFulfillmentHistSearchForm.getSiteNumber());
        lCDHPFulfillmentSearch.setCdhpTableType(lCDHPFulfillmentHistSearchForm.getCdhpTableType());
        lCDHPFulfillmentSearch.setFileSentFromDate(BPMAdminUtils.convertStringToSqlDate(lCDHPFulfillmentHistSearchForm.getFileSentFromDate(), BPMAdminConstants.HP_BPM_ADMIN_UI_COMMON_DATE_FORMAT));
        lCDHPFulfillmentSearch.setFileSentToDate(BPMAdminUtils.convertStringToSqlDate(lCDHPFulfillmentHistSearchForm.getFileSentToDate(), BPMAdminConstants.HP_BPM_ADMIN_UI_COMMON_DATE_FORMAT));
        lCDHPFulfillmentSearch.setProgramStartDate(BPMAdminUtils.convertStringToSqlDate(lCDHPFulfillmentHistSearchForm.getEffectiveDate(), BPMAdminConstants.HP_BPM_ADMIN_UI_COMMON_DATE_FORMAT));

        return lCDHPFulfillmentSearch;
    }

    protected void setCDHPFulfillmentTrackingReportPagination(ModelMap modelMap, UserSession sessionBean, String actionType, boolean newDTOList, String pWhichList, String pRequestAttribute) {
        ArrayList<CDHPFulfillmentTrackingReportHist> lCDHPFulfillmentTrackingReportHistList = sessionBean.getCdhpFulfillmentTrackingReportHistList();
        BPMPagination pagination = sessionBean.getPaginationMap().get(pWhichList);

        PageableCDHPFulfillmentTrackingReportHist lPCFTR = null;
        if (pagination == null || newDTOList) {
            lPCFTR = new PageableCDHPFulfillmentTrackingReportHist(lCDHPFulfillmentTrackingReportHistList);
            lPCFTR.addRowNumber();
            pagination = new BPMPagination(lPCFTR, new ArrayList<Object>(lCDHPFulfillmentTrackingReportHistList));
            sessionBean.getPaginationMap().put(pWhichList, pagination);
        }

        ArrayList<CDHPFulfillmentTrackingReportHist> lCDHPFulfillmentTrackingReportHistPerPage = (ArrayList<CDHPFulfillmentTrackingReportHist>) determineNextOrBackAction(actionType, pagination);
        setAttributesForPaginationOnModel(modelMap, lCDHPFulfillmentTrackingReportHistList.size(), pagination);
        modelMap.put(pRequestAttribute, lCDHPFulfillmentTrackingReportHistPerPage);
        sessionBean.setCdhpFulfillmentTrackingReportHistList(lCDHPFulfillmentTrackingReportHistList);
        sessionBean.setCdhpFulfillmentTrackingReportHistPerPage(lCDHPFulfillmentTrackingReportHistPerPage);
    }

    protected void backToGroupList(HttpServletRequest request, CDHPFulfillmentSearchForm lCDHPFulfillmentHistSearchForm) throws Exception {
        ArrayList<EmployerGroup> lEmployerGroups = getUserSession().getEmployerGroups();
        ArrayList<EmployerGroup> lEmployerGroupsPerPage = getUserSession().getEmployerGroupsPerPage();
        request.setAttribute("employerGroups", lEmployerGroupsPerPage);
        BPMPagination pagination = getUserSession().getPaginationMap().get(EMPLOYER_GROUPS_LIST);
        setAttributesForPagination(request, lEmployerGroups.size(), pagination);
        request.setAttribute("groupNameExists", BPMAdminConstants.BPM_ADMIN_FALSE);
        request.setAttribute("whichList", EMPLOYER_GROUPS_LIST);
        getUserSession().setCdhpFulfillmentSearchForm(lCDHPFulfillmentHistSearchForm);
        lCDHPFulfillmentHistSearchForm.setGroupName(getUserSession().getGroupName());
    }

    private void handlePaginationActions(CDHPFulfillmentSearchForm form, ModelMap modelMap) {
        if (CDHP_FULFILL_HISTORIES_LIST.equals(form.getWhichList())) {
            setCDHPFulfillmentTrackingReportPagination(modelMap, getUserSession(), form.getActionType(), false, form.getWhichList(), "cdhpFulfillHistories");
            getUserSession().setCdhpFulfillmentTrackingReportHistPerPage(null);
        }

        if (CDHP_FULFILL_CONTRACTS_LIST.equals(form.getWhichList())) {
            setCDHPFulfillmentTrackingReportPagination(modelMap, getUserSession(), form.getActionType(), false, form.getWhichList(), "cdhpFulfillContracts");
            getUserSession().setCdhpFulfillmentTrackingReportHistPerPage(null);
        }

        if (EMPLOYER_GROUPS_LIST.equals(form.getWhichList())) {
            setEmployerGroupPaginationOnModel(modelMap, getUserSession(), form.getActionType(), false);
            getUserSession().setGroupName(form.getGroupName());
            form.setGroupName(getUserSession().getGroupName());
        }

        getUserSession().setCdhpFulfillmentSearchForm(form);
        getUserSession().setGroupNo(form.getGroupNumber());

        if (getUserSession().getEmployerGroups() != null && getUserSession().getEmployerGroups().size() > 0 && CDHP_FULFILL_HISTORIES_LIST.equals(form.getWhichList())) {
            modelMap.put("groupNameExists", BPMAdminConstants.BPM_ADMIN_TRUE);
        }
    }

    private void handleDownload(CDHPFulfillmentSearchForm form,  HttpServletRequest request, HttpServletResponse response) throws IOException {
        if (getUserSession().getCdhpFulfillmentTrackingReportHistList() != null &&
                getUserSession().getCdhpFulfillmentTrackingReportHistList().size() > 0) {
            ArrayList<CDHPFulfillmentTrackingReportHist> lCDHPFulfillmentTrackingReportHist = getUserSession().getCdhpFulfillmentTrackingReportHistList();
            response.setHeader("Content-Type", "text/csv");
            response.setHeader("Content-Disposition", "attachment;filename=\"report.csv\"");
            writeCsv(lCDHPFulfillmentTrackingReportHist, response.getOutputStream(), form.getCdhpTableType());
        } else {
            String message = getMessage("errors.download", null);
            List<String> messages = new ArrayList<>();
            messages.add(message);
            request.setAttribute("messages", messages);
        }
    }

    private void writeCsv(Collection<CDHPFulfillmentTrackingReportHist> csv, OutputStream output, String cdhpTableType) throws IOException {
        BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(output, StandardCharsets.UTF_8));

        if (cdhpTableType.equals(BPMAdminConstants.CDHP_TABLE_TYPE_FULFILL_CONTRACT)) {
            formatForFulfillContractHeaderNWrite(writer);
        } else {
            formatForFulfillDetailHeaderNWrite(writer);
        }

        for (CDHPFulfillmentTrackingReportHist lCDHPFulfillmentTrackingReportHist : csv) {
            if (cdhpTableType.equals(BPMAdminConstants.CDHP_TABLE_TYPE_FULFILL_CONTRACT)) {
                formatForFulfillContractNWrite(writer, lCDHPFulfillmentTrackingReportHist);
            } else {
                formatForFulfillDetailNWrite(writer, lCDHPFulfillmentTrackingReportHist);
            }
        }

        closeFileWriter(writer);
    }

    public void closeFileWriter(BufferedWriter writer) {
        try {
            writer.flush();
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void formatForFulfillContractHeaderNWrite(BufferedWriter writer) throws IOException {
        writer.append("No");
        writer.append(delimiter);

        writer.append("File Sent Date");
        writer.append(delimiter);

        writer.append("Group No");
        writer.append(delimiter);

        writer.append("Site No");
        writer.append(delimiter);

        writer.append("Contract No");
        writer.append(delimiter);

        writer.append("Contribution Amount");
        writer.append(delimiter);

        writer.append("Contribution Date");
        writer.append(delimiter);

        writer.append("Member Count");
        writer.append(delimiter);

        writer.append("Product Type");
        writer.append(delimiter);

        writer.newLine();
    }

    private void formatForFulfillDetailHeaderNWrite(BufferedWriter writer) throws IOException {
        writer.append("No");
        writer.append(delimiter);

        writer.append("File Sent Date");
        writer.append(delimiter);

        writer.append("Group No");
        writer.append(delimiter);

        writer.append("Site No");
        writer.append(delimiter);

        writer.append("Member No");
        writer.append(delimiter);

        writer.append("Last Name");
        writer.append(delimiter);

        writer.append("First Name");
        writer.append(delimiter);

        writer.append("Contract No");
        writer.append(delimiter);

        writer.append("Activity Name");
        writer.append(delimiter);

        writer.append("Contribution Amount");
        writer.append(delimiter);

        writer.append("Contribution Date");
        writer.append(delimiter);

        writer.append("Product Type");
        writer.append(delimiter);

        writer.newLine();
    }

    private void formatForFulfillContractNWrite(BufferedWriter writer, CDHPFulfillmentTrackingReportHist lCDHPFulfillmentContractReportHist) throws IOException {
        writer.append(Integer.toString(lCDHPFulfillmentContractReportHist.getRowNumber()));
        writer.append(delimiter);

        writer.append(BPMAdminUtils.formatDateMMddyyyy(lCDHPFulfillmentContractReportHist.getFileSentDate()));
        writer.append(delimiter);

        writer.append(lCDHPFulfillmentContractReportHist.getGroupNo());
        writer.append(delimiter);

        writer.append(lCDHPFulfillmentContractReportHist.getSiteNo());
        writer.append(delimiter);

        writer.append(Integer.toString(lCDHPFulfillmentContractReportHist.getContractNo()));
        writer.append(delimiter);

        writer.append(Integer.toString(lCDHPFulfillmentContractReportHist.getContributionAmount()));
        writer.append(delimiter);

        writer.append(BPMAdminUtils.formatDateMMddyyyy(lCDHPFulfillmentContractReportHist.getContributionDate()));
        writer.append(delimiter);

        writer.append(Integer.toString(lCDHPFulfillmentContractReportHist.getMemberCount()));
        writer.append(delimiter);

        writer.append(lCDHPFulfillmentContractReportHist.getPackageSubTypeName());

        writer.newLine();
    }

    private void formatForFulfillDetailNWrite(BufferedWriter writer, CDHPFulfillmentTrackingReportHist lCDHPFulfillmentContractReportHist) throws IOException {
        writer.append(Integer.toString(lCDHPFulfillmentContractReportHist.getRowNumber()));
        writer.append(delimiter);

        writer.append(BPMAdminUtils.formatDateMMddyyyy(lCDHPFulfillmentContractReportHist.getFileSentDate()));
        writer.append(delimiter);

        writer.append(lCDHPFulfillmentContractReportHist.getGroupNo());
        writer.append(delimiter);

        writer.append(lCDHPFulfillmentContractReportHist.getSiteNo());
        writer.append(delimiter);

        writer.append(lCDHPFulfillmentContractReportHist.getMemberNo());
        writer.append(delimiter);

        writer.append(lCDHPFulfillmentContractReportHist.getLastName());
        writer.append(delimiter);

        writer.append(lCDHPFulfillmentContractReportHist.getFirstName());
        writer.append(delimiter);

        writer.append(Integer.toString(lCDHPFulfillmentContractReportHist.getContractNo()));
        writer.append(delimiter);

        writer.append(lCDHPFulfillmentContractReportHist.getActivityName().replaceAll(",", ""));
        writer.append(delimiter);

        writer.append(Integer.toString(lCDHPFulfillmentContractReportHist.getContributionAmount()));
        writer.append(delimiter);

        writer.append(BPMAdminUtils.formatDateMMddyyyy(lCDHPFulfillmentContractReportHist.getContributionDate()));
        writer.append(delimiter);

        writer.append(lCDHPFulfillmentContractReportHist.getPackageSubTypeName());

        writer.newLine();
    }

    @Override
    public boolean supports(Class<?> clazz) {
        return CDHPFulfillmentSearchForm.class.isAssignableFrom(clazz);
    }

    @Override
    public void validate(Object target, Errors errors) {
        CDHPFulfillmentSearchForm form = (CDHPFulfillmentSearchForm) target;
        getValidationSupport().validateRequiredFieldIsNotEmpty("productType", form.getProductType(), errors, new Object[]{"Product Type"});
        getValidationSupport().validateRequiredFieldIsNotEmpty("cdhpTableType", form.getCdhpTableType(), errors, new Object[]{"CDHP Fulfillment Type"});
        if (StringUtils.isNotEmpty(form.getGroupNumber())) {
            getValidationSupport().validateNotSpecialChar("groupNumber", form.getGroupNumber(), errors, new Object[]{"Group No"});
        }
        if (StringUtils.isNotEmpty(form.getGroupName())) {
            getValidationSupport().validateNotSpecialChar("groupName", form.getGroupName(), errors, new Object[]{"Group Name"});
        }
        if (StringUtils.isNotEmpty(form.getSiteNumber())) {
            getValidationSupport().validateNotSpecialChar("siteNumber", form.getSiteNumber(), errors, new Object[]{"Site No"});
        }
        if (StringUtils.isNotEmpty(form.getEffectiveDate())) {
            getValidationSupport().validateDateFormat("effectiveDate", form.getEffectiveDate(), errors, new Object[]{"Program-Year Effective Date"});
        }
        if (StringUtils.isNotEmpty(form.getFileSentFromDate())) {
            getValidationSupport().validateDateFormat("fileSentFromDate", form.getFileSentFromDate(), errors, new Object[]{"File Sent From Date"});
        }
        if (StringUtils.isNotEmpty(form.getFileSentToDate())) {
            getValidationSupport().validateDateFormat("fileSentToDate", form.getFileSentToDate(), errors, new Object[]{"File Sent To Date"});
        }
        if (StringUtils.isNotEmpty(form.getContractNumber())) {
            getValidationSupport().validateNotInteger("contractNumber", form.getContractNumber(), errors, new Object[]{"Contract No"});
        }
    }
}
