package com.healthpartners.app.bpm.pageable;

import com.healthpartners.app.bpm.dto.RewardCardFulfillmentTrackingReportHist;

import java.util.ArrayList;
import java.util.Iterator;

/**
 * The pageable class serves as a wrapper for the array list of objects, and
 * operations that are performed on those objects. For ex. adding a row number
 * for display.
 * The BPMPagination then has a pointer to an instance of this class.
 *
 * @author tjquist
 */
public class PageableRewardCardFulfillmentTrackingReportHist implements BPMPageable {
    ArrayList<RewardCardFulfillmentTrackingReportHist> rewardCardFulfillmentTrackingReports;

    public PageableRewardCardFulfillmentTrackingReportHist() {
        super();
    }

    public PageableRewardCardFulfillmentTrackingReportHist(ArrayList<RewardCardFulfillmentTrackingReportHist> pRewardCardFulfillmentTrackingReports) {
        rewardCardFulfillmentTrackingReports = pRewardCardFulfillmentTrackingReports;
    }

    public ArrayList<RewardCardFulfillmentTrackingReportHist> getRewardCardFulfillmentTrackingReports() {
        return rewardCardFulfillmentTrackingReports;
    }

    public void setRewardCardFulfillmentTrackingReports(
            ArrayList<RewardCardFulfillmentTrackingReportHist> rewardCardFulfillmentTrackingReports) {
        this.rewardCardFulfillmentTrackingReports = rewardCardFulfillmentTrackingReports;
    }

    public void addRowNumber() {
        int startRowNumber = 1;
        Iterator<RewardCardFulfillmentTrackingReportHist> iter = (Iterator<RewardCardFulfillmentTrackingReportHist>) rewardCardFulfillmentTrackingReports.iterator();
        while (iter.hasNext()) {
            RewardCardFulfillmentTrackingReportHist lRewardCardFulfillmentTrackingReportHist = (RewardCardFulfillmentTrackingReportHist) iter.next();
            lRewardCardFulfillmentTrackingReportHist.setRowNumber(startRowNumber);
            startRowNumber++;
        }
    }

}
