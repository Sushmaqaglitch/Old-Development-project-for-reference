package com.healthpartners.app.bpm.dto;

import java.io.Serializable;

public class ProgramContributionGrid implements Serializable
{	
	static final long serialVersionUID = 0L;
		
	private Integer rowID;
	private Integer contributionGridID;
	private Integer programIncentiveOptionID;
	private Integer benefitContractTypeID;
	private String  benefitContractTypeDesc;
	private Integer relationshipCodeID;
	private String  relationshipCode;
	private Integer contributionAmount;
	private Integer incentiveOptionID;
	
	
	private boolean used;
	
	public ProgramContributionGrid()
	{
		super();
	}
	
	public Integer getRowID() {
		return rowID;
	}

	public void setRowID(Integer rowID) {
		this.rowID = rowID;
	}

	public Integer getContributionGridID() {
		return contributionGridID;
	}

	public void setContributionGridID(Integer contributionGridID) {
		this.contributionGridID = contributionGridID;
	}

	public Integer getProgramIncentiveOptionID() {
		return programIncentiveOptionID;
	}

	public void setProgramIncentiveOptionID(Integer programIncentiveOptionID) {
		this.programIncentiveOptionID = programIncentiveOptionID;
	}

	

	public Integer getBenefitContractTypeID() {
		return benefitContractTypeID;
	}

	public void setBenefitContractTypeID(Integer benefitContractTypeID) {
		this.benefitContractTypeID = benefitContractTypeID;
	}

	public String getBenefitContractTypeDesc() {
		return benefitContractTypeDesc;
	}

	public void setBenefitContractTypeDesc(String benefitContractTypeDesc) {
		this.benefitContractTypeDesc = benefitContractTypeDesc;
	}

	public Integer getRelationshipCodeID() {
		return relationshipCodeID;
	}

	public void setRelationshipCodeID(Integer relationshipCodeID) {
		this.relationshipCodeID = relationshipCodeID;
	}
	
	

	public String getRelationshipCode() {
		return relationshipCode;
	}

	public void setRelationshipCode(String relationshipCode) {
		this.relationshipCode = relationshipCode;
	}

	public Integer getContributionAmount() {
		return contributionAmount;
	}

	public void setContributionAmount(Integer contributionAmount) {
		this.contributionAmount = contributionAmount;
	}

	

	public boolean isUsed() {
		return used;
	}

	public void setUsed(boolean used) {
		this.used = used;
	}

	public final Integer getIncentiveOptionID() {
		return incentiveOptionID;
	}

	public final void setIncentiveOptionID(Integer incentiveOptionID) {
		this.incentiveOptionID = incentiveOptionID;
	}

	
	
}
