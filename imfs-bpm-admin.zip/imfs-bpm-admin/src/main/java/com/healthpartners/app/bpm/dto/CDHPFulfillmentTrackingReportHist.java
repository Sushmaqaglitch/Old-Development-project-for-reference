package com.healthpartners.app.bpm.dto;

import java.io.Serializable;
import java.sql.Date;
import java.util.Calendar;

public class CDHPFulfillmentTrackingReportHist implements Serializable
{	
	static final long serialVersionUID = 0L;
	
	private Integer cdhpTransID;
	private Integer programID;
	private String  groupNo;
	private String  siteNo;
	private Calendar qualificationStartDate;
	private Integer personID;
	private Integer personDemographicsID;
	private Integer groupID;
	private Integer packageID;
	private String  memberNo;
	private Integer contractNo;
	private String  firstName;
	private String  lastName;
	private String  middleName;
	private Integer contributionAmount;
	private String  contributionTypeCode;
	private Integer  contributionTypeCodeId;
	private Date contributionStartDate;
	private Date contributionEndDate;
	private Date 	contributionDate;
	private Integer memberCount;
	private Integer activityID;
	private String activityName;
	private Date    fileSentDate;
	private String  packageSubTypeName;
	private String sourceActivityID;
	private String  incentiveReportName;
	private Integer  incentiveOptionID;
	private Integer rowNumber;
	private String employerGroupName;
	private String contributionType;
	private String fulfillmentRoutingType;
	
	
	
	
	
	public Integer getCdhpTransID() {
		return cdhpTransID;
	}
	public void setCdhpTransID(Integer cdhpTransID) {
		this.cdhpTransID = cdhpTransID;
	}
	public Integer getProgramID() {
		return programID;
	}
	public void setProgramID(Integer programID) {
		this.programID = programID;
	}
	
	public String getGroupNo() {
		return groupNo;
	}
	public void setGroupNo(String groupNo) {
		this.groupNo = groupNo;
	}
	
	public String getSiteNo() {
		return siteNo;
	}
	public void setSiteNo(String siteNo) {
		this.siteNo = siteNo;
	}
	public Calendar getQualificationStartDate() {
		return qualificationStartDate;
	}
	public void setQualificationStartDate(Calendar qualificationStartDate) {
		this.qualificationStartDate = qualificationStartDate;
	}
	public Integer getPersonID() {
		return personID;
	}
	public void setPersonID(Integer personID) {
		this.personID = personID;
	}
	public Integer getPersonDemographicsID() {
		return personDemographicsID;
	}
	public void setPersonDemographicsID(Integer personDemographicsID) {
		this.personDemographicsID = personDemographicsID;
	}
	
	
	
	public Integer getGroupID() {
		return groupID;
	}
	public void setGroupID(Integer groupID) {
		this.groupID = groupID;
	}
	
	public Integer getPackageID() {
		return packageID;
	}
	public void setPackageID(Integer packageID) {
		this.packageID = packageID;
	}
	public String getMemberNo() {
		return memberNo;
	}
	public void setMemberNo(String memberNo) {
		this.memberNo = memberNo;
	}
	public Integer getContractNo() {
		return contractNo;
	}
	public void setContractNo(Integer contractNo) {
		this.contractNo = contractNo;
	}
	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getMiddleName() {
		return middleName;
	}
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	public Integer getContributionAmount() {
		return contributionAmount;
	}
	public void setContributionAmount(Integer contributionAmount) {
		this.contributionAmount = contributionAmount;
	}
	public String getContributionTypeCode() {
		return contributionTypeCode;
	}
	public void setContributionTypeCode(String contributionTypeCode) {
		this.contributionTypeCode = contributionTypeCode;
	}
	
	public Integer getContributionTypeCodeId() {
		return contributionTypeCodeId;
	}
	public void setContributionTypeCodeId(Integer contributionTypeCodeId) {
		this.contributionTypeCodeId = contributionTypeCodeId;
	}
	
	public Date getContributionStartDate() {
		return contributionStartDate;
	}
	public void setContributionStartDate(Date contributionStartDate) {
		this.contributionStartDate = contributionStartDate;
	}
	public Date getContributionEndDate() {
		return contributionEndDate;
	}
	public void setContributionEndDate(Date contributionEndDate) {
		this.contributionEndDate = contributionEndDate;
	}
	
	public Date getContributionDate() {
		return contributionDate;
	}
	public void setContributionDate(Date contributionDate) {
		this.contributionDate = contributionDate;
	}
	public Integer getMemberCount() {
		return memberCount;
	}
	public void setMemberCount(Integer memberCount) {
		this.memberCount = memberCount;
	}
	
	public Integer getActivityID() {
		return activityID;
	}
	public void setActivityID(Integer activityID) {
		this.activityID = activityID;
	}
	
	
	
	public String getActivityName() {
		return activityName;
	}
	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}
	public Date getFileSentDate() {
		return fileSentDate;
	}
	public void setFileSentDate(Date fileSentDate) {
		this.fileSentDate = fileSentDate;
	}
	public String getPackageSubTypeName() {
		return packageSubTypeName;
	}
	public void setPackageSubTypeName(String packageSubTypeName) {
		this.packageSubTypeName = packageSubTypeName;
	}
	
	public String getSourceActivityID() {
		return sourceActivityID;
	}
	public void setSourceActivityID(String sourceActivityID) {
		this.sourceActivityID = sourceActivityID;
	}
	public String getIncentiveReportName() {
		return incentiveReportName;
	}
	public void setIncentiveReportName(String incentiveReportName) {
		this.incentiveReportName = incentiveReportName;
	}
	public Integer getIncentiveOptionID() {
		return incentiveOptionID;
	}
	public void setIncentiveOptionID(Integer incentiveOptionID) {
		this.incentiveOptionID = incentiveOptionID;
	}
	public Integer getRowNumber() {
		return rowNumber;
	}
	public void setRowNumber(Integer rowNumber) {
		this.rowNumber = rowNumber;
	}
	public String getEmployerGroupName() {
		return employerGroupName;
	}
	public void setEmployerGroupName(String employerGroupName) {
		this.employerGroupName = employerGroupName;
	}
	public String getContributionType() {
		return contributionType;
	}
	public void setContributionType(String contributionType) {
		this.contributionType = contributionType;
	}
	public String getFulfillmentRoutingType() {
		return fulfillmentRoutingType;
	}
	public void setFulfillmentRoutingType(String fulfillmentRoutingType) {
		this.fulfillmentRoutingType = fulfillmentRoutingType;
	}
	
	
}
