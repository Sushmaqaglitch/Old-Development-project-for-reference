package com.healthpartners.app.bpm.dao;

import com.healthpartners.app.bpm.common.BPMAdminConstants;
import com.healthpartners.app.bpm.common.BPMAdminUtils;
import com.healthpartners.app.bpm.dto.*;
import com.healthpartners.app.bpm.exception.BPMException;
import jakarta.annotation.PostConstruct;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.jdbc.support.incrementer.DataFieldMaxValueIncrementer;
import org.springframework.jdbc.support.incrementer.OracleSequenceMaxValueIncrementer;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.sql.DataSource;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;

@Repository
@Transactional(timeout = 300, rollbackFor = {DataAccessException.class, BPMException.class})
public class BusinessProgramDAOJdbc extends JdbcDaoSupport implements BusinessProgramDAO {
    private final static String BIZ_PGM_ID_SEQ = "biz_pgm_id_seq";
    private final static String BIZ_PGM_CHNG_LOG_SEQ = "biz_pgm_chng_log_seq";

    protected final Log logger = LogFactory.getLog(getClass());
    private final DataSource dataSource;

    // @formatter:off
    private static final String selectAllStartDates = "SELECT distinct qualfctn_start_dt FROM business_program where stat_calc_end_dt > sysdate order by qualfctn_start_dt desc";
    private static final String selectGroupsByName = "SELECT DISTINCT empl_grp_site.grp_id, empl_grp_no as grp_no, empl_grp_nm as grp_nm " +
            ", DECODE(biz.biz_pgm_id, NULL, '', 'Y') as has_program " + "FROM empl_grp_site " +
            "LEFT OUTER JOIN business_program biz on empl_grp_site.grp_id = biz.grp_id " +
            "WHERE empl_grp_no IS NOT NULL";
    private static final String selectAllGroupSitesWithPrograms = "SELECT DISTINCT " +
            "  egs.empl_grp_no " +
            ", egs.empl_grp_site_id_no " +
            ", egs.grp_id " +
            ", egs.subgrp_id " +
            ", egs.empl_grp_nm " +
            ", egs.empl_grp_site_nm " +
            ", biz_type.biz_pgm_nm " +
            ", biz.eff_dt " +
            ", CASE " +
            "  WHEN (biz.eff_dt IS NULL AND biz.pgm_end_dt IS NULL) THEN 'X' " +
            "  WHEN SYSDATE BETWEEN biz.eff_dt AND biz.pgm_end_dt THEN 'Y' " +
            "  ELSE 'N' END has_program " +
            "FROM empl_grp_site egs " +
            ", (SELECT biz1.grp_id, biz1.subgrp_id, max(biz1.eff_dt) max_eff_dt FROM business_program biz1 " +
            "      , empl_grp_site egs1 " +
            "      , luv l " +
            "      WHERE egs1.empl_grp_no = ? " +
            "        AND egs1.grp_id = biz1.grp_id    " +
            "        AND egs1.subgrp_id = biz1.subgrp_id " +
            "        AND biz1.biz_pgm_stat_cd_id = lu_id " +
            "        AND l.lu_grp='BPM_ACTVTN_STATUS' " +
            "        AND l.lu_val='ACTIVE'     " +
            "   GROUP BY biz1.grp_id, biz1.subgrp_id " +
            "        ) max_biz   " +
            ", business_program biz " +
            ", luv " +
            ", business_program_type biz_type " +
            "WHERE " +
            "    egs.empl_grp_no = ? " +
            "AND egs.grp_id = max_biz.grp_id " +
            "AND egs.subgrp_id = max_biz.subgrp_id " +
            "AND egs.grp_id = biz.grp_id " +
            "AND egs.subgrp_id = biz.subgrp_id " +
            "AND max_biz.grp_id = biz.grp_id " +
            "AND max_biz.subgrp_id = biz.subgrp_id " +
            "AND max_biz.max_eff_dt = biz.eff_dt " +
            "AND biz.biz_pgm_stat_cd_id = lu_id " +
            "AND lu_grp='BPM_ACTVTN_STATUS' " +
            "AND lu_val='ACTIVE' " +
            "AND biz.biz_pgm_tp_cd = biz_type.biz_pgm_tp_cd " +
            "ORDER BY eff_dt DESC, empl_grp_site_id_no ASC";
    private static final String selectAllGroupSitesWithoutPrograms = " SELECT DISTINCT " +
            "  egs.empl_grp_no " +
            ", egs.empl_grp_site_id_no " +
            ", egs.grp_id " +
            ", egs.subgrp_id " +
            ", egs.empl_grp_nm " +
            ", egs.empl_grp_site_nm " +
            ", '' biz_pgm_nm " +
            ", null eff_dt " +
            ", 'X' has_program " +
            "FROM empl_grp_site egs " +
            ", (SELECT grp_id, subgrp_id " +
            "     FROM empl_grp_site " +
            "MINUS " +
            "SELECT DISTINCT grp_id, subgrp_id " +
            "     FROM business_program, luv " +
            " WHERE " +
            "     biz_pgm_stat_cd_id = lu_id " +
            "     AND lu_grp='BPM_ACTVTN_STATUS' AND lu_val='ACTIVE' " +
            "        ) egs_wo_programs " +
            "WHERE " +
            "    egs.empl_grp_no = ? " +
            "AND egs.grp_id = egs_wo_programs.grp_id " +
            "AND egs.subgrp_id = egs_wo_programs.subgrp_id " +
            "ORDER BY egs.empl_grp_site_id_no ASC";

    private static final String selectExemptionHistory = "SELECT\n" +
            "hp_mem_id\n" +
            "--Exemption Type from LUV table\n" +
            ",(select l.lu_desc from luv l where qov.ovrd_tp_cd_id = l.lu_id) as exemption_type\n" +
            ", exemption_issue_dt\n" +
            ", qov.aprvr_user_id\n" +
            ", case\n" +
            "when trunc(con.modify_ts) > trunc(stat.modify_ts) then trunc(con.modify_ts)\n" +
            "when trunc(con.modify_ts) <= trunc(stat.modify_ts) then trunc(stat.modify_ts)\n" +
            "end\n" +
            "as processing_date\n" +
            ", (SELECT lu_val FROM luv WHERE stat.stat_cd_id = lu_id) member_status\n" +
            ", (SELECT lu_val FROM luv WHERE con.cntr_stat_cd_id = lu_id) contract_status\n" +
            ", qov.cntr_no contract_no\n" +
            ", egs.EMPL_GRP_NO\n" +
            ", egs.empl_grp_nm\n" +
            ", egs.empl_grp_site_id_no\n" +
            ", egs.empl_grp_site_nm\n" +
            ", biz.qualfctn_start_dt\n" +
            ", biz.qualfctn_end_dt\n" +
            ", biz.eff_dt\n" +
            ", biz.pgm_end_dt\n" +
            ", biz_pgm_nm\n" +
            ", qov.biz_pgm_incntv_optn_id\n" +
            ", io.incntv_optn_nm\n" +
            "-- Get User name using BPM User environment table and match on user ID.  If no match, default to INSERT_USR value\n" +
            ", nvl((select ue.bpm_usr_nm from usr_env ue where qov.insert_usr = ue.bpm_usr_id), qov.insert_usr) as created_by\n" +
            ", demo.FIRST_NM\n" +
            ", demo.LAST_NM\n" +
            ", COALESCE(demo.middle_nm, ' ') middle_nm\n" +
            ", qov.INSERT_TS\n" +
            "FROM\n" +
            "empl_grp_site egs\n" +
            ", business_program biz\n" +
            ", qualification_override qov\n" +
            ", person_program_status stat\n" +
            ", contract_program_status con\n" +
            ", biz_pgm_incentive_option bpio\n" +
            ", incentive_option io\n" +
            ",  prsn_demographics demo\n" +
            ", business_program_type biz_type\n" +
            "WHERE\n" +
            "egs.grp_id = biz.grp_id\n" +
            "And egs.grp_id = biz.grp_id\n" +
            "AND egs.subgrp_id = biz.subgrp_id\n" +
            "AND biz.eff_dt = ?\n" +
            "AND biz.biz_pgm_tp_cd = biz_type.biz_pgm_tp_cd\n" +
            "and biz_pgm_stat_cd_id = (select l.lu_id from luv l where l.lu_grp = 'BPM_ACTVTN_STATUS' and l.lu_val = 'ACTIVE')\n" +
            "\n" +
            "AND biz.biz_pgm_id = stat.biz_pgm_id\n" +
            "AND biz.biz_pgm_id = qov.biz_pgm_id\n" +
            "and demo.prsn_dmgrphcs_id = qov.prsn_dmgrphcs_id\n" +
            "AND qov.prsn_dmgrphcs_id = stat.prsn_dmgrphcs_id\n" +
            "AND biz.biz_pgm_id = con.biz_pgm_id\n" +
            "AND qov.cntr_no = con.contract_no\n" +
            "AND (stat.participation_end_dt IS NULL OR stat.participation_end_dt > biz.pgm_end_dt)\n" +
            "AND (con.participation_end_dt IS NULL OR con.participation_end_dt > biz.pgm_end_dt)\n" +
            "AND bpio.biz_pgm_incntv_optn_id = qov.biz_pgm_incntv_optn_id\n" +
            "AND bpio.incntv_optn_id = io.incntv_optn_id\n" +
            "AND qov.biz_pgm_incntv_optn_id = con.biz_pgm_incntv_optn_id\n" +
            "AND qov.biz_pgm_incntv_optn_id = stat.biz_pgm_incntv_optn_id\n";

    private static final String selectActiveNWithdrawnBusinessPrograms = " SELECT DISTINCT\n" +
            " biz.biz_pgm_id\n" +
            ", biz.biz_pgm_tp_cd\n" +
            ", prog_type.biz_pgm_nm \n" +
            ", prog_type.biz_pgm_desc \n" +
            ", biz.part_requirement_cd_id\n" +
            ", (select LU_DESC from luv where lu_id=biz.part_requirement_cd_id) as part_requirement_desc\n" +
            ", (select LU_VAL from luv where lu_id=biz.part_requirement_cd_id) as part_requirement_value\n" +
            ", biz.pgm_release_dt\n" +
            ", biz.eff_dt\n" +
            ", biz.pgm_end_dt \n" +
            ", biz.qualfctn_start_dt \n" +
            ", biz.qualfctn_end_dt \n" +
            ", biz.additional_info_txt\n" +
            ", biz.qualfctn_start_dt + interval '1' year AS bnft_yr_start_dt\n" +
            ", 0 as bnft_level_cd\n" +
            ", '' as bnft_level_desc\n" +
            ", EMPL_GRP_NM AS GRP_NM\n" +
            ", EMPL_GRP_NO AS GRP_NO\n" +
            ", biz.GRP_ID\n" +
            ", EMPL_GRP_SITE_NM AS SUBGRP_NM\n" +
            ", EMPL_GRP_SITE_ID_NO AS SITE_ID_NO\n" +
            ", biz.SUBGRP_ID\n" +
            ", EMPL_GRP_RPT_NM\n" +
            ", EMPL_GRP_SITE_RPT_NM\n" +
            ", EMPL_GRP_ABBR_NM\n" +
            ", EMPL_GRP_SITE_ABBR_NM\n" +
            ", biz.new_hire_dt\n" +
            ", biz.MBRSHP_PRCS_FLG  mbrship_process_flag\n" +
            ", biz.MBRSHP_PRCS_DT mbrship_process_date\n" +
            ", biz.biz_pgm_stat_cd_id\n" +
            ", (select LU_DESC from luv where lu_id=biz.biz_pgm_stat_cd_id) as program_status_desc\n" +
            ", (select LU_VAL from luv where lu_id=biz.biz_pgm_stat_cd_id) as program_status_val\n" +
            ", ELIG_PGM_PKG_ID\n" +
            ", QUALFCTN_CHKMRK_ID\n" +
            ", (SELECT QUALFCTN_CHKMRK_NM FROM qualfctn_chkmrk qchm WHERE qchm.QUALFCTN_CHKMRK_ID = biz.QUALFCTN_CHKMRK_ID) as QUALFCTN_CHKMRK_NM\n" +
            ", biz.stat_calc_end_dt\n" +
            ", biz.CONTRIBUTION_START_DT\n" +
            ", biz.CONTRIBUTION_END_DT\n" +
            ", biz.BIZ_PGM_SPC_HNDLR_TP_ID\n" +
            ", (SELECT lu_desc FROM luv WHERE lu_id = BIZ_PGM_SPC_HNDLR_TP_ID) BIZ_PGM_SPC_HNDLR_TP\n" +
            "FROM\n" +
            "  BUSINESS_PROGRAM biz\n" +
            ", business_program_type  prog_type\n" +
            ", empl_grp_site\n" +
            "WHERE \n" +
            "   biz.biz_pgm_tp_cd =prog_type.biz_pgm_tp_cd \n" +
            "   AND empl_grp_site.GRP_ID = biz.GRP_ID\n" +
            "   AND empl_grp_site.SUBGRP_ID = biz.SUBGRP_ID\n" +
            "   AND biz.BIZ_PGM_STAT_CD_ID IN (SELECT lu_id FROM  luv  WHERE lu_grp='BPM_ACTVTN_STATUS' AND lu_val IN ('ACTIVE', 'WITHDRAWN'))";

    private static final String selectNumberOfMembers = "SELECT count(DISTINCT PRSN_DMGRPHCS_ID) number_of_members FROM person_program_status WHERE BIZ_PGM_ID = ?";

    private static final String selectGroups = "SELECT DISTINCT grp_id, empl_grp_no as grp_no, empl_grp_nm as grp_nm FROM empl_grp_site WHERE empl_grp_no IS NOT NULL";

    private static final String selectSubGroups = " SELECT DISTINCT groups.grp_id, empl_grp_no as grp_no, empl_grp_nm as grp_nm, subgrp_id, empl_grp_site_id_no as site_id_no, EMPL_GRP_SITE_NM as subgrp_nm \n" +
            "FROM empl_grp_site groups \n" +
            "WHERE groups.grp_id = ?\n" +
            "--EV102004\n" +
            "order by groups.empl_grp_site_id_no\n" +
            "--EV 77226       \n" +
            "--AND EMPL_GRP_SITE_NM NOT LIKE '*%'";

    private static final String selectProgramTypes = "SELECT distinct DECODE(biz.biz_pgm_id, null, 0, 1) count_used, types.biz_pgm_tp_cd, biz_pgm_nm, biz_pgm_desc, types.INSERT_TS, types.MODIFY_TS, types.INSERT_USR, types.MODIFY_USR\n" +
            ", MBRSHP_CMMNCTN_FLG, RPT_INDICATOR, BIZ_EFF_DT, BIZ_END_DT  \n" +
            ", AUTH_PROMO_TP_CD_ID, \n" +
            "(SELECT lu_val FROM luv WHERE lu_id = AUTH_PROMO_TP_CD_ID) AUTH_PROMO_TP_CD,\n" +
            "ACTVTN_STAT_CD_ID,\n" +
            "(SELECT lu_val FROM luv WHERE lu_id = ACTVTN_STAT_CD_ID) ACTVTN_STAT_CD, \n" +
            "types.MRKT_INDCTR_ID,\n" +
            "MRKT_INDCTR_NM\n" +
            "FROM business_program_type types \n" +
            "LEFT OUTER JOIN business_program biz ON types.biz_pgm_tp_cd = biz.biz_pgm_tp_cd\n" +
            "LEFT OUTER JOIN mrkt_indctr_def mrkdef ON types.MRKT_INDCTR_ID = mrkdef.MRKT_INDCTR_ID\n" +
            "order by insert_ts desc";

    private static final String insertBusinessProgram = "INSERT INTO business_program\n" +
            "(biz_pgm_id, biz_pgm_tp_cd, part_requirement_cd_id, pgm_release_dt, eff_dt, pgm_end_dt, \n" +
            "qualfctn_start_dt, qualfctn_end_dt,  MBRSHP_PRCS_DT, MBRSHP_PRCS_FLG, additional_info_txt, \n" +
            "grp_id, subgrp_id, new_hire_dt, biz_pgm_stat_cd_id, QUALFCTN_CHKMRK_ID, elig_pgm_pkg_id, \n" +
            " stat_calc_end_dt, CONTRIBUTION_START_DT, CONTRIBUTION_END_DT,\n" +
            " BIZ_PGM_SPC_HNDLR_TP_ID, \n" +
            "insert_usr, modify_usr, insert_ts, modify_ts ) VALUES\n" +
            "(?, ?, ?, ?, ?, ?, \n" +
            " ?, ?, ?, ?, ?,\n" +
            " ?, ?, ?, ?, ?, ?, ?, ?, ?, \n" +
            " ?, ?, ?, SYSDATE, SYSDATE)";
    private static final String updateBusinessProgram = "  UPDATE business_program\n" +
            "SET part_requirement_cd_id  = ?, pgm_release_dt = ?, EFF_DT = ?, PGM_END_DT = ?, new_hire_dt = ?, qualfctn_start_dt = ?\n" +
            ", qualfctn_end_dt = ?,  MBRSHP_PRCS_DT=?, MBRSHP_PRCS_FLG = ?, additional_info_txt = ?, modify_usr = ?, modify_ts = SYSDATE , biz_pgm_stat_cd_id = ?\n" +
            ", ELIG_PGM_PKG_ID = ?, QUALFCTN_CHKMRK_ID = ?, STAT_CALC_END_DT = ?\n" +
            ", CONTRIBUTION_START_DT = ? , CONTRIBUTION_END_DT = ?, BIZ_PGM_SPC_HNDLR_TP_ID = ?\n" +
            "WHERE biz_pgm_id = ?";


    private static final String selectBusinessPrograms = " SELECT DISTINCT\n" +
            " biz.biz_pgm_id\n" +
            ", biz.biz_pgm_tp_cd\n" +
            ", prog_type.biz_pgm_nm \n" +
            ", prog_type.biz_pgm_desc \n" +
            ", biz.part_requirement_cd_id\n" +
            ", (select LU_DESC from luv where lu_id=biz.part_requirement_cd_id) as part_requirement_desc\n" +
            ", (select LU_VAL from luv where lu_id=biz.part_requirement_cd_id) as part_requirement_value\n" +
            ", biz.pgm_release_dt\n" +
            ", biz.eff_dt\n" +
            ", biz.pgm_end_dt \n" +
            ", biz.qualfctn_start_dt \n" +
            ", biz.qualfctn_end_dt \n" +
            ", biz.additional_info_txt\n" +
            ", biz.qualfctn_start_dt + interval '1' year AS bnft_yr_start_dt\n" +
            ", 0 as bnft_level_cd\n" +
            ", '' as bnft_level_desc\n" +
            ", EMPL_GRP_NM AS GRP_NM\n" +
            ", EMPL_GRP_NO AS GRP_NO\n" +
            ", biz.GRP_ID\n" +
            ", EMPL_GRP_SITE_NM AS SUBGRP_NM\n" +
            ", EMPL_GRP_SITE_ID_NO AS SITE_ID_NO\n" +
            ", biz.SUBGRP_ID\n" +
            ", EMPL_GRP_RPT_NM\n" +
            ", EMPL_GRP_SITE_RPT_NM\n" +
            ", EMPL_GRP_ABBR_NM\n" +
            ", EMPL_GRP_SITE_ABBR_NM\n" +
            ", biz.new_hire_dt\n" +
            ", biz.MBRSHP_PRCS_FLG  mbrship_process_flag\n" +
            ", biz.MBRSHP_PRCS_DT mbrship_process_date\n" +
            ", biz.biz_pgm_stat_cd_id\n" +
            ", (select LU_DESC from luv where lu_id=biz.biz_pgm_stat_cd_id) as program_status_desc\n" +
            ", (select LU_VAL from luv where lu_id=biz.biz_pgm_stat_cd_id) as program_status_val\n" +
            ", ELIG_PGM_PKG_ID\n" +
            ", QUALFCTN_CHKMRK_ID\n" +
            ", (SELECT QUALFCTN_CHKMRK_NM FROM qualfctn_chkmrk qchm WHERE qchm.QUALFCTN_CHKMRK_ID = biz.QUALFCTN_CHKMRK_ID) as QUALFCTN_CHKMRK_NM\n" +
            ", biz.stat_calc_end_dt\n" +
            ", biz.CONTRIBUTION_START_DT\n" +
            ", biz.CONTRIBUTION_END_DT\n" +
            ", biz.BIZ_PGM_SPC_HNDLR_TP_ID\n" +
            ", (SELECT lu_desc FROM luv WHERE lu_id = BIZ_PGM_SPC_HNDLR_TP_ID) BIZ_PGM_SPC_HNDLR_TP\n" +
            "FROM\n" +
            "  BUSINESS_PROGRAM biz\n" +
            ", business_program_type  prog_type\n" +
            ", empl_grp_site\n" +
            "WHERE \n" +
            "   biz.biz_pgm_tp_cd =prog_type.biz_pgm_tp_cd \n" +
            "   AND empl_grp_site.GRP_ID = biz.GRP_ID\n" +
            "   AND empl_grp_site.SUBGRP_ID = biz.SUBGRP_ID\n";

    private static final String updateGroupNames = "UPDATE empl_grp_site\n" +
            "SET EMPL_GRP_RPT_NM  = ?, EMPL_GRP_ABBR_NM = ?, modify_ts = SYSDATE \n" +
            "WHERE GRP_ID = ?";

    private static final String updateSiteNames = "UPDATE empl_grp_site\n" +
            "SET EMPL_GRP_SITE_RPT_NM  = ?, EMPL_GRP_SITE_ABBR_NM = ?, modify_ts = SYSDATE \n" +
            "WHERE GRP_ID = ? AND SUBGRP_ID = ?";

    private static final String deleteEmptyBusinessProgram = "DELETE business_program WHERE biz_pgm_id = ?";

    private static final String selectBusinessProgramsActive = "SELECT DISTINCT\n" +
            " biz.biz_pgm_id\n" +
            ", biz.biz_pgm_tp_cd\n" +
            ", prog_type.biz_pgm_nm \n" +
            ", prog_type.biz_pgm_desc \n" +
            ", biz.part_requirement_cd_id\n" +
            ", (select LU_DESC from luv where lu_id=biz.part_requirement_cd_id) as part_requirement_desc\n" +
            ", (select LU_VAL from luv where lu_id=biz.part_requirement_cd_id) as part_requirement_value\n" +
            ", biz.pgm_release_dt\n" +
            ", biz.eff_dt\n" +
            ", biz.pgm_end_dt \n" +
            ", biz.qualfctn_start_dt \n" +
            ", biz.qualfctn_end_dt \n" +
            ", biz.additional_info_txt\n" +
            ", biz.qualfctn_start_dt + interval '1' year AS bnft_yr_start_dt\n" +
            ", 0 as bnft_level_cd\n" +
            ", '' as bnft_level_desc\n" +
            ", EMPL_GRP_NM AS GRP_NM\n" +
            ", EMPL_GRP_NO AS GRP_NO\n" +
            ", biz.GRP_ID\n" +
            ", EMPL_GRP_SITE_NM AS SUBGRP_NM\n" +
            ", EMPL_GRP_SITE_ID_NO AS SITE_ID_NO\n" +
            ", biz.SUBGRP_ID\n" +
            ", EMPL_GRP_RPT_NM\n" +
            ", EMPL_GRP_SITE_RPT_NM\n" +
            ", EMPL_GRP_ABBR_NM\n" +
            ", EMPL_GRP_SITE_ABBR_NM\n" +
            ", biz.new_hire_dt\n" +
            ", biz.MBRSHP_PRCS_FLG  mbrship_process_flag\n" +
            ", biz.MBRSHP_PRCS_DT mbrship_process_date\n" +
            ", biz.biz_pgm_stat_cd_id\n" +
            ", (select LU_DESC from luv where lu_id=biz.biz_pgm_stat_cd_id) as program_status_desc\n" +
            ", (select LU_VAL from luv where lu_id=biz.biz_pgm_stat_cd_id) as program_status_val\n" +
            ", ELIG_PGM_PKG_ID\n" +
            ", QUALFCTN_CHKMRK_ID\n" +
            ", (SELECT QUALFCTN_CHKMRK_NM FROM qualfctn_chkmrk qchm WHERE qchm.QUALFCTN_CHKMRK_ID = biz.QUALFCTN_CHKMRK_ID) as QUALFCTN_CHKMRK_NM\n" +
            ", biz.stat_calc_end_dt\n" +
            ", biz.CONTRIBUTION_START_DT\n" +
            ", biz.CONTRIBUTION_END_DT\n" +
            ", biz.BIZ_PGM_SPC_HNDLR_TP_ID\n" +
            ", (SELECT lu_desc FROM luv WHERE lu_id = BIZ_PGM_SPC_HNDLR_TP_ID) BIZ_PGM_SPC_HNDLR_TP\n" +
            "FROM\n" +
            "  BUSINESS_PROGRAM biz\n" +
            ", business_program_type  prog_type\n" +
            ", empl_grp_site\n" +
            "WHERE \n" +
            "   biz.biz_pgm_tp_cd =prog_type.biz_pgm_tp_cd \n" +
            "   AND empl_grp_site.GRP_ID = biz.GRP_ID\n" +
            "   AND empl_grp_site.SUBGRP_ID = biz.SUBGRP_ID\n" +
            "   AND biz.BIZ_PGM_STAT_CD_ID = (SELECT lu_id FROM  luv  WHERE lu_grp='BPM_ACTVTN_STATUS' AND lu_val='ACTIVE')";

    private static final String selectParticipatingSubGroups = "SELECT DISTINCT groups.grp_id, EMPL_GRP_NO as grp_no, EMPL_GRP_NM as grp_nm, biz.subgrp_id, EMPL_GRP_SITE_ID_NO as site_id_no, EMPL_GRP_SITE_NM as subgrp_nm, max(biz.qualfctn_start_dt) qualfctn_start_dt, bpt.biz_pgm_nm\n" +
            "FROM \n" +
            "empl_grp_site groups, business_program biz, business_program_type bpt\n" +
            "WHERE groups.grp_id = ?            \n" +
            "            AND groups.grp_id = biz.grp_id\n" +
            "            AND groups.subgrp_id = biz.subgrp_id\n" +
            "AND bpt.biz_pgm_tp_cd =  biz.biz_pgm_tp_cd\n" +
            "            AND biz.BIZ_PGM_STAT_CD_ID <> (select lu_id from luv where lu_grp='BPM_ACTVTN_STATUS' and lu_val='WITHDRAWN')\n" +
            "           --EV77389\n" +
            "           -- AND SYSDATE BETWEEN biz.eff_dt AND biz.pgm_end_dt \n" +
            "GROUP BY groups.grp_id, empl_grp_no, empl_grp_nm, biz.subgrp_id, EMPL_GRP_SITE_ID_NO, EMPL_GRP_SITE_NM, bpt.biz_pgm_nm\n" +
            "ORDER BY qualfctn_start_dt desc, EMPL_GRP_SITE_ID_NO\n";

    private static final String markGroupSiteForUpdate =
            "INSERT INTO processing_status_log\n" +
                    "SELECT\n" +
                    "processing_status_log_seq.nextval, ?, prsn_id  , null,\n" +
                    "'BPM_ADMIN', 'BPM_ADMIN', SYSDATE, SYSDATE, 'PENDING'\n" +
                    "FROM\n" +
                    "( SELECT DISTINCT person_no prsn_id FROM\n" +
                    "  prsn_baseline_ds baseline\n" +
                    ", business_program biz\n" +
                    ", prsn_demographics demo\n" +
                    "WHERE\n" +
                    "biz.biz_pgm_id = ?\n" +
                    "AND baseline.grp_id = biz.grp_id\n" +
                    "AND baseline.subgrp_id = biz.subgrp_id\n" +
                    "AND biz.eff_dt = baseline.biz_pgm_eff_dt\n" +
                    "AND biz.pgm_end_dt = baseline.biz_pgm_end_dt\n" +
                    "AND baseline.person_no = demo.prsn_id\n" +
                    "AND biz.part_requirement_cd_id =\n" +
                    "   (SELECT CASE biz.part_requirement_cd_id\n" +
                    "  WHEN (select lu_id from luv where lu_val='PH_ONLY') THEN\n" +
                    "   CASE baseline.rel_cd\n" +
                    "   WHEN 1 THEN part_requirement_cd_id\n" +
                    "   END\n" +
                    "  WHEN (select lu_id from luv where lu_val='PH_AND_SPOUSE') THEN\n" +
                    "  CASE baseline.rel_cd\n" +
                    "  WHEN 1 THEN part_requirement_cd_id\n" +
                    "  WHEN 2 THEN part_requirement_cd_id\n" +
                    "  END\n" +
                    "  WHEN (select lu_id from luv where lu_val='PH_SPOUSE_OPT') THEN\n" +
                    "CASE baseline.rel_cd\n" +
                    "WHEN 1 THEN part_requirement_cd_id\n" +
                    "WHEN 2 THEN part_requirement_cd_id\n" +
                    "END\n" +
                    "  WHEN (select lu_id from luv where lu_val='PH_AND_SPOUSE_OR_DOM') THEN\n" +
                    "  CASE baseline.rel_cd\n" +
                    "  WHEN 1 THEN part_requirement_cd_id\n" +
                    "  WHEN 2 THEN part_requirement_cd_id\n" +
                    "  WHEN 13 THEN part_requirement_cd_id\n" +
                    "  END\n" +
                    "  WHEN (select lu_id from luv where lu_val='PH_SPOUSE_DOM_OPT') THEN\n" +
                    "  CASE baseline.rel_cd\n" +
                    "  WHEN 1 THEN part_requirement_cd_id\n" +
                    "  WHEN 2 THEN part_requirement_cd_id\n" +
                    "  WHEN 13 THEN part_requirement_cd_id\n" +
                    "              END\n" +
                    "WHEN (select lu_id from luv where lu_val = 'PH_SP_18_OPT')\n" +
                    "THEN CASE rel_cd\n" +
                    "WHEN 1\n" +
                    "THEN part_requirement_cd_id\n" +
                    "WHEN 2\n" +
                    "THEN part_requirement_cd_id\n" +
                    "WHEN 3\n" +
                    "THEN part_requirement_cd_id\n" +
                    "WHEN 4\n" +
                    "THEN part_requirement_cd_id\n" +
                    "WHEN 5\n" +
                    "THEN part_requirement_cd_id\n" +
                    "WHEN 6\n" +
                    "THEN part_requirement_cd_id\n" +
                    "WHEN 7\n" +
                    "THEN part_requirement_cd_id\n" +
                    "WHEN 9\n" +
                    "THEN part_requirement_cd_id\n" +
                    "WHEN 12\n" +
                    "THEN part_requirement_cd_id\n" +
                    "WHEN 14\n" +
                    "THEN part_requirement_cd_id\n" +
                    "END\n" +
                    "WHEN (select lu_id from luv where lu_val = 'PH_SP_DP_18_OPT')\n" +
                    "THEN CASE rel_cd\n" +
                    "WHEN 1\n" +
                    "THEN part_requirement_cd_id\n" +
                    "WHEN 2\n" +
                    "THEN part_requirement_cd_id\n" +
                    "WHEN 3\n" +
                    "THEN part_requirement_cd_id\n" +
                    "WHEN 4\n" +
                    "THEN part_requirement_cd_id\n" +
                    "WHEN 5\n" +
                    "THEN part_requirement_cd_id\n" +
                    "WHEN 6\n" +
                    "THEN part_requirement_cd_id\n" +
                    "WHEN 7\n" +
                    "THEN part_requirement_cd_id\n" +
                    "WHEN 9\n" +
                    "THEN part_requirement_cd_id\n" +
                    "WHEN 12\n" +
                    "THEN part_requirement_cd_id\n" +
                    "WHEN 13\n" +
                    "THEN part_requirement_cd_id\n" +
                    "WHEN 14\n" +
                    "THEN part_requirement_cd_id\n" +
                    "END\n" +
                    "  WHEN (select lu_id from luv where lu_val='ALL_MEMBERS') THEN part_requirement_cd_id\n" +
                    "   WHEN (select lu_id from luv where lu_val='PH_18_OPT') THEN\n" +
                    "   (SELECT CASE WHEN TRUNC((MONTHS_BETWEEN(SYSDATE, dob_dt))/12) >=18 THEN part_requirement_cd_id\n" +
                    " ELSE -1\n" +
                    " END as part_requirement_cd_id FROM DUAL)\n" +
                    "  WHEN (select lu_id from luv where lu_val='ALL_18_PLUS') THEN\n" +
                    "   (SELECT CASE WHEN TRUNC((MONTHS_BETWEEN(SYSDATE, dob_dt))/12) >=18 THEN part_requirement_cd_id\n" +
                    " ELSE -1\n" +
                    " END as part_requirement_cd_id FROM DUAL)\n" +
                    "  END FROM dual)\n" +
                    "      ) ";

    private static final String selectProgramTemplates =
            "SELECT DISTINCT\n" +
                    "  biz.biz_pgm_id\n" +
                    ", biz.biz_pgm_tp_cd\n" +
                    ", prog_type.biz_pgm_nm \n" +
                    ", prog_type.biz_pgm_desc \n" +
                    ", biz.part_requirement_cd_id\n" +
                    ", (select LU_DESC from luv where lu_id=biz.part_requirement_cd_id) as part_requirement_desc\n" +
                    ", (select LU_VAL from luv where lu_id=biz.part_requirement_cd_id) as part_requirement_value\n" +
                    ", biz.pgm_release_dt\n" +
                    ", biz.eff_dt\n" +
                    ", biz.pgm_end_dt \n" +
                    ", biz.qualfctn_start_dt \n" +
                    ", biz.qualfctn_end_dt \n" +
                    ", biz.additional_info_txt\n" +
                    ", biz.qualfctn_start_dt + interval '1' year AS bnft_yr_start_dt\n" +
                    ", 0 as bnft_level_cd\n" +
                    ", '' as bnft_level_desc\n" +
                    ", prog_type.biz_pgm_nm || ' Template' as GRP_NM\n" +
                    ",  '0' as GRP_NO\n" +
                    ", biz.GRP_ID\n" +
                    ", prog_type.biz_pgm_nm  || ' Template' as SUBGRP_NM\n" +
                    ", '0' as SITE_ID_NO\n" +
                    ", biz.SUBGRP_ID\n" +
                    ", '' AS EMPL_GRP_RPT_NM\n" +
                    ", '' AS EMPL_GRP_SITE_RPT_NM\n" +
                    ", '' AS EMPL_GRP_ABBR_NM\n" +
                    ", '' AS EMPL_GRP_SITE_ABBR_NM\n" +
                    ", biz.new_hire_dt\n" +
                    ", null as mbrship_process_flag\n" +
                    ", null as mbrship_process_date\n" +
                    ", biz.biz_pgm_stat_cd_id\n" +
                    ", (select LU_DESC from luv where lu_id=biz.biz_pgm_stat_cd_id) as program_status_desc\n" +
                    ", (select LU_VAL from luv where lu_id=biz.biz_pgm_stat_cd_id) as program_status_val\n" +
                    ", ELIG_PGM_PKG_ID\n" +
                    ", stat_calc_end_dt\n" +
                    ", CONTRIBUTION_START_DT                           \n" +
                    ", CONTRIBUTION_END_DT\n" +
                    ", biz.BIZ_PGM_SPC_HNDLR_TP_ID\n" +
                    ", (SELECT lu_desc FROM luv WHERE lu_id = BIZ_PGM_SPC_HNDLR_TP_ID) BIZ_PGM_SPC_HNDLR_TP  \n" +
                    " FROM\n" +
                    "  BUSINESS_PROGRAM biz\n" +
                    ", business_program_type  prog_type\n" +
                    "WHERE \n" +
                    "   biz.grp_id = 0\n" +
                    "   AND biz.biz_pgm_tp_cd =prog_type.biz_pgm_tp_cd  ";
    
    private static final String selectProgramPackages = 
            "SELECT\n" +
                    "biz.biz_pgm_id\n" +
                    ", pkb.GRP_ID\n" +
                    ", pkb.SUBGRP_ID\n" +
                    ", pkb.BEN_PKG_NM\n" +
                    ", pkb.ben_pkg_id\n" +
                    ", pkb.ben_pkg_cd\n" +
                    ", pkb.BEN_PKG_TP\n" +
                    ", pkb.INSURED_TP_NM\n" +
                    ", pkb.eff_dt\n" +
                    ", pkb.end_dt\n" +
                    ", pkb.PURCH_SUB_TP_NM\n" +
                    ", pkb.PURCH_SUB_TP_CD_ID\n" +
                    ", (SELECT lu_desc FROM luv WHERE lu_id = pkb.PURCH_SUB_TP_CD_ID) PURCH_SUB_TP_CD\n" +
                    ", pkb.PKG_BASELINE_DESC\n" +
                    "FROM\n" +
                    "pkg_baseline_ds pkb\n" +
                    ", business_program biz\n" +
                    "WHERE\n" +
                    "biz.biz_pgm_id = ?\n" +
                    "AND biz.grp_id = pkb.grp_id\n" +
                    "AND biz.subgrp_id = pkb.subgrp_id\n" +
                    "            order by pkb.BEN_PKG_NM asc";

    private static final String selectBusinessProgramChangeLog =
            "  SELECT change_text, (SELECT DISTINCT BPM_USR_NM FROM usr_env WHERE BPM_USR_ID = insert_usr) insert_user \n" +
                    ", insert_ts FROM business_program_change_log WHERE biz_pgm_id = ?\n" +
                    "ORDER BY insert_ts DESC";

    private static final String selectBusinessProgramInSameYear =
            "SELECT DISTINCT biz.biz_pgm_id, groups.grp_id, EMPL_GRP_NO as grp_no, EMPL_GRP_NM as grp_nm, biz.subgrp_id, EMPL_GRP_SITE_ID_NO as site_id_no, EMPL_GRP_SITE_NM as subgrp_nm, max(biz.qualfctn_start_dt) qualfctn_start_dt, bpt.biz_pgm_nm\n" +
                    "FROM \n" +
                    "empl_grp_site groups, business_program biz \n" +
                    ", (SELECT grp_id, eff_dt FROM business_program WHERE biz_pgm_id = ?) same_eff_date, business_program_type bpt\n" +
                    "WHERE biz.eff_dt = same_eff_date.eff_dt\n" +
                    "            AND biz.grp_id = same_eff_date.grp_id\n" +
                    "            AND groups.grp_id = biz.grp_id\n" +
                    "            AND groups.subgrp_id = biz.subgrp_id\n" +
                    "            AND biz.BIZ_PGM_STAT_CD_ID <> (select lu_id from luv where lu_grp='BPM_ACTVTN_STATUS' and lu_val='WITHDRAWN')\n" +
                    "AND bpt.biz_pgm_tp_cd =  biz.biz_pgm_tp_cd\n" +
                    "GROUP BY biz.biz_pgm_id, groups.grp_id, empl_grp_no, empl_grp_nm, biz.subgrp_id, EMPL_GRP_SITE_ID_NO, EMPL_GRP_SITE_NM, bpt.biz_pgm_nm\n" +
                    "ORDER BY qualfctn_start_dt desc, EMPL_GRP_SITE_ID_NO ";

    private static final String updatePackageID =
            "UPDATE business_program\n" +
                    "SET ELIG_PGM_PKG_ID = ?, modify_usr = ?, modify_ts = SYSDATE\n" +
                    "tWHERE biz_pgm_id = ? ";

    private static final String insertBusinessProgramChangeLog =
            """
            INSERT INTO business_program_change_log (biz_pgm_chng_log_id, biz_pgm_id, change_text, insert_usr, insert_ts) VALUES (?, ?, ?, ?, SYSDATE) 
            """;

    private static final String selectAllBPMGroups = """
            SELECT distinct biz.grp_id, empl_grp_no as grp_no, empl_grp_nm as grp_nm
            FROM empl_grp_site groups, business_program biz
            WHERE biz.grp_id = groups.grp_id
            AND groups.empl_grp_no IS NOT NULL
            ORDER BY empl_grp_nm
            """;

    private static final String selectBPMGroupByMemberIdAndTransactionDate = """
                SELECT distinct biz.grp_id, empl_grp_no as grp_no, empl_grp_nm as grp_nm
                FROM empl_grp_site egs, business_program biz , prsn_demographics demo, prsn_baseline_ds baseline
                WHERE baseline.person_no = demo.prsn_id and baseline.grp_id = biz.grp_id
                AND baseline.subgrp_id = biz.subgrp_id
                AND baseline.biz_pgm_eff_dt = biz.eff_dt
                AND baseline.biz_pgm_end_dt = biz.pgm_end_dt
                and ((baseline.grp_id = egs.grp_id) and (baseline.subgrp_id = egs.subgrp_id))
                AND biz.BIZ_PGM_STAT_CD_ID = (SELECT lu_id FROM luv WHERE
                lu_grp='BPM_ACTVTN_STATUS' AND lu_val='ACTIVE') AND egs.empl_grp_no IS NOT NULL
             """;

    // @formatter:on

    private DataFieldMaxValueIncrementer businessProgramIdIncrementer;
    private DataFieldMaxValueIncrementer programChangeLogIDIncrementer;


    public BusinessProgramDAOJdbc(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @PostConstruct
    private void initialize() {
        setDataSource(dataSource);
        businessProgramIdIncrementer = new OracleSequenceMaxValueIncrementer(dataSource, BIZ_PGM_ID_SEQ);
        programChangeLogIDIncrementer = new OracleSequenceMaxValueIncrementer(dataSource, BIZ_PGM_CHNG_LOG_SEQ);
    }

    @Override
    public Collection<String> getAllStartDates() {
        final ArrayList<String> lStartDates = new ArrayList<String>();

        JdbcTemplate template = getJdbcTemplate();
        Object[] params = null;
        int[] types = null;


        template.query(selectAllStartDates, params, types, new RowCallbackHandler() {
            public void processRow(ResultSet rs) throws SQLException {
                SimpleDateFormat fmt = new SimpleDateFormat(BPMAdminConstants.HP_BPM_ADMIN_UI_COMMON_DATE_FORMAT);

                if (rs.getDate("qualfctn_start_dt") != null) {
                    String lQualificationStartDate = fmt.format(rs.getDate("qualfctn_start_dt"));
                    lStartDates.add(lQualificationStartDate);
                }
            }
        });

        return lStartDates;
    }

    /**
     * Retrieve a list of Employer Groups given a full or partial Group Name.
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Override
    public Collection<EmployerGroup> getGroupsByName(String pGroupName) throws DataAccessException {
        final ArrayList<EmployerGroup> lGroups = new ArrayList<EmployerGroup>();
        Object[] params = new Object[0];
        int[] types = new int[0];

        StringBuffer lQuery = new StringBuffer();

        JdbcTemplate template = getJdbcTemplate();

        lQuery.append(selectGroupsByName);
        lQuery.append(" AND EMPL_GRP_NM like UPPER('");
        lQuery.append(pGroupName);
        lQuery.append("%')");
        lQuery.append(" ORDER BY EMPL_GRP_NM ");

        template.query(lQuery.toString(), new RowCallbackHandler() {
            public void processRow(ResultSet rs) throws SQLException {
                EmployerGroup lEmployerGroup = new EmployerGroup();

                lEmployerGroup.setGroupID(rs.getInt("grp_id"));
                lEmployerGroup.setGroupNumber(rs.getString("grp_no"));
                lEmployerGroup.setGroupName(rs.getString("grp_nm"));
                lEmployerGroup.setHasProgram(rs.getString("has_program"));

                lGroups.add(lEmployerGroup);
            }
        });

        return lGroups;
    }

    @Override
    public Collection<EmployerGroup> getAllGroupSites(String pGroupNo) {
        final ArrayList<EmployerGroup> lGroupSites = new ArrayList<EmployerGroup>();
        Object[] params = new Object[]{pGroupNo, pGroupNo};
        int[] types = new int[]{Types.VARCHAR, Types.VARCHAR};
        StringBuffer lQuery = new StringBuffer();

        JdbcTemplate template = getJdbcTemplate();

        /*
         * Group Sites that have a current, or have had a business program.
         */
        lQuery.append(selectAllGroupSitesWithPrograms);

        template.query(lQuery.toString(), params, types, new RowCallbackHandler() {
            public void processRow(ResultSet rs) throws SQLException {
                EmployerGroup lEmployerGroup = new EmployerGroup();

                lEmployerGroup.setGroupID(rs.getInt("grp_id"));
                lEmployerGroup.setGroupNumber(rs.getString("empl_grp_no"));
                lEmployerGroup.setGroupName(rs.getString("empl_grp_nm"));
                lEmployerGroup.setSubgroupID(rs.getInt("subgrp_id"));
                lEmployerGroup.setSiteName(rs.getString("empl_grp_site_nm"));
                lEmployerGroup.setSiteNumber(rs.getString("empl_grp_site_id_no"));
                lEmployerGroup.setHasProgram(rs.getString("has_program"));
                lEmployerGroup.setBusinessProgramName(rs.getString("biz_pgm_nm"));
                lEmployerGroup.setEffectiveDate(rs.getDate("eff_dt"));

                lGroupSites.add(lEmployerGroup);
            }
        });

        Object[] params2 = new Object[]{pGroupNo};
        int[] types2 = new int[]{Types.VARCHAR};
        StringBuffer lQuery2 = new StringBuffer();

        /*
         * Group Sites that have never had a business program.
         */

        lQuery2.append(selectAllGroupSitesWithoutPrograms);

        template.query(lQuery2.toString(), params2, types2, new RowCallbackHandler() {
            public void processRow(ResultSet rs) throws SQLException {
                EmployerGroup lEmployerGroup = new EmployerGroup();

                lEmployerGroup.setGroupID(rs.getInt("grp_id"));
                lEmployerGroup.setGroupNumber(rs.getString("empl_grp_no"));
                lEmployerGroup.setGroupName(rs.getString("empl_grp_nm"));
                lEmployerGroup.setSubgroupID(rs.getInt("subgrp_id"));
                lEmployerGroup.setSiteName(rs.getString("empl_grp_site_nm"));
                lEmployerGroup.setSiteNumber(rs.getString("empl_grp_site_id_no"));
                lEmployerGroup.setHasProgram(rs.getString("has_program"));
                lEmployerGroup.setBusinessProgramName(rs.getString("biz_pgm_nm"));
                lEmployerGroup.setEffectiveDate(rs.getDate("eff_dt"));

                lGroupSites.add(lEmployerGroup);
            }
        });

        return lGroupSites;
    }

    @Override
    public Collection<ExemptionHistory> getExemptionHistory(String pGroupNo, java.sql.Date pProgramEffectiveDate, String pSiteNo, String pExemptionTypeCode, String pContractNo, String pMemberNo, java.sql.Date pExemptionFromDate, java.sql.Date pExemptionToDate) throws DataAccessException {
        final ArrayList<ExemptionHistory> lExemptionHistoryList = new ArrayList<ExemptionHistory>();
        StringBuffer lQuery = new StringBuffer();
        ArrayList<Object> lParameters = new ArrayList<Object>();
        ArrayList<Integer> lTypes = new ArrayList<Integer>();

        JdbcTemplate template = getJdbcTemplate();

        lQuery.append(selectExemptionHistory);

        lParameters.add(pProgramEffectiveDate);
        lTypes.add(Types.DATE);


        if (pExemptionTypeCode != null && pExemptionTypeCode.length() > 0 && !pExemptionTypeCode.equalsIgnoreCase(BPMAdminConstants.BPM_EXEMPTION_TYPE_ALL)) {
            lQuery.append(" AND qov.ovrd_tp_cd_id = ? ");
            lParameters.add(pExemptionTypeCode);
            lTypes.add(Types.INTEGER);
        }


        if (pGroupNo != null && pGroupNo.length() > 0) {
            lQuery.append(" AND egs.empl_grp_no = ? ");
            lParameters.add(pGroupNo);
            lTypes.add(Types.VARCHAR);
        }

        if (pSiteNo != null && pSiteNo.length() > 0) {
            lQuery.append(" AND egs.empl_grp_site_id_no = ? ");
            lParameters.add(pSiteNo);
            lTypes.add(Types.VARCHAR);
        }


        //BPM-27
        if (pContractNo != null && pContractNo.length() > 0) {
            lQuery.append(" AND con.contract_no = ? ");
            lParameters.add(Integer.valueOf(pContractNo));
            lTypes.add(Types.INTEGER);
        }

        if (pMemberNo != null && pMemberNo.length() > 0) {
            lQuery.append(" AND demo.hp_mem_id = ? ");
            lParameters.add(pMemberNo);
            lTypes.add(Types.VARCHAR);
        }

        if (pExemptionFromDate != null && pExemptionToDate != null) {
            lQuery.append(" AND qov.exemption_issue_dt between ? and ? ");
            lParameters.add(pExemptionFromDate);
            lTypes.add(Types.DATE);
            lParameters.add(pExemptionToDate);
            lTypes.add(Types.DATE);
        } else if (pExemptionFromDate != null) {
            lQuery.append(" AND qov.exemption_issue_dt >= ?");
            lParameters.add(pExemptionFromDate);
            lTypes.add(Types.DATE);
        }

        lQuery.append(" group by hp_mem_id, qov.ovrd_tp_cd_id, exemption_issue_dt, qov.aprvr_user_id, con.modify_ts, stat.modify_ts," + " stat.stat_cd_id, con.cntr_stat_cd_id, qov.cntr_no, egs.EMPL_GRP_NO, egs.empl_grp_nm, egs.empl_grp_site_id_no, egs.empl_grp_site_nm," + "biz.qualfctn_start_dt, biz.qualfctn_end_dt, biz.eff_dt, biz.pgm_end_dt, biz_pgm_nm, qov.biz_pgm_incntv_optn_id," + "io.incntv_optn_nm, qov.insert_usr, demo.FIRST_NM, demo.LAST_NM, demo.middle_nm, qov.INSERT_TS ");

        lQuery.append(" ORDER BY trunc(qov.exemption_issue_dt) DESC, qov.ovrd_tp_cd_id asc, egs.empl_grp_no asc, egs.empl_grp_site_id_no asc, hp_mem_id asc, qov.cntr_no asc ");

        Object[] params = new Object[lParameters.size()];
        lParameters.toArray(params);

        int[] types = new int[lTypes.size()];
        for (int j = 0; j < lTypes.size(); j++) {
            types[j] = lTypes.get(j).intValue();
        }

        try {
            template.query(lQuery.toString(), params, types, new RowCallbackHandler() {
                public void processRow(ResultSet rs) throws SQLException {
                    ExemptionHistory lExemptionHistory = new ExemptionHistory();

                    lExemptionHistory.setExemptionTypeCodeDesc(rs.getString("exemption_type"));
                    lExemptionHistory.setExemptionDate(rs.getDate("exemption_issue_dt"));
                    lExemptionHistory.setApprover(rs.getString("aprvr_user_id"));
                    lExemptionHistory.setMemberID(rs.getString("hp_mem_id"));
                    lExemptionHistory.setProcessingDate(rs.getDate("processing_date"));
                    lExemptionHistory.setMemberStatus(rs.getString("member_status"));
                    lExemptionHistory.setContractStatus(rs.getString("contract_status"));
                    lExemptionHistory.setContractNumber(rs.getInt("contract_no"));
                    lExemptionHistory.setSiteNumber(rs.getString("empl_grp_site_id_no"));
                    lExemptionHistory.setSiteName(rs.getString("empl_grp_site_nm"));
                    lExemptionHistory.setQualificationStartDate(rs.getDate("qualfctn_start_dt"));
                    lExemptionHistory.setQualificationEndDate(rs.getDate("qualfctn_end_dt"));
                    lExemptionHistory.setProgramEffectiveDate(rs.getDate("eff_dt"));
                    lExemptionHistory.setProgramEndDate(rs.getDate("pgm_end_dt"));
                    lExemptionHistory.setProgramName(rs.getString("biz_pgm_nm"));
                    lExemptionHistory.setProgramIncentiveOptionID(rs.getInt("biz_pgm_incntv_optn_id"));
                    lExemptionHistory.setIncentiveOptionName(rs.getString("incntv_optn_nm"));
                    lExemptionHistory.setCreatedBy(rs.getString("created_by"));
                    lExemptionHistory.setCreateDate(rs.getDate("INSERT_TS"));
                    lExemptionHistory.setGroupNumber(rs.getString("empl_grp_no"));
                    lExemptionHistory.setGroupName(rs.getString("empl_grp_nm"));
                    lExemptionHistory.setFirstName(rs.getString("FIRST_NM"));
                    lExemptionHistory.setLastName(rs.getString("LAST_NM"));
                    lExemptionHistory.setMiddleName(rs.getString("MIDDLE_NM"));
                    lExemptionHistory.setApprover(rs.getString("aprvr_user_id"));

                    lExemptionHistoryList.add(lExemptionHistory);
                }
            });
        } catch(Exception e) {
            logger.error(e);
        }

        return lExemptionHistoryList;
    }

    /**
     * Returns a BusinessProgramTO object representing the Business Program specified by the
     * qualification start date, and group number.
     *
     * @param pTargetQualificationDate
     * @param pGroupNo
     *
     * @return ArrayList of BusinessPrograms
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Override
    public Collection<BusinessProgram> getActiveNWithdrawnBusinessPrograms(Date pTargetQualificationDate, String pGroupNo, String pSiteNo, Integer pGroupID) {
        final ArrayList<BusinessProgram> lBusinessPrograms;

        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectActiveNWithdrawnBusinessPrograms);

        ArrayList<Object> lParameters = new ArrayList<Object>();
        ArrayList<Integer> lTypes = new ArrayList<Integer>();

        if (pTargetQualificationDate != null) {
            lParameters.add(pTargetQualificationDate);
            lTypes.add(Integer.valueOf(Types.DATE));
            lQuery.append(" AND QUALFCTN_START_DT = ? ");
        }

        // Group Number
        if (pGroupNo != null && pGroupNo.length() > 0 && Integer.valueOf(pGroupNo) > 0) {
            lParameters.add(pGroupNo);
            lTypes.add(Integer.valueOf(Types.CHAR));
            lQuery.append(" AND EMPL_GRP_NO = ? ");
        }


        if (pSiteNo != null && pSiteNo.length() > 0) {
            lParameters.add(pSiteNo);
            lTypes.add(Integer.valueOf(Types.CHAR));
            lQuery.append(" AND EMPL_GRP_SITE_ID_NO = ? ");
        }

        if (pGroupID != null && pGroupID.intValue() > 0) {
            lParameters.add(pGroupID);
            lTypes.add(Integer.valueOf(Types.INTEGER));
            lQuery.append(" AND biz.GRP_ID = ? ");
        }

        // Convert the parameter and types ArrayLists to arrays of primitive types.
        Object params[] = new Object[lParameters.size()];
        lParameters.toArray(params);

        int types[] = new int[lTypes.size()];
        for (int j = 0; j < lTypes.size(); j++) {
            types[j] = ((Integer) lTypes.get(j)).intValue();
        }

        //lQuery.append(" ORDER BY QUALFCTN_START_DT desc, EMPL_GRP_NO, EMPL_GRP_SITE_ID_NO ");
        lQuery.append(" ORDER BY PROGRAM_STATUS_VAL asc, QUALFCTN_START_DT desc, EMPL_GRP_NO, EMPL_GRP_SITE_ID_NO asc ");

        JdbcTemplate template = getJdbcTemplate();

        lBusinessPrograms = (ArrayList<BusinessProgram>)
                template.query(lQuery.toString(), params, types, new BusinessProgramRowMapper());

        return lBusinessPrograms;
    }

    //	 Spring rowMapper class for BusinessProgramTO.
    // Retrieves the columns values from the resultSet and populates a BusinessProgramTO
    // object.
    private static final class BusinessProgramRowMapper implements RowMapper {
        public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
            BusinessProgram lBusinessProgram = new BusinessProgram();

            lBusinessProgram.setProgramID(rs.getInt("biz_pgm_id"));

            lBusinessProgram.setProgramTypeCodeID(rs.getString("biz_pgm_tp_cd"));
            lBusinessProgram.setProgramName(rs.getString("biz_pgm_nm"));
            lBusinessProgram.setProgramDescription(rs.getString("biz_pgm_desc"));
            lBusinessProgram.setFamilyParticipationRequirement(rs.getInt("part_requirement_cd_id"));
            lBusinessProgram.setFamilyParticipationDesc(rs.getString("part_requirement_desc"));
            lBusinessProgram.setFamilyParticipationValue(rs.getString("part_requirement_value"));
            lBusinessProgram.setReleaseDate(rs.getDate("pgm_release_dt"));
            lBusinessProgram.setEffectiveDate(rs.getDate("eff_dt"));
            lBusinessProgram.setEndDate(rs.getDate("pgm_end_dt"));

            lBusinessProgram.setQualificationWindowStartDate(rs.getDate("qualfctn_start_dt"));
            lBusinessProgram.setQualificationWindowEndDate(rs.getDate("qualfctn_end_dt"));

            if (rs.getString("mbrship_process_flag") != null) {
                lBusinessProgram.setMembershipProcessFlag(rs.getString("mbrship_process_flag"));
            } else {
                lBusinessProgram.setMembershipProcessFlag("");
            }

            lBusinessProgram.setMembershipProcessDate(rs.getDate("mbrship_process_date"));

            lBusinessProgram.setAdditionalGroupProgramInfo(rs.getString("additional_info_txt"));

            lBusinessProgram.setBenefitYearStartDate(rs.getDate("bnft_yr_start_dt"));
            lBusinessProgram.setBenefitLevelCodeID(rs.getInt("bnft_level_cd"));
            lBusinessProgram.setBenefitLevelDesc(rs.getString("bnft_level_desc"));

            lBusinessProgram.setProgramStatusCodeID(rs.getInt("biz_pgm_stat_cd_id"));
            lBusinessProgram.setProgramStatusCodeValue(rs.getString("program_status_val"));
            lBusinessProgram.setProgramStatusDesc(rs.getString("program_status_desc"));
            lBusinessProgram.setPackageID(rs.getInt("ELIG_PGM_PKG_ID"));
            lBusinessProgram.setStatusCalcEndDate(rs.getDate("stat_calc_end_dt"));

            lBusinessProgram.setContributionStartDate(rs.getDate("CONTRIBUTION_START_DT"));
            lBusinessProgram.setContributionEndDate(rs.getDate("CONTRIBUTION_END_DT"));

            lBusinessProgram.setReportIndicatorCodeID(rs.getInt("BIZ_PGM_SPC_HNDLR_TP_ID"));
            lBusinessProgram.setReportIndicatorCodeValue(rs.getString("BIZ_PGM_SPC_HNDLR_TP"));


            EmployerGroup lEmployerGroup = new EmployerGroup();
            lEmployerGroup.setGroupName(rs.getString("GRP_NM"));
            lEmployerGroup.setGroupNumber(rs.getString("GRP_NO"));
            lEmployerGroup.setGroupID(rs.getInt("GRP_ID"));
            lEmployerGroup.setSiteName(rs.getString("SUBGRP_NM"));
            lEmployerGroup.setSiteNumber(rs.getString("SITE_ID_NO"));
            lEmployerGroup.setSubgroupID(rs.getInt("SUBGRP_ID"));
            lEmployerGroup.setNewHireDate(rs.getDate("new_hire_dt"));

            lEmployerGroup.setGroupReportName(rs.getString("EMPL_GRP_RPT_NM"));
            lEmployerGroup.setGroupAbbreviatedName(rs.getString("EMPL_GRP_ABBR_NM"));
            lEmployerGroup.setSiteReportName(rs.getString("EMPL_GRP_SITE_RPT_NM"));
            lEmployerGroup.setSiteAbbreviatedName(rs.getString("EMPL_GRP_SITE_ABBR_NM"));

            lBusinessProgram.setEmployerGroup(lEmployerGroup);

            return lBusinessProgram;
        }
    }

    @Override
    public Collection<Integer> getNumberOfMembers(Integer pProgramID) {
        final ArrayList<Integer> lNumberOfMembers = new ArrayList<Integer>();
        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{pProgramID};
        int types[] = new int[]{Types.INTEGER};

        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectNumberOfMembers);
        lQuery.append(" AND (participation_end_dt IS NULL OR trunc(participation_end_dt) > trunc(SYSDATE))");

        template.query(lQuery.toString(), params, types, new RowCallbackHandler() {
            public void processRow(ResultSet rs) throws SQLException {
                Integer lMemberCount = Integer.valueOf(rs.getInt("number_of_members"));

                lNumberOfMembers.add(lMemberCount);
            }
        });

        return lNumberOfMembers;
    }

    @Override
    public Collection<EmployerGroup> getGroups(String pGroupNumber) {
        final ArrayList<EmployerGroup> lGroups = new ArrayList<EmployerGroup>();
        Object params[] = new Object[0];
        int types[] = new int[0];
        StringBuffer lQuery = new StringBuffer();

        JdbcTemplate template = getJdbcTemplate();

        lQuery.append(selectGroups);
        lQuery.append(" AND empl_grp_no = '");
        lQuery.append(pGroupNumber);
        lQuery.append("'");
        lQuery.append(" ORDER BY empl_grp_no ");

        template.query(lQuery.toString(), new RowCallbackHandler() {
            public void processRow(ResultSet rs) throws SQLException {
                EmployerGroup lEmployerGroup = new EmployerGroup();

                lEmployerGroup.setGroupID(rs.getInt("grp_id"));
                lEmployerGroup.setGroupNumber(rs.getString("grp_no"));
                lEmployerGroup.setGroupName(rs.getString("grp_nm"));

                lGroups.add(lEmployerGroup);
            }
        });

        return lGroups;
    }

    @Override
    public Collection<EmployerGroup> getSubGroups(Integer pGroupID) {
        final ArrayList<EmployerGroup> lGroups = new ArrayList<EmployerGroup>();
        Object params[] = new Object[]{pGroupID};
        int types[] = new int[]{Types.INTEGER};

        final Integer lGroupID = pGroupID;

        JdbcTemplate template = getJdbcTemplate();

        template.query(selectSubGroups, params, types, new RowCallbackHandler() {
            public void processRow(ResultSet rs) throws SQLException {
                EmployerGroup lEmployerGroup = new EmployerGroup();

                lEmployerGroup.setGroupID(lGroupID);

                lEmployerGroup.setSubgroupID(rs.getInt("subgrp_id"));
                lEmployerGroup.setSiteName(rs.getString("subgrp_nm"));
                lEmployerGroup.setSiteNumber(rs.getString("site_id_no"));
                lEmployerGroup.setGroupNumber(rs.getString("grp_no"));
                lEmployerGroup.setGroupName(rs.getString("grp_nm"));

                lGroups.add(lEmployerGroup);
            }
        });

        return lGroups;
    }

    @Override
    public Collection<ProgramType> getProgramTypes() {
        final ArrayList<ProgramType> lProgramTypes = new ArrayList<ProgramType>();

        Object params[] = null;
        int types[] = null;

        JdbcTemplate template = getJdbcTemplate();

        template.query(selectProgramTypes, params, types, new RowCallbackHandler() {
            public void processRow(ResultSet rs) throws SQLException {
                ProgramType lProgramType = new ProgramType();

                lProgramType.setUsed(rs.getInt("count_used"));
                lProgramType.setProgramTypeCode(rs.getString("biz_pgm_tp_cd"));
                lProgramType.setProgramTypeName(rs.getString("biz_pgm_nm"));
                lProgramType.setProgramTypeDesc(rs.getString("biz_pgm_desc"));
                lProgramType.setReportIndicatorTypeCode(rs.getString("RPT_INDICATOR"));
                lProgramType.setInsertDate(rs.getDate("insert_ts"));
                lProgramType.setModifyDate(rs.getDate("modify_ts"));
                lProgramType.setInsertUser(rs.getString("insert_usr"));
                lProgramType.setModifyUser(rs.getString("modify_usr"));
                lProgramType.setMembershipCommunicationFlag(rs.getString("MBRSHP_CMMNCTN_FLG"));
                lProgramType.setEffectiveDate(rs.getDate("BIZ_EFF_DT"));
                lProgramType.setEndDate(rs.getDate("BIZ_END_DT"));
                if (rs.getDate("BIZ_EFF_DT") != null) {
                    lProgramType.setEffectiveDateString(BPMAdminUtils.formatDateMMddyyyy(rs.getDate("BIZ_EFF_DT")));
                }
                if (rs.getDate("BIZ_END_DT") != null) {
                    lProgramType.setEndDateString(BPMAdminUtils.formatDateMMddyyyy(rs.getDate("BIZ_END_DT")));
                }

                lProgramType.setAuthPromoTypeCodeID(rs.getInt("AUTH_PROMO_TP_CD_ID"));
                lProgramType.setAuthPromoTypeCode(rs.getString("AUTH_PROMO_TP_CD"));
                lProgramType.setActivationStatusCodeID(rs.getInt("ACTVTN_STAT_CD_ID"));
                lProgramType.setActivationStatusCode(rs.getString("ACTVTN_STAT_CD"));

                lProgramType.setMarketIndicatorID(rs.getInt("MRKT_INDCTR_ID"));
                lProgramType.setMarketIndicatorName(rs.getString("MRKT_INDCTR_NM"));

                lProgramTypes.add(lProgramType);
            }
        });

        return lProgramTypes;
    }

    @Override
    public BusinessProgram getBusinessProgram(Integer pProgramID, boolean all) {
        final ArrayList<BusinessProgram> lBusinessPrograms;

        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectBusinessPrograms);

        ArrayList<Object> lParameters = new ArrayList<Object>();
        ArrayList<Integer> lTypes = new ArrayList<Integer>();

        lParameters.add(pProgramID);
        lTypes.add(Integer.valueOf(Types.INTEGER));
        lQuery.append(" AND BIZ.biz_pgm_id = ? ");

        // If NOT all, get only ACTIVE business programs.
        if (all == false) {
            lQuery.append("    AND biz.BIZ_PGM_STAT_CD_ID IN (SELECT lu_id FROM  luv  WHERE lu_grp='BPM_ACTVTN_STATUS' AND lu_val IN ('ACTIVE', 'THIRD_PARTY')) ");
        }

        // Convert the parameter and types ArrayLists to arrays of primitive types.
        Object params[] = new Object[lParameters.size()];
        lParameters.toArray(params);

        int types[] = new int[lTypes.size()];
        for (int j = 0; j < lTypes.size(); j++) {
            types[j] = ((Integer) lTypes.get(j)).intValue();
        }

        JdbcTemplate template = getJdbcTemplate();

        lBusinessPrograms = (ArrayList<BusinessProgram>)
                template.query(lQuery.toString(), params, types, new BusinessProgramRowMapper());

        if (lBusinessPrograms != null && lBusinessPrograms.size() > 0) {
            ArrayList<Integer> lNumberOfMembers = (ArrayList<Integer>)
                    this.getNumberOfMembers(lBusinessPrograms.get(0).getProgramID());
            if (lNumberOfMembers.size() > 0) {
                Integer lMemberCount = (Integer) lNumberOfMembers.get(0);
                if (lMemberCount > 0) {
                    lBusinessPrograms.get(0).setHasMembers(true);
                }
                lBusinessPrograms.get(0).setNumberOfMembers(lMemberCount);
            }
            return lBusinessPrograms.get(0);
        } else {
            return new BusinessProgram();
        }
    }

    /**
     *
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Override
    public int insertBusinessProgram(BusinessProgram pBusinessProgram, String lUserID) {
        JdbcTemplate template = getJdbcTemplate();

        pBusinessProgram.setProgramID(businessProgramIdIncrementer.nextIntValue());

        Object params[] = new Object[]{
                pBusinessProgram.getProgramID(),
                pBusinessProgram.getProgramTypeCodeID(),
                pBusinessProgram.getFamilyParticipationRequirement(),
                pBusinessProgram.getReleaseDate(),
                pBusinessProgram.getEffectiveDate(),
                pBusinessProgram.getEndDate(),
                pBusinessProgram.getQualificationWindowStartDate(),
                pBusinessProgram.getQualificationWindowEndDate(),
                pBusinessProgram.getMembershipProcessDate(),
                pBusinessProgram.getMembershipProcessFlag(),
                pBusinessProgram.getAdditionalGroupProgramInfo(),
                pBusinessProgram.getEmployerGroup().getGroupID(),
                pBusinessProgram.getEmployerGroup().getSubgroupID(),
                pBusinessProgram.getEmployerGroup().getNewHireDate(),
                pBusinessProgram.getProgramStatusCodeID(),
                pBusinessProgram.getQualificationCheckmarkID(),
                pBusinessProgram.getPackageID(),
                pBusinessProgram.getStatusCalcEndDate(),
                pBusinessProgram.getContributionStartDate(),
                pBusinessProgram.getContributionEndDate(),
                pBusinessProgram.getReportIndicatorCodeID(),
                lUserID,
                lUserID
        };

        int types[] = new int[]{
                Types.INTEGER, Types.VARCHAR, Types.INTEGER,
                Types.DATE, Types.DATE, Types.DATE,
                Types.DATE, Types.DATE,
                Types.DATE, Types.CHAR,
                Types.VARCHAR, Types.INTEGER, Types.INTEGER,
                Types.DATE, Types.INTEGER,
                Types.INTEGER, Types.INTEGER, // Checkmark & Package ID
                Types.DATE,  // Status Calc End Date
                Types.DATE, Types.DATE, // Contribution Start and End Date
                Types.INTEGER, // Report Indicator ID
                Types.VARCHAR, Types.VARCHAR
        };

        return template.update(insertBusinessProgram, params, types);
    }

    /**
     *
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Override
    public int updateBusinessProgram(BusinessProgram pBusinessProgram, String lUserID) {
        // Check for existing business program for this program ID. Set the "All" parameter to true. Otherwise template
        // types would not be returned.
        BusinessProgram lExistingBusinessProgram = getBusinessProgram(pBusinessProgram.getProgramID(), true);

        if (pBusinessProgram.getProgramID() == 0 || lExistingBusinessProgram == null || lExistingBusinessProgram.getProgramID() != pBusinessProgram.getProgramID()) {
            return this.insertBusinessProgram(pBusinessProgram, lUserID);
        }

        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{
                pBusinessProgram.getFamilyParticipationRequirement(),
                pBusinessProgram.getReleaseDate(),
                pBusinessProgram.getEffectiveDate(),
                pBusinessProgram.getEndDate(),
                pBusinessProgram.getEmployerGroup().getNewHireDate(),
                pBusinessProgram.getQualificationWindowStartDate(),
                pBusinessProgram.getQualificationWindowEndDate(),
                pBusinessProgram.getMembershipProcessDate(),
                pBusinessProgram.getMembershipProcessFlag(),
                pBusinessProgram.getAdditionalGroupProgramInfo(),
                lUserID,
                pBusinessProgram.getProgramStatusCodeID(),
                pBusinessProgram.getPackageID(),
                pBusinessProgram.getQualificationCheckmarkID(),
                pBusinessProgram.getStatusCalcEndDate(),
                pBusinessProgram.getContributionStartDate(),
                pBusinessProgram.getContributionEndDate(),
                pBusinessProgram.getReportIndicatorCodeID(),
                pBusinessProgram.getProgramID()
        };

        int types[] = new int[]{
                Types.INTEGER, Types.DATE, Types.DATE, Types.DATE,
                Types.DATE, Types.DATE, Types.DATE, Types.DATE, Types.CHAR, Types.VARCHAR, Types.VARCHAR, Types.INTEGER
                , Types.INTEGER, Types.INTEGER, Types.DATE
                , Types.DATE, Types.DATE
                , Types.INTEGER
                , Types.INTEGER
        };

        return template.update(updateBusinessProgram, params, types);
    }

    /**
     * @param pBusinessProgram
     * @param lUserID
     * @return
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Override
    public int updateGroupNames(BusinessProgram pBusinessProgram, String lUserID) {
        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{

                pBusinessProgram.getEmployerGroup().getGroupReportName(),
                pBusinessProgram.getEmployerGroup().getGroupAbbreviatedName(),
                pBusinessProgram.getEmployerGroup().getGroupID()
        };

        int types[] = new int[]{Types.VARCHAR, Types.VARCHAR, Types.INTEGER};

        return template.update(updateGroupNames, params, types);
    }

    /**
     * @param pBusinessProgram
     * @param lUserID
     * @return
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Override
    public int updateSiteNames(BusinessProgram pBusinessProgram, String lUserID) {
        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{
                pBusinessProgram.getEmployerGroup().getSiteReportName(),
                pBusinessProgram.getEmployerGroup().getSiteAbbreviatedName(),
                pBusinessProgram.getEmployerGroup().getGroupID(),
                pBusinessProgram.getEmployerGroup().getSubgroupID()
        };

        int types[] = new int[]{Types.VARCHAR, Types.VARCHAR, Types.INTEGER, Types.INTEGER};

        return template.update(updateSiteNames, params, types);
    }

    @Override
    public Collection<EmployerGroup> getParticipatingSubGroups(Integer pGroupID) {
        final ArrayList<EmployerGroup> lGroups = new ArrayList<EmployerGroup>();
        Object params[] = new Object[]{pGroupID};
        int types[] = new int[]{Types.INTEGER};

        final Integer lGroupID = pGroupID;

        JdbcTemplate template = getJdbcTemplate();

        template.query(selectParticipatingSubGroups, params, types, new RowCallbackHandler() {
            public void processRow(ResultSet rs) throws SQLException {
                EmployerGroup lEmployerGroup = new EmployerGroup();

                lEmployerGroup.setGroupID(lGroupID);

                lEmployerGroup.setSubgroupID(rs.getInt("subgrp_id"));
                lEmployerGroup.setSiteName(rs.getString("subgrp_nm"));
                lEmployerGroup.setSiteNumber(rs.getString("site_id_no"));
                lEmployerGroup.setGroupNumber(rs.getString("grp_no"));
                lEmployerGroup.setGroupName(rs.getString("grp_nm"));
                lEmployerGroup.setQualificationStartDate(rs.getDate("qualfctn_start_dt"));
                lEmployerGroup.setBusinessProgramName(rs.getString("biz_pgm_nm"));

                lGroups.add(lEmployerGroup);
            }
        });

        return lGroups;
    }


    /**
     *
     * @param pProgramID
     * @return
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Override
    public int deleteEmptyBusinessProgram(Integer pProgramID) {
        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{pProgramID};
        int types[] = new int[]{Types.INTEGER};

        return template.update(deleteEmptyBusinessProgram, params, types);
    }

    //Produces warnings during compile time to quickly identify typos or API changes
    @Override
    public Collection<Integer> getNumberOfTerminatedMembers(Integer pProgramID) {
        final ArrayList<Integer> lNumberOfMembers = new ArrayList<Integer>();
        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{pProgramID};
        int types[] = new int[]{Types.INTEGER};

        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectNumberOfMembers);
        lQuery.append(" AND (participation_end_dt IS NOT NULL AND participation_end_dt <= SYSDATE)");

        template.query(lQuery.toString(), params, types, new RowCallbackHandler() {
            public void processRow(ResultSet rs) throws SQLException {
                Integer lMemberCount = Integer.valueOf(rs.getInt("number_of_members"));

                lNumberOfMembers.add(lMemberCount);
            }
        });

        return lNumberOfMembers;
    }

    /**
     * Returns a BusinessProgramTO object representing the Business Program specified by the
     * qualification start date, and group number returning only ACTIVE minus WITHDRAWN biz programs
     *
     * @param pTargetQualificationDate
     * @param pGroupNo
     * @return ArrayList of BusinessPrograms
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Override
    public Collection<BusinessProgram> getBusinessProgramsActive(
            Date pTargetQualificationDate,
            String pGroupNo,
            String pSiteNo) {
        final ArrayList<BusinessProgram> lBusinessPrograms;

        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectBusinessProgramsActive);

        ArrayList<Object> lParameters = new ArrayList<Object>();
        ArrayList<Integer> lTypes = new ArrayList<Integer>();

        if (pTargetQualificationDate != null) {
            lParameters.add(pTargetQualificationDate);
            lTypes.add(Integer.valueOf(Types.DATE));
            lQuery.append(" AND QUALFCTN_START_DT = ? ");
        }

        // Group Number
        if (pGroupNo != null && pGroupNo.length() > 0 && Integer.valueOf(pGroupNo) > 0) {
            lParameters.add(pGroupNo);
            lTypes.add(Integer.valueOf(Types.CHAR));
            lQuery.append(" AND EMPL_GRP_NO = ? ");
        }


        if (pSiteNo != null && pSiteNo.length() > 0) {
            lParameters.add(pSiteNo);
            lTypes.add(Integer.valueOf(Types.CHAR));
            lQuery.append(" AND EMPL_GRP_SITE_ID_NO = ? ");
        }

        // Convert the parameter and types ArrayLists to arrays of primitive types.
        Object params[] = new Object[lParameters.size()];
        lParameters.toArray(params);

        int types[] = new int[lTypes.size()];
        for (int j = 0; j < lTypes.size(); j++) {
            types[j] = ((Integer) lTypes.get(j)).intValue();
        }

        //lQuery.append(" ORDER BY QUALFCTN_START_DT desc, EMPL_GRP_NO, EMPL_GRP_SITE_ID_NO ");
        lQuery.append(" ORDER BY PROGRAM_STATUS_VAL asc, QUALFCTN_START_DT desc, EMPL_GRP_NO, EMPL_GRP_SITE_ID_NO asc ");

        JdbcTemplate template = getJdbcTemplate();

        lBusinessPrograms = (ArrayList<BusinessProgram>)
                template.query(lQuery.toString(), params, types, new BusinessProgramRowMapper());

        return lBusinessPrograms;
    }

    /**
     * @param pProgramID
     * @return
     */
    @Override
    public int updateAllGroupSiteMembers(Integer pProcessID, Integer pProgramID) {
        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{pProcessID, pProgramID};
        int types[] = new int[]{Types.INTEGER, Types.INTEGER};

        return template.update(markGroupSiteForUpdate, params, types);
    }

    /**
     * Fetch all the Business Program Templates.
     *
     * @return
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Override
    public Collection<BusinessProgram> getProgramTemplates(Integer pProgramID)
    {
        final ArrayList<BusinessProgram> lBusinessPrograms;

        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectProgramTemplates);

        ArrayList<Object> lParameters = new ArrayList<Object>();
        ArrayList<Integer> lTypes = new ArrayList<Integer>();

        if(pProgramID != null)
        {
            lParameters.add(pProgramID);
            lTypes.add(Integer.valueOf(Types.INTEGER));
            lQuery.append(" AND BIZ.biz_pgm_id = ? ");
        }

        lQuery.append(" ORDER BY prog_type.biz_pgm_nm, biz.biz_pgm_id ");

        // Convert the parameter and types ArrayLists to arrays of primitive types.
        Object params[] = new Object[lParameters.size()];
        lParameters.toArray(params);

        int types[] = new int[lTypes.size()];
        for(int j = 0; j < lTypes.size(); j++)
        {
            types[j] = ((Integer)lTypes.get(j)).intValue();
        }

        JdbcTemplate template = getJdbcTemplate();

        lBusinessPrograms = (ArrayList<BusinessProgram>)
                template.query(lQuery.toString(), params, types, new BusinessProgramRowMapper());

        return lBusinessPrograms;
    }

    /**
     * @param pProgramID
     * @return
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Override
    public Collection<BenefitPackage> getBenefitPackages(Integer pProgramID) {
        final ArrayList<BenefitPackage> lBenefitPackages = new ArrayList<BenefitPackage>();

        Object params[] = new Object[]{pProgramID};
        int types[] = new int[]{Types.INTEGER};

        StringBuffer lQuery = new StringBuffer();

        JdbcTemplate template = getJdbcTemplate();

        lQuery.append(selectProgramPackages);

        template.query(lQuery.toString(), params, types, new RowCallbackHandler() {
            public void processRow(ResultSet rs) throws SQLException {
                BenefitPackage lBenefitPackage = new BenefitPackage();

                lBenefitPackage.setProgramID(rs.getInt("BIZ_PGM_ID"));
                lBenefitPackage.setGroupID(rs.getInt("GRP_ID"));
                lBenefitPackage.setSubGroupID(rs.getInt("SUBGRP_ID"));
                lBenefitPackage.setPackageID(rs.getInt("BEN_PKG_ID"));
                lBenefitPackage.setPackageCode(rs.getString("BEN_PKG_CD"));
                lBenefitPackage.setPackageName(rs.getString("BEN_PKG_NM"));

                lBenefitPackage.setBenefitPackageType(rs.getString("BEN_PKG_TP"));
                lBenefitPackage.setInsuredTypeName(rs.getString("INSURED_TP_NM"));

                lBenefitPackage.setEffectiveDate(rs.getDate("EFF_DT"));
                lBenefitPackage.setEndDate(rs.getDate("END_DT"));
                lBenefitPackage.setPurchaserSubTypeName(rs.getString("PURCH_SUB_TP_NM"));
                lBenefitPackage.setPurchaserSubTypeCodeID(rs.getInt("PURCH_SUB_TP_CD_ID"));
                lBenefitPackage.setPurchaserSubTypeCode(rs.getString("PURCH_SUB_TP_CD"));

                if (rs.getDate("EFF_DT") != null) {
                    lBenefitPackage.setEffectiveDateString(BPMAdminUtils.formatDateMMddyyyy(rs.getDate("EFF_DT")));
                }

                if (rs.getDate("END_DT") != null) {
                    lBenefitPackage.setEndDateString(BPMAdminUtils.formatDateMMddyyyy(rs.getDate("END_DT")));
                }

                lBenefitPackage.setDescription(rs.getString("PKG_BASELINE_DESC"));

                lBenefitPackages.add(lBenefitPackage);
            }
        });

        return lBenefitPackages;
    }

    /**
     * @param pProgramID
     * @return
     * @throws DataAccessException
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Override
    public Collection<ProgramChangeLog> getBusinessProgramChangeLog(Integer pProgramID) throws DataAccessException {
        final ArrayList<ProgramChangeLog> lProgramChangeLogs = new ArrayList<ProgramChangeLog>();
        Object params[] = new Object[]{pProgramID};
        int types[] = new int[]{Types.INTEGER};

        StringBuffer lQuery = new StringBuffer();

        JdbcTemplate template = getJdbcTemplate();

        lQuery.append(selectBusinessProgramChangeLog);

        template.query(lQuery.toString(), params, types, new RowCallbackHandler() {
            public void processRow(ResultSet rs) throws SQLException {
                ProgramChangeLog lProgramChangeLog = new ProgramChangeLog();

                lProgramChangeLog.setChangeText(rs.getString("change_text"));
                lProgramChangeLog.setInsertUserID(rs.getString("insert_user"));
                lProgramChangeLog.setInsertDate(rs.getDate("insert_ts"));

                lProgramChangeLogs.add(lProgramChangeLog);
            }
        });

        return lProgramChangeLogs;
    }

    /**
     * Retrieve Business Programs by Group ID and Subgroup ID.
     *
     * @param pGroupID
     * @param pSubgroupID
     * @return
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Override
    public Collection<BusinessProgram> getBusinessPrograms(Integer pGroupID, Integer pSubgroupID) {
        final ArrayList<BusinessProgram> lBusinessPrograms;

        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectBusinessPrograms);

        ArrayList<Object> lParameters = new ArrayList<Object>();
        ArrayList<Integer> lTypes = new ArrayList<Integer>();


        lQuery.append(" AND sysdate between biz.eff_dt and biz.pgm_end_dt");

        lParameters.add(pGroupID);
        lTypes.add(Integer.valueOf(Types.INTEGER));
        lQuery.append(" AND biz.GRP_ID = ? ");

        lParameters.add(pSubgroupID);
        lTypes.add(Integer.valueOf(Types.INTEGER));
        lQuery.append(" AND biz.SUBGRP_ID = ? ");

        Object params[] = new Object[lParameters.size()];
        lParameters.toArray(params);

        int types[] = new int[lTypes.size()];
        for (int j = 0; j < lTypes.size(); j++) {
            types[j] = ((Integer) lTypes.get(j)).intValue();
        }

        JdbcTemplate template = getJdbcTemplate();

        lBusinessPrograms = (ArrayList<BusinessProgram>)
                template.query(lQuery.toString(), params, types, new BusinessProgramRowMapper());

        return lBusinessPrograms;
    }

    /**
     * Retrieve Business Programs by Qualification Date, Group ID, and Subgroup ID.
     *
     * @param pEffectiveDate
     * @param pGroupID
     * @param pSubgroupID
     * @return
     */
    @Override
    public Collection<BusinessProgram> getBusinessPrograms(Date pEffectiveDate, Integer pGroupID, Integer pSubgroupID) {
        final ArrayList<BusinessProgram> lBusinessPrograms;

        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectBusinessPrograms);

        ArrayList<Object> lParameters = new ArrayList<Object>();
        ArrayList<Integer> lTypes = new ArrayList<Integer>();

        lParameters.add(pEffectiveDate);
        lTypes.add(Integer.valueOf(Types.DATE));
        lQuery.append(" AND biz.eff_dt = ? ");

        lParameters.add(pGroupID);
        lTypes.add(Integer.valueOf(Types.INTEGER));
        lQuery.append(" AND biz.GRP_ID = ? ");

        if (pSubgroupID != null) {
            lParameters.add(pSubgroupID);
            lTypes.add(Integer.valueOf(Types.INTEGER));
            lQuery.append(" AND biz.SUBGRP_ID = ? ");
        }

        Object params[] = new Object[lParameters.size()];
        lParameters.toArray(params);

        int types[] = new int[lTypes.size()];
        for (int j = 0; j < lTypes.size(); j++) {
            types[j] = ((Integer) lTypes.get(j)).intValue();
        }

        JdbcTemplate template = getJdbcTemplate();

        lBusinessPrograms = (ArrayList<BusinessProgram>)
                template.query(lQuery.toString(), params, types, new BusinessProgramRowMapper());

        return lBusinessPrograms;
    }

    /**
     * @param pBusinessProgramID
     * @return
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Override
    public Collection<EmployerGroup> getBusinessProgramInSameYear(Integer pBusinessProgramID) {
        final ArrayList<EmployerGroup> lGroups = new ArrayList<EmployerGroup>();
        Object params[] = new Object[]{pBusinessProgramID};
        int types[] = new int[]{Types.INTEGER};

        final Integer lBusinessProgramID = pBusinessProgramID;

        JdbcTemplate template = getJdbcTemplate();

        template.query(selectBusinessProgramInSameYear, params, types, new RowCallbackHandler() {
            public void processRow(ResultSet rs) throws SQLException {
                EmployerGroup lEmployerGroup = new EmployerGroup();

                lEmployerGroup.setProgramID(rs.getInt("biz_pgm_id"));
                lEmployerGroup.setGroupID(rs.getInt("grp_id"));

                lEmployerGroup.setSubgroupID(rs.getInt("subgrp_id"));
                lEmployerGroup.setSiteName(rs.getString("subgrp_nm"));
                lEmployerGroup.setSiteNumber(rs.getString("site_id_no"));
                lEmployerGroup.setGroupNumber(rs.getString("grp_no"));
                lEmployerGroup.setGroupName(rs.getString("grp_nm"));
                lEmployerGroup.setQualificationStartDate(rs.getDate("qualfctn_start_dt"));
                lEmployerGroup.setBusinessProgramName(rs.getString("biz_pgm_nm"));

                lGroups.add(lEmployerGroup);
            }
        });

        return lGroups;
    }

    @Override
    public int updatePackageID(BusinessProgram pBusinessProgram, String lUserID) {
        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{
                pBusinessProgram.getPackageID(),
                lUserID,
                pBusinessProgram.getProgramID()};

        int types[] = new int[]{Types.INTEGER,
                Types.VARCHAR,
                Types.INTEGER};

        return template.update(updatePackageID, params, types);
    }

    @Override
    public int insertProgramChangeLog(ProgramChangeLog pProgramChangeLog, String pUserID) throws DataAccessException {
        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]
                {
                        programChangeLogIDIncrementer.nextIntValue()
                        , pProgramChangeLog.getProgramID()
                        , pProgramChangeLog.getChangeText()
                        , pUserID
                };

        int types[] = new int[] {
                Types.INTEGER, Types.INTEGER, Types.VARCHAR, Types.VARCHAR
        };

        return template.update(insertBusinessProgramChangeLog, params, types);
    }

    @Override
    public Collection<EmployerGroup> getAllBPMGroups() {
        final ArrayList<EmployerGroup> lGroups = new ArrayList<EmployerGroup>();
        Object params[] = new Object[0];
        int types[] = new int[0];

        JdbcTemplate template = getJdbcTemplate();

        template.query(selectAllBPMGroups, new RowCallbackHandler() {
            public void processRow(ResultSet rs) throws SQLException {
                EmployerGroup lEmployerGroup = new EmployerGroup();

                lEmployerGroup.setGroupID(rs.getInt("grp_id"));
                lEmployerGroup.setGroupNumber(rs.getString("grp_no"));
                lEmployerGroup.setGroupName(rs.getString("grp_nm"));

                lGroups.add(lEmployerGroup);
            }
        });

        return lGroups;
    }

    /**
     * Retrieves all the Employer Groups in BPM.
     * @return
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Override
    public Collection<EmployerGroup> getBPMGroupsForMemberAndTransactionDate(String memberId, Date transactionDate)
    {
        final ArrayList<EmployerGroup> lGroups = new ArrayList<EmployerGroup>();
        final ArrayList<Activity> lActivities = new ArrayList<Activity>();

        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectBPMGroupByMemberIdAndTransactionDate);
        lQuery.append(" and demo.hp_mem_id = ?");
        lQuery.append(" and biz.stat_calc_end_dt >= ?");
        lQuery.append(" ORDER BY empl_grp_nm");


        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[] { memberId, transactionDate };
        ArrayList<Integer> lTypes = new ArrayList<Integer>();
        lTypes.add(new Integer(Types.VARCHAR));
        lTypes.add(new Integer(Types.DATE));

        int types[] = new int[lTypes.size()];
        for(int j = 0; j < lTypes.size(); j++)
        {
            types[j] = ((Integer)lTypes.get(j)).intValue();
        }

        template.query(lQuery.toString(), params, types, new RowCallbackHandler() {
            public void processRow(ResultSet rs) throws SQLException {
                EmployerGroup lEmployerGroup = new EmployerGroup();

                lEmployerGroup.setGroupID(rs.getInt("grp_id"));
                lEmployerGroup.setGroupNumber(rs.getString("grp_no"));
                lEmployerGroup.setGroupName(rs.getString("grp_nm"));

                lGroups.add(lEmployerGroup);
            }
        });

        return lGroups;
    }
}