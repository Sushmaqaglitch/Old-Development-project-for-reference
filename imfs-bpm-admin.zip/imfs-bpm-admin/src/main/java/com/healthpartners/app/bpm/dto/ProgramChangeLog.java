package com.healthpartners.app.bpm.dto;

import java.io.Serializable;

public class ProgramChangeLog implements Serializable {
    static final long serialVersionUID = 0L;

    private Integer programID;
    private String changeText;
    private String insertUserID;
    private java.sql.Date insertDate;

    public ProgramChangeLog() {
        super();
    }

    public Integer getProgramID() {
        return programID;
    }

    public void setProgramID(Integer programID) {
        this.programID = programID;
    }

    public String getChangeText() {
        return changeText;
    }

    public void setChangeText(String changeText) {
        this.changeText = changeText;
    }

    public String getInsertUserID() {
        return insertUserID;
    }

    public void setInsertUserID(String insertUserID) {
        this.insertUserID = insertUserID;
    }

    public java.sql.Date getInsertDate() {
        return insertDate;
    }

    public void setInsertDate(java.sql.Date insertDate) {
        this.insertDate = insertDate;
    }


}
