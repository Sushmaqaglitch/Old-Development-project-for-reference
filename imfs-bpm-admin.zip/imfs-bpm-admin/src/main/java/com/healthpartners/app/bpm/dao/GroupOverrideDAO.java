package com.healthpartners.app.bpm.dao;

import com.healthpartners.app.bpm.dto.GroupOverride;
import org.springframework.dao.DataAccessException;

import java.util.ArrayList;
import java.util.Collection;


public interface GroupOverrideDAO {

    int updateGroupOverride(GroupOverride lGroupOverride) throws DataAccessException;

    int deleteGroupOverride(Integer groupOverrideID) throws DataAccessException;

    GroupOverride getGroupOverride(int groupOverrideID);

    Collection<GroupOverride> getGroupOverrides();

    ArrayList<GroupOverride> getGroupOverrideByGroupNumber(String groupNumber);

    ArrayList<GroupOverride> getGroupOverrideByGroupID(Integer groupID);

    ArrayList<GroupOverride> getAssignedSitesForGroupSiteException(String groupNumber);

    ArrayList<GroupOverride> getAvailableSitesForGroupSiteException(String groupNumber);

}
