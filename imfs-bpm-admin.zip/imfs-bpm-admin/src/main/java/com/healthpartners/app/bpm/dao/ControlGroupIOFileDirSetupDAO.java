package com.healthpartners.app.bpm.dao;

import com.healthpartners.app.bpm.dto.ControlGroupIOFileDirSetup;
import org.springframework.dao.DataAccessException;

import java.util.Collection;


public interface ControlGroupIOFileDirSetupDAO {
    Collection<ControlGroupIOFileDirSetup> getControlGroupsIOFileDirSetup(Integer routingTypeID) throws DataAccessException;
}
