package com.healthpartners.app.bpm.dto;

import com.healthpartners.app.bpm.common.BPMAdminUtils;
import com.healthpartners.service.bpm.dto.BaseDTO;

import java.sql.Date;

/**
 * 
 * @author f5929
 *
 */
public class RejectedPerson extends BaseDTO 
{
	
	static final long serialVersionUID = 0L;
	
	private Integer rowNumber = null;
	private Integer employerRecycleID = null;
	private String firstName = null;
	private String middleName = null;
	private String lastName = null;
	private Integer contributionAmount = null;
	private Date dateOfBirth = null;
	private String dateOfBirthFormatted = null;
	private String gender = null;
	private Integer recycleStatusCodeID = null;
	private String recycleStatusCode = null;
	private Date recycleStatusDate = null;
	private String reasonDesc = null;
	private String approverUserID = null;
	private Integer personDemographicsID = null;
	private String memberNo = null;
	private Integer activityID = null;
	private String sourceActivityID = null;
	private String activityName = null;
	private Date activityDate = null;
	private String groupNo = null;
	private String siteNo = null;
	private Date programEffDate = null;
	private String programEffDateFormatted = null;
	private String externalEmployerPersonId;
	
	
	
	
	public Integer getRowNumber() {
		return rowNumber;
	}
	public void setRowNumber(Integer rowNumber) {
		this.rowNumber = rowNumber;
	}
	public final Integer getEmployerRecycleID() {
		return employerRecycleID;
	}
	public final void setEmployerRecycleID(Integer employerRecycleID) {
		this.employerRecycleID = employerRecycleID;
	}
	public final String getFirstName() {
		return firstName;
	}
	public final void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public final String getMiddleName() {
		return middleName;
	}
	public final void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	public final String getLastName() {
		return lastName;
	}
	public final void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	
	
	public Integer getContributionAmount() {
		return contributionAmount;
	}
	public void setContributionAmount(Integer contributionAmount) {
		this.contributionAmount = contributionAmount;
	}
	public final Date getDateOfBirth() {
		return dateOfBirth;
	}
	public final void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	
	public String getDateOfBirthFormatted() {
		dateOfBirthFormatted = BPMAdminUtils.getStringDateFromSqlDate(this.dateOfBirth);
		return dateOfBirthFormatted;
	}
	public final String getGender() {
		return gender;
	}
	public final void setGender(String gender) {
		this.gender = gender;
	}
	public final Integer getRecycleStatusCodeID() {
		return recycleStatusCodeID;
	}
	public final void setRecycleStatusCodeID(Integer recycleStatusCodeID) {
		this.recycleStatusCodeID = recycleStatusCodeID;
	}
	public final String getRecycleStatusCode() {
		return recycleStatusCode;
	}
	public final void setRecycleStatusCode(String recycleStatusCode) {
		this.recycleStatusCode = recycleStatusCode;
	}
	public final Date getRecycleStatusDate() {
		return recycleStatusDate;
	}
	public final void setRecycleStatusDate(Date recycleStatusDate) {
		this.recycleStatusDate = recycleStatusDate;
	}
	public final String getReasonDesc() {
		return reasonDesc;
	}
	public final void setReasonDesc(String reasonDesc) {
		this.reasonDesc = reasonDesc;
	}
	public final String getApproverUserID() {
		return approverUserID;
	}
	public final void setApproverUserID(String approverUserID) {
		this.approverUserID = approverUserID;
	}
	public final Integer getPersonDemographicsID() {
		return personDemographicsID;
	}
	public final void setPersonDemographicsID(Integer personDemographicsID) {
		this.personDemographicsID = personDemographicsID;
	}
	
	public String getMemberNo() {
		return memberNo;
	}
	public void setMemberNo(String memberNo) {
		this.memberNo = memberNo;
	}
	public final Integer getActivityID() {
		return activityID;
	}
	public final void setActivityID(Integer activityID) {
		this.activityID = activityID;
	}
	
	
	public String getActivityName() {
		return activityName;
	}
	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}
	public final Date getActivityDate() {
		return activityDate;
	}
	public final void setActivityDate(Date activityDate) {
		this.activityDate = activityDate;
	}
	public String getSourceActivityID() {
		return sourceActivityID;
	}
	public void setSourceActivityID(String sourceActivityID) {
		this.sourceActivityID = sourceActivityID;
	}
	public String getGroupNo() {
		return groupNo;
	}
	public void setGroupNo(String groupNo) {
		this.groupNo = groupNo;
	}
	public String getSiteNo() {
		return siteNo;
	}
	public void setSiteNo(String siteNo) {
		this.siteNo = siteNo;
	}
	
	
	public Date getProgramEffDate() {
		return programEffDate;
	}
	public void setProgramEffDate(Date programEffDate) {
		this.programEffDate = programEffDate;
	}
	public String getProgramEffDateFormatted() {
		programEffDateFormatted = BPMAdminUtils.getStringDateFromSqlDate(this.programEffDate);
		return programEffDateFormatted;
	}
	
	public String getExternalEmployerPersonId() {
		return externalEmployerPersonId;
	}
	public void setExternalEmployerPersonId(String externalEmployerPersonId) {
		this.externalEmployerPersonId = externalEmployerPersonId;
	}
	public void setProgramEffDateFormatted(String programEffDateFormatted) {
		this.programEffDateFormatted = programEffDateFormatted;
	}
	
    
	
}
