package com.healthpartners.app.bpm.service;

import com.healthpartners.app.bpm.dto.GroupOverride;
import org.springframework.dao.DataAccessException;

import java.util.ArrayList;

public interface GroupSiteExceptionService {
    GroupOverride getGroupOverride(int groupOverrideID);

    ArrayList<GroupOverride> getGroupOverrideByGroupID(Integer groupID);

    int deleteGroupOverride(Integer groupOverrideID) throws DataAccessException;

    int updateGroupOverride(GroupOverride groupSiteException);

    ArrayList<GroupOverride> getGroupOverrideByGroupNumber(String groupNumber);
}
