package com.healthpartners.app.bpm.dao;

import com.healthpartners.app.bpm.dto.Risk;
import org.springframework.dao.DataAccessException;

import java.util.Collection;

/**
 * Retrieves instances of <code>Risk</code> from the
 * <code>Risk</code> table.
 * 
 * @author tjquist
 */
public interface RiskDAO {

		
	/**
	 * Retrieves Risk codes.
	 * 
	 * @return Collection of <code>Risk</code> objects
	 * @throws DataAccessException
	 *             when a database-related error is encountered
	 */
	Collection<Risk> getAllRisks() throws DataAccessException;
	
	/**
	 * Retrieves a Risk record using the specified value code.
	 * 
	 * @param value
	 *            specifies the value code
	 * @return <code>Risk</code> object, or null if not found
	 * @throws DataAccessException
	 *             when a database-related error is encountered
	 */
	Risk getRiskByName(String value) throws DataAccessException;
	
	/**
	 * Retrieves a Risk record using the specified value code.
	 * 
	 * @param id
	 *            specifies the value code
	 * @return <code>Risk</code> object, or null if not found
	 * @throws DataAccessException
	 *             when a database-related error is encountered
	 */
	Risk getRiskById(Integer id) throws DataAccessException;
	
	/**
	 * Retrieves a Risk record using the specified group code.
	 * 
	 * @param group
	 *            specifies the group code
	 * @return <code>Risk</code> object, or null if not found
	 * @throws DataAccessException
	 *             when a database-related error is encountered
	 */
	Risk getRiskByGroupName(String group) throws DataAccessException;
	
	int updateRisk(Risk lRisk) throws DataAccessException;

	int deleteRisk(Integer RiskID) throws DataAccessException;
	
	int insertRisk(Risk lRisk) throws DataAccessException;

}
