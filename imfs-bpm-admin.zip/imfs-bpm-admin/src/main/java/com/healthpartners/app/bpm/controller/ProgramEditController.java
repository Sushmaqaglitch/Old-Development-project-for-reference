package com.healthpartners.app.bpm.controller;

import com.healthpartners.app.bpm.common.BPMAdminConstants;
import com.healthpartners.app.bpm.common.BPMAdminUtils;
import com.healthpartners.app.bpm.dto.*;
import com.healthpartners.app.bpm.exception.BPMException;
import com.healthpartners.app.bpm.form.*;
import com.healthpartners.app.bpm.iface.BusinessProgramService;
import com.healthpartners.app.bpm.iface.MemberService;
import com.healthpartners.app.bpm.iface.RewardCardService;
import com.healthpartners.app.bpm.service.ProgramValidationService;
import com.healthpartners.service.bpm.common.BPMConstants;
import jakarta.servlet.http.HttpServletRequest;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.view.RedirectView;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import static org.apache.commons.lang.exception.ExceptionUtils.getStackTrace;

@Controller
public class ProgramEditController extends BaseController implements Validator {
    private SimpleDateFormat fmt = new SimpleDateFormat(BPMAdminConstants.HP_BPM_ADMIN_UI_COMMON_DATE_FORMAT);
    private final BusinessProgramService businessProgramService;
    private final RewardCardService rewardCardService;

    private final MemberService memberService;
    private final ProgramValidationService programValidationService;

    protected final Log logger = LogFactory.getLog(getClass());

    public ProgramEditController(BusinessProgramService businessProgramService, RewardCardService rewardCardService, MemberService memberService, ProgramValidationService programValidationService) {
        this.businessProgramService = businessProgramService;
        this.rewardCardService = rewardCardService;
        this.memberService = memberService;
        this.programValidationService = programValidationService;
    }

    @PostMapping(value="/editProgram", params="cancelViewProgram")
    public RedirectView submitCopyToYearCancel(@ModelAttribute("editProgramForm") EditProgramForm form, RedirectAttributes ra) throws Exception {
        ra.addFlashAttribute("groupNumber", form.getGroupNo());
        return new RedirectView("programSearch");
    }

    @PostMapping(value="/editProgram", params="edit")
    public String editProgram(@ModelAttribute("editProgramForm") EditProgramForm form, ModelMap modelMap) throws Exception {
        try {
            Integer programId = form.getProgramID();
            BusinessProgram businessProgram = getUserSession().getBusinessProgram();
            // Boolean indicates all programs and not just ACTIVEs.
            // Just retrieve ACTIVEs.
            if (businessProgram == null) {
                businessProgram = businessProgramService.getBusinessProgram(programId, false);
            }
            ProgramType programType = businessProgramService.getProgramTypeByTypeID(businessProgram.getProgramTypeCodeID());
            ArrayList<LookUpValueCode> lProgramSpecialReportHandlingCodes = (ArrayList<LookUpValueCode>) businessProgramService.getProgramSpecialReportHandlingCodes();
            assignDefaultReportIndicator(businessProgram, programType, lProgramSpecialReportHandlingCodes);
            populateUserSessionAndRequest(businessProgram, lProgramSpecialReportHandlingCodes, modelMap);
            SaveProgramForm saveProgramForm = populateSaveProgramForm(businessProgram);
            modelMap.put("saveProgramForm", saveProgramForm);
        } catch (Exception e) {
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
            // Add error stack trace on the request, to be hidden in html.
            createErrorMessageOnModel(modelMap, getStackTrace(e));
        }
        return "editProgram";
    }

    @PostMapping(value="/editProgram", params="editActivities")
    public String editProgramActivities(@ModelAttribute("editProgramForm") EditProgramForm form, ModelMap modelMap) throws Exception {
        try {
            addViewProgramActivities(form, modelMap);
        } catch (Exception e) {
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
            createErrorMessageOnModel(modelMap, getStackTrace(e));
        }
        return "programActivities";
    }

    @PostMapping(value="/editProgram", params="editIncentives")
    public String editProgramIncentiveOptions(@ModelAttribute("editProgramForm") EditProgramForm form, ModelMap modelMap) throws Exception {
        try {
            addEditProgramIncentiveOptions(form, modelMap);
        } catch (Exception e) {
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
            createErrorMessageOnModel(modelMap, getStackTrace(e));
        }
        return "programIncentives";
    }

    @GetMapping(value="/editProgram")
    public String loadEditProgramChildView(@ModelAttribute("editProgramForm") EditProgramForm form, ModelMap modelMap) throws Exception {
        try {
            if ("editIncentives".equals(modelMap.getAttribute("actionType")) || "editIncentives".equals(form.getActionType())) {
                if (form.getProgramID() == null) {
                    form.setProgramID(getUserSession().getProgramID());
                }
                addEditProgramIncentiveOptions(form, modelMap);
            }
        } catch (Exception e) {
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
            createErrorMessageOnModel(modelMap, getStackTrace(e));
        }
        return "programIncentives";
    }

    @PostMapping(value="/editProgram", params="editCheckmarks")
    public String editProgramCheckmarks(@ModelAttribute("editProgramForm") EditProgramForm form, ModelMap modelMap) throws Exception {
        try {
            addEditProgramCheckmarks(form, modelMap);
        } catch (Exception e) {
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
            createErrorMessageOnModel(modelMap, getStackTrace(e));
        }
        return "programCheckmarks";
    }

    @PostMapping(value="/editProgram", params="editAdditionalInfo")
    public String editAdditionInfo(@ModelAttribute("editProgramForm") EditProgramForm form, ModelMap modelMap, HttpServletRequest request) throws Exception {
        try {
            addEditAdditionalInfo(form, modelMap);
        } catch (Exception e) {
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
            createErrorMessageOnModel(modelMap, getStackTrace(e));
        }
        return "programAdditionalInfos";
    }

    @PostMapping(value="/editProgram", params="editExtendedAuthCodes")
    public String editExtendedAuthCodes(@ModelAttribute("editProgramForm") EditProgramForm form, ModelMap modelMap, HttpServletRequest request) throws Exception {
        try {
            addExtendedAuthCodes(form, modelMap);
        } catch (Exception e) {
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
            createErrorMessageOnModel(modelMap, getStackTrace(e));
        }
        return "extendedAuthCodes";
    }

    @PostMapping(value="/editProgram", params="editChangeLog")
    public String editChangeLog(@ModelAttribute("editProgramForm") EditProgramForm form, ModelMap modelMap, HttpServletRequest request) throws Exception {
        try {
            addChangeLog(form, modelMap);
        } catch (Exception e) {
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
            createErrorMessageOnModel(modelMap, getStackTrace(e));
        }
        return "programChangeLog";
    }

    private void addViewProgramActivities(EditProgramForm form, ModelMap modelMap) throws Exception {
        Integer programId = form.getProgramID();
        BusinessProgram businessProgram = getUserSession().getBusinessProgram();
        if(businessProgram == null) {
            businessProgram = businessProgramService.getBusinessProgram(programId, false);
        }
        findAvailablePackage(modelMap);
        SaveProgramActivityForm saveProgramActivityForm = new SaveProgramActivityForm();
        // The primitive array for HTML select needs to be pre-populated in order to work properly with Spring MVC errors, otherwise upon POST action, form values are lost/reset
        populateSaveFormIncentiveOverrideCodeTypes(saveProgramActivityForm);
        modelMap.put("saveProgramActivityForm", saveProgramActivityForm);
        modelMap.put("businessProgram", businessProgram);

        if (CollectionUtils.isEmpty(getUserSession().getEligibleActivities())) {
            ArrayList<EligibleActivity> eligibleActivities = (ArrayList<EligibleActivity>) businessProgramService.getEligibleActivities(programId);
            getUserSession().setEligibleActivities(eligibleActivities);
        }
        modelMap.put("eligibleActivities", getUserSession().getEligibleActivities());

        if (CollectionUtils.isEmpty(getUserSession().getAvailableActivities())) {
            ArrayList<Activity> availableActivities = (ArrayList<Activity>) businessProgramService.getAvailableActivities(programId);
            getUserSession().setAvailableActivities(availableActivities);
        }
        modelMap.put("availableActivities", getUserSession().getAvailableActivities());

        if (CollectionUtils.isEmpty(getUserSession().getIncentiveOverrideCodeTypes())) {
            ArrayList<LookUpValueCode> luvIncentiveOverrideCodeTypes = (ArrayList<LookUpValueCode>) businessProgramService.getIncentiveOverrideCodeTypes();
            getUserSession().setIncentiveOverrideCodeTypes(luvIncentiveOverrideCodeTypes);
        }

        modelMap.put("luvIncentiveOverrideCodeTypes", getUserSession().getIncentiveOverrideCodeTypes());
        modelMap.put("membershipProcessFlag", businessProgram.getMembershipProcessFlag());
    }

    private void populateSaveFormIncentiveOverrideCodeTypes(SaveProgramActivityForm saveProgramActivityForm) {
        List<EligibleActivity> activities = getUserSession().getEligibleActivities();
        String[] incentiveOverrideCodeTypes =
                activities
                        .stream()
                        .map(activity -> activity.getIncentiveOverrideCodeID().toString())
                        .toArray(String[] :: new);
        saveProgramActivityForm.setIncentiveOverrideCodeIDs(incentiveOverrideCodeTypes);
    }

    private void addEditProgramIncentiveOptions(EditProgramForm form, ModelMap modelMap) throws Exception {
        Integer programId = form.getProgramID();
        BusinessProgram businessProgram = getUserSession().getBusinessProgram();
        if (businessProgram == null) {
            businessProgram = businessProgramService.getBusinessProgram(programId, false);
        }

        SaveProgramIncentiveForm saveProgramIncentiveForm = new SaveProgramIncentiveForm();
        modelMap.put("saveProgramIncentiveForm", saveProgramIncentiveForm);

        ArrayList<ProgramIncentiveOption> lProgramIncentiveOptions = (ArrayList<ProgramIncentiveOption>) businessProgramService.getProgramIncentiveOptions(businessProgram.getProgramID());
        ArrayList<IncentiveOption> lIncentiveOptions = (ArrayList<IncentiveOption>) businessProgramService.getIncentiveOptions();
        ArrayList<IncentiveOption> lIncentiveOptionsActive = (ArrayList<IncentiveOption>) businessProgramService.getActiveIncentiveOptions();
        ArrayList<LookUpValueCode> lIncentiveOptionStatuses = (ArrayList<LookUpValueCode>) businessProgramService.getIncentiveOptionStatusCodes();
        ArrayList<LookUpValueCode> lIncentiveFulfillTypes = (ArrayList<LookUpValueCode>) businessProgramService.getIncentiveFulfillTypeCodes();
        ArrayList<LookUpValueCode> lIncentiveReportNameTypes = (ArrayList<LookUpValueCode>) businessProgramService.getIncentiveReportNameCodeTypes();
        ArrayList<LookUpValueCode> lIncentedStatusCodes = (ArrayList<LookUpValueCode>) businessProgramService.getIncentiveStatusCodes();
        ArrayList<LookUpValueCode> lIncentiveEnrollmentRuleCodes = (ArrayList<LookUpValueCode>) businessProgramService.getIncentiveEnrollmentRuleCodes();
        ArrayList<ProgramActivityIncentiveSummary> lProgramActivityIncentivesSummary = (ArrayList<ProgramActivityIncentiveSummary>) businessProgramService.getProgramActivityIncentivesSummaryWithRequirements(businessProgram.getProgramID());
        ArrayList<IncentiveOptionRewardCard> incentiveOptionRewardCardTypes = (ArrayList<IncentiveOptionRewardCard>) rewardCardService.getIncentiveOptionRewardCardTypes();
        ArrayList<LookUpValueCode> luvBatchRunFrequencyTypes = (ArrayList<LookUpValueCode>) businessProgramService.getRewardRunFrequencyTypes();
        ArrayList<ProgramCheckmark> lProgramCheckmarks = businessProgramService.getProgramCheckmarks(businessProgram.getProgramID());

        for (ProgramCheckmark lProgramCheckmark : lProgramCheckmarks) {
            lProgramCheckmark.setCheckmarkRequirements((ArrayList<CheckmarkRequirement>) businessProgramService.getCheckmarkRequirements(lProgramCheckmark.getQualificationCheckmarkID()));
        }

        ArrayList<LookUpValueCode> unitCodeTypes = (ArrayList<LookUpValueCode>) memberService.getLUVCodesByGroup(BPMAdminConstants.BPM_LUV_INCENTIVE_OPTN_UNIT_TYPE);
        ArrayList<IncentivePackageRuleGroup> incentivePackageRuleGroups = (ArrayList<IncentivePackageRuleGroup>) businessProgramService.getIncentivePackageRuleGroups(businessProgram.getProgramID());
        ArrayList<LookUpValueCode> luvDeliveryInfoTypes = (ArrayList<LookUpValueCode>) businessProgramService.getDeliveryInfoTypes();
        ArrayList<ParticipationGroup> lParticipationGroups = (ArrayList<ParticipationGroup>) businessProgramService.getParticipationGroups();

        // Look at the Program Incentive Options. If an Incentive Option has been assigned to
        // the program already, remove it from the list of Available Incentive Options.
        for (int i = 0; i < lProgramIncentiveOptions.size(); i++) {
            ProgramIncentiveOption lProgramIncentiveOption = (ProgramIncentiveOption) lProgramIncentiveOptions.get(i);

            for (int j = 0; j < lIncentiveOptions.size(); j++) {
                IncentiveOption lIncentiveOption = (IncentiveOption) lIncentiveOptions.get(j);
                if (lIncentiveOption.getIncentiveOptionID().intValue() == lProgramIncentiveOption.getIncentiveOption().getIncentiveOptionID().intValue()) {
                    lIncentiveOptions.remove(j);
                }
            }

            if (lProgramIncentiveOption.getRunFrequencyID() == null || lProgramIncentiveOption.getRunFrequencyID() == 0) {
                lProgramIncentiveOption.setRunFrequencyID(Integer.valueOf("0"));
                lProgramIncentiveOption.setRunFrequencyValue("select");
            }
            if (lProgramIncentiveOption.getIncentiveOptionRewardCardID() == null || lProgramIncentiveOption.getIncentiveOptionRewardCardID() == 0) {
                lProgramIncentiveOption.setIncentiveOptionRewardCardID(Integer.valueOf("0"));
                lProgramIncentiveOption.setIncentiveOptionRewardCardName("select");
            }
            if (lProgramIncentiveOption.getIncentiveOptionRewardCard() == null) {
                IncentiveOptionRewardCard lIncentiveOptionRewardCard = new IncentiveOptionRewardCard();
                lIncentiveOptionRewardCard.setRewardCardID(0);
                lProgramIncentiveOption.setIncentiveOptionRewardCard(lIncentiveOptionRewardCard);
            }

            // Retrieve and set the Program Incentive Option Requirements.
            lProgramIncentiveOptions.get(i).setActivityIncentiveRequirements((ArrayList<ActivityIncentiveRequirement>)
                    businessProgramService.getProgramActivityIncentiveRequirements(lProgramIncentiveOptions.get(i).getBusinessProgramID()
                            , lProgramIncentiveOptions.get(i).getIncentiveOption().getIncentiveOptionID()));
        }

        populateSaveProgramIncentiveFormArrays(saveProgramIncentiveForm, lProgramIncentiveOptions);

        LookUpValueCode luvSendToMembership = memberService.getLUVCodeByGroupNValue(BPMConstants.BPM_GRP_FLFLMNT_RTNG_TP, BPMConstants.BPM_VAL_FLFLMNT_RTNG_TP_SND_TO_MBRSHP);
        String lLuvIdSendToMembership = Integer.toString(luvSendToMembership.getLuvId());

        LookUpValueCode luvSendToPremiumBilling = memberService.getLUVCodeByGroupNValue(BPMConstants.BPM_GRP_FLFLMNT_RTNG_TP, BPMConstants.BPM_VAL_FLFLMNT_RTNG_TP_SND_TO_MBPB);
        String lLuvIdSendToPremiumBilling = Integer.toString(luvSendToPremiumBilling.getLuvId());

        LookUpValueCode luvSendToIntelispend = memberService.getLUVCodeByGroupNValue(BPMConstants.BPM_GRP_FLFLMNT_RTNG_TP, BPMConstants.BPM_VAL_FLFLMNT_RTNG_TP_SND_TO_INTELISPEND);
        String lLuvSendToIntelispend = Integer.toString(luvSendToIntelispend.getLuvId());

        LookUpValueCode luvSendToCDHP = memberService.getLUVCodeByGroupNValue(BPMConstants.BPM_GRP_FLFLMNT_RTNG_TP, BPMConstants.BPM_VAL_FLFLMNT_RTNG_TP_SND_TO_CDHP);
        String lLuvSendToCDHP = Integer.toString(luvSendToCDHP.getLuvId());

        LookUpValueCode luvIdContractBased = memberService.getLUVCodeByGroupNValue(BPMConstants.BPM_INCENTED_STATUS_GROUP, BPMConstants.BPM_INCENTED_STATUS_TYPE_CONTRACT_BASED);
        String lLuvIdContractBased = Integer.toString(luvIdContractBased.getLuvId());

        LookUpValueCode luvIdMemberBased = memberService.getLUVCodeByGroupNValue(BPMConstants.BPM_INCENTED_STATUS_GROUP, BPMConstants.BPM_INCENTED_STATUS_TYPE_MEMBER_BASED);
        String lLuvIdMemberBased = Integer.toString(luvIdMemberBased.getLuvId());

        getUserSession().setLuvIdSendToMembership(lLuvIdSendToMembership);
        getUserSession().setLuvIdSendToPremiumBilling(lLuvIdSendToPremiumBilling);
        getUserSession().setLuvIdSendToIntelispend(lLuvSendToIntelispend);
        getUserSession().setLuvIdSendToCDHP(lLuvSendToCDHP);
        getUserSession().setLuvIdContractBased(lLuvIdContractBased);
        getUserSession().setLuvIdMemberBased(lLuvIdMemberBased);

        getUserSession().setBusinessProgram(businessProgram);
        getUserSession().setIncentiveOptions(lIncentiveOptions);
        getUserSession().setActiveIncentiveOptions(lIncentiveOptionsActive);
        getUserSession().setProgramIncentiveOptions(lProgramIncentiveOptions);
        getUserSession().setIncentiveOptionStatuses(lIncentiveOptionStatuses);
        getUserSession().setIncentiveFulfillTypes(lIncentiveFulfillTypes);
        getUserSession().setIncentiveReportNameTypes(lIncentiveReportNameTypes);
        getUserSession().setProgramActivityIncentivesSummary(lProgramActivityIncentivesSummary);
        getUserSession().setIncentedStatusCodes(lIncentedStatusCodes);
        getUserSession().setIncentiveEnrollmentRuleCodes(lIncentiveEnrollmentRuleCodes);
        getUserSession().setRewardRunFrequencyTypes(luvBatchRunFrequencyTypes);
        getUserSession().setIncentiveOptionRewardCardTypes(incentiveOptionRewardCardTypes);
        getUserSession().setProgramCheckmarks(lProgramCheckmarks);
        getUserSession().setUnitCodeTypes(unitCodeTypes);
        getUserSession().setIncentivePackageRuleGroups(incentivePackageRuleGroups);
        getUserSession().setDeliveryInfoTypes(luvDeliveryInfoTypes);
        getUserSession().setParticipationGroups(lParticipationGroups);

        modelMap.put("businessProgram", businessProgram);
        modelMap.put("incentiveOptions", lIncentiveOptionsActive);
        modelMap.put("programIncentiveOptions", lProgramIncentiveOptions);
        modelMap.put("incentiveStatuses", lIncentiveOptionStatuses);
        modelMap.put("incentiveFulfillTypes", lIncentiveFulfillTypes);
        modelMap.put("incentiveReportNameTypes", lIncentiveReportNameTypes);
        modelMap.put("programActivityIncentivesSummary", lProgramActivityIncentivesSummary);
        modelMap.put("incentedStatusCodes", lIncentedStatusCodes);
        modelMap.put("luvIdSendToMembership", getUserSession().getLuvIdSendToMembership());
        modelMap.put("luvIdSendToPremiumBilling", getUserSession().getLuvIdSendToPremiumBilling());
        modelMap.put("luvIdSendToIntelispend", getUserSession().getLuvIdSendToIntelispend());
        modelMap.put("luvIdSendToCDHP", getUserSession().getLuvIdSendToCDHP());
        modelMap.put("luvIdContractBased", getUserSession().getLuvIdContractBased());
        modelMap.put("luvIdMemberBased", getUserSession().getLuvIdMemberBased());
        modelMap.put("incentiveEnrollmentRuleCodes", lIncentiveEnrollmentRuleCodes);
        modelMap.put("luvBatchRunFrequencyTypes", luvBatchRunFrequencyTypes);
        modelMap.put("incentiveOptionRewardCardTypes", incentiveOptionRewardCardTypes);
        modelMap.put("programCheckmarks", lProgramCheckmarks);
        modelMap.put("unitCodeTypes", unitCodeTypes);
        modelMap.put("packageRuleGroups", incentivePackageRuleGroups);
        modelMap.put("luvDeliveryInfoTypes", getUserSession().getDeliveryInfoTypes());
        modelMap.put("participationGroups", getUserSession().getParticipationGroups());
    }

    private void populateSaveProgramIncentiveFormArrays(SaveProgramIncentiveForm saveProgramIncentiveForm, ArrayList<ProgramIncentiveOption> lProgramIncentiveOptions) {
        String[] incentiveOptionInfos = new String[lProgramIncentiveOptions.size()];
        String[] incentiveOptionAddInfos = new String[lProgramIncentiveOptions.size()];
        Integer[] deliveryInfoIDs = new Integer[lProgramIncentiveOptions.size()];
        Integer[] participationGroupIDs = new Integer[lProgramIncentiveOptions.size()];
        String[] programIncentiveOptionEffDates = new String[lProgramIncentiveOptions.size()];
        String[] programIncentiveOptionEnrolDeadlineDates = new String[lProgramIncentiveOptions.size()];
        String[] programIncentiveOptionComplDeadlineDates = new String[lProgramIncentiveOptions.size()];
        String[] programIncentiveOptionEndDates = new String[lProgramIncentiveOptions.size()];
        String[] programIncentiveOptionActDates = new String[lProgramIncentiveOptions.size()];
        String[] programIncentiveOptionDelDates = new String[lProgramIncentiveOptions.size()];
        String[] programIncentiveOptionSortOrders = new String[lProgramIncentiveOptions.size()];
        String[] closeDates = new String[lProgramIncentiveOptions.size()];
        String[] creationDates = new String[lProgramIncentiveOptions.size()];
        Integer[] programIncentiveOptionStatusIDs = new Integer[lProgramIncentiveOptions.size()];
        Integer[] incentiveRuleTypeCodeIDs = new Integer[lProgramIncentiveOptions.size()];
        Integer[] programIncentiveReportNameIDs = new Integer[lProgramIncentiveOptions.size()];
        Integer[] programIncentiveFulfillReqIDs = new Integer[lProgramIncentiveOptions.size()];
        Integer[] incentedStatusTypeCodeIDs = new Integer[lProgramIncentiveOptions.size()];
        Integer[] packageRuleGroupIDs = new Integer[lProgramIncentiveOptions.size()];
        Integer[] unitTypeCodeIDs = new Integer[lProgramIncentiveOptions.size()];
        String[] newHireDates = new String[lProgramIncentiveOptions.size()];
        Integer[] incentiveOptionRewardCardIDs = new Integer[lProgramIncentiveOptions.size()];
        Integer[] rewardRunFreqIDs = new Integer[lProgramIncentiveOptions.size()];
        String[] activityCompletionPeriods = new String[lProgramIncentiveOptions.size()];
        String[] familyCaps = new String[lProgramIncentiveOptions.size()];
        String[] participantCap = new String[lProgramIncentiveOptions.size()];

        int i = 0;
        for (ProgramIncentiveOption programIncentiveOption : lProgramIncentiveOptions) {
            incentiveOptionInfos[i] = programIncentiveOption.getIncentiveOptionInfo();
            incentiveOptionAddInfos[i] = programIncentiveOption.getAdditionalInfo();
            deliveryInfoIDs[i] = programIncentiveOption.getDeliveryInfoID();
            participationGroupIDs[i] = programIncentiveOption.getParticipationGroupID();
            programIncentiveOptionEffDates[i] = programIncentiveOption.getEffectiveDate() != null ? fmt.format(programIncentiveOption.getEffectiveDate()) : "";
            programIncentiveOptionEnrolDeadlineDates[i] = programIncentiveOption.getEnrollmentDeadlineDate() != null ? fmt.format(programIncentiveOption.getEnrollmentDeadlineDate()) : "";
            programIncentiveOptionComplDeadlineDates[i] = programIncentiveOption.getCompletionDeadlineDate() != null ? fmt.format(programIncentiveOption.getCompletionDeadlineDate()) : "";
            programIncentiveOptionEndDates[i] = programIncentiveOption.getEndDate() != null ? fmt.format(programIncentiveOption.getEndDate()) : "";
            programIncentiveOptionActDates[i] = programIncentiveOption.getActivationDate() != null ? fmt.format(programIncentiveOption.getActivationDate()) : "";
            programIncentiveOptionDelDates[i] = programIncentiveOption.getDeliveryDate() != null ? fmt.format(programIncentiveOption.getDeliveryDate()) : "";
            closeDates[i] = programIncentiveOption.getIncentiveOption().getCloseDate() != null ? fmt.format(programIncentiveOption.getIncentiveOption().getCloseDate()) : "";
            creationDates[i] = programIncentiveOption.getIncentiveOption().getCreationDate() != null ? fmt.format(programIncentiveOption.getIncentiveOption().getCreationDate()) : "";
            newHireDates[i] = programIncentiveOption.getNewHireDate() != null ? fmt.format(programIncentiveOption.getNewHireDate()) : "";

            programIncentiveOptionSortOrders[i] = String.valueOf(programIncentiveOption.getSortOrder());

            programIncentiveOptionStatusIDs[i] = programIncentiveOption.getIncentiveOptionStatusCodeID();
            incentiveRuleTypeCodeIDs[i] = programIncentiveOption.getIncentiveRuleTypeCodeID();
            programIncentiveReportNameIDs[i] = programIncentiveOption.getIncentiveReportNameCodeID();
            programIncentiveFulfillReqIDs[i] = programIncentiveOption.getIncentiveFulfillmentRoutingCodeID();
            incentedStatusTypeCodeIDs[i] = programIncentiveOption.getIncentedStatusTypeCodeID();
            packageRuleGroupIDs[i] = programIncentiveOption.getPackageRuleGroupID();
            unitTypeCodeIDs[i] = programIncentiveOption.getUnitTypeCodeID();
            incentiveOptionRewardCardIDs[i] = programIncentiveOption.getIncentiveOptionRewardCardID();
            rewardRunFreqIDs[i] = programIncentiveOption.getRunFrequencyID();
            activityCompletionPeriods[i] = programIncentiveOption.getActivityCompletionPeriod();
            familyCaps[i] = programIncentiveOption.getFamilyCap();
            participantCap[i] = programIncentiveOption.getParticipantCap();
            i++;
        }

        saveProgramIncentiveForm.setIncentiveOptionInfos(incentiveOptionInfos);
        saveProgramIncentiveForm.setIncentiveOptionAddInfos(incentiveOptionAddInfos);
        saveProgramIncentiveForm.setDeliveryInfoIDs(deliveryInfoIDs);
        saveProgramIncentiveForm.setParticipationGroupIDs(participationGroupIDs);
        saveProgramIncentiveForm.setProgramIncentiveOptionEffDates(programIncentiveOptionEffDates);
        saveProgramIncentiveForm.setProgramIncentiveOptionEnrolDeadlineDates(programIncentiveOptionEnrolDeadlineDates);
        saveProgramIncentiveForm.setProgramIncentiveOptionComplDeadlineDates(programIncentiveOptionComplDeadlineDates);
        saveProgramIncentiveForm.setProgramIncentiveOptionEndDates(programIncentiveOptionEndDates);
        saveProgramIncentiveForm.setProgramIncentiveOptionActDates(programIncentiveOptionActDates);
        saveProgramIncentiveForm.setProgramIncentiveOptionDelDates(programIncentiveOptionDelDates);
        saveProgramIncentiveForm.setProgramIncentiveOptionSortOrders(programIncentiveOptionSortOrders);
        saveProgramIncentiveForm.setCloseDates(closeDates);
        saveProgramIncentiveForm.setCreationDates(creationDates);
        saveProgramIncentiveForm.setProgramIncentiveOptionStatusIDs(programIncentiveOptionStatusIDs);
        saveProgramIncentiveForm.setIncentiveRuleTypeCodeIDs(incentiveRuleTypeCodeIDs);
        saveProgramIncentiveForm.setProgramIncentiveReportNameIDs(programIncentiveReportNameIDs);
        saveProgramIncentiveForm.setProgramIncentiveFulfillReqIDs(programIncentiveFulfillReqIDs);
        saveProgramIncentiveForm.setIncentedStatusTypeCodeIDs(incentedStatusTypeCodeIDs);
        saveProgramIncentiveForm.setPackageRuleGroupIDs(packageRuleGroupIDs);
        saveProgramIncentiveForm.setUnitTypeCodeIDs(unitTypeCodeIDs);
        saveProgramIncentiveForm.setNewHireDates(newHireDates);
        saveProgramIncentiveForm.setIncentiveOptionRewardCardIDs(incentiveOptionRewardCardIDs);
        saveProgramIncentiveForm.setRewardRunFreqIDs(rewardRunFreqIDs);
        saveProgramIncentiveForm.setActivityCompletionPeriods(activityCompletionPeriods);
        saveProgramIncentiveForm.setFamilyCap(familyCaps);
        saveProgramIncentiveForm.setParticipantCap(participantCap);
    }

    private void addEditProgramCheckmarks(EditProgramForm form, ModelMap modelMap) throws Exception {
        Integer programId = form.getProgramID();
        BusinessProgram businessProgram = getUserSession().getBusinessProgram();
        if (businessProgram == null) {
            businessProgram = businessProgramService.getBusinessProgram(programId, false);
        }

        SaveProgramCheckmarksForm saveProgramCheckmarksForm = new SaveProgramCheckmarksForm();
        modelMap.put("saveProgramCheckmarksForm", saveProgramCheckmarksForm);
        ArrayList<ProgramCheckmark> lProgramCheckmarks = businessProgramService.getProgramCheckmarks(businessProgram.getProgramID());
        Integer[] participationGroupIDs = new Integer[lProgramCheckmarks.size()];
        Integer[] programIncentiveOptionIDs = new Integer[lProgramCheckmarks.size()];
        int i = 0;
        for (ProgramCheckmark lProgramCheckmark : lProgramCheckmarks) {
            lProgramCheckmark.setCheckmarkRequirements((ArrayList<CheckmarkRequirement>) businessProgramService.getCheckmarkRequirements(lProgramCheckmark.getQualificationCheckmarkID()));
            participationGroupIDs[i] = lProgramCheckmark.getParticipationGroupID();
            programIncentiveOptionIDs[i] = lProgramCheckmark.getProgramIncentiveOptionID();
            i++;
        }
        saveProgramCheckmarksForm.setParticipationGroupIDs(participationGroupIDs);
        saveProgramCheckmarksForm.setProgramIncentiveOptionIDs(programIncentiveOptionIDs);

        ArrayList<QualificationCheckmark> lAvailableCheckmarks = businessProgramService.getAvailableCheckmarks(programId);
        ArrayList<LookUpValueCode> lParticipationCodes = (ArrayList<LookUpValueCode>) businessProgramService.getParticipationCodes();
        ArrayList<PersonRelationshipCode> lPersonRelationshipCodes = (ArrayList<PersonRelationshipCode>) businessProgramService.getPersonRelationshipCodes();
        ArrayList<ProgramIncentiveOption> lProgramIncentiveOptions = (ArrayList<ProgramIncentiveOption>) businessProgramService.getProgramIncentiveOptions(programId);

        ArrayList<ParticipationGroup> lParticipationGroups = (ArrayList<ParticipationGroup>) businessProgramService.getParticipationGroups();

        getUserSession().setProgramCheckmarks(lProgramCheckmarks);
        getUserSession().setAvailableCheckmarks(lAvailableCheckmarks);
        getUserSession().setParticipationList(lParticipationCodes);
        getUserSession().setPersonRelationshipCodes(lPersonRelationshipCodes);
        getUserSession().setParticipationGroups(lParticipationGroups);

        modelMap.put("businessProgram", businessProgram);
        modelMap.put("programCheckmarks", lProgramCheckmarks);
        modelMap.put("availableCheckmarks", lAvailableCheckmarks);
        modelMap.put("participationCodes", lParticipationCodes);
        modelMap.put("personRelationshipCodes", lPersonRelationshipCodes);
        modelMap.put("programIncentiveOptions", lProgramIncentiveOptions);
        modelMap.put("participationGroups", lParticipationGroups);
    }

    private void addEditAdditionalInfo(EditProgramForm form, ModelMap modelMap) throws BPMException {
        Integer programId = form.getProgramID();
        BusinessProgram businessProgram = getUserSession().getBusinessProgram();
        if (businessProgram == null) {
            businessProgram = businessProgramService.getBusinessProgram(programId, false);
        }

        ArrayList<AdditionalInformation> additionalInfos = (ArrayList<AdditionalInformation>) businessProgramService.getAdditionalInfos(programId);
        getUserSession().setAdditionalInfos(additionalInfos);
        getUserSession().setAdditionalInfoFixedNames((ArrayList<LookUpValueCode>)businessProgramService.getAdditionalInfoFixedNames());

        SaveProgramAdditionalInfoForm saveProgramAdditionalInfoForm = new SaveProgramAdditionalInfoForm();
        modelMap.put("saveProgramAdditionalInfoForm", saveProgramAdditionalInfoForm);
        modelMap.put("businessProgram", businessProgram);
        modelMap.put("additionalInfos", additionalInfos);
        modelMap.put("additionaInfoFixedNames", getUserSession().getAdditionalInfoFixedNames());

        populateSaveProgramAdditionalInfoFormArrays(saveProgramAdditionalInfoForm, additionalInfos);
    }

    private void addExtendedAuthCodes(EditProgramForm form, ModelMap modelMap) throws BPMException {
        Integer programId = form.getProgramID();
        BusinessProgram businessProgram = getUserSession().getBusinessProgram();
        if (businessProgram == null) {
            businessProgram = businessProgramService.getBusinessProgram(programId, false);
        }

        ArrayList<AuthCode> lExtendedAuthCodes = (ArrayList<AuthCode>) businessProgramService.getExtendedAuthCodes(programId);
        getUserSession().setExtendedAuthCodes(lExtendedAuthCodes);

        ArrayList<LookUpValueCode> luvExtendedAuthCodeTypes = (ArrayList<LookUpValueCode>) businessProgramService.getExtendedAuthCodeTypes();
        LookUpValueCode lLookUpValueCodeFirstItem = new LookUpValueCode();
        lLookUpValueCodeFirstItem.setLuvId(0);
        lLookUpValueCodeFirstItem.setLuvVal(BPMAdminConstants.BPM_DEFAULT_FIRST_ITEM_IN_DROPDOWN);
        luvExtendedAuthCodeTypes.add(lLookUpValueCodeFirstItem);
        getUserSession().setAuthCodeTypes(luvExtendedAuthCodeTypes);

        SaveExtendedAuthCodesForm saveExtendedAuthCodesForm = new SaveExtendedAuthCodesForm();
        String[] extendedAuthCodeEffectiveDates = new String[getUserSession().getExtendedAuthCodes().size()];
        String[] extendedAuthCodeEndDates = new String[getUserSession().getExtendedAuthCodes().size()];
        int i = 0;
        for (AuthCode authCode : getUserSession().getExtendedAuthCodes()) {
            extendedAuthCodeEffectiveDates[i] = fmt.format(authCode.getEffectiveDate());
            extendedAuthCodeEndDates[i] = fmt.format(authCode.getEndDate());
            i++;
        }
        saveExtendedAuthCodesForm.setExtendedAuthCodeEffectiveDates(extendedAuthCodeEffectiveDates);
        saveExtendedAuthCodesForm.setExtendedAuthCodeEndDates(extendedAuthCodeEndDates);

        modelMap.put("saveExtendedAuthCodesForm", saveExtendedAuthCodesForm);
        modelMap.put("businessProgram", businessProgram);
        modelMap.put("extendedAuthCodes", getUserSession().getExtendedAuthCodes());
        modelMap.put("luvExtendedAuthCodeTypes", luvExtendedAuthCodeTypes);
    }

    private void addChangeLog(EditProgramForm form, ModelMap modelMap) throws BPMException {
        Integer programId = form.getProgramID();
        BusinessProgram businessProgram = getUserSession().getBusinessProgram();
        if (businessProgram == null) {
            businessProgram = businessProgramService.getBusinessProgram(programId, false);
        }

        ProgramChangeLogForm programChangeLogForm = new ProgramChangeLogForm();
        modelMap.put("programChangeLogForm", programChangeLogForm);
        modelMap.put("programID", programId);
        modelMap.put("businessProgram", businessProgram);
        modelMap.put("changeLogList", businessProgramService.getBusinessProgramChangeLog(programId));
    }

    private void populateSaveProgramAdditionalInfoFormArrays(SaveProgramAdditionalInfoForm saveProgramAdditionalInfoForm, ArrayList<AdditionalInformation> additionalInfos) {
        Integer[] additionalInfoIDs = new Integer[additionalInfos.size()];
        String[] additionalInfoNames = new String[additionalInfos.size()];
        String[] additionalInfoTexts = new String[additionalInfos.size()];
        Integer[] additionalInfoTypeCodeIDs = new Integer[additionalInfos.size()];
        String[] additionalInfoTypeCodes = new String[additionalInfos.size()];
        Integer[] sortOrders = new Integer[additionalInfos.size()];

        int i = 0;
        for (AdditionalInformation additionalInformation : additionalInfos) {
            additionalInfoIDs[i] = additionalInformation.getAdditionalInfoID();
            additionalInfoNames[i] = additionalInformation.getAdditionalInfoName();
            additionalInfoTexts[i] = additionalInformation.getAdditionalInfoText();
            additionalInfoTypeCodeIDs[i] = additionalInformation.getAdditionalInfoTypeID();
            additionalInfoTypeCodes[i] = additionalInformation.getAdditionalInfoTypeCode();
            sortOrders[i] = additionalInformation.getSortOrder();
            i++;
        }

        saveProgramAdditionalInfoForm.setAdditionalInfoIDs(additionalInfoIDs);
        saveProgramAdditionalInfoForm.setAdditionalInfoNames(additionalInfoNames);
        saveProgramAdditionalInfoForm.setAdditionalInfoTexts(additionalInfoTexts);
        saveProgramAdditionalInfoForm.setAdditionalInfoTypeCodeIDs(additionalInfoTypeCodeIDs);
        saveProgramAdditionalInfoForm.setAdditionalInfoTypeCodes(additionalInfoTypeCodes);
        saveProgramAdditionalInfoForm.setSortOrders(sortOrders);
    }

    private SaveProgramForm populateSaveProgramForm(BusinessProgram lBusinessProgram) throws BPMException {
        SaveProgramForm saveProgramForm = new SaveProgramForm();
        saveProgramForm.setProgramID(lBusinessProgram.getProgramID());
        saveProgramForm.setProgramName(lBusinessProgram.getProgramName());
        saveProgramForm.setProgramStatusCodeID(lBusinessProgram.getProgramStatusCodeID());
        saveProgramForm.setActivationCodes(getUserSession().getActivationCodes());
        saveProgramForm.setGroupID(lBusinessProgram.getEmployerGroup().getGroupID());
        saveProgramForm.setGroupNumber(lBusinessProgram.getEmployerGroup().getGroupNumber());
        saveProgramForm.setSiteName(lBusinessProgram.getEmployerGroup().getSiteName());
        saveProgramForm.setSiteNumber(lBusinessProgram.getEmployerGroup().getSiteNumber());
        saveProgramForm.setGroupName(lBusinessProgram.getEmployerGroup().getGroupName());
        saveProgramForm.setGroupReportName(lBusinessProgram.getEmployerGroup().getGroupReportName());
        saveProgramForm.setGroupAbbreviatedName(lBusinessProgram.getEmployerGroup().getGroupAbbreviatedName());
        saveProgramForm.setSiteReportName(lBusinessProgram.getEmployerGroup().getSiteReportName());
        saveProgramForm.setSiteAbbreviatedName(lBusinessProgram.getEmployerGroup().getSiteAbbreviatedName());
        saveProgramForm.setReleaseDate(lBusinessProgram.getReleaseDate() != null ? fmt.format(lBusinessProgram.getReleaseDate()) : null);
        saveProgramForm.setStatusCalcEndDate(lBusinessProgram.getStatusCalcEndDate() != null ? fmt.format(lBusinessProgram.getStatusCalcEndDate()) : null);
        saveProgramForm.setQualificationWindowStartDate(lBusinessProgram.getQualificationWindowStartDate() != null ? fmt.format(lBusinessProgram.getQualificationWindowStartDate()) : null);
        saveProgramForm.setEffectiveDate(lBusinessProgram.getEffectiveDate() != null ? fmt.format(lBusinessProgram.getEffectiveDate()) : null);
        saveProgramForm.setQualificationWindowEndDate(lBusinessProgram.getQualificationWindowEndDate() != null ? fmt.format(lBusinessProgram.getQualificationWindowEndDate()) : null);
        saveProgramForm.setEndDate(lBusinessProgram.getEndDate() != null ? fmt.format(lBusinessProgram.getEndDate()) : null);
        saveProgramForm.setNewHireDate(lBusinessProgram.getEmployerGroup().getNewHireDate() != null ? fmt.format(lBusinessProgram.getEmployerGroup().getNewHireDate()) : null);
        saveProgramForm.setMembershipActivationDate(lBusinessProgram.getMembershipProcessDate() != null ? fmt.format(lBusinessProgram.getMembershipProcessDate()) : null);
        if (lBusinessProgram.getContributionStartDate() != null) {
            saveProgramForm.setContributionStartDate(fmt.format(lBusinessProgram.getContributionStartDate()));
        }
        if (lBusinessProgram.getContributionEndDate() != null) {
            saveProgramForm.setContributionEndDate(fmt.format(lBusinessProgram.getContributionEndDate()));
        }
        saveProgramForm.setFamilyParticipationRequirement(lBusinessProgram.getFamilyParticipationRequirement());

        if (CollectionUtils.isEmpty(getUserSession().getActivationCodes())) {
            ArrayList<LookUpValueCode> lActivationCodes = (ArrayList<LookUpValueCode>) businessProgramService.getProgramActivationCodes();
            getUserSession().setActivationCodes(lActivationCodes);
        }

        if (CollectionUtils.isEmpty(getUserSession().getParticipationList())) {
            ArrayList<LookUpValueCode> lParticipationList = (ArrayList<LookUpValueCode>) businessProgramService.getParticipationCodes();
            getUserSession().setParticipationList(lParticipationList);
        }

        if (CollectionUtils.isEmpty(getUserSession().getProgramSpecialReportHandlingCodes())) {
            ArrayList<LookUpValueCode> lProgramSpecialReportHandlingCodes = (ArrayList<LookUpValueCode>) businessProgramService.getProgramSpecialReportHandlingCodes();
            getUserSession().setProgramSpecialReportHandlingCodes(lProgramSpecialReportHandlingCodes);
        }

        if (CollectionUtils.isEmpty(getUserSession().getAvailableSites())) {
            ArrayList<EmployerGroup> availableSites = (ArrayList<EmployerGroup>) businessProgramService.getSubGroups(lBusinessProgram.getEmployerGroup().getGroupID());
            getUserSession().setAvailableSites(availableSites);
        }

        saveProgramForm.setParticipationList(getUserSession().getParticipationList());
        saveProgramForm.setReportIndicatorList(getUserSession().getProgramSpecialReportHandlingCodes());
        saveProgramForm.setAvailableSites(getUserSession().getAvailableSites());

        saveProgramForm.setReportIndicatorCodeID(lBusinessProgram.getReportIndicatorCodeID());
        saveProgramForm.setReportIndicatorCodeValue(lBusinessProgram.getReportIndicatorCodeValue());

        saveProgramForm.setProgramTypeCodeID(lBusinessProgram.getProgramTypeCodeID());
        saveProgramForm.setProgramStatusCodeID(lBusinessProgram.getProgramStatusCodeID());
        saveProgramForm.setQualificationCheckmarkID(lBusinessProgram.getQualificationCheckmarkID() != null ? lBusinessProgram.getQualificationCheckmarkID() : 0);
        saveProgramForm.setSubgroupID(lBusinessProgram.getEmployerGroup().getSubgroupID());

        saveProgramForm.setAdditionalGroupProgramInfo(lBusinessProgram.getAdditionalGroupProgramInfo());

        return saveProgramForm;
    }

    private void populateUserSessionAndRequest(BusinessProgram lBusinessProgram, ArrayList<LookUpValueCode> lProgramSpecialReportHandlingCodes, ModelMap modelMap) throws BPMException {
        ArrayList<LookUpValueCode> lParticipationList = (ArrayList<LookUpValueCode>) businessProgramService.getParticipationCodes();
        ArrayList<EligibleActivity> lEligibleActivities = (ArrayList<EligibleActivity>) businessProgramService.getEligibleActivities(lBusinessProgram.getProgramID());
        ArrayList<Activity> lAvailableActivities = (ArrayList<Activity>) businessProgramService.getAvailableActivities(lBusinessProgram.getProgramID());
        ArrayList<LookUpValueCode> lActivationCodes = (ArrayList<LookUpValueCode>) businessProgramService.getProgramActivationCodes();
        ArrayList<QualificationCheckmark> lQualificationCheckmarks = (ArrayList<QualificationCheckmark>) businessProgramService.getQualificationCheckmarks();

        modelMap.put("reportIndicatorList", getUserSession().getProgramSpecialReportHandlingCodes());
        modelMap.put("businessProgram", lBusinessProgram);
        modelMap.put("eligibleActivities", lEligibleActivities);
        modelMap.put("availableActivities", lAvailableActivities);
        modelMap.put("participationList", lParticipationList);
        modelMap.put("activationCodes", lActivationCodes);
        modelMap.put("qualificationCheckmarks", lQualificationCheckmarks);

        getUserSession().setBusinessProgram(lBusinessProgram);
        if (getUserSession().getEligibleActivities() != null) {
            getUserSession().getEligibleActivities().clear();
        }
        if (getUserSession().getAvailableActivities() != null) {
            getUserSession().getAvailableActivities().clear();
        }
        if (getUserSession().getParticipationList() != null) {
            getUserSession().getParticipationList().clear();
        }
        if (getUserSession().getActivationCodes() != null) {
            getUserSession().getActivationCodes().clear();
        }
        if (getUserSession().getQualificationCheckmarks() != null) {
            getUserSession().getQualificationCheckmarks().clear();
        }
        if (getUserSession().getProgramSpecialReportHandlingCodes() != null) {
            getUserSession().getProgramSpecialReportHandlingCodes().clear();
        }
        getUserSession().setEligibleActivities(lEligibleActivities);
        getUserSession().setAvailableActivities(lAvailableActivities);
        getUserSession().setParticipationList(lParticipationList);
        getUserSession().setActivationCodes(lActivationCodes);
        getUserSession().setQualificationCheckmarks(lQualificationCheckmarks);
        getUserSession().setProgramSpecialReportHandlingCodes(lProgramSpecialReportHandlingCodes);
    }

    private void assignDefaultReportIndicator(BusinessProgram pBusinessProgram, ProgramType pProgramType, ArrayList<LookUpValueCode> pProgramSpecialReportHandlingCodes) {
        if (BPMAdminConstants.BPM_ADMIN_REPORT_TYPE_BUSG.equals(pProgramType.getReportIndicatorTypeCode())) {
            for (LookUpValueCode lLookUpValueCode : pProgramSpecialReportHandlingCodes) {
                if (BPMAdminConstants.BPM_ADMIN_REPORT_IND_INCLUDE.equals(lLookUpValueCode.getLuvVal())) {
                    pBusinessProgram.setReportIndicatorCodeID(lLookUpValueCode.getLuvId());
                    pBusinessProgram.setReportIndicatorCodeValue(lLookUpValueCode.getLuvDesc());
                    break;
                }
            }
        } else if (BPMAdminConstants.BPM_ADMIN_REPORT_TYPE_NONE.equals(pProgramType.getReportIndicatorTypeCode())) {
            for (LookUpValueCode lLookUpValueCode : pProgramSpecialReportHandlingCodes) {
                if (BPMAdminConstants.BPM_ADMIN_REPORT_IND_EXCLUDE.equals(lLookUpValueCode.getLuvVal())) {
                    pBusinessProgram.setReportIndicatorCodeID(lLookUpValueCode.getLuvId());
                    pBusinessProgram.setReportIndicatorCodeValue(lLookUpValueCode.getLuvDesc());
                    break;
                }
            }
        }
    }

    protected void findAvailablePackage(ModelMap modelMap) throws Exception {
        ArrayList<ProgramPackage> lProgramPackages = (ArrayList<ProgramPackage>) businessProgramService.getProgramPackages();
        modelMap.put("programPackages", lProgramPackages);
        if (getUserSession().getProgramPackages() != null) {
            getUserSession().getProgramPackages().clear();
        }
        getUserSession().setProgramPackages(lProgramPackages);
    }

    @Override
    public boolean supports(Class<?> clazz) {
        return CreateProgramForm.class.isAssignableFrom(clazz);
    }

    @Override
    public void validate(Object target, Errors errors) {
        SaveProgramForm form = (SaveProgramForm) target;
        programValidationService.validateSaveProgram(form, errors);
    }
}
