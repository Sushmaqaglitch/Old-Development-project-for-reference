/* $Id$ */

package com.healthpartners.app.bpm.impl;

import com.healthpartners.app.bpm.common.BPMAdminConstants;
import com.healthpartners.app.bpm.dao.LookUpValueDAO;
import com.healthpartners.app.bpm.dto.LookUpValueCode;
import com.healthpartners.app.bpm.exception.BPMException;
import com.healthpartners.app.bpm.iface.LookUpValueService;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

/**
 * A caching implementation of the LookUpValueService interface. The caching
 * strategy used would be lazy load.
 *
 * @author pbhenninger
 */
@Service
public class LookUpValueServiceImpl implements LookUpValueService {

    protected final Log logger = LogFactory.getLog(getClass());

    private LookUpValueDAO dao;

    public LookUpValueServiceImpl(LookUpValueDAO dao) {
		this.dao = dao;
    }


    @Transactional(timeout = 300, rollbackFor = {DataAccessException.class, BPMException.class})
    public int insertLUVCode(LookUpValueCode code)
            throws BPMException, DataAccessException {
        return dao.insertLUVCode(code);
    }

    @Transactional(timeout = 300, rollbackFor = {DataAccessException.class, BPMException.class})
    public int updateLUVCode(LookUpValueCode code)
            throws BPMException, DataAccessException {
        return dao.updateLUVCode(code);
    }

    @Transactional(timeout = 300, rollbackFor = {DataAccessException.class, BPMException.class})
    public int deleteLUVCode(LookUpValueCode code)
            throws BPMException, DataAccessException {
        return deleteLUVCode(code.getLuvGroup(), code.getLuvVal());
    }

    @Transactional(timeout = 300, rollbackFor = {DataAccessException.class, BPMException.class})
    public int deleteLUVCode(String group, String value) {
        return dao.deleteLUVCode(group, value);
    }

    public Collection<LookUpValueCode> getAllLUVCodes()
            throws BPMException, DataAccessException {
        Collection<LookUpValueCode> codes = new ArrayList<LookUpValueCode>();

        try {
            codes.addAll(dao.getAllLUVCodes());
        } catch (Exception e) {
            e.printStackTrace();
            //throw new BPMException(e.getMessage(), e);
        }

        return codes;
    }

    public Collection<LookUpValueCode> getActiveLUVCodes()
            throws BPMException, DataAccessException {
        Collection<LookUpValueCode> codes = new ArrayList<LookUpValueCode>();

        try {
            Collection<LookUpValueCode> allLUVCodes = getAllLUVCodes();
            Iterator<LookUpValueCode> iter = allLUVCodes.iterator();
            while (iter.hasNext()) {
                LookUpValueCode code = iter.next();
                if (BPMAdminConstants.ACTIVATE_STATUS.equals(code.getLuvStatus())) {
                    codes.add(code);
                }
            }
        } catch (Exception e) {
            throw new BPMException(e.getMessage(), e);
        }

        return codes;
    }

    public Collection<LookUpValueCode> getActiveNNonActiveLUVCodes()
            throws BPMException, DataAccessException {
        Collection<LookUpValueCode> codes = new ArrayList<LookUpValueCode>();

        try {
            Collection<LookUpValueCode> allLUVCodes = getAllLUVCodes();
            Iterator<LookUpValueCode> iter = allLUVCodes.iterator();
            while (iter.hasNext()) {
                LookUpValueCode code = iter.next();
                codes.add(code);
            }
        } catch (Exception e) {
            throw new BPMException(e.getMessage(), e);
        }

        return codes;
    }

    public Collection<LookUpValueCode> getLUVCodesByGroup(String group)
            throws BPMException, DataAccessException {
        Collection<LookUpValueCode> codes = new ArrayList<LookUpValueCode>();

        try {
            Collection<LookUpValueCode> allActiveLUVCodes = getActiveLUVCodes();
            Iterator<LookUpValueCode> iter = allActiveLUVCodes.iterator();
            while (iter.hasNext()) {
                LookUpValueCode code = iter.next();
                if (code.getLuvGroup().equals(group)) {
                    codes.add(code);
                }
            }
        } catch (Exception e) {
            throw new BPMException(e.getMessage(), e);
        }

        return codes;
    }

    public LookUpValueCode getLUVCodeByID(Integer luvID)
            throws BPMException, DataAccessException {
        Collection<LookUpValueCode> codes = new ArrayList<LookUpValueCode>();

        try {
            Collection<LookUpValueCode> allActiveLUVCodes = getActiveLUVCodes();
            Iterator<LookUpValueCode> iter = allActiveLUVCodes.iterator();
            while (iter.hasNext()) {
                LookUpValueCode code = iter.next();
                if (code.getLuvId().equals(luvID)) {
                    codes.add(code);
                }
            }
        } catch (Exception e) {
            throw new BPMException(e.getMessage(), e);
        }

        LookUpValueCode lLookUpValueCode = null;
        if (codes.size() > 0) {
            lLookUpValueCode = codes.iterator().next();
        }

        return lLookUpValueCode;
    }

    public synchronized Collection<LookUpValueCode> getLUVCodesByGroupAndName(
            String group, String luVal)
            throws BPMException, DataAccessException {
        Collection<LookUpValueCode> codes = new ArrayList<LookUpValueCode>();

        try {
            Collection<LookUpValueCode> allActiveLUVCodes = getActiveNNonActiveLUVCodes();
            Iterator<LookUpValueCode> iter = allActiveLUVCodes.iterator();
            while (iter.hasNext()) {
                LookUpValueCode code = iter.next();
                if (code.getLuvGroup().equals(group)
                        && code.getLuvVal().equals(luVal)) {
                    codes.add(code);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new BPMException(e.getMessage(), e);
        }

        return codes;
    }
}
