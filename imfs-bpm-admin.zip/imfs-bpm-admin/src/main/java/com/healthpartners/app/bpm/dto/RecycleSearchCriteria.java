package com.healthpartners.app.bpm.dto;

import com.healthpartners.service.bpm.dto.BaseDTO;

/**
 * @author jxbourbour
 */
public class RecycleSearchCriteria extends BaseDTO {
    static final long serialVersionUID = 0L;

    private String memberID;
    private String contractNo;
    private String groupNo;
    private String programName;
    private String recycleStatusID;
    private String recycleStatusDateString;

    public RecycleSearchCriteria() {
        super();
    }

    public final String getMemberID() {
        return memberID;
    }

    public final void setMemberID(String memberID) {
        this.memberID = memberID;
    }

    public final String getContractNo() {
        return contractNo;
    }

    public final void setContractNo(String contractNo) {
        this.contractNo = contractNo;
    }

    public final String getGroupNo() {
        return groupNo;
    }

    public final void setGroupNo(String groupNo) {
        this.groupNo = groupNo;
    }

    public final String getProgramName() {
        return programName;
    }

    public final void setProgramName(String programName) {
        this.programName = programName;
    }

    public final String getRecycleStatusID() {
        return recycleStatusID;
    }

    public final void setRecycleStatusID(String recycleStatusID) {
        this.recycleStatusID = recycleStatusID;
    }

    public final String getRecycleStatusDateString() {
        return recycleStatusDateString;
    }

    public final void setRecycleStatusDateString(String recycleStatusDateString) {
        this.recycleStatusDateString = recycleStatusDateString;
    }


}
