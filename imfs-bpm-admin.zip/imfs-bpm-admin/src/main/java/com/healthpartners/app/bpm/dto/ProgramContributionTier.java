package com.healthpartners.app.bpm.dto;

import java.io.Serializable;

public class ProgramContributionTier implements Serializable
{	
	static final long serialVersionUID = 0L;
		
	private Integer rowID;
	private Integer programID;
	private Integer incentiveOptionID;
	private Integer activityID;
	private Integer activityTypeCodeID;
	private String  activityName;
	private String  activityTypeCode;
	private Integer tierContributionID;
	private Integer activityIncentiveID;
	private Integer tierTypeID;
	private Integer tierValueID;
	private Integer relationshipCode;
	private String  relationshipDesc;
	private Integer contributionAmount;
	private Integer benefitContractTypeID;
	private String  benefitContractType;
	private String  tierTypeName;
	private String  tierTypeDesc;
	private boolean used;
	private Integer qualificationCheckmarkDetailID;
	private Integer activityIncentiveGroupID;
	private Integer activityIncentiveGroupReqID;
	
	
	
	public ProgramContributionTier()
	{
		super();
	}


	

	public Integer getRowID() {
		return rowID;
	}




	public void setRowID(Integer rowID) {
		this.rowID = rowID;
	}




	public Integer getProgramID() {
		return programID;
	}



	public void setProgramID(Integer programID) {
		this.programID = programID;
	}



	public Integer getIncentiveOptionID() {
		return incentiveOptionID;
	}



	public void setIncentiveOptionID(Integer incentiveOptionID) {
		this.incentiveOptionID = incentiveOptionID;
	}



	public Integer getActivityID() {
		return activityID;
	}



	public void setActivityID(Integer activityID) {
		this.activityID = activityID;
	}



	public Integer getActivityTypeCodeID() {
		return activityTypeCodeID;
	}



	public void setActivityTypeCodeID(Integer activityTypeCodeID) {
		this.activityTypeCodeID = activityTypeCodeID;
	}



	public String getActivityName() {
		return activityName;
	}



	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}



	public String getActivityTypeCode() {
		return activityTypeCode;
	}



	public void setActivityTypeCode(String activityTypeCode) {
		this.activityTypeCode = activityTypeCode;
	}



	public Integer getTierContributionID() {
		return tierContributionID;
	}



	public void setTierContributionID(Integer tierContributionID) {
		this.tierContributionID = tierContributionID;
	}



	public Integer getActivityIncentiveID() {
		return activityIncentiveID;
	}



	public void setActivityIncentiveID(Integer activityIncentiveID) {
		this.activityIncentiveID = activityIncentiveID;
	}



	public Integer getTierTypeID() {
		return tierTypeID;
	}



	public void setTierTypeID(Integer tierTypeID) {
		this.tierTypeID = tierTypeID;
	}
	
	



	public Integer getTierValueID() {
		return tierValueID;
	}



	public void setTierValueID(Integer tierValueID) {
		this.tierValueID = tierValueID;
	}




	public Integer getRelationshipCode() {
		return relationshipCode;
	}



	public void setRelationshipCode(Integer relationshipCode) {
		this.relationshipCode = relationshipCode;
	}



	public String getRelationshipDesc() {
		return relationshipDesc;
	}



	public void setRelationshipDesc(String relationshipDesc) {
		this.relationshipDesc = relationshipDesc;
	}



	public Integer getContributionAmount() {
		return contributionAmount;
	}



	public void setContributionAmount(Integer contributionAmount) {
		this.contributionAmount = contributionAmount;
	}



	public Integer getBenefitContractTypeID() {
		return benefitContractTypeID;
	}



	public void setBenefitContractTypeID(Integer benefitContractTypeID) {
		this.benefitContractTypeID = benefitContractTypeID;
	}



	public String getBenefitContractType() {
		return benefitContractType;
	}



	public void setBenefitContractType(String benefitContractType) {
		this.benefitContractType = benefitContractType;
	}




	public String getTierTypeName() {
		return tierTypeName;
	}




	public void setTierTypeName(String tierTypeName) {
		this.tierTypeName = tierTypeName;
	}




	public String getTierTypeDesc() {
		return tierTypeDesc;
	}




	public void setTierTypeDesc(String tierTypeDesc) {
		this.tierTypeDesc = tierTypeDesc;
	}




	public boolean isUsed() {
		return used;
	}




	public void setUsed(boolean used) {
		this.used = used;
	}




	public Integer getQualificationCheckmarkDetailID() {
		return qualificationCheckmarkDetailID;
	}




	public void setQualificationCheckmarkDetailID(
			Integer qualificationCheckmarkDetailID) {
		this.qualificationCheckmarkDetailID = qualificationCheckmarkDetailID;
	}




	public Integer getActivityIncentiveGroupID() {
		return activityIncentiveGroupID;
	}




	public void setActivityIncentiveGroupID(Integer activityIncentiveGroupID) {
		this.activityIncentiveGroupID = activityIncentiveGroupID;
	}




	public Integer getActivityIncentiveGroupReqID() {
		return activityIncentiveGroupReqID;
	}




	public void setActivityIncentiveGroupReqID(Integer activityIncentiveGroupReqID) {
		this.activityIncentiveGroupReqID = activityIncentiveGroupReqID;
	}

	
	
	
	
}
