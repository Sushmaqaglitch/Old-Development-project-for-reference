package com.healthpartners.app.bpm.dto;
import java.io.Serializable;
import java.lang.reflect.Field;

/**
 * Represents a BPM Audit Record. Maps to the <code>audit log</code> table.
 * 
 * @author tjquist
 */
public class BPMAuditRecord implements Serializable {
    private static final String RESULT_SUCCESS = "success";
    private static final String RESULT_FAIL = "fail";
	private java.util.Date logDate;
	private String applicationId;
	private String applicationEvent;
	private String eventResult;
	private String param1;
	private String param2;
	private String param3;
	private String param4;
    
	public BPMAuditRecord() {
		super();
	}
	
	
	public String getApplicationEvent() {
		return applicationEvent;
	}


	public void setApplicationEvent(String applicationEvent) {
		this.applicationEvent = applicationEvent;
	}


	public String getApplicationId() {
		return applicationId;
	}


	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}


	public String getEventResult() {
		return eventResult;
	}


	public void setEventResult(String eventResult) {
		this.eventResult = eventResult;
	}


	public java.util.Date getLogDate() {
		return logDate;
	}


	public void setLogDate(java.util.Date logDate) {
		this.logDate = logDate;
	}


	public String getParam1() {
		return param1;
	}


	public void setParam1(String param1) {
		this.param1 = param1;
	}


	public String getParam2() {
		return param2;
	}


	public void setParam2(String param2) {
		this.param2 = param2;
	}


	public String getParam3() {
		return param3;
	}


	public void setParam3(String param3) {
		this.param3 = param3;
	}


	public String getParam4() {
		return param4;
	}


	public void setParam4(String param4) {
		this.param4 = param4;
	}


	/**
	 * Overridden toString method.
	 * 
	 * @return A reflexively built string representation of this bean.
	 */
	public String toString() {
		String value = null;
		StringBuffer sb = new StringBuffer(1000);
		sb.append("[" + super.toString() + "]={");
		boolean firstPropertyDisplayed = false;

		try {
			Field[] fields = this.getClass().getDeclaredFields();
			for (int i = 0; i < fields.length; i++) {
				if (firstPropertyDisplayed) {
					sb.append(", ");
				} else {
					firstPropertyDisplayed = true;
				}
				sb.append(fields[i].getName() + "=" + fields[i].get(this));
			}
			sb.append("}");
			value = sb.toString().trim();
		} catch (IllegalAccessException iae) {
			iae.printStackTrace();
		}

		return value;
	}
}
