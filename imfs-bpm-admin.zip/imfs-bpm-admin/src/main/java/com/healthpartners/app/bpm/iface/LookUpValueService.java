/* $Id$ */

package com.healthpartners.app.bpm.iface;

import com.healthpartners.app.bpm.dto.LookUpValueCode;
import com.healthpartners.app.bpm.exception.BPMException;
import org.springframework.dao.DataAccessException;

import java.util.Collection;

/**
 * Provides LookUpValueCode services.
 * 
 * @author tjquist
 */
public interface LookUpValueService {

	/**
	 * Insert the specified <code>LookUpValueCode</code>.
	 * 
	 * @param code
	 *            an instance of <code>LookUpValueCode</code>
	 * @return the number of codes inserted
	 * @throws DataAccessException
	 */
	public int insertLUVCode(LookUpValueCode code)
			throws BPMException,
			DataAccessException;

	/**
	 * Update the specified <code>LookUpValueCode</code>.
	 * 
	 * @param code
	 *            an instance of <code>LookUpValueCode</code>
	 * @return the number of codes updated
	 * @throws DataAccessException
	 */	
	public int updateLUVCode(LookUpValueCode code)
			throws BPMException,
			DataAccessException;

	/**
	 * Deletes the specified <code>LookUpValueCode</code>.
	 * 
	 * @param code
	 *            an instance of <code>LookUpValueCode</code>
	 * @return a count of deletes performed
	 * @throws DataAccessException
	 */
	public int deleteLUVCode(LookUpValueCode code)
			throws BPMException,
			DataAccessException;

	/**
	 * Deletes the specified <code>LookUpValueCode</code>.
	 * 
	 * @param group
	 *            the LUV group
	 * @param value
	 *            the LUV value
	 * @return a count of deletes performed
	 * @throws DataAccessException
	 */
	public int deleteLUVCode(String group, String value)
			throws BPMException,
			DataAccessException;

	/**
	 * Retrieves all codes.
	 * 
	 * @return <code>Collection</code> of <code>LookUpValueCode</code>
	 *         objects
	 * @throws DataAccessException
	 */
	public Collection<LookUpValueCode> getAllLUVCodes()
			throws BPMException,
			DataAccessException;

	/**
	 * Retrieves all active codes.
	 * 
	 * @return <code>Collection</code> of <code>LookUpValueCode</code>
	 *         objects
	 * @throws DataAccessException
	 */
	public Collection<LookUpValueCode> getActiveLUVCodes()
			throws BPMException,
			DataAccessException;
	
	public LookUpValueCode getLUVCodeByID(Integer luvID)
			throws BPMException, DataAccessException;

	/**
	 * Retrieves all code of the specified group.
	 * 
	 * @param group
	 *            the LUV group
	 * @return a <code>Collection</code> of <code>LookUpValueCode</code>
	 *         objects
	 * @throws DataAccessException
	 */
	public Collection<LookUpValueCode> getLUVCodesByGroup(String group)
			throws BPMException,
			DataAccessException;

	/**
	 * Retrieves all code of the specified group and name.
	 * 
	 * @param group
	 *            the LUV group
	 * @param name
	 *            the LUV name
	 * @return a <code>Collection</code> of <code>LookUpValueCode</code>
	 *         objects
	 * @throws DataAccessException
	 */
	public Collection<LookUpValueCode> getLUVCodesByGroupAndName(String group,
			String name) throws BPMException, DataAccessException;
}
