package com.healthpartners.app.bpm.controller;

import com.healthpartners.app.bpm.common.BPMAdminConstants;
import com.healthpartners.app.bpm.common.BPMAdminUtils;
import com.healthpartners.app.bpm.common.BPMPagination;
import com.healthpartners.app.bpm.dao.ControlGroupIOFileDirSetupDAO;
import com.healthpartners.app.bpm.dao.GroupActivityProgressTrackerDAO;
import com.healthpartners.app.bpm.dto.ControlGroupIOFileDirSetup;
import com.healthpartners.app.bpm.dto.GroupActivityProgressTracker;
import com.healthpartners.app.bpm.dto.LookUpValueCode;
import com.healthpartners.app.bpm.exception.BPMException;
import com.healthpartners.app.bpm.form.PersonCDHPFulfillRecycleSearchForm;
import com.healthpartners.app.bpm.form.PersonContractRecycleSearchForm;
import com.healthpartners.app.bpm.form.PersonEmployerActivityUploadSearchForm;
import com.healthpartners.app.bpm.iface.MemberService;
import com.healthpartners.app.bpm.pageable.PageableGroupActivityProgressTracker;
import com.healthpartners.app.bpm.session.UserSession;
import com.healthpartners.service.bpm.common.BPMConstants;
import com.healthpartners.service.bpm.rules.StatusCalculationCommand;
import jakarta.servlet.http.HttpServletRequest;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.sql.Date;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collection;

@Controller
public class PersonEmployerActivityUploadSearchController extends BaseController implements Validator {

    private static final int DEFAULT_BATCH_SIZE = 200;
    private static final Integer MAX_RECS_PER_PAGE = 255;

    private static final String GROUP_ACTIVITY_PROGRESS_TRACKER_LIST = "GROUP_ACTIVITY_PROGRESS_TRACKERS";
    private final MemberService memberService;
    private final ControlGroupIOFileDirSetupDAO controlGroupIOFileDirSetupDAO;
    private final GroupActivityProgressTrackerDAO groupActivityProgressTrackerDAO;
    private final Log logger = LogFactory.getLog(getClass());


    public PersonEmployerActivityUploadSearchController(MemberService memberService, ControlGroupIOFileDirSetupDAO controlGroupIOFileDirSetupDAO, GroupActivityProgressTrackerDAO groupActivityProgressTrackerDAO) {
        this.memberService = memberService;
        this.controlGroupIOFileDirSetupDAO = controlGroupIOFileDirSetupDAO;
        this.groupActivityProgressTrackerDAO = groupActivityProgressTrackerDAO;
    }

    @GetMapping("/showPersonEmployerActivityUploadSearch")
    public String loadSearch(ModelMap modelMap) throws BPMException {
        try {
            loadInitial(modelMap);
        } catch (Exception e) {
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
            modelMap.put("errorMsg", getStackTrace(e));
        }
        return "personEmployerActivityUploadSearch";
    }

    @PostMapping("/personEmployerActivityUploadSearch")
    public String submit(@ModelAttribute("personEmployerActivityUploadSearchForm") PersonEmployerActivityUploadSearchForm form, ModelMap modelMap, BindingResult result) throws Exception {
        try {
            populateSelects(modelMap);
            if (ACTION_SEARCH.equals(form.getActionType())) {
                validate(form, result);
                if (!result.hasErrors()) {
                    search(form, modelMap);
                }
            } else if (ACTION_SAVE.equals(form.getActionType())) {
               performSave(form, modelMap);
            }
        } catch (Exception e) {
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
            // Add error stack trace on the request, to be hidden in html.
            modelMap.put("errorMsg", getStackTrace(e));
        }

        return "personEmployerActivityUploadSearch";
    }

    @GetMapping("/personEmployerActivityUploadSearch")
    public String handleSubmitActionFromLink(@RequestParam(name="actionType") String actionType,
                                             @RequestParam(name="controlGroupNo") String controlGroupNo,
                                             @RequestParam(name="batchDate") String batchDate,
                                             @RequestParam(name="trackingStatusId") String trackingStatusId,
                                             @RequestParam(name="fileName") String fileName,
                                             ModelMap modelMap) throws Exception {
        try {
            PersonEmployerActivityUploadSearchForm form = (PersonEmployerActivityUploadSearchForm)modelMap.getAttribute("personEmployerActivityUploadSearchForm");
            performSubmitAction(form, modelMap, actionType, controlGroupNo, batchDate, trackingStatusId, fileName);

        } catch (Exception e) {
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
            // Add error stack trace on the request, to be hidden in html.
            modelMap.put("errorMsg", getStackTrace(e));
        }

        return "personEmployerActivityUploadSearch";
    }

    @PostMapping(value = "/personEmployerActivityUploadSearch", params = "next")
    public String submitNext(@ModelAttribute("personEmployerActivityUploadSearchForm") PersonEmployerActivityUploadSearchForm form, ModelMap modelMap, HttpServletRequest request) throws Exception {
        return performPaginationAction(form, modelMap);
    }

    @PostMapping(value = "/personEmployerActivityUploadSearch", params = "back")
    public String submitBack(@ModelAttribute("personEmployerActivityUploadSearchForm") PersonEmployerActivityUploadSearchForm form, ModelMap modelMap, HttpServletRequest request) throws Exception {
        return performPaginationAction(form, modelMap);
    }

    private String performPaginationAction(PersonEmployerActivityUploadSearchForm form, ModelMap modelMap) throws BPMException, ParseException {
        setGroupActivityProgressionTrackerPagination(modelMap, getUserSession(), form.getActionType(), false);
        populateSelects(modelMap);
        return "personEmployerActivityUploadSearch";
    }

    private void loadInitial(ModelMap modelMap) throws BPMException {
        PersonEmployerActivityUploadSearchForm form = new PersonEmployerActivityUploadSearchForm();
        form.setControlGroupNo("select");
        form.setTrackingStatusId("select");
        modelMap.put("personEmployerActivityUploadSearchForm", form);

        getUserSession().reset();

        populateSelects(modelMap);

        LookUpValueCode emplUploadPreprocess = memberService.getLUVCodeByGroupNValue(BPMConstants.UPL_EMPL_TRACK_STAT_GROUP, BPMConstants.UPL_EMPL_PREPROCESS_STATUS);
        Integer preprocessTrackingStatusId = emplUploadPreprocess.getLuvId();

        LookUpValueCode emplUploadInprocess = memberService.getLUVCodeByGroupNValue(BPMConstants.UPL_EMPL_TRACK_STAT_GROUP, BPMConstants.UPL_EMPL_INPROCESS_STATUS);
        Integer inprocessTrackingStatusId = emplUploadInprocess.getLuvId();

        ArrayList<GroupActivityProgressTracker> lGroupActivityProgressTrackersAll = new ArrayList<>();
        ArrayList<GroupActivityProgressTracker> lGroupActivityProgressTrackersPreprocess = (ArrayList<GroupActivityProgressTracker>)groupActivityProgressTrackerDAO.getGroupActivityProgressionTracker(null, null, null, preprocessTrackingStatusId);

        ArrayList<GroupActivityProgressTracker> lGroupActivityProgressTrackersInprocess = (ArrayList<GroupActivityProgressTracker>)groupActivityProgressTrackerDAO.getGroupActivityProgressionTracker(null, null, null, inprocessTrackingStatusId);

        lGroupActivityProgressTrackersAll.addAll(lGroupActivityProgressTrackersPreprocess);
        lGroupActivityProgressTrackersAll.addAll(lGroupActivityProgressTrackersInprocess);

        setActionStatusAll(lGroupActivityProgressTrackersAll, BPMConstants.UPL_EMPL_SUBMIT_STATUS);

        getUserSession().setGroupActivityProgressTrackers(lGroupActivityProgressTrackersAll);

        modelMap.put("groupActivityProgressTrackers", lGroupActivityProgressTrackersAll);

        setAttributesPaginationBackNextButtonsToDisableOnModel(modelMap, getUserSession());
    }

    private void populateSelects(ModelMap modelMap) throws BPMException {
        if (CollectionUtils.isEmpty(getUserSession().getEmployerUploadTrackingStatusCodes())) {
            ArrayList<LookUpValueCode> lLuvEmployerUploadTrackingStatusCodes = (ArrayList<LookUpValueCode>) memberService.getLUVCodesByGroup(BPMConstants.UPL_EMPL_TRACK_STAT_GROUP);
            getUserSession().setEmployerUploadTrackingStatusCodes(lLuvEmployerUploadTrackingStatusCodes);
        }
        if (CollectionUtils.isEmpty(getUserSession().getControlGroupsIOFileDirSetup())) {
            LookUpValueCode uploadEmployerGroupLuv =  memberService.getLUVCodeByGroupNValue(BPMAdminConstants.CNTRL_GRP_RT_TYPE, BPMAdminConstants.UPL_EMPLOYER_SPONSORED);
            Integer routingTypeId = uploadEmployerGroupLuv.getLuvId();
            ArrayList<ControlGroupIOFileDirSetup> lControlGroupsIOFileDirSetup = (ArrayList<ControlGroupIOFileDirSetup>)controlGroupIOFileDirSetupDAO.getControlGroupsIOFileDirSetup(routingTypeId);
            getUserSession().setControlGroupsIOFileDirSetup(lControlGroupsIOFileDirSetup);
        }

        modelMap.put("trackingStatusCodes", getUserSession().getEmployerUploadTrackingStatusCodes());
        modelMap.put("groupNames", getUserSession().getControlGroupsIOFileDirSetup());
    }

    private void setActionStatusAll(Collection<GroupActivityProgressTracker> lGroupActivityProgressTrackers, String actionStatus) {
        for (GroupActivityProgressTracker lGroupActivityProgressTracker : lGroupActivityProgressTrackers) {
            lGroupActivityProgressTracker.setActionStatus(actionStatus);
        }
    }

    private void search(PersonEmployerActivityUploadSearchForm form, ModelMap modelMap) throws ParseException {
        Date batchDate = BPMAdminUtils.convertStringToSqlDate(form.getBatchDate(), BPMAdminConstants.HP_BPM_ADMIN_UI_DATE_FORMAT_yyyy_MM_dd);
        String groupNo = "select".equals(form.getControlGroupNo()) ? null : form.getControlGroupNo();
        String fileName = form.getFileName();
        Integer trackingStatusId = Integer.valueOf(form.getTrackingStatusId());

        ArrayList<GroupActivityProgressTracker> groupActivityProgressTrackers = (ArrayList<GroupActivityProgressTracker>)
                groupActivityProgressTrackerDAO.getGroupActivityProgressionTracker(groupNo, fileName, batchDate, trackingStatusId);

        setActionStatusAll(groupActivityProgressTrackers, BPMConstants.UPL_EMPL_SUBMIT_STATUS);

        getUserSession().setGroupActivityProgressTrackers(groupActivityProgressTrackers);

        if(groupActivityProgressTrackers.size() < 1) {
            createNoResultsFoundMessageOnModel(modelMap);
        }
        modelMap.put("groupActivityProgressTrackers", getUserSession().getGroupActivityProgressTrackers());
        setGroupActivityProgressionTrackerPagination(modelMap, getUserSession(), form.getActionType(), true);
    }

    private void performSave(PersonEmployerActivityUploadSearchForm form, ModelMap modelMap) throws IOException, BPMException {
        boolean updatesDetected = false;
        String[] filenames = form.getFilenames();
        Integer[] uids = form.getUids();
        String[] statusTrackingIDs = form.getTrackingStatusIDs();
        String[] postprocessCounts = form.getPostprocessCounts();
        String[] postprocessAmounts = form.getPostprocessAmounts();
        String[] trackingReasons = form.getTrackingReasons();

        updatesDetected = updateWithTrackingStatusChange(uids, filenames, statusTrackingIDs, postprocessCounts, postprocessAmounts, trackingReasons, getUserSessionSupport().getAuthenticatedUsername());
        if (updatesDetected) {
            //SEND MESSAGE THAT UPDATE WAS SUCCESSFUL
            createActionMessagesOnModel(modelMap, "Tracking record update successful.");
        } else {
            createActionMessagesOnModel(modelMap, "No Tracking records updated.");
        }

        modelMap.put("groupActivityProgressTrackers", getUserSession().getGroupActivityProgressTrackers());
        populateSelects(modelMap);
    }

    private boolean updateWithTrackingStatusChange(Integer[] uids, String[] filenames, String[] statusTrackingIDs, String[] postprocessCounts, String[] postprocessAmounts, String[] trackingReasons, String pUserID) throws BPMException, DataAccessException, IOException {
        boolean updatesDetected = false;
        ArrayList<GroupActivityProgressTracker> lGroupActivityProgressTrackersToRemove = new ArrayList<>();
        Collection<GroupActivityProgressTracker> lGroupActivityProgressTrackers = getUserSession().getGroupActivityProgressTrackers();

        for (GroupActivityProgressTracker lGroupActivityProgressTracker : lGroupActivityProgressTrackers) {

            for (int i = 0; i < uids.length; i++) {
                if (lGroupActivityProgressTracker.getUid().intValue() == Integer.valueOf(uids[i])) {

                    String[] lStatusTrackingIDAndValue = statusTrackingIDs[i].split("-");
                    String lStatusTrackingID = lStatusTrackingIDAndValue[0];
                    String lStatusTrackingValue = lStatusTrackingIDAndValue[1];

                    groupActivityProgressTrackerDAO.updateGroupActivityProgressionTrackerStatus(uids[i], Integer.parseInt(lStatusTrackingID), Integer.valueOf(postprocessCounts[i]),
                            Integer.valueOf(postprocessAmounts[i]), trackingReasons[i], pUserID);

                    if (lGroupActivityProgressTracker.getTrackingStatusID().intValue() == Integer.parseInt(lStatusTrackingID)) {
                        lGroupActivityProgressTracker.setPostprocessCount(Integer.valueOf(postprocessCounts[i]));
                        lGroupActivityProgressTracker.setPostprocessAmount(Integer.valueOf(postprocessAmounts[i]));
                        lGroupActivityProgressTracker.setTrackingReason(trackingReasons[i]);
                    } else {
                        //tracking status changed so remove from the original list.
                        lGroupActivityProgressTrackersToRemove.add(lGroupActivityProgressTracker);
                    }
                    updatesDetected = true;

                    // EV 95453 If status tracking is POSTPROCESS, move the file
                    if (BPMConstants.UPL_EMPL_POSTPROCESS_STATUS.equalsIgnoreCase(lStatusTrackingValue)) {
                        moveFile(filenames[i]);
                    }
                }

            }
        }

        for (GroupActivityProgressTracker lGroupActivityProgressTrackerToRemove : lGroupActivityProgressTrackersToRemove) {
            getUserSession().getGroupActivityProgressTrackers().remove(lGroupActivityProgressTrackerToRemove);
        }

        return updatesDetected;
    }

    /**
     * Migrate files from preprocess to post process after a file was forced to balance
     *
     * @param pFileName
     * @throws IOException
     */
    private void moveFile(String pFileName) throws IOException {
        // EV 95453 migrate files from preprocess to post process after a file was forced to balance
        String lFromPath = null;
        String lToPath = null;

        ArrayList<ControlGroupIOFileDirSetup> lControlGroupsIOFileDirSetups = getUserSession().getControlGroupsIOFileDirSetup();

        if (pFileName.contains(BPMAdminConstants.TARGET_FILE_NAME_PREFIX)) {
            for (ControlGroupIOFileDirSetup lControlGroupIOFileDirSetup : lControlGroupsIOFileDirSetups) {
                if (BPMAdminConstants.GROUP_NAME_TARGET.equals(lControlGroupIOFileDirSetup.getGroupName())) {
                    lFromPath = lControlGroupIOFileDirSetup.getInputFileLocPreprocess();
                    lToPath = lControlGroupIOFileDirSetup.getInputFileLocProcessed();
                    break;
                }
            }
        } else if (pFileName.contains(BPMAdminConstants.WELLSFARGO_FILE_NAME_PREFIX)) {
            for (ControlGroupIOFileDirSetup lControlGroupIOFileDirSetup : lControlGroupsIOFileDirSetups) {
                if (BPMAdminConstants.GROUP_NAME_WELLSFARGO.equals(lControlGroupIOFileDirSetup.getGroupName())) {
                    lFromPath = lControlGroupIOFileDirSetup.getInputFileLocPreprocess();
                    lToPath = lControlGroupIOFileDirSetup.getInputFileLocProcessed();
                    break;
                }
            }
        }

        if (lFromPath.contains("..") || lFromPath.contains("/") || lFromPath.contains("\\")) {
            throw new IllegalArgumentException("Invalid source path");
        }

        if (lToPath.contains("..") || lToPath.contains("/") || lToPath.contains("\\")) {
            throw new IllegalArgumentException("Invalid destination path");
        }

        if (pFileName.contains("..") || pFileName.contains("/") || pFileName.contains("\\")) {
            throw new IllegalArgumentException("Invalid filename");
        }

        Path movefrom = FileSystems.getDefault().getPath(lFromPath, pFileName);
        Path moveTo = FileSystems.getDefault().getPath(lToPath, pFileName);
        if (pFileName.matches("\\w*") && lFromPath.matches("\\w*") && lToPath.matches("\\w*")) {
            logger.info("--- Moving " + pFileName + ", from " + lFromPath + " to " + lToPath);
        }

        Files.move(movefrom, moveTo, StandardCopyOption.REPLACE_EXISTING);
    }

    private void performSubmitAction(PersonEmployerActivityUploadSearchForm form, ModelMap modelMap, String actionType, String pControlGroupNo, String pBatchDate, String pTrackingStatusId, String pFileName) {
        boolean newDTOList = false;
        String userId = getUserSessionSupport().getAuthenticatedUsername();

        String groupNo = pControlGroupNo;
        if (groupNo.equals(BPMAdminConstants.BPM_DEFAULT_SELECT_IN_DROPDOWN)) {
            groupNo = null;
        }
        String trackingStatusIDStr = pTrackingStatusId;
        String fileName = pFileName;
        String batchDateStr = pBatchDate;

        Date batchDate = null;
        if (batchDateStr !=null) {
            batchDate = BPMAdminUtils.convertStringToSqlDate(batchDateStr, BPMAdminConstants.HP_BPM_ADMIN_UI_DATE_FORMAT_yyyy_MM_dd);
            batchDateStr = BPMAdminUtils.getStringDateFromSqlDate(batchDate);
        }

        Integer trackingStatusID = null;
        if (trackingStatusIDStr != null && BPMAdminUtils.isValueInteger(trackingStatusIDStr)) {
            trackingStatusID = Integer.valueOf(trackingStatusIDStr);
        }

        groupNo = form.getControlGroupNo();
        trackingStatusIDStr  = form.getTrackingStatusId();
        if (trackingStatusIDStr != null) {
            trackingStatusID = Integer.valueOf(trackingStatusIDStr);
        }
        fileName = form.getFileName();
        batchDateStr = form.getBatchDate();
        if (batchDateStr !=null) {
            batchDate = BPMAdminUtils.convertStringToSqlDate(batchDateStr, BPMAdminConstants.HP_BPM_ADMIN_UI_DATE_FORMAT_yyyy_MM_dd);
            batchDateStr = BPMAdminUtils.getStringDateFromSqlDate(batchDate);
        }

        Collection<GroupActivityProgressTracker> lGroupActivityProgressTrackers = groupActivityProgressTrackerDAO.getGroupActivityProgressionTracker(groupNo, fileName, batchDate, trackingStatusID);

        for (GroupActivityProgressTracker lGroupActivityProgressTracker : lGroupActivityProgressTrackers) {
            StatusCalculationCommand statusCalculationCommand = new StatusCalculationCommand();
            if (lGroupActivityProgressTracker.getTrackingStatusCode().equals(StatusCalculationCommand.EMPLOYER_ACTIVITY_PREPROCESS)) {
                statusCalculationCommand.setUploadEmployerActivityPreprocess();
                statusCalculationCommand
                        .setCurrentProcessingCommand(StatusCalculationCommand.UPLOAD_EMPLOYER_ACTIVITY_PREPROCESS);
                statusCalculationCommand.setBatchSizeCommand(DEFAULT_BATCH_SIZE);

                statusCalculationCommand.setUserID(userId);

                //send message to kickoff Employer Sponsored Activity Upload Preprocess job
                //memberService.sendJMSCommand(statusCalculationCommand);
            }

            if (lGroupActivityProgressTracker.getTrackingStatusCode().equals(StatusCalculationCommand.EMPLOYER_ACTIVITY_INPROCESS)) {
                statusCalculationCommand.setUploadEmployerActivityPostprocess();
                statusCalculationCommand
                        .setCurrentProcessingCommand(StatusCalculationCommand.UPLOAD_EMPLOYER_ACTIVITY_POSTPROCESS);
                statusCalculationCommand.setBatchSizeCommand(DEFAULT_BATCH_SIZE);

                statusCalculationCommand.setUserID(userId);

                //send message to kickoff Employer Sponsored Activity Upload Postprocess job
                //memberService.sendJMSCommand(statusCalculationCommand);
            }
            setActionStatus(getUserSession().getGroupActivityProgressTrackers(), groupNo, fileName, batchDate, trackingStatusID, BPMConstants.UPL_EMPL_SUBMITTED_STATUS);
        }

        modelMap.put("trackingStatusCodes", getUserSession().getEmployerUploadTrackingStatusCodes());
        modelMap.put("groupActivityProgressTrackers", getUserSession().getGroupActivityProgressTrackers());

        getUserSession().setGroupNo(groupNo);
        getUserSession().setTrackingStatusId(trackingStatusID);
        getUserSession().setBatchDate(batchDateStr);
        getUserSession().setFileName(fileName);

        setGroupActivityProgressionTrackerPagination(modelMap, getUserSession(), actionType, newDTOList);

        modelMap.put("batchDate", batchDateStr);
        modelMap.put("groupActivityProgressTrackers", getUserSession().getGroupActivityProgressTrackers());

        getUserSession().setPersonEmployerActivityUploadSearchForm(form);
    }

    private void setActionStatus(ArrayList<GroupActivityProgressTracker> groupActivityProgressTrackers, String groupNo, String fileName, Date batchDate, Integer trackingStatusID, String status) {
        if (groupActivityProgressTrackers != null && groupActivityProgressTrackers.size() > 0) {
            for (GroupActivityProgressTracker lGroupActivityProgressTracker : groupActivityProgressTrackers) {
                if (lGroupActivityProgressTracker.getGroupNo().equals(groupNo) &&
                        lGroupActivityProgressTracker.getInputFileName().equals(fileName) &&
                        lGroupActivityProgressTracker.getBatchDate().equals(batchDate) &&
                        lGroupActivityProgressTracker.getTrackingStatusID().equals(trackingStatusID)) {
                    lGroupActivityProgressTracker.setActionStatus(status);
                    break;
                }
            }
        }
    }

    /**
     * Determine the size of the Group Activity Progression Tracker array list and the number of rows
     * to be displayed per page.
     *
     * @param modelMap
     * @param sessionBean
     * @param actionType
     * @param newDTOList
     */
    private void setGroupActivityProgressionTrackerPagination(ModelMap modelMap, UserSession sessionBean, String actionType, boolean newDTOList) {
        ArrayList<GroupActivityProgressTracker> lGroupActivityProgressTrackerList = sessionBean.getGroupActivityProgressTrackers();

        /**
         * Create a Pageable wrapper for the array list.
         * Create a Pagination object and point it to the wrapper.
         */
        BPMPagination pagination = sessionBean.getPaginationMap().get(GROUP_ACTIVITY_PROGRESS_TRACKER_LIST);
        PageableGroupActivityProgressTracker lPageableGroupActivityProgressTracker = null;
        if (pagination == null || newDTOList) {
            lPageableGroupActivityProgressTracker = new PageableGroupActivityProgressTracker(lGroupActivityProgressTrackerList);
            lPageableGroupActivityProgressTracker.addRowNumber();
            pagination = new BPMPagination(lPageableGroupActivityProgressTracker, new ArrayList<Object>(lGroupActivityProgressTrackerList), MAX_RECS_PER_PAGE);
            sessionBean.getPaginationMap().put(GROUP_ACTIVITY_PROGRESS_TRACKER_LIST, pagination);
        }

        ArrayList<GroupActivityProgressTracker> lGroupActivityProgressTrackersPerPage = (ArrayList<GroupActivityProgressTracker>) determineNextOrBackAction(actionType, pagination);
        setAttributesForPaginationOnModel(modelMap, lGroupActivityProgressTrackerList.size(), pagination);
        sessionBean.setPagination(pagination);

        modelMap.put("groupActivityProgressTrackers", lGroupActivityProgressTrackersPerPage);

        sessionBean.setGroupActivityProgressTrackersPerPage(lGroupActivityProgressTrackersPerPage);
        sessionBean.setGroupActivityProgressTrackers(lGroupActivityProgressTrackerList);
    }

    @Override
    public boolean supports(Class<?> clazz) {
        return PersonCDHPFulfillRecycleSearchForm.class.isAssignableFrom(clazz);
    }

    @Override
    public void validate(Object target, Errors errors) {
        PersonEmployerActivityUploadSearchForm form = (PersonEmployerActivityUploadSearchForm) target;

        if (form.getTrackingStatusId().equals("select")) {
            form.setTrackingStatusId("");
        }

        getValidationSupport().validateRequiredFieldIsNotEmpty("trackingStatusId", form.getTrackingStatusId(), errors, new Object[]{"Tracking Status"});

        if (StringUtils.isNotEmpty(form.getBatchDate())) {
            getValidationSupport().validateDateFormat("batchDate", form.getBatchDate(), errors, new Object[]{"Batch Date"});
        }
    }

}
