package com.healthpartners.app.bpm.dto;

import com.healthpartners.app.bpm.common.BPMAdminUtils;

import java.io.Serializable;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

/**
 * 
 * @author jxbourbour
 * 
 */
public class ParticipationGroup implements Serializable {
	static final long serialVersionUID = 0L;

	private Integer participationGroupID;
	private String participationGroupName;
	private String participationGroupInfo;
	private String participationGroupDesc;
	private Date effectiveDate;
	private Date endDate;
	private boolean used;

	private String effectiveDateString;
	private String endDateString;

	private List<ParticipationGroupRequirement> participationGroupRequirements = new ArrayList<ParticipationGroupRequirement>();

	public ParticipationGroup() {
		super();
	}

	public final Integer getParticipationGroupID() {
		return participationGroupID;
	}

	public final void setParticipationGroupID(Integer participationGroupID) {
		this.participationGroupID = participationGroupID;
	}

	public final String getParticipationGroupName() {
		return participationGroupName;
	}

	public final void setParticipationGroupName(String participationGroupName) {
		this.participationGroupName = participationGroupName;
	}

	public final String getParticipationGroupInfo() {
		return participationGroupInfo;
	}

	public final void setParticipationGroupInfo(String participationGroupInfo) {
		this.participationGroupInfo = participationGroupInfo;
	}

	public final String getParticipationGroupDesc() {
		return participationGroupDesc;
	}

	public final void setParticipationGroupDesc(String participationGroupDesc) {
		this.participationGroupDesc = participationGroupDesc;
	}

	public final Date getEffectiveDate() {
		return effectiveDate;
	}

	public final void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
		effectiveDateString = BPMAdminUtils.formatDateMMddyyyy(effectiveDate);
	}

	public final Date getEndDate() {
		return endDate;
	}

	public final void setEndDate(Date endDate) {
		this.endDate = endDate;
		endDateString = BPMAdminUtils.formatDateMMddyyyy(endDate);
	}

	public final String getEffectiveDateString() {
		return effectiveDateString;
	}

	public final void setEffectiveDateString(String effectiveDateString) {
		this.effectiveDateString = effectiveDateString;
		effectiveDate = BPMAdminUtils.getSqlDateFromString(effectiveDateString);
	}

	public final String getEndDateString() {
		return endDateString;
	}

	public final void setEndDateString(String endDateString) {
		this.endDateString = endDateString;
		endDate = BPMAdminUtils.getSqlDateFromString(endDateString);
	}

	public final List<ParticipationGroupRequirement> getParticipationGroupRequirements() {
		return participationGroupRequirements;
	}

	public final void setParticipationGroupRequirements(
			List<ParticipationGroupRequirement> participationGroupRequirements) {
		this.participationGroupRequirements = participationGroupRequirements;
	}

	public boolean isUsed() {
		return used;
	}

	public void setUsed(boolean used) {
		this.used = used;
	}

	public boolean isPersistent() {
		return participationGroupID != null && participationGroupID > 0;
	}
}
