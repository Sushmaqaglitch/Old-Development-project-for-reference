package com.healthpartners.app.bpm.dao;

import com.healthpartners.app.bpm.common.BPMAdminConstants;
import com.healthpartners.app.bpm.dto.CDHPFulfillmentSearch;
import com.healthpartners.app.bpm.dto.CDHPFulfillmentTrackingReportHist;
import com.healthpartners.app.bpm.exception.BPMException;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import jakarta.annotation.PostConstruct;
import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Collection;

/**
 * @author tjquist
 */
@Repository
@Transactional(timeout = 300, rollbackFor = {DataAccessException.class, BPMException.class})
public class CDHPFulfillmentRptDAOJdbc extends JdbcDaoSupport implements CDHPFulfillmentRptDAO {

    private static final String selectCDHPFulfillmentTrackingReportHist = "select " +
			"         t.cdhp_txn_hist_id, " +
			"         t.biz_pgm_id, " +
			"         bp.grp_id, " +
			"         egs.empl_grp_no, " +
			"         egs.empl_grp_site_id_no, " +
			"         t.contract_no, " +
			"         t.prsn_dmgrphcs_id, " +
			"         pd.hp_mem_id, " +
			"         pd.first_nm, " +
			"         pd.last_nm, " +
			"         t.purch_sub_tp_nm, " +
			"         bp.contribution_start_dt, " +
			"         bp.contribution_end_dt, " +
			"         t.contrib_amt, " +
			"         t.tier_contrib_id, " +
			"         t.contrib_dt, " +
			"         t.actv_id, " +
			"         (select l.actv_nm from activity l where l.actv_id = t.actv_id) activity_name,  " +
			"         a.srce_actv_id, " +
			"         t.incntv_optn_id, " +
			"         t.file_sent_dt, " +
			"         (select l.lu_desc from luv l where l.lu_id = bp_io.incntv_rpt_desc_id) incntv_rpt_name  " +
			"      from cdhp_fulfill_rpt_tracking_hist t, " +
			"           business_program bp, " +
			"           biz_pgm_incentive_option bp_io, " +
			"           empl_grp_site egs, " +
			"           activity a, " +
			"           prsn_demographics pd " +
			"         where " +
			"               t.biz_pgm_id = bp.biz_pgm_id " +
			"          AND  bp.grp_id = egs.grp_id " +
			"          AND  bp.subgrp_id = egs.subgrp_id " +
			"          AND  t.actv_id = a.actv_id " +
			"          AND  bp.biz_pgm_id = bp_io.biz_pgm_id " +
			"          AND  bp_io.incntv_optn_id = t.incntv_optn_id " +
			"          AND  pd.prsn_dmgrphcs_id = t.prsn_dmgrphcs_id";

    private static final String selectCDHPFulfillmentTrackingReport = "select " +
			"distinct " +
			"t.cdhp_txn_id, " +
			"t.biz_pgm_id, " +
			"bp.grp_id, " +
			"egs.empl_grp_no, " +
			"egs.empl_grp_site_id_no, " +
			"egs.empl_grp_rpt_nm, " +
			"t.purch_sub_tp_nm, " +
			"t.contract_no, " +
			"bp.contribution_start_dt, " +
			"bp.contribution_end_dt, " +
			"t.contrib_amt, " +
			"t.tier_contrib_id, " +
			"(select l.lu_val from luv l where l.lu_id = io.incntv_optn_tp_cd_id) contributionType, " +
			"t.contrib_dt, " +
			"t.mem_count, " +
			"t.file_sent_dt, " +
			"(select l.lu_val from luv l where l.lu_id = bp_io.fulfillment_rtng_tp_cd_id) fulfillment_rtng_tp, " +
			"(select l.lu_desc from luv l where l.lu_id = bp_io.incntv_rpt_desc_id) incntv_rpt_name " +
			" " +
			"from cdhp_fulfill_rpt_tracking t, " +
			"cdhp_fulfill_rpt_tracking_hist cfrth, " +
			"business_program bp, " +
			"biz_pgm_incentive_option bp_io, " +
			"empl_grp_site egs, " +
			"incentive_option io, " +
			"PRSN_DEMOGRAPHICS pd " +
			"where " +
			"t.biz_pgm_id = bp.biz_pgm_id " +
			"AND  bp.grp_id = egs.grp_id " +
			"AND  bp.subgrp_id = egs.subgrp_id " +
			"AND  bp.biz_pgm_id = bp_io.biz_pgm_id " +
			"AND  bp_io.incntv_optn_id = t.incntv_optn_id " +
			"AND  t.incntv_optn_id = io.incntv_optn_id " +
			"AND t.BIZ_PGM_ID = cfrth.BIZ_PGM_ID " +
			"AND pd.PRSN_DMGRPHCS_ID = cfrth.PRSN_DMGRPHCS_ID " +
			"AND t.PURCH_SUB_TP_NM = cfrth.PURCH_SUB_TP_NM " +
			"AND trunc(t.FILE_SENT_DT) = trunc(cfrth.FILE_SENT_DT) " +
			"AND t.INCNTV_OPTN_ID = cfrth.INCNTV_OPTN_ID " +
			"AND t.CONTRACT_NO = cfrth.CONTRACT_NO";

	private final DataSource dataSource;

	public CDHPFulfillmentRptDAOJdbc(DataSource dataSource) {
		this.dataSource = dataSource;
	}

	@PostConstruct
	private void initialize() {
		setDataSource(dataSource);
	}

    //Produces warnings during compile time to quickly identify typos or API changes
    @Override
    public Collection<CDHPFulfillmentTrackingReportHist> getCDHPFulfillmentTrackingReportHist(CDHPFulfillmentSearch lCDHPFulfillmentSearch)
            throws DataAccessException {

        final ArrayList<CDHPFulfillmentTrackingReportHist> lCDHPFulfillmentTrackingReportsHist = new ArrayList<CDHPFulfillmentTrackingReportHist>();
        ArrayList<Object> lParameters = new ArrayList<Object>();
        ArrayList<Integer> lTypes = new ArrayList<Integer>();
        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectCDHPFulfillmentTrackingReportHist);
        JdbcTemplate template = getJdbcTemplate();


        if (lCDHPFulfillmentSearch.getGroupNo() != null && lCDHPFulfillmentSearch.getGroupNo().length() > 0) {
            lQuery.append(" AND egs.empl_grp_no = ?");
            lParameters.add(lCDHPFulfillmentSearch.getGroupNo());
            lTypes.add(Integer.valueOf(Types.VARCHAR));
        }

        if (lCDHPFulfillmentSearch.getGroupName() != null && lCDHPFulfillmentSearch.getGroupName().length() > 0) {
            lQuery.append(" AND egs.empl_grp_nm like upper(?)");
            lParameters.add("%" + lCDHPFulfillmentSearch.getGroupName() + "%");
            lTypes.add(Integer.valueOf(Types.VARCHAR));
        }

        if (lCDHPFulfillmentSearch.getSiteNo() != null && lCDHPFulfillmentSearch.getSiteNo().length() > 0) {
            lQuery.append(" AND egs.empl_grp_site_id_no = ?");
            lParameters.add(lCDHPFulfillmentSearch.getSiteNo());
            lTypes.add(Integer.valueOf(Types.VARCHAR));
        }

        if (lCDHPFulfillmentSearch.getContractNo() != null && lCDHPFulfillmentSearch.getContractNo().length() > 0) {
            lQuery.append(" AND t.contract_no = ?");
            lParameters.add(lCDHPFulfillmentSearch.getContractNo());
            lTypes.add(Integer.valueOf(Types.VARCHAR));
        }

        if (lCDHPFulfillmentSearch.getMemberNo() != null && lCDHPFulfillmentSearch.getMemberNo().length() > 0) {
            lQuery.append(" AND pd.hp_mem_id = ?");
            lParameters.add(lCDHPFulfillmentSearch.getMemberNo());
            lTypes.add(Integer.valueOf(Types.VARCHAR));
        }

        if (lCDHPFulfillmentSearch.getProgramStartDate() != null) {
            lQuery.append(" AND bp.eff_dt = ?");
            lParameters.add(lCDHPFulfillmentSearch.getProgramStartDate());
            lTypes.add(Integer.valueOf(Types.DATE));
        }
        if (lCDHPFulfillmentSearch.getFileSentFromDate() != null && lCDHPFulfillmentSearch.getFileSentToDate() != null) {
            lQuery.append(" AND trunc(t.file_sent_dt) >= ? AND trunc(t.file_sent_dt) <= ?");
            lParameters.add(lCDHPFulfillmentSearch.getFileSentFromDate());
            lParameters.add(lCDHPFulfillmentSearch.getFileSentToDate());
            lTypes.add(Integer.valueOf(Types.DATE));
            lTypes.add(Integer.valueOf(Types.DATE));
        } else if (lCDHPFulfillmentSearch.getFileSentFromDate() != null) {
            lQuery.append(" AND trunc(t.file_sent_dt) = ?");
            lParameters.add(lCDHPFulfillmentSearch.getFileSentFromDate());
            lTypes.add(Integer.valueOf(Types.DATE));
        }

        if (lCDHPFulfillmentSearch.getProductType() != null && lCDHPFulfillmentSearch.getProductType().length() > 0) {
            if (lCDHPFulfillmentSearch.getProductType().equals(BPMAdminConstants.GROUP_PRODUCT_TYPE_ALL)) {

            } else {
                lQuery.append(" AND t.purch_sub_tp_nm = ?");
                lParameters.add(lCDHPFulfillmentSearch.getProductType());
                lTypes.add(Integer.valueOf(Types.VARCHAR));
            }
        }
        if (lCDHPFulfillmentSearch.getCdhpTableType().equals(BPMAdminConstants.CDHP_TABLE_TYPE_FULFILL_HIST)) {
            lQuery.append(" order by t.file_sent_dt desc, egs.empl_grp_no, egs.empl_grp_site_id_no, pd.hp_mem_id, activity_name, t.contrib_dt, t.contrib_amt");
        } else {
            lQuery.append(" order by t.file_sent_dt desc, egs.empl_grp_no, egs.empl_grp_site_id_no, t.contract_no, t.contrib_dt, t.contrib_amt");
        }

        // Convert the parameter arraylists to arrays.
        Object params[] = new Object[lParameters.size()];
        lParameters.toArray(params);

        int types[] = new int[lTypes.size()];
        for (int j = 0; j < lTypes.size(); j++) {
            types[j] = ((Integer) lTypes.get(j)).intValue();
        }

        template.query(lQuery.toString(), params, types,
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        CDHPFulfillmentTrackingReportHist lCDHPFulfillmentTrackingReportHist = new CDHPFulfillmentTrackingReportHist();
                        lCDHPFulfillmentTrackingReportHist.setCdhpTransID(rs.getInt("cdhp_txn_hist_id"));
                        lCDHPFulfillmentTrackingReportHist.setProgramID(rs.getInt("biz_pgm_id"));
                        lCDHPFulfillmentTrackingReportHist.setGroupID(rs.getInt("grp_id"));
                        lCDHPFulfillmentTrackingReportHist.setGroupNo(rs.getString("empl_grp_no"));
                        lCDHPFulfillmentTrackingReportHist.setSiteNo(rs.getString("empl_grp_site_id_no"));
                        lCDHPFulfillmentTrackingReportHist.setContractNo(rs.getInt("contract_no"));
                        lCDHPFulfillmentTrackingReportHist.setPersonDemographicsID(rs.getInt("prsn_dmgrphcs_id"));
                        lCDHPFulfillmentTrackingReportHist.setMemberNo(rs.getString("hp_mem_id"));
                        lCDHPFulfillmentTrackingReportHist.setFirstName(rs.getString("first_nm"));
                        lCDHPFulfillmentTrackingReportHist.setLastName(rs.getString("last_nm"));
                        lCDHPFulfillmentTrackingReportHist.setContributionStartDate(rs.getDate("contribution_start_dt"));
                        lCDHPFulfillmentTrackingReportHist.setContributionEndDate(rs.getDate("contribution_end_dt"));
                        lCDHPFulfillmentTrackingReportHist.setContributionAmount(rs.getInt("contrib_amt"));
                        lCDHPFulfillmentTrackingReportHist.setContributionTypeCodeId(rs.getInt("tier_contrib_id"));
                        lCDHPFulfillmentTrackingReportHist.setContributionDate(rs.getDate("contrib_dt"));
                        lCDHPFulfillmentTrackingReportHist.setFileSentDate(rs.getDate("file_sent_dt"));
                        lCDHPFulfillmentTrackingReportHist.setActivityID(rs.getInt("actv_id"));
                        lCDHPFulfillmentTrackingReportHist.setActivityName(rs.getString("activity_name"));
                        lCDHPFulfillmentTrackingReportHist.setSourceActivityID(rs.getString("srce_actv_id"));
                        lCDHPFulfillmentTrackingReportHist.setIncentiveReportName(rs.getString("incntv_rpt_name"));
                        lCDHPFulfillmentTrackingReportHist.setIncentiveOptionID(rs.getInt("incntv_optn_id"));
                        lCDHPFulfillmentTrackingReportHist.setPackageSubTypeName(rs.getString("purch_sub_tp_nm"));


                        lCDHPFulfillmentTrackingReportsHist.add(lCDHPFulfillmentTrackingReportHist);

                    }
                });


        return lCDHPFulfillmentTrackingReportsHist;
    }

    //Produces warnings during compile time to quickly identify typos or API changes
    @Override
    public Collection<CDHPFulfillmentTrackingReportHist> getCDHPFulfillmentTrackingReport(CDHPFulfillmentSearch lCDHPFulfillmentSearch)
            throws DataAccessException {

        final ArrayList<CDHPFulfillmentTrackingReportHist> lCDHPFulfillmentTrackingReports = new ArrayList<CDHPFulfillmentTrackingReportHist>();
        ArrayList<Object> lParameters = new ArrayList<Object>();
        ArrayList<Integer> lTypes = new ArrayList<Integer>();
        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectCDHPFulfillmentTrackingReport);
        JdbcTemplate template = getJdbcTemplate();


        if (lCDHPFulfillmentSearch.getGroupNo() != null && lCDHPFulfillmentSearch.getGroupNo().length() > 0) {
            lQuery.append(" AND egs.empl_grp_no = ?");
            lParameters.add(lCDHPFulfillmentSearch.getGroupNo());
            lTypes.add(Integer.valueOf(Types.VARCHAR));
        }

        if (lCDHPFulfillmentSearch.getGroupName() != null && lCDHPFulfillmentSearch.getGroupName().length() > 0) {
            lQuery.append(" AND egs.empl_grp_nm like upper(?)");
            lParameters.add("%" + lCDHPFulfillmentSearch.getGroupName() + "%");
            lTypes.add(Integer.valueOf(Types.VARCHAR));
        }

        if (lCDHPFulfillmentSearch.getSiteNo() != null && lCDHPFulfillmentSearch.getSiteNo().length() > 0) {
            lQuery.append(" AND egs.empl_grp_site_id_no = ?");
            lParameters.add(lCDHPFulfillmentSearch.getSiteNo());
            lTypes.add(Integer.valueOf(Types.VARCHAR));
        }

        if (lCDHPFulfillmentSearch.getContractNo() != null && lCDHPFulfillmentSearch.getContractNo().length() > 0) {
            lQuery.append(" AND t.contract_no = ?");
            lParameters.add(lCDHPFulfillmentSearch.getContractNo());
            lTypes.add(Integer.valueOf(Types.VARCHAR));
        }

        if (lCDHPFulfillmentSearch.getMemberNo() != null && lCDHPFulfillmentSearch.getMemberNo().length() > 0) {
            lQuery.append(" AND pd.HP_MEM_ID = ?");
            lParameters.add(lCDHPFulfillmentSearch.getMemberNo());
            lTypes.add(Integer.valueOf(Types.VARCHAR));
        }

        if (lCDHPFulfillmentSearch.getProgramStartDate() != null) {
            lQuery.append(" AND bp.eff_dt = ?");
            lParameters.add(lCDHPFulfillmentSearch.getProgramStartDate());
            lTypes.add(Integer.valueOf(Types.DATE));
        }

        if (lCDHPFulfillmentSearch.getFileSentFromDate() != null && lCDHPFulfillmentSearch.getFileSentToDate() != null) {
            lQuery.append(" AND trunc(t.file_sent_dt) >= ? AND trunc(t.file_sent_dt) <= ?");
            lParameters.add(lCDHPFulfillmentSearch.getFileSentFromDate());
            lParameters.add(lCDHPFulfillmentSearch.getFileSentToDate());
            lTypes.add(Integer.valueOf(Types.DATE));
            lTypes.add(Integer.valueOf(Types.DATE));
        } else if (lCDHPFulfillmentSearch.getFileSentFromDate() != null) {
            lQuery.append(" AND trunc(t.file_sent_dt) = ?");
            lParameters.add(lCDHPFulfillmentSearch.getFileSentFromDate());
            lTypes.add(Integer.valueOf(Types.DATE));
        }

        if (lCDHPFulfillmentSearch.getProductType() != null && lCDHPFulfillmentSearch.getProductType().length() > 0) {
            if (lCDHPFulfillmentSearch.getProductType().equals(BPMAdminConstants.GROUP_PRODUCT_TYPE_ALL)) {

            } else {
                lQuery.append(" AND t.purch_sub_tp_nm = ?");
                lParameters.add(lCDHPFulfillmentSearch.getProductType());
                lTypes.add(Integer.valueOf(Types.VARCHAR));
            }
        }

        lQuery.append(" order by t.file_sent_dt desc, t.contrib_dt desc, t.contract_no asc, egs.empl_grp_no asc");
        // Convert the parameter arraylists to arrays.
        Object params[] = new Object[lParameters.size()];
        lParameters.toArray(params);

        int types[] = new int[lTypes.size()];
        for (int j = 0; j < lTypes.size(); j++) {
            types[j] = ((Integer) lTypes.get(j)).intValue();
        }

        template.query(lQuery.toString(), params, types,
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        CDHPFulfillmentTrackingReportHist lCDHPFulfillmentTrackingReport = new CDHPFulfillmentTrackingReportHist();
                        lCDHPFulfillmentTrackingReport.setCdhpTransID(rs.getInt("cdhp_txn_id"));
                        lCDHPFulfillmentTrackingReport.setProgramID(rs.getInt("biz_pgm_id"));
                        lCDHPFulfillmentTrackingReport.setGroupID(rs.getInt("grp_id"));
                        lCDHPFulfillmentTrackingReport.setGroupNo(rs.getString("empl_grp_no"));
                        lCDHPFulfillmentTrackingReport.setSiteNo(rs.getString("empl_grp_site_id_no"));
                        lCDHPFulfillmentTrackingReport.setEmployerGroupName(rs.getString("empl_grp_rpt_nm"));
                        lCDHPFulfillmentTrackingReport.setContractNo(rs.getInt("contract_no"));
                        lCDHPFulfillmentTrackingReport.setContributionStartDate(rs.getDate("contribution_start_dt"));
                        lCDHPFulfillmentTrackingReport.setContributionEndDate(rs.getDate("contribution_end_dt"));
                        lCDHPFulfillmentTrackingReport.setContributionAmount(rs.getInt("contrib_amt"));
                        lCDHPFulfillmentTrackingReport.setContributionTypeCodeId(rs.getInt("tier_contrib_id"));
                        lCDHPFulfillmentTrackingReport.setContributionType(rs.getString("contributionType"));
                        lCDHPFulfillmentTrackingReport.setContributionDate(rs.getDate("contrib_dt"));
                        lCDHPFulfillmentTrackingReport.setMemberCount(rs.getInt("mem_count"));
                        lCDHPFulfillmentTrackingReport.setFileSentDate(rs.getDate("file_sent_dt"));
                        lCDHPFulfillmentTrackingReport.setIncentiveReportName(rs.getString("incntv_rpt_name"));
                        lCDHPFulfillmentTrackingReport.setFulfillmentRoutingType(rs.getString("fulfillment_rtng_tp"));
                        lCDHPFulfillmentTrackingReport.setPackageSubTypeName(rs.getString("purch_sub_tp_nm"));

                        lCDHPFulfillmentTrackingReports.add(lCDHPFulfillmentTrackingReport);

                    }
                });

        return lCDHPFulfillmentTrackingReports;
    }
}
