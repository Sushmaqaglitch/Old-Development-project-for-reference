package com.healthpartners.app.bpm.dao;

import com.healthpartners.app.bpm.dto.MemberProcessingStatusLog;
import com.healthpartners.app.bpm.exception.BPMException;
import jakarta.annotation.PostConstruct;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.jdbc.support.incrementer.DataFieldMaxValueIncrementer;
import org.springframework.jdbc.support.incrementer.OracleSequenceMaxValueIncrementer;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.sql.DataSource;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Collection;

/**
 * @author jxbourbour
 */
@Repository
@Transactional(timeout = 300, rollbackFor = {DataAccessException.class, BPMException.class})
public class ProcessingStatusLogDAOJdbc extends JdbcDaoSupport implements ProcessingStatusLogDAO {

    private static final String insertPersonProcessingStatusLog = """
            INSERT INTO PROCESSING_STATUS_LOG (PSL_ID, PRCS_ID, PRSN_ID, PRCS_COMPLETION_DT, PRCSNG_STAT_VAL, INSERT_USR, INSERT_TS) VALUES (?, ?,
            	      	(SELECT prsn_id FROM prsn_demographics WHERE PRSN_DMGRPHCS_ID=?), NULL, ?, ?, SYSDATE)
            """;

    private static final String selectPendingPersonsFromProcessingStatusLog = """
            SELECT log.PSL_ID, log.PRSN_ID, person.HP_MEM_ID, person.FIRST_NM, person.LAST_NM,
             log.INSERT_USR, log.INSERT_TS
             , person.PRSN_DMGRPHCS_ID
             FROM PROCESSING_STATUS_LOG log,  prsn_demographics   person
             WHERE log.PRCS_COMPLETION_DT IS NULL
             AND log.PRSN_ID = person.PRSN_ID
             AND PRCS_ID = ?
             AND (PRCSNG_STAT_VAL = 'PENDING' OR PRCSNG_STAT_VAL IS NULL)
             ORDER BY INSERT_TS DESC
            """;

    private static final String deleteProcessingPersonByID = """
            DELETE FROM PROCESSING_STATUS_LOG WHERE PSL_ID = ?
            """;

    private static final String selectCountProcessingStatusLog = """
            SELECT count('x') to_be_processed_count FROM processing_status_log WHERE prcs_completion_dt IS NULL	
                  """;

    private final DataSource dataSource;

    private DataFieldMaxValueIncrementer processingStatusLogIdIncrementer;

    private static final String PROCESSING_STATUS_LOG_SEQ = "PROCESSING_STATUS_LOG_SEQ";

    public ProcessingStatusLogDAOJdbc(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @PostConstruct
    private void initialize() {
        setDataSource(dataSource);
        processingStatusLogIdIncrementer = new OracleSequenceMaxValueIncrementer(dataSource, PROCESSING_STATUS_LOG_SEQ);
    }

    @Transactional(timeout = 300, rollbackFor = {DataAccessException.class, BPMException.class})
    @Override
    public long insertPersonProcessingStatusLog(Integer personId, Integer processId, String processingStatusValue, String userId)
            throws DataAccessException {
        // Retrieve the next sequence number .
        Long logId = processingStatusLogIdIncrementer.nextLongValue();

        // Persist
        JdbcTemplate template = getJdbcTemplate();

        Object params[] = new Object[]{logId, processId, personId,
                processingStatusValue, userId};

        int types[] = new int[]{Types.BIGINT, Types.INTEGER, Types.INTEGER,
                Types.VARCHAR, Types.VARCHAR};

        template.update(insertPersonProcessingStatusLog, params, types);

        return logId.longValue();
    }

    @Override
    public Collection<MemberProcessingStatusLog> getPendingPersonsFromProcessingStatusLog(int pProcessID) throws DataAccessException {
        final ArrayList<MemberProcessingStatusLog> results = new ArrayList<MemberProcessingStatusLog>();
        JdbcTemplate template = getJdbcTemplate();

        Object params[] = new Object[]{pProcessID};
        int types[] = new int[]{Types.INTEGER};

        template.query(selectPendingPersonsFromProcessingStatusLog, params,
                types, new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        MemberProcessingStatusLog procesStatus = new MemberProcessingStatusLog();
                        procesStatus
                                .setProcessLogID((rs.getObject("PRSN_DMGRPHCS_ID") != null) ? rs.getLong("PSL_ID")
                                        : null);
                        procesStatus
                                .setPersonID((rs.getObject("PRSN_DMGRPHCS_ID") != null) ? rs.getInt("PRSN_DMGRPHCS_ID")
                                        : null);
                        procesStatus.setMemberID(rs.getString("HP_MEM_ID"));
                        procesStatus.setFirstName(rs.getString("FIRST_NM"));
                        procesStatus.setLastName(rs.getString("LAST_NM"));
                        procesStatus.setInsertUser(rs.getString("INSERT_USR"));
                        procesStatus.setInsertDate(rs.getDate("INSERT_TS"));
                        results.add(procesStatus);
                    }
                });
        return results;
    }

    @Override
    public int[] deleteProcessingStatusLogRecords(Collection<Long> processLogIDs) throws DataAccessException {
        int[] numberOfRowsUpdated;
        final Object objs[] = processLogIDs.toArray();

        JdbcTemplate template = getJdbcTemplate();

        BatchPreparedStatementSetter setter = null;
        setter = new BatchPreparedStatementSetter() {
            public int getBatchSize() {
                return objs.length;
            }

            public void setValues(PreparedStatement ps, int index)
                    throws SQLException {
                Long processLogID = (Long) objs[index];
                ps.setLong(1, processLogID.longValue());
            }
        };
        numberOfRowsUpdated = template.batchUpdate(deleteProcessingPersonByID,
                setter);
        return numberOfRowsUpdated;
    }

    @Override
    public Collection<Integer> getNumberOfProcessingStatusLogPending() {
        final ArrayList<Integer> lNumberOfPending = new ArrayList<Integer>();
        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{};
        int types[] = new int[]{};

        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectCountProcessingStatusLog);
        lQuery.append(" AND PRCSNG_STAT_VAL = 'PENDING'");

        template.query(lQuery.toString(), params, types, new RowCallbackHandler() {
            public void processRow(ResultSet rs) throws SQLException {
                Integer lToBeProcessedCount = rs.getInt("to_be_processed_count");

                lNumberOfPending.add(lToBeProcessedCount);
            }
        });

        return lNumberOfPending;
    }

    @Override
    public Collection<Integer> getNumberOfProcessingStatusLogInProcess() {
        final ArrayList<Integer> lNumberOfPending = new ArrayList<Integer>();
        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{};
        int types[] = new int[]{};

        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectCountProcessingStatusLog);
        lQuery.append(" AND PRCSNG_STAT_VAL = 'IN_PROCESS'");

        template.query(lQuery.toString(), params, types, new RowCallbackHandler() {
            public void processRow(ResultSet rs) throws SQLException {
                Integer lToBeProcessedCount = rs.getInt("to_be_processed_count");

                lNumberOfPending.add(lToBeProcessedCount);
            }
        });

        return lNumberOfPending;
    }

}
