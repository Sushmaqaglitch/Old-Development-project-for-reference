package com.healthpartners.app.bpm.form;

/**
 * @author jxbourbour
 */
public class EditProgramActivityIncentiveForm extends BaseForm {

    private Integer programID;
    private Integer incentiveOptionID;
    private String actionType;
    private String groupNo;

    public EditProgramActivityIncentiveForm() {
        super();
    }

    public Integer getProgramID() {
        return programID;
    }

    public void setProgramID(Integer programID) {
        this.programID = programID;
    }

    public String getActionType() {
        return actionType;
    }

    public void setActionType(String actionType) {
        this.actionType = actionType;
    }

    public String getGroupNo() {
        return groupNo;
    }

    public void setGroupNo(String groupNo) {
        this.groupNo = groupNo;
    }

    public Integer getIncentiveOptionID() {
        return incentiveOptionID;
    }

    public void setIncentiveOptionID(Integer incentiveOptionID) {
        this.incentiveOptionID = incentiveOptionID;
    }
}
