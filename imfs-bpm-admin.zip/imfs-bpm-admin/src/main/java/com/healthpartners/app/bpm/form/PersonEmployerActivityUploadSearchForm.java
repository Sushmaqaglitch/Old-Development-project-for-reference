package com.healthpartners.app.bpm.form;

import com.healthpartners.app.bpm.dto.LookUpValueCode;

import java.util.ArrayList;

/**
 * @author tjquist
 *
 */
public class PersonEmployerActivityUploadSearchForm extends BaseForm {

    static final long serialVersionUID = 0L;

    private String controlGroupId;
    private String controlGroupName;
    private String controlGroupNo;
    private String batchDate;
    private String trackingStatusId;
    private String trackingStatusCode;
    private String fileName;
    private ArrayList<LookUpValueCode> trackingStatusCodes;
    private ArrayList<LookUpValueCode> controlGroups;

    private String actionType;

    private String[] filenames;
    private Integer[] uids;
    private String[] trackingStatusIDs;
    private String[] postprocessCounts;
    private String[] postprocessAmounts;
    private String[] trackingReasons;


    public PersonEmployerActivityUploadSearchForm() {
        super();
    }


    public String getControlGroupId() {
        return controlGroupId;
    }


    public void setControlGroupId(String controlGroupId) {
        this.controlGroupId = controlGroupId;
    }

    public String getControlGroupName() {
        return controlGroupName;
    }


    public void setControlGroupName(String controlGroupName) {
        this.controlGroupName = controlGroupName;
    }

    public String getControlGroupNo() {
        return controlGroupNo;
    }

    public void setControlGroupNo(String controlGroupNo) {
        this.controlGroupNo = controlGroupNo;
    }


    public String getBatchDate() {
        return batchDate;
    }


    public void setBatchDate(String batchDate) {
        this.batchDate = batchDate;
    }


    public String getTrackingStatusId() {
        return trackingStatusId;
    }


    public void setTrackingStatusId(String trackingStatusId) {
        this.trackingStatusId = trackingStatusId;
    }


    public String getTrackingStatusCode() {
        return trackingStatusCode;
    }


    public void setTrackingStatusCode(String trackingStatusCode) {
        this.trackingStatusCode = trackingStatusCode;
    }


    public String getFileName() {
        return fileName;
    }


    public void setFileName(String fileName) {
        this.fileName = fileName;
    }


    public ArrayList<LookUpValueCode> getTrackingStatusCodes() {
        return trackingStatusCodes;
    }


    public void setTrackingStatusCodes(
            ArrayList<LookUpValueCode> trackingStatusCodes) {
        this.trackingStatusCodes = trackingStatusCodes;
    }


    public ArrayList<LookUpValueCode> getControlGroups() {
        return controlGroups;
    }


    public void setControlGroups(ArrayList<LookUpValueCode> controlGroups) {
        this.controlGroups = controlGroups;
    }


    public String getActionType() {
        return actionType;
    }


    public void setActionType(String actionType) {
        this.actionType = actionType;
    }


    public Integer[] getUids() {
        return uids;
    }


    public void setUids(Integer[] uids) {
        this.uids = uids;
    }

    public final String[] getTrackingStatusIDs() {
        return trackingStatusIDs;
    }


    public final void setTrackingStatusIDs(String[] trackingStatusIDs) {
        this.trackingStatusIDs = trackingStatusIDs;
    }


    public String[] getPostprocessCounts() {
        return postprocessCounts;
    }


    public void setPostprocessCounts(String[] postprocessCounts) {
        this.postprocessCounts = postprocessCounts;
    }


    public String[] getPostprocessAmounts() {
        return postprocessAmounts;
    }


    public void setPostprocessAmounts(String[] postprocessAmounts) {
        this.postprocessAmounts = postprocessAmounts;
    }


    public String[] getTrackingReasons() {
        return trackingReasons;
    }


    public void setTrackingReasons(String[] trackingReasons) {
        this.trackingReasons = trackingReasons;
    }


    public final String[] getFilenames() {
        return filenames;
    }


    public final void setFilenames(String[] filenames) {
        this.filenames = filenames;
    }


}
