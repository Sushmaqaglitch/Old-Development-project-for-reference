package com.healthpartners.app.bpm.dto;

import com.healthpartners.app.bpm.common.BPMAdminConstants;
import com.healthpartners.app.bpm.dto.EmployerGroup;

import java.io.Serializable;
import java.sql.Date;


public class BusinessProgram implements Serializable
{	
	static final long serialVersionUID = 0L;
	
	private Integer rowNumber;
	private int programID;
	
	private String programName;
	private String programDescription;
	private String programTypeCodeID;
	
	private int familyParticipationRequirement;
	private String familyParticipationValue;
	private String familyParticipationDesc;
	private String goldPassDescription;
	private String activityCostRule;
	private Date releaseDate;
	private Date effectiveDate;
	private Date endDate;
	private Integer contractNumber; 

	private Date qualificationWindowStartDate;	
    private Date qualificationWindowEndDate;

	private String additionalGroupProgramInfo;
	
	private Date benefitYearStartDate;
	private int benefitLevelCodeID;
	private String benefitLevelDesc;	
	
	private Date membershipProcessDate;
	private String membershipProcessFlag;
	private boolean membershipProcessActivated;
	
	private EmployerGroup employerGroup;
	
	boolean hasMembers;
	private Integer numberOfMembers;
	private Integer numberOfTerminatedMembers;
	
	private int programStatusCodeID;
	private String programStatusCodeValue;
	private String programStatusDesc;
	
	private Integer packageID;
	private Integer qualificationCheckmarkID;
	private String qualificationCheckmarkName;
	
	private Date statusCalcEndDate;
	
	private boolean withDrawn;
	private boolean thirdParty;
	
	
    private Date contributionStartDate;
    private Date contributionEndDate;
    
    private String templateEffectiveDateString;
    private String templateEndDateString;
	
    private Integer reportIndicatorCodeID;
    private String reportIndicatorCodeValue;

    

    public BusinessProgram()
    {
    	super();
    }
    
	public boolean isWithDrawn() {
		
		setWithDrawn(false);
		if (this.programStatusCodeValue.equals(BPMAdminConstants.BUS_PROGRAM_ACTVTN_WITHDRAWN)) {
			setWithDrawn(true);
		}
		return withDrawn;
	}

	public void setWithDrawn(boolean withDrawn) {
		this.withDrawn = withDrawn;
	}
	
	public boolean isThirdParty() 
	{		
		setThirdParty(false);
		if (this.programStatusCodeValue.equals(BPMAdminConstants.BUS_PROGRAM_ACTVTN_THIRD_PARTY)) {
			setThirdParty(true);
		}
		return thirdParty;
	}


	public void setThirdParty(boolean thirdParty) {
		this.thirdParty = thirdParty;
	}

	public int getProgramID() {
		return programID;
	}

	public void setProgramID(int programID) {
		this.programID = programID;
	}

	
	public int getFamilyParticipationRequirement() {
		return familyParticipationRequirement;
	}

	public void setFamilyParticipationRequirement(int familyParticipationRequirement) {
		this.familyParticipationRequirement = familyParticipationRequirement;
	}

	public String getGoldPassDescription() {
		return goldPassDescription;
	}

	public void setGoldPassDescription(String goldPassDescription) {
		this.goldPassDescription = goldPassDescription;
	}
	
	public Date getQualificationWindowEndDate() {
		return qualificationWindowEndDate;
	}
	public void setQualificationWindowEndDate(Date qualificationWindowEndDate) {
		this.qualificationWindowEndDate = qualificationWindowEndDate;
	}
	
	public Date getQualificationWindowStartDate() {
		return qualificationWindowStartDate;
	}
	public void setQualificationWindowStartDate(Date qualificationWindowStartDate) {
		this.qualificationWindowStartDate = qualificationWindowStartDate;
	}

	public String getActivityCostRule() {
		return activityCostRule;
	}

	public void setActivityCostRule(String activityCostRule) {
		this.activityCostRule = activityCostRule;
	}

	public String getAdditionalGroupProgramInfo() {
		return additionalGroupProgramInfo;
	}

	public void setAdditionalGroupProgramInfo(String additionalGroupProgramInfo) {
		this.additionalGroupProgramInfo = additionalGroupProgramInfo;
	}

	public Date getReleaseDate() {
		return releaseDate;
	}

	public void setReleaseDate(Date releaseDate) {
		this.releaseDate = releaseDate;
	}
	
	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	
	public String getProgramDescription() {
		return programDescription;
	}

	public void setProgramDescription(String programDescription) {
		this.programDescription = programDescription;
	}

	public String getProgramName() {
		return programName;
	}

	public void setProgramName(String programName) {
		this.programName = programName;
	}	

	public Date getBenefitYearStartDate() {
		return benefitYearStartDate;
	}

	public void setBenefitYearStartDate(Date benefitYearStartDate) {
		this.benefitYearStartDate = benefitYearStartDate;
	}			

	public int getBenefitLevelCodeID() {
		return benefitLevelCodeID;
	}

	public void setBenefitLevelCodeID(int benefitLevelCodeID) {
		this.benefitLevelCodeID = benefitLevelCodeID;
	}

	public String getBenefitLevelDesc() {
		return benefitLevelDesc;
	}

	public void setBenefitLevelDesc(String benefitLevelDesc) {
		this.benefitLevelDesc = benefitLevelDesc;
	}

	public String getFamilyParticipationDesc() {
		return familyParticipationDesc;
	}

	public void setFamilyParticipationDesc(String familyParticipationDesc) {
		this.familyParticipationDesc = familyParticipationDesc;
	}	
	
	public String getFamilyParticipationValue() {
		return familyParticipationValue;
	}

	public void setFamilyParticipationValue(String familyParticipationValue) {
		this.familyParticipationValue = familyParticipationValue;
	}

	public String getProgramTypeCodeID() {
		return programTypeCodeID;
	}

	public void setProgramTypeCodeID(String programTypeCodeID) {
		this.programTypeCodeID = programTypeCodeID;
	}

	public Integer getContractNumber() {
		return contractNumber;
	}

	public void setContractNumber(Integer contractNumber) {
		this.contractNumber = contractNumber;
	}

	public EmployerGroup getEmployerGroup() {
		return employerGroup;
	}

	public void setEmployerGroup(EmployerGroup employerGroup) {
		this.employerGroup = employerGroup;
	}

	public boolean isHasMembers() {
		return hasMembers;
	}

	public void setHasMembers(boolean hasMembers) {
		this.hasMembers = hasMembers;
	}

	public final Integer getNumberOfMembers() {
		return numberOfMembers;
	}

	public final void setNumberOfMembers(Integer numberOfMembers) {
		this.numberOfMembers = numberOfMembers;
	}

	public final Date getEffectiveDate() {
		return effectiveDate;
	}

	public final void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public Date getMembershipProcessDate() {
		return membershipProcessDate;
	}

	public void setMembershipProcessDate(Date membershipProcessDate) {
		this.membershipProcessDate = membershipProcessDate;
	}

	public String getMembershipProcessFlag() {
		return membershipProcessFlag;
	}

	public void setMembershipProcessFlag(String membershipProcessFlag) {
		this.membershipProcessFlag = membershipProcessFlag;
		
		if (BPMAdminConstants.BPM_ADMIN_MEMBERSHIP_FLAG_TRUE.equals(membershipProcessFlag)) {
			setMembershipProcessActivated(true);
		} else {
			setMembershipProcessActivated(false);
		}
	}

	public boolean isMembershipProcessActivated() {
		return membershipProcessActivated;
	}

	private void setMembershipProcessActivated(boolean membershipProcessActivated) {
		this.membershipProcessActivated = membershipProcessActivated;
	}

	public final Integer getNumberOfTerminatedMembers() {
		return numberOfTerminatedMembers;
	}

	public final void setNumberOfTerminatedMembers(Integer numberOfTerminatedMembers) {
		this.numberOfTerminatedMembers = numberOfTerminatedMembers;
	}

	public int getProgramStatusCodeID() {
		return programStatusCodeID;
	}

	public void setProgramStatusCodeID(int programStatusCodeID) {
		this.programStatusCodeID = programStatusCodeID;
	}

	public String getProgramStatusCodeValue() {
		return programStatusCodeValue;
	}

	public void setProgramStatusCodeValue(String programStatusCodeValue) {
		this.programStatusCodeValue = programStatusCodeValue;
	}

	public String getProgramStatusDesc() {
		return programStatusDesc;
	}

	public void setProgramStatusDesc(String programStatusDesc) {
		this.programStatusDesc = programStatusDesc;
	}

	public Integer getPackageID() {
		return packageID;
	}

	public void setPackageID(Integer packageID) {
		this.packageID = packageID;
	}

	public final Integer getQualificationCheckmarkID() {
		return qualificationCheckmarkID;
	}

	public final void setQualificationCheckmarkID(Integer qualificationCheckmarkID) {
		this.qualificationCheckmarkID = qualificationCheckmarkID;
	}

	public final String getQualificationCheckmarkName() {
		return qualificationCheckmarkName;
	}

	public final void setQualificationCheckmarkName(
			String qualificationCheckmarkName) {
		this.qualificationCheckmarkName = qualificationCheckmarkName;
	}

	public final Date getStatusCalcEndDate() {
		return statusCalcEndDate;
	}

	public final void setStatusCalcEndDate(Date statusCalcEndDate) {
		this.statusCalcEndDate = statusCalcEndDate;
	}

	public Integer getRowNumber() {
		return rowNumber;
	}

	public void setRowNumber(Integer rowNumber) {
		this.rowNumber = rowNumber;
	}

	public Date getContributionStartDate() {
		return contributionStartDate;
	}

	public void setContributionStartDate(Date contributionStartDate) {
		this.contributionStartDate = contributionStartDate;
	}

	public Date getContributionEndDate() {
		return contributionEndDate;
	}

	public void setContributionEndDate(Date contributionEndDate) {
		this.contributionEndDate = contributionEndDate;
	}

	public String getTemplateEffectiveDateString() {
		return templateEffectiveDateString;
	}

	public void setTemplateEffectiveDateString(String templateEffectiveDateString) {
		this.templateEffectiveDateString = templateEffectiveDateString;
	}

	public String getTemplateEndDateString() {
		return templateEndDateString;
	}

	public void setTemplateEndDateString(String templateEndDateString) {
		this.templateEndDateString = templateEndDateString;
	}

	public Integer getReportIndicatorCodeID() {
		return reportIndicatorCodeID;
	}

	public void setReportIndicatorCodeID(Integer reportIndicatorCodeID) {
		this.reportIndicatorCodeID = reportIndicatorCodeID;
	}

	public String getReportIndicatorCodeValue() {
		return reportIndicatorCodeValue;
	}

	public void setReportIndicatorCodeValue(String reportIndicatorCodeValue) {
		this.reportIndicatorCodeValue = reportIndicatorCodeValue;
	}

	
	
	
}
