package com.healthpartners.app.bpm.dto;

import java.io.Serializable;
import java.sql.Date;

public class ContributionTierBenefitContractTypeRelationship implements Serializable {
    static final long serialVersionUID = 0L;

    private Integer tierValueRelationshipID;
    private Integer tierValueID;
    private Integer benefitContractTypeID;
    private Integer relationshipCode;
    private String relationshipDesc;
    private Date insertDate;
    private Date modifyDate;
    private String insertUser;
    private String modifyUser;


    public ContributionTierBenefitContractTypeRelationship() {
        super();
    }

    public Integer getTierValueRelationshipID() {
        return tierValueRelationshipID;
    }

    public void setTierValueRelationshipID(Integer tierValueRelationshipID) {
        this.tierValueRelationshipID = tierValueRelationshipID;
    }

    public Integer getTierValueID() {
        return tierValueID;
    }

    public void setTierValueID(Integer tierValueID) {
        this.tierValueID = tierValueID;
    }

    public Integer getBenefitContractTypeID() {
        return benefitContractTypeID;
    }

    public void setBenefitContractTypeID(Integer benefitContractTypeID) {
        this.benefitContractTypeID = benefitContractTypeID;
    }

    public Integer getRelationshipCode() {
        return relationshipCode;
    }

    public void setRelationshipCode(Integer relationshipCode) {
        this.relationshipCode = relationshipCode;
    }

    public String getRelationshipDesc() {
        return relationshipDesc;
    }

    public void setRelationshipDesc(String relationshipDesc) {
        this.relationshipDesc = relationshipDesc;
    }

    public Date getInsertDate() {
        return insertDate;
    }

    public void setInsertDate(Date insertDate) {
        this.insertDate = insertDate;
    }

    public Date getModifyDate() {
        return modifyDate;
    }

    public void setModifyDate(Date modifyDate) {
        this.modifyDate = modifyDate;
    }

    public String getInsertUser() {
        return insertUser;
    }

    public void setInsertUser(String insertUser) {
        this.insertUser = insertUser;
    }

    public String getModifyUser() {
        return modifyUser;
    }

    public void setModifyUser(String modifyUser) {
        this.modifyUser = modifyUser;
    }


}
