/**
 * 
 */
package com.healthpartners.app.bpm.form;

import com.healthpartners.app.bpm.dto.LookUpValueCode;
import java.util.ArrayList;

/**
 * @author f5929
 *
 */
public class PersonEmployerActivityRecycleSearchForm extends BaseForm {

	static final long serialVersionUID = 0L;
	
	private String firstName;
	private String lastName;
	private String activityName;
	private String activityDate;
	private String recycleStatusDate;
	private String recycleStatusId;
	private String activityId;
	private String actionType;
	private ArrayList<LookUpValueCode> recycleStatusCodes;
	

	public ArrayList<LookUpValueCode> getRecycleStatusCodes() {
		return recycleStatusCodes;
	}


	public void setRecycleStatusCodes(ArrayList<LookUpValueCode> recycleStatusCodes) {
		this.recycleStatusCodes = recycleStatusCodes;
	}


	public PersonEmployerActivityRecycleSearchForm() {
		super();
	}
	

	public String getRecycleStatusDate() {
		return recycleStatusDate;
	}


	public void setRecycleStatusDate(String recycleStatusDate) {
		this.recycleStatusDate = recycleStatusDate;
	}


	public String getActivityName() {
		return activityName;
	}


	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}
    
	

	public String getActivityDate() {
		return activityDate;
	}


	public void setActivityDate(String activityDate) {
		this.activityDate = activityDate;
	}


	public String getRecycleStatusId() {
		return recycleStatusId;
	}


	public void setRecycleStatusId(String recycleStatusId) {
		this.recycleStatusId = recycleStatusId;
	}


	public String getActionType() {
		return actionType;
	}


	public void setActionType(String actionType) {
		this.actionType = actionType;
	}


	public String getFirstName() {
		return firstName;
	}


	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	public String getLastName() {
		return lastName;
	}


	public void setLastName(String lastName) {
		this.lastName = lastName;
	}


	

	public String getActivityId() {
		return activityId;
	}


	public void setActivityId(String activityId) {
		this.activityId = activityId;
	}
	
	


	
	
}
