package com.healthpartners.app.bpm.iface;

import com.healthpartners.app.bpm.dto.*;
import com.healthpartners.app.bpm.exception.BPMException;
import org.springframework.dao.DataAccessException;

import java.io.IOException;
import java.sql.Date;
import java.sql.SQLTimeoutException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;

public interface MemberService {
    Collection<PersonActivityContributionPending> getPersonActivityNonEmployerSponsoredContributionsPending(PersonActivityIncentiveSearch lPersonActivityIncentiveSearch) throws BPMException, DataAccessException;

    Collection<PersonActivityContributionPending> getPersonActivityEmployerSponsoredContributionsPending(PersonActivityIncentiveSearch lPersonActivityIncentiveSearch) throws BPMException, DataAccessException;

    Collection<LookUpValueCode> getLUVCodesByGroup(String group) throws DataAccessException, BPMException;

    LookUpValueCode getLUVCodeByGroupNValue(String group, String value) throws DataAccessException;

    void kickStartBatchProcessOnOpenshift(String urlRestEndpointCommand) throws IOException;

    int updateMemberStatusByCodeValue(Integer pPersonID, Integer pProgramID, Integer pGroupID, String pNewStatus, String pUserID) throws DataAccessException;

    Collection<MemberProgramActivity> getActivityHistory(String memberID, Date qualificationStartDate) throws BPMException, DataAccessException;

    MemberDetail getMemberDetail(String memberID, java.sql.Date qualificationStartDate) throws BPMException, DataAccessException;

    Collection<BaselineHistory> getBaselineHistory(String pMemberID, Integer pContractNo, Date pProgramEffetiveDate, String pEligibilityHistoryResults);

    MemberDetail getMemberDemographicsOnly(String memberID, Date qualificationStartDate)
            throws BPMException, DataAccessException;

    Collection<String> getMemberIDFromPersonDetails(String firstName,
                                                    String middleInitial, String lastName, String gender,
                                                    Date dateOfBirth) throws DataAccessException, BPMException;

    Collection<String> getMemberIDByContractNo(Integer pContractNo) throws DataAccessException;

    Collection<LookUpValueCode> getActivityEventFilteredOutReasons() throws DataAccessException;

    ArrayList<MemberProgramDetail> selectPersonProgramRelationship(String pMemberID) throws BPMException, DataAccessException;

    Collection<MemberDetail> getRelatedMemberDetail(String memberID, Date qualificationStartDate) throws BPMException, DataAccessException;

    Collection<MemberProcessingStatusLog> getPendingPersonsFromProcessingStatusLog(int pProcessID) throws BPMException, DataAccessException;

    int[] deleteProcessingStatusLogRecords(Collection<Long> processLogIDs) throws BPMException, DataAccessException;

    ArrayList<PersonContractHist> getMemberContractsHistory(
            String memberId, String contractNo, Date programEffectiveDate, String groupNo, String luvContractHistResultCodeValue)
            throws DataAccessException, SQLTimeoutException;

    Collection<CDHPFulfillmentTrackingRecycle> getPersonCDHPFulfillsRecycle(
            String memberId, String groupNo, String contractNo, Date recycleStatusDate, Integer recycleStatusId, String programName)
            throws DataAccessException;

    int updatePersonCDHPFulfillRecycle(CDHPFulfillmentTrackingRecycle pCDHPFulfillmentTrackingRecycle) throws BPMException, DataAccessException;

    int updateMemberProgramActivityIncentiveModifyDate(Integer personDemographicsID, Integer programID, Integer activityID, String userID) throws DataAccessException;

    CDHPFulfillmentTrackingRecycle getPersonCDHPFulfillRecycle(Integer recycleID) throws DataAccessException;

    MemberDetail getMemberDetail(String memberID, Integer programID) throws BPMException, DataAccessException;

    Collection<MemberDetail> getRelatedMemberDetail(String memberID) throws BPMException, DataAccessException;

    Collection<PersonContractRecycle> getMemberContractsRecycle(
            String memberId, String groupNo, String contractNo, Date recycleStatusDate, Integer recycleStatusId, String programName)
            throws DataAccessException;
    int updatePersonContractRecycle(PersonContractRecycle pPersonContractRecycle) throws BPMException, DataAccessException;
    int updateMemberProgramStatusContractStatusDate(Integer personId, Integer programId) throws BPMException, DataAccessException;
    PersonContractRecycle getMemberContractRecycle(Integer recycleID) throws DataAccessException;
    Collection<Integer> getNumberOfProcessingStatusLogPending() throws DataAccessException;
    Collection<Integer> getNumberOfProcessingStatusLogInProcess() throws DataAccessException;
    Collection<Integer> getNumberOfActivityEventLog(String pProcessingStatus) throws DataAccessException;
    Collection<Activity> getEmployerAdminsterdActivities() throws DataAccessException, BPMException;
    int updateFilteredActivities(String pMemberID, Date pInsertDate, Integer pGroupID, Integer pActivityID, String pActivityStatusToProcess, String pProcessingStatus)
            throws BPMException, DataAccessException;

    public long insertPersonProcessingStatus(Integer personId,
                                             Integer processId, String processingStatusValue, String userId)
            throws BPMException, DataAccessException;

    public Collection<MemberProgramDetail> getTermedMemberProgramHistoryDetails(
            String memberID, Date qualificationStartDate)
            throws DataAccessException;

    public int updateMemberStatus(Integer pPersonID, Integer pProgramID, Integer pNewStatus, String pUserID, Integer pProgramIncentiveOptionID)
            throws BPMException, DataAccessException;

    public LookUpValueCode getLUVCodeByID(Integer pLUVID)
            throws DataAccessException;

    public void insertManualExemptionForMember(Integer personDemographicsID, Integer personID,
                                               Integer businessProgramID, Integer contractNo, String exemptionReason,
                                               Calendar issueDate, String approverUser, String userId, Integer pProgramIncentiveOptionID)
            throws IOException, DataAccessException;

    public int updateContractProgramStatus(Integer pProgramID, Integer pContractNo, Integer pNewStatus, String pUserID, Integer pProgramIncentiveOptionID)
            throws BPMException, DataAccessException;

    public int updateParticipationEndDate(Integer pPersonDemographicsID, Integer pProgramID, java.sql.Date pParticipationEndDate)
            throws DataAccessException;
}