package com.healthpartners.app.bpm.controller;

import com.healthpartners.app.bpm.common.BPMAdminConstants;
import com.healthpartners.app.bpm.common.BPMAdminUtils;
import com.healthpartners.app.bpm.common.BPMPagination;
import com.healthpartners.app.bpm.dto.CDHPFulfillmentTrackingRecycle;
import com.healthpartners.app.bpm.dto.LookUpValueCode;
import com.healthpartners.app.bpm.dto.RecycleSearchCriteria;
import com.healthpartners.app.bpm.exception.BPMException;
import com.healthpartners.app.bpm.form.PersonCDHPFulfillRecycleSearchForm;
import com.healthpartners.app.bpm.iface.MemberService;
import com.healthpartners.app.bpm.pageable.PageablePersonCDHPFulfillRecycle;
import com.healthpartners.app.bpm.session.UserSession;
import com.healthpartners.service.bpm.common.BPMConstants;
import jakarta.servlet.http.HttpServletRequest;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

@Controller
public class PersonCDHPFulfillRecycleSearchController extends BaseController implements Validator {

    private final MemberService memberService;

    public PersonCDHPFulfillRecycleSearchController(MemberService memberService) {
        this.memberService = memberService;
    }

    @GetMapping("/showPersonCDHPFulfillRecycleSearch")
    public String loadSearch(ModelMap modelMap) throws BPMException {
        PersonCDHPFulfillRecycleSearchForm form = new PersonCDHPFulfillRecycleSearchForm();
        modelMap.put("personCDHPFulfillRecycleSearchForm", form);

        try {
            loadInitial(modelMap);
        } catch (Exception e) {
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
            modelMap.put("errorMsg", getStackTrace(e));
        }
        return "personCDHPFulfillRecycleSearch";
    }

    @PostMapping(value = "/personCDHPFulfillRecycleSearch", params = "next")
    public String submitNext(@ModelAttribute("personCDHPFulfillRecycleSearchForm") PersonCDHPFulfillRecycleSearchForm form, ModelMap modelMap, HttpServletRequest request) throws Exception {
        return performPaginationAction(form, modelMap);
    }

    @PostMapping(value = "/personCDHPFulfillRecycleSearch", params = "back")
    public String submitBack(@ModelAttribute("personCDHPFulfillRecycleSearchForm") PersonCDHPFulfillRecycleSearchForm form, ModelMap modelMap, HttpServletRequest request) throws Exception {
        return performPaginationAction(form, modelMap);
    }

    @PostMapping("/personCDHPFulfillRecycleSearch")
    public String submit(@ModelAttribute("personCDHPFulfillRecycleSearchForm") PersonCDHPFulfillRecycleSearchForm form, ModelMap modelMap, BindingResult result) throws Exception {
        try {
            populateSelects(modelMap);
            if (ACTION_SEARCH.equals(form.getActionType())) {
                validate(form, result);
                if (!result.hasErrors()) {
                    search(form, modelMap);
                }

            } else if (ACTION_UPDATE.equals(form.getActionType())) {
                validateForRecycleUpdate(form, modelMap, result);
                if (!result.hasErrors()) {
                    update(form, modelMap);
                }
                form.setActionType(ACTION_SEARCH);
                search(form, modelMap);
            }
        } catch (Exception e) {
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
            // Add error stack trace on the request, to be hidden in html.
            modelMap.put("errorMsg", getStackTrace(e));
        }

        return "personCDHPFulfillRecycleSearch";
    }

    @GetMapping("/personCDHPFulfillRecycleSearch")
    public String loadSearchFromBackButtonAction(@ModelAttribute("personCDHPFulfillRecycleSearchForm") PersonCDHPFulfillRecycleSearchForm form, ModelMap modelMap, BindingResult result) throws Exception {
        try {
            RecycleSearchCriteria lRecycleSearchCriteria = getUserSession().getRecycleSearchCriteria();
            form.setActionType(ACTION_SEARCH);
            form.setGroupNo(lRecycleSearchCriteria.getGroupNo());
            form.setMemberId(lRecycleSearchCriteria.getMemberID());
            form.setContractNo(lRecycleSearchCriteria.getContractNo());
            form.setProgramName(lRecycleSearchCriteria.getProgramName());
            form.setRecycleStatusId(lRecycleSearchCriteria.getRecycleStatusID());
            form.setRecycleStatusDate(lRecycleSearchCriteria.getRecycleStatusDateString());

            populateSelects(modelMap);

            CDHPFulfillmentTrackingRecycle cdhpFulfillmentTrackingRecycle = getUserSession().getPersonCDHPFulfillRecycle();
            if (cdhpFulfillmentTrackingRecycle != null) {
                form.setApprover(cdhpFulfillmentTrackingRecycle.getApproverUserId());
                form.setRecycleStatusUpdateId(cdhpFulfillmentTrackingRecycle.getRecycleStatusId() != null ? String.valueOf(cdhpFulfillmentTrackingRecycle.getRecycleStatusId()) : null);
                form.setReason(cdhpFulfillmentTrackingRecycle.getReasonDesc());
            }

            search(form, modelMap);

        } catch (Exception e) {
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
            // Add error stack trace on the request, to be hidden in html.
            modelMap.put("errorMsg", getStackTrace(e));
        }

        return "personCDHPFulfillRecycleSearch";
    }

    private void loadInitial(ModelMap modelMap) throws BPMException {
        getUserSession().reset();

        populateSelects(modelMap);

        BPMPagination pagination = new BPMPagination();
        pagination.setBackPageFlag(BPMAdminConstants.BPM_ADMIN_PAGINATION_END);
        pagination.setNextPageFlag(BPMAdminConstants.BPM_ADMIN_PAGINATION_END);
        modelMap.put("backPageFlag", pagination.getBackPageFlag());
        modelMap.put("nextPageFlag", pagination.getNextPageFlag());
    }

    private void populateSelects(ModelMap modelMap) throws BPMException {
        if (CollectionUtils.isEmpty(getUserSession().getRecycleStatusCodes())) {
            ArrayList<LookUpValueCode> lLuvRecycleStatusCodes = (ArrayList<LookUpValueCode>) memberService.getLUVCodesByGroup(BPMConstants.BPM_CDHP_RECYCLE_STATUS);
            getUserSession().setRecycleStatusCodes(lLuvRecycleStatusCodes);
        }
        modelMap.put("recycleStatusCodes", getUserSession().getRecycleStatusCodes());
    }

    private void search(PersonCDHPFulfillRecycleSearchForm form, ModelMap modelMap) throws ParseException {
        boolean newDTOList = false;
        Integer lRecycleStatusIdInt = 0;
        java.util.Date lRecycleStatusDate = null;
        java.sql.Date lSearchDate = null;
        ArrayList<CDHPFulfillmentTrackingRecycle> lPersonCDHPFulfillsRecycle = null;

        String lMemberId = form.getMemberId();
        String lContractNo = form.getContractNo();
        String lGroupNo = form.getGroupNo();
        String lProgramName = form.getProgramName();
        String lRecycleStatusId = form.getRecycleStatusId();
        String lRecycleStatusDateString = form.getRecycleStatusDate();

        // Save the search criteria, so after modifying (approving, denying) and committing the changes
        // retrieve a fresh list with the same criteria.
        RecycleSearchCriteria lRecycleSearchCriteria = new RecycleSearchCriteria();
        lRecycleSearchCriteria.setMemberID(lMemberId);
        lRecycleSearchCriteria.setContractNo(lContractNo);
        lRecycleSearchCriteria.setGroupNo(lGroupNo);
        lRecycleSearchCriteria.setProgramName(lProgramName);
        lRecycleSearchCriteria.setRecycleStatusID(lRecycleStatusId);
        lRecycleSearchCriteria.setRecycleStatusDateString(lRecycleStatusDateString);
        getUserSession().setRecycleSearchCriteria(lRecycleSearchCriteria);

        if (lRecycleStatusDateString != null && lRecycleStatusDateString.length() > 0) {
            lRecycleStatusDate = getFmt().parse(lRecycleStatusDateString);
            lSearchDate = new java.sql.Date(lRecycleStatusDate.getTime());
        }

        if (lRecycleStatusId != null && BPMAdminUtils.isValueInteger(lRecycleStatusId)) {
            lRecycleStatusIdInt = Integer.valueOf(lRecycleStatusId);
        }

        lPersonCDHPFulfillsRecycle = getUserSession().getPersonCDHPFulfillsRecycle();

        if (CollectionUtils.isEmpty(lPersonCDHPFulfillsRecycle) || form.getActionType().equals(ACTION_SEARCH)) {
            lPersonCDHPFulfillsRecycle = (ArrayList<CDHPFulfillmentTrackingRecycle>) memberService.getPersonCDHPFulfillsRecycle(lMemberId, lGroupNo, lContractNo, lSearchDate, lRecycleStatusIdInt, lProgramName);
            getUserSession().setPersonCDHPFulfillsRecycle(lPersonCDHPFulfillsRecycle);
            newDTOList = true;
        }

        if (lPersonCDHPFulfillsRecycle.size() < 1) {
            createNoResultsFoundMessageOnModel(modelMap);
        }

        setPersonCDHPFulfillRecyclePagination(modelMap, getUserSession(), form.getActionType(), newDTOList);
    }

    /**
     * Determine the size of the person cdhp fulfill recycle array list and the number of person cdhp fulfill recycle rows
     * to be displayed per page.
     */
    private void setPersonCDHPFulfillRecyclePagination(ModelMap modelMap,
                                                       UserSession sessionBean,
                                                       String actionType,
                                                       boolean newDTOList) {
        ArrayList<CDHPFulfillmentTrackingRecycle> lPersonCDHPFulfillsRecycleList = sessionBean.getPersonCDHPFulfillsRecycle();

        /**
         * Create a Pageable wrapper for the array list.
         * Create a Pagination object and point it to the wrapper.
         */
        BPMPagination pagination = sessionBean.getPaginationMap().get(PERSON_CDHP_FULFILL_RECYCLE_LIST);
        PageablePersonCDHPFulfillRecycle lPPR = null;
        if (pagination == null || newDTOList) {
            lPPR = new PageablePersonCDHPFulfillRecycle(lPersonCDHPFulfillsRecycleList);
            lPPR.addRowNumber();
            pagination = new BPMPagination(lPPR, new ArrayList<Object>(lPersonCDHPFulfillsRecycleList));
            sessionBean.getPaginationMap().put(PERSON_CDHP_FULFILL_RECYCLE_LIST, pagination);
        }

        ArrayList<CDHPFulfillmentTrackingRecycle> lPersonCDHPFulfillsRecyclePerPage =
                (ArrayList<CDHPFulfillmentTrackingRecycle>) determineNextOrBackAction(actionType, pagination);
        setAttributesForPaginationOnModel(modelMap, lPersonCDHPFulfillsRecycleList.size(), pagination);
        sessionBean.setPagination(pagination);

        modelMap.put("personCDHPFulfillsRecycle", lPersonCDHPFulfillsRecyclePerPage);
        sessionBean.setPersonCDHPFulfillsRecyclePerPage(lPersonCDHPFulfillsRecyclePerPage);
    }

    private void update(PersonCDHPFulfillRecycleSearchForm form, ModelMap modelMap) throws ParseException, BPMException {
        Integer lRecycleStatusIdInt = 0;
        java.util.Date lRecycleStatusDate = null;
        java.sql.Date lSearchDate = null;
        boolean newDTOList = false;
        ArrayList<CDHPFulfillmentTrackingRecycle> lPersonCDHPFulfillsRecycleList = null;
        String lRecycleStatusDateString = form.getRecycleStatusUpdateDate();
        String recycleStatusUpdateId = form.getRecycleStatusUpdateId();
        String lReason = form.getReason();
        String lApprover = form.getApprover();

        SimpleDateFormat fmt = new SimpleDateFormat(BPMAdminConstants.HP_BPM_ADMIN_UI_COMMON_DATE_FORMAT);

        if (lRecycleStatusDateString != null && lRecycleStatusDateString.length() > 0) {
            lRecycleStatusDate = getFmt().parse(lRecycleStatusDateString);
            lSearchDate = new java.sql.Date(lRecycleStatusDate.getTime());
        }
        if (recycleStatusUpdateId != null && BPMAdminUtils.isValueInteger(recycleStatusUpdateId)) {
            lRecycleStatusIdInt = Integer.valueOf(recycleStatusUpdateId);
        }

        // For all the ones that are checked
        lPersonCDHPFulfillsRecycleList = getUserSession().getPersonCDHPFulfillsRecycle();
        for (int i = 0; i < lPersonCDHPFulfillsRecycleList.size(); i++) {
            CDHPFulfillmentTrackingRecycle lCDHPFulfillmentTrackingRecycle = lPersonCDHPFulfillsRecycleList.get(i);
            // If checked
            if (isRecycleRecordChecked(lCDHPFulfillmentTrackingRecycle, form)) {
                lCDHPFulfillmentTrackingRecycle.setApproverUserId(lApprover);
                lCDHPFulfillmentTrackingRecycle.setRecycleStatusId(lRecycleStatusIdInt);
                lCDHPFulfillmentTrackingRecycle.setReasonDesc(lReason);

                memberService.updatePersonCDHPFulfillRecycle(lCDHPFulfillmentTrackingRecycle);
                //update member activity incentive modify date with system date so incentive is re-evaluated.
                memberService.updateMemberProgramActivityIncentiveModifyDate(lCDHPFulfillmentTrackingRecycle.getPersonDemographicsID(), lCDHPFulfillmentTrackingRecycle.getProgramId(), lCDHPFulfillmentTrackingRecycle.getActivityId(), BPMAdminConstants.BPM_USER_SYSTEM);
            }
        }

        // After having saved the changes, retrieve a fresh list of recycles using the same criteria that
        // were used before. This way the records that were changed will not re-appear on the screen.
        RecycleSearchCriteria lRecycleSearchCriteria = getUserSession().getRecycleSearchCriteria();
        String lRecycleStatusDateSearchString = lRecycleSearchCriteria.getRecycleStatusDateString();
        java.sql.Date lRecycleSearchDate = null;
        Integer lRecycleStatusSearchIdInt = 0;
        if (lRecycleSearchCriteria.getRecycleStatusID() != null && BPMAdminUtils.isValueInteger(lRecycleSearchCriteria.getRecycleStatusID())) {
            lRecycleStatusSearchIdInt = Integer.valueOf(lRecycleSearchCriteria.getRecycleStatusID());
        }

        if (lRecycleStatusDateString != null && lRecycleStatusDateString.length() > 0) {
            lRecycleSearchDate = BPMAdminUtils.convertStringToSqlDate(lRecycleStatusDateSearchString, BPMAdminConstants.HP_BPM_ADMIN_UI_COMMON_DATE_FORMAT);
        }
        lPersonCDHPFulfillsRecycleList =
                (ArrayList<CDHPFulfillmentTrackingRecycle>) memberService.getPersonCDHPFulfillsRecycle(
                        lRecycleSearchCriteria.getMemberID()
                        , lRecycleSearchCriteria.getGroupNo()
                        , lRecycleSearchCriteria.getContractNo()
                        , lRecycleSearchDate
                        , lRecycleStatusSearchIdInt
                        , lRecycleSearchCriteria.getProgramName());

        getUserSession().setPersonCDHPFulfillsRecycle(lPersonCDHPFulfillsRecycleList);
        newDTOList = true;
        // Set actionType to empty string to start pagination from the beginning.
        setPersonCDHPFulfillRecyclePagination(modelMap, getUserSession(), "", newDTOList);
    }

    private boolean isRecycleRecordChecked(CDHPFulfillmentTrackingRecycle pCDHPFulfillmentTrackingRecycle, PersonCDHPFulfillRecycleSearchForm pPersonCDHPFulfillRecycleSearchForm) {
        String[] lSelectedRecycleIDs = pPersonCDHPFulfillRecycleSearchForm.getSelectedRecycleIDs();

        if (lSelectedRecycleIDs != null) {
            for (int recID = 0; recID < lSelectedRecycleIDs.length; recID++) {
                String cdhpRecycleId = String.valueOf(pCDHPFulfillmentTrackingRecycle.getCdhpRecycleId());
                if (cdhpRecycleId.equals(lSelectedRecycleIDs[recID])) {
                    logger.info("isRecycleRecordChecked match occurred");
                    return true;
                }
            }
        }

        return false;
    }

    private String performPaginationAction(PersonCDHPFulfillRecycleSearchForm form, ModelMap modelMap) throws BPMException, ParseException {
        setPersonCDHPFulfillRecyclePagination(modelMap, getUserSession(), form.getActionType(), false);
        populateSelects(modelMap);
        getUserSession().setMemberId(getUserSession().getRecycleSearchCriteria().getMemberID());
        getUserSession().setContractNo(getUserSession().getRecycleSearchCriteria().getContractNo());
        getUserSession().setGroupNo(getUserSession().getRecycleSearchCriteria().getGroupNo());
        getUserSession().setProgramName(getUserSession().getRecycleSearchCriteria().getProgramName());
        getUserSession().setRecycleStatusId(StringUtils.isNotEmpty(getUserSession().getRecycleSearchCriteria().getRecycleStatusID())  ? Integer.valueOf(getUserSession().getRecycleSearchCriteria().getRecycleStatusID()) : null);

        return "personCDHPFulfillRecycleSearch";
    }

    @Override
    public boolean supports(Class<?> clazz) {
        return PersonCDHPFulfillRecycleSearchForm.class.isAssignableFrom(clazz);
    }

    @Override
    public void validate(Object target, Errors errors) {
        PersonCDHPFulfillRecycleSearchForm form = (PersonCDHPFulfillRecycleSearchForm) target;

        boolean minimumOneSearchTarget = false;
        if (form.getMemberId().length() > 0) {
            getValidationSupport().validateNotInteger("memberId", form.getMemberId(), errors, new Object[]{"Member ID"});
            minimumOneSearchTarget = true;
        }
        if (form.getGroupNo().length() > 0) {
            getValidationSupport().validateNotInteger("groupNo", form.getGroupNo(), errors, new Object[]{"Group Number"});
            minimumOneSearchTarget = true;
        }
        if (form.getContractNo().length() > 0) {
            getValidationSupport().validateNotInteger("contractNo", form.getContractNo(), errors, new Object[]{"Contract Number"});
            minimumOneSearchTarget = true;
        }
        if (form.getProgramName().length() > 0) {
            minimumOneSearchTarget = true;
        }
        if (form.getRecycleStatusId().length() > 0 && !form.getRecycleStatusId().equals("select")) {
            minimumOneSearchTarget = true;
        }
        if (form.getRecycleStatusId().equals("select")) {
            form.setRecycleStatusId("");
        }

        if (form.getRecycleStatusDate().length() > 0) {
            getValidationSupport().validateDateFormat("recycleStatusDate", form.getRecycleStatusDate(), errors, new Object[]{"Contract Status Date "});
            minimumOneSearchTarget = true;
        }

        if (!minimumOneSearchTarget) {
            String[] fieldValues = {};
            getValidationSupport().validateAtleastOneSelection("memberId", "", errors, new Object[]{"field element to search on"});
        }
    }

    private void validateForRecycleUpdate(PersonCDHPFulfillRecycleSearchForm form, ModelMap modelMap, Errors errors) {
        if (form.getRecycleStatusId().equalsIgnoreCase("select")) {
            form.setRecycleStatusId("");
        }

        if (form.getRecycleStatusUpdateId().length() <= 0 || form.getRecycleStatusUpdateId().equals("select")) {
            getValidationSupport().addValidationFailureMessage("recycleStatusUpdateId", errors, "errors.required", new Object[]{"Recycle Status"});
        }

        if (form.getRecycleStatusUpdateDate().length() > 0) {
            getValidationSupport().validateDateFormat("recycleStatusUpdateDate", form.getRecycleStatusUpdateDate(), errors, new Object[]{"Status Date"});
        }

        getValidationSupport().validateRequiredFieldIsNotEmpty("approver", form.getApprover(), errors, new Object[]{"Approver"});
        getValidationSupport().validateRequiredFieldIsNotEmpty("reason", form.getReason(), errors, new Object[]{"Approver"});
    }

}
