package com.healthpartners.app.bpm.pageable;

import com.healthpartners.app.bpm.dto.ExemptionHistory;

import java.util.ArrayList;
import java.util.Iterator;

/**
 * The pageable class serves as a wrapper for the array list of objects, and
 * operations that are performed on those objects. For ex. adding a row number
 * for display.
 * The BPMPagination then has a pointer to an instance of this class.
 *
 * @author jxbourbour
 */
public class PageableExemptionHistory implements BPMPageable {
    ArrayList<ExemptionHistory> exemptionHistorys;

    public PageableExemptionHistory() {
        super();
    }

    public PageableExemptionHistory(ArrayList<ExemptionHistory> pExemptionHistorys) {
        exemptionHistorys = pExemptionHistorys;
    }

    public ArrayList<ExemptionHistory> getExemptionHistorys() {
        return exemptionHistorys;
    }

    public void setExemptionHistorys(ArrayList<ExemptionHistory> exemptionHistorys) {
        this.exemptionHistorys = exemptionHistorys;
    }

    public void addRowNumber() {
        int startRowNumber = 1;
        Iterator<ExemptionHistory> iter = exemptionHistorys.iterator();
        while (iter.hasNext()) {
            ExemptionHistory lExemptionHistory = iter.next();
            lExemptionHistory.setRowNumber(startRowNumber);
            startRowNumber++;
        }
    }
}
