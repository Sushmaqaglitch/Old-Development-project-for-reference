package com.healthpartners.app.bpm.dao;

import com.healthpartners.app.bpm.dto.ControlGroupIOFileDirSetup;
import com.healthpartners.app.bpm.exception.BPMException;
import jakarta.annotation.PostConstruct;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Collection;


/**
 * @author tjquist
 */
@Repository
@Transactional(timeout = 300, rollbackFor = {DataAccessException.class, BPMException.class})
public class ControlGroupIOFileDirSetupDAOJdbc extends JdbcDaoSupport implements ControlGroupIOFileDirSetupDAO {
    private final String selectControlGroupIOFileDirSetup = """
         	select t.cntrl_grp_io_id,
			   t.routing_tp_id,
			   t.grp_no,
			   (select distinct egs.empl_grp_nm from empl_grp_site egs where egs.empl_grp_no = t.grp_no) group_name,
			   t.input_file_loc_preprocess,
			   t.input_file_loc_processed,
			   t.file_name_prefix_1,
			   t.file_name_prefix_2,
			   t.processed_output_file_loc_1,
			   t.processed_output_file_loc_2
			from CNTRL_GRP_IO_FILE_DIR_SETUP t
			where t.routing_tp_id = ?		
            """;

    private final DataSource dataSource;

    public ControlGroupIOFileDirSetupDAOJdbc(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @PostConstruct
    private void initialize() {
        setDataSource(dataSource);
    }


    @Override
    public Collection<ControlGroupIOFileDirSetup> getControlGroupsIOFileDirSetup(Integer routingTypeID) throws DataAccessException {
        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{routingTypeID};
        int types[] = new int[]{Types.INTEGER};
        final ArrayList<ControlGroupIOFileDirSetup> lControlGroupIOFileDirSetups = new ArrayList<ControlGroupIOFileDirSetup>();

        template.query(selectControlGroupIOFileDirSetup, params, types,
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        ControlGroupIOFileDirSetup lControlGroupIOFileDirSetup = new ControlGroupIOFileDirSetup();

                        lControlGroupIOFileDirSetup.setControlGroupIOID(rs.getInt("cntrl_grp_io_id"));
                        lControlGroupIOFileDirSetup.setRoutingTypeID(rs.getInt("routing_tp_id"));
                        lControlGroupIOFileDirSetup.setGroupNo(rs.getString("GRP_NO"));
                        lControlGroupIOFileDirSetup.setGroupName(rs.getString("group_name"));

                        lControlGroupIOFileDirSetup.setInputFileLocPreprocess(rs.getString("input_file_loc_preprocess"));
                        lControlGroupIOFileDirSetup.setInputFileLocProcessed(rs.getString("input_file_loc_processed"));
                        lControlGroupIOFileDirSetup.setFileNamePrefix1(rs.getString("file_name_prefix_1"));
                        lControlGroupIOFileDirSetup.setFileNamePrefix2(rs.getString("file_name_prefix_2"));
                        lControlGroupIOFileDirSetup.setProcessedOutputFilePathLoc1(rs.getString("processed_output_file_loc_1"));
                        lControlGroupIOFileDirSetup.setProcessedOutputFilePathLoc2(rs.getObject("processed_output_file_loc_2") == null ? "" : rs.getString("processed_output_file_loc_2"));


                        lControlGroupIOFileDirSetups.add(lControlGroupIOFileDirSetup);
                    }
                });

        return lControlGroupIOFileDirSetups;
    }

}
