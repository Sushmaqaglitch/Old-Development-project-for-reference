package com.healthpartners.app.bpm.dto;

import java.io.Serializable;
import java.util.ArrayList;

public class BPMCollection implements Serializable {
    static final long serialVersionUID = 0L;

    private Integer collectionID;
    private String collectionName;
    private String collectionInfo;
    private String collectionDesc;
    private Integer requiredQuantity;

    private Integer collectionTypeCodeID;
    private String collectionTypeCode;
    private String collectionTypeDesc;

    private java.sql.Date effectiveDate;
    private java.sql.Date endDate;

    private Integer used;

    private ArrayList<CollectionActivity> collectionActivities;


    public BPMCollection() {
        super();
    }


    public Integer getCollectionID() {
        return collectionID;
    }


    public void setCollectionID(Integer collectionID) {
        this.collectionID = collectionID;
    }


    public String getCollectionName() {
        return collectionName;
    }


    public void setCollectionName(String collectionName) {
        this.collectionName = collectionName;
    }


    public String getCollectionDesc() {
        return collectionDesc;
    }


    public void setCollectionDesc(String collectionDesc) {
        this.collectionDesc = collectionDesc;
    }


    public Integer getRequiredQuantity() {
        return requiredQuantity;
    }


    public void setRequiredQuantity(Integer requiredQuantity) {
        this.requiredQuantity = requiredQuantity;
    }


    public Integer getCollectionTypeCodeID() {
        return collectionTypeCodeID;
    }


    public void setCollectionTypeCodeID(Integer collectionTypeCodeID) {
        this.collectionTypeCodeID = collectionTypeCodeID;
    }


    public String getCollectionTypeCode() {
        return collectionTypeCode;
    }


    public void setCollectionTypeCode(String collectionTypeCode) {
        this.collectionTypeCode = collectionTypeCode;
    }


    public String getCollectionTypeDesc() {
        return collectionTypeDesc;
    }


    public void setCollectionTypeDesc(String collectionTypeDesc) {
        this.collectionTypeDesc = collectionTypeDesc;
    }


    public java.sql.Date getEffectiveDate() {
        return effectiveDate;
    }


    public void setEffectiveDate(java.sql.Date effectiveDate) {
        this.effectiveDate = effectiveDate;
    }


    public java.sql.Date getEndDate() {
        return endDate;
    }


    public void setEndDate(java.sql.Date endDate) {
        this.endDate = endDate;
    }


    public ArrayList<CollectionActivity> getCollectionActivities() {
        return collectionActivities;
    }


    public void setCollectionActivities(ArrayList<CollectionActivity> collectionActivities) {
        this.collectionActivities = collectionActivities;
    }


    public Integer getUsed() {
        return used;
    }


    public void setUsed(Integer used) {
        this.used = used;
    }


    public String getCollectionInfo() {
        return collectionInfo;
    }


    public void setCollectionInfo(String collectionInfo) {
        this.collectionInfo = collectionInfo;
    }


}
