package com.healthpartners.app.bpm.dto;

import java.io.Serializable;


public class IncentiveParticipantRelationship implements Serializable
{	
	static final long serialVersionUID = 0L;
	
	private Integer activityIncentiveID;
	private Integer relationshipCode;
	private String relationshipName;
	private Integer maxQauntity;
	
	public Integer getActivityIncentiveID() {
		return activityIncentiveID;
	}
	public void setActivityIncentiveID(Integer activityIncentiveID) {
		this.activityIncentiveID = activityIncentiveID;
	}
	public Integer getRelationshipCode() {
		return relationshipCode;
	}
	public void setRelationshipCode(Integer relationshipCode) {
		this.relationshipCode = relationshipCode;
	}
	
	public String getRelationshipName() {
		return relationshipName;
	}
	public void setRelationshipName(String relationshipName) {
		this.relationshipName = relationshipName;
	}
	public Integer getMaxQauntity() {
		return maxQauntity;
	}
	public void setMaxQauntity(Integer maxQauntity) {
		this.maxQauntity = maxQauntity;
	}	
	
    
}
