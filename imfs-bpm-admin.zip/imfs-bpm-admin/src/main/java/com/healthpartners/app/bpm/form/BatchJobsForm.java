package com.healthpartners.app.bpm.form;

/**
 * @author mxthoutam
 */
public class BatchJobsForm extends BaseForm {

    static final long serialVersionUID = 0L;

    private String operationType;


    public BatchJobsForm() {
        super();
    }


    public String getOperationType() {
        return operationType;
    }

    public void setOperationType(String operationType) {
        this.operationType = operationType;
    }

}
