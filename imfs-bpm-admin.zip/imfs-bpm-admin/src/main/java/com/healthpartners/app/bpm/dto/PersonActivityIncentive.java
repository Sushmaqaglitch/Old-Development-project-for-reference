package com.healthpartners.app.bpm.dto;

import java.io.Serializable;

/**
 * 
 * @author jxbourbour
 *
 */
public class PersonActivityIncentive implements Serializable
{	
	static final long serialVersionUID = 0L;

	private Integer personDemographicsID;
	private Integer businessProgramID;
	private Integer activityID;
	private String activityName;
	private Integer activityIncentiveID;
	private Integer incentiveOptionID;    
    private String incentiveOptionName;
    private String incentiveOptionDesc;    
    private String incentiveOptionUnitTypeCode;
    private Integer participantCap;
    private Integer familyCap;
    private Integer activityStatusCodeID;
    private String activityStatusCode;
    private String registrationID; 
    private String incentedStatusTypeCode;
    private String sourceActivityID;
		
    private java.sql.Date activityDate;
	
    
	public PersonActivityIncentive()
    {
    	super();
    }


	public Integer getActivityID() {
		return activityID;
	}


	public void setActivityID(Integer activityID) {
		this.activityID = activityID;
	}


	public String getActivityName() {
		return activityName;
	}


	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}


	public Integer getActivityIncentiveID() {
		return activityIncentiveID;
	}


	public void setActivityIncentiveID(Integer activityIncentiveID) {
		this.activityIncentiveID = activityIncentiveID;
	}


	public Integer getIncentiveOptionID() {
		return incentiveOptionID;
	}


	public void setIncentiveOptionID(Integer incentiveOptionID) {
		this.incentiveOptionID = incentiveOptionID;
	}


	public String getIncentiveOptionName() {
		return incentiveOptionName;
	}


	public void setIncentiveOptionName(String incentiveOptionName) {
		this.incentiveOptionName = incentiveOptionName;
	}


	public Integer getActivityStatusCodeID() {
		return activityStatusCodeID;
	}


	public void setActivityStatusCodeID(Integer activityStatusCodeID) {
		this.activityStatusCodeID = activityStatusCodeID;
	}


	public String getActivityStatusCode() {
		return activityStatusCode;
	}


	public void setActivityStatusCode(String activityStatusCode) {
		this.activityStatusCode = activityStatusCode;
	}


	public String getRegistrationID() {
		return registrationID;
	}


	public void setRegistrationID(String registrationID) {
		this.registrationID = registrationID;
	}


	public java.sql.Date getActivityDate() {
		return activityDate;
	}


	public void setActivityDate(java.sql.Date activityDate) {
		this.activityDate = activityDate;
	}


	public Integer getPersonDemographicsID() {
		return personDemographicsID;
	}


	public void setPersonDemographicsID(Integer personDemographicsID) {
		this.personDemographicsID = personDemographicsID;
	}


	public Integer getBusinessProgramID() {
		return businessProgramID;
	}


	public void setBusinessProgramID(Integer businessProgramID) {
		this.businessProgramID = businessProgramID;
	}


	public String getIncentiveOptionDesc() {
		return incentiveOptionDesc;
	}


	public void setIncentiveOptionDesc(String incentiveOptionDesc) {
		this.incentiveOptionDesc = incentiveOptionDesc;
	}	

	public String getIncentedStatusTypeCode() {
		return incentedStatusTypeCode;
	}


	public void setIncentedStatusTypeCode(String incentedStatusTypeCode) {
		this.incentedStatusTypeCode = incentedStatusTypeCode;
	}


	public Integer getParticipantCap() {
		return participantCap;
	}


	public void setParticipantCap(Integer participantCap) {
		this.participantCap = participantCap;
	}


	public Integer getFamilyCap() {
		return familyCap;
	}


	public void setFamilyCap(Integer familyCap) {
		this.familyCap = familyCap;
	}


	public String getIncentiveOptionUnitTypeCode() {
		return incentiveOptionUnitTypeCode;
	}


	public void setIncentiveOptionUnitTypeCode(String incentiveOptionUnitTypeCode) {
		this.incentiveOptionUnitTypeCode = incentiveOptionUnitTypeCode;
	}


	public String getSourceActivityID() {
		return sourceActivityID;
	}


	public void setSourceActivityID(String sourceActivityID) {
		this.sourceActivityID = sourceActivityID;
	}

	

		
}
