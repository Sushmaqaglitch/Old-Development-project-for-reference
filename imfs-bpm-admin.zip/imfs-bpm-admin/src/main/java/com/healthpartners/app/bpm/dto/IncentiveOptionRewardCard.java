package com.healthpartners.app.bpm.dto;

import java.io.Serializable;
import java.sql.Date;

public class IncentiveOptionRewardCard implements Serializable
{	
	static final long serialVersionUID = 0L;
	
	private Integer incentiveOptionRewardCardID;
	private Integer rewardCardID;
	private String quoteNo;
	private String  quoteDesc;
	private Integer rewardCardFeeID;
	private String  rewardCardFeeDesc;
	private Integer rewardEmbossedLineID;
	private String  rewardEmbossedLineDesc;
	private Integer rewardCarrierMessageID;
	private String  rewardCarrierMessageDesc;
	private Integer rewardTransactionMessageID;
	private String  rewardTransactionMessageDesc;
	private String  incentiveOptionRewardCardName;
	private String  incentiveOptionRewardCardDesc;
	private Integer rewardCardClientContactID;
	private String rewardCardClientDataName;
	private Date	effectiveDate;
	private Date    endDate;
	
	private Integer used;
	
	public Integer getIncentiveOptionRewardCardID() {
		return incentiveOptionRewardCardID;
	}
	public void setIncentiveOptionRewardCardID(Integer incentiveOptionRewardCardID) {
		this.incentiveOptionRewardCardID = incentiveOptionRewardCardID;
	}
	public Integer getRewardCardID() {
		return rewardCardID;
	}
	public void setRewardCardID(Integer rewardCardID) {
		this.rewardCardID = rewardCardID;
	}

	public String getQuoteNo() {
		return quoteNo;
	}

	public void setQuoteNo(String quoteNo) {
		this.quoteNo = quoteNo;
	}

	public String getQuoteDesc() {
		return quoteDesc;
	}

	public void setQuoteDesc(String quoteDesc) {
		this.quoteDesc = quoteDesc;
	}

	public Integer getRewardCardFeeID() {
		return rewardCardFeeID;
	}
	public void setRewardCardFeeID(Integer rewardCardFeeID) {
		this.rewardCardFeeID = rewardCardFeeID;
	}
	public Integer getRewardEmbossedLineID() {
		return rewardEmbossedLineID;
	}
	public void setRewardEmbossedLineID(Integer rewardEmbossedLineID) {
		this.rewardEmbossedLineID = rewardEmbossedLineID;
	}
	public Integer getRewardCarrierMessageID() {
		return rewardCarrierMessageID;
	}
	public void setRewardCarrierMessageID(Integer rewardCarrierMessageID) {
		this.rewardCarrierMessageID = rewardCarrierMessageID;
	}
	
	public Integer getRewardTransactionMessageID() {
		return rewardTransactionMessageID;
	}
	public void setRewardTransactionMessageID(Integer rewardTransactionMessageID) {
		this.rewardTransactionMessageID = rewardTransactionMessageID;
	}
	public String getIncentiveOptionRewardCardName() {
		return incentiveOptionRewardCardName;
	}
	public void setIncentiveOptionRewardCardName(
			String incentiveOptionRewardCardName) {
		this.incentiveOptionRewardCardName = incentiveOptionRewardCardName;
	}
	public String getIncentiveOptionRewardCardDesc() {
		return incentiveOptionRewardCardDesc;
	}
	public void setIncentiveOptionRewardCardDesc(
			String incentiveOptionRewardCardDesc) {
		this.incentiveOptionRewardCardDesc = incentiveOptionRewardCardDesc;
	}
	public Date getEffectiveDate() {
		return effectiveDate;
	}
	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public Integer getUsed() {
		return used;
	}
	public void setUsed(Integer used) {
		this.used = used;
	}
	public String getRewardEmbossedLineDesc() {
		return rewardEmbossedLineDesc;
	}
	public void setRewardEmbossedLineDesc(String rewardEmbossedLineDesc) {
		this.rewardEmbossedLineDesc = rewardEmbossedLineDesc;
	}
	public String getRewardCarrierMessageDesc() {
		return rewardCarrierMessageDesc;
	}
	public void setRewardCarrierMessageDesc(String rewardCarrierMessageDesc) {
		this.rewardCarrierMessageDesc = rewardCarrierMessageDesc;
	}
	public String getRewardTransactionMessageDesc() {
		return rewardTransactionMessageDesc;
	}
	public void setRewardTransactionMessageDesc(String rewardTransactionMessageDesc) {
		this.rewardTransactionMessageDesc = rewardTransactionMessageDesc;
	}
	public String getRewardCardFeeDesc() {
		return rewardCardFeeDesc;
	}
	public void setRewardCardFeeDesc(String rewardCardFeeDesc) {
		this.rewardCardFeeDesc = rewardCardFeeDesc;
	}
	public final Integer getRewardCardClientContactID() {
		return rewardCardClientContactID;
	}
	public final void setRewardCardClientContactID(Integer rewardCardClientContactID) {
		this.rewardCardClientContactID = rewardCardClientContactID;
	}
	public final String getRewardCardClientDataName() {
		return rewardCardClientDataName;
	}
	public final void setRewardCardClientDataName(String rewardCardClientDataName) {
		this.rewardCardClientDataName = rewardCardClientDataName;
	}

	
	
}
