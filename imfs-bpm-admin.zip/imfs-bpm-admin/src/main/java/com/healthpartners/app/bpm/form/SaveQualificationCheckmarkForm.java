/**
 * 
 */
package com.healthpartners.app.bpm.form;


/**
 * @author jxbourbour
 *
 */
public class SaveQualificationCheckmarkForm extends BaseForm {

	static final long serialVersionUID = 0L;

	String qualificationCheckmarkID;
	String qualificationCheckmarkName;
	String qualificationCheckmarkInfo;
	String qualificationCheckmarkDesc;
	
	private String effectiveDate;
	private String endDate;
	
	String[] quantities;
	String[] activityIDs;
	String[] activityTypeCodeIDs;
	String[] collectionIDs;
	String[] qualificationStatusCodeIDs;
	
	Integer requirementID;
	Integer activityID;
	Integer activityTypeCodeID;
	Integer rowID;
	String previousActionType;
	String[] checkmarkRequirements;

	public SaveQualificationCheckmarkForm() {
		super();
	}


	public String getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(String effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getQualificationCheckmarkDesc() {
		return qualificationCheckmarkDesc;
	}

	public void setQualificationCheckmarkDesc(String qualificationCheckmarkDesc) {
		this.qualificationCheckmarkDesc = qualificationCheckmarkDesc;
	}

	public String getQualificationCheckmarkID() {
		return qualificationCheckmarkID;
	}

	public void setQualificationCheckmarkID(String qualificationCheckmarkID) {
		this.qualificationCheckmarkID = qualificationCheckmarkID;
	}

	public String getQualificationCheckmarkInfo() {
		return qualificationCheckmarkInfo;
	}

	public void setQualificationCheckmarkInfo(String qualificationCheckmarkInfo) {
		this.qualificationCheckmarkInfo = qualificationCheckmarkInfo;
	}

	public String getQualificationCheckmarkName() {
		return qualificationCheckmarkName;
	}

	public void setQualificationCheckmarkName(String qualificationCheckmarkName) {
		this.qualificationCheckmarkName = qualificationCheckmarkName;
	}
	

	public Integer getActivityID() {
		return activityID;
	}

	public void setActivityID(Integer activityID) {
		this.activityID = activityID;
	}

	public Integer getActivityTypeCodeID() {
		return activityTypeCodeID;
	}

	public void setActivityTypeCodeID(Integer activityTypeCodeID) {
		this.activityTypeCodeID = activityTypeCodeID;
	}

	public Integer getRequirementID() {
		return requirementID;
	}

	public void setRequirementID(Integer requirementID) {
		this.requirementID = requirementID;
	}

	

	public Integer getRowID() {
		return rowID;
	}

	public void setRowID(Integer rowID) {
		this.rowID = rowID;
	}

	public final String[] getCollectionIDs() {
		return collectionIDs;
	}

	public final void setCollectionIDs(String[] collectionIDs) {
		this.collectionIDs = collectionIDs;
	}

	public String[] getQualificationStatusCodeIDs() {
		return qualificationStatusCodeIDs;
	}

	public void setQualificationStatusCodeIDs(String[] qualificationStatusCodeIDs) {
		this.qualificationStatusCodeIDs = qualificationStatusCodeIDs;
	}

	public final String[] getQuantities() {
		return quantities;
	}

	public final void setQuantities(String[] quantities) {
		this.quantities = quantities;
	}

	public final String[] getActivityIDs() {
		return activityIDs;
	}

	public final void setActivityIDs(String[] activityIDs) {
		this.activityIDs = activityIDs;
	}

	public final String[] getActivityTypeCodeIDs() {
		return activityTypeCodeIDs;
	}

	public final void setActivityTypeCodeIDs(String[] activityTypeCodeIDs) {
		this.activityTypeCodeIDs = activityTypeCodeIDs;
	}

	public String getPreviousActionType() {
		return previousActionType;
	}

	public void setPreviousActionType(String previousActionType) {
		this.previousActionType = previousActionType;
	}

	public String[] getCheckmarkRequirements() {
		return checkmarkRequirements;
	}

	public void setCheckmarkRequirements(String[] checkmarkRequirements) {
		this.checkmarkRequirements = checkmarkRequirements;
	}
}
