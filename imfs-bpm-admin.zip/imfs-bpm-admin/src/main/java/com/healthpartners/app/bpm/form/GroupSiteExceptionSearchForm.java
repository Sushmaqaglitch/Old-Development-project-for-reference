package com.healthpartners.app.bpm.form;

/**
 * @author tjquist
 */
public class GroupSiteExceptionSearchForm extends BaseForm {
    static final long serialVersionUID = 0L;

    private String groupNumber;
    private String groupName;
    private Integer groupID;
    private String whichList;
    private Integer groupOverrideID;


    public GroupSiteExceptionSearchForm() {
        super();
    }

    public String getGroupNumber() {
        return groupNumber;
    }

    public void setGroupNumber(String groupNumber) {
        this.groupNumber = groupNumber;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public Integer getGroupID() {
        return groupID;
    }

    public void setGroupID(Integer groupID) {
        this.groupID = groupID;
    }

    public String getWhichList() {
        return whichList;
    }

    public void setWhichList(String whichList) {
        this.whichList = whichList;
    }

    public Integer getGroupOverrideID() {
        return groupOverrideID;
    }

    public void setGroupOverrideID(Integer groupOverrideID) {
        this.groupOverrideID = groupOverrideID;
    }
}
