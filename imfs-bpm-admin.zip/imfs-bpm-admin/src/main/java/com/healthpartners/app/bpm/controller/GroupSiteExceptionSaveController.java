package com.healthpartners.app.bpm.controller;

import com.healthpartners.app.bpm.common.BPMAdminConstants;
import com.healthpartners.app.bpm.common.BPMAdminUtils;
import com.healthpartners.app.bpm.dao.LookUpValueDAO;
import com.healthpartners.app.bpm.dto.EmployerGroup;
import com.healthpartners.app.bpm.dto.GroupOverride;
import com.healthpartners.app.bpm.dto.LookUpValueCode;
import com.healthpartners.app.bpm.dto.ProgramType;
import com.healthpartners.app.bpm.exception.BPMException;
import com.healthpartners.app.bpm.form.SaveGroupSiteExceptionForm;
import com.healthpartners.app.bpm.iface.BusinessProgramService;
import com.healthpartners.app.bpm.service.GroupSiteExceptionService;
import jakarta.servlet.http.HttpServletRequest;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.ArrayList;
import java.util.Iterator;

@Controller
public class GroupSiteExceptionSaveController extends BaseController implements Validator {

    private final BusinessProgramService businessProgramService;
    private final GroupSiteExceptionService groupSiteExceptionService;

    private final LookUpValueDAO lookUpValueDAO;
    private final Log logger = LogFactory.getLog(getClass());

    public GroupSiteExceptionSaveController(BusinessProgramService businessProgramService, GroupSiteExceptionService groupSiteExceptionService, LookUpValueDAO lookUpValueDAO) {
        this.businessProgramService = businessProgramService;
        this.groupSiteExceptionService = groupSiteExceptionService;
        this.lookUpValueDAO = lookUpValueDAO;
    }

    @GetMapping("/editGroupSiteException")
    public String load(@RequestParam(name = "groupOverrideId") Integer groupOverrideId, ModelMap modelMap) throws BPMException {
        try {
            getUserSession().setCopyGroupSiteException(false);
            getUserSession().setAddGroupSiteException(false);
            getUserSession().setGroupSiteDisabled(true);
            populateFormAndModel(modelMap, groupOverrideId);

        } catch (Exception e) {
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
            modelMap.put("errorMsg", getStackTrace(e));
        }

        return "editGroupSiteException";
    }

    @GetMapping("/copyGroupSiteException")
    public String copy(@RequestParam(name = "groupOverrideId") Integer groupOverrideId, ModelMap modelMap) throws BPMException {
        try {
            getUserSession().setCopyGroupSiteException(true);
            getUserSession().setAddGroupSiteException(false);
            getUserSession().setGroupSiteDisabled(false);
            populateFormAndModel(modelMap, groupOverrideId);

        } catch (Exception e) {
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
            modelMap.put("errorMsg", getStackTrace(e));
        }

        return "editGroupSiteException";
    }

    @PostMapping("/saveGroupSiteException")
    public String submit(@ModelAttribute("saveGroupSiteExceptionForm") SaveGroupSiteExceptionForm saveGroupSiteExceptionForm, ModelMap modelMap, BindingResult result, RedirectAttributes ra) throws Exception {
        String resultPage = "editGroupSiteException";

        try {
            if(ACTION_ADD.equals(saveGroupSiteExceptionForm.getActionType())) {
                addGroupSiteException(modelMap, saveGroupSiteExceptionForm);
                setAttributes(modelMap);
                modelMap.put("isAddGroupSiteException", true);
                return resultPage;

            } else if(ACTION_REMOVE.equals(saveGroupSiteExceptionForm.getActionType())) {
                removeAssignedGroupSiteException(saveGroupSiteExceptionForm);
                setAttributes(modelMap);
                modelMap.put("isAddGroupSiteException", true);
                return resultPage;

            } else if (ACTION_SAVE.equals(saveGroupSiteExceptionForm.getActionType()) ||
                    ACTION_SAVE_TO_ALL_SITES.equals(saveGroupSiteExceptionForm.getActionType()) ||
                    ACTION_SAVE_TO_SELECTED.equals(saveGroupSiteExceptionForm.getActionType())) {

                validate(saveGroupSiteExceptionForm, result);
                if (result.hasErrors()) {
                    populateFormAndModelForValidation(modelMap);
                    return resultPage;
                }

                if (getUserSession().isAddGroupSiteException()) {
                    if(ACTION_SAVE_TO_SELECTED.equals(saveGroupSiteExceptionForm.getActionType()) && CollectionUtils.isEmpty(getUserSession().getAssignedSitesForGroupSiteException())) {
                        createActionMessagesOnModel(modelMap, "errors.assignedSitesMissing", null);
                        populateFormAndModelForValidation(modelMap);
                        return resultPage;
                    }
                }

                GroupOverride lGroupSiteException = initGroupOverride(saveGroupSiteExceptionForm, getUserSessionSupport().getAuthenticatedUsername());

                if (getUserSession().isCopyGroupSiteException() && isDuplicateGroupSiteException(lGroupSiteException)) {
                    createErrorMessageOnModel(modelMap, getMessage("errors.duplicate.groupsiteexception", new Object[]{"Duplicate Group Site Exception"}));
                    populateFormAndModelForValidation(modelMap);

                    return resultPage;
                }

                return saveGroupSiteException(lGroupSiteException, saveGroupSiteExceptionForm.getActionType(), modelMap, ra);
            }

        } catch (Exception e) {
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
            // Add error stack trace on the request, to be hidden in html.
            createErrorMessageOnModel(modelMap, getStackTrace(e));
        }

        return resultPage;
    }

    @PostMapping(value = "/saveGroupSiteException", params = "cancel")
    public String submitCancelEditProgramActivityIncentive(@ModelAttribute("saveGroupSiteExceptionForm") SaveGroupSiteExceptionForm saveGroupSiteExceptionForm, RedirectAttributes ra) {
        return performRedirectBackToSearch(saveGroupSiteExceptionForm.getGroupNo(), saveGroupSiteExceptionForm.getGroupName(), ra);
    }

    @GetMapping(value = "/addGroupSiteException")
    public String submitAdd(ModelMap modelMap, HttpServletRequest request) throws BPMException {
        String resultPage = "editGroupSiteException";
        try {
            getUserSession().setCopyGroupSiteException(false);
            getUserSession().setAddGroupSiteException(true);
            getUserSession().setGroupSiteDisabled(false);
            populateFormAndModelForAdd(modelMap);

        } catch (Exception e) {
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
            modelMap.put("errorMsg", getStackTrace(e));
        }

        return resultPage;
    }

    private void populateFormAndModel(ModelMap modelMap, Integer groupOverrideId) throws BPMException {
        SaveGroupSiteExceptionForm saveGroupSiteExceptionForm = new SaveGroupSiteExceptionForm();
        modelMap.put("saveGroupSiteExceptionForm", saveGroupSiteExceptionForm);

        GroupOverride lGroupSiteException = groupSiteExceptionService.getGroupOverride(groupOverrideId);
        if (getUserSession().isCopyGroupSiteException()) {
            lGroupSiteException.setGroupOverrideId(null);
        }
        getUserSession().setGroupSiteException(lGroupSiteException);
        modelMap.put("groupSiteException", getUserSession().getGroupSiteException());

        populateSelects(modelMap);

        //Lookup group site exemption id description.
        Iterator<LookUpValueCode> iter = getUserSession().getGroupSiteExceptionTypes().iterator();
        while (iter.hasNext()) {
            LookUpValueCode lookupValueCode = (LookUpValueCode) iter.next();
            if (lookupValueCode.getLuvId().equals(lGroupSiteException.getExceptionTypeCodeId())) {
                lGroupSiteException.setExceptionTypeCodeId(lookupValueCode.getLuvId());
                lGroupSiteException.setExceptionTypeDesc(lookupValueCode.getLuvVal());
            }
        }

        saveGroupSiteExceptionForm.setGroupId(String.valueOf(lGroupSiteException.getGroupId()));
        saveGroupSiteExceptionForm.setGroupNo(lGroupSiteException.getGroupNo());
        saveGroupSiteExceptionForm.setGroupName(lGroupSiteException.getGroupName());
        saveGroupSiteExceptionForm.setGroupOverrideId(lGroupSiteException.getGroupOverrideId() != null ? String.valueOf(lGroupSiteException.getGroupOverrideId()) : null);
        saveGroupSiteExceptionForm.setSiteNo(lGroupSiteException.getSiteNo());
        saveGroupSiteExceptionForm.setSiteName(lGroupSiteException.getSiteName());
        saveGroupSiteExceptionForm.setSubgroupID(String.valueOf(lGroupSiteException.getSiteId()));
        saveGroupSiteExceptionForm.setProgramTypeCode(lGroupSiteException.getBizProgTypeCodeId());
        saveGroupSiteExceptionForm.setLuvExceptionTypeID(String.valueOf(lGroupSiteException.getExceptionTypeCodeId()));
        saveGroupSiteExceptionForm.setExceptionReason(lGroupSiteException.getReason());
        saveGroupSiteExceptionForm.setApproverID(lGroupSiteException.getApproverId());
        saveGroupSiteExceptionForm.setIssueDate(lGroupSiteException.getIssueDate() != null ? getFmt().format(lGroupSiteException.getIssueDate()) : "");
        saveGroupSiteExceptionForm.setEffectiveDate(lGroupSiteException.getEffectiveDate() != null ? getFmt().format(lGroupSiteException.getIssueDate()) : "");
        saveGroupSiteExceptionForm.setEndDate(lGroupSiteException.getEndDate() != null ? getFmt().format(lGroupSiteException.getEndDate()) : "");

        modelMap.put("isAddGroupSiteException", getUserSession().isAddGroupSiteException());
        modelMap.put("isCopyGroupSiteException", getUserSession().isCopyGroupSiteException());
        modelMap.put("isGroupSiteDisabled", getUserSession().isGroupSiteDisabled());
    }

    private void populateFormAndModelForValidation(ModelMap modelMap) throws BPMException {
        modelMap.put("groupSiteException", getUserSession().getGroupSiteException());
        modelMap.put("isGroupSiteDisabled", getUserSession().isGroupSiteDisabled());
        modelMap.put("isAddGroupSiteException", getUserSession().isAddGroupSiteException());
        populateSelects(modelMap);
        setAttributes(modelMap);
    }

    private void populateFormAndModelForAdd(ModelMap modelMap) throws BPMException {
        SaveGroupSiteExceptionForm saveGroupSiteExceptionForm = new SaveGroupSiteExceptionForm();

        Integer groupID = (Integer) modelMap.getAttribute("groupID");
        saveGroupSiteExceptionForm.setGroupId(String.valueOf(groupID));

        GroupOverride lGroupSiteException = new GroupOverride();
        lGroupSiteException.setGroupId(Integer.valueOf(saveGroupSiteExceptionForm.getGroupId()));

        ArrayList<EmployerGroup> lEmployerSubGroups = (ArrayList<EmployerGroup>) businessProgramService.getSubGroups(Integer.valueOf(saveGroupSiteExceptionForm.getGroupId()));

        if (lEmployerSubGroups != null && lEmployerSubGroups.size() > 0) {
            EmployerGroup lEmployerGroup = lEmployerSubGroups.get(0);
            saveGroupSiteExceptionForm.setGroupNo(lEmployerGroup.getGroupNumber());
            saveGroupSiteExceptionForm.setGroupName(lEmployerGroup.getGroupName());
            lGroupSiteException.setGroupNo(lEmployerGroup.getGroupNumber());
            lGroupSiteException.setGroupName(lEmployerGroup.getGroupName());
        }

        ArrayList<GroupOverride> lAssignedSitesForGroupSiteException = businessProgramService.getAssignedSitesForGroupSiteException(saveGroupSiteExceptionForm.getGroupNo());
        ArrayList<GroupOverride> lAvailableSitesForGroupSiteException = businessProgramService.getAvailableSitesForGroupSiteException(saveGroupSiteExceptionForm.getGroupNo());

        lGroupSiteException.setBizProgTypeCodeId("0");
        lGroupSiteException.setBizProgramName("select");
        lGroupSiteException.setSiteId(Integer.valueOf("999"));
        lGroupSiteException.setSiteName("select");
        lGroupSiteException.setExceptionTypeCodeId(Integer.valueOf("0"));
        lGroupSiteException.setExceptionTypeDesc("select");
        lGroupSiteException.setGroupId(Integer.valueOf(saveGroupSiteExceptionForm.getGroupId()));

        getUserSession().setGroupSiteException(lGroupSiteException);

        modelMap.put("saveGroupSiteExceptionForm", saveGroupSiteExceptionForm);

        modelMap.put("isGroupSiteDisabled", getUserSession().isGroupSiteDisabled());
        modelMap.put("isAddGroupSiteException", getUserSession().isAddGroupSiteException());
        modelMap.put("groupSiteException", lGroupSiteException);
        modelMap.put("employerSubGroups", lEmployerSubGroups);
        modelMap.put("availableSitesForGroupSiteException", lAvailableSitesForGroupSiteException);
        modelMap.put("assignedSitesForGroupSiteException", lAssignedSitesForGroupSiteException);
        modelMap.put("isAddGroupSiteException", true);

        getUserSession().setEmployerSubGroups(lEmployerSubGroups);
        getUserSession().setAvailableSitesForGroupSiteException(lAvailableSitesForGroupSiteException);
        getUserSession().setAssignedSitesForGroupSiteException(lAssignedSitesForGroupSiteException);

        populateSelects(modelMap);
    }

    private void populateSelects(ModelMap modelMap) throws BPMException {
        ArrayList<ProgramType> lProgramTypes = getUserSession().getProgramTypes();
        if (CollectionUtils.isEmpty(lProgramTypes)) {
            lProgramTypes = (ArrayList<ProgramType>) businessProgramService.getProgramTypes();
            getUserSession().setProgramTypes(lProgramTypes);
        }

        ArrayList<LookUpValueCode> lGroupSiteExceptionTypes =  getUserSession().getGroupSiteExceptionTypes();
        if (CollectionUtils.isEmpty(lGroupSiteExceptionTypes)) {
            lGroupSiteExceptionTypes = (ArrayList<LookUpValueCode>) lookUpValueDAO.getLUVCodesByGroup(BPMAdminConstants.BPM_LUV_GROUP_SITE_EXCEPT_TYPES);
            getUserSession().setGroupSiteExceptionTypes(lGroupSiteExceptionTypes);
        }

        ArrayList<EmployerGroup> lEmployerSubGroups = getUserSession().getEmployerSubGroups();
        if (CollectionUtils.isEmpty(lEmployerSubGroups)) {
            lEmployerSubGroups = (ArrayList<EmployerGroup>) businessProgramService.getSubGroups(Integer.valueOf(getUserSession().getGroupSiteException().getGroupId()));
            getUserSession().setEmployerSubGroups(lEmployerSubGroups);
        }

        modelMap.put("programTypes", getUserSession().getProgramTypes());
        modelMap.put("luvGroupSiteExceptionTypes", getUserSession().getGroupSiteExceptionTypes());
        modelMap.put("employerSubGroups", getUserSession().getEmployerSubGroups());
    }

    private GroupOverride initGroupOverride(SaveGroupSiteExceptionForm lSaveGroupSiteExceptionForm, String userID) {
        GroupOverride lGroupSiteException = new GroupOverride();

        lGroupSiteException.setGroupNo(lSaveGroupSiteExceptionForm.getGroupNo());
        lGroupSiteException.setGroupName(lSaveGroupSiteExceptionForm.getGroupName());

        if (!lSaveGroupSiteExceptionForm.getGroupOverrideId().isEmpty()) {
            lGroupSiteException.setGroupOverrideId(Integer.valueOf(lSaveGroupSiteExceptionForm.getGroupOverrideId()));
        }
        lGroupSiteException.setUserId(userID);

        lGroupSiteException.setGroupId(Integer.valueOf(lSaveGroupSiteExceptionForm.getGroupId()));

        if (lSaveGroupSiteExceptionForm.getSubgroupID() == null) {
            if (getUserSession().getGroupSiteException().getSiteId() != null) {
                lGroupSiteException.setSiteName(getUserSession().getGroupSiteException().getSiteName());
                lGroupSiteException.setSiteNo(getUserSession().getGroupSiteException().getSiteNo());
                lGroupSiteException.setSiteId(getUserSession().getGroupSiteException().getSiteId());
            } else {
                lGroupSiteException.setSiteName("select");
                //NA - Not available
                lGroupSiteException.setSiteNo("NA");
                lGroupSiteException.setSiteId(0);
            }
        } else {
            lGroupSiteException.setSiteId(Integer.valueOf(lSaveGroupSiteExceptionForm.getSubgroupID()));

            //Check Site Name record and it's site code if value from
            //the form returns empty string or null.

            if (lGroupSiteException.getSiteName() == null) {
                //Lookup group site id description.
                Iterator<EmployerGroup> iter = getUserSession().getEmployerSubGroups().iterator();
                while (iter.hasNext()) {
                    EmployerGroup emplSubGroups = (EmployerGroup) iter.next();
                    if (emplSubGroups.getSubgroupID().equals(lGroupSiteException.getSiteId())) {
                        lGroupSiteException.setSiteName(emplSubGroups.getSiteName());
                        lGroupSiteException.setSiteNo(emplSubGroups.getSiteNumber());
                        lGroupSiteException.setSiteId(emplSubGroups.getSubgroupID());
                        break;
                    }
                }
            } else {
                lGroupSiteException.setSiteId(Integer.valueOf(lSaveGroupSiteExceptionForm.getSubgroupID()));
                lGroupSiteException.setSiteName(lSaveGroupSiteExceptionForm.getSiteName());
            }
        }

        //Check Program Name record and it's program type code id if value from
        //the form returns empty string.
        if (lSaveGroupSiteExceptionForm.getProgramTypeCode() == null || lSaveGroupSiteExceptionForm.getProgramTypeCode().equals("0") || lSaveGroupSiteExceptionForm.getProgramTypeCode().isEmpty()) {
            lGroupSiteException.setBizProgramName("select");
        } else {
            lGroupSiteException.setBizProgTypeCodeId(lSaveGroupSiteExceptionForm.getProgramTypeCode());
            //Lookup group site exemption id description.
            Iterator<ProgramType> iter = getUserSession().getProgramTypes().iterator();
            while (iter.hasNext()) {
                ProgramType programType = (ProgramType) iter.next();
                if (programType.getProgramTypeCode().equals(lGroupSiteException.getBizProgTypeCodeId())) {
                    lGroupSiteException.setBizProgramName(programType.getProgramTypeDesc());
                    break;
                }
            }
        }

        //Check Group Site Exception record and it's exception type code id if value from
        //the form returns empty string.

        if (lSaveGroupSiteExceptionForm.getLuvExceptionTypeID() == null || lSaveGroupSiteExceptionForm.getLuvExceptionTypeID().equals("0") || lSaveGroupSiteExceptionForm.getLuvExceptionTypeID().isEmpty()) {
            lGroupSiteException.setExceptionTypeDesc("select");
        } else {
            lGroupSiteException.setExceptionTypeCodeId(Integer.valueOf(lSaveGroupSiteExceptionForm.getLuvExceptionTypeID()));
            //Lookup group site exemption id description.
            Iterator<LookUpValueCode> iter = getUserSession().getGroupSiteExceptionTypes().iterator();
            while (iter.hasNext()) {
                LookUpValueCode lookupValueCode = (LookUpValueCode) iter.next();
                if (lookupValueCode.getLuvId().equals(lGroupSiteException.getExceptionTypeCodeId())) {
                    lGroupSiteException.setExceptionTypeDesc(lookupValueCode.getLuvVal());
                    break;
                }
            }
        }

        lGroupSiteException.setReason(lSaveGroupSiteExceptionForm.getExceptionReason());
        lGroupSiteException.setApproverId(lSaveGroupSiteExceptionForm.getApproverID());
        lGroupSiteException.setIssueDate(BPMAdminUtils.getSqlDateFromString(lSaveGroupSiteExceptionForm.getIssueDate()));
        lGroupSiteException.setEffectiveDate(BPMAdminUtils.getSqlDateFromString(lSaveGroupSiteExceptionForm.getEffectiveDate()));
        lGroupSiteException.setEndDate(BPMAdminUtils.getSqlDateFromString(lSaveGroupSiteExceptionForm.getEndDate()));

        getUserSession().setGroupSiteException(lGroupSiteException);

        return lGroupSiteException;
    }

    private void addGroupSiteException(ModelMap modelMap, SaveGroupSiteExceptionForm saveGroupSiteExceptionForm) throws BPMException {
        String siteNo = saveGroupSiteExceptionForm.getSiteNo();

        ArrayList<GroupOverride> lAssignedSitesForGroupSiteException = getUserSession().getAssignedSitesForGroupSiteException();
        ArrayList<GroupOverride> lAvailableSitesForGroupSiteException = getUserSession().getAvailableSitesForGroupSiteException();

        if (lAssignedSitesForGroupSiteException == null) {
            lAssignedSitesForGroupSiteException = new ArrayList<GroupOverride>();

            getUserSession().setAssignedSitesForGroupSiteException(lAssignedSitesForGroupSiteException);
        }

        // Find the group site exception whose ID matches the one selected.
        for (int i = 0; i < lAvailableSitesForGroupSiteException.size(); i++) {
            GroupOverride lAvailableSiteForGroupSiteException = (GroupOverride) lAvailableSitesForGroupSiteException.get(i);
            // Once the ID is found, add the Contract Benefit Type to the Program Contribution Tier Contract Benefit Type collection.
            if (lAvailableSiteForGroupSiteException.getSiteNo().equals(siteNo)) {
                lAssignedSitesForGroupSiteException.add(lAvailableSiteForGroupSiteException);
                lAvailableSitesForGroupSiteException.remove(i);
                break;
            }
        }

        getUserSession().setAssignedSitesForGroupSiteException(lAssignedSitesForGroupSiteException);

        populateSelects(modelMap);
    }

    private void removeAssignedGroupSiteException(SaveGroupSiteExceptionForm lSaveGroupSiteExceptionForm) {
        String siteNo = lSaveGroupSiteExceptionForm.getSiteNo();

        ArrayList<GroupOverride> lAssignedSitesForGroupSiteException = getUserSession().getAssignedSitesForGroupSiteException();
        ArrayList<GroupOverride> lAvailableSitesForGroupSiteException = getUserSession().getAvailableSitesForGroupSiteException();

        // Find the Group Site Exceptions whose site ID matches the one selected.
        for (int i = 0; i < lAssignedSitesForGroupSiteException.size(); i++) {
            GroupOverride lAssignedSiteForGroupSiteException = (GroupOverride) lAssignedSitesForGroupSiteException.get(i);
            // Once the ID is found, remove the Contract Benefit Type from the list of assigned contract benefit types
            // and add it back to the list of available contract benefit types.
            if (lAssignedSiteForGroupSiteException.getSiteNo().equals(siteNo)) {
                lAvailableSitesForGroupSiteException.add(lAssignedSiteForGroupSiteException);
                lAssignedSitesForGroupSiteException.remove(i);
                break;
            }
        }

        getUserSession().setAvailableSitesForGroupSiteException(lAvailableSitesForGroupSiteException);
        getUserSession().setAssignedSitesForGroupSiteException(lAssignedSitesForGroupSiteException);
    }

    private void setAttributes(ModelMap modelMap) {
        modelMap.put("assignedSitesForGroupSiteException", getUserSession().getAssignedSitesForGroupSiteException());
        modelMap.put("availableSitesForGroupSiteException", getUserSession().getAvailableSitesForGroupSiteException());
        modelMap.put("groupSiteException", getUserSession().getGroupSiteException());
        modelMap.put("isGroupSiteDisabled", getUserSession().isGroupSiteDisabled());
        modelMap.put("isAddGroupSiteException", getUserSession().isAddGroupSiteException());
        modelMap.put("employerSubGroups", getUserSession().getEmployerSubGroups());
    }

    private String saveGroupSiteException(GroupOverride lGroupSiteException, String actionType, ModelMap modelMap, RedirectAttributes ra) throws Exception {
        int updCtr = 0;
        if(ACTION_SAVE_TO_SELECTED.equals(actionType)) {
            updCtr = saveAssignedSitesGroupSiteExceptions(lGroupSiteException);
            return performRedirectBackToSearch(lGroupSiteException.getGroupNo(), lGroupSiteException.getGroupName(), ra);
        } else if(ACTION_SAVE_TO_ALL_SITES.equals(actionType)) {
            updCtr = saveAllSitesGroupSiteExceptions(lGroupSiteException, modelMap);
            return performRedirectBackToSearch(lGroupSiteException.getGroupNo(), lGroupSiteException.getGroupName(), ra);
        } else if(ACTION_SAVE.equals(actionType)) {
            updCtr = groupSiteExceptionService.updateGroupOverride(lGroupSiteException);
            return performRedirectBackToSearch(lGroupSiteException.getGroupNo(), lGroupSiteException.getGroupName(), ra);
        }

        return "groupSiteExceptionSearch";
    }

    private String performRedirectBackToSearch(String groupNumber, String groupName, RedirectAttributes ra) {
        ra.addFlashAttribute("groupNumber", groupNumber);
        ra.addFlashAttribute("groupName", groupName);
        ra.addFlashAttribute("actionType", ACTION_SEARCH);
        return "redirect:groupSiteExceptionSearch";
    }

    private int saveAssignedSitesGroupSiteExceptions(GroupOverride lGroupSiteException) {
        int updCtrTotal = 0;
        ArrayList<GroupOverride> lGroupOverridesAssigned = getUserSession().getAssignedSitesForGroupSiteException();

        if (lGroupOverridesAssigned != null) {
            for (GroupOverride lGroupOverrideAssigned : lGroupOverridesAssigned) {
                GroupOverride lGroupSiteExceptionDetail = assignGroupSiteExceptionSiteNo(lGroupOverrideAssigned, lGroupSiteException);
                int updCtr = groupSiteExceptionService.updateGroupOverride(lGroupSiteExceptionDetail);
                updCtrTotal = updCtrTotal + updCtr;
            }
        }

        return updCtrTotal;
    }

    private int saveAllSitesGroupSiteExceptions(GroupOverride lGroupSiteException, ModelMap modelMap) {

        int updCtr = 0;
        ArrayList<GroupOverride> lGroupSiteExceptionsAssigned = (ArrayList<GroupOverride>) groupSiteExceptionService.getGroupOverrideByGroupNumber(lGroupSiteException.getGroupNo());

        if (lGroupSiteExceptionsAssigned.isEmpty()) {
            lGroupSiteExceptionsAssigned = addAllGroupSiteExceptions(modelMap);
        }

        if (lGroupSiteExceptionsAssigned != null) {
            for (GroupOverride lGroupSiteExceptionAssigned : lGroupSiteExceptionsAssigned) {
                GroupOverride lGroupSiteExceptionDetail = assignGroupSiteExceptionSiteNo(lGroupSiteExceptionAssigned, lGroupSiteException);
                updCtr = groupSiteExceptionService.updateGroupOverride(lGroupSiteExceptionDetail);
            }
        }

        return updCtr;
    }

    private GroupOverride assignGroupSiteExceptionSiteNo(GroupOverride lGroupOverrideAssigned, GroupOverride lGroupSiteException) {
        lGroupSiteException.setGroupOverrideId(lGroupOverrideAssigned.getGroupOverrideId());
        lGroupSiteException.setSiteId(lGroupOverrideAssigned.getSiteId());
        lGroupSiteException.setSiteNo(lGroupOverrideAssigned.getSiteNo());

        return lGroupSiteException;
    }

    private ArrayList<GroupOverride> addAllGroupSiteExceptions(ModelMap modelMap) {
        ArrayList<GroupOverride> lAssignedSitesForGroupSiteException = new ArrayList<GroupOverride>();
        ArrayList<GroupOverride> lAvailableSitesForGroupSiteException = getUserSession().getAvailableSitesForGroupSiteException();

        // Find the group site exception whose ID matches the one selected.
        for (int i = 0; i < lAvailableSitesForGroupSiteException.size(); i++) {
            GroupOverride lAvailableSiteForGroupSiteException = lAvailableSitesForGroupSiteException.get(i);
            lAssignedSitesForGroupSiteException.add(lAvailableSiteForGroupSiteException);
        }

        lAvailableSitesForGroupSiteException.clear();

        getUserSession().setAssignedSitesForGroupSiteException(lAssignedSitesForGroupSiteException);

        modelMap.put("assignedSitesForGroupSiteException", lAssignedSitesForGroupSiteException);
        modelMap.put("availableSitesForGroupSiteException", lAvailableSitesForGroupSiteException);

        return lAssignedSitesForGroupSiteException;
    }

    @Override
    public boolean supports(Class<?> clazz) {
        return SaveGroupSiteExceptionForm.class.isAssignableFrom(clazz);
    }

    @Override
    public void validate(Object target, Errors errors) {
        SaveGroupSiteExceptionForm form = (SaveGroupSiteExceptionForm) target;

        if(ACTION_SAVE_TO_SELECTED.equals(form.getActionType()) || ACTION_SAVE_TO_ALL_SITES.equals(form.getActionType())) {
            //ignore edit since site id is available with the assigned sites.
        } else if (form.getSubgroupID() == null || form.getSubgroupID().equals("999")) {
            String subgroupIDStr = null;
            getValidationSupport().validateRequiredFieldIsNotEmptyOrZero("subgroupID", form.getSubgroupID(), errors, new Object[]{"Site Name"});
        }
        
        getValidationSupport().validateRequiredFieldIsNotEmptyOrZero("programTypeCode", form.getProgramTypeCode(), errors, new Object[]{"Program Name"});
        getValidationSupport().validateRequiredFieldIsNotEmptyOrZero("luvExceptionTypeID", form.getLuvExceptionTypeID(), errors, new Object[]{"Exception Type"});

        //At this time, don't allow program type that is not Smart Steps to be selected.
		/*if (!programTypeCode.equals("2")) {

			this.getActionMessages().add("programID", new ActionError(
						"messages.programTypeNotAllowedForSelection", "programID"));
		}*/

        boolean lIssueDateValid = getValidationSupport().validateDateFormat("issueDate", form.getIssueDate(), errors, new Object[]{"Exception Issue Date"});
        getValidationSupport().validateRequiredFieldIsNotEmpty("exceptionReason", form.getExceptionReason(), errors, new Object[]{"Exception Reason"});

        if (StringUtils.isNotEmpty(form.getExceptionReason())) {
            if (form.getExceptionReason().length() > BPMAdminConstants.BPM_GROUPOVRD_DESCRIPTION_LENGTH) {
                getValidationSupport().addValidationFailureMessage("exceptionReason", errors, "errors.maxlength", new Object[]{String.valueOf(BPMAdminConstants.BPM_GROUPOVRD_DESCRIPTION_LENGTH)});
            }
        }

        getValidationSupport().validateRequiredFieldIsNotEmpty("approverID", form.getApproverID(), errors, new Object[]{"Exception Approver"});

        boolean lEffectiveDateValid = getValidationSupport().validateDateFormat("effectiveDate", form.getEffectiveDate(), errors, new Object[]{"Effective Date"});
        boolean lEndDateValid = getValidationSupport().validateDateFormat("endDate", form.getEndDate(), errors, new Object[]{"End Date"});

        if (lEffectiveDateValid && lEndDateValid) {
            getValidationSupport().validateBeforeOrEqual("effectiveDate", form.getEffectiveDate(), form.getEndDate(), "Program Effective Date", errors, new Object[]{"End Date"});

        }

        if (lIssueDateValid && lEndDateValid) {
            getValidationSupport().validateBeforeOrEqual("issueDate", form.getIssueDate(), form.getEndDate(), "Issue Date", errors, new Object[]{"End Date"});
        }
    }

    private boolean isDuplicateGroupSiteException(GroupOverride lGroupSiteException) throws Exception {
        boolean result = false;
        try {
            ArrayList<GroupOverride> lGroupOverrides = (ArrayList<GroupOverride>) groupSiteExceptionService.getGroupOverrideByGroupID(lGroupSiteException.getGroupId());

            Iterator<GroupOverride> iter = lGroupOverrides.iterator();
            while (iter.hasNext()) {
                GroupOverride groupOverride = (GroupOverride) iter.next();
                if (groupOverride.getGroupId().equals(lGroupSiteException.getGroupId()) && groupOverride.getSiteId().equals(lGroupSiteException.getSiteId())) {
                    result = true;
                    break;
                }
            }

        } catch (Exception e) {
            logger.error("An unexpected error has occured in SaveGroupSiteException.isDuplicateGroupSiteException: " + e.getMessage(), e);
            throw new Exception(e);
        }

        return result;
    }

}
