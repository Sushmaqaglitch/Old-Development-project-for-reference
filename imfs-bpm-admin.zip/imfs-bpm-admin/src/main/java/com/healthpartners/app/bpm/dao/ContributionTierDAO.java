package com.healthpartners.app.bpm.dao;

import com.healthpartners.app.bpm.dto.*;
import com.healthpartners.app.bpm.exception.BPMException;
import org.springframework.dao.DataAccessException;

import java.util.ArrayList;

public interface ContributionTierDAO {
    int deleteProgramContributionIncentiveTierByProgramID(Integer lProgramID) throws BPMException, DataAccessException;

    int deleteProgramContributionTierByProgramID(Integer lProgramID) throws BPMException, DataAccessException;

    ArrayList<ProgramContributionTier> getProgramContributionIncentiveTiers(Integer programID, Integer incentiveOptionID, String incentedStatusTypeCode) throws BPMException, DataAccessException;

    ArrayList<ProgramContributionTier> getProgramContributionIncentiveTiersContractMemberLevel(Integer programID, Integer incentiveOptionID) throws BPMException, DataAccessException;

    boolean isActivityRequirementRegisteredToProgramTierContribution(ActivityIncentiveRequirement lActivityIncentiveRequirement) throws BPMException, DataAccessException;

    ArrayList<ContributionTierBenefitContractType> getAssignedContributionTierBenefitContractTypes(final Integer pTierTypeID, boolean isAllowRelationshipSelfOnly) throws BPMException, DataAccessException;

    /*
     * Determine if tier value id has a foreign key relationship to
     * tier_contribution table using the tier type id as a search target. If so,
     * then set flag to not allow "remove" link to appear with the assigned
     * Benefit Contract Types. In other words when the tier value row has a
     * parent child relationship to another table, then user of the Contribution
     * Tier definition screen cannot remove the assigned benefit contract type.
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    boolean determineUsedForTierValueParentRelationshipToTierContribution(Integer pTierTypeID, Integer pBenefitContractTypeID) throws DataAccessException;

    ArrayList<ContributionTierBenefitContractTypeRelationship> getContributionTierBenefitContractTypeRelationships(
            Integer pTierValueID, boolean isAllowRelationshipSelfOnly) throws BPMException,
            DataAccessException;

    ArrayList<ContributionTier> getAllContributionTiers() throws DataAccessException;

    int deleteProgramContributionTier(Integer lTierContributionID) throws BPMException, DataAccessException;

    int deleteProgramContributionIncentiveTier(Integer lTierContributionID) throws BPMException, DataAccessException;

    int updateProgramContributionTier(Integer activityIncentiveID, Integer groupID, Integer groupRequiredID, Integer qualificationCheckmarkDetailID, ProgramContributionTier pProgramContributionTier, String pModifyUserID) throws BPMException, DataAccessException;

    Long insertProgramContributionTier(ProgramContributionTier pProgramContributionTier, String pInsertUserID) throws BPMException, DataAccessException;

    int insertProgramContributionIncentiveTier(Long tierContribID,
                                           Integer activityIncentiveID, Integer groupID, Integer groupRequiredID, Integer qualificationCheckmarkDetailID,
                                           ProgramContributionTier pProgramContributionTier,
                                           String pModifyUserID) throws BPMException, DataAccessException;
}
