package com.healthpartners.app.bpm.dto;

import com.healthpartners.app.bpm.common.BPMAdminConstants;
import com.healthpartners.app.bpm.common.BPMAdminUtils;

import java.io.Serializable;

public class BenefitPackage implements Serializable {
    static final long serialVersionUID = 0L;

    private Integer programID;
    private Integer groupID;
    private Integer subGroupID;
    private Integer packageID;
    private String packageCode;
    private String packageName;
    private String benefitPackageType;
    private String insuredTypeName;
    private java.sql.Date effectiveDate;
    private java.sql.Date endDate;
    private String purchaserSubTypeName;
    private Integer purchaserSubTypeCodeID;
    private String purchaserSubTypeCode;
    private String description;

    private String effectiveDateString;
    private String endDateString;

    public BenefitPackage() {
        super();
    }

    public Integer getPackageID() {
        return packageID;
    }

    public void setPackageID(Integer packageID) {
        this.packageID = packageID;
    }

    public String getPackageCode() {
        return packageCode;
    }

    public void setPackageCode(String packageCode) {
        this.packageCode = packageCode;
    }

    public java.sql.Date getEffectiveDate() {
        return effectiveDate;
    }

    public void setEffectiveDate(java.sql.Date effectiveDate) {
        this.effectiveDate = effectiveDate;
    }

    public java.sql.Date getEndDate() {
        return endDate;
    }

    public void setEndDate(java.sql.Date endDate) {
        this.endDate = endDate;
    }

    public Integer getPurchaserSubTypeCodeID() {
        return purchaserSubTypeCodeID;
    }

    public void setPurchaserSubTypeCodeID(Integer purchaserSubTypeCodeID) {
        this.purchaserSubTypeCodeID = purchaserSubTypeCodeID;
    }

    public String getPurchaserSubTypeCode() {
        return purchaserSubTypeCode;
    }

    public void setPurchaserSubTypeCode(String purchaserSubTypeCode) {
        this.purchaserSubTypeCode = purchaserSubTypeCode;
    }

    public String getEffectiveDateString() {
        return BPMAdminUtils.formatDateMMddyyyy(effectiveDate);
    }

    public void setEffectiveDateString(String effectiveDateString) {
        this.effectiveDateString = effectiveDateString;
    }

    public String getEndDateString() {
        if (endDate == null) {
            return BPMAdminConstants.BPM_ADMIN_DEFAULT_END_DATE;
        }

        endDateString = BPMAdminUtils.formatDateMMddyyyy(endDate);

        if (endDateString == null || endDateString.length() < 1) {
            return BPMAdminConstants.BPM_ADMIN_DEFAULT_END_DATE;
        }

        return endDateString;
    }

    public void setEndDateString(String endDateString) {
        this.endDateString = endDateString;
    }

    public Integer getProgramID() {
        return programID;
    }

    public void setProgramID(Integer programID) {
        this.programID = programID;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getGroupID() {
        return groupID;
    }

    public void setGroupID(Integer groupID) {
        this.groupID = groupID;
    }

    public Integer getSubGroupID() {
        return subGroupID;
    }

    public void setSubGroupID(Integer subGroupID) {
        this.subGroupID = subGroupID;
    }

    public String getPackageName() {
        return packageName;
    }

    public void setPackageName(String packageName) {
        this.packageName = packageName;
    }

    public String getPurchaserSubTypeName() {
        return purchaserSubTypeName;
    }

    public void setPurchaserSubTypeName(String purchaserSubTypeName) {
        this.purchaserSubTypeName = purchaserSubTypeName;
    }

    public final String getBenefitPackageType() {
        return benefitPackageType;
    }

    public final void setBenefitPackageType(String benefitPackageType) {
        this.benefitPackageType = benefitPackageType;
    }

    public final String getInsuredTypeName() {
        return insuredTypeName;
    }

    public final void setInsuredTypeName(String insuredTypeName) {
        this.insuredTypeName = insuredTypeName;
    }


}
