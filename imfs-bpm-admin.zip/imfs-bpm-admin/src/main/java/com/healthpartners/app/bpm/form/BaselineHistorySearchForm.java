package com.healthpartners.app.bpm.form;

/**
 * @author jxbourbour
 * 
 */
public class BaselineHistorySearchForm extends BaseForm {

	static final long serialVersionUID = 0L;

	private String operationType;

	private String memberID;
	private Integer contractNo;
	private String programEffectiveDate;
	private String eligibilityHistoryResults;

	private String qualificationStartDate;

	private String personID;
	
	private String searchedMemberID;

	public BaselineHistorySearchForm() {
		super();
	}


	public String getMemberID() {
		if (memberID != null) {
			return memberID.trim();
		}
		return memberID;
	}

	public void setMemberID(String memberID) {
		this.memberID = memberID;
	}

	public String getOperationType() {
		return operationType;
	}

	public void setOperationType(String operationType) {
		this.operationType = operationType;
	}

	public String getQualificationStartDate() {
		return qualificationStartDate;
	}

	public void setQualificationStartDate(String qualificationStartDate) {
		this.qualificationStartDate = qualificationStartDate;
	}

	public String getPersonID() {
		return personID;
	}

	public void setPersonID(String personID) {
		this.personID = personID;
	}

	public String getSearchedMemberID() {
		if(searchedMemberID != null)
		{
			return searchedMemberID.trim();
		}
		return searchedMemberID;
	}

	public void setSearchedMemberID(String searchedMemberID) {
		this.searchedMemberID = searchedMemberID;
	}

	public Integer getContractNo() {
		return contractNo;
	}

	public void setContractNo(Integer contractNo) {
		this.contractNo = contractNo;
	}

	public String getProgramEffectiveDate() {
		return programEffectiveDate;
	}

	public void setProgramEffectiveDate(String programEffectiveDate) {
		this.programEffectiveDate = programEffectiveDate;
	}

	public String getEligibilityHistoryResults() {
		return eligibilityHistoryResults;
	}

	public void setEligibilityHistoryResults(String eligibilityHistoryResults) {
		this.eligibilityHistoryResults = eligibilityHistoryResults;
	}

		

}
