package com.healthpartners.app.bpm.controller;

import com.healthpartners.app.bpm.common.*;
import com.healthpartners.app.bpm.dto.*;
import com.healthpartners.app.bpm.form.BaseForm;
import com.healthpartners.app.bpm.iface.MemberService;
import com.healthpartners.app.bpm.pageable.PageableBusinessProgram;
import com.healthpartners.app.bpm.pageable.PageableEmployerGroup;
import com.healthpartners.app.bpm.pageable.PageableMemberDetail;
import com.healthpartners.app.bpm.pageable.PageablePersonContractHist;
import com.healthpartners.app.bpm.session.UserSession;
import jakarta.servlet.http.HttpServletRequest;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.ui.ModelMap;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.*;

public class BaseController {
    public static final String REQUIRED = "required";
    public static final String ACTION_PAGE_BACK = "goBackThruList";
    public static final String ACTION_PAGE_FORWARD = "goForwardThruList";
    public static final String ACTION_DOWNLOAD_CONTRIBUTIONS_PAGE = "downloadContributionsPage";
    public static final String ACTION_SEARCH = "search";
    public static final String ACTION_SUBMIT = "submit";
    public static final String ACTION_CANCEL = "cancel";
    public static final String ACTION_SAVE = "save";
    public static final String ACTION_UPDATE = "update";
    public static final String ACTION_SAVE_TO_ALL_SITES = "saveToAllSites";
    public static final String ACTION_SAVE_TO_SELECTED = "saveToSelected";
    public static final String ACTION_COPY = "copy";
    public static final String ACTION_REMOVE = "remove";
    public static final String ACTION_REFRESH_PAGE = "refresh";
    public static final String ACTION_ADD = "add";
    public static final String ACTION_DELETE = "delete";
    public static final String EMPLOYER_GROUPS_LIST = "EMPLOYER_GROUPS";
    public static final String ACTION_SITE_SEARCH = "sitesearch";
    public static final String ACTION_BACK_TO_GROUP_LIST = "backToGroupList";
    public static final String BUSINESS_PROGRAMS_LIST = "BUSINESS_PROGRAMS";
    public static final String EMPLOYER_GROUP_SITE_LIST = "EMPLOYER_GROUP_SITES";
    public static final String CDHP_FULFILL_HISTORIES_LIST = "CDHP_FULFILL_HISTORIES";
    public static final String CDHP_FULFILL_CONTRACTS_LIST = "CDHP_FULFILL_CONTRACTS";
    public static final String PERSON_CDHP_FULFILL_RECYCLE_LIST = "PERSON_CDHP_FULFILL_RECYCLES";
    public static final String PERSON_CONTRACT_RECYCLE_LIST = "PERSON_CONTRACT_RECYCLES";
    public static final String REPORT_TYPE_PENDING_EMPLOYER_SPONSORED_ACTIVITY = "PENDING_EMPLOYER_SPONSORED_ACTIVITY";
    public static final String REPORT_TYPE_PENDING_NON_EMPLOYER_SPONSORED_ACTIVITY = "PENDING_NON_EMPLOYER_SPONSORED_ACTIVITY";
    public static final String FAILURE = "failure";
    public static final String FAILURE_ALTFLOW1 = "failureAltFlow1";
    public static final String WHICH_SAVE_SELECTED_SITES_BIZ_PROGRAM = "BusinessProgram";
    public static final String WHICH_SAVE_SELECTED_SITES_ACTIVITIES = "EligibleProgramActivities";
    public static final String WHICH_SAVE_SELECTED_SITES_CHECKMARKS = "ProgramCheckmarks";
    public static final String WHICH_SAVE_SELECTED_SITES_INCENTIVES = "ProgramIncentives";
    public static final String WHICH_SAVE_SELECTED_SITES_ADD_INFOS = "ProgramAdditionalInfos";
    public static final String WHICH_SAVE_SELECTED_SITES_EXTENDED_AUTH_CODES = "ExtendedAuthCodes";
    public static final String WHICH_SAVE_SELECTED_SITES_INCENTIVE_ACTIVITIES = "IncentiveActivities";
    public static final String WHICH_SAVE_SELECTED_SITES_CONTRIBUTION = "ContributionGrid";
    public static final String WHICH_SAVE_SELECTED_SITES_BENEFIT_PACKAGE = "BenefitPackage";
    public static final String WHICH_SAVE_SELECTED_SITES_PROGRAM_CONTRIBUTION_GRID = "ProgramContributionGrid";
    public static final String WHICH_SAVE_SELECTED_SITES_CHANGE_LOG = "ChangeLog";

    public static final String MEMBER_DETAIL_LIST = "MEMBER_DETAILS";

    public static final String PERSON_CONTRACT_HISTORY_LIST = "PERSON_CONTRACT_HISTORIES";

    public static final String ACTION_DOWNLOAD_PERSON_CONTRACT_HIST_PAGE = "downloadPersonContractHistPage";

    public static final String GROUP_SITE_EXCEPTION_OVERRIDES = "GROUP_SITE_EXCEPTION_OVERRIDES";

    public static final String EMPLOYER_GROUPS_OVERRIDES_LIST = "EMPLOYER_GROUPS_OVERRIDES";
    public static final String EMPLOYER_ACTIVITY_RECYCLE_LIST = "EMPLOYER_ACTIVITY_RECYCLES";

    public static final String ACTION_REPROCESS_ACTIVE_ACTIVITIES = "actives";
    public static final String ACTION_REPROCESS_ACTIVE_COMPLETES = "completes";
    public static final String ACTION_REPROCESS_FILTERED_ACTIVES = "filteredActives";
    public static final String ACTION_REPROCESS_FILTERED_COMPLETES = "filteredCompletes";

    public static final String ACTION_UPDATE_STATUS_RECALC = "updateStatusRecalc";

    public static final String ACTION_UPDATE_MEMBERSHIP_ONLY = "updateMembershipOnly";


    public static final String ACTION_UPDATE_GROUP_MEMBERSHIP = "updateGroupMembership";

    public static final String ACTION_UPDATE_MEMBERSHIP = "updateMembership";

    public static final String ACTION_UPDATE_GROUP_STATUS_RECALC = "updateGroupStatusRecalc";

    public static final String ACTION_EDIT = "edit";
    public static final String ACTION_NO_MATCH = "No_Match";
    private UserSessionSupport userSessionSupport;
    private MessageSource messageSource;
    private ValidationSupport validationSupport;

    private SimpleDateFormat fmt = new SimpleDateFormat(BPMAdminConstants.HP_BPM_ADMIN_UI_COMMON_DATE_FORMAT);

    protected final Log logger = LogFactory.getLog(getClass());



    /**
     * Save pagination state in the HTTP request object.
     *
     * @param request
     * @param pBPMPagination
     */
    @Deprecated
    protected void setAttributesBackAndNextButtons(HttpServletRequest request, BPMPagination pBPMPagination) {
        if (pBPMPagination != null) {
            pBPMPagination.enableAndDisableButtons();
            request.setAttribute("backPageFlag", pBPMPagination.getBackPageFlag());
            request.setAttribute("nextPageFlag", pBPMPagination.getNextPageFlag());
            request.setAttribute("pagination", pBPMPagination);
        } else {
            request.setAttribute("backPageFlag", null);
            request.setAttribute("nextPageFlag", null);
        }
    }

    protected void setAttributesBackAndNextButtonsOnModel(ModelMap modelMap, BPMPagination pBPMPagination) {
        if (pBPMPagination != null) {
            pBPMPagination.enableAndDisableButtons();
            modelMap.put("backPageFlag", pBPMPagination.getBackPageFlag());
            modelMap.put("nextPageFlag", pBPMPagination.getNextPageFlag());
            modelMap.put("pagination", pBPMPagination);
        } else {
            modelMap.put("backPageFlag", null);
            modelMap.put("nextPageFlag", null);
        }
    }

    /**
     * Set pagination attributes to a default setting when no results exist in the list.
     *
     * @param request
     *  * @param sessionBean
     *
     * @return
     */
    @Deprecated
    protected void setAttributesPaginationBackNextButtonsToDisable(HttpServletRequest request, UserSession sessionBean) {
        BPMPagination pagination = new BPMPagination();
        pagination.disableBackNextButtons();
        request.setAttribute("backPageFlag", pagination.getBackPageFlag());
        request.setAttribute("nextPageFlag", pagination.getNextPageFlag());

        sessionBean.setPagination(pagination);
    }

    protected void setAttributesPaginationBackNextButtonsToDisableOnModel(ModelMap modelMap, UserSession sessionBean) {
        BPMPagination pagination = new BPMPagination();
        pagination.disableBackNextButtons();
        modelMap.put("backPageFlag", pagination.getBackPageFlag());
        modelMap.put("nextPageFlag", pagination.getNextPageFlag());

        sessionBean.setPagination(pagination);
    }


    @Deprecated
    protected void setEmployerGroupPagination(HttpServletRequest request, UserSession sessionBean, String actionType, boolean newDTOList) {
        ArrayList<EmployerGroup> lEmployerGroups = sessionBean.getEmployerGroups();
        /**
         * Create a Pageable wrapper for the array list.
         * Create a Pagination object and point it to the wrapper.
         */
        BPMPagination pagination = sessionBean.getPaginationMap().get(EMPLOYER_GROUPS_LIST);
        PageableEmployerGroup lPEG = null;
        if (pagination == null || newDTOList) {
            lPEG = new PageableEmployerGroup(lEmployerGroups);
            lPEG.addRowNumber();
            pagination = new BPMPagination(lPEG, new ArrayList<Object>(lEmployerGroups));
            sessionBean.getPaginationMap().put(EMPLOYER_GROUPS_LIST, pagination);
        }

        ArrayList<EmployerGroup> lEmployerGroupsPerPage = (ArrayList<EmployerGroup>) determineNextOrBackAction(actionType, pagination);
        setAttributesForPagination(request, lEmployerGroups.size(), pagination);

        request.setAttribute("employerGroups", lEmployerGroupsPerPage);
        sessionBean.setEmployerGroupsPerPage(lEmployerGroupsPerPage);
    }

    protected void setEmployerGroupPaginationOnModel(ModelMap modelMap, UserSession sessionBean, String actionType, boolean newDTOList) {
        ArrayList<EmployerGroup> lEmployerGroups = sessionBean.getEmployerGroups();
        /**
         * Create a Pageable wrapper for the array list.
         * Create a Pagination object and point it to the wrapper.
         */
        BPMPagination pagination = sessionBean.getPaginationMap().get(EMPLOYER_GROUPS_LIST);
        PageableEmployerGroup lPEG = null;
        if (pagination == null || newDTOList) {
            lPEG = new PageableEmployerGroup(lEmployerGroups);
            lPEG.addRowNumber();
            pagination = new BPMPagination(lPEG, new ArrayList<Object>(lEmployerGroups));
            sessionBean.getPaginationMap().put(EMPLOYER_GROUPS_LIST, pagination);
        }

        ArrayList<EmployerGroup> lEmployerGroupsPerPage = (ArrayList<EmployerGroup>) determineNextOrBackAction(actionType, pagination);
        setAttributesForPaginationOnModel(modelMap, lEmployerGroups.size(), pagination);

        modelMap.put("employerGroups", lEmployerGroupsPerPage);
        sessionBean.setEmployerGroupsPerPage(lEmployerGroupsPerPage);
    }

    protected List determineNextOrBackAction(String actionType, BPMPagination pBPMPagination) {
        List objectListPage = null;
        if (ACTION_PAGE_BACK.equals(actionType)) {
            objectListPage = pBPMPagination.moveBack();
        } else if (ACTION_PAGE_FORWARD.equals(actionType)) {
            objectListPage = pBPMPagination.moveNext();
        } else {
            //objectListPage = pBPMPagination.addRowNumbers();
            objectListPage = pBPMPagination.getPageList();
            ArrayList<Object> arrayPageList = (ArrayList<Object>) objectListPage;
            pBPMPagination.setPageList(arrayPageList);
            objectListPage = pBPMPagination.moveNext();
        }

        return objectListPage;
    }

    /**
     * Save pagination state in the HTTP request object.
     *
     * @param request
     * @param resultSize
     * @param pBPMPagination
     */
    @Deprecated
    protected void setAttributesForPagination(HttpServletRequest request, Integer resultSize, BPMPagination pBPMPagination) {
        request.setAttribute("resultSize", String.valueOf(resultSize));
        if (pBPMPagination != null) {
            request.setAttribute("startPageCt", Integer.toString(pBPMPagination.getStartPageCt()));
            request.setAttribute("endPageCt", Integer.toString(pBPMPagination.getEndPageCt()));
        }
        setAttributesBackAndNextButtons(request, pBPMPagination);
    }

    /**
     * Save pagination state in the HTTP request object.
     *
     * @param modelMap
     * @param resultSize
     * @param pBPMPagination
     */
    protected void setAttributesForPaginationOnModel(ModelMap modelMap, Integer resultSize, BPMPagination pBPMPagination) {
        modelMap.put("resultSize", String.valueOf(resultSize));
        if (pBPMPagination != null) {
            modelMap.put("startPageCt", Integer.toString(pBPMPagination.getStartPageCt()));
            modelMap.put("endPageCt", Integer.toString(pBPMPagination.getEndPageCt()));
        }
        setAttributesBackAndNextButtonsOnModel(modelMap, pBPMPagination);
    }

    @Deprecated
    protected void createActionMessages(HttpServletRequest request, String code, Object[] params) {
        String message = getMessage(code, params);
        List<String> messages = new ArrayList<>();
        messages.add(message);
        request.setAttribute("messages", messages);
    }

    protected void createActionMessagesOnModel(ModelMap modelMap, String code, Object[] params) {
        String message = getMessage(code, params);
        List<String> messages = new ArrayList<>();
        messages.add(message);
        modelMap.put("messages", messages);
    }

    protected void createActionMessagesOnModel(ModelMap modelMap, String message) {
        List<String> messages = new ArrayList<>();
        messages.add(message);
        modelMap.put("messages", messages);
    }

    protected void createActionMessagesForRedirect(RedirectAttributes ra, String code, Object[] params) {
        String message = getMessage(code, params);
        List<String> messages = new ArrayList<>();
        messages.add(message);
        ra.addFlashAttribute("messages", messages);
    }

    protected void createErrorMessageOnModel(ModelMap modelMap, String errorMessage) {
        modelMap.put("errorMsg", errorMessage);
    }

    /**
     * Determine the size of the business program array list and the number of business programs
     * to be displayed per page.
     *
     * @param request
     * @param sessionBean
     * @param actionType
     * @param newDTOList
     */
    @Deprecated
    protected void setBusinessProgramPagination(HttpServletRequest request, UserSession sessionBean, String actionType, boolean newDTOList) {
        ArrayList<BusinessProgram> lBusinessPrograms = sessionBean.getBusinessPrograms();

        if (lBusinessPrograms.size() < 1) {
            createActionMessages(request, "messages.nosearchresults", null);
        }

        //Pagination code begins here.
        /**
         * Create a Pageable wrapper for the array list.
         * Create a Pagination object and point it to the wrapper.
         */
        BPMPagination pagination = sessionBean.getPaginationMap().get(BUSINESS_PROGRAMS_LIST);

        PageableBusinessProgram lVBP = null;
        if (pagination == null || newDTOList) {
            lVBP = new PageableBusinessProgram(lBusinessPrograms);
            lVBP.addRowNumber();
            pagination = new BPMPagination(lVBP, new ArrayList<Object>(lBusinessPrograms));
            sessionBean.getPaginationMap().put(BUSINESS_PROGRAMS_LIST, pagination);
        }

        ArrayList<BusinessProgram> lBusinessProgramsPerPage =
                (ArrayList<BusinessProgram>) determineNextOrBackAction(actionType, pagination);
        this.setAttributesForPagination(request, lBusinessPrograms.size(), pagination);
        //Pagination code ends here.

        request.setAttribute("businessPrograms", lBusinessProgramsPerPage);
        sessionBean.setBusinessProgramsPerPage(lBusinessProgramsPerPage);
        sessionBean.setPagination(pagination);
    }

    /**
     * Determine the size of the business program array list and the number of business programs
     * to be displayed per page.
     *
     * @param modelMap
     * @param sessionBean
     * @param actionType
     * @param newDTOList
     */
    protected void setBusinessProgramPaginationOnModel(ModelMap modelMap, UserSession sessionBean, String actionType, boolean newDTOList) {
        ArrayList<BusinessProgram> lBusinessPrograms = sessionBean.getBusinessPrograms();

        if (lBusinessPrograms.size() < 1) {
            createActionMessagesOnModel(modelMap, "messages.nosearchresults", null);
        }

        //Pagination code begins here.
        /**
         * Create a Pageable wrapper for the array list.
         * Create a Pagination object and point it to the wrapper.
         */
        BPMPagination pagination = sessionBean.getPaginationMap().get(BUSINESS_PROGRAMS_LIST);

        PageableBusinessProgram lVBP = null;
        if (pagination == null || newDTOList) {
            lVBP = new PageableBusinessProgram(lBusinessPrograms);
            lVBP.addRowNumber();
            pagination = new BPMPagination(lVBP, new ArrayList<Object>(lBusinessPrograms));
            sessionBean.getPaginationMap().put(BUSINESS_PROGRAMS_LIST, pagination);
        }

        ArrayList<BusinessProgram> lBusinessProgramsPerPage = (ArrayList<BusinessProgram>) determineNextOrBackAction(actionType, pagination);
        setAttributesForPaginationOnModel(modelMap, lBusinessPrograms.size(), pagination);
        //Pagination code ends here.

        modelMap.put("businessPrograms", lBusinessProgramsPerPage);
        sessionBean.setBusinessProgramsPerPage(lBusinessProgramsPerPage);
        sessionBean.setPagination(pagination);
    }

    public Integer convertStringToInteger(String idStr) {
        Integer idInt = null;
        if (idStr != null && !idStr.trim().equals("")) {
            try {
                idInt = new Integer(idStr);
            } catch (Exception e) {
                logger.warn("String could not be converted to an Integer: "
                        + e.getMessage(), e);
            }
        }
        return idInt;
    }

    protected boolean validateDateFormat(java.lang.String fieldElement,
                                         java.lang.String fieldValue, java.lang.String messageAppender) {
        boolean result = true;

        try {
            SimpleDateFormat fmt = new SimpleDateFormat(
                    BPMAdminConstants.HP_BPM_ADMIN_UI_COMMON_DATE_FORMAT);
            java.util.Date lGroupStartDate = fmt.parse(fieldValue.trim());
        } catch (Exception ne) {
//            this.actionMessages.add(fieldElement, new ActionMessage(
//                    "errors.date", messageAppender));
            result = false;
        }

        return result;
    }

    @Deprecated
    protected void createNoResultsFoundMessage(HttpServletRequest request) {
        String message = getMessage("messages.info", new Object[]{"No results found for the given search attribute(s)"});
        List<String> messages = new ArrayList<>();
        messages.add(message);
        request.setAttribute("messages", messages);
    }

    protected void createNoResultsFoundMessageOnModel(ModelMap modelMap) {
        String message = getMessage("messages.info", new Object[]{"No results found for the given search attribute(s)"});
        List<String> messages = new ArrayList<>();
        messages.add(message);
        modelMap.put("messages", messages);
    }

    protected String getMessage(String code, Object[] messages) {
       return messageSource.getMessage(code, messages, Locale.getDefault());
    }

    protected Date convertUIDateToSqlDate(String date) {
        return BPMAdminUtils.convertStringToSqlDate(date, BPMAdminConstants.HP_BPM_ADMIN_UI_COMMON_DATE_FORMAT);
    }

    protected void prepareAndSendSummaryEmail(BusinessProgram businessProgram, MemberService memberService, BPMAdminEmailUtility bpmAdminEmailUtility, Integer pNumberOfQualifieds, Integer pNumberOfNotQualifieds, String hostName) {
        String emailServerHost = null;
        String emailFromAddress = null;
        String dbEnvirnment = "";
        List<String> emailToAddress = new ArrayList<String>();
        StringBuffer emailContent = new StringBuffer();
        StringBuffer emailSubject = new StringBuffer();
        java.util.Date startDate = new java.util.Date();
        try {

            Collection<LookUpValueCode> serverHost = memberService
                    .getLUVCodesByGroup(BPMAdminConstants.BPM_ADMIN_EMAIL_HOST_SRVR);
            Collection<LookUpValueCode> fromAddress = memberService
                    .getLUVCodesByGroup(BPMAdminConstants.BPM_ADMIN_EMAIL_FROM_ADDR);
            Collection<LookUpValueCode> toAddress = memberService
                    .getLUVCodesByGroup(BPMAdminConstants.BPM_ADMIN_MEMBERSHIP_DISTRIBUTION_EMAIL);
            Collection<LookUpValueCode> dbEnvirnments = memberService
                    .getLUVCodesByGroup(BPMAdminConstants.BPM_ADMIN_DB_ENV);

            // email server host
            Iterator<LookUpValueCode> itrHost = serverHost.iterator();
            if (itrHost.hasNext()) {
                LookUpValueCode lvalue = itrHost.next();
                emailServerHost = lvalue.getLuvDesc();
            }

            // from address
            Iterator<LookUpValueCode> itrTo = fromAddress.iterator();
            if (itrTo.hasNext()) {
                LookUpValueCode lvalue = itrTo.next();
                emailFromAddress = lvalue.getLuvDesc();
            }

            // to address
            Iterator<LookUpValueCode> itr = toAddress.iterator();
            while (itr.hasNext()) {
                LookUpValueCode lvalue = itr.next();
                emailToAddress.add(lvalue.getLuvDesc());
            }

            Iterator<LookUpValueCode> itrEnv = dbEnvirnments.iterator();
            while (itrEnv.hasNext()) {
                LookUpValueCode lvalue = itrEnv.next();
                dbEnvirnment = lvalue.getLuvDesc();
                break;
            }

            // prepare summary email body
            emailSubject
                    .append("BPM Admin - Membership Flag Notification: ");
            emailSubject.append(businessProgram.getEmployerGroup().getGroupName() + " ");
            emailSubject.append(" Site: " + businessProgram.getEmployerGroup().getSiteNumber());

            emailContent.append("\nMembership Flag Notification");
            emailContent.append("<table>");
            emailContent.append("<tr><td>Database Environment:</td>");
            emailContent.append("<td>" + dbEnvirnment + "</td></tr>");
            emailContent.append("<tr><td>Application Server:</td>");
            emailContent.append("<td>" + hostName + "</td></tr>");

            emailContent.append("</table>");

            // valid activities processed
            emailContent.append("<br><br><table>");
            emailContent
                    .append("<tr><td>***************************************************************************</td></tr>");
            emailContent
                    .append("<tr><td>Membership Flag Notification");
            emailContent
                    .append("<tr><td>***************************************************************************</td></tr>");

            emailContent.append("<tr><td></td></tr>");
            emailContent.append("<tr><td></td></tr>");
            emailContent.append("<tr><td> Membership Notification Flag Date:<strong>" + fmt.format(businessProgram.getMembershipProcessDate()) + "</strong></td></tr>");
            emailContent.append("<tr><td></td></tr>");
            emailContent.append("<tr><td> Group:" + businessProgram.getEmployerGroup().getGroupNumber() + ", "
                    + businessProgram.getEmployerGroup().getGroupName() + "</td></tr>");
            emailContent.append("<tr><td> Site:" + businessProgram.getEmployerGroup().getSiteNumber()  + ", "
                    + businessProgram.getEmployerGroup().getSiteName() + "</td></tr>");

            emailContent.append("<tr><td> Qualification Begin Date:" + BPMAdminUtils.formatDateMMddyyyy(businessProgram.getQualificationWindowStartDate()) + "</td></tr>");
            emailContent.append("<tr><td> Qualification End Date:" + BPMAdminUtils.formatDateMMddyyyy(businessProgram.getQualificationWindowEndDate()) + "</td></tr>");

            Calendar lBenefitYear = Calendar.getInstance();
            lBenefitYear.setTime(businessProgram.getEndDate());
            lBenefitYear.add(Calendar.DATE, 1);
            emailContent.append("<tr><td> Benefit Year:" + BPMAdminUtils.formatDateMMddyyyy(lBenefitYear) + "</td></tr>");


            emailContent.append("<tr><td> Total Number Of Contracts as of :" + fmt.format(new java.util.Date(System.currentTimeMillis())) + "</td></tr>");
            emailContent.append("<tr><td> Total Number Of Contracts:" + String.valueOf(pNumberOfQualifieds.intValue() + pNumberOfNotQualifieds.intValue()) + "</td></tr>");
            emailContent.append("<tr><td> Number Of Qualified Contracts:" + String.valueOf(pNumberOfQualifieds.intValue()) + "</td></tr>");
            emailContent.append("<tr><td> Number Of Not-Qualified Contracts:" + String.valueOf(pNumberOfNotQualifieds.intValue()) + "</td></tr>");

            emailContent.append("<tr><td>&nbsp;</td></tr>");
            emailContent.append("<tr><td>Please note that the final Qualified/Not-Qualified contract counts "
                    + " may change as Member Eligibility Changes, Exemptions, Dispute Resolutions, and retroactive activity statuses are processed."
                    + "</td></tr>");

            emailContent.append("</table>");


            bpmAdminEmailUtility.sendEmail(emailServerHost, emailFromAddress,
                    emailToAddress, emailSubject.toString(), emailContent
                            .toString(),
                    bpmAdminEmailUtility.EMAIL_CONTENT_TYPE_HTML, null);

        } catch (Exception e) {
            logger.error(
                    "Error occurred sending Membership Flag Notification email: "
                            + e.getMessage(), e);
            logger.error("  emailToAddress=" + emailToAddress);
            logger.error("  emailFromAddress=" + emailFromAddress);
            logger.error("  emailSubject=" + emailSubject.toString());
            logger.error("  emailContent=" + emailContent.toString());
        }
    }

    /**
     * Creates and returns a {@link java.lang.String} from t's stacktrace
     *
     * @param t
     *            Throwable whose stack trace is required
     * @return String representing the stack trace of the exception
     */
    protected String getStackTrace(Throwable t) {
        StringWriter stringWritter = new StringWriter();
        PrintWriter printWritter = new PrintWriter(stringWritter, true);
        t.printStackTrace(printWritter);
        printWritter.flush();
        stringWritter.flush();
        return stringWritter.toString();
    }

    protected void setMemberDetailPagination(ModelMap modelMap, UserSession sessionBean, String actionType, boolean newDTOList) {
        ArrayList<MemberDetail> lMemberDetails = sessionBean.getMemberDetails();
        /**
         * Create a Pageable wrapper for the array list.
         * Create a Pagination object and point it to the wrapper.
         */
        BPMPagination pagination = sessionBean.getPaginationMap().get(MEMBER_DETAIL_LIST);
        PageableMemberDetail lPMD = null;
        if (pagination == null || newDTOList) {
            lPMD = new PageableMemberDetail(lMemberDetails);
            lPMD.addRowNumber();
            pagination = new BPMPagination(lPMD, new ArrayList<Object>(lMemberDetails));
            sessionBean.getPaginationMap().put(MEMBER_DETAIL_LIST, pagination);
        }

        ArrayList<MemberDetail> lMemberDetailsPerPage = (ArrayList<MemberDetail>) determineNextOrBackAction(actionType, pagination);
        setAttributesForPaginationOnModel(modelMap, lMemberDetails.size(), pagination);
        sessionBean.setPagination(pagination);

        modelMap.put("allFoundMembers", lMemberDetailsPerPage);
        sessionBean.setMemberDetailsPerPage(lMemberDetailsPerPage);
    }

    public Collection<Long> convertStringsToLongs(String[] idStrs) {
        ArrayList<Long> idLngs = new ArrayList<Long>();
        if (idStrs != null) {
            for (int i = 0; i < idStrs.length; i++) {
                Long idLng = null;
                if (idStrs[i] != null && !idStrs[i].trim().equals("")) {
                    try {
                        idLng = new Long(idStrs[i]);
                        idLngs.add(idLng);
                    } catch (Exception e) {
                        logger.warn(
                                "String could not be converted to an Long: "
                                        + e.getMessage(), e);
                    }
                }

            }
        }
        return idLngs;
    }

    /**
     *
     * @param modelMap
     * @param sessionBean
     * @param actionType
     * @param newDTOList
     */
    protected void setPersonContractHistoryPagination(ModelMap modelMap,
                                                      UserSession sessionBean,
                                                      String actionType,
                                                      boolean newDTOList)
    {
        ArrayList<PersonContractHist> lPersonContractsHistory = sessionBean.getPersonContractHistory();
        BPMPagination pagination = sessionBean.getPaginationMap().get(PERSON_CONTRACT_HISTORY_LIST);

        PageablePersonContractHist lPCH = null;
        if (pagination == null || newDTOList)
        {
            lPCH = new PageablePersonContractHist(lPersonContractsHistory);
            lPCH.addRowNumber();
            pagination = new BPMPagination(lPCH, new ArrayList<Object>(lPersonContractsHistory));
            sessionBean.getPaginationMap().put(PERSON_CONTRACT_HISTORY_LIST, pagination);
        }

        ArrayList<PersonContractHist> lPersonContractsHistoryPerPage = (ArrayList<PersonContractHist>)
                determineNextOrBackAction(actionType, pagination);
        setAttributesForPaginationOnModel (modelMap, lPersonContractsHistory.size(), pagination);

        modelMap.put("personContractsHistory", lPersonContractsHistoryPerPage);
        sessionBean.setPersonContractHistory(lPersonContractsHistory);
    }

    /**
     * Determine the size of the person employer activity recycle array list and the number of person contract recycle rows
     * to be displayed per page.
     *
     * @param modelMap
     * @param sessionBean
     * @param actionType
     * @param newDTOList
     */
    protected void setPersonEmployerActivityRecyclePagination(ModelMap modelMap,
                                                              UserSession sessionBean,
                                                              String actionType,
                                                              boolean newDTOList)
    {
        ArrayList<RejectedPerson> lPersonEmployerActivitiesRecycleList = sessionBean.getPersonEmployerActivitiesRecycle();

        /**
         * Create a Pageable wrapper for the array list.
         * Create a Pagination object and point it to the wrapper.
         */
        BPMPagination pagination = sessionBean.getPaginationMap().get(EMPLOYER_ACTIVITY_RECYCLE_LIST);
        PageableRejectedPerson lPRP = null;
        if (pagination == null || newDTOList)
        {
            lPRP = new PageableRejectedPerson(lPersonEmployerActivitiesRecycleList);
            lPRP.addRowNumber();
            pagination = new BPMPagination(lPRP, new ArrayList<Object>(lPersonEmployerActivitiesRecycleList));
            sessionBean.getPaginationMap().put(EMPLOYER_ACTIVITY_RECYCLE_LIST, pagination);
        }

        ArrayList<RejectedPerson> lPersonEmployerActivitiesRecyclePerPage = (ArrayList<RejectedPerson>) determineNextOrBackAction(actionType, pagination);
        setAttributesForPaginationOnModel(modelMap, lPersonEmployerActivitiesRecycleList.size(), pagination);
        sessionBean.setPagination(pagination);
        modelMap.put("activityDate", sessionBean.getActivityDate());
        modelMap.put("recycleStatusDate", sessionBean.getRecycleStatusDate());
        modelMap.put("personEmployerActivitiesRecycle", lPersonEmployerActivitiesRecyclePerPage);
        sessionBean.setPersonEmployerActivitiesRecyclePerPage(lPersonEmployerActivitiesRecyclePerPage);
        sessionBean.setPersonEmployerActivitiesRecycle(lPersonEmployerActivitiesRecycleList);
    }

    public UserSessionSupport getUserSessionSupport() {
        return userSessionSupport;
    }

    public UserSession getUserSession() {
        return userSessionSupport.getUserSession();
    }

    @Autowired
    public final void setUserSessionSupport(UserSessionSupport userSessionSupport) {
        this.userSessionSupport = userSessionSupport;
    }

    public MessageSource getMessageSource() {
        return messageSource;
    }

    @Autowired
    public final void setMessageSource(MessageSource messageSource) {
        this.messageSource = messageSource;
    }

    public ValidationSupport getValidationSupport() {
        return validationSupport;
    }

    @Autowired
    public final void setValidationSupport(ValidationSupport validationSupport) {
        this.validationSupport = validationSupport;
    }

    protected String getActionType(Object target) {
        return ((BaseForm) target).getActionType();
    }

    public SimpleDateFormat getFmt() {
        return fmt;
    }
}
