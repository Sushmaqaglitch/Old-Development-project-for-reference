package com.healthpartners.app.bpm.security;

import com.healthpartners.app.bpm.common.BPMAdminConstants;
import com.healthpartners.app.bpm.common.UserSessionSupport;
import com.healthpartners.app.bpm.dao.AuditLogDAO;
import com.healthpartners.app.bpm.dto.BPMAuditRecord;
import com.healthpartners.app.bpm.dto.LookUpValueCode;
import com.healthpartners.app.bpm.dto.UserAccess;
import com.healthpartners.app.bpm.iface.BusinessProgramService;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.SavedRequestAwareAuthenticationSuccessHandler;
import org.springframework.security.web.savedrequest.DefaultSavedRequest;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.util.*;

@Component
public class BPMAdminAuthenticationSuccessHandler extends SavedRequestAwareAuthenticationSuccessHandler {
    private static final String FAILURE_REDIRECT_URL = "/login";

    protected final Log logger = LogFactory.getLog(getClass());

    @Autowired
    private BusinessProgramService businessProgramService;

    @Autowired
    private UserSessionSupport userSessionSupport;

    @Autowired
    AuditLogDAO auditLogDAO;

    public BPMAdminAuthenticationSuccessHandler() {
        super();
        setUseReferer(true);
    }


    @Override
    public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response, Authentication authentication) throws ServletException, IOException {
        String eventResult = checkUserAccess(request);
        logAuditEvent(eventResult);
        if (!eventResult.equals("SUCCESS")) {
            redirect(request, response, FAILURE_REDIRECT_URL);
        }

        // Determine if roles should be filtered for testing purposes
        handleFilteredRoles(request);

        super.onAuthenticationSuccess(request, response, authentication);
    }

    private void handleFilteredRoles(HttpServletRequest request) {
        HttpSession session = request.getSession();
        DefaultSavedRequest defaultSavedRequest = (DefaultSavedRequest) session.getAttribute("SPRING_SECURITY_SAVED_REQUEST");
        if (defaultSavedRequest == null) {
            return;
        }

        String[] filteredRoles = defaultSavedRequest.getParameterValues("role");
        if (filteredRoles == null) {
            return;
        }

        List<SimpleGrantedAuthority> updatedAuthorities = new ArrayList<>();

        Collection<SimpleGrantedAuthority> unfilteredAuthorities = (Collection<SimpleGrantedAuthority>)SecurityContextHolder.getContext().getAuthentication().getAuthorities();
        for (SimpleGrantedAuthority authority : unfilteredAuthorities) {
            String val = authority.getAuthority();
            for(String role : filteredRoles) {
                String filteredAuthorityRole = role;
                if (!filteredAuthorityRole.contains("ROLE_IS")) {
                    filteredAuthorityRole = "ROLE_IS " + role;
                }
                if (filteredAuthorityRole.equals(val)) {
                    updatedAuthorities.add(authority);
                }
            }
        }

        if (CollectionUtils.isEmpty(updatedAuthorities)) {
            updatedAuthorities.addAll(unfilteredAuthorities);
        }

        SecurityContextHolder.getContext().setAuthentication(
                new UsernamePasswordAuthenticationToken(
                        SecurityContextHolder.getContext().getAuthentication().getPrincipal(),
                        SecurityContextHolder.getContext().getAuthentication().getCredentials(),
                        updatedAuthorities)
        );
    }

    private void redirect(HttpServletRequest request, HttpServletResponse response, String url) throws IOException {
        String contextPath = request.getContextPath();
        response.sendRedirect(contextPath + url);
    }

    private String checkUserAccess(HttpServletRequest request) {
        String eventResult = "SUCCESS";
        try {
            HttpSession session = userSessionSupport.getSession();

            // Check the person's access to this environment.
            Boolean lHasAccess = false;

            String lUserName = getAuthenticatedUserName();
            ArrayList<UserAccess> lUserAccessList = (ArrayList<UserAccess>)
                    businessProgramService.getUserAccessList(lUserName);

            LookUpValueCode lDatabaseEnvironment = businessProgramService.getDatabaseEnvironment();

            for(int i = 0; i < lUserAccessList.size(); i++)
            {
                ArrayList<LookUpValueCode> lUserEnvs = (ArrayList<LookUpValueCode>)lUserAccessList.get(i).getUserEnvironments();

                for(int j = 0; j < lUserEnvs.size(); j++)
                {
                    if(lUserEnvs.get(j).getLuvVal().equalsIgnoreCase(lDatabaseEnvironment.getLuvVal()))
                    {
                        lHasAccess = true;
                        break;
                    }
                }
            }

            if(!lHasAccess) {
                logger.error("User " + lUserName + " does not have access to environment " + lDatabaseEnvironment);
            }

            session.setAttribute(BPMAdminConstants.BPM_ADMIN_HAS_ACCESS_TO_ENV, lHasAccess);

            logger.info("User is: " + getAuthenticatedUserName());

            determineNAssignUserAccesses(request, session);

        } catch (Exception e) {
            e.printStackTrace();
            eventResult = "FAILURE";
        }

        return eventResult;
    }

    private void determineNAssignUserAccesses(HttpServletRequest request, HttpSession session) {
        Collection<GrantedAuthority> authorities = getGrantedAuthorities();

        for(GrantedAuthority grantedAuthority : authorities) {
            if(grantedAuthority.getAuthority().equals("ROLE_IS BPM DEVELOPMENT TEAM") ||
                    grantedAuthority.getAuthority().equals("ROLE_IS BPM SUPER USER")) {
                logger.info("Super User access allowed!");
                request.getSession().setAttribute(BPMAdminConstants.BPM_SUPER_USER, true);
            }

            if(grantedAuthority.getAuthority().equals("ROLE_IS BPM MBR SERVICES ADMIN")) {
                logger.info("Member Services Admin access allowed!");
                request.getSession().setAttribute(BPMAdminConstants.BPM_MEMBER_SERVICES_ADMIN_ROLE, true);
            }

            if(grantedAuthority.getAuthority().equals("ROLE_IS BPM DEVELOPMENT TEAM") ||
                    grantedAuthority.getAuthority().equals("ROLE_IS BPM SUPER USER") ||
                    grantedAuthority.getAuthority().equals("ROLE_IS BPM BUSINESS USERS")) {
                logger.info("Group view edit access allowed!");
                request.getSession().setAttribute(BPMAdminConstants.BPM_ADMIN_GROUP_VIEW_EDIT_ACCESS, true);
            }
        }

        if(request.getSession().getAttribute(BPMAdminConstants.BPM_SUPER_USER) == null) {
            logger.info("Super User access NOT allowed!");
            request.getSession().setAttribute(BPMAdminConstants.BPM_SUPER_USER, false);
        }

        if(request.getSession().getAttribute(BPMAdminConstants.BPM_MEMBER_SERVICES_ADMIN_ROLE) == null) {
            logger.info("Member Services Admin access NOT allowed!");
            request.getSession().setAttribute(BPMAdminConstants.BPM_MEMBER_SERVICES_ADMIN_ROLE, false);
        }

        if(request.getSession().getAttribute(BPMAdminConstants.BPM_ADMIN_GROUP_VIEW_EDIT_ACCESS) == null) {
            logger.info("Group view edit access NOT allowed!");
            request.getSession().setAttribute(BPMAdminConstants.BPM_ADMIN_GROUP_VIEW_EDIT_ACCESS, false);
        }
    }

    public static String getAuthenticatedUserName() {
        String userName = null;

        Authentication auth = SecurityContextHolder.getContext()
                .getAuthentication();
        if (auth != null) {
            userName = auth.getName();
        }

        return userName;
    }

    public static Collection<GrantedAuthority> getGrantedAuthorities() {
        Collection<GrantedAuthority> authorities = new ArrayList<>();

        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth != null) {
            authorities = (Collection<GrantedAuthority>) auth.getAuthorities();
        }

        return authorities;
    }

    private BPMAuditRecord buildAuditLogLoginRecord(String eventResult, String applicationEvent, String param1) {
        // Membership process date was set or edited.
        // Record in the Audit Log table.
        BPMAuditRecord bpmAuditRecord = new BPMAuditRecord();
        bpmAuditRecord.setApplicationId(getAuthenticatedUserName());
        bpmAuditRecord.setEventResult(eventResult);
        bpmAuditRecord.setParam1(param1);
        bpmAuditRecord.setApplicationEvent(applicationEvent);

        return bpmAuditRecord;
    }

    private Integer createAuditEventLogEntry(BPMAuditRecord bpmAuditRecord) {
        Integer auditLogId = null;
        try {
            auditLogDAO.insertAuditLog(bpmAuditRecord);
        } catch (Exception e) {
            logger.error("Error writing AuditEventLogEntry " + e);
        }

        return auditLogId;
    }

    private void logAuditEvent(String eventResult) {
        //BPM-33 - Capture users login event to AuditLog table.
        String param1 = "BPM Admin Tool Login";
        String applicationEvent = "BPMAdminAuthenticationProcessingFilter.onSuccessfulAuthentication";
        BPMAuditRecord bpmAuditRecord = buildAuditLogLoginRecord(eventResult, applicationEvent, param1);

        createAuditEventLogEntry(bpmAuditRecord);
    }
}
