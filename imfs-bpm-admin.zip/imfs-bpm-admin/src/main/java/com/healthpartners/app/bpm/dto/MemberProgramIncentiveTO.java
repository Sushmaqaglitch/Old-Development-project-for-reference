package com.healthpartners.app.bpm.dto;

import java.sql.Date;

/**
 * This class represents the internal BPM package Data Transfer Object.
 * It is not exposed to web services for example.
 * 
 * Represents a record in the pgm_mem_incntv_status table. 
 * 
 * @author jxbourbour
 */
public class MemberProgramIncentiveTO
{
	static final long serialVersionUID = 0L;
	
	private Integer memberProgramStatusID;
	private Integer businessProgramID;
	private Integer incentiveOptionID;
	private String  incentiveOptionName;
	private Integer contractNo;
	private Integer personDemographicsID;
	private Integer qualificationCheckmarkID;
	private String  memberIncentiveStatusCode;
	private Date    memberIncentiveStatusDate; 
	private Date    memberIncentiveAchievedDate;
	private Integer  activationStatusCodeID;
	private String  activationStatusCode;
			
	public MemberProgramIncentiveTO()
	{
		super();
	}

	
	public Integer getMemberProgramStatusID() {
		return memberProgramStatusID;
	}


	public void setMemberProgramStatusID(Integer memberProgramStatusID) {
		this.memberProgramStatusID = memberProgramStatusID;
	}


	public Integer getBusinessProgramID() {
		return businessProgramID;
	}

	public void setBusinessProgramID(Integer businessProgramID) {
		this.businessProgramID = businessProgramID;
	}

	public Integer getIncentiveOptionID() {
		return incentiveOptionID;
	}

	public void setIncentiveOptionID(Integer incentiveOptionID) {
		this.incentiveOptionID = incentiveOptionID;
	}

	public Integer getContractNo() {
		return contractNo;
	}

	public void setContractNo(Integer contractNo) {
		this.contractNo = contractNo;
	}

	public Integer getPersonDemographicsID() {
		return personDemographicsID;
	}

	public void setPersonDemographicsID(Integer personDemographicsID) {
		this.personDemographicsID = personDemographicsID;
	}

	public String getMemberIncentiveStatusCode() {
		return memberIncentiveStatusCode;
	}

	public void setMemberIncentiveStatusCode(String memberIncentiveStatusCode) {
		this.memberIncentiveStatusCode = memberIncentiveStatusCode;
	}


	public Date getMemberIncentiveStatusDate() {
		return memberIncentiveStatusDate;
	}

	public void setMemberIncentiveStatusDate(Date memberIncentiveStatusDate) {
		this.memberIncentiveStatusDate = memberIncentiveStatusDate;
	}

	public Integer getQualificationCheckmarkID() {
		return qualificationCheckmarkID;
	}

	public void setQualificationCheckmarkID(Integer qualificationCheckmarkID) {
		this.qualificationCheckmarkID = qualificationCheckmarkID;
	}

	public String getIncentiveOptionName() {
		return incentiveOptionName;
	}

	public void setIncentiveOptionName(String incentiveOptionName) {
		this.incentiveOptionName = incentiveOptionName;
	}

	public Date getMemberIncentiveAchievedDate() {
		return memberIncentiveAchievedDate;
	}

	public void setMemberIncentiveAchievedDate(Date memberIncentiveAchievedDate) {
		this.memberIncentiveAchievedDate = memberIncentiveAchievedDate;
	}


	public final Integer getActivationStatusCodeID() {
		return activationStatusCodeID;
	}


	public final void setActivationStatusCodeID(Integer activationStatusCodeID) {
		this.activationStatusCodeID = activationStatusCodeID;
	}


	public final String getActivationStatusCode() {
		return activationStatusCode;
	}


	public final void setActivationStatusCode(String activationStatusCode) {
		this.activationStatusCode = activationStatusCode;
	}

	
		
}
