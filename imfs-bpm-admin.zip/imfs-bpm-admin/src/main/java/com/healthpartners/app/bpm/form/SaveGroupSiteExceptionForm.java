/**
 *
 */
package com.healthpartners.app.bpm.form;


/**
 * @author tjquist
 *
 */
public class SaveGroupSiteExceptionForm extends BaseForm {

    static final long serialVersionUID = 0L;

    String groupNo;
    String groupId;
    String groupName;
    String siteName;
    String groupOverrideId;
    String subgroupID;
    String programTypeCode;
    String luvExceptionTypeID;
    String approverID;
    String effectiveDate;
    String endDate;
    String issueDate;
    String exceptionReason;
    String siteNo;


    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    public String getLuvExceptionTypeID() {
        return luvExceptionTypeID;
    }

    public void setLuvExceptionTypeID(String luvExceptionTypeID) {
        this.luvExceptionTypeID = luvExceptionTypeID;
    }

    public String getSiteName() {
        return siteName;
    }

    public void setSiteName(String siteName) {
        this.siteName = siteName;
    }

    public String getIssueDate() {
        return issueDate;
    }

    public void setIssueDate(String issueDate) {
        this.issueDate = issueDate;
    }

    public String getExceptionReason() {
        return exceptionReason;
    }

    public void setExceptionReason(String exceptionReason) {
        this.exceptionReason = exceptionReason;
    }

    public String getApproverID() {
        return approverID;
    }

    public void setApproverID(String approverID) {
        this.approverID = approverID;
    }

    public String getEffectiveDate() {
        return effectiveDate;
    }

    public void setEffectiveDate(String effectiveDate) {
        this.effectiveDate = effectiveDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public String getGroupOverrideId() {
        return groupOverrideId;
    }

    public void setGroupOverrideId(String groupOverrideId) {
        this.groupOverrideId = groupOverrideId;
    }

    public String getProgramTypeCode() {
        return programTypeCode;
    }

    public void setProgramTypeCode(String programTypeCode) {
        this.programTypeCode = programTypeCode;
    }

    public String getSubgroupID() {
        return subgroupID;
    }

    public void setSubgroupID(String subgroupID) {
        this.subgroupID = subgroupID;
    }

    public String getGroupNo() {
        return groupNo;
    }

    public void setGroupNo(String groupNo) {
        this.groupNo = groupNo;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public String getSiteNo() {
        return siteNo;
    }

    public void setSiteNo(String siteNo) {
        this.siteNo = siteNo;
    }


//    /**
//     * Validate form values.
//     *
//     * @param mapping
//     *            The mapping used to select this instance
//     * @param request
//     *            The servlet request we are processing
//     * @return errors
//     */
//    public ActionMessages validateSave() {
//
//        if (BaseAction.ACTION_SAVE_TO_SELECTED.equals(actionType) || BaseAction.ACTION_SAVE_TO_ALL_SITES.equals(actionType)) {
//            //ignore edit since site id is available with the assigned sites.
//        } else if (subgroupID == null || subgroupID.equals("999")) {
//            String subgroupIDStr = null;
//            validateNotNull("subgroupID", subgroupIDStr, "Site Name");
//        }
//
//        if (programTypeCode.equals("0") || programTypeCode.isEmpty()) {
//            String programIDStr = null;
//            validateNotNull("programID", programIDStr, "Program Name");
//        }
//
//        if (luvExceptionTypeID.equals("0") || luvExceptionTypeID.isEmpty()) {
//            validateNotNull("luvExceptionTypeID", luvExceptionTypeID, "Exception Type");
//        }
//
//        //At this time, don't allow program type that is not Smart Steps to be selected.
//		/*if (!programTypeCode.equals("2")) {
//
//			this.getActionMessages().add("programID", new ActionError(
//						"messages.programTypeNotAllowedForSelection", "programID"));
//		}*/
//
//        boolean lIssueDateValid = validateNotDate("issueDate", issueDate, "Exception Issue Date");
//
//        validateNotNull("exceptionReason", exceptionReason, "Exception Reason");
//
//        if (exceptionReason != null) {
//            if (exceptionReason.length() > BPMAdminConstants.BPM_GROUPOVRD_DESCRIPTION_LENGTH) {
//                this.getActionMessages().add("exceptionReason", new ActionError(
//                        "errors.maxlength", "Exception Reason", String.valueOf(BPMAdminConstants.BPM_GROUPOVRD_DESCRIPTION_LENGTH)));
//            }
//        }
//
//        validateNotNull("approverId", approverID, "Exception Approver");
//
//        boolean lEffectiveDateValid = validateNotDate("effectiveDate", effectiveDate, "Effective Date");
//        boolean lEndDateValid = validateNotDate("endDate", endDate, "End Date");
//
//        if (lEffectiveDateValid && lEndDateValid) {
//            validateBeforeOrEqual("effectiveDate", effectiveDate, "Effective Date", endDate, "End Date");
//        }
//
//        if (lIssueDateValid && lEndDateValid) {
//            validateBeforeOrEqual("issueDate", issueDate, "Issue Date", endDate, "End Date");
//        }
//
//        return getActionMessages();
//    }


}
