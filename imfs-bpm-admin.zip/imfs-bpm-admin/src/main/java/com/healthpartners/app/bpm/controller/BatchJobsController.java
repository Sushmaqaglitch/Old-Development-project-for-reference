package com.healthpartners.app.bpm.controller;

import com.healthpartners.app.bpm.common.BPMAdminConstants;
import com.healthpartners.app.bpm.dto.Activity;
import com.healthpartners.app.bpm.dto.EmployerGroup;
import com.healthpartners.app.bpm.dto.LookUpValueCode;
import com.healthpartners.app.bpm.dto.MemberProcessingStatusLog;
import com.healthpartners.app.bpm.exception.BPMException;
import com.healthpartners.app.bpm.form.BatchJobsForm;
import com.healthpartners.app.bpm.form.BatchMemberSelectionForm;
import com.healthpartners.app.bpm.iface.BusinessProgramService;
import com.healthpartners.app.bpm.iface.MemberService;
import com.healthpartners.service.bpm.rules.StatusCalculationCommand;
import jakarta.servlet.http.HttpServletRequest;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

@Controller
public class BatchJobsController extends BaseController implements Validator {

    private static final String BATCH_MEMBERSHIP_UPDATE_ONLY = "Membership Update Only";
    private static final String BATCH_MEMBERSHIP_UPDATE = "Membership Update";
    private static final String PAGE_PENDING_DATE_SELECTION = "reprocessMissingActivities";
    private static final String PAGE_PENDING_MEMBERS_SELECTION = "batchMemberSelection";
    private static final String BATCH_MENBER_RECALCULATION = "Member status Re-Calculation";
    private static final String BATCH_PENDING_ACTIVITIES = "Pending Activities";
    private static final String BATCH_MEMBERSHIP_ETL_UPDATE_QUEUE = "Batch Membership Update Queue";

    private static final String BATCH_CDHP_HRA_FULFILLMENT_FEED = "CDHP Hra Feed";
    private static final String EMPLOYER_GROUP_SITE_SETUP = "Employer Group Site Setup";
    private static final String EMPLOYER_BASELINE_SETUP = "Employer Group Baseline Setup";
    private static final String POPULATE_MISSING_PEOPLE = "POPULATE_MISSING_PEOPLE";
    private static final String UPLOAD_EMPLOYER_ACTIVITY_PREPROCESS = "UPLOAD_EMPLOYER_ACTIVITY_PREPROCESS";
    private static final String BATCH_PURGE_AUDIT_LOG_TABLE = "Audit Log Purge";
    private static final String BATCH_PURGE_PROCESSLG_TABLE = "Processing Status Log Purge";
    private static final String CONTRACT_RECONCILIATION = "Contract Reconciliation With History";
    private static final String DELETE_TERMED_PARTICIPANTS = "DELETE_TERMED_PARTICIPANTS";
    private static final String POPULATE_PACKAGE_BASELINE = "POPULATE_PACKAGE_BASELINE";
    private static final String FILTERED_OUT_ACTIVITY_REPORT = "FILTERED_OUT_ACTIVITY_REPORT";
    private static final String AUTO_POPULATE_AUDIT_REPORT = "AUTO_POPULATE_AUDIT_REPORT";
    private static final String CORRECT_PURCHASER_SUBTYPE = "CORRECT_PURCHASER_SUBTYPE";
    private static final String REPROCESS_MISSING_ACTIVITES = "REPROCESS_MISSING_ACTIVITES";
    private static final Integer batchSize = 100;

    private final Log logger = LogFactory.getLog(getClass());

    private final MemberService memberService;
    private final BusinessProgramService businessProgramService;

    public BatchJobsController(MemberService memberService, BusinessProgramService businessProgramService) {
        this.memberService = memberService;
        this.businessProgramService = businessProgramService;
    }

    @GetMapping("/batchJobs")
    public String load(ModelMap modelMap) throws BPMException {
        try {
            BatchJobsForm form = new BatchJobsForm();
            modelMap.put("batchJobsForm", form);
        } catch (Exception e) {
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
            modelMap.put("errorMsg", getStackTrace(e));
        }

        return "batchJobs";
    }

    @PostMapping("/batchJobs")
    public String submit(@ModelAttribute("batchJobsForm") BatchJobsForm form, ModelMap modelMap, BindingResult result, HttpServletRequest request) throws Exception {
        String resultPage = "batchJobs";

        try {
            resultPage = executeBatchOperation(form, modelMap);
        } catch (Exception e) {
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
            // Add error stack trace on the request, to be hidden in html.
            createErrorMessageOnModel(modelMap, getStackTrace(e));
        }

        return resultPage;
    }

    private String executeBatchOperation(BatchJobsForm form, ModelMap modelMap) throws BPMException, IOException {
        boolean batchToProcessNow = false;
        boolean batchRequiresMemberSelection = false;
        boolean batchRequiresDateSelection = false;
        String resultPage = "batchJobs";
        String operationType = form.getOperationType();

        if (StringUtils.isNotEmpty(operationType)) {
            StatusCalculationCommand calculationCommand = new StatusCalculationCommand();

            if (BATCH_MEMBERSHIP_UPDATE_ONLY.equals(operationType)) {
                calculationCommand.setEtlMembershipUpdateOnlyCommand();
                calculationCommand.setProcessIDForEtlMembershipUpdateOnlyCommand(BPMAdminConstants.BPM_ADMIN_MEMBERSHIP_UPDATE_ONLY_PRCS_ID);
                calculationCommand.setCurrentProcessingCommand(StatusCalculationCommand.ETL_MEMBERSHIP_UPDATE_ONLY);
                batchRequiresMemberSelection = true;

            } else if (BATCH_MEMBERSHIP_UPDATE.equals(operationType)) {
                calculationCommand.setEtlMembershipUpdateCommand();
                calculationCommand.setProcessIDForEtlMembershipUpdateCommand(BPMAdminConstants.BPM_ADMIN_MEMBERSHIP_UPDATE_PRCS_ID);
                calculationCommand.setCurrentProcessingCommand(StatusCalculationCommand.ETL_MEMBERSHIP_UPDATE);
                batchRequiresMemberSelection = true;

            } else if (BATCH_MENBER_RECALCULATION.equals(operationType)) {
                calculationCommand.setMembersReCalculationCommand();
                calculationCommand.setProcessIDForMembersReCalculationCommand(BPMAdminConstants.BPM_ADMIN_MEMBERS_RECALCULATION_PRCS_ID);
                calculationCommand.setCurrentProcessingCommand(StatusCalculationCommand.MEMBERS_RECALCULATION);
                batchRequiresMemberSelection = true;
//				} else if (BATCH_ELAPSED_TIME.equals(operationType)) {
//					calculationCommand.setMemberElapsedTimeCommand();
//					batchToProcessNow = true;

            } else if (BATCH_PENDING_ACTIVITIES.equals(operationType)) {
                calculationCommand.setPendingActivityEventsCommand();
                batchToProcessNow = true;
//				} else if (BATCH_PENDING_TASKS.equals(operationType)) {
//					calculationCommand.setPendingTaskEventsCommand();
//					batchToProcessNow = true;
//				} else if (BATCH_MEMBERSHIP_FEED.equals(operationType)) {
//					calculationCommand.setMbrShipFeedCommand();
//					calculationCommand.setProcessName("BPM");
//					calculationCommand
//							.setCurrentProcessingCommand(StatusCalculationCommand.MEMBERSHIP_FEED);
//					batchToProcessNow = true;
//					batchRequiresMemberSelection = false;
//				} else if (BATCH_MEMBERSHIP_PREMIUM_BILLING_FEED.equals(operationType)) {
//					calculationCommand.setMbrShipPremiumBillingFeedCommand();
//					calculationCommand.setProcessName("BPM");
//					calculationCommand
//							.setCurrentProcessingCommand(StatusCalculationCommand.MEMBERSHIP_PREMIUM_BILLING_FEED);
//					batchToProcessNow = true;
//					batchRequiresMemberSelection = false;

            } else if (BATCH_CDHP_HRA_FULFILLMENT_FEED.equals(operationType)) {
                calculationCommand.setHraFulfillmentFeedCommand();
                calculationCommand.setProcessName("BPM");
                calculationCommand.setCurrentProcessingCommand(StatusCalculationCommand.CDHP_HRA_FULFILLMENT_REPORTING);
                batchToProcessNow = true;
                batchRequiresMemberSelection = false;

                // Run the batch membership update for all the members changed
                // in MODS and
                // marked by the membership ETL process in our
                // processing_status_log table.
//			} else if (BATCH_MEMBERSHIP_ETL_UPDATE.equals(operationType)) {
//					calculationCommand.setEtlMembershipUpdateCommand();
//					calculationCommand
//							.setProcessIDForEtlMembershipUpdateCommand(BPMConstants.ETL_MEMBERSHIP_UPDATE_PRCS_ID);
//					calculationCommand
//					.setCurrentProcessingCommand(StatusCalculationCommand.ETL_MEMBERSHIP_UPDATE);
//					batchToProcessNow = true;
//					batchRequiresMemberSelection = false;
//				}
                //story BPM-343
//				else if (BATCH_MEMBERSHIP_ETL_UPDATE_ONLY.equals(operationType)) {
//					calculationCommand.setEtlMembershipUpdateOnlyCommand();
//					calculationCommand
//							.setProcessIDForEtlMembershipUpdateOnlyCommand(BPMConstants.ETL_MEMBERSHIP_UPDATE_ONLY_PRCS_ID);
//					calculationCommand
//					.setCurrentProcessingCommand(StatusCalculationCommand.ETL_MEMBERSHIP_UPDATE_ONLY);
//					batchToProcessNow = true;
//					batchRequiresMemberSelection = false;
//				}

            } else if (BATCH_PURGE_AUDIT_LOG_TABLE.equals(operationType)) {
                calculationCommand.setPurgeAuditLogTableCommand();
                calculationCommand.setCurrentProcessingCommand(StatusCalculationCommand.PURGE_AUDIT_LOG_TABLE);
                batchToProcessNow = true;
                batchRequiresMemberSelection = false;

            } else if (BATCH_PURGE_PROCESSLG_TABLE.equals(operationType)) {
                calculationCommand.setPurgeProcessStatLogTableCommand();
                calculationCommand
                        .setCurrentProcessingCommand(StatusCalculationCommand.PURGE_PROCESSLG_TABLE);
                batchToProcessNow = true;
                batchRequiresMemberSelection = false;

            } else if (CONTRACT_RECONCILIATION.equals(operationType)) {
                calculationCommand.setPersonContractHistReconciliationCommand();
                batchToProcessNow = true;

            } else if (EMPLOYER_GROUP_SITE_SETUP.equals(operationType)) {
                calculationCommand.setEmployerGoupSiteSetup();
                calculationCommand.setCurrentProcessingCommand(StatusCalculationCommand.EMPLOYER_GROUP_SITE_SETUP);
                batchToProcessNow = true;
                batchRequiresMemberSelection = false;

            } else if (EMPLOYER_BASELINE_SETUP.equals(operationType)) {
                calculationCommand.setEmployerBaselineSetup();
                calculationCommand.setCurrentProcessingCommand(StatusCalculationCommand.EMPLOYER_BASELINE_SETUP);
                batchToProcessNow = true;
                batchRequiresMemberSelection = false;
            }
//				else if(AUTO_PROGRAM_SETUP_NEW_SMARTSTEPS.equals(operationType))
//				{
//					calculationCommand.setAutoProgramNewSmartStepsSetup();
//					calculationCommand
//					    .setCurrentProcessingCommand(StatusCalculationCommand.AUTO_PROGRAM_NEW_SMARTSTEPS);
//					batchToProcessNow = true;
//					batchRequiresMemberSelection = false;
//				}
            else if (POPULATE_MISSING_PEOPLE.equals(operationType)) {
                calculationCommand.setPopulateMissingPeople();
                calculationCommand.setCurrentProcessingCommand(StatusCalculationCommand.POPULATE_MISSING_PEOPLE);
                batchToProcessNow = true;
                batchRequiresMemberSelection = false;

            } else if (UPLOAD_EMPLOYER_ACTIVITY_PREPROCESS.equals(operationType)) {
                calculationCommand.setUploadEmployerActivityPreprocess();
                calculationCommand.setCurrentProcessingCommand(StatusCalculationCommand.UPLOAD_EMPLOYER_ACTIVITY_PREPROCESS);
                batchToProcessNow = true;
                batchRequiresMemberSelection = false;

            } else if (DELETE_TERMED_PARTICIPANTS.equals(operationType)) {
                calculationCommand.setDeleteTermedParticipants();
                calculationCommand.setCurrentProcessingCommand(StatusCalculationCommand.DELETE_TERMED_PARTICIPANTS);
                batchToProcessNow = true;
                batchRequiresMemberSelection = false;

            } else if (POPULATE_PACKAGE_BASELINE.equals(operationType)) {
                calculationCommand.setPopulatePackageBaseline();
                calculationCommand.setCurrentProcessingCommand(StatusCalculationCommand.POPULATE_PACKAGE_BASELINE);
                batchToProcessNow = true;
                batchRequiresMemberSelection = false;

            } else if (FILTERED_OUT_ACTIVITY_REPORT.equals(operationType)) {
                calculationCommand.setFilteredOutActivityReport();
                calculationCommand.setCurrentProcessingCommand(StatusCalculationCommand.FILTERED_OUT_ACTIVITY_REPORT);
                batchToProcessNow = true;
                batchRequiresMemberSelection = false;

            } else if (AUTO_POPULATE_AUDIT_REPORT.equals(operationType)) {
                calculationCommand.setAutoPopulateAuditReport();
                calculationCommand
                        .setCurrentProcessingCommand(StatusCalculationCommand.AUTO_POPULATE_AUDIT_REPORT);
                batchToProcessNow = true;
                batchRequiresMemberSelection = false;

            } else if (CORRECT_PURCHASER_SUBTYPE.equals(operationType)) {
                calculationCommand.setCorrectPurchaserSubType();
                calculationCommand.setCurrentProcessingCommand(StatusCalculationCommand.CORRECT_PURCHASER_SUBTYPE);
                batchToProcessNow = true;
                batchRequiresMemberSelection = false;

            } else if (REPROCESS_MISSING_ACTIVITES.equals(operationType)) {
                calculationCommand.setReprocessMissingActivities();
                calculationCommand.setCurrentProcessingCommand(StatusCalculationCommand.REPROCESS_MISSING_ACTIVITES);
                batchToProcessNow = true;

            } else if (BATCH_MEMBERSHIP_ETL_UPDATE_QUEUE.equals(operationType)) {
                calculationCommand.setEtlMembershipUpdateQueueCommand();
                calculationCommand.setCurrentProcessingCommand(StatusCalculationCommand.ETL_MEMBERSHIP_UPDATE_QUEUE);
                batchToProcessNow = true;
            }

            if (batchRequiresDateSelection) {
                Collection<Activity> lActivities = (Collection<Activity>) businessProgramService.getActivities();
                modelMap.put("activityList", lActivities);
                getUserSession().setActivities((ArrayList<Activity>) lActivities);
                Collection<EmployerGroup> lEmployerGroups = (Collection<EmployerGroup>)businessProgramService.getAllBPMGroups();
                getUserSession().setEmployerGroups((ArrayList<EmployerGroup>) lEmployerGroups);
                modelMap.put("employerGroups", getUserSession().getEmployerGroups());
                resultPage = PAGE_PENDING_DATE_SELECTION;

            } else if (batchRequiresMemberSelection) {
                Collection<MemberProcessingStatusLog> pendingProcessMembers = memberService.getPendingPersonsFromProcessingStatusLog(calculationCommand.getProcessIDForCurrentProcessingCommand());
                modelMap.put("pendingProcessMembers", pendingProcessMembers);
                modelMap.put("statusLogProcessID", Integer.valueOf(calculationCommand.getProcessIDForCurrentProcessingCommand()));
                resultPage = PAGE_PENDING_MEMBERS_SELECTION;
                BatchMemberSelectionForm batchMemberSelectionForm = new BatchMemberSelectionForm();
                modelMap.put("batchMemberSelectionForm", batchMemberSelectionForm);
                modelMap.put("BPM_ADMIN_MEMBERSHIP_UPDATE_PRCS_ID", BPMAdminConstants.BPM_ADMIN_MEMBERSHIP_UPDATE_PRCS_ID);
                modelMap.put("BPM_ADMIN_MEMBERS_RECALCULATION_PRCS_ID", BPMAdminConstants.BPM_ADMIN_MEMBERS_RECALCULATION_PRCS_ID);

            } else if (batchToProcessNow) {
                calculationCommand.setBatchSizeCommand(batchSize);
                String userId = getUserSessionSupport().getAuthenticatedUsername();
                calculationCommand.setUserID(userId);
                //BPM-926 - hit openshift rest endpoint and pass in command to kick off service.
                if (calculationCommand.isPendingActivityEventsCommand()) {
                    LookUpValueCode luvRestEndpoint = (LookUpValueCode) memberService.getLUVCodeByGroupNValue(BPMAdminConstants.OS_REST_URL_COMMAND, BPMAdminConstants.OS_URL_KS_PENDING_ACTIVITY);
                    String urlRestEndpointCommand = luvRestEndpoint.getLuvDesc();
                    memberService.kickStartBatchProcessOnOpenshift(urlRestEndpointCommand);
                }
                if (calculationCommand.isReprocessMissingActivitiesCommand()) {
                    LookUpValueCode luvRestEndpoint = (LookUpValueCode) memberService.getLUVCodeByGroupNValue(BPMAdminConstants.OS_REST_URL_COMMAND, BPMAdminConstants.OS_URL_KS_MISSING_ACTIVITIES);
                    String urlRestEndpointCommand = luvRestEndpoint.getLuvDesc();
                    memberService.kickStartBatchProcessOnOpenshift(urlRestEndpointCommand);
                }
                if (calculationCommand.isEmployerBaselineSetup()) {
                    LookUpValueCode luvRestEndpoint = (LookUpValueCode) memberService.getLUVCodeByGroupNValue(BPMAdminConstants.OS_REST_URL_COMMAND, BPMAdminConstants.OS_URL_KS_EMPLOYER_BASELINE_SETUP);
                    String urlRestEndpointCommand = luvRestEndpoint.getLuvDesc();
                    memberService.kickStartBatchProcessOnOpenshift(urlRestEndpointCommand);
                }
                if (calculationCommand.isEmployerGroupSiteSetup()) {
                    LookUpValueCode luvRestEndpoint = (LookUpValueCode) memberService.getLUVCodeByGroupNValue(BPMAdminConstants.OS_REST_URL_COMMAND, BPMAdminConstants.OS_URL_KS_EMPLOYER_GRP_SITE_SETUP);
                    String urlRestEndpointCommand = luvRestEndpoint.getLuvDesc();
                    memberService.kickStartBatchProcessOnOpenshift(urlRestEndpointCommand);
                }
                if (calculationCommand.isEtlMembershipUpdateQueueCommand()) {
                    LookUpValueCode luvRestEndpoint = (LookUpValueCode) memberService.getLUVCodeByGroupNValue(BPMAdminConstants.OS_REST_URL_COMMAND, BPMAdminConstants.OS_URL_KS_MEMBER_UPD_QUEUE);
                    String urlRestEndpointCommand = luvRestEndpoint.getLuvDesc();
                    memberService.kickStartBatchProcessOnOpenshift(urlRestEndpointCommand);
                }
                if (calculationCommand.isPopulateMissingPeople()) {
                    LookUpValueCode luvRestEndpoint = (LookUpValueCode) memberService.getLUVCodeByGroupNValue(BPMAdminConstants.OS_REST_URL_COMMAND, BPMAdminConstants.OS_URL_KS_ETL_MISSING_PERSON);
                    String urlRestEndpointCommand = luvRestEndpoint.getLuvDesc();
                    memberService.kickStartBatchProcessOnOpenshift(urlRestEndpointCommand);
                }

                createActionMessagesOnModel(modelMap, "messages.batchjob.started", new Object[]{operationType});

                // log the batch job for audit
                SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss z");
                String sanitizedOperationType = operationType.replaceAll("[\\r\\n]", "");
                if (sanitizedOperationType.matches("\\w*")) {
                    logger.info("@@@Batch job named '" + sanitizedOperationType
                            + "' has been started by user '" + userId
                            + "' at time '" + dateFormat.format(new Date())
                            + "' through BPM-ADMIN application @@@");
                }

            } else {
                createActionMessagesOnModel(modelMap, "messages.info", new Object[]{"Unknown batch job named '" + operationType + "'."});
            }
        }

        return resultPage;
    }

    @Override
    public boolean supports(Class<?> clazz) {
        return BatchJobsForm.class.isAssignableFrom(clazz);
    }

    @Override
    public void validate(Object target, Errors errors) {
        BatchJobsForm form = (BatchJobsForm) target;
    }
}
