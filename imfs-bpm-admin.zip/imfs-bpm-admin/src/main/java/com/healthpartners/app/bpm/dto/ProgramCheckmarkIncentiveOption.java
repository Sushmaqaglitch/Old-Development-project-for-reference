package com.healthpartners.app.bpm.dto;

import java.io.Serializable;

/**
 * 
 * @author jxbourbour
 *
 */
public class ProgramCheckmarkIncentiveOption implements Serializable
{	
	static final long serialVersionUID = 0L;
		
	private Integer programCheckmarkIncentiveOptionID;
	private Integer programCheckmarkID;
	private Integer programIncentiveOptionID;
	
	private String qualificationCheckmarkName;
	private String incentiveOptionName;
	
	private Boolean assigned;
		
	public ProgramCheckmarkIncentiveOption()
	{
		super();
	}

	public Integer getProgramCheckmarkIncentiveOptionID() {
		return programCheckmarkIncentiveOptionID;
	}

	public void setProgramCheckmarkIncentiveOptionID(
			Integer programCheckmarkIncentiveOptionID) {
		this.programCheckmarkIncentiveOptionID = programCheckmarkIncentiveOptionID;
	}

	public Integer getProgramCheckmarkID() {
		return programCheckmarkID;
	}

	public void setProgramCheckmarkID(Integer programCheckmarkID) {
		this.programCheckmarkID = programCheckmarkID;
	}

	public Integer getProgramIncentiveOptionID() {
		return programIncentiveOptionID;
	}

	public void setProgramIncentiveOptionID(Integer programIncentiveOptionID) {
		this.programIncentiveOptionID = programIncentiveOptionID;
	}

	public String getQualificationCheckmarkName() {
		return qualificationCheckmarkName;
	}

	public void setQualificationCheckmarkName(String qualificationCheckmarkName) {
		this.qualificationCheckmarkName = qualificationCheckmarkName;
	}

	public String getIncentiveOptionName() {
		return incentiveOptionName;
	}

	public void setIncentiveOptionName(String incentiveOptionName) {
		this.incentiveOptionName = incentiveOptionName;
	}

	public Boolean getAssigned() {
		return assigned;
	}

	public void setAssigned(Boolean assigned) {
		this.assigned = assigned;
	}

	
		
}
