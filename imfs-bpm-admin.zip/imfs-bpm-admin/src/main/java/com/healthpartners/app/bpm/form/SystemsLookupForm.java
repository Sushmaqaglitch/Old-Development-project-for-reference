package com.healthpartners.app.bpm.form;

/**
 * @author jxbourbour
 *
 */
public class SystemsLookupForm extends BaseForm {

	static final long serialVersionUID = 0L;

	private String systemValue;
	

	public SystemsLookupForm() {
		super();
	}


	public String getSystemValue() {
		return systemValue;
	}


	public void setSystemValue(String systemValue) {
		this.systemValue = systemValue;
	}
}
