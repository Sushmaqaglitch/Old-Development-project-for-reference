/**
 * 
 */
package com.healthpartners.app.bpm.form;


import com.healthpartners.app.bpm.dto.LookUpValueCode;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.util.Collection;

/**
 * @author tjquist
 *
 */
public class SaveActivityForm extends BaseForm {


	Collection<LookUpValueCode> luvActivityTypes;
	Integer activityID;
	@Size(min=1, max=20, message = "Source System Activity ID" + REQUIRED)
	String sourceSystemActivityID;
	String luvActivityTypeCodeValue;
	@Min(value=1, message = "Activity Type" + REQUIRED)
	Integer luvActivityTypeCodeId;
	@NotNull
	@Size(min=1, max=100, message = "Name" + REQUIRED)
	String name;
	int duration;
	@Size(min=1, max=50, message = "Host Source" + REQUIRED)
	String hostSource;
	String cost;
	String webLink;
	@Size(min=1, max=1000, message = "Description" + REQUIRED)
	String description;
	@Size(min=1, max=10, message = "Activity Effective Date" + REQUIRED)
	String effectiveDate;
	@Size(min=1, max=10, message = "Activity End Date" + REQUIRED)
	String endDate;

	public Collection<LookUpValueCode> getLuvActivityTypes() {
		return luvActivityTypes;
	}

	public void setLuvActivityTypes(Collection<LookUpValueCode> luvActivityTypes) {
		this.luvActivityTypes = luvActivityTypes;
	}

	public Integer getActivityID() {
		return activityID;
	}

	public void setActivityID(Integer activityID) {
		this.activityID = activityID;
	}

	public String getSourceSystemActivityID() {
		return sourceSystemActivityID;
	}

	public void setSourceSystemActivityID(String sourceSystemActivityID) {
		this.sourceSystemActivityID = sourceSystemActivityID;
	}

	public String getLuvActivityTypeCodeValue() {
		return luvActivityTypeCodeValue;
	}

	public void setLuvActivityTypeCodeValue(String luvActivityTypeCodeValue) {
		this.luvActivityTypeCodeValue = luvActivityTypeCodeValue;
	}

	public Integer getLuvActivityTypeCodeId() {
		return luvActivityTypeCodeId;
	}

	public void setLuvActivityTypeCodeId(Integer luvActivityTypeCodeId) {
		this.luvActivityTypeCodeId = luvActivityTypeCodeId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getDuration() {
		return duration;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}

	public String getHostSource() {
		return hostSource;
	}

	public void setHostSource(String hostSource) {
		this.hostSource = hostSource;
	}

	public String getCost() {
		return cost;
	}

	public void setCost(String cost) {
		this.cost = cost;
	}

	public String getWebLink() {
		return webLink;
	}

	public void setWebLink(String webLink) {
		this.webLink = webLink;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(String effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
}
