package com.healthpartners.app.bpm.form;
import org.springframework.ui.ModelMap;

public class MemberUpdateForm extends BaseForm {

	static final long serialVersionUID = 0L;

	private String operationType;

	private String memberID;

	private String qualificationStartDate;

	private String personDemographicsID;
	private String personID;
	
	private String searchedMemberID;
	
	private String groupNumber;
	
	private Integer contractNo;


	private int programID;

	private int programIncentiveOptionID;
	
	private int[] programIDs;
	
	private String[] currentMemberStatuses;
	private String[] newMemberStatuses;
	
	private String[] currentContractStatuses;
	private String[] newContractStatuses;

	private boolean[] memberStatusCalcDatePassed;
	private boolean[] contractStatusCalcDatePassed;
	
	private String[] participationEndDates;

	private String[] qualificationStartDates;

	public MemberUpdateForm() {
		super();
	}

	public void reset(ModelMap modelMap) {

		if (modelMap.isEmpty()) {
			//no values to cleawr out
		} else {
			modelMap = new ModelMap();
		}
	}

	public String getMemberID() {
		if(memberID != null)
		{
			return memberID.trim();
		}
		return memberID;
	}

	public void setMemberID(String memberID) {
		this.memberID = memberID;
	}

	public String getOperationType() {
		return operationType;
	}

	public void setOperationType(String operationType) {
		this.operationType = operationType;
	}

	public String getQualificationStartDate() {
		return qualificationStartDate;
	}

	public void setQualificationStartDate(String qualificationStartDate) {
		this.qualificationStartDate = qualificationStartDate;
	}

	public String getPersonID() {
		return personID;
	}

	public void setPersonID(String personID) {
		this.personID = personID;
	}

	public String getSearchedMemberID() {
		return searchedMemberID;
	}

	public void setSearchedMemberID(String searchedMemberID) {
		this.searchedMemberID = searchedMemberID;
	}

	public String getGroupNumber() {
		if(groupNumber != null)
		{
			return groupNumber.trim();
		}
		return groupNumber;
	}

	public void setGroupNumber(String groupNumber) {

		this.groupNumber = groupNumber;
	}

	public int getProgramID() {
		return programID;
	}

	public void setProgramID(int programID) {

		this.programID = programID;
	}

	public int getProgramIncentiveOptionID() {
		return programIncentiveOptionID;
	}

	public void setProgramIncentiveOptionID(int programIncentiveOptionID) {
		this.programIncentiveOptionID = programIncentiveOptionID;
	}

	public final int[] getProgramIDs() {
		return programIDs;
	}

	public final void setProgramIDs(int[] programIDs) {

		this.programIDs = programIDs;
	}

	

	public final boolean[] getContractStatusCalcDatePassed() {
		return contractStatusCalcDatePassed;
	}

	public final void setContractStatusCalcDatePassed(
			boolean[] contractStatusCalcDatePassed) {
		this.contractStatusCalcDatePassed = contractStatusCalcDatePassed;
	}

	public final boolean[] getMemberStatusCalcDatePassed() {
		return memberStatusCalcDatePassed;
	}

	public final void setMemberStatusCalcDatePassed(
			boolean[] memberStatusCalcDatePassed) {
		this.memberStatusCalcDatePassed = memberStatusCalcDatePassed;
	}

	public final String[] getNewMemberStatuses() {
		return newMemberStatuses;
	}

	public final void setNewMemberStatuses(String[] newMemberStatuses) {

		this.newMemberStatuses = newMemberStatuses;
	}

	public final String[] getCurrentContractStatuses() {
		return currentContractStatuses;
	}

	public final void setCurrentContractStatuses(String[] currentContractStatuses) {
		this.currentContractStatuses = currentContractStatuses;
	}

	public final String[] getCurrentMemberStatuses() {
		return currentMemberStatuses;
	}

	public final void setCurrentMemberStatuses(String[] currentMemberStatuses) {
		this.currentMemberStatuses = currentMemberStatuses;
	}

	public final String[] getNewContractStatuses() {
		return newContractStatuses;
	}

	public final void setNewContractStatuses(String[] newContractStatuses) {
		this.newContractStatuses = newContractStatuses;
	}


	public final Integer getContractNo() {
		return contractNo;
	}

	public final void setContractNo(Integer contractNo) {
		this.contractNo = contractNo;
	}

	public String getPersonDemographicsID() {
		return personDemographicsID;
	}

	public void setPersonDemographicsID(String personDemographicsID) {
		this.personDemographicsID = personDemographicsID;
	}

	public String[] getParticipationEndDates() {
		return participationEndDates;
	}

	public void setParticipationEndDates(String[] participationEndDates) {
		this.participationEndDates = participationEndDates;
	}


}
