package com.healthpartners.app.bpm.dto;

import com.healthpartners.service.bpm.dto.BaseDTO;

/**
 * @author tjquist
 */
public class Risk extends BaseDTO {

    static final long serialVersionUID = 0L;

    private Integer riskID;
    private String name;
    private String description;
    private String holdDuration;
    private Integer groupCodeID;
    private String groupCodeVal;
    private String userId;
    private Integer used;


    public Risk() {
        super();
    }

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public Integer getUsed() {
        return used;
    }

    public void setUsed(Integer used) {
        this.used = used;
    }

    public Integer getRiskID() {
        return riskID;
    }

    public void setRiskID(Integer riskID) {
        this.riskID = riskID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getHoldDuration() {
        return holdDuration;
    }

    public void setHoldDuration(String holdDuration) {
        this.holdDuration = holdDuration;
    }

    public Integer getGroupCodeID() {
        return groupCodeID;
    }

    public void setGroupCodeID(Integer groupCodeID) {
        this.groupCodeID = groupCodeID;
    }

    public String getGroupCodeVal() {
        return groupCodeVal;
    }

    public void setGroupCodeVal(String groupCodeVal) {
        this.groupCodeVal = groupCodeVal;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }


}
