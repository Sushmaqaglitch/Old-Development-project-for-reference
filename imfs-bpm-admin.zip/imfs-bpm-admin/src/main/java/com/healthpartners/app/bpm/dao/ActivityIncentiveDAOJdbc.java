package com.healthpartners.app.bpm.dao;

import com.healthpartners.app.bpm.dto.ActivityIncentiveDetail;
import com.healthpartners.app.bpm.dto.ActivityIncentiveRequirement;
import com.healthpartners.app.bpm.dto.IncentiveParticipantRelationship;
import com.healthpartners.app.bpm.dto.ProgramActivityIncentiveSummary;
import com.healthpartners.app.bpm.exception.BPMException;
import jakarta.annotation.PostConstruct;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.jdbc.support.incrementer.DataFieldMaxValueIncrementer;
import org.springframework.jdbc.support.incrementer.OracleSequenceMaxValueIncrementer;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Collection;

@Repository
@Transactional(timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
public class ActivityIncentiveDAOJdbc extends JdbcDaoSupport implements ActivityIncentiveDAO {

	// @formatter:off
	private static final String selectProgramActivityIncentiveRequirements =
			"SELECT \n" +
			"ACTV_INCNTV_GRP_ID,\n" +
			"ACTV_INCNTV_GRP_REQ_ID,\n" +
			"REQRD_QTY,\n" +
			"INSERT_TS,\n" +
			"MODIFY_TS,\n" +
			"INSERT_USR,\n" +
			"MODIFY_USR,\n" +
			"INCNTV_OPTN_ID,\n" +
			"BIZ_PGM_ID\n" +
			"FROM ACTIVITY_INCENTIVE_GRP_REQ\n" +
			"WHERE biz_pgm_id = ? AND\n" +
			"INCNTV_OPTN_ID = ? ";

	private static final String selectProgramActivityIncentiveDetails =
			"SELECT\n" +
					"        ai.BIZ_PGM_ID,\n" +
					"        ai.ACTV_INCNTV_ID,\n" +
					"        ai.ACTV_INCNTV_GRP_ID,\n" +
					"        ai.ACTV_INCNTV_GRP_REQ_ID,\n" +
					"        ai.INCNTV_OPTN_ID,\n" +
					"        ai.ACTV_ID,\n" +
					"        (SELECT actv_nm FROM activity WHERE activity.actv_id = ai.ACTV_ID) actv_nm,\n" +
					"        ai.ACTV_TP_CD_ID,\n" +
					"        (SELECT lu_val  FROM luv WHERE lu_id=ai.ACTV_TP_CD_ID) activityTypeVal,\n" +
					"        (SELECT lu_desc FROM luv WHERE lu_id=ai.ACTV_TP_CD_ID) activityTypeDesc,\n" +
					"        ACTV_INCNTV_TP_CD_ID,\n" +
					"        io_activity_incentive.lu_val activityIncentiveTypeVal,\n" +
					"        io_activity_incentive.lu_desc activityIncentiveTypeDesc,\n" +
					"        ai.INCNTD_STS_TP_CD_ID,\n" +
					"        io_incented_status.lu_val incentedStatusTypeVal,\n" +
					"        io_incented_status.lu_desc incentedStatusTypeDesc,\n" +
					"        ai.INCNTV_QTY,\n" +
					"        ai.INSERT_TS,\n" +
					"        ai.MODIFY_TS,\n" +
					"        ai.INSERT_USR,\n" +
					"        ai.MODIFY_USR,\n" +
					"        aigr.reqrd_qty,        \n" +
					"        incent_opt.incntv_optn_nm\n" +
					"        , incent_opt.INCNTV_URL\n" +
					"        , ai.collection_id\n" +
					"        , (SELECT collection_nm FROM collection WHERE collection.collection_id = ai.collection_id) collection_nm\n" +
					"      FROM activity_incentive ai,\n" +
					"           activity_incentive_grp_req aigr,\n" +
					"           incentive_option incent_opt,\n" +
					"           luv io_activity_incentive,\n" +
					"           luv io_incented_status\n" +
					"      WHERE\n" +
					"           ai.biz_pgm_id = ? and\n" +
					"           ai.INCNTV_OPTN_ID = ? and   \n" +
					"           ai.actv_incntv_grp_id = ? AND \n" +
					"           ai.actv_incntv_grp_id =  aigr.actv_incntv_grp_id and\n" +
					"           ai.actv_incntv_grp_req_id = aigr.actv_incntv_grp_req_id and\n" +
					"           io_activity_incentive.lu_id = ai.actv_incntv_tp_cd_id and\n" +
					"           io_incented_status.lu_id = ai.incntd_sts_tp_cd_id and           \n" +
					"           incent_opt.incntv_optn_id = ai.INCNTV_OPTN_ID ";

	private static final String selectIncentiveParticipantRelationships =
			"SELECT \n" +
					"          ACTV_INCNTV_ID,\n" +
					"          REL_CD,\n" +
					"          MAX_QTY,\n" +
					" rlshp_txt\n" +
					"      FROM INCENTIVE_PARTICIP_REL\n" +
					", pes_rel_ds\n" +
					"      WHERE ACTV_INCNTV_ID = ?\n" +
					"AND rel_cd = pes_rel_ds.rlshp_cd";

	private static final String insertIncentiveRequirement =
			"INSERT INTO activity_incentive_grp_req (\n" +
					"  ACTV_INCNTV_GRP_ID \n" +
					", ACTV_INCNTV_GRP_REQ_ID\n" +
					", INCNTV_OPTN_ID \n" +
					", BIZ_PGM_ID \n" +
					", REQRD_QTY\n" +
					", INSERT_TS \n" +
					", INSERT_USR )\n" +
					"VALUES (?, ?, ?, ?, ?, SYSDATE, ?)";

	private static final String insertActivityIncentiveDetail =
			"INSERT INTO activity_incentive (\n" +
					"ACTV_INCNTV_ID \n" +
					", ACTV_INCNTV_GRP_ID \n" +
					", ACTV_INCNTV_GRP_REQ_ID \n" +
					", INCNTV_OPTN_ID \n" +
					", BIZ_PGM_ID     \n" +
					", ACTV_ID        \n" +
					", ACTV_TP_CD_ID  \n" +
					", COLLECTION_ID\n" +
					", ACTV_INCNTV_TP_CD_ID \n" +
					", INCNTD_STS_TP_CD_ID  \n" +
					", INCNTV_QTY \n" +
					", INSERT_TS  \n" +
					", INSERT_USR ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, SYSDATE, ?) ";

	private static final String insertIncentiveParticipant =
			"INSERT INTO incentive_particip_rel (ACTV_INCNTV_ID\n" +
					", REL_CD\n" +
					", MAX_QTY \n" +
					", INSERT_TS  \n" +
					", INSERT_USR ) VALUES (?, ?, ?, SYSDATE, ?) ";

	private static final String selectProgramActivityIncentiveSummary =
			"SELECT \n" +
					"          AIGR.biz_pgm_id,\n" +
					"          AIGR.ACTV_INCNTV_GRP_ID,\n" +
					"          AIGR.ACTV_INCNTV_GRP_REQ_ID,\n" +
					"          AIGR.INCNTV_OPTN_ID,\n" +
					"          AI.ACTV_INCNTV_ID,\n" +
					"          LUV_ACT_TYPE.LU_VAL ACTIVITY_TYPE,\n" +
					"          A.ACTV_NM ACTIVITY_NAME,\n" +
					"          IO.INCNTV_OPTN_NM INCENTIVE_OPTION_NAME,\n" +
					"           REL.RLSHP_TXT REL_NAME,\n" +
					"          LUV_INCENT_STATUS.LU_VAL INCENTIVE_STATUS                          \n" +
					"      FROM ACTIVITY_INCENTIVE_GRP_REQ AIGR,\n" +
					"           INCENTIVE_OPTION IO,\n" +
					"           ACTIVITY_INCENTIVE AI,\n" +
					"           ACTIVITY A,\n" +
					"           INCENTIVE_PARTICIP_REL IPR,\n" +
					"           LUV LUV_ACT_TYPE,\n" +
					"           LUV LUV_INCENT_STATUS,\n" +
					"           PES_REL_DS REL                 \n" +
					"      WHERE AIGR.biz_pgm_id = ? AND\n" +
					"            AIGR.INCNTV_OPTN_ID = IO.INCNTV_OPTN_ID AND\n" +
					"            AI.BIZ_PGM_ID = AIGR.biz_pgm_id AND\n" +
					"            AI.INCNTV_OPTN_ID = IO.INCNTV_OPTN_ID\n" +
					"            AND (a.actv_id = coalesce(ai.actv_id, -1)\n" +
					"                 OR a.actv_tp_cd_id = coalesce(ai.actv_tp_cd_id, -1))\n" +
					"            AND LUV_ACT_TYPE.LU_ID = A.ACTV_TP_CD_ID AND\n" +
					"            IPR.ACTV_INCNTV_ID = AI.ACTV_INCNTV_ID AND\n" +
					"            LUV_INCENT_STATUS.LU_ID = AI.ACTV_INCNTV_TP_CD_ID AND\n" +
					"            REL.RLSHP_CD = IPR.REL_CD ";

	// @formatter:on

	protected final Log logger = LogFactory.getLog(getClass());

	private final DataSource dataSource;

	private DataFieldMaxValueIncrementer incentiveRequirementIdIncrementer;
	private static final String ACTV_INCNTV_GRP_ID_SEQ = "ACTV_INCNTV_GRP_ID_SEQ";
	private DataFieldMaxValueIncrementer activityIncentiveIdIncrementer;
	private static final String ACTV_INCNTV_ID_SEQ = "ACTV_INCNTV_ID_SEQ";
	private static final String updateActivityIncentiveDetailDirectly =
			"""
   			UPDATE activity_incentive t SET t.actv_id = ?, t.actv_tp_cd_id = ?, t.collection_id = ?, t.incntv_qty = ?, t.MODIFY_TS = SYSDATE, t.MODIFY_USR = ?  WHERE ACTV_INCNTV_ID = ?
			""";
	private static final String deleteIncentiveParticipantByID =
			"""
   			DELETE FROM incentive_particip_rel WHERE ACTV_INCNTV_ID = ? 
			""";
	private static final String deleteIncentiveParticipant =
			"""
			DELETE FROM incentive_particip_rel WHERE ACTV_INCNTV_ID IN 
			(SELECT ACTV_INCNTV_ID FROM activity_incentive WHERE biz_pgm_id = ? 
			""";
	private static final String deleteActivityIncentiveDetail =
			"""
   			DELETE FROM activity_incentive WHERE biz_pgm_id = ? 
			""";
	private static final String deleteIncentiveRequirement =
			"""
   			DELETE FROM activity_incentive_grp_req WHERE biz_pgm_id = ? 
			""";

	public ActivityIncentiveDAOJdbc (DataSource dataSource) {
		this.dataSource = dataSource;
	}


	@PostConstruct
	private void initialize() {
		setDataSource(dataSource);
		incentiveRequirementIdIncrementer = new OracleSequenceMaxValueIncrementer(dataSource, ACTV_INCNTV_GRP_ID_SEQ);
		activityIncentiveIdIncrementer = new OracleSequenceMaxValueIncrementer(dataSource, ACTV_INCNTV_ID_SEQ);
	}

	/**
	 * @param programID
	 * @return
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Override
	public Collection<ActivityIncentiveRequirement> getProgramActivityIncentiveRequirements(Integer programID, Integer incentiveOptionID)
			throws BPMException, DataAccessException {

		final ArrayList<ActivityIncentiveRequirement> lProgramActivityIncentiveRequirements = new ArrayList<ActivityIncentiveRequirement>();

		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[]{programID, incentiveOptionID};
		int types[] = new int[]{Types.INTEGER, Types.INTEGER};

		template.query(selectProgramActivityIncentiveRequirements, params, types, new RowCallbackHandler() {
			public void processRow(ResultSet rs) throws SQLException {
				ActivityIncentiveRequirement lActivityIncentiveRequirement = new ActivityIncentiveRequirement();
				lActivityIncentiveRequirement.setGroupID(rs.getInt("ACTV_INCNTV_GRP_ID"));
				lActivityIncentiveRequirement.setGroupRequirementID(rs.getInt("ACTV_INCNTV_GRP_REQ_ID"));
				lActivityIncentiveRequirement.setQuantity(rs.getInt("REQRD_QTY"));
				lActivityIncentiveRequirement.setIncentiveOptionID(rs.getInt("INCNTV_OPTN_ID"));
				lActivityIncentiveRequirement.setProgramID(rs.getInt("BIZ_PGM_ID"));

				lProgramActivityIncentiveRequirements.add(lActivityIncentiveRequirement);
			}
		});

		// Now for each Program Activity Incentive Requirement, retrieve the Requirement Details.
		for (int i = 0; i < lProgramActivityIncentiveRequirements.size(); i++) {
			ArrayList<ActivityIncentiveDetail> lProgramActivityIncentiveRequirementsDetails = (ArrayList<ActivityIncentiveDetail>)
					getProgramActivityIncentiveRequirementDetails(programID,
							lProgramActivityIncentiveRequirements.get(i).getIncentiveOptionID(),
							lProgramActivityIncentiveRequirements.get(i).getGroupID());

			lProgramActivityIncentiveRequirements.get(i).setActivityIncentiveDetails(lProgramActivityIncentiveRequirementsDetails);
		}


		return lProgramActivityIncentiveRequirements;
	}

	/**
	 *
	 * @param programID
	 * @param incentiveOptionID
	 * @param pIncentiveRequirementGroupID
	 * @return
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	private Collection<ActivityIncentiveDetail> getProgramActivityIncentiveRequirementDetails(Integer programID, Integer incentiveOptionID, Integer pIncentiveRequirementGroupID) throws BPMException, DataAccessException {
		final ArrayList<ActivityIncentiveDetail> lActivityIncentiveDetailList = new ArrayList<ActivityIncentiveDetail>();

		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[]{programID, incentiveOptionID, pIncentiveRequirementGroupID};
		int types[] = new int[]{Types.INTEGER, Types.INTEGER, Types.INTEGER};

		template.query(selectProgramActivityIncentiveDetails, params, types, new RowCallbackHandler() {
			public void processRow(ResultSet rs) throws SQLException {
				ActivityIncentiveDetail lActivityIncentiveDetail = new ActivityIncentiveDetail();
				//lActivityIncentiveDetail.setRowID(rowNum);
				lActivityIncentiveDetail.setProgramID(rs.getInt("BIZ_PGM_ID"));
				lActivityIncentiveDetail
						.setActivityIncentiveID(rs.getObject("ACTV_INCNTV_ID") != null ? Integer.valueOf(
								rs.getInt("ACTV_INCNTV_ID"))
								: null);
				lActivityIncentiveDetail.setGroupID(rs.getInt("ACTV_INCNTV_GRP_ID"));
				lActivityIncentiveDetail.setGroupRequiredID(rs.getInt("ACTV_INCNTV_GRP_REQ_ID"));
				lActivityIncentiveDetail.setIncentiveOptionID(rs.getInt("INCNTV_OPTN_ID"));
				lActivityIncentiveDetail.setIncentiveOptionName(rs.getString("incntv_optn_nm"));

				lActivityIncentiveDetail.setActivityID(rs.getInt("ACTV_ID"));
				lActivityIncentiveDetail.setActivityName(rs.getString("actv_nm"));
				// Activity Type
				lActivityIncentiveDetail.setActivityTypeCodeID(rs.getInt("ACTV_TP_CD_ID"));
				lActivityIncentiveDetail.setActivityTypeVal(rs.getString("activityTypeVal"));
				// Incentive Type
				lActivityIncentiveDetail.setActivityIncentiveTypeDesc(rs.getString("activityIncentiveTypeDesc"));
				lActivityIncentiveDetail.setActivityIncentiveTypeCodeID(rs.getInt("ACTV_INCNTV_TP_CD_ID"));
				lActivityIncentiveDetail.setActivityIncentiveTypeVal(rs.getString("activityIncentiveTypeVal"));
				// Incented Status Type
				lActivityIncentiveDetail.setIncentedStatusTypeCodeID(rs.getInt("INCNTD_STS_TP_CD_ID"));
				lActivityIncentiveDetail.setActivityIncentedStatusTypeVal(rs.getString("incentedStatusTypeVal"));
				lActivityIncentiveDetail.setActivityIncentedStatusTypeDesc(rs.getString("incentedStatusTypeDesc"));

				lActivityIncentiveDetail.setCollectionID(rs.getInt("collection_id"));
				lActivityIncentiveDetail.setCollectionName(rs.getString("collection_nm"));


				lActivityIncentiveDetail.setIncentiveQuantity(rs.getInt("INCNTV_QTY"));
				lActivityIncentiveDetail.setInsertDate(rs.getDate("INSERT_TS"));
				lActivityIncentiveDetail.setInsertUserId(rs.getString("INSERT_TS"));
				lActivityIncentiveDetail.setModifyDate(rs.getDate("MODIFY_TS"));
				lActivityIncentiveDetail.setModifyUserId(rs.getString("MODIFY_USR"));

				lActivityIncentiveDetailList.add(lActivityIncentiveDetail);
			}
		});

		// For each Program Activity Incentive Detail record, retrieve the incentive participant detail.
		for (int i = 0; i < lActivityIncentiveDetailList.size(); i++) {
			ArrayList<IncentiveParticipantRelationship> lIncentiveParticipantRelationships = (ArrayList<IncentiveParticipantRelationship>)
					getIncentiveParticipantRelationships(lActivityIncentiveDetailList.get(i).getActivityIncentiveID());

			lActivityIncentiveDetailList.get(i).setIncentiveParticipantRelationships(lIncentiveParticipantRelationships);
		}


		return lActivityIncentiveDetailList;
	}

	/**
	 *
	 * @param activityIncentiveID
	 * @return
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	private Collection<IncentiveParticipantRelationship> getIncentiveParticipantRelationships(Integer activityIncentiveID) throws BPMException, DataAccessException {
		final ArrayList<IncentiveParticipantRelationship> lIncentiveParticipantRelationships = new ArrayList<IncentiveParticipantRelationship>();

		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[]{activityIncentiveID};
		int types[] = new int[]{Types.INTEGER};

		template.query(selectIncentiveParticipantRelationships, params, types, new RowCallbackHandler() {
			public void processRow(ResultSet rs) throws SQLException {
				IncentiveParticipantRelationship lIncentiveParticipantRelationship = new IncentiveParticipantRelationship();

				lIncentiveParticipantRelationship.setActivityIncentiveID(rs.getInt("ACTV_INCNTV_ID"));
				lIncentiveParticipantRelationship.setRelationshipCode(rs.getInt("REL_CD"));
				lIncentiveParticipantRelationship.setMaxQauntity(rs.getInt("MAX_QTY"));
				lIncentiveParticipantRelationship.setRelationshipName(rs.getString("rlshp_txt"));

				lIncentiveParticipantRelationships.add(lIncentiveParticipantRelationship);
			}
		});

		return lIncentiveParticipantRelationships;
	}

	/**
	 * @param pIncentiveRequirement
	 * @param pUserID
	 * @return
	 * @throws DataAccessException
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Override
	public Integer insertIncentiveRequirement(ActivityIncentiveRequirement pIncentiveRequirement, String pUserID) throws DataAccessException {
		JdbcTemplate template = getJdbcTemplate();

		Integer incentiveGroupID = incentiveRequirementIdIncrementer.nextIntValue();

		Object params[] = new Object[]{incentiveGroupID
				, pIncentiveRequirement.getGroupRequirementID()
				, pIncentiveRequirement.getIncentiveOptionID()
				, pIncentiveRequirement.getProgramID()
				, pIncentiveRequirement.getQuantity()
				, pUserID};
		int types[] = new int[]{Types.INTEGER, Types.INTEGER,
				Types.INTEGER, Types.INTEGER, Types.INTEGER,
				Types.VARCHAR};

		int rowInserted = template.update(insertIncentiveRequirement, params, types);

		return incentiveGroupID;
	}

	/**
	 * Inserts a record into the Activity Incentive table.
	 *
	 * @param pActivityIncentiveDetail
	 * @return
	 * @throws DataAccessException
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Override
	public Integer insertActivityIncentiveDetail(ActivityIncentiveDetail pActivityIncentiveDetail, String pUserID) throws DataAccessException {
		JdbcTemplate template = getJdbcTemplate();

		int activityIncentiveID = activityIncentiveIdIncrementer.nextIntValue();

		Object params[] = new Object[] { activityIncentiveID
				, pActivityIncentiveDetail.getGroupID()
				, pActivityIncentiveDetail.getGroupRequiredID()
				, pActivityIncentiveDetail.getIncentiveOptionID()
				, pActivityIncentiveDetail.getProgramID()
				, pActivityIncentiveDetail.getActivityID()
				, pActivityIncentiveDetail.getActivityTypeCodeID()
				, pActivityIncentiveDetail.getCollectionID()
				, pActivityIncentiveDetail.getActivityIncentiveTypeCodeID()
				, pActivityIncentiveDetail.getIncentedStatusTypeCodeID()
				, pActivityIncentiveDetail.getIncentiveQuantity()
				, pUserID};
		int types[] = new int[] { Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.INTEGER,
				Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.INTEGER,
				Types.VARCHAR};

		int rowInserted = template.update(insertActivityIncentiveDetail, params, types);

		return activityIncentiveID;
	}

	/**
	 * Inserts a row in the Incentive Participant Relationship table.
	 *
	 * @param pIncentiveParticipantRelationship
	 * @param pUserID
	 * @return
	 * @throws DataAccessException
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Override
	public Integer insertIncentiveParticipant(IncentiveParticipantRelationship pIncentiveParticipantRelationship, String pUserID) throws DataAccessException {
		JdbcTemplate template = getJdbcTemplate();

		Object params[] = new Object[]{pIncentiveParticipantRelationship.getActivityIncentiveID()
				, pIncentiveParticipantRelationship.getRelationshipCode()
				, pIncentiveParticipantRelationship.getMaxQauntity()
				, pUserID};
		int types[] = new int[]{Types.INTEGER, Types.INTEGER, Types.INTEGER,
				Types.VARCHAR};

		int rowInserted = template.update(insertIncentiveParticipant, params, types);

		return rowInserted;
	}

	/**
	 * @param programID
	 * @return
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Override
	public Collection<ProgramActivityIncentiveSummary> getProgramActivityIncentiveSummaryWithRequirements(Integer programID) throws BPMException, DataAccessException {

		final ArrayList<ProgramActivityIncentiveSummary> lProgramActivityIncentivesSummary = new ArrayList<ProgramActivityIncentiveSummary>();

		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[]{programID};
		int types[] = new int[]{Types.INTEGER};

		template.query(selectProgramActivityIncentiveSummary, params, types, new RowCallbackHandler() {
			int rowID = 1;

			public void processRow(ResultSet rs) throws SQLException {
				ProgramActivityIncentiveSummary lProgramActivityIncentiveSummary = new ProgramActivityIncentiveSummary();
				lProgramActivityIncentiveSummary.setRowID(rowID++);
				lProgramActivityIncentiveSummary.setProgramID(rs.getInt("BIZ_PGM_ID"));
				lProgramActivityIncentiveSummary.setIncentiveOptionID(rs.getInt("INCNTV_OPTN_ID"));
				lProgramActivityIncentiveSummary.setActivityIncentiveGroupID(rs.getInt("ACTV_INCNTV_GRP_ID"));
				lProgramActivityIncentiveSummary.setActivityIncentiveGroupReqID(rs.getInt("ACTV_INCNTV_GRP_REQ_ID"));
				lProgramActivityIncentiveSummary.setActivityIncentiveID(rs.getInt("ACTV_INCNTV_ID"));
				lProgramActivityIncentiveSummary.setIncentiveOptionID(rs.getInt("INCNTV_OPTN_ID"));
				lProgramActivityIncentiveSummary.setActivityTypeDesc(rs.getString("ACTIVITY_TYPE"));
				lProgramActivityIncentiveSummary.setActivityName(rs.getString("ACTIVITY_NAME"));
				lProgramActivityIncentiveSummary.setIncentiveOptionName(rs.getString("INCENTIVE_OPTION_NAME"));
				lProgramActivityIncentiveSummary.setRelationshipName(rs.getString("REL_NAME"));
				lProgramActivityIncentiveSummary.setIncentiveStatus(rs.getString("INCENTIVE_STATUS"));

				lProgramActivityIncentivesSummary.add(lProgramActivityIncentiveSummary);
			}
		});

		// Now for each Program Activity Incentive Group which relates back to a program incentive option record, retrieve the Program Activity Incentive Requirements.
		for (int i = 0; i < lProgramActivityIncentivesSummary.size(); i++) {
			ArrayList<ActivityIncentiveRequirement> lProgramActivityIncentiveRequirements = (ArrayList<ActivityIncentiveRequirement>)
					getProgramActivityIncentiveRequirements(programID, lProgramActivityIncentivesSummary.get(i).getIncentiveOptionID());

			lProgramActivityIncentivesSummary.get(i).setActivityIncentiveRequirements(lProgramActivityIncentiveRequirements);
		}

		return lProgramActivityIncentivesSummary;
	}

	@Override
	public int updateActivityIncentiveDetailDirectly(ActivityIncentiveDetail pActivityIncentiveDetail, String userID) throws DataAccessException {
		Integer activityID = (pActivityIncentiveDetail.getActivityID() != null) ? pActivityIncentiveDetail.getActivityID() : null;
		Integer activityTypeCodeID = (pActivityIncentiveDetail.getActivityTypeCodeID() != null) ? pActivityIncentiveDetail.getActivityTypeCodeID() : null;
		Integer collectionID = (pActivityIncentiveDetail.getCollectionID() != null) ? pActivityIncentiveDetail.getCollectionID() : null;
		Integer incentiveQuantity = (pActivityIncentiveDetail.getIncentiveQuantity() != null) ? pActivityIncentiveDetail.getIncentiveQuantity() : null;
		Integer activityIncentiveID = (pActivityIncentiveDetail.getActivityIncentiveID() != null) ? pActivityIncentiveDetail.getActivityIncentiveID() : null;

		if (activityIncentiveID == null) {
			return this.insertActivityIncentiveDetail(pActivityIncentiveDetail, userID);
		}


		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] {
				activityID,
				activityTypeCodeID,
				collectionID,
				incentiveQuantity,
				userID,
				activityIncentiveID};
		int types[] = new int[] { Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.VARCHAR, Types.INTEGER};

		int rowInserted = template.update(updateActivityIncentiveDetailDirectly, params, types);
		return rowInserted;
	}

	@Override
	public int updateIncentiveParticipant(IncentiveParticipantRelationship lIncentiveParticipantRelationship, String userID) throws DataAccessException {
		Integer activityIncentiveID = (lIncentiveParticipantRelationship.getActivityIncentiveID() != null) ? lIncentiveParticipantRelationship.getActivityIncentiveID() : null;
		deleteIncentiveParticipantByID(activityIncentiveID);
		int rowInserted = this.insertIncentiveParticipant(lIncentiveParticipantRelationship, userID);
		return rowInserted;
	}

	/**
	 * Delete Incentive Participant row by unique identifier
	 * @param activityIncentiveID
	 * @return
	 */
	@Override
	public int deleteIncentiveParticipantByID(Integer activityIncentiveID) throws DataAccessException  {
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] {activityIncentiveID};
		int types[] = new int[] { Types.INTEGER};
		StringBuffer lQuery = new StringBuffer();

		lQuery.append(deleteIncentiveParticipantByID);

		return template.update(lQuery.toString(), params, types);
	}

	/**
	 * Deletes from the Incentive Participants Relationship table.
	 *
	 * @param pBusinessProgramID
	 * @param pIncentiveOptionID
	 * @return
	 * @throws DataAccessException
	 */
	@Override
	public int deleteIncentiveParticipant(Integer pBusinessProgramID, Integer pIncentiveOptionID) throws DataAccessException {
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[]{pBusinessProgramID};
		int types[] = new int[]{Types.INTEGER};
		StringBuffer lQuery = new StringBuffer();

		lQuery.append(deleteIncentiveParticipant);

		if (pIncentiveOptionID != null && pIncentiveOptionID.intValue() > 0) {
			lQuery.append(" AND INCNTV_OPTN_ID = ");
			lQuery.append(pIncentiveOptionID);
		}

		lQuery.append(")");

		return template.update(lQuery.toString(), params, types);
	}

	/**
	 * Deletes from the Activity Incentive table.
	 *
	 * @param pBusinessProgramID
	 * @param pIncentiveOptionID
	 * @return
	 * @throws DataAccessException
	 */
	@Override
	public int deleteActivityIncentiveDetail(Integer pBusinessProgramID, Integer pIncentiveOptionID) throws DataAccessException {
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[]{pBusinessProgramID};
		int types[] = new int[]{Types.INTEGER};
		StringBuffer lQuery = new StringBuffer();

		lQuery.append(deleteActivityIncentiveDetail);

		if (pIncentiveOptionID != null && pIncentiveOptionID.intValue() > 0) {
			lQuery.append(" AND INCNTV_OPTN_ID = ");
			lQuery.append(pIncentiveOptionID);
		}

		return template.update(lQuery.toString(), params, types);
	}

	@Override
	public int deleteIncentiveRequirement(Integer pBusinessProgramID, Integer pIncentiveOptionID) throws DataAccessException {
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[]{pBusinessProgramID};
		int types[] = new int[]{Types.INTEGER};
		StringBuffer lQuery = new StringBuffer();

		lQuery.append(deleteIncentiveRequirement);

		if (pIncentiveOptionID != null && pIncentiveOptionID.intValue() > 0) {
			lQuery.append(" AND INCNTV_OPTN_ID = ");
			lQuery.append(pIncentiveOptionID);
		}

		return template.update(lQuery.toString(), params, types);
	}
}