package com.healthpartners.app.bpm.controller;

import com.healthpartners.app.bpm.common.BPMAdminConstants;
import com.healthpartners.app.bpm.common.BPMAdminUtils;
import com.healthpartners.app.bpm.dto.*;
import com.healthpartners.app.bpm.exception.BPMException;
import com.healthpartners.app.bpm.form.SaveQualificationCheckmarkForm;
import com.healthpartners.app.bpm.iface.BusinessProgramService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collection;

@Controller
public class QualificationCheckmarkController extends BaseController implements Validator {

    private String delimiter = ",";
    protected String ACTION_ADD_ACTIVTY = "addActivity";
    protected String ACTION_REMOVE_ACTIVTY = "removeActivity";
    protected String ACTION_REMOVE_ACTIVTY_TYPE = "removeActivityType";
    protected String ACTION_REMOVE_REQUIREMENT = "removeRequirement";
    protected String ACTION_ADD_REQUIREMENT = "addRequirement";

    private final BusinessProgramService businessProgramService;


    public QualificationCheckmarkController( BusinessProgramService businessProgramService) {
        this.businessProgramService = businessProgramService;
    }

    @GetMapping("/qualificationCheckmark")
    public String load(ModelMap modelMap) throws BPMException {
        modelMap.put("addQualificationCheckmarkForm", new SaveQualificationCheckmarkForm());
        modelMap.put("saveQualificationCheckmarkForm", new SaveQualificationCheckmarkForm());
        try {
            loadCheckmarks(modelMap);

        } catch (Exception e) {
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
            modelMap.put("errorMsg", getStackTrace(e));
        }
        return "qualificationCheckmark";
    }

    @PostMapping(value = "/saveQualificationCheckmark", params = "download")
    public String submitDownload(@ModelAttribute("saveQualificationCheckmarkForm") SaveQualificationCheckmarkForm saveQualificationCheckmarkForm,
                                 HttpServletRequest request,
                                 ModelMap modelMap,
                                 HttpServletResponse response) throws Exception {
        return handleDownload(saveQualificationCheckmarkForm, request, modelMap, response);
    }

    @PostMapping(value = "/addQualificationCheckmark", params = "add")
    public String submitAddQualificationCheckmark(@ModelAttribute("saveQualificationCheckmarkForm") SaveQualificationCheckmarkForm saveQualificationCheckmarkForm, ModelMap modelMap) throws Exception {
        return addQualificationCheckmark(saveQualificationCheckmarkForm, modelMap);
    }

    @GetMapping("/deleteQualificationCheckmark")
    public String deleteQualificationCheckmark(@RequestParam(name="qualificationCheckmarkID") Integer qualificationCheckmarkID, ModelMap modelMap) throws BPMException {
        try {
            deleteQualificationCheckmark(modelMap, qualificationCheckmarkID);

        } catch (Exception e) {
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
            modelMap.put("errorMsg", getStackTrace(e));
        }

        return "redirect: qualificationCheckmark";
    }

    @GetMapping("/editQualificationCheckmark")
    public String loadEdit(@RequestParam(name="qualificationCheckmarkID") Integer qualificationCheckmarkID,
                           @RequestParam(name="actionType") String actionType,
                           ModelMap modelMap) throws BPMException {
        SaveQualificationCheckmarkForm saveQualificationCheckmarkForm = new SaveQualificationCheckmarkForm();
        saveQualificationCheckmarkForm.setActionType(actionType);
        modelMap.put("saveQualificationCheckmarkForm", saveQualificationCheckmarkForm);
        try {
            loadEditQualificationCheckmark(saveQualificationCheckmarkForm, modelMap, qualificationCheckmarkID);

        } catch (Exception e) {
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
            modelMap.put("errorMsg", getStackTrace(e));
        }

        return "editQualificationCheckmark";
    }

    @PostMapping(value = "/saveQualificationCheckmark")
    public String submitSaveQualificationCheckmarkFormActions(@ModelAttribute("saveQualificationCheckmarkForm") SaveQualificationCheckmarkForm saveQualificationCheckmarkForm,
                                                              ModelMap modelMap,
                                                              BindingResult result) throws Exception {

        if(ACTION_ADD_REQUIREMENT.equals(saveQualificationCheckmarkForm.getActionType())) {
            addRequirement(modelMap, saveQualificationCheckmarkForm);

        } else if(ACTION_REMOVE_REQUIREMENT.equals(saveQualificationCheckmarkForm.getActionType())) {
            removeRequirement(modelMap, saveQualificationCheckmarkForm);

        } else if(ACTION_ADD_ACTIVTY.equals(saveQualificationCheckmarkForm.getActionType())) {
            addActivity(modelMap, saveQualificationCheckmarkForm);

        } else if(ACTION_REMOVE_ACTIVTY.equals(saveQualificationCheckmarkForm.getActionType())) {
            removeActivity(modelMap, saveQualificationCheckmarkForm);

        } else if(ACTION_SAVE.equals(saveQualificationCheckmarkForm.getActionType())) {
            validate(saveQualificationCheckmarkForm, result);
            if (!result.hasErrors()) {
                saveQualificationCheckmark(saveQualificationCheckmarkForm, modelMap);
                return "qualificationCheckmark";
            }
            populateRequest(modelMap);
        }

        return "editQualificationCheckmark";
    }

    @PostMapping(value = "/saveQualificationCheckmark", params = "cancel")
    public String submitCancelEditProgramActivityIncentive(@ModelAttribute("saveQualificationCheckmarkForm") SaveQualificationCheckmarkForm saveQualificationCheckmarkForm, RedirectAttributes ra) {
        return "redirect:qualificationCheckmark";
    }

    private void loadCheckmarks(ModelMap modelMap) throws BPMException {
        ArrayList<QualificationCheckmark> lQualificationCheckmarks = (ArrayList<QualificationCheckmark>) businessProgramService.getQualificationCheckmarks();
        ArrayList<QualificationCheckmark> lExpiredQualificationCheckmarks = (ArrayList<QualificationCheckmark>) businessProgramService.getExpiredQualificationCheckmarks();
        modelMap.put("qualificationCheckmarks", lQualificationCheckmarks);
        modelMap.put("expiredQualificationCheckmarks", lExpiredQualificationCheckmarks);
        getUserSession().setQualificationCheckmarks(lQualificationCheckmarks);
        getUserSession().setExpiredQualificationCheckmarks(lExpiredQualificationCheckmarks);
    }

    private void deleteQualificationCheckmark(ModelMap modelMap, Integer qualificationCheckmarkID) throws BPMException {
        businessProgramService.deleteQualificationCheckmark(qualificationCheckmarkID);
        modelMap.put("message", "Qualification Checkmark Deleted Successfully.");
        createActionMessagesOnModel(modelMap, "Qualification Checkmark Deleted Successfully.");
        loadCheckmarks(modelMap);
    }

    private void loadEditQualificationCheckmark(SaveQualificationCheckmarkForm saveQualificationCheckmarkForm, ModelMap modelMap, Integer qualificationCheckmarkID) throws BPMException {
        ArrayList<QualificationCheckmark> lAllQualficationCheckmarks = new ArrayList<>();

        lAllQualficationCheckmarks.addAll(getUserSession().getQualificationCheckmarks());
        lAllQualficationCheckmarks.addAll(getUserSession().getExpiredQualificationCheckmarks());

        QualificationCheckmark lQualificationCheckmark = null;
        for (int i = 0; i < lAllQualficationCheckmarks.size(); i++) {
            lQualificationCheckmark = lAllQualficationCheckmarks.get(i);
            if (lQualificationCheckmark.getQualificationCheckmarkID().equals(qualificationCheckmarkID)) {
                modelMap.put("qualificationCheckmark", lQualificationCheckmark);
                getUserSession().setQualificationCheckmark(lQualificationCheckmark);
                ArrayList<CheckmarkRequirement> lCheckmarkRequirements = (ArrayList<CheckmarkRequirement>) businessProgramService.getCheckmarkRequirements(qualificationCheckmarkID);
                lQualificationCheckmark.setCheckmarkRequirements(lCheckmarkRequirements);
                break;
            }
        }

        if (lQualificationCheckmark != null) {
            saveQualificationCheckmarkForm.setQualificationCheckmarkDesc(lQualificationCheckmark.getQualificationCheckmarkDesc());
        }

        Collection<LookUpValueCode> lActivityTypes = businessProgramService.getActivityTypeCodes();
        modelMap.put("luvActivityTypes", lActivityTypes);
        getUserSession().setActivityTypeCodes((ArrayList<LookUpValueCode>) lActivityTypes);

        ArrayList<Activity> lActivities = (ArrayList<Activity>) businessProgramService.getActivities();
        modelMap.put("activities", lActivities);
        getUserSession().setActivities(lActivities);

        ArrayList<BPMCollection> lBPMCollections = businessProgramService.getAllCollections();
        modelMap.put("collections", lBPMCollections);
        getUserSession().setCollections(lBPMCollections);

        Collection<LookUpValueCode> lQualificationStatusCodes = businessProgramService.getQualificationStatusCodes();
        modelMap.put("qualificationStatusCodes", lQualificationStatusCodes);
        getUserSession().setQualificationStatusCodes((ArrayList<LookUpValueCode>) lQualificationStatusCodes);
    }

    private void saveQualificationCheckmark(SaveQualificationCheckmarkForm saveQualificationCheckmarkForm, ModelMap modelMap) throws BPMException, ParseException {
        QualificationCheckmark lQualificationCheckmark = getUserSession().getQualificationCheckmark();
        //lQualificationCheckmark.setQualificationCheckmarkID(Integer.parseInt(lSaveQualificationCheckmarkForm.getQualificationCheckmarkID()));
        lQualificationCheckmark.setQualificationCheckmarkName(saveQualificationCheckmarkForm.getQualificationCheckmarkName());
        lQualificationCheckmark.setQualificationCheckmarkInfo(saveQualificationCheckmarkForm.getQualificationCheckmarkInfo());
        lQualificationCheckmark.setQualificationCheckmarkDesc(saveQualificationCheckmarkForm.getQualificationCheckmarkDesc());
        lQualificationCheckmark.setEffectiveDateString(saveQualificationCheckmarkForm.getEffectiveDate());
        lQualificationCheckmark.setEndDateString(saveQualificationCheckmarkForm.getEndDate());

        saveRequirements(saveQualificationCheckmarkForm, getUserSession().getQualificationCheckmark());

        // Dates have been validated
        lQualificationCheckmark.setEffectiveDate(new java.sql.Date(getFmt().parse(saveQualificationCheckmarkForm.getEffectiveDate()).getTime()));
        lQualificationCheckmark.setEndDate(new java.sql.Date(getFmt().parse(saveQualificationCheckmarkForm.getEndDate()).getTime()));

        // Save here (update will check for insert or update in the DAO)
        businessProgramService.updateQualificationCheckmark(lQualificationCheckmark, getUserSessionSupport().getAuthenticatedUsername());

        ArrayList<QualificationCheckmark> lQualificationCheckmarks = (ArrayList<QualificationCheckmark>)
                businessProgramService.getQualificationCheckmarks();

        ArrayList<QualificationCheckmark> lExpiredQualificationCheckmarks = (ArrayList<QualificationCheckmark>)
                businessProgramService.getExpiredQualificationCheckmarks();

        getUserSession().reset();
        modelMap.put("qualificationCheckmarks", lQualificationCheckmarks);
        modelMap.put("expiredQualificationCheckmarks", lExpiredQualificationCheckmarks);
        getUserSession().setQualificationCheckmarks(lQualificationCheckmarks);
        getUserSession().setExpiredQualificationCheckmarks(lExpiredQualificationCheckmarks);
        modelMap.put("luvActivityTypes", getUserSession().getActivityTypeCodes());

        clearFormArrays(saveQualificationCheckmarkForm);
    }

    protected void saveRequirements(SaveQualificationCheckmarkForm lSaveQualificationCheckmarkForm, QualificationCheckmark pQualificationCheckmark) {
        String[] lActivityIDs = lSaveQualificationCheckmarkForm.getActivityIDs();
        String[] lActivityTypeCodeIDs = lSaveQualificationCheckmarkForm.getActivityTypeCodeIDs();
        String[] lCollectionIDs = lSaveQualificationCheckmarkForm.getCollectionIDs();

        int lActivityRowCounter = 0;

        for (int i = 0; i < pQualificationCheckmark.getCheckmarkRequirements().size(); i++) {
            // Store the quantities in the corresponding Requirements.
            if (lSaveQualificationCheckmarkForm.getQuantities() != null) {
                pQualificationCheckmark.getCheckmarkRequirements().get(i).setQuantity(Integer.valueOf(lSaveQualificationCheckmarkForm.getQuantities()[i]));
                pQualificationCheckmark.getCheckmarkRequirements().get(i).setQualificationStatusCodeID(Integer.valueOf(lSaveQualificationCheckmarkForm.getQualificationStatusCodeIDs()[i]));

                for (LookUpValueCode lQualificationStatusCode : getUserSession().getQualificationStatusCodes()) {
                    if (pQualificationCheckmark.getCheckmarkRequirements().get(i).getQualificationStatusCodeID().intValue() == lQualificationStatusCode.getLuvId().intValue()) {
                        pQualificationCheckmark.getCheckmarkRequirements().get(i).setQualificationStatusCode(lQualificationStatusCode.getLuvVal());
                        pQualificationCheckmark.getCheckmarkRequirements().get(i).setQualificationStatusDesc(lQualificationStatusCode.getLuvDesc());
                    }
                }
            }

            // Then store the Activity ID, or the Activity Type Code ID in the corresponding
            // Checkmark detail.
            for (int j = 0; j < pQualificationCheckmark.getCheckmarkRequirements().get(i).getCheckmarkDetails().size(); j++) {
                CheckmarkDetail lCheckmarkDetail =
                        pQualificationCheckmark.getCheckmarkRequirements().get(i).getCheckmarkDetails().get(j);

                if (lActivityIDs != null && Integer.parseInt(lActivityIDs[lActivityRowCounter]) > 0) {
                    lCheckmarkDetail.setActivityID(Integer.valueOf(lActivityIDs[lActivityRowCounter]));

                    ArrayList<Activity> lActivities = getUserSession().getActivities();
                    for (int k = 0; k < lActivities.size(); k++) {
                        if (lActivities.get(k).getActivityID().intValue() == lCheckmarkDetail.getActivityID().intValue()) {
                            lCheckmarkDetail.setActivityName(lActivities.get(k).getName());
                            break;
                        }
                    }

                } else if (lActivityTypeCodeIDs != null && Integer.parseInt(lActivityTypeCodeIDs[lActivityRowCounter]) > 0) {
                    lCheckmarkDetail.setActivityTypeCodeID(Integer.valueOf(lActivityTypeCodeIDs[lActivityRowCounter]));

                    ArrayList<LookUpValueCode> lActivityTypeCodes = getUserSession().getActivityTypeCodes();
                    for (int k = 0; k < lActivityTypeCodes.size(); k++) {
                        if (lActivityTypeCodes.get(k).getLuvId().intValue() == lCheckmarkDetail.getActivityTypeCodeID().intValue()) {
                            lCheckmarkDetail.setActivityTypeCode(lActivityTypeCodes.get(k).getLuvDesc());
                            break;
                        }
                    }
                } else if (lCollectionIDs != null && Integer.parseInt(lCollectionIDs[lActivityRowCounter]) > 0) {
                    lCheckmarkDetail.setCollectionID(Integer.valueOf(lCollectionIDs[lActivityRowCounter]));

                    ArrayList<BPMCollection> lCollectionsList = getUserSession().getCollections();
                    for (BPMCollection lBPMCollection : lCollectionsList) {
                        if (lBPMCollection.getCollectionID().intValue() == lCheckmarkDetail.getCollectionID().intValue()) {
                            lCheckmarkDetail.setCollectionName(lBPMCollection.getCollectionName());
                            break;
                        }
                    }
                }

                lActivityRowCounter++;
            }

        }
    }

    private void clearFormArrays(SaveQualificationCheckmarkForm pSaveQualificationCheckmarkForm) {
        pSaveQualificationCheckmarkForm.setActivityIDs(null);
        pSaveQualificationCheckmarkForm.setActivityTypeCodeIDs(null);
        pSaveQualificationCheckmarkForm.setQuantities(null);
        pSaveQualificationCheckmarkForm.setCollectionIDs(null);
        pSaveQualificationCheckmarkForm.setQualificationStatusCodeIDs(null);
    }

    private void populateRequest(ModelMap modelMap) {
        modelMap.put("activities", getUserSession().getActivities());
        modelMap.put("luvActivityTypes", getUserSession().getActivityTypeCodes());
        modelMap.put("qualificationCheckmark", getUserSession().getQualificationCheckmark());
        modelMap.put("collections", getUserSession().getCollections());
        modelMap.put("qualificationStatusCodes", getUserSession().getQualificationStatusCodes());
    }

    private void addRequirement(ModelMap modelMap, SaveQualificationCheckmarkForm form) {
        QualificationCheckmark lQualificationCheckmark = getUserSession().getQualificationCheckmark();

        // Save any potential values that the user may have entered on the form.
        saveRequirements(form, lQualificationCheckmark);

        CheckmarkRequirement lCheckmarkRequirement = new CheckmarkRequirement();
        lCheckmarkRequirement.setQualificationCheckmarkID(lQualificationCheckmark.getQualificationCheckmarkID().intValue());
        lCheckmarkRequirement.setRequirementID(lQualificationCheckmark.getCheckmarkRequirements().size() + 1);
        lCheckmarkRequirement.setQuantity(0);
        lCheckmarkRequirement.setQualificationStatusCodeID(0);
        ArrayList<CheckmarkDetail> lCheckmarkDetails = new ArrayList<CheckmarkDetail>();
        lCheckmarkRequirement.setCheckmarkDetails(lCheckmarkDetails);

        lQualificationCheckmark.getCheckmarkRequirements().add(lCheckmarkRequirement);

        clearFormArrays(form);
        populateRequest(modelMap);
    }

    private void removeRequirement(ModelMap modelMap, SaveQualificationCheckmarkForm form) {
        QualificationCheckmark lQualificationCheckmark = getUserSession().getQualificationCheckmark();

        // Save any potential values that the user may have entered on the form.
        saveRequirements(form, lQualificationCheckmark);

        for (int i = 0; i < lQualificationCheckmark.getCheckmarkRequirements().size(); i++) {
            if (lQualificationCheckmark.getCheckmarkRequirements().get(i).getRequirementID().intValue() ==
                    form.getRequirementID().intValue()) {
                lQualificationCheckmark.getCheckmarkRequirements().get(i).getCheckmarkDetails().clear();
                lQualificationCheckmark.getCheckmarkRequirements().remove(i);
                break;
            }
        }

        clearFormArrays(form);
        populateRequest(modelMap);
    }

    /**
     * Add an activity-activityType line to the Checkmark detail array of the given
     * Requirement ID.
     *
     * @param modelMap
     * @param form
     */
    private void addActivity(ModelMap modelMap, SaveQualificationCheckmarkForm form) {
        QualificationCheckmark lQualificationCheckmark = getUserSession().getQualificationCheckmark();

        // Save any potential values that the user may have entered on the form.
        saveRequirements(form, lQualificationCheckmark);

        for (int i = 0; i < lQualificationCheckmark.getCheckmarkRequirements().size(); i++) {
            if (lQualificationCheckmark.getCheckmarkRequirements().get(i).getRequirementID().intValue() ==
                    form.getRequirementID().intValue()) {
                CheckmarkDetail lCheckmarkDetail = new CheckmarkDetail();
                lCheckmarkDetail.setQualificationCheckmarkID(lQualificationCheckmark.getQualificationCheckmarkID().intValue());
                lCheckmarkDetail.setRequirementID(form.getRequirementID().intValue());
                lCheckmarkDetail.setActivityID(0);
                lCheckmarkDetail.setActivityName("");
                lCheckmarkDetail.setActivityTypeCodeID(0);
                lCheckmarkDetail.setActivityTypeDesc("");
                lCheckmarkDetail.setActivityTypeCode("");
                lCheckmarkDetail.setCollectionID(0);
                lCheckmarkDetail.setCollectionName("");

                lQualificationCheckmark.getCheckmarkRequirements().get(i).getCheckmarkDetails().add(lCheckmarkDetail);

                break;
            }
        }

        clearFormArrays(form);
        populateRequest(modelMap);
    }

    private void removeActivity(ModelMap modelMap, SaveQualificationCheckmarkForm form) {
        QualificationCheckmark lQualificationCheckmark = getUserSession().getQualificationCheckmark();
        int lRowID = form.getRowID().intValue();

        // Save any potential values that the user may have entered on the form.
        saveRequirements(form, lQualificationCheckmark);

        for (int i = 0; i < lQualificationCheckmark.getCheckmarkRequirements().size(); i++) {
            if (lQualificationCheckmark.getCheckmarkRequirements().get(i).getRequirementID().intValue() == form.getRequirementID().intValue()) {
                lQualificationCheckmark.getCheckmarkRequirements().get(i).getCheckmarkDetails().remove(lRowID);
                break;
            }
        }

        clearFormArrays(form);
        populateRequest(modelMap);
    }

    private String addQualificationCheckmark(SaveQualificationCheckmarkForm form, ModelMap modelMap) throws BPMException {
        QualificationCheckmark lQualificationCheckmark = new QualificationCheckmark();
        lQualificationCheckmark.setQualificationCheckmarkID(0);

        ArrayList<CheckmarkRequirement> lCheckmarkRequirements = new ArrayList<CheckmarkRequirement>();
        lQualificationCheckmark.setCheckmarkRequirements(lCheckmarkRequirements);

        Collection<LookUpValueCode> lActivityTypes =  businessProgramService.getActivityTypeCodes();

        ArrayList<Activity> lActivities = (ArrayList<Activity>)businessProgramService.getActivities();

        ArrayList<BPMCollection> lBPMCollections = businessProgramService.getAllCollections();

        ArrayList<LookUpValueCode> lQualificationStatusCodes = (ArrayList<LookUpValueCode>)businessProgramService.getQualificationStatusCodes();

        modelMap.put("qualificationCheckmark", lQualificationCheckmark);
        modelMap.put("luvActivityTypes", lActivityTypes);
        modelMap.put("activities", lActivities);
        modelMap.put("collections", lBPMCollections);
        modelMap.put("qualificationStatusCodes", lQualificationStatusCodes);

        getUserSession().setQualificationCheckmark(lQualificationCheckmark);
        getUserSession().setActivities(lActivities);
        getUserSession().setActivityTypeCodes((ArrayList<LookUpValueCode>)lActivityTypes);
        getUserSession().setCollections(lBPMCollections);
        getUserSession().setQualificationStatusCodes(lQualificationStatusCodes);

        return "editQualificationCheckmark";
    }

    private String handleDownload(SaveQualificationCheckmarkForm form, HttpServletRequest request, ModelMap modelMap, HttpServletResponse response) throws IOException, BPMException {
        request.setAttribute("qualificationCheckmarks", getUserSession().getQualificationCheckmarks());
        response.setHeader("Content-Type", "text/csv");
        response.setHeader("Content-Disposition", "attachment;filename=\"report.csv\"");
        writeCsv(getUserSession().getQualificationCheckmarks(), response.getOutputStream());
        form.setActionType(null);
        return "qualificationCheckmark";
    }

    private void writeCsv(Collection<QualificationCheckmark> lQualificationCheckmarks, OutputStream output) throws IOException {
        BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(output, "UTF-8"));

        formatHeaderNWrite(writer);

        for (QualificationCheckmark lQualificationCheckmark : lQualificationCheckmarks) {
            formatDetailNWrite(writer, lQualificationCheckmark);
        }

        closeFileWriter(writer);
    }

    public void closeFileWriter(BufferedWriter writer) {
        try {
            writer.flush();
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void formatHeaderNWrite(BufferedWriter writer) throws IOException {
        writer.append("Checkmark ID");
        writer.append(delimiter);

        writer.append("Checkmark Name");
        writer.append(delimiter);

        writer.append("Checkmark Information");
        writer.append(delimiter);

        writer.append("Checkmark Description");
        writer.append(delimiter);

        writer.append("Effective Date");
        writer.append(delimiter);

        writer.append("End Date");
        writer.append(delimiter);

        writer.append("Insert Date");
        writer.append(delimiter);

        writer.append("Insert User");
        writer.append(delimiter);

        writer.append("Modify Date");
        writer.append(delimiter);

        writer.append("Modify User");
        writer.append(delimiter);

        writer.newLine();
    }

    private void formatDetailNWrite(BufferedWriter writer, QualificationCheckmark lQualificationCheckmark) throws IOException {
        writer.append(String.valueOf(lQualificationCheckmark.getQualificationCheckmarkID()));
        writer.append(delimiter);

        writer.append(lQualificationCheckmark.getQualificationCheckmarkName().replaceAll(",", "").replaceAll(":", ""));
        writer.append(delimiter);

        writer.append(lQualificationCheckmark.getQualificationCheckmarkInfo().replaceAll(",", "").replaceAll(":", ""));
        writer.append(delimiter);

        writer.append(lQualificationCheckmark.getQualificationCheckmarkDesc().replaceAll(",", "").replaceAll(":", ""));
        writer.append(delimiter);

        if (lQualificationCheckmark.getEffectiveDate() != null) {
            writer.append(BPMAdminUtils.formatDateMMddyyyy(lQualificationCheckmark.getEffectiveDate()));
            writer.append(delimiter);
        } else {
            writer.append("N/A");
            writer.append(delimiter);
        }

        if (lQualificationCheckmark.getEndDate() != null) {
            writer.append(BPMAdminUtils.formatDateMMddyyyy(lQualificationCheckmark.getEndDate()));
            writer.append(delimiter);
        } else {
            writer.append("N/A");
            writer.append(delimiter);
        }

        if (lQualificationCheckmark.getInsertDate() != null) {
            writer.append(BPMAdminUtils.formatDateMMddyyyy(lQualificationCheckmark.getInsertDate()));
            writer.append(delimiter);
        } else {
            writer.append("N/A");
            writer.append(delimiter);
        }

        if (lQualificationCheckmark.getModifyDate() != null) {
            writer.append(BPMAdminUtils.formatDateMMddyyyy(lQualificationCheckmark.getModifyDate()));
            writer.append(delimiter);
        } else if (lQualificationCheckmark.getModifyDate() == null) {
            writer.append("N/A");
            writer.append(delimiter);
        }

        if (lQualificationCheckmark.getInsertUser() != null) {
            writer.append(lQualificationCheckmark.getInsertUser());
            writer.append(delimiter);
        } else {
            writer.append("N/A");
            writer.append(delimiter);
        }

        if (lQualificationCheckmark.getModifyUser() != null) {
            writer.append(lQualificationCheckmark.getModifyUser());
        } else {
            writer.append("N/A");
        }

        writer.newLine();
    }

    @Override
    public boolean supports(Class<?> clazz) {
        return SaveQualificationCheckmarkForm.class.isAssignableFrom(clazz);
    }

    @Override
    public void validate(Object target, Errors errors) {
        SaveQualificationCheckmarkForm form = (SaveQualificationCheckmarkForm) target;
        if (StringUtils.isNotEmpty(form.getQualificationCheckmarkInfo())) {
            getValidationSupport().validateNotSpecialChar("qualificationCheckmarkInfo", form.getQualificationCheckmarkInfo(), errors, new Object[]{"Qualification Checkmark Information"});
        }

        if (StringUtils.isNotEmpty(form.getQualificationCheckmarkDesc())) {
           getValidationSupport().validateNotSpecialChar("qualificationCheckmarkDesc", form.getQualificationCheckmarkDesc(), errors, new Object[]{"Qualification Checkmark Description"});
        }

        getValidationSupport().validateRequiredFieldIsNotEmpty("qualificationCheckmarkName", form.getQualificationCheckmarkName(), errors, new Object[]{"Qualification Checkmark Name"});

        boolean lEffectiveDateValid = getValidationSupport().validateDateFormat("effectiveDate", form.getEffectiveDate(), errors, new Object[]{"Qualification Checkmark Name"});
        boolean lEndDateValid = getValidationSupport().validateDateFormat("endDate", form.getEndDate(), errors, new Object[]{"End Date"});

        if (lEffectiveDateValid && lEndDateValid) {
            getValidationSupport().validateBeforeOrEqual("effectiveDate", form.getEffectiveDate(), form.getEndDate(), "endDate", errors, new Object[]{"End Date"});
        }

        if (form.getActivityIDs() != null) {
            for (int i = 0; i < form.getActivityIDs().length; i++) {
                if (Integer.parseInt(form.getActivityIDs()[i]) == 0 && Integer.parseInt(form.getActivityTypeCodeIDs()[i]) == 0 && Integer.parseInt(form.getCollectionIDs()[i]) == 0) {
                    getValidationSupport().addValidationFailureMessage("activityTypeCodeIDs["+i+"]", errors, "errors.noselect", new Object[]{"Activity, Activity Type, or Collection"});
                }

                if (form.getActivityTypeCodeIDs() != null) {
                    if (form.getActivityIDs()[i] != null && form.getActivityTypeCodeIDs() != null) {
                        if (Integer.parseInt(form.getActivityIDs()[i]) > 0 && Integer.parseInt(form.getActivityTypeCodeIDs()[i]) > 0) {
                            getValidationSupport().addValidationFailureMessage("activityTypeCodeIDs["+i+"]", errors, "errors.cannotSelectActivityAndType", null);
                        }
                    }
                }
            }
        }

        if (form.getActivityIDs() == null && form.getActivityTypeCodeIDs() == null && form.getCollectionIDs() == null) {
            if (form.getQuantities() != null) {
                getValidationSupport().addValidationFailureMessage("quantities[0]", errors, "errors.noselect", new Object[]{"Activity, Activity Type, or Collection"});
            } else {
                getValidationSupport().addValidationFailureMessage("endDate", errors, "errors.noselect", new Object[]{"Activity, Activity Type, or Collection"});
            }
        }

        if (form.getQualificationStatusCodeIDs() != null) {
            for (int j = 0; j < form.getQualificationStatusCodeIDs().length; j++) {
                if (form.getQualificationStatusCodeIDs()[j] != null && Integer.parseInt(form.getQualificationStatusCodeIDs()[j]) == 0) {
                    getValidationSupport().addValidationFailureMessage("qualificationStatusCodeIDs["+j+"]", errors, "errors.notselected", new Object[]{"Qualification Status"});
                }
            }
        }

        if (form.getQuantities() != null) {
            for (int j = 0; j < form.getQuantities().length; j++) {
                if (Integer.parseInt(form.getQuantities()[j]) == 0) {
                    getValidationSupport().addValidationFailureMessage("quantities["+j+"]", errors, "errors.notselected", new Object[]{"Quantity"});
                }
            }
        }
    }
}
