package com.healthpartners.app.bpm.controller;

import com.healthpartners.app.bpm.common.BPMAdminConstants;
import com.healthpartners.app.bpm.dto.*;
import com.healthpartners.app.bpm.exception.BPMException;
import com.healthpartners.app.bpm.form.EditProgramForm;
import com.healthpartners.app.bpm.form.SaveProgramActivitySiteForm;
import com.healthpartners.app.bpm.form.SaveProgramContributionGridForm;
import com.healthpartners.app.bpm.iface.BusinessProgramService;
import jakarta.servlet.http.HttpServletRequest;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.view.RedirectView;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;

import static org.apache.commons.lang.exception.ExceptionUtils.getStackTrace;

@Controller
public class ProgramContributionGridController extends BaseController implements Validator {

    private static final String ACTION_SAVE = "save";
    private static final String ACTION_SAVE_TO_ALL_SITES = "saveToAllSites";
    private static final String ACTION_SAVE_TO_SELECTED = "saveToSelected";
    private static final String ACTION_SELECT_SITES = "selectSites";
    private static final String ACTION_ADD_BENEFIT_CONTRACT_TYPE = "addBenefitContractType";
    private static final String ACTION_REMOVE_BENEFIT_CONTRACT_TYPE = "removeBenefitContractType";
    private static final String ACTION_ADD_RELATIONSHIPS = "addRelationships";

    protected final Log logger = LogFactory.getLog(getClass());
    private final BusinessProgramService businessProgramService;


    public ProgramContributionGridController(BusinessProgramService businessProgramService) {
        this.businessProgramService = businessProgramService;
    }

    @GetMapping("/editProgramContributionGrid")
    public String loadProgramContributionGrid(ModelMap modelMap,
                                               @RequestParam(name = "actionType") String actionType,
                                               @RequestParam(name = "programID") Integer programID,
                                               @RequestParam(name = "incentiveOptionID") Integer incentiveOptionID,
                                               @RequestParam(name = "programIncentiveOptionID") Integer programIncentiveOptionID) throws Exception {
        try {
            SaveProgramContributionGridForm form = new SaveProgramContributionGridForm();
            form.setActionType(actionType);
            form.setProgramID(programID);
            form.setIncentiveOptionID(incentiveOptionID);
            form.setProgramIncentiveOptionID(programIncentiveOptionID);

            loadInitial(form, modelMap);

        } catch (Exception e) {
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
            createErrorMessageOnModel(modelMap, getStackTrace(e));
        }

        return "editProgramContributionGrid";
    }

    @PostMapping(value="/saveProgramContributionGrid", params="cancel")
    public RedirectView submitCancelEdit(@ModelAttribute("saveProgramContributionGridForm") SaveProgramContributionGridForm form, RedirectAttributes ra) throws BPMException {
        try {
            EditProgramForm editProgramForm = new EditProgramForm();
            editProgramForm.setGroupNo(getUserSession().getGroupNo());
            editProgramForm.setProgramID(form.getProgramID());
            ra.addFlashAttribute("editProgramForm", editProgramForm);
            ra.addFlashAttribute("groupNumber", getUserSession().getGroupNo());
            ra.addFlashAttribute("actionType", "editIncentives");
        } catch (Exception e) {
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
        }

        String url = "editProgram";
        return new RedirectView(url);
    }

    @PostMapping(value = "/saveProgramContributionGrid")
    public String submitProgramActivityIncentive(@ModelAttribute("saveProgramContributionGridForm") SaveProgramContributionGridForm form, ModelMap modelMap, BindingResult result, HttpServletRequest request, RedirectAttributes ra) {
        try {
            if (ACTION_ADD_BENEFIT_CONTRACT_TYPE.equals(form.getActionType())) {
                addBenefitContractType(form, modelMap, result);
                return "editProgramContributionGrid";

            } else if (ACTION_REMOVE_BENEFIT_CONTRACT_TYPE.equals(form.getActionType())) {
                assignRelationshipAtributesToProgramContributionGrid(form);
                removeAssignedProgramBenefitContractTypes(form, modelMap);
                return "editProgramContributionGrid";

            } else if (ACTION_ADD_RELATIONSHIPS.equals(form.getActionType())) {
                addAssignedRelationships(form, modelMap);
                return "editProgramContributionGrid";

            } else if (ACTION_SELECT_SITES.equals(form.getActionType())) {
                selectSites(modelMap);
                return "programActivitySites";

            } else if (ACTION_SAVE.equals(form.getActionType()) || ACTION_SAVE_TO_ALL_SITES.equals(form.getActionType()) || ACTION_SAVE_TO_SELECTED.equals(form.getActionType())) {
                validate(form, result);
                if (result.hasErrors()) {
                    clearFormArrays(form);
                    populateRequest(modelMap);
                    return "editProgramContributionGrid";
                } else {
                    return performSave(modelMap, ra, form, result);
                }
            }
        } catch (Exception e) {
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
            createErrorMessageOnModel(modelMap, getStackTrace(e));
        }

        // Add package also forwards to the same jsp.
        return "editProgramActivityIncentive";
    }

    private void loadInitial(SaveProgramContributionGridForm form, ModelMap modelMap) throws Exception {
        if (form.getIncentiveOptionID() == null) {
            form.setIncentiveOptionID(-1);
        }

        BusinessProgram businessProgram = getUserSession().getBusinessProgram();
        if (businessProgram == null) {
            businessProgram = businessProgramService.getBusinessProgram(form.getProgramID(), false);
        }

        ArrayList<ProgramContributionGrid> programContributionGrids = new ArrayList<>();

        ArrayList<ProgramIncentiveOption> programIncentiveOptions = (ArrayList<ProgramIncentiveOption>) businessProgramService.getProgramIncentiveOptions(form.getProgramID());
        // In the list of program incentive options, find the one that was selected.
        for (int i = 0; i < programIncentiveOptions.size(); i++) {
            if (programIncentiveOptions.get(i).getIncentiveOption().getIncentiveOptionID().intValue() == form.getIncentiveOptionID()) {
                Integer programIncentiveOptionID = programIncentiveOptions.get(i).getProgramIncentiveOptionID();
                programContributionGrids = (ArrayList<ProgramContributionGrid>) businessProgramService.getProgramContributionGrids(programIncentiveOptionID);
                programIncentiveOptions.get(i).setProgramContributionGrids(programContributionGrids);
                getUserSession().setProgramIncentiveOption(programIncentiveOptions.get(i));
                break;
            }
        }

        if (programContributionGrids == null) {
            programContributionGrids = (ArrayList<ProgramContributionGrid>) businessProgramService.getProgramContributionGrids(getUserSession().getProgramIncentiveOption().getProgramIncentiveOptionID());
        }

        if (getUserSession().getRemovedProgramContributionGrids() != null) {
            getUserSession().getRemovedProgramContributionGrids().clear();
        }

        ArrayList<LookUpValueCode> luvBenefitContractTypes = (ArrayList<LookUpValueCode>)businessProgramService.getBenefitContractTypes();

        ArrayList<ContributionGridBenefitContractType> lContributionGridBenefitContractTypes = getContributionGridBenefitContractTypes(luvBenefitContractTypes);
        if (lContributionGridBenefitContractTypes != null && lContributionGridBenefitContractTypes.size() > 0) {
            //populate benefit contract type dropdown based on benefit contract types.
            modelMap.put("contributionGridBenefitContractTypes", lContributionGridBenefitContractTypes);
            getUserSession().setContributionGridBenefitContractTypes(lContributionGridBenefitContractTypes);
            loadRelationshipHashmap(modelMap, lContributionGridBenefitContractTypes);
        }

        ProgramContributionGrid programContributionGrid = new ProgramContributionGrid();
        if(form.getActionType().equals(BPMAdminConstants.BPM_ADMIN_ACTION_ADD)) {
            programContributionGrid.setProgramIncentiveOptionID(form.getProgramIncentiveOptionID());
            programContributionGrid.setBenefitContractTypeID(0);
            programContributionGrid.setRelationshipCodeID(0);

        } else {
            programContributionGrid = programContributionGrids.get(0);
            if (programContributionGrid.getBenefitContractTypeID().equals(0)) {
                programContributionGrid.setBenefitContractTypeDesc("Select...");
            }
            if (programContributionGrid.getRelationshipCodeID().equals(0)) {
                programContributionGrid.setRelationshipCode("Select...");
            }
            boolean isAllowRelationshipSelfOnly = false;
            if (getUserSession().getProgramIncentiveOption().getIncentedStatusTypeCode().equals(BPMAdminConstants.BPM_INCENTED_STATUS_TYPE_CONTRACT_BASED)) {
                isAllowRelationshipSelfOnly = true;
            }
        }

        modelMap.put("saveProgramContributionGridForm", form);
        modelMap.put("contributionGridBenefitContractTypes", getUserSession().getContributionGridBenefitContractTypes());
        HashMap<Integer, String> benefitContractTypeHashMap = createBenefitContractTypeDescLookup(lContributionGridBenefitContractTypes);
        getUserSession().setBenefitContractTypeHashMap(benefitContractTypeHashMap);
        modelMap.put("businessProgram", businessProgram);
        modelMap.put("programIncentiveOption", getUserSession().getProgramIncentiveOption());
        modelMap.put("benefitContractTypeRelationshipHashMap", getUserSession().getBenefitContractTypeRelationshipGridHashMap());
        modelMap.put("luvBenefitContractTypes", luvBenefitContractTypes);
        getUserSession().setProgramContributionGrids(programContributionGrids);
        getUserSession().setProgramContributionGrid(programContributionGrid);
        getUserSession().setBenefitContractTypes(luvBenefitContractTypes);

        if (programContributionGrids.size() > 0) {
            getUserSession().setProgramContributionGridExists(true);
        } else {
            getUserSession().setProgramContributionGridExists(false);
        }

        modelMap.put("isProgramContributionRowDisabled", getUserSession().isProgramContributionGridExists());

        // Attribute that is used to determine whether or not to display the
        // Save To Selected Sites button.
        modelMap.put(BPMAdminConstants.BPM_ADMIN_SITES_SELECTED, "false");
    }

    private void loadRelationshipHashmap(ModelMap modelMap, ArrayList<ContributionGridBenefitContractType> lContributionGridBenefitContractTypes) throws Exception {
        if (lContributionGridBenefitContractTypes != null && lContributionGridBenefitContractTypes.size() > 0) {
            getUserSession().setContributionGridBenefitContractTypes(lContributionGridBenefitContractTypes);
            HashMap<Integer, Collection<ContributionGridBenefitContractTypeRelationship>> benefitContractTypeRelationshipHashMap = createRelationshipLookup(lContributionGridBenefitContractTypes);
            modelMap.put("benefitContractTypeRelationshipHashMap", benefitContractTypeRelationshipHashMap);
            getUserSession().setBenefitContractTypeRelationshipGridHashMap(benefitContractTypeRelationshipHashMap);
        }
    }

    private HashMap<Integer, String> createBenefitContractTypeDescLookup(ArrayList<ContributionGridBenefitContractType> lContributionGridBenefitContractTypes) {
        HashMap<Integer, String> benefitContractTypeHashMap = new HashMap<>();
        for (ContributionGridBenefitContractType lContributionGridBenefitContractType : lContributionGridBenefitContractTypes) {
            Collection<ContributionGridBenefitContractTypeRelationship> lContributionGridBenefitContractTypeRelationships = lContributionGridBenefitContractType.getContributionGridBenefitContractTypeRelationships();
            benefitContractTypeHashMap.put(lContributionGridBenefitContractType.getBenefitContractTypeID(), lContributionGridBenefitContractType.getLuvDesc());
        }

        return benefitContractTypeHashMap;
    }

    private HashMap<Integer, Collection<ContributionGridBenefitContractTypeRelationship>> createRelationshipLookup(ArrayList<ContributionGridBenefitContractType> lContributionGridBenefitContractTypes) {
        HashMap<Integer, Collection<ContributionGridBenefitContractTypeRelationship>> benefitContractTypeRelationshipHashMap = new HashMap<Integer, Collection<ContributionGridBenefitContractTypeRelationship>>();
        for (ContributionGridBenefitContractType lContributionGridBenefitContractType : lContributionGridBenefitContractTypes) {
            Collection<ContributionGridBenefitContractTypeRelationship> lContributionGridBenefitContractTypeRelationships = lContributionGridBenefitContractType.getContributionGridBenefitContractTypeRelationships();
            benefitContractTypeRelationshipHashMap.put(lContributionGridBenefitContractType.getBenefitContractTypeID(), lContributionGridBenefitContractTypeRelationships);
        }

        return benefitContractTypeRelationshipHashMap;
    }

    private ArrayList<ContributionGridBenefitContractType> getContributionGridBenefitContractTypes(ArrayList<LookUpValueCode> luvBenefitContractTypes) throws Exception {
        ArrayList<ContributionGridBenefitContractType> lContributionGridBenefitContractTypes = new ArrayList<ContributionGridBenefitContractType>();
        Collection<ContributionGridBenefitContractTypeRelationship> lContributionGridBenefitContractTypeRelationships = null;

        try {
            for (LookUpValueCode luvBenefitContractType : luvBenefitContractTypes) {
                ContributionGridBenefitContractType lContributionGridBenefitContractType = new ContributionGridBenefitContractType();
                Integer benefitContractTypeID = luvBenefitContractType.getLuvId();
                String luvDesc = luvBenefitContractType.getLuvDesc();
                lContributionGridBenefitContractTypeRelationships = businessProgramService.getContributionGridBenefitContractTypeRelationships(benefitContractTypeID);
                lContributionGridBenefitContractType.setBenefitContractTypeID(benefitContractTypeID);
                lContributionGridBenefitContractType.setLuvDesc(luvDesc);
                lContributionGridBenefitContractType.setContributionGridBenefitContractTypeRelationships(lContributionGridBenefitContractTypeRelationships);
                lContributionGridBenefitContractTypes.add(lContributionGridBenefitContractType);
            }
        } catch (Exception e) {
            logger.error("Failed to get assigned contribution tier benefit contract types when calling businessProgramService.getAssignedContributionTierBenefitContractTypes.");
            throw e;
        }

        return lContributionGridBenefitContractTypes;
    }

    private void addBenefitContractType(SaveProgramContributionGridForm form, ModelMap modelMap, Errors errors) throws BPMException {
        //if removing benefit contract types then don't allow any new benefit contract types
        if (getUserSession().getRemovedProgramContributionGrids() != null && getUserSession().getRemovedProgramContributionGrids().size() > 0) {
            getValidationSupport().addValidationFailureMessage("programBenefitContractTypeIDs[0]", errors, "errors.removeBenefitContractTypeError", new Object[]{"Remove benefit contract type error"});
            retainValuesEntered(form);
            clearFormArrays(form);
            populateRequest(modelMap);
        } else {
            if (getUserSession().getProgramContributionGrids() == null || getUserSession().getProgramContributionGrids().size() == 0) {
                boolean isAllowRelationshipSelfOnly = false;
                if (getUserSession().getProgramIncentiveOption().getIncentedStatusTypeCode().equals(BPMAdminConstants.BPM_INCENTED_STATUS_TYPE_CONTRACT_BASED)) {
                    isAllowRelationshipSelfOnly = true;
                }
                ArrayList<ProgramContributionGrid> lProgramContributionGrids = (ArrayList<ProgramContributionGrid>) businessProgramService.getProgramContributionGrids(form.getProgramIncentiveOptionID());
                getUserSession().setProgramContributionGrids(lProgramContributionGrids);
            }
            addAssignedBenefitContractType(form, modelMap);
        }
    }

    private void addAssignedBenefitContractType(SaveProgramContributionGridForm form, ModelMap modelMap) {
        ProgramIncentiveOption lProgramIncentiveOption = getUserSession().getProgramIncentiveOption();
        SaveProgramContributionGridForm lSaveProgramContributionGridForm = (SaveProgramContributionGridForm) form;


        // When adding the first requirement
        if (lProgramIncentiveOption.getProgramContributionGrids() == null) {
            ArrayList<ProgramContributionGrid> lProgramContributionGrids = new ArrayList<ProgramContributionGrid>();
            lProgramIncentiveOption.setProgramContributionGrids(lProgramContributionGrids);
        }

        HashMap<Integer, Collection<ContributionGridBenefitContractTypeRelationship>> benefitContractTypeRelationshipHashMap = new HashMap<Integer, Collection<ContributionGridBenefitContractTypeRelationship>>();
        if (getUserSession().getBenefitContractTypeRelationshipGridHashMap() != null && getUserSession().getBenefitContractTypeRelationshipGridHashMap().size() > 0) {
            benefitContractTypeRelationshipHashMap = getUserSession().getBenefitContractTypeRelationshipGridHashMap();
        }

        //Transfer what was entered from benefit contract contribution amount row from screen into program contribution grid object.
        String[] programBenefitContractTypeIDs = lSaveProgramContributionGridForm.getProgramBenefitContractTypeIDs();
        Collection<ProgramContributionGrid> lProgramContributionGrids = lProgramIncentiveOption.getProgramContributionGrids();

        if (programBenefitContractTypeIDs != null) {
            for (ProgramContributionGrid lProgramContributionGrid : lProgramContributionGrids) {
                for (int i = 0; i < programBenefitContractTypeIDs.length; i++) {
                    if ((i + 1) == lProgramContributionGrid.getRowID() && Integer.valueOf(programBenefitContractTypeIDs[i]).equals(lProgramContributionGrid.getBenefitContractTypeID())) {
                        Integer relationshipCodeID = Integer.valueOf(lSaveProgramContributionGridForm.getRelationshipIDs()[i]);
                        lProgramContributionGrid.setRelationshipCodeID(relationshipCodeID);
                        String relationshipDesc = findRelationshipDesc(lProgramContributionGrid.getBenefitContractTypeID(), relationshipCodeID, benefitContractTypeRelationshipHashMap);
                        lProgramContributionGrid.setRelationshipCode(relationshipDesc);
                        lProgramContributionGrid.setContributionAmount(Integer.valueOf(lSaveProgramContributionGridForm.getContributionAmounts()[i]));
                    }
                }
            }
        }

        ProgramContributionGrid lProgramContributionGrid = new ProgramContributionGrid();

        lProgramContributionGrid.setBenefitContractTypeID(0);
        lProgramContributionGrid.setContributionAmount(0);
        lProgramContributionGrid.setRelationshipCodeID(0);
        lProgramContributionGrid.setRowID(lProgramIncentiveOption.getProgramContributionGrids().size() + 1);

        lProgramIncentiveOption.getProgramContributionGrids().add(lProgramContributionGrid);

        ArrayList<ContributionGridBenefitContractTypeRelationship> lNewContributionGridBenefitContractTypeRelationships = new ArrayList<>();
        ContributionGridBenefitContractTypeRelationship lNewContributionGridBenefitContractTypeRelationship = new ContributionGridBenefitContractTypeRelationship();
        lNewContributionGridBenefitContractTypeRelationship.setBenefitContractTypeID(0);
        lNewContributionGridBenefitContractTypeRelationship.setRelationshipCode(0);
        lNewContributionGridBenefitContractTypeRelationship.setRelationshipDesc("Select");
        lNewContributionGridBenefitContractTypeRelationships.add(lNewContributionGridBenefitContractTypeRelationship);
        benefitContractTypeRelationshipHashMap.put(0, lNewContributionGridBenefitContractTypeRelationships);
        getUserSession().setBenefitContractTypeRelationshipGridHashMap(benefitContractTypeRelationshipHashMap);
        clearFormArrays(lSaveProgramContributionGridForm);
        populateRequest(modelMap);
    }

    private void populateRequest(ModelMap modelMap) {
        modelMap.put("businessProgram", getUserSession().getBusinessProgram());
        //modelMap.put("programContributionGrids", sessionBean.getProgramIncentiveOption().getProgramContributionGrids());
        modelMap.put("programIncentiveOption", getUserSession().getProgramIncentiveOption());
        modelMap.put ("programCheckmarks", getUserSession().getProgramCheckmarks());
        modelMap.put("contributionGridBenefitContractTypes", getUserSession().getContributionGridBenefitContractTypes());

        modelMap.put("eligibleActivities", getUserSession().getEligibleActivities());
        modelMap.put("luvActivityTypes", getUserSession().getActivityTypeCodes());
        modelMap.put("benefitContractTypeRelationshipHashMap", getUserSession().getBenefitContractTypeRelationshipGridHashMap());

        modelMap.put("activities", getUserSession().getActivities());
        modelMap.put("luvActivityIncentiveTypes", getUserSession().getActivityIncentiveTypeCodes());

        modelMap.put("personRelationshipCodes", getUserSession().getPersonRelationshipCodes());
        modelMap.put("luvActivityIncentiveStatuses", getUserSession().getActivityIncentiveStatusCodes());
        modelMap.put("incentiveOptions", getUserSession().getActiveIncentiveOptions());

        modelMap.put("incentiveStatuses", getUserSession().getIncentiveOptionStatuses());
        modelMap.put("incentiveFulfillTypes", getUserSession().getIncentiveFulfillTypes());
        modelMap.put("programActivityIncentivesSummary", getUserSession().getProgramActivityIncentivesSummary());
        modelMap.put("collections", getUserSession().getCollections());

        modelMap.put("incentiveReportNameTypes", getUserSession().getIncentiveReportNameTypes());
        modelMap.put("incentedStatusCodes", getUserSession().getIncentedStatusCodes());
        modelMap.put("luvIdSendToMembership", getUserSession().getLuvIdSendToMembership());
        modelMap.put("luvIdSendToPremiumBilling", getUserSession().getLuvIdSendToPremiumBilling());
        modelMap.put("luvIdSendToIntelispend", getUserSession().getLuvIdSendToIntelispend());
        modelMap.put("luvIdSendToCDHP", getUserSession().getLuvIdSendToCDHP());
        modelMap.put("incentiveEnrollmentRuleCodes", getUserSession().getIncentiveEnrollmentRuleCodes());
        modelMap.put("luvBatchRunFrequencyTypes", getUserSession().getRewardRunFrequencyTypes());
        modelMap.put("incentiveOptionRewardCardTypes", getUserSession().getIncentiveOptionRewardCardTypes());
        modelMap.put("packageRuleGroups", getUserSession().getIncentivePackageRuleGroupTypes());
        modelMap.put("luvDeliveryInfoTypes", getUserSession().getDeliveryInfoTypes());

        modelMap.put("unitCodeTypes", getUserSession().getUnitCodeTypes());

        //modelMap.put("programContributionGrid", sessionBean.getProgramContributionGrid());

        modelMap.put("isProgramContributionRowDisabled", getUserSession().isProgramContributionGridExists());
    }

    private String findRelationshipDesc(Integer benefitContractTypeID, Integer targetRelationshipCode, HashMap<Integer, Collection<ContributionGridBenefitContractTypeRelationship>> benefitContractTypeRelationshipHashMap) {
        String relationshipDesc = "Select...";
        Collection<ContributionGridBenefitContractTypeRelationship> lContributionGridBenefitContractTypeRelationships = benefitContractTypeRelationshipHashMap.get(benefitContractTypeID);

        if (lContributionGridBenefitContractTypeRelationships != null) {
            for (ContributionGridBenefitContractTypeRelationship lContributionGridBenefitContractTypeRelationship : lContributionGridBenefitContractTypeRelationships) {

                if (targetRelationshipCode.equals(lContributionGridBenefitContractTypeRelationship.getRelationshipCode())) {
                    relationshipDesc = lContributionGridBenefitContractTypeRelationship.getRelationshipDesc();
                }
            }
        }

        return relationshipDesc;
    }

    private void clearFormArrays(SaveProgramContributionGridForm pSaveProgramContributionGridForm) {
        pSaveProgramContributionGridForm.setProgramBenefitContractTypeIDs(null);
        pSaveProgramContributionGridForm.setRelationshipIDs(null);
        pSaveProgramContributionGridForm.setContributionAmounts(null);
        pSaveProgramContributionGridForm.setRowID(null);
    }

    private void retainValuesEntered(SaveProgramContributionGridForm lSaveProgramContributionGridForm) {
        ProgramIncentiveOption lProgramIncentiveOption = getUserSession().getProgramIncentiveOption();
        ArrayList<ProgramContributionGrid> lProgramContributionGrids = lProgramIncentiveOption.getProgramContributionGrids();
        Collection<ContributionGridBenefitContractType> lContributionGridBenefitContractTypes = getUserSession().getContributionGridBenefitContractTypes();

        String[] programBenefitContractTypeIDs = lSaveProgramContributionGridForm.getProgramBenefitContractTypeIDs();
        String[] contributionAmounts = lSaveProgramContributionGridForm.getContributionAmounts();
        String[] relationshipIDs = lSaveProgramContributionGridForm.getRelationshipIDs();


        if (programBenefitContractTypeIDs != null) {
            for ( int i = 0; i < programBenefitContractTypeIDs.length; i++) {
                Integer benefitContractTypeID = Integer.valueOf(programBenefitContractTypeIDs[i]);
                Integer relationshipCodeID = Integer.valueOf(relationshipIDs[i]);
                Integer contributionAmount = Integer.valueOf(contributionAmounts[i]);

                ProgramContributionGrid lProgramContributionGrid = getProgramContributionGrid(benefitContractTypeID, lProgramContributionGrids);

                if (lProgramContributionGrid != null) {
                    String benefitContractTypeDesc = getBenefitContractTypeDesc(benefitContractTypeID, lContributionGridBenefitContractTypes);
                    lProgramContributionGrid.setBenefitContractTypeDesc(benefitContractTypeDesc);
                    lProgramContributionGrid.setRelationshipCodeID(relationshipCodeID);
                    String relationshipDesc = findRelationshipDesc(benefitContractTypeID, relationshipCodeID, getUserSession().getBenefitContractTypeRelationshipGridHashMap());
                    lProgramContributionGrid.setRelationshipCode(relationshipDesc);
                    lProgramContributionGrid.setContributionAmount(contributionAmount);
                } else {
                    ProgramContributionGrid lProgramContributionGridNew = new ProgramContributionGrid();
                    lProgramContributionGridNew.setBenefitContractTypeID(benefitContractTypeID);
                    lProgramContributionGridNew.setProgramIncentiveOptionID(Integer.valueOf(lSaveProgramContributionGridForm.getProgramIncentiveOptionID()));
                    String benefitContractTypeDesc = getBenefitContractTypeDesc(benefitContractTypeID, lContributionGridBenefitContractTypes);
                    lProgramContributionGridNew.setBenefitContractTypeDesc(benefitContractTypeDesc);

                    lProgramContributionGridNew.setRelationshipCodeID(relationshipCodeID);
                    String relationshipDesc = findRelationshipDesc(benefitContractTypeID, relationshipCodeID, getUserSession().getBenefitContractTypeRelationshipGridHashMap());
                    lProgramContributionGridNew.setRelationshipCode(relationshipDesc);
                    lProgramContributionGridNew.setContributionAmount(contributionAmount);
                    lProgramContributionGrids.add(lProgramContributionGridNew);
                }
            }
        }

        if (lProgramContributionGrids.size() > 0) {
            lProgramIncentiveOption.setProgramContributionGrids(lProgramContributionGrids);
        }
    }

    private ProgramContributionGrid getProgramContributionGrid(Integer benefitContractTypeID, ArrayList<ProgramContributionGrid> lProgramContributionGrids) {
        ProgramContributionGrid lProgramContributionGridResult = null;
        for (ProgramContributionGrid lProgramContributionGrid : lProgramContributionGrids) {
            if (lProgramContributionGrid.getBenefitContractTypeID().equals(benefitContractTypeID)) {
                lProgramContributionGridResult = lProgramContributionGrid;
                break;
            }

        }

        return lProgramContributionGridResult;
    }

    private String getBenefitContractTypeDesc(Integer programBenefitContractTypeID, Collection<ContributionGridBenefitContractType> lContributionGridBenefitContractTypes) {
        String benefitContractTypeDesc = "not found";
        for (ContributionGridBenefitContractType lContributionGridBenefitContractType : lContributionGridBenefitContractTypes) {
            if (programBenefitContractTypeID.equals(lContributionGridBenefitContractType.getBenefitContractTypeID())) {
                benefitContractTypeDesc = lContributionGridBenefitContractType.getLuvDesc();
                break;
            }
        }

        return benefitContractTypeDesc;

    }

    private void assignRelationshipAtributesToProgramContributionGrid(SaveProgramContributionGridForm lSaveProgramContributionGridForm) {

        Collection<ContributionGridBenefitContractType> lContributionGridBenefitContractTypes = getUserSession().getContributionGridBenefitContractTypes();

        ProgramIncentiveOption lProgramIncentiveOption = getUserSession().getProgramIncentiveOption();
        Collection<ProgramContributionGrid> lProgramContributionGrids = lProgramIncentiveOption.getProgramContributionGrids();

        String[] programBenefitContractTypeIDs = lSaveProgramContributionGridForm.getProgramBenefitContractTypeIDs();
        String[] contributionAmounts = lSaveProgramContributionGridForm.getContributionAmounts();
        String[] relationshipIDs = lSaveProgramContributionGridForm.getRelationshipIDs();

        if (getUserSession().getRemovedProgramContributionGrids() == null || getUserSession().getRemovedProgramContributionGrids().isEmpty()) {
            if (programBenefitContractTypeIDs != null) {
                for (int i = 0; i < programBenefitContractTypeIDs.length; i++) {
                    Integer chosenBenefitContractTypeID = Integer.valueOf(programBenefitContractTypeIDs[i]);
                    Integer relationshipCodeID = Integer.valueOf(relationshipIDs[i]);
                    Integer contributionAmount = Integer.valueOf(contributionAmounts[i]);
                    for (ContributionGridBenefitContractType lContributionGridBenefitContractType : lContributionGridBenefitContractTypes) {
                        if (chosenBenefitContractTypeID.equals(lContributionGridBenefitContractType.getBenefitContractTypeID())) {


                            for (ProgramContributionGrid lProgramContributionGrid : lProgramContributionGrids) {
                                if (i + 1 == lProgramContributionGrid.getRowID().intValue()) {
                                    if (lProgramContributionGrid.getProgramIncentiveOptionID() == null) {
                                        lProgramContributionGrid.setProgramIncentiveOptionID(Integer.valueOf(lSaveProgramContributionGridForm.getProgramIncentiveOptionID()));
                                    }
                                    lProgramContributionGrid.setBenefitContractTypeID(chosenBenefitContractTypeID);
                                    String benefitContractTypeDesc = findBenefitContractTypeDesc(chosenBenefitContractTypeID, getUserSession().getBenefitContractTypeHashMap());
                                    lProgramContributionGrid.setBenefitContractTypeDesc(benefitContractTypeDesc);
                                    lProgramContributionGrid.setRelationshipCodeID(relationshipCodeID);
                                    String relationshipDesc = findRelationshipDesc(chosenBenefitContractTypeID, relationshipCodeID, getUserSession().getBenefitContractTypeRelationshipGridHashMap());
                                    lProgramContributionGrid.setRelationshipCode(relationshipDesc);
                                    lProgramContributionGrid.setContributionAmount(contributionAmount);

                                }
                            }
                        }
                    }
                }
            }
        }
    }

    private void removeAssignedProgramBenefitContractTypes(SaveProgramContributionGridForm form, ModelMap modelMap) {
        Integer rowID = Integer.parseInt(form.getRowID());

        ArrayList<ProgramContributionGrid> lProgramContributionGrids = getUserSession().getProgramIncentiveOption().getProgramContributionGrids();

        ArrayList<ProgramContributionGrid> lRemovedProgramContributionGrids = new ArrayList<>();
        if (getUserSession().getRemovedProgramContributionGrids() != null) {
            lRemovedProgramContributionGrids = getUserSession().getRemovedProgramContributionGrids();
        }

        if (lProgramContributionGrids != null) {
            // Find the Benefit Contract Type whose ID matches the one selected.
            for (ProgramContributionGrid lProgramContributionGrid : lProgramContributionGrids) {

                if (rowID != null && lProgramContributionGrid.getRowID().equals(rowID)) {
                    lRemovedProgramContributionGrids.add(lProgramContributionGrid);
                    lProgramContributionGrids.remove(lProgramContributionGrid);
                    getUserSession().setRemovedProgramContributionGrids(lRemovedProgramContributionGrids);
                    break;
                }
            }
        } else {
            //remove rows added but no data selected or entered.
            getUserSession().getProgramIncentiveOption().getProgramContributionGrids().clear();
        }

        clearFormArrays(form);
        populateRequest(modelMap);
    }

    private String findBenefitContractTypeDesc(Integer benefitContractTypeID, HashMap<Integer, String> benefitContractTypeHashMap) {
        String benefitContractTypeDesc = benefitContractTypeHashMap.get(benefitContractTypeID);
        return benefitContractTypeDesc;
    }

    private void addAssignedRelationships(SaveProgramContributionGridForm form, ModelMap modelMap) {
        HashMap<Integer, Collection<ContributionGridBenefitContractTypeRelationship>> benefitContractTypeRelationshipHashMap = new HashMap<>();
        Collection<ContributionGridBenefitContractType> lContributionGridBenefitContractTypes = getUserSession().getContributionGridBenefitContractTypes();

        String[] programBenefitContractTypeIDs = form.getProgramBenefitContractTypeIDs();
        for (int i = 0; i < programBenefitContractTypeIDs.length; i++) {
            Integer chosenBenefitContractTypeID = Integer.valueOf(programBenefitContractTypeIDs[i]);

            for (ContributionGridBenefitContractType lContributionGridBenefitContractType : lContributionGridBenefitContractTypes) {
                if (chosenBenefitContractTypeID.equals(lContributionGridBenefitContractType.getBenefitContractTypeID())) {
                    if (!benefitContractTypeRelationshipHashMap.containsKey(chosenBenefitContractTypeID)) {
                        benefitContractTypeRelationshipHashMap.put(chosenBenefitContractTypeID, lContributionGridBenefitContractType.getContributionGridBenefitContractTypeRelationships());
                        break;
                    }
                }
            }

            if (benefitContractTypeRelationshipHashMap.isEmpty()) {
                ArrayList<ContributionGridBenefitContractTypeRelationship> lNewContributionGridBenefitContractTypeRelationships = new ArrayList<>();
                ContributionGridBenefitContractTypeRelationship lNewContributionGridBenefitContractTypeRelationship = new ContributionGridBenefitContractTypeRelationship();
                lNewContributionGridBenefitContractTypeRelationship.setBenefitContractTypeID(0);
                lNewContributionGridBenefitContractTypeRelationship.setRelationshipCode(0);
                lNewContributionGridBenefitContractTypeRelationship.setRelationshipDesc("");
                lNewContributionGridBenefitContractTypeRelationships.add(lNewContributionGridBenefitContractTypeRelationship);
                benefitContractTypeRelationshipHashMap.put(chosenBenefitContractTypeID, lNewContributionGridBenefitContractTypeRelationships);
            }
        }

        getUserSession().setBenefitContractTypeRelationshipGridHashMap(benefitContractTypeRelationshipHashMap);
        assignRelationshipAtributesToProgramContributionGrid(form);
        modelMap.put("benefitContractTypeRelationshipHashMap", benefitContractTypeRelationshipHashMap);
        clearFormArrays(form);
        populateRequest(modelMap);
    }

    private String performSave(ModelMap modelMap, RedirectAttributes ra, SaveProgramContributionGridForm form, BindingResult result) throws Exception {
        String userID = getUserSessionSupport().getAuthenticatedUsername();

        if (ACTION_SAVE.equals(form.getActionType())) {
            boolean isValid = save(form, modelMap, result, userID);
            if (!isValid || result.hasErrors()) {
                return "editProgramContributionGrid";
            }

        } else {
            ProgramIncentiveOption saveProgramIncentiveOption = getUserSession().getProgramIncentiveOption();
            Collection<EmployerGroup> lEmployerGroups = null;

            if (ACTION_SAVE_TO_ALL_SITES.equals(form.getActionType())) {
                lEmployerGroups = businessProgramService.getSubGroups(getUserSession().getBusinessProgram().getEmployerGroup().getGroupID());

            } else if (ACTION_SAVE_TO_SELECTED.equals(form.getActionType())) {
                lEmployerGroups = getUserSession().getEmployerSubGroups();
            }

            boolean isValid = saveProgramContributionGridToAllSites(form, lEmployerGroups, modelMap , result, userID);

            //reset.
            getUserSession().setProgramIncentiveOption(saveProgramIncentiveOption);

            //Not valid
            if (!isValid) {
                assignRelationshipAtributesToProgramContributionGrid(form);
                addAssignedRelationships(form, modelMap);
                clearFormArrays(form);
                populateRequest(modelMap);
                createActionMessagesOnModel(modelMap, "errors.noCopyForContributionGrid", new Object[]{ "incentiveOption"});
                return "editProgramContributionGrid";
            }
        }

        // Redirect back to the editProgram incentiveOptions screen upon successful process of saves
        EditProgramForm editProgramForm = new EditProgramForm();
        editProgramForm.setGroupNo(getUserSession().getGroupNo());
        editProgramForm.setProgramID(form.getProgramID());
        getUserSession().setProgramID(form.getProgramID());
        ra.addFlashAttribute("editProgramForm", editProgramForm);
        ra.addFlashAttribute("groupNumber", getUserSession().getGroupNo());
        ra.addFlashAttribute("actionType", "editIncentives");
        ra.addAttribute("groupNumber", getUserSession().getGroupNo());
        ra.addAttribute("actionType", "editIncentives");
        return "redirect: editProgram";
    }

    private boolean save(SaveProgramContributionGridForm saveProgramContributionGridForm, ModelMap modelMap, BindingResult result, String userID) throws Exception {
        boolean isValid;

        assignRelationshipAtributesToProgramContributionGrid(saveProgramContributionGridForm);

        isValid = validateNSaveProgramContributionGrid(getUserSession().getBusinessProgram(), getUserSession().getProgramIncentiveOption(), saveProgramContributionGridForm, modelMap, result, userID);
        if (isValid) {
            if (getUserSession().getRemovedProgramContributionGrids() != null && getUserSession().getRemovedProgramContributionGrids().size() > 0) {
                deleteProgramContributionGrid();
            }
        } else {
            clearFormArrays(saveProgramContributionGridForm);
            populateRequest(modelMap);
        }

        return isValid;
    }

    private boolean validateNSaveProgramContributionGrid(BusinessProgram lBusinessProgram, ProgramIncentiveOption lProgramIncentiveOption, SaveProgramContributionGridForm lSaveProgramContributionGridForm, ModelMap modelMap, Errors errors, String lUserID) throws Exception {
        if (isBenefitContractTypeAllWithMultipleBenefitContractTypes(lSaveProgramContributionGridForm)) {
            getValidationSupport().addValidationFailureMessage("programBenefitContractTypeIDs[0]", errors, "errors.benefitContractTypeALL", new Object[] {"Benefit Contract Type ALL "});
            return false;
        }

        if (lSaveProgramContributionGridForm.getProgramBenefitContractTypeIDs() != null && lSaveProgramContributionGridForm.getProgramBenefitContractTypeIDs().length == 0) {
            getValidationSupport().addValidationFailureMessage("contributionAmounts[0]", errors, "errors.programBenefitContractRelAmtMissing", new Object[] {"Benefit Contract Contribution Amount"});
            return false;
        }

        //read luv record for to check for max amount allowed to be entered.
        LookUpValueCode contributionAmountLimitLuv = businessProgramService.getContributionAmountLimit(BPMAdminConstants.CONTRIBUTION_AMT_LIMIT);

        Integer contributionAmountLimit = Integer.valueOf(contributionAmountLimitLuv.getLuvVal());

        if (lSaveProgramContributionGridForm.getContributionAmounts() != null) {
            String[]  amounts = lSaveProgramContributionGridForm.getContributionAmounts();
            for (int i = 0; i < amounts.length; i++ ) {
                Integer amount = Integer.valueOf(amounts[i]);
                if (amount > contributionAmountLimit) {
                    getValidationSupport().addValidationFailureMessage("contributionAmounts[0]", errors, "errors.contributionAmtExceeded", new Object[] {"Contribution Amount", contributionAmountLimit});
                    return false;
                }
            }
        }

        if (lSaveProgramContributionGridForm.getProgramBenefitContractTypeIDs() != null && lSaveProgramContributionGridForm.getRelationshipIDs() != null) {
            Collection<ProgramContributionGrid> lProgramContributionGrids = lProgramIncentiveOption.getProgramContributionGrids();
            String[]  programBenefitContractTypeIDs = lSaveProgramContributionGridForm.getProgramBenefitContractTypeIDs();
            String[]  relationshipIDs = lSaveProgramContributionGridForm.getRelationshipIDs();
            for (int i = 0; i < programBenefitContractTypeIDs.length; i++ ) {
                Integer benefitContractTypeID = Integer.valueOf(programBenefitContractTypeIDs[i]);
                Integer relationshipID = Integer.valueOf(relationshipIDs[i]);

                if (isDuplicateEntry(benefitContractTypeID, relationshipID, lProgramContributionGrids)) {
                    getValidationSupport().addValidationFailureMessage("programBenefitContractTypeIDs[0]", errors, "errors.duplicateContributionGridEntry", new Object[] {"Duplicate entry"});
                    return false;
                }

            }
        }

        try {
            saveProgramContributionGrids(lSaveProgramContributionGridForm, lUserID);
        } catch (Exception e) {
            logger.error("validateProgramContributionGridForm: error when attempting to save program benefit contract type.");
            throw (e);
        }

        return true;
    }

    private boolean isBenefitContractTypeAllWithMultipleBenefitContractTypes(SaveProgramContributionGridForm lSaveProgramContributionGridForm) throws BPMException {
        boolean isBenefitContractTypeAllWithMultiples = false;
        String[] programBenefitContractTypeIDs = lSaveProgramContributionGridForm.getProgramBenefitContractTypeIDs();

        if (programBenefitContractTypeIDs != null) {
            for (int i = 0; i < programBenefitContractTypeIDs.length; i++) {
                Integer chosenBenefitContractTypeID = Integer.valueOf(programBenefitContractTypeIDs[i].toString());

                try {
                    LookUpValueCode lLookUpValueCode = businessProgramService.getBenefitContractTypeById(chosenBenefitContractTypeID);
                    if (lLookUpValueCode.getLuvVal().equals(BPMAdminConstants.BEN_CON_ALL) && programBenefitContractTypeIDs.length > 1) {
                        isBenefitContractTypeAllWithMultiples = true;
                        break;
                    }
                } catch (BPMException e) {
                    logger.error("BPMException: Read error at determineAllBenefitContractTypeNAssign");
                    throw (e);

                }
            }
        }

        return isBenefitContractTypeAllWithMultiples;
    }

    private void saveProgramContributionGrids(SaveProgramContributionGridForm lSaveProgramContributionGridForm, String pUserID) throws Exception {
        assignRelationshipAtributesToProgramContributionGrid(lSaveProgramContributionGridForm);

        //create available benefit contract type contribution incentive grids if benefit contract type selected is ALL.
        determineBenefitContractTypeALLNAssign(lSaveProgramContributionGridForm);

        Collection<ProgramContributionGrid> lProgramContributionGrids = getUserSession().getProgramIncentiveOption().getProgramContributionGrids();
        for (ProgramContributionGrid lProgramContributionGrid : lProgramContributionGrids) {
            businessProgramService.updateProgramContributionGrid(lProgramContributionGrid, pUserID);
        }
    }

    private boolean isDuplicateEntry(Integer benefitContractTypeID, Integer relationshipID, Collection<ProgramContributionGrid> lProgramContributionGrids) {
        boolean isDuplicate = false;
        int moreThanOneCounter = 0;
        for (ProgramContributionGrid lProgramContributionGrid : lProgramContributionGrids) {
            if (lProgramContributionGrid.getBenefitContractTypeID().equals(benefitContractTypeID) &&
                    lProgramContributionGrid.getRelationshipCodeID().equals(relationshipID)) {
                moreThanOneCounter++;
            }
            if (moreThanOneCounter > 1) {
                isDuplicate = true;
            }
        }

        return isDuplicate;
    }

    private void determineBenefitContractTypeALLNAssign(SaveProgramContributionGridForm lSaveProgramContributionGridForm) throws BPMException {

        ArrayList<ProgramContributionGrid> lProgramContributionGridNewList = new ArrayList<>();

        Collection<ContributionGridBenefitContractType> lContributionGridBenefitContractTypes = getUserSession().getContributionGridBenefitContractTypes();

        ProgramIncentiveOption lProgramIncentiveOption =  getUserSession().getProgramIncentiveOption();

        String[] programBenefitContractTypeIDs = lSaveProgramContributionGridForm.getProgramBenefitContractTypeIDs();
        String[] contributionAmounts = lSaveProgramContributionGridForm.getContributionAmounts();
        String[] relationshipIDs = lSaveProgramContributionGridForm.getRelationshipIDs();


        if (programBenefitContractTypeIDs != null) {
            for ( int i = 0; i < programBenefitContractTypeIDs.length; i++) {
                Integer chosenBenefitContractTypeID = Integer.valueOf(programBenefitContractTypeIDs[i]);
                Integer relationshipCodeID = Integer.valueOf(relationshipIDs[i]);
                Integer contributionAmount = Integer.valueOf(contributionAmounts[i]);

                try {
                    LookUpValueCode lLookUpValueCode = businessProgramService.getBenefitContractTypeById(chosenBenefitContractTypeID);
                    if (lLookUpValueCode.getLuvVal().equals(BPMAdminConstants.BEN_CON_ALL)) {
                        for (ContributionGridBenefitContractType lContributionGridBenefitContractType : lContributionGridBenefitContractTypes) {
                            if (chosenBenefitContractTypeID.equals(lContributionGridBenefitContractType.getBenefitContractTypeID())) {
                                //Do not include Benefit Contract Type of ALL since ALL is driving the creation of available Benefit Contract Types assigned to the Grid.
                            } else {
                                ProgramContributionGrid lProgramContributionGrid = new ProgramContributionGrid();
                                lProgramContributionGrid.setBenefitContractTypeID(lContributionGridBenefitContractType.getBenefitContractTypeID());
                                lProgramContributionGrid.setProgramIncentiveOptionID(Integer.valueOf(lSaveProgramContributionGridForm.getProgramIncentiveOptionID()));
                                lProgramContributionGrid.setBenefitContractTypeDesc(lContributionGridBenefitContractType.getLuvDesc());

                                lProgramContributionGrid.setRelationshipCodeID(relationshipCodeID);
                                String relationshipDesc = findRelationshipDesc(lProgramContributionGrid.getBenefitContractTypeID(), relationshipCodeID, getUserSession().getBenefitContractTypeRelationshipGridHashMap());
                                lProgramContributionGrid.setRelationshipCode(relationshipDesc);
                                lProgramContributionGrid.setContributionAmount(contributionAmount);
                                lProgramContributionGridNewList.add(lProgramContributionGrid);
                            }
                        }

                    }
                } catch (BPMException e) {
                    logger.error("BPMException: Read error at determineAllBenefitContractTypeNAssign");
                    throw (e);
                }
            }
        }

        if (lProgramContributionGridNewList.size() > 0) {
            lProgramIncentiveOption.setProgramContributionGrids(lProgramContributionGridNewList);
        }
    }

    private int  deleteProgramContributionGrid() throws BPMException {
        int numberDeleted = 0;
        Collection<ProgramContributionGrid> lremovedProgramContributionGrids = getUserSession().getRemovedProgramContributionGrids();
        try {
            numberDeleted = businessProgramService.deleteProgramContributionGrids(lremovedProgramContributionGrids);
        } catch (BPMException e) {
            throw e;
        }

        getUserSession().getRemovedProgramContributionGrids().clear();

        return numberDeleted;
    }

    private boolean saveProgramContributionGridToAllSites(SaveProgramContributionGridForm lSaveProgramContributionGridForm, Collection<EmployerGroup> pEmployerGroups, ModelMap modelMap, Errors errors, String pUserID) throws Exception {
        boolean isValid = false;

        assignRelationshipAtributesToProgramContributionGrid(lSaveProgramContributionGridForm);
        BusinessProgram pBusinessProgram = getUserSession().getBusinessProgram();
        ProgramIncentiveOption lProgramIncentiveOptionOrigin = getUserSession().getProgramIncentiveOption();
        Integer incentiveOptonIDTarget = lProgramIncentiveOptionOrigin.getIncentiveOption().getIncentiveOptionID();

        Collection<ProgramContributionGrid> lProgramContributionGridsToSaveFrom = lProgramIncentiveOptionOrigin.getProgramContributionGrids();
        for (EmployerGroup lEmployerGroup : pEmployerGroups) {
            ArrayList<BusinessProgram> lBusinessPrograms = (ArrayList<BusinessProgram>)
                    businessProgramService.getBusinessPrograms(pBusinessProgram.getEffectiveDate()
                            , pBusinessProgram.getEmployerGroup().getGroupID()
                            , lEmployerGroup.getSubgroupID());

            for (BusinessProgram lBusinessProgram : lBusinessPrograms) {
                ProgramIncentiveOption lProgramIncentiveOptionOnMatch = null;
                Collection<ProgramIncentiveOption> lProgramIncentiveOptions = businessProgramService.getProgramIncentiveOptions(lBusinessProgram.getProgramID());

                //using the current program incentive option as the target match to the program incentive option in which program contribution grids are being added.
                for (ProgramIncentiveOption lProgramIncentiveOption : lProgramIncentiveOptions) {
                    if (lProgramIncentiveOption.getIncentiveOption().getIncentiveOptionID().equals(incentiveOptonIDTarget)) {

                        lProgramIncentiveOptionOnMatch = lProgramIncentiveOption;

                        ArrayList<ProgramContributionGrid> lProgramContributionGridsToTransfer = lProgramIncentiveOptionOrigin.getProgramContributionGrids();

                        //using the original
                        for (ProgramContributionGrid lProgramContributionGridToTransfer : lProgramContributionGridsToTransfer) {
                            lProgramContributionGridToTransfer.setProgramIncentiveOptionID(lProgramIncentiveOptionOnMatch.getProgramIncentiveOptionID());
                            if (lProgramIncentiveOptionOnMatch.getProgramContributionGrids().isEmpty()) {
                                lProgramContributionGridToTransfer.setContributionGridID(null);
                            }
                        }

                        lProgramIncentiveOptionOnMatch.setProgramContributionGrids(lProgramContributionGridsToTransfer);

                        getUserSession().setProgramIncentiveOption(lProgramIncentiveOptionOnMatch);
                        break;
                    }
                }

                if (lProgramIncentiveOptionOnMatch != null) {
                    isValid = validateNSaveProgramContributionGrid(lBusinessProgram, lProgramIncentiveOptionOnMatch, lSaveProgramContributionGridForm, modelMap, errors, pUserID);

                    //check to see if any program contribution grid was removed.  If yes, then need to remove all associated program contribution grids by site.
                    if (getUserSession().getRemovedProgramContributionGrids() != null) {
                        Collection<ProgramContributionGrid> lProgramContributionGridsRemoved = getUserSession().getRemovedProgramContributionGrids();
                        ArrayList<ProgramContributionGrid> lProgramContributionGridsToRemove = new ArrayList<ProgramContributionGrid>();
                        //match on program contribution grid of business program to get activity incentive id used as part of the key to the record when updating.
                        Collection<ProgramContributionGrid> lProgramContributionGrids = businessProgramService.getProgramContributionGrids(lProgramIncentiveOptionOnMatch.getProgramIncentiveOptionID());
                        for (ProgramContributionGrid lProgramContributionGridRemoved : lProgramContributionGridsRemoved) {
                            for (ProgramContributionGrid lProgramContributionGrid : lProgramContributionGrids) {
                                if (lProgramContributionGridRemoved.getContributionGridID().equals(lProgramContributionGrid.getContributionGridID())) {
                                    lProgramContributionGridsToRemove.add(lProgramContributionGrid);
                                }
                            }
                        }

                        if (isValid) {
                            if (lProgramContributionGridsToRemove != null && lProgramContributionGridsToRemove.size() > 0) {
                                getUserSession().setProgramContributionGrids(lProgramContributionGridsToRemove);
                                deleteProgramContributionGrid();
                            }
                        }
                    }
                }
            }
        }

        //reset back to original
        getUserSession().setProgramIncentiveOption(lProgramIncentiveOptionOrigin);

        if (getUserSession().getRemovedProgramContributionGrids() != null) {
            getUserSession().getRemovedProgramContributionGrids().clear();
        }

        return isValid;
    }

    private void selectSites(ModelMap modelMap) throws BPMException {
        if (getUserSession().getAvailableSites() != null) {
            getUserSession().getAvailableSites().clear();
        }

        if (getUserSession().getEmployerSubGroups() != null) {
            getUserSession().getEmployerSubGroups().clear();
        }

        Collection<EmployerGroup> lSubGroups = businessProgramService.getBusinessProgramInSameYear(getUserSession().getBusinessProgram().getProgramID());

        modelMap.put("businessProgram", getUserSession().getBusinessProgram());
        modelMap.put("selectedSubGroups", lSubGroups);

        SaveProgramActivitySiteForm saveProgramActivitySiteForm = new SaveProgramActivitySiteForm();
        saveProgramActivitySiteForm.setSubGroupID(((ArrayList<EmployerGroup>) lSubGroups).get(0).getSubgroupID());
        modelMap.put("saveProgramActivitySiteForm", saveProgramActivitySiteForm);

        getUserSession().setEmployerSubGroups((ArrayList<EmployerGroup>) lSubGroups);
        getUserSession().setWhichSaveSelectedSite(WHICH_SAVE_SELECTED_SITES_PROGRAM_CONTRIBUTION_GRID);
    }

    @Override
    public boolean supports(Class<?> clazz) {
        return SaveProgramContributionGridForm.class.isAssignableFrom(clazz);
    }

    @Override
    public void validate(Object target, Errors errors) {
        SaveProgramContributionGridForm form = (SaveProgramContributionGridForm) target;
        boolean isAllBenefitContractTypesSelected = false;

        if (BPMAdminConstants.ACTION_SAVE.equals(form.getActionType())) {
            if (form.getProgramBenefitContractTypeIDs() != null) {
                for (int i=0; i < form.getProgramBenefitContractTypeIDs().length; i++) {
                    if (isAllBenefitContractTypeSelected(form.getProgramBenefitContractTypeIDs()[i])) {
                        isAllBenefitContractTypesSelected = true;
                    }
                    getValidationSupport().validateNotSelected("programBenefitContractTypeIDs["+i+"]", form.getProgramBenefitContractTypeIDs()[i], errors, new Object[]{"Benefit Contract Type"});
                }
            }

            if (!isAllBenefitContractTypesSelected) {
                if (form.getRelationshipIDs() != null) {
                    for (int i=0; i < form.getRelationshipIDs().length; i++) {
                        getValidationSupport().validateNotSelected("relationshipIDs["+i+"]", form.getRelationshipIDs()[i], errors, new Object[]{"Relationship"});
                    }
                }

                if (form.getContributionAmounts() != null) {
                    for (int i=0; i < form.getContributionAmounts().length; i++) {
                        if (getValidationSupport().validateNotInteger("contributionAmounts["+i+"]", form.getContributionAmounts()[i], errors, new Object[]{"Amount"})){
                            getValidationSupport().validateNotSelected("contributionAmounts[" + i + "]", form.getContributionAmounts()[i], errors, new Object[]{"Amount"});
                            getValidationSupport().validateNotZero("contributionAmounts[" + i + "]", form.getContributionAmounts()[i], errors, new Object[]{"Amount"});
                        }
                    }
                }
            }
        }
    }

    private boolean isAllBenefitContractTypeSelected(String chosenBenefitContractTypeID) {
        boolean isAllBenefitContractTypeSelected = false;
        if (chosenBenefitContractTypeID == null) {
            chosenBenefitContractTypeID = "0";
        }
        try {
            if (chosenBenefitContractTypeID != null && businessProgramService != null) {
                LookUpValueCode lLookUpValueCode = businessProgramService.getBenefitContractTypeById(Integer.valueOf(chosenBenefitContractTypeID));
                if (lLookUpValueCode != null && lLookUpValueCode.getLuvVal().equals(BPMAdminConstants.BEN_CON_ALL)) {
                    isAllBenefitContractTypeSelected = true;
                }
            }
        } catch (BPMException e) {
            System.out.print("Error trying to determine if all benefit contract types was selected");

        }

        return isAllBenefitContractTypeSelected;
    }

}
