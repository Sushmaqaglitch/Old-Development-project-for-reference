package com.healthpartners.app.bpm.pageable;

import com.healthpartners.app.bpm.dto.CDHPFulfillmentTrackingReportHist;

import java.util.ArrayList;
import java.util.Iterator;

/**
 * The pageable class serves as a wrapper for the array list of objects, and
 * operations that are performed on those objects. For ex. adding a row number
 * for display.
 * The BPMPagination then has a pointer to an instance of this class.
 *
 * @author jxbourbour
 */
public class PageableCDHPFulfillmentTrackingReportHist implements BPMPageable {
    ArrayList<CDHPFulfillmentTrackingReportHist> cDHPFulfillmentTrackingReports;

    public PageableCDHPFulfillmentTrackingReportHist() {
        super();
    }

    public PageableCDHPFulfillmentTrackingReportHist(ArrayList<CDHPFulfillmentTrackingReportHist> pCDHPFulfillmentTrackingReports) {
        cDHPFulfillmentTrackingReports = pCDHPFulfillmentTrackingReports;
    }

    public ArrayList<CDHPFulfillmentTrackingReportHist> getcDHPFulfillmentTrackingReports() {
        return cDHPFulfillmentTrackingReports;
    }

    public void setcDHPFulfillmentTrackingReports(ArrayList<CDHPFulfillmentTrackingReportHist> cDHPFulfillmentTrackingReports) {
        this.cDHPFulfillmentTrackingReports = cDHPFulfillmentTrackingReports;
    }

    public void addRowNumber() {
        int startRowNumber = 1;
        Iterator<CDHPFulfillmentTrackingReportHist> iter = cDHPFulfillmentTrackingReports.iterator();
        while (iter.hasNext()) {
            CDHPFulfillmentTrackingReportHist lCDHPFulfillmentTrackingReportHist = iter.next();
            lCDHPFulfillmentTrackingReportHist.setRowNumber(startRowNumber);
            startRowNumber++;
        }
    }

}
