package com.healthpartners.app.bpm.controller;

import com.healthpartners.app.bpm.common.BPMAdminConstants;
import com.healthpartners.app.bpm.common.BPMPagination;
import com.healthpartners.app.bpm.dto.BusinessProgram;
import com.healthpartners.app.bpm.dto.EmployerGroup;
import com.healthpartners.app.bpm.form.CopyAllGroupForm;
import com.healthpartners.app.bpm.form.ProgramSearchForm;
import com.healthpartners.app.bpm.form.ShowGroupsForm;
import com.healthpartners.app.bpm.iface.BusinessProgramService;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.mvc.support.RedirectAttributesModelMap;
import org.springframework.web.servlet.view.RedirectView;

import jakarta.servlet.http.HttpServletRequest;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import static org.apache.commons.lang.exception.ExceptionUtils.getStackTrace;

@Controller
public class ProgramSearchController extends BaseController implements Validator {

    protected final Log logger = LogFactory.getLog(getClass());

    private final BusinessProgramService businessProgramService;

    public ProgramSearchController(BusinessProgramService businessProgramService) {
        this.businessProgramService = businessProgramService;
    }

    @GetMapping("/showProgramSearch")
    public String loadShowGroupLookup(HttpServletRequest request, ModelMap modelMap, @RequestParam(name = "actionType") String actionType) {
        getUserSession().reset();
        setAttributesPaginationBackNextButtonsToDisableOnModel(modelMap, getUserSession());
        ProgramSearchForm programSearchForm = new ProgramSearchForm();
        programSearchForm.setActionType(ACTION_SEARCH);
        CopyAllGroupForm copyAllGroupForm = new CopyAllGroupForm();
        ShowGroupsForm showGroupsForm = new ShowGroupsForm();
        modelMap.put("programSearchForm", programSearchForm);
        modelMap.put("copyAllGroupForm", copyAllGroupForm);
        modelMap.put("showGroupsForm", showGroupsForm);

        if (BPMAdminConstants.BPM_ADMIN_ADMIN_VIEW.equalsIgnoreCase(actionType)) {
            request.getSession().setAttribute(BPMAdminConstants.BPM_MEMBER_SERVICES_ADMIN_ROLE, false);
            request.getSession().setAttribute(BPMAdminConstants.BPM_ADMIN_PRINTER_FRIENDLY_ACCESS, true);
        } else if (BPMAdminConstants.BPM_ADMIN_GROUP_SETUP.equalsIgnoreCase(actionType)) {
            request.getSession().setAttribute(BPMAdminConstants.BPM_MEMBER_SERVICES_ADMIN_ROLE, false);
            request.getSession().setAttribute(BPMAdminConstants.BPM_ADMIN_GROUP_VIEW_EDIT_ACCESS, true);
            request.getSession().setAttribute(BPMAdminConstants.BPM_ADMIN_PRINTER_FRIENDLY_ACCESS, true);
        } else if (BPMAdminConstants.BPM_MEMBER_SERVICES_ADMIN_ROLE.equalsIgnoreCase(actionType)) {
            request.getSession().setAttribute(BPMAdminConstants.BPM_MEMBER_SERVICES_ADMIN_ROLE, true);
        }
        setRequestAttributesAndFormProperties(modelMap, programSearchForm);
        return "programSearch";
    }

    @PostMapping("/programSearch")
    public String submitSearch(@ModelAttribute("programSearchForm") ProgramSearchForm form, ModelMap modelMap, BindingResult result) throws Exception {
        try {
            if (StringUtils.isEmpty(form.getActionType())) {
                form.setActionType(ACTION_SEARCH);
            }
            if (ACTION_SEARCH.equals(form.getActionType())) {
                validate(form, result);
            }
            if (!result.hasErrors()) {
                clearForm(form);
                search(form, modelMap);
            }
        } catch (Exception e) {
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
            // Add error stack trace on the request, to be hidden in html.
            createErrorMessageOnModel(modelMap, getStackTrace(e));
        }

        return "programSearch";
    }

    private void clearForm(ProgramSearchForm form) {
        form.setGroupID(null);
        form.setGroupStartDate(null);
        form.setWhichList(null);
        form.setQualificationStartDate(null);
    }

    @PostMapping(value="/programSearch", params="next")
    public String submitNext(@ModelAttribute("programSearchForm") ProgramSearchForm form, ModelMap modelMap) throws Exception {
        form.setActionType(ACTION_PAGE_FORWARD);
        search(form, modelMap);
        return "programSearch";
    }

    @PostMapping(value="/programSearch", params="back")
    public String submitBack(@ModelAttribute("programSearchForm") ProgramSearchForm form, ModelMap modelMap) throws Exception {
        form.setActionType(ACTION_PAGE_BACK);
        search(form, modelMap);
        return "programSearch";
    }

    @PostMapping(value="/programSearch", params="backToGroupList")
    public String submitBackToGroupList(@ModelAttribute("programSearchForm") ProgramSearchForm form, ModelMap modelMap) throws Exception {
        form.setActionType(ACTION_BACK_TO_GROUP_LIST);
        form.setGroupName(getUserSession().getGroupName());
        backToGroupList(modelMap, form);
        return "programSearch";
    }

    @PostMapping(value="/programSearch", params="copyToYear")
    public RedirectView submitCopyToYear(@ModelAttribute("programSearchForm") ProgramSearchForm programSearchForm, RedirectAttributesModelMap attributes) {
        attributes.addFlashAttribute("groupID", programSearchForm.getGroupID());
        attributes.addFlashAttribute("groupStartDate", programSearchForm.getQualificationStartDate());
        return new RedirectView("copyAllGroup");
    }

    @GetMapping("/programSearch")
    public String loadSearch(@ModelAttribute("programSearchForm") ProgramSearchForm form, BindingResult result, Map<String, Object> model, ModelMap modelMap) throws Exception {
        String groupNumber = (String)model.get("groupNumber");
        form.setActionType(ACTION_SEARCH);
        form.setGroupNumber(groupNumber);
        validate(form, result);
        if (!result.hasErrors()) {
            search(form, modelMap);
        }
        return "programSearch";
    }

    @GetMapping("/deleteProgram")
    public RedirectView deleteProgram(@RequestParam(value = "programID") Integer programID, ModelMap modelMap, Locale locale, RedirectAttributes ra) {
        try {
            businessProgramService.deleteEmptyBusinessProgram(programID);
            buildDeleteMessage(locale, ra);
            BusinessProgram businessProgram = getUserSession().getBusinessPrograms().get(0);
            if(businessProgram != null){
                ra.addFlashAttribute("groupNumber", businessProgram.getEmployerGroup().getGroupNumber());
            }
        } catch (Exception e) {
            logger.error(e);
            createErrorMessageOnModel(modelMap, getStackTrace(e));
        }
        return new RedirectView("programSearch");
    }


    private void buildDeleteMessage(Locale locale, RedirectAttributes ra) {
        String message = getMessageSource().getMessage("messages.programDeleted", null, locale);
        List<String> messages = new ArrayList<>();
        messages.add(message);
        ra.addFlashAttribute("messages", messages);
    }

    private void search(ProgramSearchForm form, ModelMap modelMap) throws Exception {
        if (StringUtils.isNotEmpty(form.getGroupName()) || EMPLOYER_GROUPS_LIST.equals(form.getWhichList())) {
            searchByGroupName(modelMap, form);
        } else {
            searchByGroupID(modelMap, form);
        }
        setRequestAttributesAndFormProperties(modelMap, form);
    }

    private void searchByGroupName(ModelMap modelMap, ProgramSearchForm lProgramSearchForm) throws Exception {
        boolean newDTOList = false;
        ArrayList<EmployerGroup> lEmployerGroups = getUserSession().getEmployerGroups();
        String actionType = lProgramSearchForm.getActionType();

        if (CollectionUtils.isEmpty(lEmployerGroups) || actionType.equals(ACTION_SEARCH)) {
            lEmployerGroups = (ArrayList<EmployerGroup>) businessProgramService.getGroupsByName(lProgramSearchForm.getGroupName());
            getUserSession().setEmployerGroups(lEmployerGroups);
            newDTOList = true;
        }

        setEmployerGroupPaginationOnModel(modelMap, getUserSession(), actionType, newDTOList);

        if (actionType.equals(ACTION_SEARCH)) {
            modelMap.put("groupNameExists", BPMAdminConstants.BPM_ADMIN_FALSE);
        }
        if (actionType.equals(ACTION_SITE_SEARCH)) {
            modelMap.put("groupNameExists", BPMAdminConstants.BPM_ADMIN_TRUE);
        }

        getUserSession().setEmployerGroups(lEmployerGroups);
        getUserSession().setProgramSearchForm(lProgramSearchForm);
        getUserSession().setGroupName(lProgramSearchForm.getGroupName());
        lProgramSearchForm.setGroupName(getUserSession().getGroupName());
    }

    private void searchByGroupID(ModelMap modelMap, ProgramSearchForm pProgramSearchForm) throws Exception {
        boolean newDTOList = false;
        String actionType = pProgramSearchForm.getActionType();
        ArrayList<BusinessProgram> lBusinessPrograms = getUserSession().getBusinessPrograms();

        if (CollectionUtils.isEmpty(lBusinessPrograms) || actionType.equals(ACTION_SEARCH) || actionType.equals(ACTION_SITE_SEARCH)) {
            lBusinessPrograms = (ArrayList<BusinessProgram>) businessProgramService.getActiveNWithdrawnBusinessPrograms(pProgramSearchForm.getGroupNumber(), null, pProgramSearchForm.getGroupID(), null);
            getUserSession().setBusinessPrograms(lBusinessPrograms);
            newDTOList = true;
        }

        if (lBusinessPrograms.size() <= 0) {
            createActionMessagesOnModel(modelMap, "messages.info", new Object[]{"No results found for the given search attribute(s)"});
        }

        setBusinessProgramPaginationOnModel(modelMap, getUserSession(), actionType, newDTOList);

        getUserSession().setBusinessPrograms(lBusinessPrograms);
        getUserSession().setProgramSearchForm(pProgramSearchForm);
        if (!CollectionUtils.isEmpty(getUserSession().getEmployerGroups())) {
            modelMap.put("groupNameExists", BPMAdminConstants.BPM_ADMIN_TRUE);
        }
        getUserSession().setGroupName(pProgramSearchForm.getGroupName());

    }

    protected void backToGroupList(ModelMap modelMap, ProgramSearchForm lProgramSearchForm) throws Exception {
        ArrayList<EmployerGroup> lEmployerGroups = getUserSession().getEmployerGroups();
        ArrayList<EmployerGroup> lEmployerGroupsPerPage = getUserSession().getEmployerGroupsPerPage();

        BPMPagination pagination = getUserSession().getPaginationMap().get(EMPLOYER_GROUPS_LIST);
        setAttributesForPaginationOnModel(modelMap, lEmployerGroups.size(), pagination);

        modelMap.put("employerGroups", lEmployerGroupsPerPage);
        modelMap.put("groupNameExists", BPMAdminConstants.BPM_ADMIN_FALSE);
        modelMap.put("whichList", EMPLOYER_GROUPS_LIST);

        getUserSession().setProgramSearchForm(lProgramSearchForm);
        lProgramSearchForm.setGroupName(getUserSession().getGroupName());
    }

    private void setRequestAttributesAndFormProperties(ModelMap modelMap, ProgramSearchForm form) {
        Boolean groupViewAndEditAccess = (Boolean)getUserSessionSupport().getSession().getAttribute(BPMAdminConstants.BPM_ADMIN_GROUP_VIEW_EDIT_ACCESS);
        Boolean memberServicesAdminRole = (Boolean)getUserSessionSupport().getSession().getAttribute(BPMAdminConstants.BPM_MEMBER_SERVICES_ADMIN_ROLE);
        modelMap.put("groupViewAndEditAccess", groupViewAndEditAccess);
        modelMap.put("memberServicesAdminRole", memberServicesAdminRole);

        ArrayList lBusinessPrograms = (ArrayList)modelMap.getAttribute("businessPrograms");
        if(!CollectionUtils.isEmpty(lBusinessPrograms)) {
            BusinessProgram businessProgram = (BusinessProgram) lBusinessPrograms.get(0);
            SimpleDateFormat fmt = new SimpleDateFormat(BPMAdminConstants.HP_BPM_ADMIN_UI_COMMON_DATE_FORMAT);
            String qualificationStartDate = fmt.format(businessProgram.getQualificationWindowStartDate());
            form.setGroupID(businessProgram.getEmployerGroup().getGroupID());
            form.setQualificationStartDate(qualificationStartDate);
        }
    }

    @Override
    public boolean supports(Class<?> clazz) {
        return ProgramSearchForm.class.isAssignableFrom(clazz);
    }

    @Override
    public void validate(Object target, Errors errors) {
        ProgramSearchForm form = (ProgramSearchForm) target;
        String groupNumber = form.getGroupNumber();
        String groupName = form.getGroupName();

        if(StringUtils.isEmpty(groupNumber) && StringUtils.isEmpty(groupName)) {
            String errorMessage = getMessageSource().getMessage("errors.required", new Object[]{"Group Number or Group Name"}, Locale.getDefault());
            errors.rejectValue("groupNumber", REQUIRED, errorMessage);
        }

        if (!StringUtils.isEmpty(groupNumber) && !StringUtils.isEmpty(groupName)) {
            String errorMessage = getMessageSource().getMessage("errors.groupNameOrNumber", null, Locale.getDefault());
            errors.rejectValue("groupNumber", REQUIRED, errorMessage);
        }

        getValidationSupport().validateNotSpecialChar("groupNumber", groupNumber, errors, new Object[]{"Group Number"});
        getValidationSupport().validateNotSpecialChar("groupName", groupName, errors, new Object[]{"Group Name"});
    }
}
