package com.healthpartners.app.bpm.form;

import com.healthpartners.app.bpm.dto.AdditionalInformation;

import java.util.Collection;

/**
 * @author tjquist
 *
 */
public class SaveProgramAdditionalInfoForm extends BaseForm {

	private Integer programID;
	private Integer groupID;
	private Integer subGroupID;
	private String programTypeCodeID;
	private String groupNumber;
	private String groupName;
	private String siteNumber;
	private String siteName;

	private Integer activityID;
	
	private Collection<AdditionalInformation> additionalInfos;
	private Integer[] additionalInfoIDs;		
	private String[] additionalInfoNames;
	private String[] additionalInfoTexts;
	private Integer[] sortOrders;
	private String [] additionalInfoTypeCodes;
	private Integer[] additionalInfoTypeCodeIDs;
	private Integer programAdditionalInfoAddRemove;

	
	
//	public ActionMessages validateSaveProgramAdditionalInfo(ActionMapping mapping,
//			HttpServletRequest request)
//	{
//		if(additionalInfoIDs != null && additionalInfoIDs.length > 0)
//		{
//			for(int i = 0; i < additionalInfoIDs.length; i++)
//				{
//			    validateNotNull("additionalInfoNames", additionalInfoNames[i], "Additional Info Names");
//		        validateNotNull("additionalInfoTexts", additionalInfoTexts[i], "Additional Info Texts");
//		        validateNotInteger("sortOrders", Integer.toString(sortOrders[i]), "Sort Orders");
//		        validateNotSpecialChar("additionalInfoTexts", additionalInfoTexts[i], "Additional Info Texts");
//				}
//		}
//
//	    return this.getActionMessages();
//	}

	public String getActionType() {
		return actionType;
	}

	public void setActionType(String actionType) {
		this.actionType = actionType;
	}

	public Integer getProgramID() {
		return programID;
	}

	public void setProgramID(Integer programID) {
		this.programID = programID;
	}

	public Integer[] getAdditionalInfoIDs() {
		return additionalInfoIDs;
	}

	public void setAdditionalInfoIDs(Integer[] additionalInfoIDs) {
		this.additionalInfoIDs = additionalInfoIDs;
	}

	public String[] getAdditionalInfoNames() {
		return additionalInfoNames;
	}

	public void setAdditionalInfoNames(String[] additionalInfoNames) {
		this.additionalInfoNames = additionalInfoNames;
	}

	public String[] getAdditionalInfoTexts() {
		return additionalInfoTexts;
	}

	public void setAdditionalInfoTexts(String[] additionalInfoTexts) {
		this.additionalInfoTexts = additionalInfoTexts;
	}

	public Integer[] getSortOrders() {
		return sortOrders;
	}

	public void setSortOrders(Integer[] sortOrders) {
		this.sortOrders = sortOrders;
	}

	public Collection<AdditionalInformation> getAdditionalInfos() {
		return additionalInfos;
	}

	public void setAdditionalInfos(Collection<AdditionalInformation> additionalInfos) {
		this.additionalInfos = additionalInfos;
	}

	public final Integer[] getAdditionalInfoTypeCodeIDs() {
		return additionalInfoTypeCodeIDs;
	}

	public final void setAdditionalInfoTypeCodeIDs(
			Integer[] additionalInfoTypeCodeIDs) {
		this.additionalInfoTypeCodeIDs = additionalInfoTypeCodeIDs;
	}

	public final String[] getAdditionalInfoTypeCodes() {
		return additionalInfoTypeCodes;
	}

	public final void setAdditionalInfoTypeCodes(String[] additionalInfoTypeCodes) {
		this.additionalInfoTypeCodes = additionalInfoTypeCodes;
	}

	public Integer getGroupID() {
		return groupID;
	}

	public void setGroupID(Integer groupID) {
		this.groupID = groupID;
	}

	public Integer getSubGroupID() {
		return subGroupID;
	}

	public void setSubGroupID(Integer subGroupID) {
		this.subGroupID = subGroupID;
	}

	public String getProgramTypeCodeID() {
		return programTypeCodeID;
	}

	public void setProgramTypeCodeID(String programTypeCodeID) {
		this.programTypeCodeID = programTypeCodeID;
	}

	public String getGroupNumber() {
		return groupNumber;
	}

	public void setGroupNumber(String groupNumber) {
		this.groupNumber = groupNumber;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public String getSiteNumber() {
		return siteNumber;
	}

	public void setSiteNumber(String siteNumber) {
		this.siteNumber = siteNumber;
	}

	public String getSiteName() {
		return siteName;
	}

	public void setSiteName(String siteName) {
		this.siteName = siteName;
	}

	public Integer getActivityID() {
		return activityID;
	}

	public void setActivityID(Integer activityID) {
		this.activityID = activityID;
	}

	public Integer getProgramAdditionalInfoAddRemove() {
		return programAdditionalInfoAddRemove;
	}

	public void setProgramAdditionalInfoAddRemove(Integer programAdditionalInfoAddRemove) {
		this.programAdditionalInfoAddRemove = programAdditionalInfoAddRemove;
	}
}
