/* $Id$ */

package com.healthpartners.app.bpm.dao;

import com.healthpartners.app.bpm.dto.BPMAuditRecord;
import org.springframework.dao.DataAccessException;

/**
 * Inserts the bpm audit log record into the bpm audit history table.
 * 
 * @author tjquist
 */
public interface AuditLogDAO {

	/**
	 * Insert the specified <code>bpm Audit Record</code>.
	 * 
	 * @param BPMAuditRecord
	 * @return the audit log id
	 * @throws DataAccessException
	 *             when a database-related error is encountered
	 */
	public Integer insertAuditLog(BPMAuditRecord BPMAuditRecord)
			throws DataAccessException;
}