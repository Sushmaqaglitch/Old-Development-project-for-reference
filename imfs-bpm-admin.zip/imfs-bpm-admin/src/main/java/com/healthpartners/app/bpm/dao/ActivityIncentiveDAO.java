package com.healthpartners.app.bpm.dao;

import com.healthpartners.app.bpm.dto.*;
import com.healthpartners.app.bpm.exception.BPMException;
import org.springframework.dao.DataAccessException;

import java.util.Collection;


public interface ActivityIncentiveDAO {
	Collection<ActivityIncentiveRequirement> getProgramActivityIncentiveRequirements(Integer programID, Integer incentiveOptionID) throws BPMException, DataAccessException;

	Integer insertIncentiveRequirement(ActivityIncentiveRequirement pIncentiveRequirement, String pUserID) throws DataAccessException;

	Integer insertActivityIncentiveDetail(ActivityIncentiveDetail lActivityIncentiveDetail, String pUserID);

	Integer insertIncentiveParticipant(IncentiveParticipantRelationship pIncentiveParticipantRelationship, String pUserID) throws DataAccessException;

    Collection<ProgramActivityIncentiveSummary> getProgramActivityIncentiveSummaryWithRequirements(Integer programID) throws BPMException, DataAccessException;

	int updateActivityIncentiveDetailDirectly(ActivityIncentiveDetail pActivityIncentiveDetail, String userID) throws DataAccessException;

	int updateIncentiveParticipant(IncentiveParticipantRelationship lIncentiveParticipantRelationship, String userID) throws DataAccessException;

	int deleteIncentiveParticipantByID(Integer activityIncentiveID) throws DataAccessException;

	int deleteIncentiveParticipant(Integer pBusinessProgramID, Integer pIncentiveOptionID) throws DataAccessException;

	int deleteActivityIncentiveDetail(Integer pBusinessProgramID, Integer pIncentiveOptionID) throws DataAccessException;

	int deleteIncentiveRequirement(Integer pBusinessProgramID, Integer pIncentiveOptionID) throws DataAccessException;
}
