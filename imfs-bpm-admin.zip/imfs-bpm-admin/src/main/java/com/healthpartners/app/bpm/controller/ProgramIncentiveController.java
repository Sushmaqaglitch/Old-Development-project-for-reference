package com.healthpartners.app.bpm.controller;

import com.healthpartners.app.bpm.common.BPMAdminConstants;
import com.healthpartners.app.bpm.common.BPMAdminUtils;
import com.healthpartners.app.bpm.dto.*;
import com.healthpartners.app.bpm.exception.BPMException;
import com.healthpartners.app.bpm.form.SaveProgramActivitySiteForm;
import com.healthpartners.app.bpm.form.SaveProgramIncentiveForm;
import com.healthpartners.app.bpm.iface.BusinessProgramService;
import com.healthpartners.app.bpm.iface.MemberService;
import com.healthpartners.service.bpm.common.BPMConstants;
import jakarta.servlet.http.HttpServletRequest;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.view.RedirectView;

import java.sql.SQLIntegrityConstraintViolationException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

import static org.apache.commons.lang.exception.ExceptionUtils.getStackTrace;

@Controller
public class ProgramIncentiveController extends BaseController implements Validator {

    protected final Log logger = LogFactory.getLog(getClass());

    private SimpleDateFormat fmt = new SimpleDateFormat(BPMAdminConstants.HP_BPM_ADMIN_UI_COMMON_DATE_FORMAT);
    
    private final BusinessProgramService businessProgramService;

    private final MemberService memberService;

    public ProgramIncentiveController(BusinessProgramService businessProgramService, MemberService memberService) {
        this.businessProgramService = businessProgramService;
        this.memberService = memberService;
    }

    @PostMapping(value = "/saveProgramIncentive", params = "cancel")
    public RedirectView submitCancelEditProgram(@ModelAttribute("saveProgramIncentiveForm") SaveProgramIncentiveForm form, RedirectAttributes ra) {
        ra.addFlashAttribute("groupNumber", getUserSession().getGroupNo());
        String url = "viewProgram?programID=" + form.getProgramID();
        return new RedirectView(url);
    }

    @PostMapping(value = "/saveProgramIncentive")
    public String submitActivityProgram(@ModelAttribute("saveProgramIncentiveForm") SaveProgramIncentiveForm form, ModelMap modelMap, BindingResult result, HttpServletRequest request, RedirectAttributes ra) throws Exception {
        try {
            if (ACTION_REFRESH_PAGE.equals(form.getActionType())) {
                populateFromForm(form);
                populateRequest(modelMap);
                return "programIncentives";
            } else if (ACTION_REMOVE.equals(form.getActionType())) {
                removeProgramIncentive(form, result, modelMap, request);
            } else if(ACTION_ADD.equals(form.getActionType())) {
                addProgramIncentive(form, result, modelMap);
            } else if (ACTION_SAVE.equals(form.getActionType()) || ACTION_SAVE_TO_ALL_SITES.equals(form.getActionType()) || ACTION_SAVE_TO_SELECTED.equals(form.getActionType())) {
                validate(form, result);

                if (result.hasErrors()) {
                    populateRequest(modelMap);
                    populateFromForm(form);
                    populateRequest(modelMap);
                    return "programIncentives";
                } else {
                    return performSave(modelMap, ra, form);
                }
            }
            if (result.hasErrors()) {
                populateFromForm(form);
                populateRequest(modelMap);
                return "programIncentives";
            }
        } catch (Exception e) {
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
            createErrorMessageOnModel(modelMap, getStackTrace(e));
        }

        // Add package also forwards to the same jsp.
        return "programIncentives";
    }

    private void removeProgramIncentive(SaveProgramIncentiveForm form, Errors errors, ModelMap modelMap, HttpServletRequest request) {
        Integer lIncentiveOptionID = form.getProgramIncentiveAddRemove();
        ArrayList<IncentiveOption> lIncentiveOptions = getUserSession().getActiveIncentiveOptions();

        if (lIncentiveOptions == null) {
            lIncentiveOptions = getUserSession().getIncentiveOptions();
        }

        ArrayList<ProgramIncentiveOption> lProgramIncentiveOptions = getUserSession().getProgramIncentiveOptions();

        boolean lIncentiveOptionUsed = checkIfIncentiveOptionUsed(lIncentiveOptionID);

        if (lIncentiveOptionUsed) {
            String lIncentiveOptionName = "";
            int i = 0;
            for (ProgramIncentiveOption lProgramIncentiveOption : lProgramIncentiveOptions) {
                if (lProgramIncentiveOption.getProgramIncentiveOptionID().intValue() == lIncentiveOptionID.intValue()) {
                    lIncentiveOptionName = lProgramIncentiveOption.getIncentiveOption().getIncentiveOptionName();
                    break;
                }
                i++;
            }
            createActionMessagesOnModel(modelMap, "errors.cannotBeDeleted", new Object[]{lIncentiveOptionName});
            getValidationSupport().addValidationFailureMessage("incentiveOptionNames["+i+"]", errors, "errors.cannotBeDeleted", new Object[]{lIncentiveOptionName});

            populateRequest(modelMap);
            modelMap.put("programIncentiveOptions", lProgramIncentiveOptions);
            modelMap.put("incentiveOptions", getUserSession().getActiveIncentiveOptions());
            return;
        }

        // Find the ProgramIncentiveOption whose ID matches the one selected.
        for (int i = 0; i < lProgramIncentiveOptions.size(); i++) {
            ProgramIncentiveOption lProgramIncentiveOption = (ProgramIncentiveOption) lProgramIncentiveOptions.get(i);
            // Once the ID is found, remove the Incentive from the Program Incentive Options
            // and add it back to the list of Available Incentives.
            if (lProgramIncentiveOption.getProgramIncentiveOptionID().intValue() == lIncentiveOptionID.intValue()) {
                lIncentiveOptions.add(lProgramIncentiveOption.getIncentiveOption());
                getUserSession().getDeletedProgramIncentiveOptions().add(lProgramIncentiveOption);
                lProgramIncentiveOptions.remove(i);
                break;
            }
        }

        populateRequest(modelMap);
        modelMap.put("programIncentiveOptions", lProgramIncentiveOptions);
        modelMap.put("incentiveOptions", getUserSession().getActiveIncentiveOptions());
    }

    private void addProgramIncentive(SaveProgramIncentiveForm form, Errors errors, ModelMap modelMap) {
        // The ID of the Incentive Option that was selected.
        Integer lIncentiveOptionID = form.getProgramIncentiveAddRemove();

        ArrayList<IncentiveOption> lIncentiveOptions = getUserSession().getIncentiveOptions();
        ArrayList<ProgramIncentiveOption> lProgramIncentiveOptions = getUserSession().getProgramIncentiveOptions();

        ProgramIncentiveOption lProgramIncentiveOption = new ProgramIncentiveOption();

        lProgramIncentiveOption.setProgramIncentiveOptionID(0);

        lProgramIncentiveOption.setEffectiveDate(getUserSession().getBusinessProgram().getQualificationWindowStartDate());
        lProgramIncentiveOption.setEndDate(getUserSession().getBusinessProgram().getEndDate());
        lProgramIncentiveOption.setCompletionDeadlineDate(getUserSession().getBusinessProgram().getQualificationWindowEndDate());

        // ExtraView 20163: Set Activation Date to Program End Date less 45 days.
        // For some odd reason, the minus wasn't working with number greater than 20.
        // So subtract 15 days 3 times.
        // EV73098 - Commenting out this block of code due to less groups offering
        // preferred benefit as an incentive.  Default to program end date.
		/*java.sql.Date lActivationDate = new java.sql.Date(System.currentTimeMillis());
		lActivationDate.setTime(sessionBean.getBusinessProgram().getEndDate().getTime() -
				(BPMAdminConstants.BPM_ADMIN_INCENTIVE_ACTIVATION_DAYS * 24 * 3600 * 1000));
		lActivationDate.setTime(lActivationDate.getTime() -
				(BPMAdminConstants.BPM_ADMIN_INCENTIVE_ACTIVATION_DAYS * 24 * 3600 * 1000));
		lActivationDate.setTime(lActivationDate.getTime() -
				(BPMAdminConstants.BPM_ADMIN_INCENTIVE_ACTIVATION_DAYS * 24 * 3600 * 1000));
		lProgramIncentiveOption.setActivationDate(lActivationDate);*/
        //EV73098
        lProgramIncentiveOption.setActivationDate(getUserSession().getBusinessProgram().getEndDate());

        // ExtraView 20163: Set Delivery Date to Program End Date plus 1 day.
        java.sql.Date lDeliveryDate = new java.sql.Date(System.currentTimeMillis());
        lDeliveryDate.setTime(getUserSession().getBusinessProgram().getEndDate().getTime() + (1 * 24 * 3600 * 1000));

        lProgramIncentiveOption.setDeliveryDate(lDeliveryDate);

        lProgramIncentiveOption.setSortOrder(0);

        lProgramIncentiveOption.setIncentiveOptionStatusCodeID(0);
        lProgramIncentiveOption.setIncentiveOptionStatusCode("select");

        lProgramIncentiveOption.setIncentiveFulfillmentRoutingCodeID(0);
        lProgramIncentiveOption.setIncentiveFulfillmentCode("select");

        lProgramIncentiveOption.setIncentiveReportNameCodeID(0);
        lProgramIncentiveOption.setIncentiveReportNameCode("select");

        lProgramIncentiveOption.setIncentedStatusTypeCodeID(0);
        lProgramIncentiveOption.setIncentedStatusTypeCode("select");

        Collection<LookUpValueCode> incentiveStatusCodesLUV = null;

        LookUpValueCode luvUnitTypeCodeNONE = null;
        try {
            luvUnitTypeCodeNONE = memberService.getLUVCodeByGroupNValue(BPMAdminConstants.BPM_LUV_INCENTIVE_OPTN_UNIT_TYPE, BPMAdminConstants.BPM_IO_UNIT_TYPE_NONE);
            lProgramIncentiveOption.setUnitTypeCodeID(luvUnitTypeCodeNONE.getLuvId());
            lProgramIncentiveOption.setUnitTypeDesc(luvUnitTypeCodeNONE.getLuvDesc());
        } catch (Exception e) {
            logger.error("Could not retrieve Incentive Option Unit NONE from luv table");
            lProgramIncentiveOption.setUnitTypeCodeID(0);
            lProgramIncentiveOption.setUnitTypeDesc("select");
        }

        lProgramIncentiveOption.setIncentiveRuleTypeCodeID(0);
        lProgramIncentiveOption.setIncentiveRuleTypeCode("select");

        lProgramIncentiveOption.setParticipationGroupID(0);
        lProgramIncentiveOption.setParticipationGroupName("select");

        lProgramIncentiveOption.setIncentiveOptionRewardCardID(0);
        lProgramIncentiveOption.setIncentiveOptionRewardCardName("select");

        lProgramIncentiveOption.setRunFrequencyID(0);
        lProgramIncentiveOption.setRunFrequencyValue("select");

        lProgramIncentiveOption.setPackageRuleGroupID(0);
        lProgramIncentiveOption.setPackageRuleGroupName("select");

        lProgramIncentiveOption.setDeliveryInfoID(0);
        lProgramIncentiveOption.setDeliveryInfoValue("select");

        lProgramIncentiveOption.setNewHireDate(getUserSession().getBusinessProgram().getEmployerGroup().getNewHireDate());

        // Find the IncentiveOption whose ID matches the one selected.
        for (int i = 0; i < lIncentiveOptions.size(); i++) {
            IncentiveOption lIncentiveOption = (IncentiveOption) lIncentiveOptions.get(i);
            // Once the ID is found, add the Incentive Option to the Program Incentive Options.
            if (lIncentiveOption.getIncentiveOptionID().intValue() == lIncentiveOptionID.intValue()) {
                lProgramIncentiveOption.setIncentiveOption(lIncentiveOption);
                lProgramIncentiveOption.setIncentiveOptionInfo(lIncentiveOption.getIncentiveOptionName());

                lProgramIncentiveOptions.add(lProgramIncentiveOption);
                lIncentiveOptions.remove(i);
                break;
            }
        }

        populateSaveProgramIncentiveFormArrays(form, lProgramIncentiveOptions);
        populateRequest(modelMap);
        modelMap.put("programIncentiveOptions", lProgramIncentiveOptions);
    }

    private void populateSaveProgramIncentiveFormArrays(SaveProgramIncentiveForm saveProgramIncentiveForm, ArrayList<ProgramIncentiveOption> lProgramIncentiveOptions) {
        String[] incentiveOptionInfos = new String[lProgramIncentiveOptions.size()];
        String[] incentiveOptionAddInfos = new String[lProgramIncentiveOptions.size()];
        Integer[] deliveryInfoIDs = new Integer[lProgramIncentiveOptions.size()];
        Integer[] participationGroupIDs = new Integer[lProgramIncentiveOptions.size()];
        String[] programIncentiveOptionEffDates = new String[lProgramIncentiveOptions.size()];
        String[] programIncentiveOptionEnrolDeadlineDates = new String[lProgramIncentiveOptions.size()];
        String[] programIncentiveOptionComplDeadlineDates = new String[lProgramIncentiveOptions.size()];
        String[] programIncentiveOptionEndDates = new String[lProgramIncentiveOptions.size()];
        String[] programIncentiveOptionActDates = new String[lProgramIncentiveOptions.size()];
        String[] programIncentiveOptionDelDates = new String[lProgramIncentiveOptions.size()];
        String[] programIncentiveOptionSortOrders = new String[lProgramIncentiveOptions.size()];
        String[] closeDates = new String[lProgramIncentiveOptions.size()];
        String[] creationDates = new String[lProgramIncentiveOptions.size()];
        Integer[] programIncentiveOptionStatusIDs = new Integer[lProgramIncentiveOptions.size()];
        Integer[] incentiveRuleTypeCodeIDs = new Integer[lProgramIncentiveOptions.size()];
        Integer[] programIncentiveReportNameIDs = new Integer[lProgramIncentiveOptions.size()];
        Integer[] programIncentiveFulfillReqIDs = new Integer[lProgramIncentiveOptions.size()];
        Integer[] incentedStatusTypeCodeIDs = new Integer[lProgramIncentiveOptions.size()];
        Integer[] packageRuleGroupIDs = new Integer[lProgramIncentiveOptions.size()];
        Integer[] unitTypeCodeIDs = new Integer[lProgramIncentiveOptions.size()];
        String[] newHireDates = new String[lProgramIncentiveOptions.size()];
        Integer[] incentiveOptionRewardCardIDs = new Integer[lProgramIncentiveOptions.size()];
        Integer[] rewardRunFreqIDs = new Integer[lProgramIncentiveOptions.size()];
        String[] activityCompletionPeriods = new String[lProgramIncentiveOptions.size()];
        String[] familyCaps = new String[lProgramIncentiveOptions.size()];
        String[] participantCap = new String[lProgramIncentiveOptions.size()];

        int i = 0;
        for (ProgramIncentiveOption programIncentiveOption : lProgramIncentiveOptions) {
            incentiveOptionInfos[i] = programIncentiveOption.getIncentiveOptionInfo();
            incentiveOptionAddInfos[i] = programIncentiveOption.getAdditionalInfo();
            deliveryInfoIDs[i] = programIncentiveOption.getDeliveryInfoID();
            participationGroupIDs[i] = programIncentiveOption.getParticipationGroupID();
            programIncentiveOptionEffDates[i] = programIncentiveOption.getEffectiveDate() != null ? fmt.format(programIncentiveOption.getEffectiveDate()) : "";
            programIncentiveOptionEnrolDeadlineDates[i] = programIncentiveOption.getEnrollmentDeadlineDate() != null ? fmt.format(programIncentiveOption.getEnrollmentDeadlineDate()) : "";
            programIncentiveOptionComplDeadlineDates[i] = programIncentiveOption.getCompletionDeadlineDate() != null ? fmt.format(programIncentiveOption.getCompletionDeadlineDate()) : "";
            programIncentiveOptionEndDates[i] = programIncentiveOption.getEndDate() != null ? fmt.format(programIncentiveOption.getEndDate()) : "";
            programIncentiveOptionActDates[i] = programIncentiveOption.getActivationDate() != null ? fmt.format(programIncentiveOption.getActivationDate()) : "";
            programIncentiveOptionDelDates[i] = programIncentiveOption.getDeliveryDate() != null ? fmt.format(programIncentiveOption.getDeliveryDate()) : "";
            closeDates[i] = programIncentiveOption.getIncentiveOption().getCloseDate() != null ? fmt.format(programIncentiveOption.getIncentiveOption().getCloseDate()) : "";
            creationDates[i] = programIncentiveOption.getIncentiveOption().getCreationDate() != null ? fmt.format(programIncentiveOption.getIncentiveOption().getCreationDate()) : "";
            newHireDates[i] = programIncentiveOption.getNewHireDate() != null ? fmt.format(programIncentiveOption.getNewHireDate()) : "";

            programIncentiveOptionSortOrders[i] = String.valueOf(programIncentiveOption.getSortOrder());

            programIncentiveOptionStatusIDs[i] = programIncentiveOption.getIncentiveOptionStatusCodeID();
            incentiveRuleTypeCodeIDs[i] = programIncentiveOption.getIncentiveRuleTypeCodeID();
            programIncentiveReportNameIDs[i] = programIncentiveOption.getIncentiveReportNameCodeID();
            programIncentiveFulfillReqIDs[i] = programIncentiveOption.getIncentiveFulfillmentRoutingCodeID();
            incentedStatusTypeCodeIDs[i] = programIncentiveOption.getIncentedStatusTypeCodeID();
            packageRuleGroupIDs[i] = programIncentiveOption.getPackageRuleGroupID();
            unitTypeCodeIDs[i] = programIncentiveOption.getUnitTypeCodeID();
            incentiveOptionRewardCardIDs[i] = programIncentiveOption.getIncentiveOptionRewardCardID();
            rewardRunFreqIDs[i] = programIncentiveOption.getRunFrequencyID();
            activityCompletionPeriods[i] = programIncentiveOption.getActivityCompletionPeriod();
            familyCaps[i] = programIncentiveOption.getFamilyCap();
            participantCap[i] = programIncentiveOption.getParticipantCap();
            i++;
        }

        saveProgramIncentiveForm.setIncentiveOptionInfos(incentiveOptionInfos);
        saveProgramIncentiveForm.setIncentiveOptionAddInfos(incentiveOptionAddInfos);
        saveProgramIncentiveForm.setDeliveryInfoIDs(deliveryInfoIDs);
        saveProgramIncentiveForm.setParticipationGroupIDs(participationGroupIDs);
        saveProgramIncentiveForm.setProgramIncentiveOptionEffDates(programIncentiveOptionEffDates);
        saveProgramIncentiveForm.setProgramIncentiveOptionEnrolDeadlineDates(programIncentiveOptionEnrolDeadlineDates);
        saveProgramIncentiveForm.setProgramIncentiveOptionComplDeadlineDates(programIncentiveOptionComplDeadlineDates);
        saveProgramIncentiveForm.setProgramIncentiveOptionEndDates(programIncentiveOptionEndDates);
        saveProgramIncentiveForm.setProgramIncentiveOptionActDates(programIncentiveOptionActDates);
        saveProgramIncentiveForm.setProgramIncentiveOptionDelDates(programIncentiveOptionDelDates);
        saveProgramIncentiveForm.setProgramIncentiveOptionSortOrders(programIncentiveOptionSortOrders);
        saveProgramIncentiveForm.setCloseDates(closeDates);
        saveProgramIncentiveForm.setCreationDates(creationDates);
        saveProgramIncentiveForm.setProgramIncentiveOptionStatusIDs(programIncentiveOptionStatusIDs);
        saveProgramIncentiveForm.setIncentiveRuleTypeCodeIDs(incentiveRuleTypeCodeIDs);
        saveProgramIncentiveForm.setProgramIncentiveReportNameIDs(programIncentiveReportNameIDs);
        saveProgramIncentiveForm.setProgramIncentiveFulfillReqIDs(programIncentiveFulfillReqIDs);
        saveProgramIncentiveForm.setIncentedStatusTypeCodeIDs(incentedStatusTypeCodeIDs);
        saveProgramIncentiveForm.setPackageRuleGroupIDs(packageRuleGroupIDs);
        saveProgramIncentiveForm.setUnitTypeCodeIDs(unitTypeCodeIDs);
        saveProgramIncentiveForm.setNewHireDates(newHireDates);
        saveProgramIncentiveForm.setIncentiveOptionRewardCardIDs(incentiveOptionRewardCardIDs);
        saveProgramIncentiveForm.setRewardRunFreqIDs(rewardRunFreqIDs);
        saveProgramIncentiveForm.setActivityCompletionPeriods(activityCompletionPeriods);
        saveProgramIncentiveForm.setFamilyCap(familyCaps);
        saveProgramIncentiveForm.setParticipantCap(participantCap);
    }

    protected void populateRequest(ModelMap modelMap) {
        modelMap.put("businessProgram", getUserSession().getBusinessProgram());
        modelMap.put("incentiveOptions", getUserSession().getActiveIncentiveOptions());
        modelMap.put("incentiveStatuses", getUserSession().getIncentiveOptionStatuses());
        modelMap.put("incentedStatusCodes", getUserSession().getIncentedStatusCodes());
        modelMap.put("incentiveFulfillTypes", getUserSession().getIncentiveFulfillTypes());
        modelMap.put("incentiveReportNameTypes", getUserSession().getIncentiveReportNameTypes());
        modelMap.put("luvIdSendToMembership", getUserSession().getLuvIdSendToMembership());
        modelMap.put("luvIdSendToPremiumBilling", getUserSession().getLuvIdSendToPremiumBilling());
        modelMap.put("additionalInfos", getUserSession().getAdditionalInfos());
        modelMap.put("eligibleActivities", getUserSession().getEligibleActivities());
        modelMap.put("incentiveEnrollmentRuleCodes", getUserSession().getIncentiveEnrollmentRuleCodes());
        modelMap.put("programCheckmarks", getUserSession().getProgramCheckmarks());
        modelMap.put("programIncentiveOptions", getUserSession().getProgramIncentiveOptions());
        modelMap.put("participationGroups", getUserSession().getParticipationGroups());
        modelMap.put("incentiveOptionRewardCardTypes",getUserSession().getIncentiveOptionRewardCardTypes());
        modelMap.put("luvBatchRunFrequencyTypes",getUserSession().getRewardRunFrequencyTypes());
        modelMap.put("luvIdSendToCDHP", getUserSession().getLuvIdSendToCDHP());
        modelMap.put("unitCodeTypes",getUserSession().getUnitCodeTypes());
        modelMap.put("changeLogList", getUserSession().getProgramChangeLogList());
        modelMap.put("benefitPackages", getUserSession().getBenefitPackages());
        modelMap.put("extendedAuthCodes", getUserSession().getExtendedAuthCodes());
        modelMap.put("packageRuleGroups", getUserSession().getIncentivePackageRuleGroups());
        modelMap.put("luvDeliveryInfoTypes", getUserSession().getDeliveryInfoTypes());
        BPMAdminUtils.populateProgramCheckmarkDefinition(getUserSession());
        modelMap.put("qualificationCheckmarks", getUserSession().getQualificationCheckmarks());
    }

    private void populateFromForm(SaveProgramIncentiveForm pSaveProgramIncentiveForm) {
        Integer[] incentiveOptionIDs = pSaveProgramIncentiveForm.getIncentiveOptionIDs();
        ArrayList<ProgramIncentiveOption> lProgramIncentiveOptions = getUserSession().getProgramIncentiveOptions();

        if (incentiveOptionIDs != null && incentiveOptionIDs.length > 0) {
            for (int i = 0; i < incentiveOptionIDs.length; i++) {
                for (int j = 0; j < lProgramIncentiveOptions.size(); j++) {
                    ProgramIncentiveOption lProgramIncentiveOption = lProgramIncentiveOptions.get(j);

                    if (lProgramIncentiveOption.getIncentiveOption().getIncentiveOptionID().intValue() == incentiveOptionIDs[i].intValue()) {
                        lProgramIncentiveOption.setAdditionalInfo(pSaveProgramIncentiveForm.getIncentiveOptionAddInfos()[i]);
                        lProgramIncentiveOption.setIncentiveOptionInfo(pSaveProgramIncentiveForm.getIncentiveOptionInfos()[i]);

                        lProgramIncentiveOption.setIncentiveOptionStatusCodeID(pSaveProgramIncentiveForm.getProgramIncentiveOptionStatusIDs()[i]);
                        ArrayList<LookUpValueCode> lIncentiveOptionStatuses = getUserSession().getIncentiveOptionStatuses();
                        for (LookUpValueCode lLookUpValueCode : lIncentiveOptionStatuses) {
                            if (lLookUpValueCode.getLuvId().intValue() == lProgramIncentiveOption.getIncentiveOptionStatusCodeID().intValue()) {
                                lProgramIncentiveOption.setIncentiveOptionStatusCode(lLookUpValueCode.getLuvVal());
                            }
                        }

                        lProgramIncentiveOption.setIncentedStatusTypeCodeID(pSaveProgramIncentiveForm.getIncentedStatusTypeCodeIDs()[i]);
                        ArrayList<LookUpValueCode> lIncentedStatusCodes = getUserSession().getIncentedStatusCodes();
                        for (LookUpValueCode lLookUpValueCode : lIncentedStatusCodes) {
                            if (lLookUpValueCode.getLuvId().intValue() == lProgramIncentiveOption.getIncentedStatusTypeCodeID().intValue()) {
                                lProgramIncentiveOption.setIncentedStatusTypeCode(lLookUpValueCode.getLuvVal());
                            }
                        }

                        lProgramIncentiveOption.setIncentiveFulfillmentRoutingCodeID(pSaveProgramIncentiveForm.getProgramIncentiveFulfillReqIDs()[i]);

                        lProgramIncentiveOption.setIncentiveReportNameCodeID(pSaveProgramIncentiveForm.getProgramIncentiveReportNameIDs()[i]);
                        ArrayList<LookUpValueCode> lReportNameTypes = getUserSession().getIncentiveReportNameTypes();
                        for (LookUpValueCode lLookUpValueCode : lReportNameTypes) {
                            if (lLookUpValueCode.getLuvId().intValue() == lProgramIncentiveOption.getIncentiveReportNameCodeID().intValue()) {
                                lProgramIncentiveOption.setIncentiveReportNameCode(lLookUpValueCode.getLuvVal());
                            }
                        }

                        lProgramIncentiveOption.setIncentiveRuleTypeCodeID(pSaveProgramIncentiveForm.getIncentiveRuleTypeCodeIDs()[i]);


                        lProgramIncentiveOption.setParticipationGroupID(pSaveProgramIncentiveForm.getParticipationGroupIDs()[i]);
                        ArrayList<ParticipationGroup> lParticipationGroups = (ArrayList<ParticipationGroup>) getUserSession().getParticipationGroups();
                        for (ParticipationGroup lParticipationGroup : lParticipationGroups) {
                            if (lParticipationGroup.getParticipationGroupID().intValue() == lProgramIncentiveOption.getParticipationGroupID().intValue()) {
                                lProgramIncentiveOption.setParticipationGroupName(lParticipationGroup.getParticipationGroupName());
                                lProgramIncentiveOption.setParticipationGroupInfo(lParticipationGroup.getParticipationGroupInfo());
                            }
                        }

                        ArrayList<LookUpValueCode> lIncentiveFulfillTypes = getUserSession().getIncentiveFulfillTypes();
                        for (LookUpValueCode lLookUpValueCode : lIncentiveFulfillTypes) {
                            if (lLookUpValueCode.getLuvId().intValue() == lProgramIncentiveOption.getIncentiveFulfillmentRoutingCodeID().intValue()) {
                                lProgramIncentiveOption.setIncentiveFulfillmentCode(lLookUpValueCode.getLuvVal());
                            }
                        }

                        ArrayList<LookUpValueCode> lIncentiveReportNameTypes = getUserSession().getIncentiveReportNameTypes();
                        for (LookUpValueCode lLookUpValueCode : lIncentiveReportNameTypes) {
                            if (lLookUpValueCode.getLuvId().intValue() == lProgramIncentiveOption.getIncentiveReportNameCodeID().intValue()) {
                                lProgramIncentiveOption.setIncentiveReportNameCode(lLookUpValueCode.getLuvVal());
                            }
                        }

                        ArrayList<LookUpValueCode> lIncentiveEnrollmentRuleCodes = getUserSession().getIncentiveEnrollmentRuleCodes();
                        for (LookUpValueCode lLookUpValueCode : lIncentiveEnrollmentRuleCodes) {
                            if (lLookUpValueCode.getLuvId().intValue() == lProgramIncentiveOption.getIncentiveRuleTypeCodeID().intValue()) {
                                lProgramIncentiveOption.setIncentiveRuleTypeCode(lLookUpValueCode.getLuvVal());
                            }
                        }


                        if (pSaveProgramIncentiveForm.getParticipantCap()[i] != null) {
                            lProgramIncentiveOption.setParticipantCap(pSaveProgramIncentiveForm.getParticipantCap()[i]);
                        }
                        if (pSaveProgramIncentiveForm.getFamilyCap()[i] != null) {
                            lProgramIncentiveOption.setFamilyCap(pSaveProgramIncentiveForm.getFamilyCap()[i]);
                        }

                        if (pSaveProgramIncentiveForm.getUnitTypeCodeIDs()[i] != null) {
                            lProgramIncentiveOption.setUnitTypeCodeID(pSaveProgramIncentiveForm.getUnitTypeCodeIDs()[i]);
                        }

                        ArrayList<LookUpValueCode> lUnitCodeTypes = getUserSession().getUnitCodeTypes();
                        for (int k = 0; k < lUnitCodeTypes.size(); k++) {
                            if (lUnitCodeTypes.get(k).getLuvId().intValue() == lProgramIncentiveOption.getUnitTypeCodeID().intValue()) {
                                lProgramIncentiveOption.setUnitTypeDesc(lUnitCodeTypes.get(k).getLuvVal());
                            }
                        }

                        if (pSaveProgramIncentiveForm.getProgramIncentiveOptionEffDates()[i] != null) {
                            lProgramIncentiveOption.setEffectiveDate(BPMAdminUtils.convertStringToSqlDate(pSaveProgramIncentiveForm.getProgramIncentiveOptionEffDates()[i], BPMAdminConstants.HP_BPM_ADMIN_UI_COMMON_DATE_FORMAT));
                        }
                        if (pSaveProgramIncentiveForm.getProgramIncentiveOptionEndDates()[i] != null) {
                            lProgramIncentiveOption.setEndDate(BPMAdminUtils.convertStringToSqlDate(pSaveProgramIncentiveForm.getProgramIncentiveOptionEndDates()[i], BPMAdminConstants.HP_BPM_ADMIN_UI_COMMON_DATE_FORMAT));
                        }
                        if (pSaveProgramIncentiveForm.getProgramIncentiveOptionActDates()[i] != null) {
                            lProgramIncentiveOption.setActivationDate(BPMAdminUtils.convertStringToSqlDate(pSaveProgramIncentiveForm.getProgramIncentiveOptionActDates()[i], BPMAdminConstants.HP_BPM_ADMIN_UI_COMMON_DATE_FORMAT));
                        }
                        if (pSaveProgramIncentiveForm.getProgramIncentiveOptionDelDates()[i] != null) {
                            lProgramIncentiveOption.setDeliveryDate(BPMAdminUtils.convertStringToSqlDate(pSaveProgramIncentiveForm.getProgramIncentiveOptionDelDates()[i], BPMAdminConstants.HP_BPM_ADMIN_UI_COMMON_DATE_FORMAT));
                        }
                        if (pSaveProgramIncentiveForm.getProgramIncentiveOptionEnrolDeadlineDates()[i] != null) {
                            lProgramIncentiveOption.setEnrollmentDeadlineDate(BPMAdminUtils.convertStringToSqlDate(pSaveProgramIncentiveForm.getProgramIncentiveOptionEnrolDeadlineDates()[i], BPMAdminConstants.HP_BPM_ADMIN_UI_COMMON_DATE_FORMAT));
                        }
                        if (pSaveProgramIncentiveForm.getProgramIncentiveOptionComplDeadlineDates()[i] != null) {
                            lProgramIncentiveOption.setCompletionDeadlineDate(BPMAdminUtils.convertStringToSqlDate(pSaveProgramIncentiveForm.getProgramIncentiveOptionComplDeadlineDates()[i], BPMAdminConstants.HP_BPM_ADMIN_UI_COMMON_DATE_FORMAT));
                        }

                        if (pSaveProgramIncentiveForm.getProgramIncentiveOptionSortOrders()[i] != null) {
                            lProgramIncentiveOption.setSortOrder(Integer.valueOf(pSaveProgramIncentiveForm.getProgramIncentiveOptionSortOrders()[i]));
                        }

                        ArrayList<IncentiveOptionRewardCard> lIncentiveOptionRewardCardTypes = getUserSession().getIncentiveOptionRewardCardTypes();
                        for (int k = 0; k < lIncentiveOptionRewardCardTypes.size(); k++) {
                            if (lIncentiveOptionRewardCardTypes.get(k).getIncentiveOptionRewardCardID().intValue() == lProgramIncentiveOption.getIncentiveOptionRewardCardID().intValue()) {
                                lProgramIncentiveOption.setIncentiveOptionRewardCardName(lIncentiveOptionRewardCardTypes.get(k).getIncentiveOptionRewardCardName());
                            }
                        }

                        ArrayList<LookUpValueCode> lRewardRunFrequencyTypes = getUserSession().getRewardRunFrequencyTypes();
                        for (int k = 0; k < lRewardRunFrequencyTypes.size(); k++) {
                            if (lRewardRunFrequencyTypes.get(k).getLuvId().intValue() == lProgramIncentiveOption.getRunFrequencyID().intValue()) {
                                lProgramIncentiveOption.setRunFrequencyValue(lRewardRunFrequencyTypes.get(k).getLuvVal());
                            }
                        }

                        lProgramIncentiveOption.setNewHireDate(BPMAdminUtils.getSqlDateFromString(pSaveProgramIncentiveForm.getNewHireDates()[i]));

                        lProgramIncentiveOption.setUnitTypeCodeID(pSaveProgramIncentiveForm.getUnitTypeCodeIDs()[i]);
                        ArrayList<LookUpValueCode> lUnitTypes = getUserSession().getUnitCodeTypes();
                        for (LookUpValueCode lUnitType : lUnitTypes) {
                            if (lUnitType.getLuvId().intValue() == lProgramIncentiveOption.getUnitTypeCodeID().intValue()) {
                                lProgramIncentiveOption.setUnitTypeCodeDesc(lUnitType.getLuvDesc());
                            }
                        }

                        lProgramIncentiveOption.setPackageRuleGroupID(pSaveProgramIncentiveForm.getPackageRuleGroupIDs()[i]);
                        ArrayList<IncentivePackageRuleGroup> lPackageRuleGroups = getUserSession().getIncentivePackageRuleGroups();
                        for (IncentivePackageRuleGroup lIncentivePackageRuleGroup : lPackageRuleGroups) {
                            if (lIncentivePackageRuleGroup.getIncentivePackageRuleGroupID().intValue() == lProgramIncentiveOption.getPackageRuleGroupID().intValue()) {
                                lProgramIncentiveOption.setPackageRuleGroupName(lIncentivePackageRuleGroup.getIncentivePackageRuleGroupName());
                            }
                        }

                        lProgramIncentiveOption.setDeliveryInfoID(pSaveProgramIncentiveForm.getDeliveryInfoIDs()[i]);
                        ArrayList<LookUpValueCode> lDeliveryInfoTypes = getUserSession().getDeliveryInfoTypes();
                        for (LookUpValueCode lDeliveryInfoType : lDeliveryInfoTypes) {
                            if (lDeliveryInfoType.getLuvId().intValue() == lProgramIncentiveOption.getDeliveryInfoID().intValue()) {
                                lProgramIncentiveOption.setDeliveryInfoValue(lDeliveryInfoType.getLuvDesc());
                            }
                        }
                    }
                }
            }
        }

        // Selected values have been stored in the ProgramIncentiveOptions.
        // Clear the form drop-down selections.
        for (int i = 0; i < pSaveProgramIncentiveForm.getIncentedStatusTypeCodeIDs().length; i++) {
            pSaveProgramIncentiveForm.getIncentedStatusTypeCodeIDs()[i] = null;
        }

        for (int i = 0; i < pSaveProgramIncentiveForm.getIncentiveRuleTypeCodeIDs().length; i++) {
            pSaveProgramIncentiveForm.getIncentiveRuleTypeCodeIDs()[i] = null;
        }

        for (int i = 0; i < pSaveProgramIncentiveForm.getParticipationGroupIDs().length; i++) {
            pSaveProgramIncentiveForm.getParticipationGroupIDs()[i] = null;
        }

        for (int i = 0; i < pSaveProgramIncentiveForm.getProgramIncentiveReportNameIDs().length; i++) {
            pSaveProgramIncentiveForm.getProgramIncentiveReportNameIDs()[i] = null;
        }


        for (int i = 0; i < pSaveProgramIncentiveForm.getProgramIncentiveFulfillReqIDs().length; i++) {
            pSaveProgramIncentiveForm.getProgramIncentiveFulfillReqIDs()[i] = null;
        }

        for (int i = 0; i < pSaveProgramIncentiveForm.getProgramIncentiveOptionStatusIDs().length; i++) {
            pSaveProgramIncentiveForm.getProgramIncentiveOptionStatusIDs()[i] = null;
        }

        for (int i = 0; i < pSaveProgramIncentiveForm.getIncentiveOptionRewardCardIDs().length; i++) {
            pSaveProgramIncentiveForm.getIncentiveOptionRewardCardIDs()[i] = null;
        }

        for (int i = 0; i < pSaveProgramIncentiveForm.getRewardRunFreqIDs().length; i++) {
            pSaveProgramIncentiveForm.getRewardRunFreqIDs()[i] = null;
        }
        for (int i = 0; i < pSaveProgramIncentiveForm.getUnitTypeCodeIDs().length; i++) {
            pSaveProgramIncentiveForm.getUnitTypeCodeIDs()[i] = null;
        }
        for (int i = 0; i < pSaveProgramIncentiveForm.getPackageRuleGroupIDs().length; i++) {
            pSaveProgramIncentiveForm.getPackageRuleGroupIDs()[i] = null;
        }

        for (int i = 0; i < pSaveProgramIncentiveForm.getDeliveryInfoIDs().length; i++) {
            pSaveProgramIncentiveForm.getDeliveryInfoIDs()[i] = null;
        }

    }

    protected boolean checkIfIncentiveOptionUsed(Integer pProgramIncentiveOptionID) {
        for (ProgramCheckmark lProgramCheckmark : getUserSession().getProgramCheckmarks()) {
            if (lProgramCheckmark.getProgramIncentiveOptionID().intValue() == pProgramIncentiveOptionID.intValue()) {
                return true;
            }
        }
        return false;
    }

    private String performSave(ModelMap modelMap, RedirectAttributes ra, SaveProgramIncentiveForm form) throws Exception {
        String pUserID = getUserSessionSupport().getAuthenticatedUsername();

        if (ACTION_SAVE.equals(form.getActionType())) {
            saveProgramIncentive(modelMap, ra, form, pUserID);
        } else if (ACTION_SAVE_TO_ALL_SITES.equals(form.getActionType())) {
            saveToAllSites(modelMap, ra, form, pUserID);
        } else if (ACTION_SAVE_TO_SELECTED.equals(form.getActionType())) {
            saveToSelectedSites(modelMap, form);
            return "programActivitySites";
        }

        // Redirect back to the viewProgram screen upon successful process of saves
        ra.addFlashAttribute("groupNumber", form.getGroupNumber());
        String url = "viewProgram?programID=" + form.getProgramID();
        return "redirect:" + url;
    }

    private void saveProgramIncentive(ModelMap modelMap, RedirectAttributes ra, SaveProgramIncentiveForm lSaveProgramIncentiveForm, String pUserID) throws SQLIntegrityConstraintViolationException, Exception {
        ArrayList<ProgramIncentiveOption> lProgramIncentiveOptions = new ArrayList<ProgramIncentiveOption>();
        Integer[] lIncentiveOptionIDs = lSaveProgramIncentiveForm.getIncentiveOptionIDs();

        if (lIncentiveOptionIDs != null && lIncentiveOptionIDs.length > 0) {
            for (int i = 0; i < lIncentiveOptionIDs.length; i++) {
                ProgramIncentiveOption lProgramIncentiveOption = new ProgramIncentiveOption();
                lProgramIncentiveOption.setProgramIncentiveOptionID(lSaveProgramIncentiveForm.getProgramIncentiveOptionIDs()[i]);

                IncentiveOption lIncentiveOption = new IncentiveOption();
                lIncentiveOption.setIncentiveOptionID(lIncentiveOptionIDs[i]);
                lProgramIncentiveOption.setIncentiveOption(lIncentiveOption);

                lProgramIncentiveOption.setBusinessProgramID(getUserSession().getBusinessProgram().getProgramID());
                lProgramIncentiveOption.setAdditionalInfo(lSaveProgramIncentiveForm.getIncentiveOptionAddInfos()[i]);
                lProgramIncentiveOption.setIncentiveOptionInfo(lSaveProgramIncentiveForm.getIncentiveOptionInfos()[i]);
                lProgramIncentiveOption.setEffectiveDate(BPMAdminUtils.getSqlDateFromString(lSaveProgramIncentiveForm.getProgramIncentiveOptionEffDates()[i]));
                lProgramIncentiveOption.setEndDate(BPMAdminUtils.getSqlDateFromString(lSaveProgramIncentiveForm.getProgramIncentiveOptionEndDates()[i]));
                lProgramIncentiveOption.setActivationDate(BPMAdminUtils.getSqlDateFromString(lSaveProgramIncentiveForm.getProgramIncentiveOptionActDates()[i]));
                lProgramIncentiveOption.setDeliveryDate(BPMAdminUtils.getSqlDateFromString(lSaveProgramIncentiveForm.getProgramIncentiveOptionDelDates()[i]));

                Integer sortOrder = BPMAdminUtils.convertStringToInteger(lSaveProgramIncentiveForm.getProgramIncentiveOptionSortOrders()[i]);

                lProgramIncentiveOption.setSortOrder(sortOrder);

                lProgramIncentiveOption.setIncentiveOptionStatusCodeID(lSaveProgramIncentiveForm.getProgramIncentiveOptionStatusIDs()[i]);
                lProgramIncentiveOption.setIncentiveFulfillmentRoutingCodeID(lSaveProgramIncentiveForm.getProgramIncentiveFulfillReqIDs()[i]);
                lProgramIncentiveOption.setIncentiveReportNameCodeID(lSaveProgramIncentiveForm.getProgramIncentiveReportNameIDs()[i]);
                lProgramIncentiveOption.setIncentedStatusTypeCodeID(lSaveProgramIncentiveForm.getIncentedStatusTypeCodeIDs()[i]);
                lProgramIncentiveOption.setParticipantCap(lSaveProgramIncentiveForm.getParticipantCap()[i]);
                lProgramIncentiveOption.setFamilyCap(lSaveProgramIncentiveForm.getFamilyCap()[i]);
                lProgramIncentiveOption.setEnrollmentDeadlineDate(BPMAdminUtils.getSqlDateFromString(lSaveProgramIncentiveForm.getProgramIncentiveOptionEnrolDeadlineDates()[i]));
                lProgramIncentiveOption.setCompletionDeadlineDate(BPMAdminUtils.getSqlDateFromString(lSaveProgramIncentiveForm.getProgramIncentiveOptionComplDeadlineDates()[i]));
                lProgramIncentiveOption.setIncentiveRuleTypeCodeID(lSaveProgramIncentiveForm.getIncentiveRuleTypeCodeIDs()[i]);
                lProgramIncentiveOption.setParticipationGroupID(lSaveProgramIncentiveForm.getParticipationGroupIDs()[i]);
                lProgramIncentiveOption.setIncentiveOptionRewardCardID(lSaveProgramIncentiveForm.getIncentiveOptionRewardCardIDs()[i]);
                lProgramIncentiveOption.setRunFrequencyID(lSaveProgramIncentiveForm.getRewardRunFreqIDs()[i]);
                if (lSaveProgramIncentiveForm.getActivityCompletionPeriods()[i] != null) {
                    lProgramIncentiveOption.setActivityCompletionPeriod(lSaveProgramIncentiveForm.getActivityCompletionPeriods()[i]);
                }

                lProgramIncentiveOption.getIncentiveOption().setIncentiveOptionID(lSaveProgramIncentiveForm.getIncentiveOptionIDs()[i]);
                lProgramIncentiveOption.setNewHireDate(BPMAdminUtils.getSqlDateFromString(lSaveProgramIncentiveForm.getNewHireDates()[i]));
                lProgramIncentiveOption.setUnitTypeCodeID(lSaveProgramIncentiveForm.getUnitTypeCodeIDs()[i]);
                lProgramIncentiveOption.setPackageRuleGroupID(lSaveProgramIncentiveForm.getPackageRuleGroupIDs()[i]);
                lProgramIncentiveOption.setDeliveryInfoID(lSaveProgramIncentiveForm.getDeliveryInfoIDs()[i]);

                lProgramIncentiveOptions.add(lProgramIncentiveOption);
            }
        }

        // The DAO will find existing ones for Update, and Insert new ones.
        businessProgramService.updateProgramIncentiveOption(lProgramIncentiveOptions, lSaveProgramIncentiveForm.getProgramID(), pUserID);

        // If the user removed any program incentives they will be in the deleted program incentive options
        // list. Delete those in the database.
        for (ProgramIncentiveOption lProgramIncentiveOption : getUserSession().getDeletedProgramIncentiveOptions()) {
            try {
                businessProgramService.deleteProgramIncentiveOption(lProgramIncentiveOption.getProgramIncentiveOptionID());
            } catch (SQLIntegrityConstraintViolationException scve) {
                logger.error("SQL Integrity Constraint Error detected: " + scve.getMessage());
                throw (scve);
            } catch (Exception e) {
                logger.error("Delete of program incentive option failed.  Exception error follows: " + e.getMessage());
                throw (e);
            }
        }

        lProgramIncentiveOptions.clear();
        lProgramIncentiveOptions = (ArrayList<ProgramIncentiveOption>) businessProgramService.getProgramIncentiveOptions(getUserSession().getBusinessProgram().getProgramID());

        populateRequest(modelMap);
        getUserSession().setProgramIncentiveOptions(lProgramIncentiveOptions);
        ra.addFlashAttribute("programIncentiveOptions", lProgramIncentiveOptions);
    }

    private void saveToAllSites(ModelMap modelMap, RedirectAttributes ra, SaveProgramIncentiveForm lSaveProgramIncentiveForm, String pUserID) throws Exception {
        ArrayList<ProgramIncentiveOption> lProgramIncentiveOptions = createIncentiveOptionListFromForm(lSaveProgramIncentiveForm);

        // The DAO will find existing ones for Update, and Insert new ones.
        businessProgramService.saveProgramIncentiveOptionsAllSites(getUserSession().getBusinessProgram(), lProgramIncentiveOptions, pUserID);

        lProgramIncentiveOptions.clear();
        lProgramIncentiveOptions = (ArrayList<ProgramIncentiveOption>) businessProgramService.getProgramIncentiveOptions(getUserSession().getBusinessProgram().getProgramID());

        populateRequest(modelMap);
        getUserSession().setProgramIncentiveOptions(lProgramIncentiveOptions);
        ra.addFlashAttribute("programIncentiveOptions", lProgramIncentiveOptions);
    }

    private void saveToSelectedSites(ModelMap modelMap, SaveProgramIncentiveForm lSaveProgramIncentiveForm) throws BPMException {
        if (getUserSession().getAvailableSites() != null) {
            getUserSession().getAvailableSites().clear();
        }

        if (getUserSession().getEmployerSubGroups() != null) {
            getUserSession().getEmployerSubGroups().clear();
        }

        ArrayList<ProgramIncentiveOption> lProgramIncentives = createIncentiveOptionListFromForm(lSaveProgramIncentiveForm);

        getUserSession().setProgramIncentiveOptions(lProgramIncentives);

        Collection<EmployerGroup> lSubGroups = businessProgramService.getBusinessProgramInSameYear(getUserSession().getBusinessProgram().getProgramID());

        modelMap.put("businessProgram", getUserSession().getBusinessProgram());
        modelMap.put("selectedSubGroups", lSubGroups);

        SaveProgramActivitySiteForm saveProgramActivitySiteForm = new SaveProgramActivitySiteForm();
        saveProgramActivitySiteForm.setSubGroupID(((ArrayList<EmployerGroup>) lSubGroups).get(0).getSubgroupID());
        modelMap.put("saveProgramActivitySiteForm", saveProgramActivitySiteForm);

        getUserSession().setEmployerSubGroups((ArrayList<EmployerGroup>) lSubGroups);
        getUserSession().setWhichSaveSelectedSite(WHICH_SAVE_SELECTED_SITES_INCENTIVES);
    }

    private ArrayList<ProgramIncentiveOption> createIncentiveOptionListFromForm(SaveProgramIncentiveForm lSaveProgramIncentiveForm) {
        ArrayList<ProgramIncentiveOption> lProgramIncentiveOptions = new ArrayList<ProgramIncentiveOption>();
        Integer[] lIncentiveOptionIDs = lSaveProgramIncentiveForm.getIncentiveOptionIDs();

        if (lIncentiveOptionIDs != null && lIncentiveOptionIDs.length > 0) {
            for (int i = 0; i < lIncentiveOptionIDs.length; i++) {
                ProgramIncentiveOption lProgramIncentiveOption = new ProgramIncentiveOption();
                IncentiveOption lIncentiveOption = new IncentiveOption();
                lProgramIncentiveOption.setIncentiveOption(lIncentiveOption);
                lIncentiveOption.setIncentiveOptionID(lSaveProgramIncentiveForm.getIncentiveOptionIDs()[i]);

                lProgramIncentiveOption.setBusinessProgramID(getUserSession().getBusinessProgram().getProgramID());
                lProgramIncentiveOption.setAdditionalInfo(lSaveProgramIncentiveForm.getIncentiveOptionAddInfos()[i]);
                lProgramIncentiveOption.setIncentiveOptionInfo(lSaveProgramIncentiveForm.getIncentiveOptionInfos()[i]);
                lProgramIncentiveOption.setEffectiveDate(BPMAdminUtils.getSqlDateFromString(lSaveProgramIncentiveForm.getProgramIncentiveOptionEffDates()[i]));
                lProgramIncentiveOption.setEndDate(BPMAdminUtils.getSqlDateFromString(lSaveProgramIncentiveForm.getProgramIncentiveOptionEndDates()[i]));
                lProgramIncentiveOption.setActivationDate(BPMAdminUtils.getSqlDateFromString(lSaveProgramIncentiveForm.getProgramIncentiveOptionActDates()[i]));
                lProgramIncentiveOption.setDeliveryDate(BPMAdminUtils.getSqlDateFromString(lSaveProgramIncentiveForm.getProgramIncentiveOptionDelDates()[i]));
                lProgramIncentiveOption.setSortOrder(BPMAdminUtils.convertStringToInteger(lSaveProgramIncentiveForm.getProgramIncentiveOptionSortOrders()[i]));
                lProgramIncentiveOption.setIncentiveOptionStatusCodeID(lSaveProgramIncentiveForm.getProgramIncentiveOptionStatusIDs()[i]);
                lProgramIncentiveOption.setIncentiveFulfillmentRoutingCodeID(lSaveProgramIncentiveForm.getProgramIncentiveFulfillReqIDs()[i]);
                lProgramIncentiveOption.setIncentedStatusTypeCodeID(lSaveProgramIncentiveForm.getIncentedStatusTypeCodeIDs()[i]);
                lProgramIncentiveOption.setParticipantCap(lSaveProgramIncentiveForm.getParticipantCap()[i]);
                lProgramIncentiveOption.setFamilyCap(lSaveProgramIncentiveForm.getFamilyCap()[i]);
                lProgramIncentiveOption.setEnrollmentDeadlineDate(BPMAdminUtils.getSqlDateFromString(lSaveProgramIncentiveForm.getProgramIncentiveOptionEnrolDeadlineDates()[i]));
                lProgramIncentiveOption.setCompletionDeadlineDate(BPMAdminUtils.getSqlDateFromString(lSaveProgramIncentiveForm.getProgramIncentiveOptionComplDeadlineDates()[i]));
                lProgramIncentiveOption.setIncentiveRuleTypeCodeID(lSaveProgramIncentiveForm.getIncentiveRuleTypeCodeIDs()[i]);
                lProgramIncentiveOption.setIncentiveReportNameCodeID(lSaveProgramIncentiveForm.getProgramIncentiveReportNameIDs()[i]);
                lProgramIncentiveOption.setParticipationGroupID(lSaveProgramIncentiveForm.getParticipationGroupIDs()[i]);
                lProgramIncentiveOption.setIncentiveOptionRewardCardID(lSaveProgramIncentiveForm.getIncentiveOptionRewardCardIDs()[i]);
                lProgramIncentiveOption.setRunFrequencyID(lSaveProgramIncentiveForm.getRewardRunFreqIDs()[i]);
                if (lSaveProgramIncentiveForm.getActivityCompletionPeriods()[i] != null) {
                    lProgramIncentiveOption.setActivityCompletionPeriod(lSaveProgramIncentiveForm.getActivityCompletionPeriods()[i]);
                }

                lProgramIncentiveOption.getIncentiveOption().setIncentiveOptionID(lSaveProgramIncentiveForm.getIncentiveOptionIDs()[i]);

                lProgramIncentiveOption.setNewHireDate(BPMAdminUtils.getSqlDateFromString(lSaveProgramIncentiveForm.getNewHireDates()[i]));
                lProgramIncentiveOption.setUnitTypeCodeID(lSaveProgramIncentiveForm.getUnitTypeCodeIDs()[i]);
                lProgramIncentiveOption.setPackageRuleGroupID(lSaveProgramIncentiveForm.getPackageRuleGroupIDs()[i]);

                lProgramIncentiveOption.setProgramIncentiveOptionID(lSaveProgramIncentiveForm.getProgramIncentiveOptionIDs()[i]);
                lProgramIncentiveOption.setDeliveryInfoID(lSaveProgramIncentiveForm.getDeliveryInfoIDs()[i]);

                lProgramIncentiveOptions.add(lProgramIncentiveOption);
            }
        }

        return lProgramIncentiveOptions;
    }

    @Override
    public boolean supports(Class<?> clazz) {
        return SaveProgramIncentiveForm.class.isAssignableFrom(clazz);
    }

    @Override
    public void validate(Object target, Errors errors) {
        SaveProgramIncentiveForm form = (SaveProgramIncentiveForm) target;
        Collection<LookUpValueCode> incentiveStatusCodesLUV;
        try {
            incentiveStatusCodesLUV = businessProgramService.getIncentiveStatusCodes();
        } catch (BPMException e) {
            throw new RuntimeException(e);
        }
        ArrayList<LookUpValueCode> pIncentiveEnrollmentRuleTypeCodes = getUserSession().getIncentiveEnrollmentRuleCodes();
        Integer luvIdSendToIntelispend = Integer.valueOf(getUserSession().getLuvIdSendToIntelispend());

        boolean isInteger = false;
        if (form.getIncentiveOptionIDs() != null && form.getIncentiveOptionIDs().length > 0) {
            for (int i = 0; i < form.getIncentiveOptionIDs().length; i++) {
                getValidationSupport().validateRequiredFieldIsNotEmpty("incentiveOptionInfos["+i+"]", form.getIncentiveOptionInfos()[i], errors, new Object[]{"Incentive Option Info"});

                getValidationSupport().validateNotSpecialChar("incentiveOptionInfos["+i+"]",  form.getIncentiveOptionInfos()[i], errors, new Object[]{"Incentive Option Info"});
                getValidationSupport().validateNotSpecialChar("incentiveOptionAddInfos["+i+"]",  form.getIncentiveOptionAddInfos()[i], errors, new Object[]{"Additional Info"});
                getValidationSupport().validateRequiredFieldIsNotEmpty("deliveryInfoIDs["+i+"]", form.getDeliveryInfoIDs()[i], errors, new Object[]{"Delivery Info"});

                boolean lEffectiveDateValid = getValidationSupport().validateDateFormat("programIncentiveOptionEffDates["+i+"]", form.getProgramIncentiveOptionEffDates()[i], errors, new Object[]{"Incentive Option Effective Date"});
                boolean lEndDateValid = getValidationSupport().validateDateFormat("programIncentiveOptionEndDates["+i+"]", form.getProgramIncentiveOptionEndDates()[i], errors, new Object[]{"Incentive Option End Date"});
                boolean lActivationDateValid = getValidationSupport().validateDateFormat("programIncentiveOptionActDates["+i+"]", form.getProgramIncentiveOptionActDates()[i], errors, new Object[]{"Incentive Option Activation Date"});
                boolean lDeliveryDateValid = getValidationSupport().validateDateFormat("programIncentiveOptionDelDates["+i+"]", form.getProgramIncentiveOptionDelDates()[i], errors, new Object[]{"Incentive Option Delivery Date"});
                boolean lNewHireDateValid = getValidationSupport().validateDateFormat("newHireDates["+i+"]", form.getNewHireDates()[i], errors, new Object[]{"New Hire Date"});

                boolean lEnrolDeadlineDateValid = false;
                if (form.getProgramIncentiveOptionEnrolDeadlineDates()[i].length() > 0) {
                    lEnrolDeadlineDateValid = getValidationSupport().validateDateFormat("programIncentiveOptionEnrolDeadlineDates["+i+"]", form.getProgramIncentiveOptionEnrolDeadlineDates()[i], errors, new Object[]{"Incentive Option Enrollment Deadline Date"});
                }

                boolean lComplDeadlineDateValid = false;
                if (form.getProgramIncentiveOptionComplDeadlineDates()[i].length() > 0) {
                    lComplDeadlineDateValid = getValidationSupport().validateDateFormat("programIncentiveOptionComplDeadlineDates["+i+"]", form.getProgramIncentiveOptionComplDeadlineDates()[i], errors, new Object[]{"Incentive Option Completion Deadline Date"});
                }

                // Program Effective, End Dates, and Close date are not Editable on this form.
                // They are view-only, so the format is correct.
                if (lEndDateValid) {
                    getValidationSupport().validateBeforeOrEqual("programIncentiveOptionEndDates["+i+"]", form.getProgramIncentiveOptionEndDates()[i], form.getCloseDates()[i], "Incentive Option End Date", errors, new Object[]{"Close Date"});
                    getValidationSupport().validateBeforeOrEqual("programIncentiveOptionEndDates["+i+"]", form.getProgramIncentiveOptionEndDates()[i], form.getProgramEndDate(), "Incentive Option End Date", errors, new Object[]{"Program End Date"});
                }
                if (lEffectiveDateValid) {
                    getValidationSupport().validateAfter("programIncentiveOptionEffDates["+i+"]", form.getProgramIncentiveOptionEffDates()[i], form.getProgramEffectiveDate(), errors, new Object[]{"Incentive Option Effective Date", "Program Effective Date"});
                    getValidationSupport().validateAfter("programIncentiveOptionEffDates["+i+"]", form.getProgramIncentiveOptionEffDates()[i], form.getCreationDates()[i], errors, new Object[]{"Incentive Option Effective Date", "Incentive Option Creation Date"});
                }

                if (lEffectiveDateValid && lEndDateValid) {
                    getValidationSupport().validateBeforeOrEqual("programIncentiveOptionEffDates["+i+"]", form.getProgramIncentiveOptionEffDates()[i], form.getProgramIncentiveOptionEndDates()[i], "Incentive Option Effective Date", errors, new Object[]{"Incentive Option End Date"});
                }
                if (lEndDateValid && lActivationDateValid) {
                    getValidationSupport().validateBeforeOrEqual("programIncentiveOptionEndDates["+i+"]", form.getProgramIncentiveOptionEndDates()[i], form.getProgramIncentiveOptionActDates()[i], "Incentive Option End Date", errors, new Object[]{"Incentive Option Activation Date"});
                }
                if (lActivationDateValid && lDeliveryDateValid) {
                    getValidationSupport().validateBeforeOrEqual("programIncentiveOptionActDates["+i+"]", form.getProgramIncentiveOptionActDates()[i], form.getProgramIncentiveOptionDelDates()[i], "Incentive Option Activation Date", errors, new Object[]{"Incentive Option Delivery Date"});
                }
                if (lEffectiveDateValid && lEnrolDeadlineDateValid) {
                    getValidationSupport().validateAfter("programIncentiveOptionEnrolDeadlineDates["+i+"]", form.getProgramIncentiveOptionEnrolDeadlineDates()[i], form.getProgramIncentiveOptionEffDates()[i], errors, new Object[]{"Incentive Option Enrollment Deadline Date", "Incentive Option Effective Date"});
                }
                if (lEffectiveDateValid && lComplDeadlineDateValid) {
                    getValidationSupport().validateAfter("programIncentiveOptionComplDeadlineDates["+i+"]", form.getProgramIncentiveOptionComplDeadlineDates()[i], form.getProgramIncentiveOptionEffDates()[i], errors, new Object[]{"Incentive Option Completion Deadline Date", "Incentive Option Effective Date"});
                }

                if (lEndDateValid && lEnrolDeadlineDateValid) {
                    getValidationSupport().validateBeforeOrEqual("programIncentiveOptionEnrolDeadlineDates["+i+"]", form.getProgramIncentiveOptionEnrolDeadlineDates()[i], form.getProgramIncentiveOptionEndDates()[i], "Incentive Option Enrollment Deadline Date", errors, new Object[]{"Incentive Option End Date"});
                }
                if (lEndDateValid && lComplDeadlineDateValid) {
                    getValidationSupport().validateBeforeOrEqual("programIncentiveOptionComplDeadlineDates["+i+"]", form.getProgramIncentiveOptionComplDeadlineDates()[i], form.getProgramIncentiveOptionEndDates()[i], "Incentive Option Completion Deadline Date", errors, new Object[]{"Incentive Option End Date"});
                }

                for (int incntvRule = 0; incntvRule < pIncentiveEnrollmentRuleTypeCodes.size(); incntvRule++) {
                    if (form.getIncentiveRuleTypeCodeIDs()[i].intValue() == pIncentiveEnrollmentRuleTypeCodes.get(incntvRule).getLuvId().intValue()) {
                        if (BPMAdminConstants.BPM_ADMIN_INCENTIVE_ENROLL_ENROLL_BY.equals(pIncentiveEnrollmentRuleTypeCodes.get(incntvRule).getLuvVal())) {
                            getValidationSupport().validateRequiredFieldIsNotEmpty("programIncentiveOptionEnrolDeadlineDates["+i+"]", form.getProgramIncentiveOptionEnrolDeadlineDates()[i], errors, new Object[]{"Incentive Option Enrollment Deadline Date"});
                        }

                        if (BPMAdminConstants.BPM_ADMIN_INCENTIVE_ENROLL_COMPLETE_BY.equals(pIncentiveEnrollmentRuleTypeCodes.get(incntvRule).getLuvVal())) {
                            getValidationSupport().validateRequiredFieldIsNotEmpty("programIncentiveOptionComplDeadlineDates["+i+"]", form.getProgramIncentiveOptionComplDeadlineDates()[i], errors, new Object[]{"Incentive Option Completion Deadline Date"});
                        }
                        if (BPMAdminConstants.BPM_ADMIN_INCENTIVE_COVERAGE_EFFECTIVE_DATE.equals(pIncentiveEnrollmentRuleTypeCodes.get(incntvRule).getLuvVal())) {
                            getValidationSupport().validateRequiredFieldIsNotEmpty("activityCompletionPeriods["+i+"]", form.getActivityCompletionPeriods()[i], errors, new Object[]{"Incentive Option Activity Completion Period"});
                        }

                        if (!BPMAdminConstants.BPM_ADMIN_INCENTIVE_COVERAGE_EFFECTIVE_DATE.equals(pIncentiveEnrollmentRuleTypeCodes.get(incntvRule).getLuvVal())) {
                            if (form.getActivityCompletionPeriods()[i] != null && form.getActivityCompletionPeriods()[i].length() > 0) {
                                getValidationSupport().addValidationFailureMessage("activityCompletionPeriods["+i+"]", errors, "errors.notallowed", new Object[]{"Time Period"});
                            }
                        }
                    }
                }

                getValidationSupport().validateOnlyNumericForInteger("programIncentiveOptionSortOrders["+i+"]", form.getProgramIncentiveOptionSortOrders()[i], errors, new Object[]{"Sort Order"});
                getValidationSupport().validateNotZero("programIncentiveOptionStatusIDs["+i+"]", String.valueOf(form.getProgramIncentiveOptionStatusIDs()[i]), errors, new Object[]{"Display Status"});
                getValidationSupport().validateNotZero("programIncentiveFulfillReqIDs["+i+"]", String.valueOf(form.getProgramIncentiveFulfillReqIDs()[i]), errors, new Object[]{"Fulfillment Routing"});
                getValidationSupport().validateNotZero("programIncentiveReportNameIDs["+i+"]", String.valueOf(form.getProgramIncentiveReportNameIDs()[i]), errors, new Object[]{"Incentive Report Name"});
                getValidationSupport().validateNotZero("incentedStatusTypeCodeIDs["+i+"]", String.valueOf(form.getIncentedStatusTypeCodeIDs()[i]), errors, new Object[]{"Incentive Status"});

                if (form.getProgramIncentiveFulfillReqIDs()[i].intValue() == luvIdSendToIntelispend) {
                    getValidationSupport().validateNotZero("incentiveOptionRewardCardIDs["+i+"]", String.valueOf(form.getIncentiveOptionRewardCardIDs()[i]), errors, new Object[]{"Reward Card Type"});
                    getValidationSupport().validateNotZero("rewardRunFreqIDs["+i+"]", String.valueOf(form.getRewardRunFreqIDs()[i]), errors, new Object[]{"Reward Batch Run Frequency"});
                }

                boolean isCapAmountExist = false;
                boolean isParticipationCapExist = false;
                boolean isFamilyCapExist = false;
                if (form.getParticipantCap()[i] != null && form.getParticipantCap()[i].length() > 0) {
                    getValidationSupport().validateNotZero("participantCap["+i+"]", String.valueOf(form.getParticipantCap()[i]), errors, new Object[]{"Participant Cap"});
                    isParticipationCapExist = true;
                    isCapAmountExist = true;
                }

                if (form.getFamilyCap()[i] != null && form.getFamilyCap()[i].length() > 0) {
                    getValidationSupport().validateNotZero("familyCap["+i+"]", String.valueOf(form.getFamilyCap()[i]), errors, new Object[]{"Family Cap"});
                    isFamilyCapExist = true;
                    isCapAmountExist = true;
                }

                if (isFamilyCapExist && isParticipationCapExist) {
                    isCapAmountExist = true;
                }

                if (isCapAmountExist) {
                    if (form.getUnitTypeCodeIDs()[i] == null || form.getUnitTypeCodeIDs()[i].intValue() == 0) {
                        getValidationSupport().addValidationFailureMessage("unitTypeCodeIDs["+i+"]", errors, "errors.required", new Object[]{"Cap Type"});
                        //if type code chosen is NONE, force user to select Unit or Dollars.
                    } else if (form.getUnitTypeCodeIDs()[i].intValue() == 2022) {
                        getValidationSupport().addValidationFailureMessage("unitTypeCodeIDs["+i+"]", errors, "errors.requiredUNITorDollars", new Object[]{"Cap Type"});
                    } else if (form.getUnitTypeCodeIDs()[i] != null && form.getUnitTypeCodeIDs()[i].intValue() > 0 && form.getUnitTypeCodeIDs()[i].intValue() != 2022 && isFamilyCapExist && !isParticipationCapExist) {
                        getValidationSupport().addValidationFailureMessage("unitTypeCodeIDs["+i+"]", errors, "errors.requiredParticipationCap", new Object[]{"Cap Type"});
                    } else if (form.getUnitTypeCodeIDs()[i] != null && form.getUnitTypeCodeIDs()[i].intValue() > 0 && form.getUnitTypeCodeIDs()[i].intValue() != 2022 && !isFamilyCapExist && isParticipationCapExist) {
                        getValidationSupport().addValidationFailureMessage("unitTypeCodeIDs["+i+"]", errors, "errors.requiredFamilyCap", new Object[]{"Cap Type"});
                    }
                } else if (form.getUnitTypeCodeIDs()[i] != null && form.getUnitTypeCodeIDs()[i].intValue() > 0 && form.getUnitTypeCodeIDs()[i].intValue() != 2022) {
                    getValidationSupport().addValidationFailureMessage("unitTypeCodeIDs["+i+"]", errors, "errors.requiredCaps", new Object[]{"Cap Type"});
                }

                getValidationSupport().validateNotZero("participationGroupIDs["+i+"]", String.valueOf(form.getParticipationGroupIDs()[i]), errors, new Object[]{"Participation Group Requirement"});
                getValidationSupport().validateNotZero("incentiveRuleTypeCodeIDs["+i+"]", String.valueOf(form.getIncentiveRuleTypeCodeIDs()[i]), errors, new Object[]{"Incentive Rule Type"});
                getValidationSupport().validateNotZero("packageRuleGroupIDs["+i+"]", String.valueOf(form.getPackageRuleGroupIDs()[i]), errors, new Object[]{"Incentive Package Rule"});
            }
        }
        //EV50511 - edit rule to make sure admin selects incentive status MULTI_ACTIVITY for the incentive option if intending to add more than one
        //incentive requirement.
        ArrayList<ProgramIncentiveOption> lProgramIncentiveOptions = getUserSession().getProgramIncentiveOptions();
        Iterator<ProgramIncentiveOption> iter = lProgramIncentiveOptions.iterator();
        int idx = 0;
        while (iter.hasNext()) {
            ProgramIncentiveOption lProgramIncentiveOption = iter.next();

            if (lProgramIncentiveOption.getActivityIncentiveRequirements() != null
                    && lProgramIncentiveOption.getActivityIncentiveRequirements().size() > 1) {

                Iterator<LookUpValueCode> iterLuv = incentiveStatusCodesLUV.iterator();
                String incentedStatusTypeCode = "";
                while (iterLuv.hasNext()) {
                    LookUpValueCode lLookUpValueCode = iterLuv.next();
                    if (form.getIncentedStatusTypeCodeIDs()[idx].equals(lLookUpValueCode.getLuvId())) {
                        incentedStatusTypeCode = lLookUpValueCode.getLuvVal();
                        break;
                    }
                }
                if (!incentedStatusTypeCode.equals(BPMConstants.BPM_INCENTED_STATUS_TYPE_MULTI_ACTIVITY)) {
                    getValidationSupport().addValidationFailureMessage("incentedStatusTypeCodeIDs["+idx+"]", errors, "errors.multiactivityedit", null);
                }
            }

            idx++;
        }

        //EV54252 - edit rule to make sure admin adds a Contribution Incentive Tier if a fulfillment routing type selected is
        //send to cdhp HRA or HSA deposits or send to Intelispend for reward cards.
        //This edit removed for now.  There are Employers that send in activities taken that have to be uploaded from a file
        //into BPM and already contain incentive amounts.  In this case, there would be no Contribution Incentive Grid required
        //to be set up.
		 /*iter = lProgramIncentiveOptions.iterator();
		 while (iter.hasNext()) {
         	ProgramIncentiveOption lProgramIncentiveOption = (ProgramIncentiveOption)iter.next();

         	if (lProgramIncentiveOption.getIncentiveFulfillmentCode().equals(BPMAdminConstants.BPM_VAL_FLFLMNT_RTNG_TP_SND_TO_CDHP) ||
         			lProgramIncentiveOption.getIncentiveFulfillmentCode().equals(BPMAdminConstants.BPM_VAL_FLFLMNT_RTNG_TP_SND_TO_HPDIT) ||
         			lProgramIncentiveOption.getIncentiveFulfillmentCode().equals(BPMAdminConstants.BPM_VAL_FLFLMNT_RTNG_TP_SND_TO_EMP_PORTAL) ||
         			lProgramIncentiveOption.getIncentiveFulfillmentCode().equals(BPMAdminConstants.BPM_VAL_FLFLMNT_RTNG_TP_SND_TO_INTELISPEND)) {
         		if (lProgramIncentiveOption.getProgramContributionTiers() == null || lProgramIncentiveOption.getProgramContributionTiers().size() == 0) {
         			this.getActionMessages().add("incentiveFulfillmentCode", new ActionError("errors.missingContributionIncentiveTier", ""));
         		}
         	}
         }*/
    }
}
