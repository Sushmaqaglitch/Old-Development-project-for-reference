package com.healthpartners.app.bpm.dto;

import java.io.Serializable;


public class PersonRelationshipCode implements Serializable {
    static final long serialVersionUID = 0L;

    private Integer relationshipCodeID;
    private String relationshipName;

    public Integer getRelationshipCodeID() {
        return relationshipCodeID;
    }

    public void setRelationshipCodeID(Integer relationshipCodeID) {
        this.relationshipCodeID = relationshipCodeID;
    }

    public String getRelationshipName() {
        return relationshipName;
    }

    public void setRelationshipName(String relationshipName) {
        this.relationshipName = relationshipName;
    }
}
