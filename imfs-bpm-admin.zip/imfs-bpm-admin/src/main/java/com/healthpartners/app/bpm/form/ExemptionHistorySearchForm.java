package com.healthpartners.app.bpm.form;

import com.healthpartners.app.bpm.dto.LookUpValueCode;

import java.util.ArrayList;

/**
 * @author jxbourbour
 *
 */
public class ExemptionHistorySearchForm extends BaseForm {

	private String groupNumber;
	private String groupName;
	private String siteNumber;
	private String effectiveDate;
	private String actionType;
	private Integer groupID;
	private String ContractNumber;
	private String MemberNumber;
	private String exemptionType;
	private String exemptionFromDate;
	private String exemptionToDate;
	private String whichList;
	private ArrayList<LookUpValueCode> exemptionTypes = new ArrayList<>();

	public ExemptionHistorySearchForm() {
		super();
	}

	public String getGroupNumber() {
		return groupNumber;
	}

	public void setGroupNumber(String groupNumber) {
		this.groupNumber = groupNumber;
	}

	public String getActionType() {
		return actionType;
	}

	public void setActionType(String actionType) {
		this.actionType = actionType;
	}

	public final String getGroupName() {
		return groupName;
	}

	public final void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public final Integer getGroupID() {
		return groupID;
	}

	public final void setGroupID(Integer groupID) {
		this.groupID = groupID;
	}

	public final String getSiteNumber() {
		return siteNumber;
	}

	public final void setSiteNumber(String siteNumber) {
		this.siteNumber = siteNumber;
	}

	public String getContractNumber() {
		return ContractNumber;
	}

	public void setContractNumber(String contractNumber) {
		ContractNumber = contractNumber;
	}

	public String getMemberNumber() {
		return MemberNumber;
	}

	public void setMemberNumber(String memberNumber) {
		MemberNumber = memberNumber;
	}

	public final String getEffectiveDate() {
		return effectiveDate;
	}

	public final void setEffectiveDate(String effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public final String getExemptionType() {
		return exemptionType;
	}

	public final void setExemptionType(String exemptionType) {
		this.exemptionType = exemptionType;
	}

	public String getExemptionFromDate() {
		return exemptionFromDate;
	}

	public void setExemptionFromDate(String exemptionFromDate) {
		this.exemptionFromDate = exemptionFromDate;
	}

	public String getExemptionToDate() {
		return exemptionToDate;
	}

	public void setExemptionToDate(String exemptionToDate) {
		this.exemptionToDate = exemptionToDate;
	}

	public final String getWhichList() {
		return whichList;
	}

	public final void setWhichList(String whichList) {
		this.whichList = whichList;
	}

	public ArrayList<LookUpValueCode> getExemptionTypes() {
		return exemptionTypes;
	}

	public void setExemptionTypes(ArrayList<LookUpValueCode> exemptionTypes) {
		this.exemptionTypes = exemptionTypes;
	}
}
