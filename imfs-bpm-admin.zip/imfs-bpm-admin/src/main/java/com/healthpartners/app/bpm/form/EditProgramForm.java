/**
 * 
 */
package com.healthpartners.app.bpm.form;

/**
 * @author jxbourbour
 *
 */
public class EditProgramForm extends BaseForm {

	private Integer programID;
	private String groupNo;

	public EditProgramForm() {
		super();
	}

	public Integer getProgramID() {
		return programID;
	}

	public void setProgramID(Integer programID) {
		this.programID = programID;
	}

	public String getGroupNo() {
		return groupNo;
	}

	public void setGroupNo(String groupNo) {
		this.groupNo = groupNo;
	}
}
