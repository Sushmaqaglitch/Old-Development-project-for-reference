package com.healthpartners.app.bpm.dto;

import java.io.Serializable;
import java.sql.Date;
import java.util.ArrayList;

public class ProgramPackage implements Serializable {
    static final long serialVersionUID = 0L;
    ArrayList<PackageActivity> packageActivities;
    private Integer packageID;
    private String packageName;
    private String packageInfo;
    private String packageDesc;
    private Date insertDate;
    private Date modifyDate;
    private String insertUser;
    private String modifyUser;
    private Date effectiveDate;
    private Date endDate;
    private Integer used;
    private String effectiveDateString;
    private String endDateString;

    public Date getEffectiveDate() {
        return effectiveDate;
    }

    public void setEffectiveDate(Date effectiveDate) {
        this.effectiveDate = effectiveDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public Date getInsertDate() {
        return insertDate;
    }

    public void setInsertDate(Date insertDate) {
        this.insertDate = insertDate;
    }

    public String getInsertUser() {
        return insertUser;
    }

    public void setInsertUser(String insertUser) {
        this.insertUser = insertUser;
    }

    public Date getModifyDate() {
        return modifyDate;
    }

    public void setModifyDate(Date modifyDate) {
        this.modifyDate = modifyDate;
    }

    public String getModifyUser() {
        return modifyUser;
    }

    public void setModifyUser(String modifyUser) {
        this.modifyUser = modifyUser;
    }

    public String getPackageDesc() {
        return packageDesc;
    }

    public void setPackageDesc(String packageDesc) {
        this.packageDesc = packageDesc;
    }

    public Integer getPackageID() {
        return packageID;
    }

    public void setPackageID(Integer packageID) {
        this.packageID = packageID;
    }

    public String getPackageInfo() {
        return packageInfo;
    }

    public void setPackageInfo(String packageInfo) {
        this.packageInfo = packageInfo;
    }

    public String getPackageName() {
        return packageName;
    }

    public void setPackageName(String packageName) {
        this.packageName = packageName;
    }

    public Integer getUsed() {
        return used;
    }

    public void setUsed(Integer used) {
        this.used = used;
    }

    public String getEffectiveDateString() {
        return effectiveDateString;
    }

    public void setEffectiveDateString(String effectiveDateString) {
        this.effectiveDateString = effectiveDateString;
    }

    public String getEndDateString() {
        return endDateString;
    }

    public void setEndDateString(String endDateString) {
        this.endDateString = endDateString;
    }

    public ArrayList<PackageActivity> getPackageActivities() {
        return packageActivities;
    }

    public void setPackageActivities(ArrayList<PackageActivity> packageActivities) {
        this.packageActivities = packageActivities;
    }

}
