package com.healthpartners.app.bpm.dao;

import com.healthpartners.app.bpm.common.BPMAdminConstants;
import com.healthpartners.app.bpm.dto.BaselineHistory;
import com.healthpartners.app.bpm.exception.BPMException;
import jakarta.annotation.PostConstruct;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Collection;

@Repository
@Transactional(timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
public class ContractDAOJdbc extends JdbcDaoSupport implements ContractDAO {

    private static final String deleteContractPrograms = "DELETE FROM contract_program_status WHERE ";

    private String updateContractProgramStatus = "UPDATE contract_program_status SET cntr_stat_cd_id = ?, cntr_stat_dt = SYSDATE, modify_ts = SYSDATE, modify_usr = ?\n" +
            "\t\t   WHERE contract_no = ? AND biz_pgm_id = ? AND biz_pgm_incntv_optn_ID = ?";

    private static final String selectContractStatusCount =
            "SELECT count('x') status_count FROM contract_program_status WHERE biz_pgm_id = ? AND cntr_stat_cd_id =\n" +
                    "(SELECT lu_id FROM luv WHERE lu_grp='BPM_CONTRACT_STATUS' AND lu_val=?) ";

    private final DataSource dataSource;
    private static final String selectBaseline = """
            SELECT person_no, hp_mem_id, first_nm, last_nm, dob_dt
            , contract_no, rel_ds.rlshp_cd, rel_ds.rlshp_txt, baseline.grp_id, empl_grp_no, empl_grp_nm
            , baseline.subgrp_id, EMPL_GRP_SITE_ID_NO, empl_grp_site_nm, ben_pkg_id
            , contract_eff_dt, contract_end_dt, subgrp_eff_dt, subgrp_end_dt, ben_pkg_eff_dt, ben_pkg_end_dt
            , BIZ_PGM_EFF_DT, BIZ_PGM_END_DT
            , load_Dt, baseline.process_ts
            ,EXT_EMP_ID_NO, PROD_TP_CD, JW_OFFER_CD, JW_REPORTING_UNIT, DIVISION_CD, EMPLOYEE_FLG, ELIG_HIRE_DT 
            FROM prsn_baseline_ds baseline,  prsn_demographics  prsn, empl_grp_site groups, pes_rel_ds rel_ds
            WHERE
                person_no = prsn_id
                AND baseline.grp_id = groups.grp_id
                AND baseline.subgrp_id = groups.subgrp_id
                AND rel_ds.rlshp_cd = baseline.rel_cd            
             """;

    private static final String selectBaselineHistory = """
            SELECT person_no, hp_mem_id, first_nm, last_nm, dob_dt
            , contract_no, rel_ds.rlshp_cd, rel_ds.rlshp_txt, baseline.grp_id, empl_grp_no, empl_grp_nm
            , baseline.subgrp_id, EMPL_GRP_SITE_ID_NO, empl_grp_site_nm, ben_pkg_id
            , contract_eff_dt, contract_end_dt, subgrp_eff_dt, subgrp_end_dt, ben_pkg_eff_dt, ben_pkg_end_dt
            , BIZ_PGM_EFF_DT, BIZ_PGM_END_DT
            , load_Dt, to_date('01/01/1900', 'dd/MM/yyyy') as process_ts
            ,EXT_EMP_ID_NO, PROD_TP_CD, JW_OFFER_CD, JW_REPORTING_UNIT, DIVISION_CD, EMPLOYEE_FLG, ELIG_HIRE_DT
            FROM prsn_baseline_hist_ds baseline,  prsn_demographics  prsn, empl_grp_site groups, pes_rel_ds rel_ds
            WHERE
                person_no = prsn_id
                AND baseline.grp_id = groups.grp_id
                AND baseline.subgrp_id = groups.subgrp_id
                AND rel_ds.rlshp_cd = baseline.rel_cd
            """;
    private static final String selectMemberIDByContractNo = """
            SELECT distinct hp_mem_id FROM prsn_demographics demo
            , prsn_baseline_ds pbl
             WHERE pbl.contract_no = ?\s
               AND pbl.rel_cd = 1
               AND pbl.person_no = demo.prsn_id\s
            """;

    public ContractDAOJdbc (DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @PostConstruct
    private void initialize() {
        setDataSource(dataSource);
    }

    //Produces warnings during compile time to quickly identify typos or API changes
    @Override
    public int deleteContractPrograms(Integer businessProgramID)
            throws DataAccessException
    {
        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[] { businessProgramID };
        int types[] = new int[] { Types.INTEGER };

        StringBuffer lQuery = new StringBuffer();
        lQuery.append(deleteContractPrograms);
        lQuery.append(" biz_pgm_id = ? ");

        return template.update(lQuery.toString(), params, types);
    }

    /**
     * Get the count for the given contract status, and the given biz pgm ID.
     *
     * @param pContractStatus
     * @return
     * @throws DataAccessException
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Override
    public Integer getContractStatusCount(String pContractStatus, Integer pBusinessProgramID) throws DataAccessException {
        final ArrayList<Integer> results = new ArrayList<Integer>();
        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{pBusinessProgramID, pContractStatus};
        int types[] = new int[]{Types.INTEGER, Types.VARCHAR};
        template.query(selectContractStatusCount, params, types,
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        results.add(rs.getInt("status_count"));
                    }
                });

        return results.get(0);
    }

    @Override
    public int deleteContractProgramsByProgramIncentiveOptionID(Integer pProgramIncentiveOptionID)
            throws DataAccessException {
        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{pProgramIncentiveOptionID};
        int types[] = new int[]{Types.INTEGER};

        StringBuffer lQuery = new StringBuffer();
        lQuery.append(deleteContractPrograms);
        lQuery.append(" BIZ_PGM_INCNTV_OPTN_ID = ? ");

        return template.update(lQuery.toString(), params, types);
    }

    @Override
    public Collection<BaselineHistory> getBaselineHistory(final String pMemberID, Integer pContractNo, java.sql.Date pProgramEffetiveDate, String pEligibilityHistoryResults) throws DataAccessException {
        final ArrayList<BaselineHistory> lBaselineHistoryList = new ArrayList<>();

        StringBuffer lQuery = new StringBuffer();
        ArrayList<Object> lParameters = new ArrayList<>();
        ArrayList<Integer> lTypes = new ArrayList<>();

        lQuery.append(selectBaseline);
        if (pMemberID != null && pMemberID.trim().length() > 0) {
            lQuery.append(" AND prsn.hp_mem_id = ?");
            lParameters.add(pMemberID);
            lTypes.add(Types.VARCHAR);
        }

        if (pContractNo != null && pContractNo > 0) {
            lQuery.append(" AND baseline.contract_no = ?");
            lParameters.add(pContractNo);
            lTypes.add(Types.INTEGER);
        }

        if (pProgramEffetiveDate != null) {
            lQuery.append(" AND baseline.biz_pgm_eff_dt = ?");
            lParameters.add(pProgramEffetiveDate);
            lTypes.add(Types.DATE);
        }

        if ("ALL".equalsIgnoreCase(pEligibilityHistoryResults)) {
            lQuery.append(" UNION ");
            lQuery.append(selectBaselineHistory);

            if (pMemberID != null && pMemberID.trim().length() > 0) {
                lQuery.append(" AND prsn.hp_mem_id = ?");
                lParameters.add(pMemberID);
                lTypes.add(Types.VARCHAR);
            }

            if (pContractNo != null && pContractNo > 0) {
                lQuery.append(" AND baseline.contract_no = ?");
                lParameters.add(pContractNo);
                lTypes.add(Types.INTEGER);
            }

            if (pProgramEffetiveDate != null) {
                lQuery.append(" AND baseline.biz_pgm_eff_dt = ?");
                lParameters.add(pProgramEffetiveDate);
                lTypes.add(Types.DATE);
            }
        }

        lQuery.append(" ORDER BY rlshp_cd ASC, process_ts DESC, load_dt DESC");

        JdbcTemplate template = getJdbcTemplate();

        Object params[] = new Object[lParameters.size()];
        lParameters.toArray(params);

        int types[] = new int[lTypes.size()];
        for (int j = 0; j < lTypes.size(); j++) {
            types[j] = (lTypes.get(j)).intValue();
        }

        template.query(lQuery.toString(), params, types,
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        BaselineHistory lBaselineHistory = new BaselineHistory();

                        lBaselineHistory.setMemberID(rs.getString("hp_mem_id"));
                        lBaselineHistory.setFirstName(rs.getString("first_nm"));
                        lBaselineHistory.setLastName(rs.getString("last_nm"));
                        lBaselineHistory.setBirthDate(rs.getDate("dob_dt"));
                        lBaselineHistory.setRelationship(rs.getString("rlshp_txt"));

                        lBaselineHistory.setPersonID(rs.getInt("person_no"));
                        lBaselineHistory.setContractNo(rs.getInt("contract_no"));

                        lBaselineHistory.setGroupID(rs.getInt("grp_id"));
                        lBaselineHistory.setGroupNo(rs.getString("empl_grp_no"));
                        lBaselineHistory.setGroupName(rs.getString("empl_grp_nm"));

                        lBaselineHistory.setSubgroupID(rs.getInt("subgrp_id"));
                        lBaselineHistory.setSiteNo(rs.getString("EMPL_GRP_SITE_ID_NO"));
                        lBaselineHistory.setSubgroupName(rs.getString("empl_grp_site_nm"));

                        lBaselineHistory.setPackageID(rs.getString("ben_pkg_id"));
                        lBaselineHistory.setPackageEffectiveDate(rs.getDate("ben_pkg_eff_dt"));
                        lBaselineHistory.setPackageEndDate(rs.getDate("ben_pkg_end_dt"));

                        lBaselineHistory.setContractEffectiveDate(rs.getDate("contract_eff_dt"));
                        lBaselineHistory.setContractEndDate(rs.getDate("contract_end_dt"));

                        lBaselineHistory.setSubgroupEffectiveDate(rs.getDate("subgrp_eff_dt"));
                        lBaselineHistory.setSubgroupEndDate(rs.getDate("subgrp_end_dt"));

                        lBaselineHistory.setProgramEffectiveDate(rs.getDate("BIZ_PGM_EFF_DT"));
                        lBaselineHistory.setProgramEndDate(rs.getDate("BIZ_PGM_END_DT"));

                        lBaselineHistory.setExternalID(rs.getString("EXT_EMP_ID_NO"));
                        lBaselineHistory.setProdTypeCode(rs.getString("PROD_TP_CD"));
                        lBaselineHistory.setOfferCode(rs.getString("JW_OFFER_CD"));
                        lBaselineHistory.setReportingUnit(rs.getString("JW_REPORTING_UNIT"));
                        lBaselineHistory.setDivisionCode(rs.getString("DIVISION_CD"));
                        lBaselineHistory.setEmployeeFlag(rs.getString("EMPLOYEE_FLG"));
                        lBaselineHistory.setHireDate(rs.getDate("ELIG_HIRE_DT"));

                        lBaselineHistory.setLoadDate(rs.getDate("load_dt"));
                        java.sql.Date lProcessDate = rs.getDate("process_ts");

                        // prsn_baseline_hist does not have a process date. It's being set to
                        // 01-JAN-1900 to set the sort order correctly.
                        if (lProcessDate != null && lProcessDate.after(BPMAdminConstants.BPM_DEFAULT_BASELINE_HISTORY_PROCESS_DATE)) {
                            lBaselineHistory.setProcessDate(lProcessDate);
                        } else {
                            lBaselineHistory.setProcessDate(null);
                        }

                        lBaselineHistoryList.add(lBaselineHistory);
                    }
                });

        return lBaselineHistoryList;
    }

    @Override
    public Collection<String> getMemberIDByContractNo(Integer pContractNo) throws DataAccessException {
        final ArrayList<String> results = new ArrayList<String>();
        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{pContractNo};
        int types[] = new int[]{Types.INTEGER};
        template.query(selectMemberIDByContractNo, params, types,
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        String lMemberID = rs.getString("hp_mem_id");

                        results.add(lMemberID);
                    }
                });
        return results;
    }
    //Produces warnings during compile time to quickly identify typos or API changes
    @Override
    public int updateContractProgramStatus(Integer pProgramID, Integer pContractNo, Integer pNewStatus, String pUserID, Integer pProgramIncentiveOptionID)
            throws DataAccessException
    {

        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[] { pNewStatus, pUserID, pContractNo, pProgramID, pProgramIncentiveOptionID };
        int types[] = new int[] { Types.INTEGER, Types.CHAR, Types.INTEGER, Types.INTEGER, Types.INTEGER };

        return template.update(updateContractProgramStatus, params, types);
    }
}
