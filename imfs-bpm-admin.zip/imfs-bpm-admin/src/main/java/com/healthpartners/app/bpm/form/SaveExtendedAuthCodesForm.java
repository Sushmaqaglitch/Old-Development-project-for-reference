package com.healthpartners.app.bpm.form;

/**
 * @author jxbourbour
 */
public class SaveExtendedAuthCodesForm extends BaseForm {

    static final long serialVersionUID = 0L;

    private String actionType;
    private String[] extendedAuthCodeNames;
    private String[] extendedAuthCodeTypeCodes;
    private String[] extendedAuthCodeEffectiveDates;
    private String[] extendedAuthCodeEndDates;
    private Integer groupID;
    private Integer programID;
    private String groupNumber;

    private String programExtendedAuthCodeAddRemove;

    public SaveExtendedAuthCodesForm() {
        super();
    }

    public final String getActionType() {
        return actionType;
    }

    public final void setActionType(String actionType) {
        this.actionType = actionType;
    }

    public final String[] getExtendedAuthCodeNames() {
        return extendedAuthCodeNames;
    }

    public final void setExtendedAuthCodeNames(String[] extendedAuthCodeNames) {
        this.extendedAuthCodeNames = extendedAuthCodeNames;
    }

    public final String[] getExtendedAuthCodeTypeCodes() {
        return extendedAuthCodeTypeCodes;
    }

    public final void setExtendedAuthCodeTypeCodes(
            String[] extendedAuthCodeTypeCodes) {
        this.extendedAuthCodeTypeCodes = extendedAuthCodeTypeCodes;
    }

    public final String[] getExtendedAuthCodeEffectiveDates() {
        return extendedAuthCodeEffectiveDates;
    }

    public final void setExtendedAuthCodeEffectiveDates(
            String[] extendedAuthCodeEffectiveDates) {
        this.extendedAuthCodeEffectiveDates = extendedAuthCodeEffectiveDates;
    }

    public final String[] getExtendedAuthCodeEndDates() {
        return extendedAuthCodeEndDates;
    }

    public final void setExtendedAuthCodeEndDates(String[] extendedAuthCodeEndDates) {
        this.extendedAuthCodeEndDates = extendedAuthCodeEndDates;
    }

    public Integer getGroupID() {
        return groupID;
    }

    public void setGroupID(Integer groupID) {
        this.groupID = groupID;
    }

    public Integer getProgramID() {
        return programID;
    }

    public void setProgramID(Integer programID) {
        this.programID = programID;
    }

    public String getProgramExtendedAuthCodeAddRemove() {
        return programExtendedAuthCodeAddRemove;
    }

    public void setProgramExtendedAuthCodeAddRemove(String programExtendedAuthCodeAddRemove) {
        this.programExtendedAuthCodeAddRemove = programExtendedAuthCodeAddRemove;
    }

    public String getGroupNumber() {
        return groupNumber;
    }

    public void setGroupNumber(String groupNumber) {
        this.groupNumber = groupNumber;
    }
}
