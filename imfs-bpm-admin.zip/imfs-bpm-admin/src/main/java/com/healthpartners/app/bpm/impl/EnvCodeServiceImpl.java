package com.healthpartners.app.bpm.impl;

import com.healthpartners.app.bpm.dao.EnvCodeDAO;
import com.healthpartners.app.bpm.dto.BPMEnvCode;
import com.healthpartners.app.bpm.exception.BPMException;
import com.healthpartners.app.bpm.iface.EnvCodeService;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

@Service
public class EnvCodeServiceImpl implements EnvCodeService {
    protected final Log logger = LogFactory.getLog(getClass());

    private final EnvCodeDAO envCodeDAO;

    public EnvCodeServiceImpl(EnvCodeDAO envCodeDAO) {
		this.envCodeDAO = envCodeDAO;
    }

    @Transactional(timeout = 300, rollbackFor = {DataAccessException.class, BPMException.class})
	@Override
	public int insertEnvCode(BPMEnvCode code) throws BPMException, DataAccessException {
        return envCodeDAO.insertEnvCode(code);
    }

    @Transactional(timeout = 300, rollbackFor = {DataAccessException.class, BPMException.class})
	@Override
	public int updateEnvCode(BPMEnvCode code) throws BPMException, DataAccessException {
        return envCodeDAO.updateEnvCode(code);
    }

    @Transactional(timeout = 300, rollbackFor = {DataAccessException.class, BPMException.class})
    @Override
	public int deleteEnvCode(BPMEnvCode code) throws BPMException, DataAccessException {
        return deleteEnvCode(code);
    }


	@Override
    public Collection<BPMEnvCode> getAllEnvCodes() throws BPMException, DataAccessException {
        Collection<BPMEnvCode> codes = new ArrayList<BPMEnvCode>();

        try {
            codes.addAll(envCodeDAO.getAllEnvCodes());

        } catch (Exception e) {
            e.printStackTrace();
            //throw new BPMException(e.getMessage(), e);
        }

        return codes;
    }

    public synchronized BPMEnvCode getEnvCodeByName(String pEnvCodeName) throws BPMException, DataAccessException {
        BPMEnvCode lCode;

        try {
            Collection<BPMEnvCode> allEnvCodes = this.getAllEnvCodes();
            Iterator<BPMEnvCode> iter = allEnvCodes.iterator();
            while (iter.hasNext()) {
                lCode = iter.next();
                if (lCode.getEnvCode().equalsIgnoreCase(pEnvCodeName)) {
                    return lCode;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new BPMException(e.getMessage(), e);
        }

        return null;
    }

}
