package com.healthpartners.app.bpm.dao;

import com.healthpartners.app.bpm.dto.BaselineHistory;
import org.springframework.dao.DataAccessException;

import java.util.Collection;

public interface ContractDAO {

    int deleteContractPrograms(Integer businessProgramID) throws DataAccessException;

    Integer getContractStatusCount(String pContractStatus, Integer pBusinessProgramID) throws DataAccessException;

    int deleteContractProgramsByProgramIncentiveOptionID(Integer pProgramIncentiveOptionID) throws DataAccessException;

    Collection<BaselineHistory> getBaselineHistory(String pMemberID, Integer pContractNo, java.sql.Date pProgramEffetiveDate, String pEligibilityHistoryResults) throws DataAccessException;

    Collection<String> getMemberIDByContractNo(Integer pContractNo)
            throws DataAccessException;

    public int updateContractProgramStatus(Integer pProgramID, Integer pContractNo, Integer pNewStatus, String pUserID, Integer pProgramIncentiveOptionID)
            throws DataAccessException;
}
