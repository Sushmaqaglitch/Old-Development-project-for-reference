/* $Id$ */

package com.healthpartners.app.bpm.dao;

import com.healthpartners.app.bpm.common.BPMAdminUtils;
import com.healthpartners.app.bpm.dto.CheckmarkDetail;
import com.healthpartners.app.bpm.dto.CheckmarkRequirement;
import com.healthpartners.app.bpm.dto.ProgramCheckmark;
import com.healthpartners.app.bpm.dto.QualificationCheckmark;
import com.healthpartners.app.bpm.exception.BPMException;
import jakarta.annotation.PostConstruct;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.jdbc.support.incrementer.DataFieldMaxValueIncrementer;
import org.springframework.jdbc.support.incrementer.OracleSequenceMaxValueIncrementer;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Collection;

/**
 * @author jxbourbour
 */
@Repository
@Transactional(timeout = 300, rollbackFor = {DataAccessException.class, BPMException.class})
public class QualificationCheckmarkDAOJdbc extends JdbcDaoSupport implements QualificationCheckmarkDAO {
	// @formatter:off
	private static final String selectQualificationCheckmarks = " SELECT qc.QUALFCTN_CHKMRK_ID,\n" +
            "qc.QUALFCTN_CHKMRK_NM,\n" +
            "qc.QUALFCTN_CHKMRK_INFO,\n" +
            "qc.QUALFCTN_CHKMRK_DESC,\n" +
            "qc.EFF_DT,\n" +
            "qc.END_DT,\n" +
            "qc.INSERT_TS,\n" +
            "qc.MODIFY_TS,\n" +
            "qc.INSERT_USR,\n" +
            "qc.MODIFY_USR,\n" +
            "CASE WHEN EXISTS (SELECT * FROM program_checkmark pgc WHERE pgc.QUALFCTN_CHKMRK_ID = qc.QUALFCTN_CHKMRK_ID) THEN 1\n" +
            "ELSE 0 END as used_flg\n" +
            "FROM QUALFCTN_CHKMRK qc WHERE 1 = 1";

    private static final String selectProgramCheckmarks =
            "SELECT program_checkmark.QUALFCTN_CHKMRK_ID, QUALFCTN_CHKMRK_NM, QUALFCTN_CHKMRK_INFO, QUALFCTN_CHKMRK_DESC, program_checkmark.EFF_DT, program_checkmark.END_DT\n" +
                    ", program_checkmark.INCNTV_PART_GRP_ID\n" +
                    ", (SELECT INCNTV_PART_GRP_NM FROM incntv_participation_grp WHERE program_checkmark.INCNTV_PART_GRP_ID = incntv_participation_grp.INCNTV_PART_GRP_ID) INCNTV_PART_GRP_NM\n" +
                    ", (SELECT INCNTV_PART_GRP_INFO FROM incntv_participation_grp WHERE program_checkmark.INCNTV_PART_GRP_ID = incntv_participation_grp.INCNTV_PART_GRP_ID) INCNTV_PART_GRP_INFO \n" +
                    ", PGM_CHKMRK_ID, program_checkmark.biz_pgm_incntv_optn_ID\n" +
                    ", (SELECT io.INCNTV_OPTN_ID FROM incentive_option io, biz_pgm_incentive_option bpio WHERE bpio.biz_pgm_incntv_optn_ID = program_checkmark.biz_pgm_incntv_optn_ID AND bpio.INCNTV_OPTN_ID = io.INCNTV_OPTN_ID)\n" +
                    "  as INCNTV_OPTN_ID  \n" +
                    "  , (SELECT io.INCNTV_OPTN_NM FROM incentive_option io, biz_pgm_incentive_option bpio WHERE bpio.biz_pgm_incntv_optn_ID = program_checkmark.biz_pgm_incntv_optn_ID AND bpio.INCNTV_OPTN_ID = io.INCNTV_OPTN_ID)\n" +
                    "  as INCNTV_OPTN_NM\n" +
                    "             FROM \n" +
                    "                QUALFCTN_CHKMRK \n" +
                    "              , program_checkmark \n" +
                    "             WHERE program_checkmark.biz_pgm_id = ?\n" +
                    "               AND program_checkmark.QUALFCTN_CHKMRK_ID = QUALFCTN_CHKMRK.QUALFCTN_CHKMRK_ID\n" +
                    "   ORDER BY QUALFCTN_CHKMRK.QUALFCTN_CHKMRK_NM ";

	private static final String updateProgramCheckmark =
            "UPDATE program_checkmark\n" +
                    "SET QUALFCTN_CHKMRK_ID = ?, INCNTV_PART_GRP_ID = ?, EFF_DT = ?, END_DT = ?, MODIFY_USR = ?, MODIFY_TS = SYSDATE\n" +
                    ", biz_pgm_incntv_optn_ID = ?\n" +
                    "WHERE pgm_chkmrk_ID = ?\t";

    private static final String insertProgramCheckmark =
            "INSERT INTO program_checkmark\n" +
                    "   (QUALFCTN_CHKMRK_ID, BIZ_PGM_ID, INCNTV_PART_GRP_ID, EFF_DT, END_DT, INSERT_USR, INSERT_TS, MODIFY_USR, MODIFY_TS, pgm_chkmrk_ID, biz_pgm_incntv_optn_ID)\n" +
                    "   VALUES\n" +
                    "   (?, ?, ?, ?, ?, ?, SYSDATE, ?, SYSDATE, ?, ?)";

    private static final String selectCheckmarkRequirement =
            "SELECT REQD_QUALFCTN_CHKMRK_ID, QUALFCTN_CHKMRK_ID, REQD_ACTV_QTY\n" +
                    ", QUALFCTN_STAT_CD_ID\n" +
                    ", (SELECT lu_val  FROM luv WHERE QUALFCTN_STAT_CD_ID = lu_id) QUALFCTN_STAT_CD\n" +
                    ", (SELECT lu_desc FROM luv WHERE QUALFCTN_STAT_CD_ID = lu_id) QUALFCTN_STAT_DESC\n" +
                    "FROM REQD_QUALFCTN_CHKMRK\n" +
                    "WHERE QUALFCTN_CHKMRK_ID = ?";

    private static final String selectCheckmarkDetail =
            "SELECT DISTINCT qcd.QUALFCTN_CHKMRK_ID, rqc.REQD_QUALFCTN_CHKMRK_ID\n" +
                    "        , REQD_ACTV_QTY\n" +
                    "        , '' actv_tp, qcd.actv_tp_cd_id, qcd.actv_id, actv_nm\n" +
                    "        , qcd.collection_id\n" +
                    "        , qcd.QUALFCTN_CHKMRK_DETL_ID\n" +
                    "        , '' COLLECTION_NM\n" +
                    "        FROM \n" +
                    "          QUALFCTN_CHKMRK_DETL qcd\n" +
                    "        , REQD_QUALFCTN_CHKMRK  rqc\n" +
                    "        , activity actv        \n" +
                    "        WHERE\n" +
                    "        actv.actv_id = \n" +
                    "           CASE WHEN qcd.actv_id IS NOT NULL THEN qcd.actv_id ELSE NULL END\n" +
                    "        AND qcd.QUALFCTN_CHKMRK_ID = ?\n" +
                    "        AND qcd.REQD_QUALFCTN_CHKMRK_ID = ?\n" +
                    "        AND rqc.QUALFCTN_CHKMRK_ID = qcd.QUALFCTN_CHKMRK_ID \n" +
                    "        AND rqc.REQD_QUALFCTN_CHKMRK_ID = qcd.REQD_QUALFCTN_CHKMRK_ID\n" +
                    "        UNION\n" +
                    "        SELECT DISTINCT qcd.QUALFCTN_CHKMRK_ID, rqc.REQD_QUALFCTN_CHKMRK_ID\n" +
                    "        , REQD_ACTV_QTY\n" +
                    "        , LU_DESC actv_tp, qcd.actv_tp_cd_id, qcd.actv_id, '' actv_nm \n" +
                    "        , qcd.collection_id\n" +
                    "        , qcd.QUALFCTN_CHKMRK_DETL_ID\n" +
                    "        , '' COLLECTION_NM                \n" +
                    "        FROM \n" +
                    "          QUALFCTN_CHKMRK_DETL qcd\n" +
                    "        , REQD_QUALFCTN_CHKMRK  rqc        \n" +
                    "        , luv\n" +
                    "        WHERE\n" +
                    "        lu_id = \n" +
                    "           CASE WHEN qcd.actv_tp_cd_id IS NOT NULL THEN qcd.actv_tp_cd_id ELSE NULL END\n" +
                    "        AND qcd.QUALFCTN_CHKMRK_ID = ?\n" +
                    "        AND qcd.REQD_QUALFCTN_CHKMRK_ID = ?\n" +
                    "        AND rqc.QUALFCTN_CHKMRK_ID = qcd.QUALFCTN_CHKMRK_ID \n" +
                    "        AND rqc.REQD_QUALFCTN_CHKMRK_ID = qcd.REQD_QUALFCTN_CHKMRK_ID\n" +
                    "UNION\n" +
                    "SELECT DISTINCT qcd.QUALFCTN_CHKMRK_ID, rqc.REQD_QUALFCTN_CHKMRK_ID\n" +
                    "        , REQD_ACTV_QTY\n" +
                    "        , '' actv_tp, qcd.actv_tp_cd_id, qcd.actv_id, '' actv_nm \n" +
                    "                , collection.collection_id\n" +
                    "                , qcd.QUALFCTN_CHKMRK_DETL_ID\n" +
                    "                , collection.COLLECTION_NM                \n" +
                    "        FROM \n" +
                    "          QUALFCTN_CHKMRK_DETL qcd\n" +
                    "        , REQD_QUALFCTN_CHKMRK  rqc        \n" +
                    "        , collection\n" +
                    "        WHERE\n" +
                    "            qcd.QUALFCTN_CHKMRK_ID = ?\n" +
                    "        AND qcd.REQD_QUALFCTN_CHKMRK_ID = ?\n" +
                    "        AND rqc.QUALFCTN_CHKMRK_ID = qcd.QUALFCTN_CHKMRK_ID \n" +
                    "        AND rqc.REQD_QUALFCTN_CHKMRK_ID = qcd.REQD_QUALFCTN_CHKMRK_ID\n" +
                    "        AND qcd.collection_id = collection.collection_id ";

    private static final String countCheckmarkDetailRegisteredToContributionTier =
            "SELECT COUNT(*) \n" +
                    "FROM tier_incentive_contribution tic\n" +
                    "WHERE tic.qualfctn_chkmrk_detl_id = ? ";

    private static final String selectAvailableCheckmarks =
            """
            SELECT qc.QUALFCTN_CHKMRK_ID, qc.QUALFCTN_CHKMRK_NM, qc.QUALFCTN_CHKMRK_INFO, qc.QUALFCTN_CHKMRK_DESC, qc.EFF_DT, qc.END_DT FROM QUALFCTN_CHKMRK qc
              , business_program biz
              WHERE  biz.biz_pgm_id = ? AND biz.pgm_end_dt <= qc.END_DT
            ORDER BY QUALFCTN_CHKMRK_NM
            """;

    private static final String deleteProgramCheckmark =
            """
            DELETE FROM program_checkmark WHERE pgm_chkmrk_ID = ?
            """;

    private static final String deleteCheckmarkDetails = """
            DELETE FROM QUALFCTN_CHKMRK_DETL WHERE QUALFCTN_CHKMRK_ID = ?
            """;

    private static final String deleteCheckmarkRequirements = """
            DELETE FROM REQD_QUALFCTN_CHKMRK WHERE QUALFCTN_CHKMRK_ID = ?
            """;

    private final static String deleteQualificationCheckmark = """
            DELETE FROM QUALFCTN_CHKMRK
            WHERE QUALFCTN_CHKMRK_ID = ? AND NOT EXISTS
            (SELECT distinct QUALFCTN_CHKMRK_ID
            FROM   business_program biz
            WHERE QUALFCTN_CHKMRK_ID = ?)
            """;

    private final static String insertQualificationCheckmark = """
            INSERT INTO QUALFCTN_CHKMRK \s
            (QUALFCTN_CHKMRK_ID, QUALFCTN_CHKMRK_NM, QUALFCTN_CHKMRK_INFO, QUALFCTN_CHKMRK_DESC, EFF_DT, END_DT, INSERT_TS, MODIFY_TS, MODIFY_USR, INSERT_USR)
            VALUES (?, ?, ?, ?, ?, ?, SYSDATE, SYSDATE, ?, ?)
            """;

    private final static String updateQualificationCheckmark = """
            UPDATE QUALFCTN_CHKMRK
            SET QUALFCTN_CHKMRK_NM = ?, QUALFCTN_CHKMRK_INFO = ?, QUALFCTN_CHKMRK_DESC = ?, EFF_DT = ?, END_DT = ?, MODIFY_TS = SYSDATE, MODIFY_USR = ?
            WHERE QUALFCTN_CHKMRK_ID = ?
            """;

    private final static String insertCheckmarkRequirement = """
            INSERT INTO REQD_QUALFCTN_CHKMRK\s
            (QUALFCTN_CHKMRK_ID, REQD_QUALFCTN_CHKMRK_ID, REQD_ACTV_QTY, QUALFCTN_STAT_CD_ID, INSERT_USR, MODIFY_USR, INSERT_TS, MODIFY_TS)
            VALUES (?, ?, ?, ?, ?, ?, SYSDATE, SYSDATE)
            """;

    private final static String insertCheckmarkDetail = """
            INSERT INTO QUALFCTN_CHKMRK_DETL
            (QUALFCTN_CHKMRK_ID, REQD_QUALFCTN_CHKMRK_ID, ACTV_ID, ACTV_TP_CD_ID, collection_id, INSERT_USR, MODIFY_USR, INSERT_TS, MODIFY_TS, qualfctn_chkmrk_detl_id)
            VALUES (?, ?, ?, ?, ?, ?, ?, SYSDATE, SYSDATE, ?)
            """;

    private final static String selectProgramsForCheckmark = """
            SELECT biz_pgm_id FROM program_checkmark WHERE QUALFCTN_CHKMRK_ID = ?
            """;

    // @formatter:on

    private static final String PGM_CHKMRK_SEQ = "pgm_chkmrk_seq";
    private static final String QUALFCTN_CHKMRK_DETL_SEQ = "QUALFCTN_CHKMRK_DETL_SEQ";
    private static final String QUALFCTN_CHKMRK_ID_SEQ = "QUALFCTN_CHKMRK_ID_SEQ";

    private final DataSource dataSource;

    private DataFieldMaxValueIncrementer qualificationCheckmarkIDIncrementer;
    private DataFieldMaxValueIncrementer qualificationCheckmarkDetailIDIncrementer;
    private DataFieldMaxValueIncrementer programCheckmarkIDIncrementer;

    public QualificationCheckmarkDAOJdbc(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @PostConstruct
    private void initialize() {
        setDataSource(dataSource);
        qualificationCheckmarkIDIncrementer = new OracleSequenceMaxValueIncrementer(dataSource, QUALFCTN_CHKMRK_ID_SEQ);
        qualificationCheckmarkDetailIDIncrementer = new OracleSequenceMaxValueIncrementer(dataSource, QUALFCTN_CHKMRK_DETL_SEQ);
        programCheckmarkIDIncrementer = new OracleSequenceMaxValueIncrementer(dataSource, PGM_CHKMRK_SEQ);
    }

    @Override
    public Collection<QualificationCheckmark> getActiveQualificationCheckmarks() throws BPMException, DataAccessException {
        final ArrayList<QualificationCheckmark> lQualificationCheckmarkList = new ArrayList<QualificationCheckmark>();

        JdbcTemplate template = getJdbcTemplate();
        Object[] params = new Object[]{};
        int[] types = new int[]{};

        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectQualificationCheckmarks);
        lQuery.append(" AND SYSDATE <= END_DT ");
        lQuery.append(" ORDER BY QUALFCTN_CHKMRK_NM");

        template.query(lQuery.toString(), params, types, new RowCallbackHandler() {
            public void processRow(ResultSet rs) throws SQLException {
                QualificationCheckmark lQualificationCheckmark = new QualificationCheckmark();
                lQualificationCheckmark.setQualificationCheckmarkID(rs.getInt("QUALFCTN_CHKMRK_ID"));
                lQualificationCheckmark.setQualificationCheckmarkName(rs.getString("QUALFCTN_CHKMRK_NM"));
                lQualificationCheckmark.setQualificationCheckmarkInfo(rs.getString("QUALFCTN_CHKMRK_INFO"));
                lQualificationCheckmark.setQualificationCheckmarkDesc(rs.getString("QUALFCTN_CHKMRK_DESC"));
                lQualificationCheckmark.setEffectiveDate(rs.getDate("EFF_DT"));
                lQualificationCheckmark.setEndDate(rs.getDate("END_DT"));
                lQualificationCheckmark.setInsertDate(rs.getDate("INSERT_TS"));
                lQualificationCheckmark.setModifyDate(rs.getDate("MODIFY_TS"));
                lQualificationCheckmark.setInsertUser(rs.getString("INSERT_USR"));
                lQualificationCheckmark.setModifyUser(rs.getString("MODIFY_USR"));

                lQualificationCheckmark.setEffectiveDateString(BPMAdminUtils.formatDateMMddyyyy(lQualificationCheckmark.getEffectiveDate()));
                lQualificationCheckmark.setEndDateString(BPMAdminUtils.formatDateMMddyyyy(lQualificationCheckmark.getEndDate()));
                lQualificationCheckmark.setInsertDate(lQualificationCheckmark.getInsertDate());
                lQualificationCheckmark.setModifyDate(lQualificationCheckmark.getModifyDate());

                lQualificationCheckmark.setUsed(rs.getInt("used_flg"));

                lQualificationCheckmarkList.add(lQualificationCheckmark);
            }
        });

        return lQualificationCheckmarkList;
    }

    @Override
    public ArrayList<ProgramCheckmark> getProgramCheckmarks(Integer pProgramID) throws DataAccessException {
        return getProgramCheckmarks(pProgramID, this.selectProgramCheckmarks);
    }

    /**
     * @param pProgramID
     * @param lQuery
     * @return
     * @throws DataAccessException
     */
    public ArrayList<ProgramCheckmark> getProgramCheckmarks(final Integer pProgramID, String lQuery) throws DataAccessException {
        final ArrayList<ProgramCheckmark> lProgramCheckmarkList = new ArrayList<ProgramCheckmark>();

        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{pProgramID};
        int types[] = new int[]{Types.INTEGER};

        template.query(lQuery, params, types, new RowCallbackHandler() {
            public void processRow(ResultSet rs) throws SQLException {
                ProgramCheckmark lProgramCheckmark = new ProgramCheckmark();
                lProgramCheckmark.setBusinessProgramID(pProgramID);
                lProgramCheckmark.setQualificationCheckmarkID(rs.getInt("QUALFCTN_CHKMRK_ID"));
                lProgramCheckmark.setQualificationCheckmarkName(rs.getString("QUALFCTN_CHKMRK_NM"));
                lProgramCheckmark.setQualificationCheckmarkInfo(rs.getString("QUALFCTN_CHKMRK_INFO"));
                lProgramCheckmark.setQualificationCheckmarkDesc(rs.getString("QUALFCTN_CHKMRK_DESC"));
                lProgramCheckmark.setEffectiveDate(rs.getDate("EFF_DT"));
                lProgramCheckmark.setEndDate(rs.getDate("END_DT"));

                lProgramCheckmark.setParticipationGroupID(rs.getInt("INCNTV_PART_GRP_ID"));
                lProgramCheckmark.setParticipationGroupName(rs.getString("INCNTV_PART_GRP_NM"));
                lProgramCheckmark.setParticipationGroupInfo(rs.getString("INCNTV_PART_GRP_INFO"));

                if (lProgramCheckmark.getEffectiveDate() != null) {
                    lProgramCheckmark.setEffectiveDateString(BPMAdminUtils.formatDateMMddyyyy(lProgramCheckmark.getEffectiveDate()));
                }
                if (lProgramCheckmark.getEndDate() != null) {
                    lProgramCheckmark.setEndDateString(BPMAdminUtils.formatDateMMddyyyy(lProgramCheckmark.getEndDate()));
                }

                lProgramCheckmark.setProgramCheckmarkID(rs.getInt("PGM_CHKMRK_ID"));
                lProgramCheckmark.setProgramIncentiveOptionID(rs.getInt("biz_pgm_incntv_optn_ID"));
                lProgramCheckmark.setIncentiveOptionID(rs.getInt("INCNTV_OPTN_ID"));
                lProgramCheckmark.setIncentiveOptionName(rs.getString("INCNTV_OPTN_NM"));

                lProgramCheckmarkList.add(lProgramCheckmark);
            }
        });

        return lProgramCheckmarkList;
    }

    @Transactional(timeout = 300, rollbackFor = {DataAccessException.class, BPMException.class})
    public int updateProgramCheckmark(ProgramCheckmark pProgramCheckmark, String pUserID) throws BPMException, DataAccessException {
        int rowUpdated = 0;

        if (doesProgramCheckmarkExist(pProgramCheckmark) == false) {
            return insertProgramCheckmark(pProgramCheckmark, pUserID);
        } else {
            JdbcTemplate template = getJdbcTemplate();
            Object params[] = new Object[]
                    {
                            pProgramCheckmark.getQualificationCheckmarkID()
                            , pProgramCheckmark.getParticipationGroupID()
                            , pProgramCheckmark.getEffectiveDate()
                            , pProgramCheckmark.getEndDate()
                            , pUserID
                            , pProgramCheckmark.getProgramIncentiveOptionID()
                            , pProgramCheckmark.getProgramCheckmarkID()
                    };

            int types[] = new int[]{Types.INTEGER, Types.INTEGER
                    , Types.DATE, Types.DATE
                    , Types.VARCHAR, Types.INTEGER, Types.INTEGER};

            rowUpdated += template.update(updateProgramCheckmark, params, types);
        }

        return rowUpdated;
    }

    /**
     * @param pProgramCheckmark
     * @return
     */
    public boolean doesProgramCheckmarkExist(ProgramCheckmark pProgramCheckmark)
            throws DataAccessException {
        ArrayList<ProgramCheckmark> lProgramCheckmarks =
                getProgramCheckmarks(pProgramCheckmark.getBusinessProgramID());

        for (ProgramCheckmark lProgramCheckmark : lProgramCheckmarks) {
            if (lProgramCheckmark.getQualificationCheckmarkID().intValue() == pProgramCheckmark.getQualificationCheckmarkID().intValue() &&
                    lProgramCheckmark.getProgramIncentiveOptionID().intValue() == pProgramCheckmark.getProgramIncentiveOptionID().intValue()) {
                return true;
            }
        }

        return false;
    }

    /**
     *
     * @param pProgramCheckmark
     * @param pUserID
     * @return
     * @throws BPMException
     * @throws DataAccessException
     */
    @Transactional(timeout = 300, rollbackFor = {DataAccessException.class, BPMException.class})
    public int insertProgramCheckmark(ProgramCheckmark pProgramCheckmark, String pUserID) throws BPMException, DataAccessException {
        int rowInserted = 0;
        JdbcTemplate template = getJdbcTemplate();

        Integer lProgramCheckmarkID = programCheckmarkIDIncrementer.nextIntValue();
        pProgramCheckmark.setProgramCheckmarkID(lProgramCheckmarkID);

        Object params[] = new Object[]{
                pProgramCheckmark.getQualificationCheckmarkID()
                , pProgramCheckmark.getBusinessProgramID()
                , pProgramCheckmark.getParticipationGroupID()
                , pProgramCheckmark.getEffectiveDate()
                , pProgramCheckmark.getEndDate()
                , pUserID, pUserID
                , lProgramCheckmarkID, pProgramCheckmark.getProgramIncentiveOptionID()};

        int types[] = new int[]{Types.INTEGER, Types.INTEGER
                , Types.INTEGER
                , Types.DATE, Types.DATE
                , Types.VARCHAR, Types.VARCHAR, Types.INTEGER, Types.INTEGER};

        rowInserted += template.update(insertProgramCheckmark, params, types);

        return rowInserted;
    }

    /**
     * @param pQualificationCheckmarkID
     * @return
     * @throws BPMException
     * @throws DataAccessException
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Override
    public Collection<CheckmarkRequirement> getCheckmarkRequirements(Integer pQualificationCheckmarkID) throws BPMException, DataAccessException {
        final ArrayList<CheckmarkRequirement> lCheckmarkRequirements;

        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectCheckmarkRequirement);

        ArrayList<Object> lParameters = new ArrayList<Object>();
        ArrayList<Integer> lTypes = new ArrayList<Integer>();

        lParameters.add(pQualificationCheckmarkID);
        lTypes.add(Integer.valueOf(Types.INTEGER));

        // Convert the parameter and types ArrayLists to arrays of primitive types.
        Object params[] = new Object[lParameters.size()];
        lParameters.toArray(params);

        int types[] = new int[lTypes.size()];
        for (int j = 0; j < lTypes.size(); j++) {
            types[j] = ((Integer) lTypes.get(j)).intValue();
        }

        JdbcTemplate template = getJdbcTemplate();

        lCheckmarkRequirements = (ArrayList<CheckmarkRequirement>)
                template.query(lQuery.toString(), params, types, new CheckmarkRequirementRowMapper());


        // Now for each Checkmark Requirement, retrieve the Requirement Details.
        for (int i = 0; i < lCheckmarkRequirements.size(); i++) {
            ArrayList<CheckmarkDetail> lCheckmarkDetails = (ArrayList<CheckmarkDetail>)
                    getCheckmarkDetails(pQualificationCheckmarkID, lCheckmarkRequirements.get(i).getRequirementID());

            lCheckmarkRequirements.get(i).setCheckmarkDetails(lCheckmarkDetails);
        }

        return lCheckmarkRequirements;
    }

    //	 Spring rowMapper class for CheckmarkRequirement.
    // Retrieves the columns values from the resultSet and populates a CheckmarkRequirement
    // object.
    private static final class CheckmarkRequirementRowMapper implements RowMapper {
        public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
            CheckmarkRequirement lCheckmarkRequirement = new CheckmarkRequirement();
            lCheckmarkRequirement.setQualificationCheckmarkID(rs.getInt("QUALFCTN_CHKMRK_ID"));
            lCheckmarkRequirement.setRequirementID(rs.getInt("REQD_QUALFCTN_CHKMRK_ID"));
            lCheckmarkRequirement.setQuantity(rs.getInt("REQD_ACTV_QTY"));
            lCheckmarkRequirement.setQualificationStatusCodeID(rs.getInt("QUALFCTN_STAT_CD_ID"));
            lCheckmarkRequirement.setQualificationStatusCode(rs.getString("QUALFCTN_STAT_CD"));
            lCheckmarkRequirement.setQualificationStatusDesc(rs.getString("QUALFCTN_STAT_DESC"));

            return lCheckmarkRequirement;
        }
    }

    /**
     * @param pQualificationCheckmarkID
     * @return
     * @throws BPMException
     * @throws DataAccessException
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Override
    public Collection<CheckmarkDetail> getCheckmarkDetails(Integer pQualificationCheckmarkID, Integer pRequirementID)
            throws BPMException, DataAccessException {
        final ArrayList<CheckmarkDetail> lCheckmarkDetailList = new ArrayList<CheckmarkDetail>();

        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{pQualificationCheckmarkID, pRequirementID
                , pQualificationCheckmarkID, pRequirementID
                , pQualificationCheckmarkID, pRequirementID};
        int types[] = new int[]{Types.INTEGER, Types.INTEGER
                , Types.INTEGER, Types.INTEGER
                , Types.INTEGER, Types.INTEGER};

        template.query(selectCheckmarkDetail, params, types, new RowCallbackHandler() {
            public void processRow(ResultSet rs) throws SQLException {
                CheckmarkDetail lCheckmarkDetail = new CheckmarkDetail();
                lCheckmarkDetail.setQualificationCheckmarkID(rs.getInt("QUALFCTN_CHKMRK_ID"));
                lCheckmarkDetail.setRequirementID(rs.getInt("REQD_QUALFCTN_CHKMRK_ID"));
                lCheckmarkDetail.setActivityID(rs.getInt("ACTV_ID"));
                lCheckmarkDetail.setActivityName(rs.getString("actv_nm"));
                lCheckmarkDetail.setActivityTypeCodeID(rs.getInt("ACTV_TP_CD_ID"));
                lCheckmarkDetail.setActivityTypeCode(rs.getString("actv_tp"));
                lCheckmarkDetail.setQuantity(rs.getInt("REQD_ACTV_QTY"));
                lCheckmarkDetail.setCollectionID(rs.getInt("collection_id"));
                lCheckmarkDetail.setQualificationCheckmarkDetailID(rs.getInt("QUALFCTN_CHKMRK_DETL_ID"));
                lCheckmarkDetail.setCollectionName(rs.getString("COLLECTION_NM"));

                lCheckmarkDetailList.add(lCheckmarkDetail);
            }
        });

        determineCheckmarkDetailUsed(lCheckmarkDetailList);

        return lCheckmarkDetailList;
    }

    /*
     * if checkmark detail used is set to true, will later drive how to update agains the checkmark requirement and detail tables.  Update using pass by reference.
     */
    private void determineCheckmarkDetailUsed(ArrayList<CheckmarkDetail> lCheckmarkDetailList) throws DataAccessException {
        for (CheckmarkDetail lCheckmarkDetail : lCheckmarkDetailList) {
            boolean isUsed = isCheckmarkDetailRegisteredToContributionTier(lCheckmarkDetail);
            lCheckmarkDetail.setUsed(isUsed);
        }
    }

    private boolean isCheckmarkDetailRegisteredToContributionTier(CheckmarkDetail lCheckmarkDetail) throws DataAccessException {

        final ArrayList<Boolean> results = new ArrayList<Boolean>();
        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{
                lCheckmarkDetail.getQualificationCheckmarkDetailID()
        };
        int types[] = new int[]{Types.INTEGER};
        template.query(countCheckmarkDetailRegisteredToContributionTier, params, types,
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {

                        if (rs.getInt(1) > 0) {
                            results.add(Boolean.valueOf(true));
                        }
                    }
                });

        return results.size() > 0;
    }

    @Override
    public ArrayList<QualificationCheckmark> getAvailableCheckmarks(Integer pProgramID) throws BPMException, DataAccessException {
        final ArrayList<QualificationCheckmark> lQualificationCheckmarkList = new ArrayList<QualificationCheckmark>();

        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{pProgramID};
        int types[] = new int[]{Types.INTEGER};

        template.query(selectAvailableCheckmarks, params, types, new RowCallbackHandler() {
            public void processRow(ResultSet rs) throws SQLException {
                QualificationCheckmark lQualificationCheckmark = new QualificationCheckmark();
                lQualificationCheckmark.setQualificationCheckmarkID(rs.getInt("QUALFCTN_CHKMRK_ID"));
                lQualificationCheckmark.setQualificationCheckmarkName(rs.getString("QUALFCTN_CHKMRK_NM"));
                lQualificationCheckmark.setQualificationCheckmarkInfo(rs.getString("QUALFCTN_CHKMRK_INFO"));
                lQualificationCheckmark.setQualificationCheckmarkDesc(rs.getString("QUALFCTN_CHKMRK_DESC"));
                lQualificationCheckmark.setEffectiveDate(rs.getDate("EFF_DT"));
                lQualificationCheckmark.setEndDate(rs.getDate("END_DT"));

                lQualificationCheckmark.setEffectiveDateString(BPMAdminUtils.formatDateMMddyyyy(lQualificationCheckmark.getEffectiveDate()));
                lQualificationCheckmark.setEndDateString(BPMAdminUtils.formatDateMMddyyyy(lQualificationCheckmark.getEndDate()));

                lQualificationCheckmarkList.add(lQualificationCheckmark);
            }
        });

        return lQualificationCheckmarkList;

    }

    /**
     *
     * @param pProgramCheckmarkID
     * @return
     * @throws BPMException
     * @throws DataAccessException
     */
    @Override
    @Transactional(timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
    public int deleteProgramCheckmark(Integer pProgramCheckmarkID) throws BPMException, DataAccessException {
        JdbcTemplate template = getJdbcTemplate();
        int rowInserted = 0;

        Object params[] = new Object[] {  pProgramCheckmarkID};

        int types[] = new int[] {Types.INTEGER };

        rowInserted = template.update(deleteProgramCheckmark, params, types);

        return rowInserted;
    }

    @Override
    public Collection<QualificationCheckmark> getExpiredQualificationCheckmarks() throws BPMException, DataAccessException {
        final ArrayList<QualificationCheckmark> lQualificationCheckmarkList = new ArrayList<QualificationCheckmark>();

        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{};
        int types[] = new int[]{};

        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectQualificationCheckmarks);
        lQuery.append(" AND SYSDATE > END_DT ");
        lQuery.append(" ORDER BY QUALFCTN_CHKMRK_NM");

        template.query(lQuery.toString(), params, types, new RowCallbackHandler() {
            public void processRow(ResultSet rs) throws SQLException {
                QualificationCheckmark lQualificationCheckmark = new QualificationCheckmark();
                lQualificationCheckmark.setQualificationCheckmarkID(rs.getInt("QUALFCTN_CHKMRK_ID"));
                lQualificationCheckmark.setQualificationCheckmarkName(rs.getString("QUALFCTN_CHKMRK_NM"));
                lQualificationCheckmark.setQualificationCheckmarkInfo(rs.getString("QUALFCTN_CHKMRK_INFO"));
                lQualificationCheckmark.setQualificationCheckmarkDesc(rs.getString("QUALFCTN_CHKMRK_DESC"));
                lQualificationCheckmark.setEffectiveDate(rs.getDate("EFF_DT"));
                lQualificationCheckmark.setEndDate(rs.getDate("END_DT"));
                lQualificationCheckmark.setEffectiveDateString(BPMAdminUtils.formatDateMMddyyyy(lQualificationCheckmark.getEffectiveDate()));
                lQualificationCheckmark.setEndDateString(BPMAdminUtils.formatDateMMddyyyy(lQualificationCheckmark.getEndDate()));
                lQualificationCheckmark.setUsed(rs.getInt("used_flg"));

                lQualificationCheckmarkList.add(lQualificationCheckmark);
            }
        });

        return lQualificationCheckmarkList;
    }

    /**
     * Delete the Checkmark Details for the given Qualification Checkmark ID.
     *
     * @param pQualificationCheckmarkID
     * @return
     * @throws BPMException
     * @throws DataAccessException
     */
    @Override
    public int deleteCheckmarkDetails(Integer pQualificationCheckmarkID) throws BPMException, DataAccessException {
        JdbcTemplate template = getJdbcTemplate();
        int rowInserted = 0;

        Object params[] = new Object[]{pQualificationCheckmarkID};

        int types[] = new int[]{Types.INTEGER};

        rowInserted = template.update(deleteCheckmarkDetails, params, types);

        return rowInserted;
    }

    /**
     * Delete the Requirements for the given Qualification Checkmark ID.
     *
     * @param pQualificationCheckmarkID
     * @return
     * @throws BPMException
     * @throws DataAccessException
     */
    @Override
    public int deleteCheckmarkRequirements(Integer pQualificationCheckmarkID) throws BPMException, DataAccessException {
        JdbcTemplate template = getJdbcTemplate();
        int rowInserted = 0;

        Object params[] = new Object[]{pQualificationCheckmarkID};

        int types[] = new int[]{Types.INTEGER};

        rowInserted = template.update(deleteCheckmarkRequirements, params, types);

        return rowInserted;
    }

    /**
     * @param pPackageID
     * @return
     * @throws DataAccessException
     */
    @Override
    public int deleteQualificationCheckmark(Integer pPackageID) throws BPMException, DataAccessException {
        JdbcTemplate template = getJdbcTemplate();
        int rowInserted = 0;

        Object params[] = new Object[]{pPackageID, pPackageID};

        int types[] = new int[]{Types.INTEGER, Types.INTEGER};

        rowInserted = template.update(deleteQualificationCheckmark, params, types);

        return rowInserted;
    }

    @Override
    public int updateQualificationCheckmark(QualificationCheckmark pQualificationCheckmark, String pModifyUserID) throws BPMException, DataAccessException {
        JdbcTemplate template = getJdbcTemplate();
        int rowInserted = 0;

        if (pQualificationCheckmark.getQualificationCheckmarkID().intValue() == 0) {
            rowInserted = this.insertQualificationCheckmark(pQualificationCheckmark, pModifyUserID);
        } else {
            Object params[] = new Object[]{
                    pQualificationCheckmark.getQualificationCheckmarkName()
                    , pQualificationCheckmark.getQualificationCheckmarkInfo()
                    , pQualificationCheckmark.getQualificationCheckmarkDesc()
                    , pQualificationCheckmark.getEffectiveDate()
                    , pQualificationCheckmark.getEndDate()
                    , pModifyUserID
                    , pQualificationCheckmark.getQualificationCheckmarkID()};

            int types[] = new int[]{
                    Types.VARCHAR, Types.VARCHAR, Types.VARCHAR,
                    Types.DATE, Types.DATE,
                    Types.VARCHAR,
                    Types.INTEGER};

            rowInserted = template.update(updateQualificationCheckmark, params, types);
        }

        return rowInserted;
    }

    /**
     * Insert into the BPM_USR_ENV table. Insert one row for each environment the user has access to.
     *
     * @param pQualificationCheckmark
     * @param pModifyUserID
     * @return
     * @throws DataAccessException
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Override
    public int insertQualificationCheckmark(QualificationCheckmark pQualificationCheckmark, String pModifyUserID) throws BPMException, DataAccessException {
        JdbcTemplate template = getJdbcTemplate();
        int rowInserted = 0;

        Long lQualificationCheckmarkID = qualificationCheckmarkIDIncrementer.nextLongValue();

        Object params[] = new Object[] {  lQualificationCheckmarkID
                , pQualificationCheckmark.getQualificationCheckmarkName()
                , pQualificationCheckmark.getQualificationCheckmarkInfo()
                , pQualificationCheckmark.getQualificationCheckmarkDesc()
                , pQualificationCheckmark.getEffectiveDate()
                , pQualificationCheckmark.getEndDate()
                , pModifyUserID, pModifyUserID};

        int types[] = new int[] {Types.INTEGER,
                Types.VARCHAR, Types.VARCHAR, Types.VARCHAR,
                Types.DATE, Types.DATE,
                Types.VARCHAR, Types.VARCHAR};

        rowInserted = template.update(insertQualificationCheckmark, params, types);

        pQualificationCheckmark.setQualificationCheckmarkID(lQualificationCheckmarkID.intValue());

        return rowInserted;
    }

    /**
     *
     * @param pCheckmarkRequirements
     * @param pModifyUserID
     * @return
     * @throws BPMException
     * @throws DataAccessException
     */
    @Override
    public int insertCheckmarkRequirements(ArrayList<CheckmarkRequirement> pCheckmarkRequirements, String pModifyUserID) throws BPMException, DataAccessException {
        int rowInserted = 0;
        JdbcTemplate template = getJdbcTemplate();

        for (int i = 0; i < pCheckmarkRequirements.size(); i++) {
            CheckmarkRequirement lCheckmarkRequirement = pCheckmarkRequirements.get(i);

            Object params[] = new Object[]{
                    lCheckmarkRequirement.getQualificationCheckmarkID()
                    , lCheckmarkRequirement.getRequirementID()
                    , lCheckmarkRequirement.getQuantity()
                    , lCheckmarkRequirement.getQualificationStatusCodeID()
                    , pModifyUserID
                    , pModifyUserID};

            int types[] = new int[]{
                    Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.INTEGER,
                    Types.VARCHAR, Types.VARCHAR};

            rowInserted = template.update(insertCheckmarkRequirement, params, types);
        }

        return rowInserted;
    }

    /**
     *
     * @param pCheckmarkDetails
     * @param pModifyUserID
     * @return
     * @throws BPMException
     * @throws DataAccessException
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Override
    public int insertCheckmarkDetails(ArrayList<CheckmarkDetail> pCheckmarkDetails, String pModifyUserID) throws BPMException, DataAccessException {
        int rowInserted = 0;
        JdbcTemplate template = getJdbcTemplate();

        for (int i = 0; i < pCheckmarkDetails.size(); i++) {
            CheckmarkDetail lCheckmarkDetail = pCheckmarkDetails.get(i);

            Long lQualificationCheckmarkDetailID = qualificationCheckmarkDetailIDIncrementer.nextLongValue();

            Object params[] = new Object[]{
                    lCheckmarkDetail.getQualificationCheckmarkID()
                    , lCheckmarkDetail.getRequirementID()
                    , lCheckmarkDetail.getActivityID()
                    , lCheckmarkDetail.getActivityTypeCodeID()
                    , lCheckmarkDetail.getCollectionID()
                    , pModifyUserID
                    , pModifyUserID
                    , lQualificationCheckmarkDetailID};

            int types[] = new int[]{
                    Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.INTEGER,
                    Types.VARCHAR, Types.VARCHAR, Types.INTEGER};

            rowInserted = template.update(insertCheckmarkDetail, params, types);
        }

        return rowInserted;
    }

    @Override
    public ArrayList<Integer> getProgramsForCheckmark(Integer pQualificationCheckmarkID) throws BPMException, DataAccessException {
        final ArrayList<Integer> lProgramIDList = new ArrayList<Integer>();

        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{pQualificationCheckmarkID};
        int types[] = new int[]{Types.INTEGER};

        template.query(selectProgramsForCheckmark, params, types, new RowCallbackHandler() {
            public void processRow(ResultSet rs) throws SQLException {
                lProgramIDList.add(rs.getInt("biz_pgm_id"));
            }
        });

        return lProgramIDList;
    }

    @Override
    public int updateCheckmarkRequirementsDirectly(ArrayList<CheckmarkRequirement> pCheckmarkRequirements, String pModifyUserID) throws BPMException, DataAccessException {
        int rowsInserted = 0;

        ArrayList<CheckmarkRequirement> pCheckmarkRequirementsNew = new ArrayList<CheckmarkRequirement>();

        try {

            for (CheckmarkRequirement pCheckmarkRequirement : pCheckmarkRequirements) {
                //
                CheckmarkRequirement pCheckmarkRequirementFound = this.getCheckmarkRequirement(pCheckmarkRequirement.getRequirementID(), pCheckmarkRequirement.getQualificationCheckmarkID());

                //If null, add pCheckmarkRequirement to new checkmarkRequirements arraylist.
                if (pCheckmarkRequirementFound == null) {
                    //Add new checkmark requirement
                    pCheckmarkRequirementsNew.add(pCheckmarkRequirement);
                }
            }
            if (pCheckmarkRequirementsNew.size() > 0) {
                rowsInserted = this.insertCheckmarkRequirements(pCheckmarkRequirementsNew, pModifyUserID);
            }
        } catch (BPMException e) {
            logger.error("BPMException Error at updateCheckmarkRequirementsDirectly. Error is " + e);
            throw e;
        } catch (DataAccessException da) {
            logger.error("DataAccessException Error at updateCheckmarkRequirementsDirectly. Error is " + da);
            throw da;
        }

        return rowsInserted;
    }

    /**
     *
     * @param pRequirementID
     * @param pQualificationCheckmarkID
     * @return
     * @throws BPMException
     * @throws DataAccessException
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Override
    public CheckmarkRequirement getCheckmarkRequirement(Integer pRequirementID, Integer pQualificationCheckmarkID) throws BPMException, DataAccessException {
        final ArrayList<CheckmarkRequirement> lCheckmarkRequirements;

        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectCheckmarkRequirement);

        ArrayList<Object> lParameters = new ArrayList<Object>();
        ArrayList<Integer> lTypes = new ArrayList<Integer>();

        lParameters.add(pQualificationCheckmarkID);
        lTypes.add(Types.INTEGER);

        lParameters.add(pRequirementID);
        lTypes.add(Types.INTEGER);
        lQuery.append(" AND reqd_qualfctn_chkmrk_id = ? ");

        // Convert the parameter and types ArrayLists to arrays of primitive types.
        Object params[] = new Object[lParameters.size()];
        lParameters.toArray(params);

        int types[] = new int[lTypes.size()];
        for(int j = 0; j < lTypes.size(); j++)
        {
            types[j] = (lTypes.get(j)).intValue();
        }

        JdbcTemplate template = getJdbcTemplate();

        lCheckmarkRequirements = (ArrayList<CheckmarkRequirement>)
                template.query(lQuery.toString(), params, types, new CheckmarkRequirementRowMapper());

        CheckmarkRequirement pCheckmarkRequirementReturn = null;
        if (lCheckmarkRequirements.size() > 0) {
            pCheckmarkRequirementReturn = lCheckmarkRequirements.get(0);
        }

        return pCheckmarkRequirementReturn;
    }

    @Override
    public int updateCheckmarkDetailsDirectly(ArrayList<CheckmarkDetail> pCheckmarkDetails, String pModifyUserID) throws BPMException, DataAccessException {
        int rowsInserted = 0;

        ArrayList<CheckmarkDetail> pCheckmarkDetailsNew = new ArrayList<CheckmarkDetail>();

        for (CheckmarkDetail pCheckmarkDetail : pCheckmarkDetails) {
            if (pCheckmarkDetail.getQualificationCheckmarkDetailID() == null) {
                pCheckmarkDetailsNew.add(pCheckmarkDetail);
            }
        }

        if (pCheckmarkDetailsNew.size() > 0) {
            rowsInserted = insertCheckmarkDetails(pCheckmarkDetailsNew, pModifyUserID);
        }

        return rowsInserted;
    }
}
