package com.healthpartners.app.bpm.dto;

import java.io.Serializable;
import java.sql.Date;

public class ProgramType implements Serializable {
    static final long serialVersionUID = 0L;

    private Integer used;
    private String programTypeCode;
    private String programTypeName;
    private String programTypeDesc;
    private String reportIndicatorTypeCode;
    private Date insertDate;
    private Date modifyDate;
    private String insertUser;
    private String modifyUser;
    private String membershipCommunicationFlag;
    private Date effectiveDate;
    private Date endDate;

    private String effectiveDateString;
    private String endDateString;

    private Integer marketIndicatorID;
    private String marketIndicatorName;
    private Integer authPromoTypeCodeID;
    private String authPromoTypeCode;

    private Integer activationStatusCodeID;
    private String activationStatusCode;


    public String getProgramTypeCode() {
        return programTypeCode;
    }

    public void setProgramTypeCode(String programTypeCode) {
        this.programTypeCode = programTypeCode;
    }

    public String getProgramTypeName() {
        return programTypeName;
    }

    public void setProgramTypeName(String programTypeName) {
        this.programTypeName = programTypeName;
    }

    public String getProgramTypeDesc() {
        return programTypeDesc;
    }

    public void setProgramTypeDesc(String programTypeDesc) {
        this.programTypeDesc = programTypeDesc;
    }

    public Integer getUsed() {
        return used;
    }

    public void setUsed(Integer used) {
        this.used = used;
    }

    public final Date getInsertDate() {
        return insertDate;
    }

    public final void setInsertDate(Date insertDate) {
        this.insertDate = insertDate;
    }

    public final String getInsertUser() {
        return insertUser;
    }

    public final void setInsertUser(String insertUser) {
        this.insertUser = insertUser;
    }

    public final Date getModifyDate() {
        return modifyDate;
    }

    public final void setModifyDate(Date modifyDate) {
        this.modifyDate = modifyDate;
    }

    public final String getModifyUser() {
        return modifyUser;
    }

    public final void setModifyUser(String modifyUser) {
        this.modifyUser = modifyUser;
    }

    public String getMembershipCommunicationFlag() {
        return membershipCommunicationFlag;
    }

    public void setMembershipCommunicationFlag(String membershipCommunicationFlag) {
        this.membershipCommunicationFlag = membershipCommunicationFlag;
    }

    public Date getEffectiveDate() {
        return effectiveDate;
    }

    public void setEffectiveDate(Date effectiveDate) {
        this.effectiveDate = effectiveDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public String getReportIndicatorTypeCode() {
        return reportIndicatorTypeCode;
    }

    public void setReportIndicatorTypeCode(String reportIndicatorTypeCode) {
        this.reportIndicatorTypeCode = reportIndicatorTypeCode;
    }

    public Integer getMarketIndicatorID() {
        return marketIndicatorID;
    }

    public void setMarketIndicatorID(Integer marketIndicatorID) {
        this.marketIndicatorID = marketIndicatorID;
    }

    public Integer getAuthPromoTypeCodeID() {
        return authPromoTypeCodeID;
    }

    public void setAuthPromoTypeCodeID(Integer authPromoTypeCodeID) {
        this.authPromoTypeCodeID = authPromoTypeCodeID;
    }

    public String getMarketIndicatorName() {
        return marketIndicatorName;
    }

    public void setMarketIndicatorName(String marketIndicatorName) {
        this.marketIndicatorName = marketIndicatorName;
    }

    public String getAuthPromoTypeCode() {
        return authPromoTypeCode;
    }

    public void setAuthPromoTypeCode(String authPromoTypeCode) {
        this.authPromoTypeCode = authPromoTypeCode;
    }

    public Integer getActivationStatusCodeID() {
        return activationStatusCodeID;
    }

    public void setActivationStatusCodeID(Integer activationStatusCodeID) {
        this.activationStatusCodeID = activationStatusCodeID;
    }

    public String getActivationStatusCode() {
        return activationStatusCode;
    }

    public void setActivationStatusCode(String activationStatusCode) {
        this.activationStatusCode = activationStatusCode;
    }

    public String getEndDateString() {
        return endDateString;
    }

    public void setEndDateString(String endDateString) {
        this.endDateString = endDateString;
    }

    public String getEffectiveDateString() {
        return effectiveDateString;
    }

    public void setEffectiveDateString(String effectiveDateString) {
        this.effectiveDateString = effectiveDateString;
    }


}
