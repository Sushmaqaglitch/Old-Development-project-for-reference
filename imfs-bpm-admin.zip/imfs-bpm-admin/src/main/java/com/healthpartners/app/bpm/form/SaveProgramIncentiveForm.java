package com.healthpartners.app.bpm.form;

/**
 * @author jxbourbour
 *
 */
public class SaveProgramIncentiveForm extends BaseForm {

	private String actionType;

	private Integer programID;
	
	private Integer[] programIncentiveOptionIDs;
	private Integer[] incentiveOptionIDs;
	private Integer[] programIncentiveOptionStatusIDs;
		
	private String[] incentiveOptionInfos;
	private String[] incentiveOptionAddInfos;		
	
	private Integer[] programIncentiveFulfillReqIDs;
	private Integer[] programIncentiveReportNameIDs;
	private Integer[] incentedStatusTypeCodeIDs;
	private Integer[] incentiveRuleTypeCodeIDs;
	
	private String[] participantCap;
	private String[] familyCap;
	
	private String[] programIncentiveOptionEffDates;	
    private String[] programIncentiveOptionEndDates;
    private String[] programIncentiveOptionActDates;	
    private String[] programIncentiveOptionDelDates;
	private String[] programIncentiveOptionSortOrders;
    private String[] programIncentiveOptionEnrolDeadlineDates;
    private String[] programIncentiveOptionComplDeadlineDates;
    
    private String programEffectiveDate;
    private String programEndDate;
    private String[] creationDates;
    private String[] closeDates; 
    private Integer[] activityDurations;
    
    private Integer[] participationGroupIDs;
    private String[] participationGroupCodes;
    private Integer[] incentiveOptionRewardCardIDs;
    private Integer[] rewardRunFreqIDs;        
    
    private Integer groupID;
  
    private String[] activityCompletionPeriods;
    
    private String[] newHireDates;
    private Integer[] unitTypeCodeIDs;
    
    private Integer[] packageRuleGroupIDs;
    private Integer[] deliveryInfoIDs;
	private Integer subGroupID;
	private String programTypeCodeID;
	private String groupNumber;
	private String groupName;
	private String siteNumber;
	private String siteName;
	String incentiveOptionTypeCode;
	private String[] incentiveOptionNames;

	private Integer programIncentiveAddRemove;
       	
	public SaveProgramIncentiveForm() {
		super();
	}

	public String getActionType() {
		return actionType;
	}

	public void setActionType(String actionType) {
		this.actionType = actionType;
	}

	public final String[] getIncentiveOptionAddInfos() {
		return incentiveOptionAddInfos;
	}

	public final void setIncentiveOptionAddInfos(String[] incentiveOptionAddInfos) {
		this.incentiveOptionAddInfos = incentiveOptionAddInfos;
	}

	public final String[] getIncentiveOptionInfos() {
		return incentiveOptionInfos;
	}

	public final void setIncentiveOptionInfos(String[] incentiveOptionInfos) {
		this.incentiveOptionInfos = incentiveOptionInfos;
	}
			
	public final Integer getProgramID() {
		return programID;
	}

	public final void setProgramID(Integer programID) {
		this.programID = programID;
	}

	public final String[] getProgramIncentiveOptionActDates() {
		return programIncentiveOptionActDates;
	}

	public final void setProgramIncentiveOptionActDates(
			String[] programIncentiveOptionActDates) {
		this.programIncentiveOptionActDates = programIncentiveOptionActDates;
	}

	public final String[] getProgramIncentiveOptionDelDates() {
		return programIncentiveOptionDelDates;
	}

	public final void setProgramIncentiveOptionDelDates(
			String[] programIncentiveOptionDelDates) {
		this.programIncentiveOptionDelDates = programIncentiveOptionDelDates;
	}

	public String[] getProgramIncentiveOptionSortOrders() {
		return programIncentiveOptionSortOrders;
	}

	public void setProgramIncentiveOptionSortOrders(String[] programIncentiveOptionSortOrders) {
		this.programIncentiveOptionSortOrders = programIncentiveOptionSortOrders;
	}

	public String[] getProgramIncentiveOptionEnrolDeadlineDates() {
		return programIncentiveOptionEnrolDeadlineDates;
	}

	public void setProgramIncentiveOptionEnrolDeadlineDates(
			String[] programIncentiveOptionEnrolDeadlineDates) {
		this.programIncentiveOptionEnrolDeadlineDates = programIncentiveOptionEnrolDeadlineDates;
	}

	public String[] getProgramIncentiveOptionComplDeadlineDates() {
		return programIncentiveOptionComplDeadlineDates;
	}

	public void setProgramIncentiveOptionComplDeadlineDates(
			String[] programIncentiveOptionComplDeadlineDates) {
		this.programIncentiveOptionComplDeadlineDates = programIncentiveOptionComplDeadlineDates;
	}

	public final String[] getProgramIncentiveOptionEffDates() {
		return programIncentiveOptionEffDates;
	}

	public final void setProgramIncentiveOptionEffDates(
			String[] programIncentiveOptionEffDates) {
		this.programIncentiveOptionEffDates = programIncentiveOptionEffDates;
	}

	public final String[] getProgramIncentiveOptionEndDates() {
		return programIncentiveOptionEndDates;
	}

	public final void setProgramIncentiveOptionEndDates(
			String[] programIncentiveOptionEndDates) {
		this.programIncentiveOptionEndDates = programIncentiveOptionEndDates;
	}

	public final Integer[] getProgramIncentiveOptionStatusIDs() {
		return programIncentiveOptionStatusIDs;
	}

	public final void setProgramIncentiveOptionStatusIDs(
			Integer[] programIncentiveOptionStatusIDs) {
		this.programIncentiveOptionStatusIDs = programIncentiveOptionStatusIDs;
	}

	public final Integer[] getIncentiveOptionIDs() {
		return incentiveOptionIDs;
	}

	public final void setIncentiveOptionIDs(Integer[] incentiveOptionIDs) {
		this.incentiveOptionIDs = incentiveOptionIDs;
	}
	
	public final String[] getCloseDates() {
		return closeDates;
	}

	public final void setCloseDates(String[] closeDates) {
		this.closeDates = closeDates;
	}

	public final String getProgramEffectiveDate() {
		return programEffectiveDate;
	}

	public final void setProgramEffectiveDate(String programEffectiveDate) {
		this.programEffectiveDate = programEffectiveDate;
	}

	public final String getProgramEndDate() {
		return programEndDate;
	}

	public final void setProgramEndDate(String programEndDate) {
		this.programEndDate = programEndDate;
	}

	public final String[] getCreationDates() {
		return creationDates;
	}

	public final void setCreationDates(String[] creationDates) {
		this.creationDates = creationDates;
	}

	public Integer[] getProgramIncentiveFulfillReqIDs() {
		return programIncentiveFulfillReqIDs;
	}

	public void setProgramIncentiveFulfillReqIDs(
			Integer[] programIncentiveFulfillReqIDs) {
		this.programIncentiveFulfillReqIDs = programIncentiveFulfillReqIDs;
	}
	

	
	public Integer[] getProgramIncentiveReportNameIDs() {
		return programIncentiveReportNameIDs;
	}

	public void setProgramIncentiveReportNameIDs(
			Integer[] programIncentiveReportNameIDs) {
		this.programIncentiveReportNameIDs = programIncentiveReportNameIDs;
	}

	public String[] getParticipantCap() {
		return participantCap;
	}

	public void setParticipantCap(String[] participantCap) {
		this.participantCap = participantCap;
	}

	public String[] getFamilyCap() {
		return familyCap;
	}

	public void setFamilyCap(String[] familyCap) {
		this.familyCap = familyCap;
	}

	public Integer[] getIncentedStatusTypeCodeIDs() {
		return incentedStatusTypeCodeIDs;
	}

	public void setIncentedStatusTypeCodeIDs(Integer[] incentedStatusTypeCodeIDs) {
		this.incentedStatusTypeCodeIDs = incentedStatusTypeCodeIDs;
	}

	public Integer[] getActivityDurations() {
		return activityDurations;
	}

	public void setActivityDurations(Integer[] activityDurations) {
		this.activityDurations = activityDurations;
	}

	public final Integer[] getIncentiveRuleTypeCodeIDs() {
		return incentiveRuleTypeCodeIDs;
	}

	public final void setIncentiveRuleTypeCodeIDs(Integer[] incentiveRuleTypeCodeIDs) {
		this.incentiveRuleTypeCodeIDs = incentiveRuleTypeCodeIDs;
	}

	public Integer[] getParticipationGroupIDs() {
		return participationGroupIDs;
	}

	public void setParticipationGroupIDs(Integer[] participationGroupIDs) {
		this.participationGroupIDs = participationGroupIDs;
	}

	public String[] getParticipationGroupCodes() {
		return participationGroupCodes;
	}

	public void setParticipationGroupCodes(String[] participationGroupCodes) {
		this.participationGroupCodes = participationGroupCodes;
	}

	public Integer[] getIncentiveOptionRewardCardIDs() {
		return incentiveOptionRewardCardIDs;
	}

	public void setIncentiveOptionRewardCardIDs(
			Integer[] incentiveOptionRewardCardIDs) {
		this.incentiveOptionRewardCardIDs = incentiveOptionRewardCardIDs;
	}
	
	

	public Integer[] getRewardRunFreqIDs() {
		return rewardRunFreqIDs;
	}

	public void setRewardRunFreqIDs(Integer[] rewardRunFreqIDs) {
		this.rewardRunFreqIDs = rewardRunFreqIDs;
	}

	public Integer getGroupID() {
		return groupID;
	}

	public void setGroupID(Integer groupID) {
		this.groupID = groupID;
	}

	public String[] getActivityCompletionPeriods() {
		return activityCompletionPeriods;
	}

	public void setActivityCompletionPeriods(String[] activityCompletionPeriods) {
		this.activityCompletionPeriods = activityCompletionPeriods;
	}


	public Integer[] getProgramIncentiveOptionIDs() {
		return programIncentiveOptionIDs;
	}

	public void setProgramIncentiveOptionIDs(Integer[] programIncentiveOptionIDs) {
		this.programIncentiveOptionIDs = programIncentiveOptionIDs;
	}

	public String[] getNewHireDates() {
		return newHireDates;
	}

	public void setNewHireDates(String[] newHireDates) {
		this.newHireDates = newHireDates;
	}

	public Integer[] getUnitTypeCodeIDs() {
		return unitTypeCodeIDs;
	}

	public void setUnitTypeCodeIDs(Integer[] unitTypeCodeIDs) {
		this.unitTypeCodeIDs = unitTypeCodeIDs;
	}

	public final Integer[] getPackageRuleGroupIDs() {
		return packageRuleGroupIDs;
	}

	public final void setPackageRuleGroupIDs(Integer[] packageRuleGroupIDs) {
		this.packageRuleGroupIDs = packageRuleGroupIDs;
	}

	public final Integer[] getDeliveryInfoIDs() {
		return deliveryInfoIDs;
	}

	public final void setDeliveryInfoIDs(Integer[] deliveryInfoIDs) {
		this.deliveryInfoIDs = deliveryInfoIDs;
	}

	public Integer getSubGroupID() {
		return subGroupID;
	}

	public void setSubGroupID(Integer subGroupID) {
		this.subGroupID = subGroupID;
	}

	public String getProgramTypeCodeID() {
		return programTypeCodeID;
	}

	public void setProgramTypeCodeID(String programTypeCodeID) {
		this.programTypeCodeID = programTypeCodeID;
	}

	public String getGroupNumber() {
		return groupNumber;
	}

	public void setGroupNumber(String groupNumber) {
		this.groupNumber = groupNumber;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public String getSiteNumber() {
		return siteNumber;
	}

	public void setSiteNumber(String siteNumber) {
		this.siteNumber = siteNumber;
	}

	public String getSiteName() {
		return siteName;
	}

	public void setSiteName(String siteName) {
		this.siteName = siteName;
	}

	public String getIncentiveOptionTypeCode() {
		return incentiveOptionTypeCode;
	}

	public void setIncentiveOptionTypeCode(String incentiveOptionTypeCode) {
		this.incentiveOptionTypeCode = incentiveOptionTypeCode;
	}

	public Integer getProgramIncentiveAddRemove() {
		return programIncentiveAddRemove;
	}

	public void setProgramIncentiveAddRemove(Integer programIncentiveAddRemove) {
		this.programIncentiveAddRemove = programIncentiveAddRemove;
	}

	public String[] getIncentiveOptionNames() {
		return incentiveOptionNames;
	}

	public void setIncentiveOptionNames(String[] incentiveOptionNames) {
		this.incentiveOptionNames = incentiveOptionNames;
	}
}
