package com.healthpartners.app.bpm.dto;

import com.healthpartners.service.bpm.dto.BaseDTO;

import java.sql.Date;

/**
 *
 * @author jxbourbour
 *
 */
public class ExemptionHistory extends BaseDTO {

	static final long serialVersionUID = 0L;

	private String exemptionTypeCodeDesc;

	private Date exemptionDate;
	private Date processingDate;
	private String approver;
	private String memberID;
	private String memberStatus;
	private Integer contractNumber;
	private String contractStatus;
	private String groupNumber;
	private String groupName;
	private String siteNumber;
	private String siteName;
	private Date qualificationStartDate;
	private Date qualificationEndDate;
	private Date programEffectiveDate;
	private Date programEndDate;
	private String programName;
	private Integer programIncentiveOptionID;
	private String incentiveOptionName;
	private String firstName;
	private String lastName;
	private String middleName;
	private String memberName;
	private String userID;
	private Date createDate;

	private String createdBy;

	private Integer rowNumber;

	public ExemptionHistory()
	{
		super();
	}

	public final String getExemptionTypeCodeDesc() {
		return exemptionTypeCodeDesc;
	}

	public final void setExemptionTypeCodeDesc(String exemptionTypeCodeDesc) {
		this.exemptionTypeCodeDesc = exemptionTypeCodeDesc;
	}

	public final Date getExemptionDate() {
		return exemptionDate;
	}

	public final void setExemptionDate(Date exemptionDate) {
		this.exemptionDate = exemptionDate;
	}

	public final Date getProcessingDate() {
		return processingDate;
	}

	public final void setProcessingDate(Date processingDate) {
		this.processingDate = processingDate;
	}

	public final String getApprover() {
		return approver;
	}

	public final void setApprover(String approver) {
		this.approver = approver;
	}

	public final String getMemberID() {
		return memberID;
	}

	public final void setMemberID(String memberID) {
		this.memberID = memberID;
	}

	public final String getMemberStatus() {
		return memberStatus;
	}

	public final void setMemberStatus(String memberStatus) {
		this.memberStatus = memberStatus;
	}

	public final Integer getContractNumber() {
		return contractNumber;
	}

	public final void setContractNumber(Integer contractNumber) {
		this.contractNumber = contractNumber;
	}

	public final String getContractStatus() {
		return contractStatus;
	}

	public final void setContractStatus(String contractStatus) {
		this.contractStatus = contractStatus;
	}

	public String getGroupNumber() {
		return groupNumber;
	}

	public void setGroupNumber(String groupNumber) {
		this.groupNumber = groupNumber;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public final String getSiteNumber() {
		return siteNumber;
	}

	public final void setSiteNumber(String siteNumber) {
		this.siteNumber = siteNumber;
	}

	public final String getSiteName() {
		return siteName;
	}

	public final void setSiteName(String siteName) {
		this.siteName = siteName;
	}

	public final Date getQualificationStartDate() {
		return qualificationStartDate;
	}

	public final void setQualificationStartDate(Date qualificationStartDate) {
		this.qualificationStartDate = qualificationStartDate;
	}

	public final Date getQualificationEndDate() {
		return qualificationEndDate;
	}

	public final void setQualificationEndDate(Date qualificationEndDate) {
		this.qualificationEndDate = qualificationEndDate;
	}

	public final String getProgramName() {
		return programName;
	}

	public final void setProgramName(String programName) {
		this.programName = programName;
	}

	public final Date getProgramEffectiveDate() {
		return programEffectiveDate;
	}

	public final void setProgramEffectiveDate(Date programEffectiveDate) {
		this.programEffectiveDate = programEffectiveDate;
	}

	public final Date getProgramEndDate() {
		return programEndDate;
	}

	public final void setProgramEndDate(Date programEndDate) {
		this.programEndDate = programEndDate;
	}


	public Integer getProgramIncentiveOptionID() {
		return programIncentiveOptionID;
	}

	public void setProgramIncentiveOptionID(Integer programIncentiveOptionID) {
		this.programIncentiveOptionID = programIncentiveOptionID;
	}

	public String getIncentiveOptionName() {
		return incentiveOptionName;
	}

	public void setIncentiveOptionName(String incentiveOptionName) {
		this.incentiveOptionName = incentiveOptionName;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getMemberName() {
		return this.lastName + ", " + this.firstName + " " + this.middleName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getUserID() {
		return userID;
	}

	public void setUserID(String userID) {
		this.userID = userID;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public Integer getRowNumber() {
		return rowNumber;
	}

	public void setRowNumber(Integer rowNumber) {
		this.rowNumber = rowNumber;
	}
}
