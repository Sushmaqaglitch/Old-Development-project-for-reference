package com.healthpartners.app.bpm.dto;

import java.io.Serializable;
import java.sql.Date;

public class CDHPFulfillmentSearch implements Serializable {
    static final long serialVersionUID = 0L;


    private String groupNo;
    private String groupName;
    private String siteNo;
    private String contractNo;
    private String memberNo;
    private Date programStartDate;
    private Date fileSentFromDate;
    private Date fileSentToDate;
    private String productType;
    private String cdhpTableType;


    public String getGroupNo() {
        return groupNo;
    }

    public void setGroupNo(String groupNo) {
        this.groupNo = groupNo;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public String getSiteNo() {
        return siteNo;
    }

    public void setSiteNo(String siteNo) {
        this.siteNo = siteNo;
    }

    public String getContractNo() {
        return contractNo;
    }

    public void setContractNo(String contractNo) {
        this.contractNo = contractNo;
    }

    public String getMemberNo() {
        return memberNo;
    }

    public void setMemberNo(String memberNo) {
        this.memberNo = memberNo;
    }

    public Date getProgramStartDate() {
        return programStartDate;
    }

    public void setProgramStartDate(Date programStartDate) {
        this.programStartDate = programStartDate;
    }

    public Date getFileSentFromDate() {
        return fileSentFromDate;
    }

    public void setFileSentFromDate(Date fileSentFromDate) {
        this.fileSentFromDate = fileSentFromDate;
    }

    public Date getFileSentToDate() {
        return fileSentToDate;
    }

    public void setFileSentToDate(Date fileSentToDate) {
        this.fileSentToDate = fileSentToDate;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public String getCdhpTableType() {
        return cdhpTableType;
    }

    public void setCdhpTableType(String cdhpTableType) {
        this.cdhpTableType = cdhpTableType;
    }


}
