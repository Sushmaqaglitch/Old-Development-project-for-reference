package com.healthpartners.app.bpm.dto;

import com.healthpartners.app.bpm.pageable.BPMPageable;

import java.util.ArrayList;
import java.util.Iterator;

/**
 * The pageable class serves as a wrapper for the array list of objects, and
 * operations that are performed on those objects. For ex. adding a row number
 * for display.
 * The BPMPagination then has a pointer to an instance of this class.
 * 
 * @author f5929
 *
 */
public class PageableRejectedPerson implements BPMPageable
{
	ArrayList<RejectedPerson> rejectedPersons;
	
    public PageableRejectedPerson()
    {
    	super();
    }
    
    public PageableRejectedPerson(ArrayList<RejectedPerson> pRejectedPersons)
    {
    	rejectedPersons = pRejectedPersons;
    }
        
	public ArrayList<RejectedPerson> getRejectedPersons() {
		return rejectedPersons;
	}

	public void setRejectedPersons(ArrayList<RejectedPerson> rejectedPersons) {
		this.rejectedPersons = rejectedPersons;
	}
    
	public void addRowNumber()
	{
		int startRowNumber = 1;
		Iterator<RejectedPerson> iter = (Iterator<RejectedPerson>) rejectedPersons.iterator();
		while (iter.hasNext()) {
			RejectedPerson personEmployerActivityRecycle = (RejectedPerson) iter.next();
			personEmployerActivityRecycle.setRowNumber(startRowNumber);
			startRowNumber++;
		}
	}
    
}
