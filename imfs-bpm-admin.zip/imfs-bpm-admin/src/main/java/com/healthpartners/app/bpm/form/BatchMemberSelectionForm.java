package com.healthpartners.app.bpm.form;

/**
 * @author mxthoutam
 */
public class BatchMemberSelectionForm extends BaseForm {

    static final long serialVersionUID = 0L;

    private String operationType;

    private String[] selectedProcessLogIDs;

    private int statusLogProcessID;

    public BatchMemberSelectionForm() {
        super();
    }


    public String getOperationType() {
        return operationType;
    }

    public void setOperationType(String operationType) {
        this.operationType = operationType;
    }

    public String[] getSelectedProcessLogIDs() {
        return selectedProcessLogIDs;
    }

    public void setSelectedProcessLogIDs(String[] selectedPersons) {
        this.selectedProcessLogIDs = selectedPersons;
    }

    public final int getStatusLogProcessID() {
        return statusLogProcessID;
    }

    public final void setStatusLogProcessID(int statusLogProcessID) {
        this.statusLogProcessID = statusLogProcessID;
    }


}
