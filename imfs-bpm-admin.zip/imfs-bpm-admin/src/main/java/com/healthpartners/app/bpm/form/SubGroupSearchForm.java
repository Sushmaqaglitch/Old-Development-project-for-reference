/**
 * 
 */
package com.healthpartners.app.bpm.form;

/**
 * @author jxbourbour
 *
 */
public class SubGroupSearchForm extends BaseForm {

	private Integer groupID;
	private Integer subgroupID;
	private String actionType;
	
//	public ActionMessages validateSubGroupSearch(ActionMapping mapping, HttpServletRequest request)
//	{
//		this.validateNotNull("groupID", String.valueOf(groupID), "An Employer-Group selection ");
//
//		if(this.getActionMessages().isEmpty())
//		{
//	        this.validateNotZero("groupID", String.valueOf(groupID), "Group");
//		}
//
//	    return this.getActionMessages();
//	}

	public SubGroupSearchForm() {
		super();
	}

	public Integer getGroupID() {
		return groupID;
	}

	public void setGroupID(Integer groupID) {
		this.groupID = groupID;
	}

	public Integer getSubgroupID() {
		return subgroupID;
	}

	public void setSubgroupID(Integer subgroupID) {
		this.subgroupID = subgroupID;
	}

	public String getActionType() {
		return actionType;
	}

	public void setActionType(String actionType) {
		this.actionType = actionType;
	}

	
}
