package com.healthpartners.app.bpm.form;

/**
 * @author jxbourbour
 */
public class SaveProgramContributionTierForm extends BaseForm {

    static final long serialVersionUID = 0L;


    Integer programID;
    Integer incentiveOptionID;

    String tierTypeID;

    String tierContributionID;

    String activityID;

    String activityTypeCodeID;

    String[] programBenefitContractTypeIDs;
    String[] relationshipIDs;
    String[] contributionAmounts;

    String programBenefitContractTypeID;
    String relationshipID;
    String contributionAmount;

    String rowID;

    private Integer groupID;

    public SaveProgramContributionTierForm() {
        super();
    }

    public Integer getProgramID() {
        return programID;
    }

    public void setProgramID(Integer programID) {
        this.programID = programID;
    }

    public Integer getIncentiveOptionID() {
        return incentiveOptionID;
    }

    public void setIncentiveOptionID(Integer incentiveOptionID) {
        this.incentiveOptionID = incentiveOptionID;
    }


    public String getTierTypeID() {
        return tierTypeID;
    }

    public void setTierTypeID(String tierTypeID) {
        this.tierTypeID = tierTypeID;
    }

    public String getTierContributionID() {
        return tierContributionID;
    }

    public void setTierContributionID(String tierContributionID) {
        this.tierContributionID = tierContributionID;
    }

    public String getActivityID() {
        return activityID;
    }

    public void setActivityID(String activityID) {
        this.activityID = activityID;
    }


    public String getActivityTypeCodeID() {
        return activityTypeCodeID;
    }

    public void setActivityTypeCodeID(String activityTypeCodeID) {
        this.activityTypeCodeID = activityTypeCodeID;
    }

    public String[] getProgramBenefitContractTypeIDs() {
        return programBenefitContractTypeIDs;
    }

    public void setProgramBenefitContractTypeIDs(
            String[] programBenefitContractTypeIDs) {
        this.programBenefitContractTypeIDs = programBenefitContractTypeIDs;
    }


    public String[] getRelationshipIDs() {
        return relationshipIDs;
    }

    public void setRelationshipIDs(String[] relationshipIDs) {
        this.relationshipIDs = relationshipIDs;
    }

    public String[] getContributionAmounts() {
        return contributionAmounts;
    }

    public void setContributionAmounts(String[] contributionAmounts) {
        this.contributionAmounts = contributionAmounts;
    }


    public String getRowID() {
        return rowID;
    }

    public void setRowID(String rowID) {
        this.rowID = rowID;
    }


    public String getProgramBenefitContractTypeID() {
        return programBenefitContractTypeID;
    }

    public void setProgramBenefitContractTypeID(String programBenefitContractTypeID) {
        this.programBenefitContractTypeID = programBenefitContractTypeID;
    }

    public String getRelationshipID() {
        return relationshipID;
    }

    public void setRelationshipID(String relationshipID) {
        this.relationshipID = relationshipID;
    }

    public String getContributionAmount() {
        return contributionAmount;
    }

    public void setContributionAmount(String contributionAmount) {
        this.contributionAmount = contributionAmount;
    }

    public Integer getGroupID() {
        return groupID;
    }

    public void setGroupID(Integer groupID) {
        this.groupID = groupID;
    }
}
