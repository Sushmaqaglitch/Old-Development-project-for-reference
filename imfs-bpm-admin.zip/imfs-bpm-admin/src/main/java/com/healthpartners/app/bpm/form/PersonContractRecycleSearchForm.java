package com.healthpartners.app.bpm.form;

import com.healthpartners.app.bpm.dto.LookUpValueCode;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.util.ArrayList;

/**
 * @author jxbourbour
 *
 */
public class PersonContractRecycleSearchForm extends BaseForm {

	static final long serialVersionUID = 0L;
	
	protected final Log logger = LogFactory.getLog(getClass());
	
	private String recycleId;
	private String memberId;
	private String contractNo;
	private String groupNo;
	
	private String recycleStatusDate;
	private String programName;
	private String recycleStatusId;
	private String actionType;
	private ArrayList<LookUpValueCode> recycleStatusCodes;
	
	
	private String recycleStatusUpdateDate;
	private String reason;
	private String recycleStatusUpdateId;	
	private String approver;
	private String[] selectedRecycleIDs;
	

	public ArrayList<LookUpValueCode> getRecycleStatusCodes() {
		return recycleStatusCodes;
	}


	public void setRecycleStatusCodes(ArrayList<LookUpValueCode> recycleStatusCodes) {
		this.recycleStatusCodes = recycleStatusCodes;
	}


	public PersonContractRecycleSearchForm() {
		super();
	}
	
	
//	public ActionMessages validateForRecycleSearch(ActionMapping mapping,
//			HttpServletRequest request)
//	{
//		boolean minimumOneSearchTarget = false;
//		if (memberId.length() > 0) {
//			validateNotInteger("memberId", memberId, "Member ID");
//			minimumOneSearchTarget = true;
//		}
//		if (groupNo.length() > 0) {
//			validateNotInteger("groupNo", groupNo, "Group Number");
//			minimumOneSearchTarget = true;
//		}
//		if (contractNo.length() > 0) {
//			validateNotInteger("contractNo", contractNo, "Contract Number");
//			minimumOneSearchTarget = true;
//		}
//		if (programName.length() > 0) {
//			minimumOneSearchTarget = true;
//		}
//		if (recycleStatusId.length() > 0 && !recycleStatusId.equals("select")) {
//			minimumOneSearchTarget = true;
//		}
//		if (recycleStatusId.equals("select")) {
//			recycleStatusId = "";
//		}
//
//		if (recycleStatusDate.length() > 0) {
//			validateNotDate("recycleStatusDate", recycleStatusDate.toString(),
//			"Contract Status Date ");
//			minimumOneSearchTarget = true;
//		}
//		if (!minimumOneSearchTarget)
//		{
//			String[] fieldValues = {};
//			validateAtleastOneSelection("", fieldValues, "field element to search on");
//		}
//
//		return getActionMessages();
//	}
//
//	protected boolean validateBothNotNull(String fieldElement,
//                                          String fieldValue,
//                                          String fieldValue2,
//                                          String messageAppender)
//	{
//		boolean result = true;
//		if (fieldValue == null || fieldValue.trim().length() <= 0)
//		{
//			if(fieldValue2 == null || fieldValue2.trim().length() <= 0)
//			{
//			    getActionMessages().add(fieldElement, new ActionError(
//					"errors.required", messageAppender));
//			    result = false;
//			}
//		}
//		return result;
//	}
//
//
//	public ActionMessages validateForRecycleUpdate(ActionMapping mapping,
//			HttpServletRequest request)
//	{
//		if (recycleStatusId.equalsIgnoreCase("select"))
//		{
//			recycleStatusId = "";
//		}
//
//		if (recycleStatusId.length() <= 0 || recycleStatusId.equals("select"))
//		{
//			getActionMessages().add("Recycle Status", new ActionError("errors.required", "Recycle Status"));
//		}
//
//		if (recycleStatusDate.length() > 0)
//		{
//			validateNotDate("recycleStatusDate", recycleStatusDate.toString(), "Status Date");
//		}
//
//		this.validateNotNull("Approver", approver);
//		this.validateEmptyString("Approver", approver);
//		this.validateNotNull("Reason", reason);
//		this.validateEmptyString("Reason", reason);
//
//		return getActionMessages();
//	}

	public String getMemberId() {
		if(memberId != null)
		{
			return memberId.trim();
		}
		return memberId;
	}


	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}


	public String getContractNo() {
		if(contractNo != null)
		{
			return contractNo.trim();
		}
		return contractNo;
	}


	public void setContractNo(String contractNo) {
		this.contractNo = contractNo;
	}




	public String getRecycleStatusDate() {
		return recycleStatusDate;
	}


	public void setRecycleStatusDate(String recycleStatusDate) {
		this.recycleStatusDate = recycleStatusDate;
	}


	public String getProgramName() {
		return programName;
	}


	public void setProgramName(String programName) {
		this.programName = programName;
	}


	public String getGroupNo() {
		if(groupNo != null)
		{
			return groupNo.trim();
		}
		return groupNo;
	}


	public void setGroupNo(String groupNo) {
		this.groupNo = groupNo;
	}


	public String getRecycleStatusId() {
		return recycleStatusId;
	}


	public void setRecycleStatusId(String recycleStatusId) {
		this.recycleStatusId = recycleStatusId;
	}


	public String getRecycleId() {
		return recycleId;
	}


	public void setRecycleId(String recycleId) {
		this.recycleId = recycleId;
	}


	public String getActionType() {
		return actionType;
	}


	public void setActionType(String actionType) {
		this.actionType = actionType;
	}


	public final String getRecycleStatusUpdateDate() {
		return recycleStatusUpdateDate;
	}


	public final void setRecycleStatusUpdateDate(String recycleStatusUpdateDate) {
		this.recycleStatusUpdateDate = recycleStatusUpdateDate;
	}


	public final String getReason() {
		return reason;
	}


	public final void setReason(String reason) {
		this.reason = reason;
	}


	public final String getRecycleStatusUpdateId() {
		return recycleStatusUpdateId;
	}


	public final void setRecycleStatusUpdateId(String recycleStatusUpdateId) {
		this.recycleStatusUpdateId = recycleStatusUpdateId;
	}


	public final String getApprover() {
		return approver;
	}


	public final void setApprover(String approver) {
		this.approver = approver;
	}


	public final String[] getSelectedRecycleIDs() {
		return selectedRecycleIDs;
	}


	public final void setSelectedRecycleIDs(String[] selectedRecycleIDs) {
		this.selectedRecycleIDs = selectedRecycleIDs;
	}


	
	
}
