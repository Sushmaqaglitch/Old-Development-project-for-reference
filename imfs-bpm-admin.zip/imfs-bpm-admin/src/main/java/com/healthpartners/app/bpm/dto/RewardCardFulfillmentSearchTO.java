package com.healthpartners.app.bpm.dto;

import java.io.Serializable;
import java.sql.Date;

public class RewardCardFulfillmentSearchTO implements Serializable {
    static final long serialVersionUID = 0L;


    private String groupNo;
    private String groupName;
    private String siteNo;
    private String contractNo;
    private String memberNo;
    private String cachePersonID;
    private String transactionID;
    private Date programStartDate;
    private Date fulfillmentFromDate;
    private Date fulfillmentToDate;
    private Integer rewardFulfillHistID;
    private Integer rewardStatusCodeID;
    private Integer rewardCardID;


    public String getGroupNo() {
        return groupNo;
    }

    public void setGroupNo(String groupNo) {
        this.groupNo = groupNo;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public String getSiteNo() {
        return siteNo;
    }

    public void setSiteNo(String siteNo) {
        this.siteNo = siteNo;
    }

    public String getContractNo() {
        return contractNo;
    }

    public void setContractNo(String contractNo) {
        this.contractNo = contractNo;
    }

    public String getMemberNo() {
        return memberNo;
    }

    public void setMemberNo(String memberNo) {
        this.memberNo = memberNo;
    }


    public String getCachePersonID() {
        return cachePersonID;
    }

    public void setCachePersonID(String cachePersonID) {
        this.cachePersonID = cachePersonID;
    }

    public String getTransactionID() {
        return transactionID;
    }

    public void setTransactionID(String transactionID) {
        this.transactionID = transactionID;
    }

    public Date getProgramStartDate() {
        return programStartDate;
    }

    public void setProgramStartDate(Date programStartDate) {
        this.programStartDate = programStartDate;
    }


    public Date getFulfillmentFromDate() {
        return fulfillmentFromDate;
    }

    public void setFulfillmentFromDate(Date fulfillmentFromDate) {
        this.fulfillmentFromDate = fulfillmentFromDate;
    }

    public Date getFulfillmentToDate() {
        return fulfillmentToDate;
    }

    public void setFulfillmentToDate(Date fulfillmentToDate) {
        this.fulfillmentToDate = fulfillmentToDate;
    }

    public Integer getRewardFulfillHistID() {
        return rewardFulfillHistID;
    }

    public void setRewardFulfillHistID(Integer rewardFulfillHistID) {
        this.rewardFulfillHistID = rewardFulfillHistID;
    }

    public Integer getRewardStatusCodeID() {
        return rewardStatusCodeID;
    }

    public void setRewardStatusCodeID(Integer rewardStatusCodeID) {
        this.rewardStatusCodeID = rewardStatusCodeID;
    }

    public Integer getRewardCardID() {
        return rewardCardID;
    }

    public void setRewardCardID(Integer rewardCardID) {
        this.rewardCardID = rewardCardID;
    }


}
