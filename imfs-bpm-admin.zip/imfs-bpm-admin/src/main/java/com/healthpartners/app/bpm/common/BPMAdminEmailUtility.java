package com.healthpartners.app.bpm.common;

import com.healthpartners.app.bpm.exception.BPMException;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import java.net.MalformedURLException;
import java.util.List;


/**
 * @author mxthoutam
 */
@Component
public class BPMAdminEmailUtility {

    public final String EMAIL_CONTENT_TYPE_HTML = "HTML";

    public final String EMAIL_CONTENT_TYPE_TEXT = "TEXT";

    private JavaMailSenderImpl mailSender;

    public void sendEmail(String mailSenderHostAddress, String emailFromAddress, List<String> emailToAddress, String emailSubject, String emailContent, String emailContentType, String emailAttachmentLocation) throws BPMException {

        MimeMessage mailMessage = mailSender.createMimeMessage();

        // Text or HTML email?
        boolean isHTMLEmail = (emailContentType != null && emailContentType.equalsIgnoreCase(EMAIL_CONTENT_TYPE_HTML));

        // Turn on multipart support only if attachments are to be sent.
        boolean hasAttachment = (emailAttachmentLocation != null && emailAttachmentLocation.trim().length() > 0);

        MimeMessageHelper mimeMessageHelper = null;
        try {
            mimeMessageHelper = new MimeMessageHelper(mailMessage, hasAttachment);

            mimeMessageHelper.setFrom(emailFromAddress);
            mimeMessageHelper.setTo(emailToAddress.toArray(new String[0]));
            mimeMessageHelper.setSubject(emailSubject == null ? "" : emailSubject);
            mimeMessageHelper.setText(emailContent, isHTMLEmail);

            if (hasAttachment) {
                String attachmentName = null;
                Resource resource = null;

                try {
                    resource = new UrlResource(emailAttachmentLocation);
                    attachmentName = emailSubject + "_" + resource.getFilename();
                } catch (MalformedURLException e) {
                    // could not resolve resource as a URL. Try loading from
                    // classpath
                    resource = new ClassPathResource(emailAttachmentLocation);
                    attachmentName = emailAttachmentLocation;
                }

                if (resource != null && attachmentName != null) {
                    mimeMessageHelper.addAttachment(attachmentName, resource);
                } else {
                    throw new BPMException("Could not create attachment for email");
                }
            }
        } catch (MessagingException me) {
            throw new BPMException("Could not create email");
        }

        mailSender.setHost(mailSenderHostAddress);

        mailSender.send(mailMessage);
    }

    public JavaMailSenderImpl getMailSender() {
        return mailSender;
    }

    public void setMailSender(JavaMailSenderImpl mailSender) {
        this.mailSender = mailSender;
    }

}
