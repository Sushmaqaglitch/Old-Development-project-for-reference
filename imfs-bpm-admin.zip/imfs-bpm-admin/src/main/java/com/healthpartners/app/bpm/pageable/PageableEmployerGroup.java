package com.healthpartners.app.bpm.pageable;

import com.healthpartners.app.bpm.dto.EmployerGroup;

import java.util.ArrayList;
import java.util.Iterator;

/**
 * The pageable class serves as a wrapper for the array list of objects, and
 * operations that are performed on those objects. For ex. adding a row number
 * for display.
 * The BPMPagination then has a pointer to an instance of this class.
 * 
 * @author jxbourbour
 *
 */
public class PageableEmployerGroup implements BPMPageable
{
    ArrayList<EmployerGroup> employerGroups;
	
	public PageableEmployerGroup()
	{
		super();
	}

	public PageableEmployerGroup(ArrayList<EmployerGroup> pEmployerGroups)
	{
		employerGroups = pEmployerGroups;
	}		

	public ArrayList<EmployerGroup> getEmployerGroups() {
		return employerGroups;
	}

	public void setEmployerGroups(ArrayList<EmployerGroup> employerGroups) {
		this.employerGroups = employerGroups;
	}
	
	public void addRowNumber()
	{
		int startRowNumber = 1;
		Iterator<EmployerGroup> iter = (Iterator<EmployerGroup>) employerGroups.iterator();
		while (iter.hasNext()) {
			EmployerGroup lEmployerGroup = (EmployerGroup) iter.next();
			lEmployerGroup.setRowNumber(startRowNumber);
			startRowNumber++;
		}
	}
}
