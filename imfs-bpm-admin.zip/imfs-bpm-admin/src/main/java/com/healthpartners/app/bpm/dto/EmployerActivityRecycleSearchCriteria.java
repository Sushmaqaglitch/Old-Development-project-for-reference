package com.healthpartners.app.bpm.dto;

import com.healthpartners.service.bpm.dto.BaseDTO;

/**
 * @author f5929
 */
public class EmployerActivityRecycleSearchCriteria extends BaseDTO {
    static final long serialVersionUID = 0L;

    private String activityDate;
    private String activityName;
    private String firstName;
    private String lastName;
    private String recycleStatusID;
    private String recycleStatusDateString;

    public EmployerActivityRecycleSearchCriteria() {
        super();
    }

    public final String getRecycleStatusID() {
        return recycleStatusID;
    }

    public final void setRecycleStatusID(String recycleStatusID) {
        this.recycleStatusID = recycleStatusID;
    }

    public final String getRecycleStatusDateString() {
        return recycleStatusDateString;
    }

    public final void setRecycleStatusDateString(String recycleStatusDateString) {
        this.recycleStatusDateString = recycleStatusDateString;
    }

    public String getActivityDate() {
        return activityDate;
    }

    public void setActivityDate(String activityDate) {
        this.activityDate = activityDate;
    }

    public String getActivityName() {
        return activityName;
    }

    public void setActivityName(String activityName) {
        this.activityName = activityName;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
}
