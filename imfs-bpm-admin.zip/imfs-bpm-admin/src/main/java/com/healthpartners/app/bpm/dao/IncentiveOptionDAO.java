package com.healthpartners.app.bpm.dao;

import com.healthpartners.app.bpm.dto.IncentiveOption;
import com.healthpartners.app.bpm.dto.ProgramIncentiveOption;
import org.springframework.dao.DataAccessException;

import java.util.Collection;

public interface IncentiveOptionDAO {

    Collection<ProgramIncentiveOption> getProgramIncentiveOptions(Integer programID) throws DataAccessException;

    int deleteProgramIncentiveOption(Integer pProgramIncentiveOptionID) throws DataAccessException, Exception;

    int updateProgramIncentiveOption(ProgramIncentiveOption pProgramIncentiveOption, String pUserID) throws DataAccessException;

    Collection<ProgramIncentiveOption> getProgramIncentiveOption(Integer programID, Integer pIncentiveOptionID) throws DataAccessException;

    int insertProgramIncentiveOption(ProgramIncentiveOption pProgramIncentiveOption, String pUserID) throws DataAccessException;

    Collection<IncentiveOption> getIncentiveOptions() throws DataAccessException;

    Collection<Integer> selectNumberOfProgramIncentives(Integer pIncentiveOptionID);

    Collection<IncentiveOption> getActiveIncentiveOptions() throws DataAccessException;

    int deleteContractProgramIncentiveStatusByID(Integer pProgramIncentiveOptionID) throws DataAccessException;
}
