package com.healthpartners.app.bpm.dto;

import java.io.Serializable;
import java.sql.Date;

public class RewardCardFulfillmentRecycleSearchTO implements Serializable {
    static final long serialVersionUID = 0L;


    private String groupNo;
    private String groupName;
    private String siteNo;
    private String contractNo;
    private String memberNo;
    private String cachePersonID;
    private String transactionID;
    private Integer rewardFulfillHistID;
    private Date recycleStatusDate;
    private Integer recycleStatusID;
    private Integer rewardStatusCodeID;


    public String getGroupNo() {
        return groupNo;
    }

    public void setGroupNo(String groupNo) {
        this.groupNo = groupNo;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public String getSiteNo() {
        return siteNo;
    }

    public void setSiteNo(String siteNo) {
        this.siteNo = siteNo;
    }

    public String getContractNo() {
        return contractNo;
    }

    public void setContractNo(String contractNo) {
        this.contractNo = contractNo;
    }

    public String getMemberNo() {
        return memberNo;
    }

    public void setMemberNo(String memberNo) {
        this.memberNo = memberNo;
    }


    public String getCachePersonID() {
        return cachePersonID;
    }

    public void setCachePersonID(String cachePersonID) {
        this.cachePersonID = cachePersonID;
    }

    public String getTransactionID() {
        return transactionID;
    }

    public void setTransactionID(String transactionID) {
        this.transactionID = transactionID;
    }

    public Integer getRewardFulfillHistID() {
        return rewardFulfillHistID;
    }

    public void setRewardFulfillHistID(Integer rewardFulfillHistID) {
        this.rewardFulfillHistID = rewardFulfillHistID;
    }

    public Date getRecycleStatusDate() {
        return recycleStatusDate;
    }

    public void setRecycleStatusDate(Date recycleStatusDate) {
        this.recycleStatusDate = recycleStatusDate;
    }

    public Integer getRecycleStatusID() {
        return recycleStatusID;
    }

    public void setRecycleStatusID(Integer recycleStatusID) {
        this.recycleStatusID = recycleStatusID;
    }

    public Integer getRewardStatusCodeID() {
        return rewardStatusCodeID;
    }

    public void setRewardStatusCodeID(Integer rewardStatusCodeID) {
        this.rewardStatusCodeID = rewardStatusCodeID;
    }


}
