package com.healthpartners.app.bpm.pageable;

import com.healthpartners.app.bpm.dto.PersonContractHist;

import java.util.ArrayList;
import java.util.Iterator;

/**
 * The pageable class serves as a wrapper for the array list of objects, and
 * operations that are performed on those objects. For ex. adding a row number
 * for display.
 * The BPMPagination then has a pointer to an instance of this class.
 * 
 * @author f5929
 *
 */
public class PageablePersonContractHist implements BPMPageable
{
	ArrayList<PersonContractHist> personContractsHist;
	
	public PageablePersonContractHist()
	{
		super();
	}

	public PageablePersonContractHist(ArrayList<PersonContractHist> pPersonContractsHist)
	{
		personContractsHist = pPersonContractsHist;
	}
		
	public ArrayList<PersonContractHist> getPersonContractsHist() {
		return personContractsHist;
	}

	public void setPersonContractsHist(
			ArrayList<PersonContractHist> personContractsHist) {
		this.personContractsHist = personContractsHist;
	}
	
	public void addRowNumber()
	{
		int startRowNumber = 1;
		Iterator<PersonContractHist> iter = (Iterator<PersonContractHist>) personContractsHist.iterator();
		while (iter.hasNext()) {
			PersonContractHist personContractHist = (PersonContractHist) iter.next();
			personContractHist.setRowNumber(startRowNumber);
			startRowNumber++;
		}
	}
}
