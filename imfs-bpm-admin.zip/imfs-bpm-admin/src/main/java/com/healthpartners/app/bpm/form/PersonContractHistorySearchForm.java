package com.healthpartners.app.bpm.form;


public class PersonContractHistorySearchForm extends BaseForm{
    static final long serialVersionUID = 0L;

    private String actionType;

    private String memberID;

    private String contractNo;

    private String programEffectiveDate;

    private String groupNo;

    private Integer luvContractHistResultCodeID;
    private String luvContractHistResultCodeValue;


    public PersonContractHistorySearchForm() {
        super();
    }


    public String getMemberID() {
        if(memberID != null)
        {
            return memberID.trim();
        }
        return memberID;
    }


    public void setMemberID(String memberID) {
        this.memberID = memberID;
    }


    public String getContractNo() {
        if(contractNo != null)
        {
            return contractNo.trim();
        }
        return contractNo;
    }


    public void setContractNo(String contractNo) {
        this.contractNo = contractNo;
    }

    public String getGroupNo() {
        if(groupNo != null)
        {
            return groupNo.trim();
        }
        return groupNo;
    }


    public void setGroupNo(String groupNo) {
        this.groupNo = groupNo;
    }



    public String getProgramEffectiveDate() {
        return programEffectiveDate;
    }


    public void setProgramEffectiveDate(String programEffectiveDate) {
        this.programEffectiveDate = programEffectiveDate;
    }


    public String getActionType() {
        return actionType;
    }


    public void setActionType(String actionType) {
        this.actionType = actionType;
    }




    public Integer getLuvContractHistResultCodeID() {
        return luvContractHistResultCodeID;
    }


    public void setLuvContractHistResultCodeID(Integer luvContractHistResultCodeID) {
        this.luvContractHistResultCodeID = luvContractHistResultCodeID;
    }


    public String getLuvContractHistResultCodeValue() {
        return luvContractHistResultCodeValue;
    }


    public void setLuvContractHistResultCodeValue(String luvContractHistResultCodeValue) {
        this.luvContractHistResultCodeValue = luvContractHistResultCodeValue;
    }

}
