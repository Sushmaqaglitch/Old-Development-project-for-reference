package com.healthpartners.app.bpm.controller;

import com.healthpartners.app.bpm.exception.BPMException;
import com.healthpartners.app.bpm.form.GroupSiteExceptionSearchForm;
import com.healthpartners.app.bpm.iface.BusinessProgramService;
import com.healthpartners.app.bpm.service.GroupSiteExceptionService;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class ProgramPrinterController extends BaseController {
    private final Log logger = LogFactory.getLog(getClass());


    @GetMapping("/viewProgramPrinter")
    public String load(ModelMap modelMap) throws BPMException {
        try {
            modelMap.put("businessProgram", getUserSession().getBusinessProgram());
            modelMap.put("programCheckmarks", getUserSession().getProgramCheckmarks());
            modelMap.put("programPackages", getUserSession().getProgramPackages());
            modelMap.put("programIncentiveOptions", getUserSession().getProgramIncentiveOptions());
            modelMap.put("additionalInfos", getUserSession().getAdditionalInfos());
            modelMap.put("eligibleActivities", getUserSession().getEligibleActivities());
            modelMap.put("programActivityIncentivesSummary", getUserSession().getProgramActivityIncentivesSummary());
            modelMap.put("extendedAuthCodes", getUserSession().getExtendedAuthCodes());

        } catch (Exception e) {
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
            createErrorMessageOnModel(modelMap, getStackTrace(e));
        }

        return "viewProgramPrinter";
    }
}
