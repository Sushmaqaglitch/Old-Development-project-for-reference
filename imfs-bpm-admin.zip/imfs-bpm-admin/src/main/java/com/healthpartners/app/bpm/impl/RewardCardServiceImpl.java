/* $Id: RuleGroupServiceImpl.java 153225 2008-01-16 19:56:08Z mxthoutam $ */

package com.healthpartners.app.bpm.impl;


import com.healthpartners.app.bpm.common.BPMAdminConstants;
import com.healthpartners.app.bpm.common.BPMAdminUtils;
import com.healthpartners.app.bpm.dao.LookUpValueDAO;
import com.healthpartners.app.bpm.dao.RewardCardDAO;
import com.healthpartners.app.bpm.dto.*;
import com.healthpartners.app.bpm.exception.BPMException;
import com.healthpartners.app.bpm.iface.RewardCardService;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import java.sql.Date;
import java.util.ArrayList;
import java.util.Collection;


/**
 * @author tjquist
 * 
 */
@Service
public class RewardCardServiceImpl implements RewardCardService {

	protected final Log logger = LogFactory.getLog(getClass());
	
	private final RewardCardDAO rewardCardDAO;
	
	
	private final LookUpValueDAO lookUpValueDAO;

	public RewardCardServiceImpl(RewardCardDAO rewardCardDAO, LookUpValueDAO lookUpValueDAO) {
		this.rewardCardDAO = rewardCardDAO;
		this.lookUpValueDAO = lookUpValueDAO;
	}


	/*
	 * If reward card assigned to incentive option, find reward card name and run frequency name and set to program incentive option object.
	 */
	@Override
	public ProgramIncentiveOption getProgramIncentiveOptionSupportingRewardCardAttributes(ProgramIncentiveOption lProgramIncentiveOption) throws DataAccessException {
		
		
		if (lProgramIncentiveOption.getIncentiveOptionRewardCardID() != null) {
			IncentiveOptionRewardCard lIncentiveOptionRewardCard = rewardCardDAO.getIncentiveOptionRewardCard(lProgramIncentiveOption.getIncentiveOptionRewardCardID());
			lProgramIncentiveOption.setIncentiveOptionRewardCard(lIncentiveOptionRewardCard);
			lProgramIncentiveOption.setIncentiveOptionRewardCardName(lIncentiveOptionRewardCard.getIncentiveOptionRewardCardName());
		} else {
			lProgramIncentiveOption.setIncentiveOptionRewardCardID(0);
			lProgramIncentiveOption.setIncentiveOptionRewardCardName("select");
		}
		
		LookUpValueCode luv = lookUpValueDAO.getLUVCodeById(lProgramIncentiveOption.getRunFrequencyID());
		if (luv != null) {
			lProgramIncentiveOption.setRunFrequencyValue(luv.getLuvVal());
		} else {
			lProgramIncentiveOption.setRunFrequencyValue("select");
		}
		
		return lProgramIncentiveOption;
	}

	@Override
	public int updateProgramRewardControllerForBatchProcessing(Integer programID, Integer incentiveOptionID, Integer rewardCardID, Integer runFreqID, Date programEffDate, String systemID)  throws BPMException, DataAccessException {

		int returnCode = rewardCardDAO.updateProgramRewardControllerForBatchProcessing(programID, incentiveOptionID, rewardCardID, runFreqID, programEffDate, systemID);

		return returnCode;
	}

	@Override
	public Collection<IncentiveOptionRewardCard> getIncentiveOptionRewardCardTypes() throws DataAccessException {
		Collection<IncentiveOptionRewardCard> incentiveOptionRewardCardTypes = null;

		try {
			incentiveOptionRewardCardTypes = rewardCardDAO.getIncentiveOptionRewardCards();
		} catch (DataAccessException dae) {
			logger.error("DataAccessException: " + dae.getMessage(), dae);
			throw dae;
		}

		return incentiveOptionRewardCardTypes;
	}

	@Override
	public Collection<RewardCard> getRewardCardTypes() throws DataAccessException {
		Collection<RewardCard> rewardCardTypes = null;

		try {
			rewardCardTypes = rewardCardDAO.getRewardCards();
		} catch (DataAccessException dae) {
			logger.error("DataAccessException: " + dae.getMessage(), dae);
			throw dae;
		}

		return rewardCardTypes;
	}

	/*
	 * Get the fulfill tracking report detail information based on the type of fulfillment record.  If externalTransID is numeric, indicates
	 * that the reward card order was sent through the BPM Intelispend batch process.  If not numeric, indicates the reward card order
	 * was manually entered in the vendors website and loaded back into BPM from the shipping detail report.
	 */
	public RewardCardFulfillmentTrackingReportHist getRewardCardFulfillmentTrackingReportHistDetail(Integer rewardFulfillHistID, String externalTransID)
			throws DataAccessException {
		RewardCardFulfillmentTrackingReportHist lRewardCardFulfillmentTrackingReportHist = null;

		try {

			Collection<RewardCardFulfillmentReportHistStatus> lRewardCardFulfillmentReportHistStatuses = rewardCardDAO.getRewardCardFulfillmentTrackingReportStatuses(rewardFulfillHistID);

			//externalTransID of null indicates order hasn't been shipped yet.
			if (externalTransID == null || BPMAdminUtils.isValueInteger(externalTransID) ||  externalTransID.isEmpty()) {
				lRewardCardFulfillmentTrackingReportHist = rewardCardDAO.getRewardCardFulfillmentTrackingReportHistDetail(rewardFulfillHistID);
				lRewardCardFulfillmentTrackingReportHist.setRewardCardFulfillmentReportHistStatuses(lRewardCardFulfillmentReportHistStatuses);
				Integer rewardTransHistID = lRewardCardFulfillmentTrackingReportHist.getRewardFulfillHistID();
				Integer programID = lRewardCardFulfillmentTrackingReportHist.getProgramID();
				Integer personDemographicsID = lRewardCardFulfillmentTrackingReportHist.getPersonDemographicsID();
				Integer incentiveOptionID = lRewardCardFulfillmentTrackingReportHist.getIncentiveOptionID();
				RewardCardAddress lRewardCardAddress = rewardCardDAO.getRewardCardAddress(rewardTransHistID, programID, personDemographicsID, incentiveOptionID);
				lRewardCardFulfillmentTrackingReportHist.setRewardCardAddress(lRewardCardAddress);
			} else {
				lRewardCardFulfillmentTrackingReportHist = rewardCardDAO.getRewardCardFulfillmentTrackingReportHistManualDetail(rewardFulfillHistID);
				lRewardCardFulfillmentTrackingReportHist.setRewardCardFulfillmentReportHistStatuses(lRewardCardFulfillmentReportHistStatuses);
			}

		} catch (DataAccessException dae) {
			logger.error("DataAccessException: " + dae.getMessage(), dae);
			throw dae;
		}


		return lRewardCardFulfillmentTrackingReportHist;
	}


	@Override
	public Collection<RewardCardFulfillmentTrackingReportHist> getRewardCardFulfillmentTrackingReportHistSearch(RewardCardFulfillmentSearchTO lRewardCardFulfillmentSearchTO) throws DataAccessException {
		ArrayList<RewardCardFulfillmentTrackingReportHist> lRewardCardFulfillmentTrackingReportsHistList = new ArrayList<RewardCardFulfillmentTrackingReportHist>();

		try {
			Collection<RewardCardFulfillmentTrackingReportHist> lRewardCardFulfillmentTrackingReportsHist = rewardCardDAO.getRewardCardFulfillmentTrackingReportHistSearch(lRewardCardFulfillmentSearchTO);
			for (RewardCardFulfillmentTrackingReportHist lRewardCardFulfillmentTrackingReportHist : lRewardCardFulfillmentTrackingReportsHist) {
				lRewardCardFulfillmentSearchTO.setRewardFulfillHistID(lRewardCardFulfillmentTrackingReportHist.getRewardFulfillHistID());
				RewardCardFulfillmentReportHistStatus lRewardCardFulfillmentReportHistStatus = rewardCardDAO.getRewardCardFulfillmentTrackingReportStatus(lRewardCardFulfillmentSearchTO, null);
				if (lRewardCardFulfillmentReportHistStatus.getRewardStatus().equals(BPMAdminConstants.REWARD_STATUS_NOT_FOUND)) {
					//Only return reward fulfillments when status exists.
				} else {
					lRewardCardFulfillmentTrackingReportHist.setRewardCardFulfillmentReportHistStatus(lRewardCardFulfillmentReportHistStatus);
					lRewardCardFulfillmentTrackingReportsHistList.add(lRewardCardFulfillmentTrackingReportHist);
				}
			}

		} catch (DataAccessException dae) {
			logger.error("DataAccessException: " + dae.getMessage(), dae);
			throw dae;
		}

		return lRewardCardFulfillmentTrackingReportsHistList;
	}
	public Collection<RewardCardFee> getRewardCardFeeTypes()
			throws DataAccessException {
		Collection<RewardCardFee> rewardCardFeeTypes = null;

		try {
			rewardCardFeeTypes = rewardCardDAO.getRewardCardFees();
		} catch (DataAccessException dae) {
			logger.error("DataAccessException: " + dae.getMessage(), dae);
			throw dae;
		}

		return rewardCardFeeTypes;
	}


	public Collection<RewardEmbossedLine> getRewardCardEmbossedLineTypes()
			throws DataAccessException {
		Collection<RewardEmbossedLine> rewardEmbossedLineTypes = null;

		try {
			rewardEmbossedLineTypes = rewardCardDAO.getRewardCardEmbossedLines();
		} catch (DataAccessException dae) {
			logger.error("DataAccessException: " + dae.getMessage(), dae);
			throw dae;
		}

		return rewardEmbossedLineTypes;
	}

	public Collection<RewardCarrierMessage> getRewardCardCarrierMessageTypes()
			throws DataAccessException {
		Collection<RewardCarrierMessage> rewardCardCarrierMessageTypes = null;

		try {
			rewardCardCarrierMessageTypes = rewardCardDAO.getRewardCarrierMessages();
		} catch (DataAccessException dae) {
			logger.error("DataAccessException: " + dae.getMessage(), dae);
			throw dae;
		}

		return rewardCardCarrierMessageTypes;
	}

	public Collection<RewardTransactionMessage> getRewardCardTransMsgTypes()
			throws DataAccessException {
		Collection<RewardTransactionMessage> rewardCardTransactionMessageTypes = null;

		try {
			rewardCardTransactionMessageTypes = rewardCardDAO.getRewardTransactionMessages();
		} catch (DataAccessException dae) {
			logger.error("DataAccessException: " + dae.getMessage(), dae);
			throw dae;
		}

		return rewardCardTransactionMessageTypes;
	}

	public Collection<RewardCardClientData> getRewardCardClientInfo()
			throws DataAccessException
	{
		return rewardCardDAO.getRewardCardClientInfo();
	}
	public int updateIncentiveOptionRewardCard(IncentiveOptionRewardCard pIncentiveOptionRewardCard, String pModifyUserID)
			throws BPMException, DataAccessException
	{
		return rewardCardDAO.updateIncentiveOptionRewardCard(pIncentiveOptionRewardCard, pModifyUserID);
	}

	public int deleteIncentiveOptionRewardCard(Integer lIncentiveOptionRewardCardID)
			throws BPMException, DataAccessException
	{
		return rewardCardDAO.deleteIncentiveOptionRewardCard(lIncentiveOptionRewardCardID);
	}
}
