package com.healthpartners.app.bpm.pageable;

import com.healthpartners.app.bpm.dto.MemberDetail;

import java.util.ArrayList;
import java.util.Iterator;

/**
 * The pageable class serves as a wrapper for the array list of objects, and
 * operations that are performed on those objects. For ex. adding a row number
 * for display.
 * The BPMPagination then has a pointer to an instance of this class.
 * 
 * @author jxbourbour
 *
 */
public class PageableMemberDetail implements BPMPageable 
{
	ArrayList<MemberDetail> memberDetails;
	
	public PageableMemberDetail()
	{
		super();
	}
	
	public PageableMemberDetail(ArrayList<MemberDetail> pMemberDetails)
	{
		memberDetails = pMemberDetails;
	}
		
	public ArrayList<MemberDetail> getMemberDetails() {
		return memberDetails;
	}

	public void setMemberDetails(ArrayList<MemberDetail> memberDetails) {
		this.memberDetails = memberDetails;
	}
	
	public void addRowNumber()
	{
		int startRowNumber = 1;
		Iterator<MemberDetail> iter = (Iterator<MemberDetail>) memberDetails.iterator();
		while (iter.hasNext()) {
			MemberDetail lMemberDetail = (MemberDetail) iter.next();
			lMemberDetail.setRowNumber(startRowNumber);
			startRowNumber++;
		}
	}
}
