package com.healthpartners.app.bpm.controller;

import com.healthpartners.app.bpm.common.BPMAdminConstants;
import com.healthpartners.app.bpm.common.BPMAdminUtils;
import com.healthpartners.app.bpm.dto.LookUpValueCode;
import com.healthpartners.app.bpm.dto.MemberDetail;
import com.healthpartners.app.bpm.dto.MemberProgramDetail;
import com.healthpartners.app.bpm.exception.BPMException;
import com.healthpartners.app.bpm.form.MemberSearchForm;
import com.healthpartners.app.bpm.iface.MemberService;
import com.healthpartners.service.bpm.common.BPMConstants;
import jakarta.servlet.http.HttpServletRequest;
import org.apache.commons.lang.StringUtils;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.view.RedirectView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;

@Controller
public class MemberSearchController extends BaseController implements Validator {

    private final MemberService memberService;

    public MemberSearchController(MemberService memberService) {
        this.memberService = memberService;
    }

    @GetMapping("/memberSearch")
    public String loadSearch(ModelMap modelMap, HttpServletRequest request) throws BPMException {
        MemberSearchForm form = new MemberSearchForm();
        modelMap.put("memberSearchForm", form);
        String operationType = request.getParameter("operationType");
        if (StringUtils.isNotEmpty(operationType) && ACTION_SEARCH.equals(operationType)) {
            form.setOperationType(operationType);
            return searchAndRefreshMemberDetails(form, modelMap, request);
        }

        return "memberSearch";
    }

    @PostMapping("/memberSearch")
    public String submitSearch(@ModelAttribute("memberSearchForm") MemberSearchForm form, ModelMap modelMap, BindingResult result, HttpServletRequest request) throws Exception {
        try {
            if (StringUtils.isEmpty(form.getOperationType())) {
                form.setOperationType(ACTION_SEARCH);
            }
            if (ACTION_SEARCH.equals(form.getOperationType())) {
                validate(form, result);
                if (!result.hasErrors()) {
                    return searchAndRefreshMemberDetails(form, modelMap, request);
                }
            }
        } catch (Exception e) {
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
            // Add error stack trace on the request, to be hidden in html.
            createErrorMessageOnModel(modelMap, getStackTrace(e));
        }

        return "memberSearch";
    }

    @PostMapping(value = "/memberSearch", params = "next")
    public String submitNext(@ModelAttribute("memberSearchForm") MemberSearchForm form, ModelMap modelMap, HttpServletRequest request) throws Exception {
        return searchAndRefreshMemberDetails(form, modelMap, request);
    }

    @PostMapping(value = "/memberSearch", params = "back")
    public String submitBack(@ModelAttribute("memberSearchForm") MemberSearchForm form, ModelMap modelMap, HttpServletRequest request) throws Exception {
        return searchAndRefreshMemberDetails(form, modelMap, request);
    }

    private String searchAndRefreshMemberDetails(MemberSearchForm thisForm, ModelMap modelMap, HttpServletRequest request) throws BPMException, DataAccessException {
        try {
            setRolesAndPermissions(modelMap);

            String memberID = thisForm.getMemberID();
            if (memberID == null) {
                // When called for the related member ID using the link on the Member Status page,
                // member ID will be a request parameter.
                memberID = (String) request.getParameter("memberID");
                thisForm.setMemberID(memberID);
            }

            if (thisForm.getContractNo() != null && thisForm.getContractNo().trim().length() > 0) {
                // If contractNo has been supplied, find memberID by contractNo
                memberID = findMemberIDByContractNo(thisForm);

                thisForm.setMemberID(memberID);
                // When called by last name and date of birth, member ID will be null
                if (memberID == null || memberID.trim().length() <= 0) {
                    createActionMessagesOnModel(modelMap, "messages.info", new Object[]{"No results found for the given contract number."});
                    return "memberSearch";
                }
            }

            if (memberID != null && memberID.trim().length() > 0) {
                refreshSearchResults(thisForm, modelMap, request);
            }

            if ((thisForm.getLastName() != null && thisForm.getLastName().trim().length() > 0
                    && thisForm.getFirstName() != null && thisForm.getFirstName().trim().length() > 0)
                    ||
                    (thisForm.getLastName() != null && thisForm.getLastName().trim().length() > 0
                            && thisForm.getDateOfBirth() != null && thisForm.getDateOfBirth().trim().length() > 0)
                    ||
                    (thisForm.getFirstName() != null && thisForm.getFirstName().trim().length() > 0
                            && thisForm.getDateOfBirth() != null && thisForm.getDateOfBirth().trim().length() > 0)
                    ||
                    (thisForm.getLastName() != null && thisForm.getLastName().trim().length() > 0
                            && thisForm.getFirstName() != null && thisForm.getFirstName().trim().length() > 0
                            && thisForm.getDateOfBirth() != null && thisForm.getDateOfBirth().trim().length() > 0)
            ) {
                findByNameAndDOB(request, thisForm, modelMap);
                return "memberSearch";
            }

            return "memberStatusDetail";

        } catch (Exception e) {
            logger.error("An unexpected error has occured: " + e.getMessage(), e);
            // Add error stack trace on the request, to be hidden in html.
            createErrorMessageOnModel(modelMap, getStackTrace(e));
            return "memberSearch";
        }
    }

    private void refreshSearchResults(MemberSearchForm form, ModelMap modelMap, HttpServletRequest request) throws BPMException, DataAccessException {
        try {
            String memberID = form.getMemberID();

            // qualificationStartDate is now optional
            java.sql.Date qualificationStartDate = null;

            MemberDetail memberDetail = memberService.getMemberDetail(memberID, qualificationStartDate);

            MemberDetail previousYearMemberDetail = splitCurrentAndPreviousYears(memberDetail);

            ArrayList<MemberDetail> lRelatedMemberDetailList = (ArrayList<MemberDetail>) memberService.getRelatedMemberDetail(memberID, qualificationStartDate);

            if (memberDetail == null) {
                createActionMessagesOnModel(modelMap, "messages.info", new Object[]{"No results found for the given member ID"});
            } else {
                if (memberDetail.getMemberProgramDetails() == null || memberDetail.getMemberProgramDetails().size() <= 0) {
                    ArrayList<MemberProgramDetail> lMemberProgramDetails = memberService.selectPersonProgramRelationship(memberID);

                    if (lMemberProgramDetails != null && lMemberProgramDetails.size() > 0) {
                        for (int i = 0; i < lMemberProgramDetails.size(); i++) {
                            StringBuffer lMessage = new StringBuffer();
                            lMessage.append("Member ID ");
                            lMessage.append(lMemberProgramDetails.get(i).getMemberID());
                            lMessage.append(" has a relationship of ");
                            lMessage.append(lMemberProgramDetails.get(i).getRelationshipCode());
                            lMessage.append(" , in a  ");
                            lMessage.append(lMemberProgramDetails.get(i).getProgramName());
                            lMessage.append(" ");
                            lMessage.append(lMemberProgramDetails.get(i).getParticipationCodeDesc());
                            lMessage.append(" requirement. Group ");
                            lMessage.append(lMemberProgramDetails.get(i).getGroupNumber());
                            lMessage.append(" ");
                            lMessage.append(lMemberProgramDetails.get(i).getGroupName());
                            lMessage.append(" , Site ");
                            lMessage.append(lMemberProgramDetails.get(i).getSiteNumber());
                            lMessage.append(" , from ");
                            lMessage.append(getFmt().format(lMemberProgramDetails.get(i).getEffectiveDate()));
                            lMessage.append("  to ");
                            lMessage.append(getFmt().format(lMemberProgramDetails.get(i).getEndDate()));

                            createActionMessagesOnModel(modelMap, "messages.info", new Object[]{lMessage.toString()});
                        }
                    }
                }
            }

            ArrayList<LookUpValueCode> lActivityEventFilteredOutReasons = getUserSession().getActivityEventFilteredOutReasons();

            if (lActivityEventFilteredOutReasons == null) {
                lActivityEventFilteredOutReasons = (ArrayList<LookUpValueCode>) memberService.getActivityEventFilteredOutReasons();
                getUserSession().setActivityEventFilteredOutReasons(lActivityEventFilteredOutReasons);
            }

            getUserSession().setMemberDetail(memberDetail);
            getUserSession().setPreviousYearMemberDetail(previousYearMemberDetail);
            getUserSession().setRelatedMemberDetailList(lRelatedMemberDetailList);

            modelMap.put("processingStatusFilteredOutConstant", BPMConstants.PROCESSING_STATUS_FILTERD_OUT);

            modelMap.put("memberDetail", memberDetail);
            modelMap.put("previousYearMemberDetail", previousYearMemberDetail);
            modelMap.put("relatedMemberDetailList", lRelatedMemberDetailList);
            modelMap.put("activityEventFilteredOutReasons", lActivityEventFilteredOutReasons);

        } catch (Exception e) {
            e.printStackTrace();
            //throw new BPMException(e);
        }
    }

    private String findMemberIDByContractNo(MemberSearchForm thisForm) {
        String lMemberIDString = thisForm.getMemberID();
        String lContractNoString = thisForm.getContractNo();

        if (lMemberIDString != null && lMemberIDString.length() > 0) {
            return lMemberIDString;
        }

        if (lContractNoString != null && lContractNoString.length() > 0) {
            Integer lContractNo = Integer.parseInt(lContractNoString);

            // Find memberID of Policy Holder from contractNo
            ArrayList<String> lMemberIDs = (ArrayList<String>) memberService.getMemberIDByContractNo(lContractNo);

            if (lMemberIDs.size() > 0) {
                return lMemberIDs.get(0);
            }
        }

        return null;
    }

    private void findByNameAndDOB(HttpServletRequest request, MemberSearchForm thisForm, ModelMap modelMap) throws BPMException, DataAccessException {
        boolean newDTOList = false;
        String operationType = thisForm.getOperationType();
        java.sql.Date lQualificationDate = null; // Just a placeholder for getMemberDetails parameter.
        ArrayList<MemberDetail> lMemberDetails = getUserSession().getMemberDetails();
        if (lMemberDetails == null || operationType.equals(ACTION_SEARCH)) {
            lMemberDetails = new ArrayList<MemberDetail>();
        }


        if (operationType.equals(ACTION_SEARCH) && (lMemberDetails.size() == 0)) {
            newDTOList = true;
            ArrayList<String> lMemberIDs = (ArrayList<String>) memberService.getMemberIDFromPersonDetails(thisForm.getFirstName(), null, thisForm.getLastName(), null, BPMAdminUtils.getSqlDateFromString(thisForm.getDateOfBirth()));

            if (lMemberIDs == null || lMemberIDs.size() <= 0) {
                createActionMessagesOnModel(modelMap, "messages.info", new Object[]{"No results found for the given search attribute(s)"});
                return;
            }

            for (int i = 0; i < lMemberIDs.size(); i++) {
                lMemberDetails.add(memberService.getMemberDemographicsOnly(lMemberIDs.get(i), lQualificationDate));
            }
        }

        getUserSession().setMemberDetails(lMemberDetails);
        //Pagination code begins here.
        setMemberDetailPagination(modelMap, getUserSession(), operationType, newDTOList);
        //Pagination code ends here.
    }

    /**
     * Split the Member Program Details to current year, and previous years based on whether or
     * not the business program end date has passed.
     *
     * @param pAllMemberDetail
     * @return
     */
    private MemberDetail splitCurrentAndPreviousYears(MemberDetail pAllMemberDetail) {
        MemberDetail lPreviousYearMemberDetail = new MemberDetail();

        if (pAllMemberDetail != null) {
            lPreviousYearMemberDetail.setMemberID(pAllMemberDetail.getMemberID());
            lPreviousYearMemberDetail.setLastName(pAllMemberDetail.getLastName());
            lPreviousYearMemberDetail.setFirstName(pAllMemberDetail.getFirstName());
            lPreviousYearMemberDetail.setMiddleInitial(pAllMemberDetail.getMiddleInitial());
            lPreviousYearMemberDetail.setBirthDate(pAllMemberDetail.getBirthDate());

            ArrayList<MemberProgramDetail> lMemberProgramDetails = (ArrayList<MemberProgramDetail>)
                    pAllMemberDetail.getMemberProgramDetails();

            if (lMemberProgramDetails != null) {
                java.util.Date lToday = new java.util.Date(System.currentTimeMillis());
                ArrayList<MemberProgramDetail> lPreviousMemberProgramDetails = new ArrayList<MemberProgramDetail>();
                lPreviousYearMemberDetail.setMemberProgramDetails(lPreviousMemberProgramDetails);

                int lNumberOfDetails = lMemberProgramDetails.size();

                for (int i = 0; i < lNumberOfDetails; i++) {
                    SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
                    String memberEndDate = dateFormat.format(lMemberProgramDetails.get(i).getEndDate());
                    String systemDate = dateFormat.format(lToday);
                    // If the end date has passed, move the member detail to the previous-years array.
                    if (lToday.after(lMemberProgramDetails.get(i).getEndDate()) && !systemDate.equals(memberEndDate)) {
                        lPreviousYearMemberDetail.getMemberProgramDetails().add(lMemberProgramDetails.get(i));
                        lMemberProgramDetails.remove(i);
                        lNumberOfDetails--;
                        i--;
                    }
                }
            }
        }

        return lPreviousYearMemberDetail;
    }

    private void setRolesAndPermissions(ModelMap modelMap) {
        Boolean groupViewAndEditAccess = (Boolean)getUserSessionSupport().getSession().getAttribute(BPMAdminConstants.BPM_ADMIN_GROUP_VIEW_EDIT_ACCESS);
        modelMap.put("groupViewAndEditAccess", groupViewAndEditAccess);
    }

    @Override
    public boolean supports(Class<?> clazz) {
        return MemberSearchForm.class.isAssignableFrom(clazz);
    }

    @Override
    public void validate(Object target, Errors errors) {
        MemberSearchForm form = (MemberSearchForm) target;

        if ((form.getContractNo() == null || form.getContractNo().trim().length() <= 0) &&
                (form.getMemberID() == null || form.getMemberID().trim().length() <= 0) &&
                (form.getLastName() == null || form.getLastName().trim().length() <= 0) &&
                (form.getFirstName() == null || form.getFirstName().trim().length() <= 0) &&
                (form.getDateOfBirth() == null || form.getDateOfBirth().trim().length() <= 0)) {
            getValidationSupport().validateRequiredFieldIsNotEmpty("memberID", form.getMemberID(), errors, new Object[]{"At least one parameter"});
        }

        if (form.getContractNo() != null && form.getContractNo().trim().length() > 0) {
            getValidationSupport().validateNotInteger("contractNo", form.getContractNo(), errors, new Object[]{"Contract Number"});
        }

        if (form.getFirstName() != null && form.getFirstName().trim().length() > 0 &&
                (form.getLastName() == null || form.getLastName().trim().length() <= 0) &&
                (form.getDateOfBirth() == null || form.getDateOfBirth().trim().length() <= 0)) {
            getValidationSupport().validateRequiredFieldIsNotEmpty("lastName", form.getLastName(), errors, new Object[]{"Last name Or Date of Birth"});
        }

        if (form.getLastName() != null && form.getLastName().trim().length() > 0 &&
                (form.getFirstName() == null || form.getFirstName().trim().length() <= 0) &&
                (form.getDateOfBirth() == null || form.getDateOfBirth().trim().length() <= 0)) {
            getValidationSupport().validateRequiredFieldIsNotEmpty("firstName", form.getFirstName(), errors, new Object[]{"First name Or Date of Birth"});
        }

        if (form.getDateOfBirth() != null && form.getDateOfBirth().trim().length() > 0) {
            getValidationSupport().validateDateFormat("dateOfBirth", form.getDateOfBirth(), errors, new Object[]{"Date of Birth"});

            if ((form.getLastName() == null || form.getLastName().trim().length() <= 0) &&
                    (form.getFirstName() == null || form.getFirstName().trim().length() <= 0)) {
                getValidationSupport().validateRequiredFieldIsNotEmpty("lastName", form.getLastName(), errors, new Object[]{"First or Last name"});
            }
        }
    }
}
