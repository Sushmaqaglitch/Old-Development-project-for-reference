package com.healthpartners.app.bpm.pageable;

import com.healthpartners.app.bpm.dto.PersonActivityContributionPending;

import java.util.ArrayList;
import java.util.Iterator;

/**
 * The pageable class serves as a wrapper for the array list of objects, and
 * operations that are performed on those objects. For ex. adding a row number
 * for display.
 * The BPMPagination then has a pointer to an instance of this class.
 *
 * @author tjquist
 */
public class PageablePersonActivityContributionPending implements BPMPageable {
    ArrayList<PersonActivityContributionPending> cPersonActivityContributionsPending;

    public PageablePersonActivityContributionPending() {
        super();
    }

    public PageablePersonActivityContributionPending(ArrayList<PersonActivityContributionPending> pPersonActivityContributionsPending) {
        cPersonActivityContributionsPending = pPersonActivityContributionsPending;
    }

    public ArrayList<PersonActivityContributionPending> getcPersonActivityContributionsPending() {
        return cPersonActivityContributionsPending;
    }

    public void setcPersonActivityContributionsPending(ArrayList<PersonActivityContributionPending> cPersonActivityContributionsPending) {
        this.cPersonActivityContributionsPending = cPersonActivityContributionsPending;
    }

    public void addRowNumber() {
        int startRowNumber = 1;
        Iterator<PersonActivityContributionPending> iter = cPersonActivityContributionsPending.iterator();
        while (iter.hasNext()) {
            PersonActivityContributionPending lPersonActivityContributionPending = iter.next();
            lPersonActivityContributionPending.setRowNumber(startRowNumber);
            startRowNumber++;
        }
    }

}
