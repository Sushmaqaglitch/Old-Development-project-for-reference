package com.healthpartners.app.bpm.controller;

import com.healthpartners.app.bpm.common.BPMAdminConstants;
import com.healthpartners.app.bpm.common.BPMAdminUtils;
import com.healthpartners.app.bpm.dto.Activity;
import com.healthpartners.app.bpm.dto.EmployerGroup;
import com.healthpartners.app.bpm.exception.BPMException;
import com.healthpartners.app.bpm.form.FilteredActivityForm;
import com.healthpartners.app.bpm.iface.BusinessProgramService;
import com.healthpartners.app.bpm.iface.MemberService;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;


@Controller
public class FilteredActivityController  extends BaseController implements Validator {
    private MemberService memberService;
    private BusinessProgramService businessProgramService;

    public FilteredActivityController(MemberService memberService, BusinessProgramService businessProgramService) {
        this.businessProgramService = businessProgramService;
        this.memberService = memberService;
    }



    @GetMapping("/filteredActivities")
    public String load(ModelMap modelMap) throws Exception {
        try {
            FilteredActivityForm filteredActivityForm = new FilteredActivityForm();
            modelMap.put("filteredActivityForm", filteredActivityForm);
            loadActivities(modelMap, filteredActivityForm);
        } catch (Exception e) {
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
            modelMap.put("errorMsg", getStackTrace(e));
        }


        return "filteredActivities";
    }



    @PostMapping("/filteredActivities")
    public String SearchFilteredActivities(@ModelAttribute("filteredActivityForm") FilteredActivityForm form, ModelMap modelMap, BindingResult result,HttpServletRequest request) throws BPMException {
        try {
                performAction(form, modelMap, result);

        } catch (Exception e) {
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
            modelMap.put("errorMsg", getStackTrace(e));
        }

        return "filteredActivities";
    }

    private void loadActivities(ModelMap modelMap, FilteredActivityForm filteredActivityForm ) throws BPMException {
        String operationType = (String)modelMap.getAttribute("lOperationType");
        filteredActivityForm.setOperationType(operationType);
        Collection<Activity> lActivities = (Collection<Activity>) businessProgramService.getActivities();
        modelMap.put("activityList", lActivities);
        Collection<EmployerGroup> lEmployerGroups = (Collection<EmployerGroup>) businessProgramService.getAllBPMGroups();
        modelMap.put("employerGroups", lEmployerGroups);

    }

    private void performAction(FilteredActivityForm form, ModelMap modelMap, BindingResult result) throws BPMException {
       int lNumberOfRows = 0;
        if (ACTION_SEARCH.equals(form.getOperationType())) {
            validate(form, result);

            if(!result.hasErrors()){
                if (form.getMemberID() != null && form.getInsertDate() != null) {
                    Collection<EmployerGroup> lEmployerGroups = (Collection<EmployerGroup>)
                            businessProgramService.getBPMGroupsForMemberAndTransactionDate(form.getMemberID(), BPMAdminUtils.convertStringToSqlDate(form.getInsertDate(), "mm/dd/yyyy"));
                    modelMap.put("employerGroups", lEmployerGroups);
                    Collection<Activity> lActivities = (Collection<Activity>)
                            businessProgramService.getActivitiesWithMemberAndTransactionDate(form.getMemberID(), BPMAdminUtils.convertStringToSqlDate(form.getInsertDate(), "mm/dd/yyyy"));
                    modelMap.put("activityList", lActivities);
                }
                modelMap.put("filteredActivityForm", form);
            }else {
                loadActivities(modelMap, form);
            }
        }

        if (ACTION_UPDATE.equalsIgnoreCase(form.getOperationType())) {
                String lStatusToProcess = null;
                String lProcessingStatus = null;

                validate(form, result);


                if (ACTION_REPROCESS_ACTIVE_ACTIVITIES.equalsIgnoreCase(form.getStatusToProcess())) {
                    lStatusToProcess = "'" + BPMAdminConstants.ACTIVITY_EVENT_ACTIVE + "'";
                } else if (ACTION_REPROCESS_ACTIVE_COMPLETES.equalsIgnoreCase(form.getStatusToProcess())) {
                    lStatusToProcess = "'" + BPMAdminConstants.ACTIVITY_EVENT_COMPLETE + "'"
                            + ", '" + BPMAdminConstants.BPM_ADMIN_ACTIVITY_STATUS_WAIVE + "'"
                            + ", '" + BPMAdminConstants.BPM_ADMIN_ACTIVITY_STATUS_EXEMPT + "'"
                            + ", '" + BPMAdminConstants.BPM_ADMIN_ACTIVITY_STATUS_CANCEL + "'"
                            + ", '" + BPMAdminConstants.BPM_ADMIN_ACTIVITY_STATUS_DELETE + "'"
                            + ", '" + BPMAdminConstants.BPM_ADMIN_ACTIVITY_STATUS_MET + "'"
                            + ", '" + BPMAdminConstants.BPM_ADMIN_ACTIVITY_STATUS_NOT_MET + "'"
                    ;
                } else if (ACTION_REPROCESS_FILTERED_ACTIVES.equalsIgnoreCase(form.getStatusToProcess())) {
                    lStatusToProcess = "'" + BPMAdminConstants.ACTIVITY_EVENT_ACTIVE + "'";
                    lProcessingStatus = BPMAdminConstants.ACTIVITY_EVENT_FILTERED;
                } else if (ACTION_REPROCESS_FILTERED_COMPLETES.equalsIgnoreCase(form.getStatusToProcess())) {
                    lStatusToProcess = "'" + BPMAdminConstants.ACTIVITY_EVENT_COMPLETE + "'"
                            + ", '" + BPMAdminConstants.BPM_ADMIN_ACTIVITY_STATUS_WAIVE + "'"
                            + ", '" + BPMAdminConstants.BPM_ADMIN_ACTIVITY_STATUS_EXEMPT + "'"
                            + ", '" + BPMAdminConstants.BPM_ADMIN_ACTIVITY_STATUS_CANCEL + "'"
                            + ", '" + BPMAdminConstants.BPM_ADMIN_ACTIVITY_STATUS_DELETE + "'"
                            + ", '" + BPMAdminConstants.BPM_ADMIN_ACTIVITY_STATUS_MET + "'"
                            + ", '" + BPMAdminConstants.BPM_ADMIN_ACTIVITY_STATUS_NOT_MET + "'"
                    ;

                    lProcessingStatus = BPMAdminConstants.ACTIVITY_EVENT_FILTERED;
                }

                lNumberOfRows = memberService.updateFilteredActivities(form.getMemberID(), BPMAdminUtils.convertStringToSqlDate(form.getInsertDate(), BPMAdminConstants.HP_BPM_ADMIN_UI_COMMON_DATE_FORMAT), form.getGroupID(), form.getActivityID(), lStatusToProcess, lProcessingStatus);
            }

            String message = getMessage("messages.filteredActivities", new Object[]{lNumberOfRows});
            List<String> messages = new ArrayList<>();
            messages.add(message);
            modelMap.put("messages", messages);
            getUserSession().reset();
        }



    @Override
    public boolean supports(Class<?> clazz) {
        return false;
    }

    @Override
    public void validate(Object target, Errors errors) {
        FilteredActivityForm form = (FilteredActivityForm)target;
       getValidationSupport().validateNotNull("insertDate",form.getInsertDate(), errors, new Object[]{"Transaction Date After"});

        if(form.getInsertDate() != null && form.getInsertDate().length() > 0)
        {
            getValidationSupport().validateDateFormat("insertDate",form.getInsertDate(), errors, new Object[]{"Date Entered "});
        }

        if((form.getInsertDate() == null || form.getInsertDate().length() == 0) &&
                (form.getMemberID() == null   || form.getMemberID().length() == 0) &&
                form.getGroupID() == null)
        {
           getValidationSupport().addValidationFailureMessage("insertDate", errors, "errors.filtered.memberordate", new Object[]{"Member ID", "Transaction Date", "Employer Group"});

        }


        if(form.getGroupID() != null && (form.getInsertDate() == null || form.getInsertDate().length() == 0)
                && (form.getMemberID() == null   || form.getMemberID().length() == 0))
        {
            getValidationSupport().addValidationFailureMessage("insertDate",errors,
                    "errors.oneRequiredWhenSelected",  new Object[]{"Transaction Date", "Employer Group"});
        }

        if(form.getInsertDate() != null && (form.getGroupID() == null)
                && (form.getMemberID() == null   || form.getMemberID().length() == 0))
        {
            getValidationSupport().addValidationFailureMessage("insertDate",errors,
                    "errors.oneRequiredWhenSelected", new Object[]{"Employer Group", "Transaction Date"});
        }
    }
}
