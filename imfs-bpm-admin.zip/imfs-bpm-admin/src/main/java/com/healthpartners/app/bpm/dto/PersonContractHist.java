package com.healthpartners.app.bpm.dto;

import com.healthpartners.service.bpm.dto.BaseDTO;

import java.sql.Date;

/**
 * 
 * @author f5929
 *
 */
public class PersonContractHist extends BaseDTO {
	
	static final long serialVersionUID = 0L;
	
	private Integer rowNumber;
	private String memberID;
	private Integer personContractSeqId;
	private Integer contractNumber;
	private String contractStatus;
	private Date contractStatusDate;
	private Integer programID;
	private String memberStatus;
	private Integer groupId;
	private Integer groupSiteId;
	private Integer personNumber;
	private Integer programTypeId;
	private Date qualificationEndDate;
	private Date qualificationStartDate;
	private Date programEndDate;
	private Date programStartDate;
	private Date runDate;
	private Date memberStatusDate;
	private String groupNumber;
	private String groupSiteNumber;
    private Integer siteNumber;
	private String groupName;
	private String groupSiteName;
	private String programName;
	private String incentiveOptionName;
	private Integer activationStatusCodeID;
	private String activationStatusCode;
	
	
	
    public Integer getGroupId() {
		return groupId;
	}

	public void setGroupId(Integer groupId) {
		this.groupId = groupId;
	}

	public Integer getGroupSiteId() {
		return groupSiteId;
	}

	public void setGroupSiteId(Integer groupSiteId) {
		this.groupSiteId = groupSiteId;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public String getGroupSiteName() {
		return groupSiteName;
	}

	public void setGroupSiteName(String groupSiteName) {
		this.groupSiteName = groupSiteName;
	}

	public PersonContractHist()
    {
    	super();
    }

	public Integer getContractNumber() {
		return contractNumber;
	}

	public void setContractNumber(Integer contractNumber) {
		this.contractNumber = contractNumber;
	}

	public String getGroupNumber() {
		return groupNumber;
	}

	public void setGroupNumber(String groupNumber) {
		this.groupNumber = groupNumber;
	}

	public Integer getPersonNumber() {
		return personNumber;
	}

	public void setPersonNumber(Integer personNumber) {
		this.personNumber = personNumber;
	}

	public Date getQualificationEndDate() {
		return qualificationEndDate;
	}

	public void setQualificationEndDate(Date qualificationEndDate) {
		this.qualificationEndDate = qualificationEndDate;
	}

	public Date getQualificationStartDate() {
		return qualificationStartDate;
	}

	public void setQualificationStartDate(Date qualificationStartDate) {
		this.qualificationStartDate = qualificationStartDate;
	}

	public Date getRunDate() {
		return runDate;
	}

	public void setRunDate(Date runDate) {
		this.runDate = runDate;
	}

	public Integer getSiteNumber() {
		return siteNumber;
	}

	public void setSiteNumber(Integer siteNumber) {
		this.siteNumber = siteNumber;
	}

	
	public Date getMemberStatusDate() {
		return memberStatusDate;
	}

	public void setMemberStatusDate(Date memberStatusDate) {
		this.memberStatusDate = memberStatusDate;
	}

	public String getContractStatus() {
		return contractStatus;
	}

	public void setContractStatus(String contractStatus) {
		this.contractStatus = contractStatus;
	}

	public String getMemberStatus() {
		return memberStatus;
	}

	public void setMemberStatus(String memberStatus) {
		this.memberStatus = memberStatus;
	}


	public Integer getProgramTypeId() {
		return programTypeId;
	}

	public void setProgramTypeId(Integer programTypeId) {
		this.programTypeId = programTypeId;
	}

	public Integer getProgramID() {
		return programID;
	}

	public void setProgramID(Integer programID) {
		this.programID = programID;
	}

	public Integer getPersonContractSeqId() {
		return personContractSeqId;
	}

	public void setPersonContractSeqId(Integer personContractSeqId) {
		this.personContractSeqId = personContractSeqId;
	}

	public String getMemberID() {
		return memberID;
	}

	public void setMemberID(String memberID) {
		this.memberID = memberID;
	}

	public String getGroupSiteNumber() {
		return groupSiteNumber;
	}

	public void setGroupSiteNumber(String groupSiteNumber) {
		this.groupSiteNumber = groupSiteNumber;
	}

	public String getProgramName() {
		return programName;
	}

	public void setProgramName(String programName) {
		this.programName = programName;
	}
	
	

	public String getIncentiveOptionName() {
		return incentiveOptionName;
	}

	public void setIncentiveOptionName(String incentiveOptionName) {
		this.incentiveOptionName = incentiveOptionName;
	}

	public Date getContractStatusDate() {
		return contractStatusDate;
	}

	public void setContractStatusDate(Date contractStatusDate) {
		this.contractStatusDate = contractStatusDate;
	}

	public Date getProgramEndDate() {
		return programEndDate;
	}

	public void setProgramEndDate(Date programEndDate) {
		this.programEndDate = programEndDate;
	}

	public Date getProgramStartDate() {
		return programStartDate;
	}

	public void setProgramStartDate(Date programStartDate) {
		this.programStartDate = programStartDate;
	}

	
	public Integer getRowNumber() {
		return rowNumber;
	}

	public void setRowNumber(Integer rowNumber) {
		this.rowNumber = rowNumber;
	}

	public final String getActivationStatusCode() {
		return activationStatusCode;
	}

	public final void setActivationStatusCode(String activationStatusCode) {
		this.activationStatusCode = activationStatusCode;
	}

	public final Integer getActivationStatusCodeID() {
		return activationStatusCodeID;
	}

	public final void setActivationStatusCodeID(Integer activationStatusCodeID) {
		this.activationStatusCodeID = activationStatusCodeID;
	}

	
    
   
    
    
}
