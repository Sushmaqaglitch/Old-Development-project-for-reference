package com.healthpartners.app.bpm.form;

/**
 * @author jxbourbour
 */
public class SaveProgramActivitySiteForm extends BaseForm {

    private Integer programID;

    private String userAuthCode;
    private String userPromoCode;

    private Integer groupID;
    private Integer subGroupID;
    private String recalculate;
    private String programTypeCodeID;
    private String groupNumber;
    private String groupName;
    private String siteNumber;
    private String siteName;


    public String getActionType() {
        return actionType;
    }


    public void setActionType(String actionType) {
        this.actionType = actionType;
    }


    public Integer getProgramID() {
        return programID;
    }


    public void setProgramID(Integer programID) {
        this.programID = programID;
    }


    public String getUserAuthCode() {
        return userAuthCode;
    }


    public void setUserAuthCode(String userAuthCode) {
        this.userAuthCode = userAuthCode;
    }


    public String getUserPromoCode() {
        return userPromoCode;
    }


    public void setUserPromoCode(String userPromoCode) {
        this.userPromoCode = userPromoCode;
    }


    public Integer getGroupID() {
        return groupID;
    }


    public void setGroupID(Integer groupID) {
        this.groupID = groupID;
    }


    public Integer getSubGroupID() {
        return subGroupID;
    }


    public void setSubGroupID(Integer subGroupID) {
        this.subGroupID = subGroupID;
    }

    public String getRecalculate() {
        return recalculate;
    }

    public void setRecalculate(String recalculate) {
        this.recalculate = recalculate;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public String getProgramTypeCodeID() {
        return programTypeCodeID;
    }

    public void setProgramTypeCodeID(String programTypeCodeID) {
        this.programTypeCodeID = programTypeCodeID;
    }

    public String getGroupNumber() {
        return groupNumber;
    }

    public void setGroupNumber(String groupNumber) {
        this.groupNumber = groupNumber;
    }

    public String getSiteNumber() {
        return siteNumber;
    }

    public void setSiteNumber(String siteNumber) {
        this.siteNumber = siteNumber;
    }

    public String getSiteName() {
        return siteName;
    }

    public void setSiteName(String siteName) {
        this.siteName = siteName;
    }
}
