package com.healthpartners.app.bpm.controller;

import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.http.HttpServletRequest;
import java.util.Map;

@Controller
public class BpmAdminErrorController implements ErrorController {
    
    @GetMapping("/error")
    public String handleError(HttpServletRequest request, Map<String, Object> model) {
        Object httpStatusCode = null;
        String errorMessage = null;

        if (request.getAttribute(RequestDispatcher.ERROR_STATUS_CODE) != null) {
            httpStatusCode = request.getAttribute(RequestDispatcher.ERROR_STATUS_CODE);
        }

        if (request.getAttribute(RequestDispatcher.ERROR_EXCEPTION) != null) {
            Exception exc = (Exception) request.getAttribute(RequestDispatcher.ERROR_EXCEPTION);
            errorMessage = exc.getLocalizedMessage();
        }
        model.put("httpStatusCode", httpStatusCode);
        model.put("errorMessage", errorMessage);

        return "errors";
    }
}
