
package com.healthpartners.app.bpm.dto;

import java.io.Serializable;
import java.util.Collection;

public class MemberDetail implements Serializable {

	static final long serialVersionUID = 0L;
	
	private Integer personDemographicsID;
	private Integer personID;

	private String memberID;

	private String firstName;

	private String lastName;
	
	private String middleInitial;
	
	private java.sql.Date birthDate;
	
	private Integer rowNumber;

	private Collection<MemberProgramDetail> memberProgramDetails;
	
	private String hasBPMProgram;
	
	public MemberDetail() {
		super();
	}
	
		
	public String getFirstName() {
		return firstName;
	}



	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	public String getLastName() {
		return lastName;
	}



	public void setLastName(String lastName) {
		this.lastName = lastName;
	}



	public String getMemberID() {
		return memberID;
	}



	public void setMemberID(String memberID) {
		this.memberID = memberID;
	}



	public Integer getPersonID() {
		return personID;
	}



	public void setPersonID(Integer personID) {
		this.personID = personID;
	}



	public Collection<MemberProgramDetail> getMemberProgramDetails() {
		return memberProgramDetails;
	}


	public void setMemberProgramDetails(
			Collection<MemberProgramDetail> memberProgramDetails) {
		this.memberProgramDetails = memberProgramDetails;
	}


	public String getDisplayName() {
		StringBuffer sb = new StringBuffer("");

		if (getFirstName() != null) {
			sb.append(getFirstName());
			sb.append(" ");
		}

		if (getMiddleInitial() != null) {
			sb.append(getMiddleInitial());
			sb.append(" ");
		}
		
		if (getLastName() != null) {
			sb.append(getLastName());
		}

		if (sb.length() == 0) {
			sb.append("member");
		}

		return sb.toString();
	}


	public final java.sql.Date getBirthDate() {
		return birthDate;
	}


	public final void setBirthDate(java.sql.Date birthDate) {
		this.birthDate = birthDate;
	}


	public final String getMiddleInitial() {
		return middleInitial;
	}


	public final void setMiddleInitial(String middleInitial) {
		this.middleInitial = middleInitial;
	}


	public Integer getRowNumber() {
		return rowNumber;
	}


	public void setRowNumber(Integer rowNumber) {
		this.rowNumber = rowNumber;
	}


	public Integer getPersonDemographicsID() {
		return personDemographicsID;
	}


	public void setPersonDemographicsID(Integer personDemographicsID) {
		this.personDemographicsID = personDemographicsID;
	}


	public String getHasBPMProgram() {
		return hasBPMProgram;
	}


	public void setHasBPMProgram(String hasBPMProgram) {
		this.hasBPMProgram = hasBPMProgram;
	}
	
	
}
