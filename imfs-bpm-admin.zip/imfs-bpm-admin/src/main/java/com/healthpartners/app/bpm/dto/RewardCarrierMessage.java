package com.healthpartners.app.bpm.dto;


public class RewardCarrierMessage
{	
	
	private Integer rewardCarrierMessageID;
	private String rewardCarrierMessageName;
	private String rewardCarrierMessageDescription;
	private String rewardCarrierMessageDescriptionContinued;
	private java.sql.Date effectiveDate;
	private java.sql.Date endDate;
	
	private Integer used;
	
	public Integer getRewardCarrierMessageID() {
		return rewardCarrierMessageID;
	}
	public void setRewardCarrierMessageID(Integer rewardCarrierMessageID) {
		this.rewardCarrierMessageID = rewardCarrierMessageID;
	}
	public String getRewardCarrierMessageName() {
		return rewardCarrierMessageName;
	}
	public void setRewardCarrierMessageName(String rewardCarrierMessageName) {
		this.rewardCarrierMessageName = rewardCarrierMessageName;
	}
	public String getRewardCarrierMessageDescription() {
		return rewardCarrierMessageDescription;
	}
	public void setRewardCarrierMessageDescription(
			String rewardCarrierMessageDescription) {
		this.rewardCarrierMessageDescription = rewardCarrierMessageDescription;
	}
	
	public String getRewardCarrierMessageDescriptionContinued() {
		return rewardCarrierMessageDescriptionContinued;
	}
	public void setRewardCarrierMessageDescriptionContinued(
			String rewardCarrierMessageDescriptionContinued) {
		this.rewardCarrierMessageDescriptionContinued = rewardCarrierMessageDescriptionContinued;
	}
	public java.sql.Date getEffectiveDate() {
		return effectiveDate;
	}
	public void setEffectiveDate(java.sql.Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}
	public java.sql.Date getEndDate() {
		return endDate;
	}
	public void setEndDate(java.sql.Date endDate) {
		this.endDate = endDate;
	}
	public Integer getUsed() {
		return used;
	}
	public void setUsed(Integer used) {
		this.used = used;
	}
	
	
	
	
}
