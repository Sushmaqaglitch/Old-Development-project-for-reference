package com.healthpartners.app.bpm.controller;

import com.healthpartners.app.bpm.common.BPMAdminConstants;
import com.healthpartners.app.bpm.common.BPMAdminUtils;
import com.healthpartners.app.bpm.dto.*;
import com.healthpartners.app.bpm.exception.BPMException;
import com.healthpartners.app.bpm.form.CopyToYearForm;
import com.healthpartners.app.bpm.form.ShowGroupsForm;
import com.healthpartners.app.bpm.iface.BusinessProgramService;
import com.healthpartners.app.bpm.session.UserSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.mvc.support.RedirectAttributesModelMap;
import org.springframework.web.servlet.view.RedirectView;

import jakarta.servlet.http.HttpServletRequest;
import java.util.*;

@Controller
public class GroupController extends BaseController implements Validator {

    private final BusinessProgramService businessProgramService;

    public GroupController(BusinessProgramService businessProgramService) {
        this.businessProgramService = businessProgramService;
    }

    @GetMapping("/showGroups")
    public String loadShowGroupLookup(Map<String, Object> model) {
        ShowGroupsForm showGroupsForm = new ShowGroupsForm();
        model.put("showGroupsForm", showGroupsForm);
        return "showGroups";
    }

    @PostMapping("/showGroups")
    public String submitGroupLookup(@ModelAttribute("showGroupsForm") ShowGroupsForm form, BindingResult result, HttpServletRequest request) throws Exception {
        form.setActionType("showGroups");
        validate(form, result);
        if (!result.hasErrors()) {
            searchByGroupNumber(request, form);
        }
        return "showGroups";
    }

    @GetMapping("/copyAllGroup")
    public String loadCopyAllGroup(Map<String, Object> model) throws BPMException {
        CopyToYearForm copyToYearForm = new CopyToYearForm();
        Integer groupId = (Integer)model.get("groupID");
        String qualificationStartDate = (String)model.get("groupStartDate");
        String groupNo = null;
        String groupName = null;

        ArrayList<EmployerGroup> employerSubGroups = (ArrayList<EmployerGroup>) businessProgramService.getParticipatingSubGroups(groupId);
        if(!CollectionUtils.isEmpty(employerSubGroups)) {
            EmployerGroup lEmployerGroup = (EmployerGroup)employerSubGroups.get(0);
            groupNo = lEmployerGroup.getGroupNumber();
            groupName = lEmployerGroup.getGroupName();
        }

        ArrayList<ProgramType> programTypes = (ArrayList<ProgramType>) businessProgramService.getProgramTypes();

        if(getUserSession().getEmployerSubGroups() != null) {
            getUserSession().getEmployerSubGroups().clear();
        }
        if(getUserSession().getProgramTypes() != null) {
            getUserSession().getProgramTypes().clear();
        }
        getUserSession().setEmployerSubGroups(employerSubGroups);
        getUserSession().setProgramTypes(programTypes);

        copyToYearForm.setGroupID(groupId);
        copyToYearForm.setGroupNo(groupNo);
        copyToYearForm.setGroupName(groupName);
        copyToYearForm.setQualificationStartDate(qualificationStartDate);
        copyToYearForm.setEmployerSubGroups(employerSubGroups);
        copyToYearForm.setProgramTypes(programTypes);
        model.put("copyToYearForm", copyToYearForm);
        return "copyToYear";
    }

    @PostMapping(value="/copyToYear")
    public String submitCopyToYear(@ModelAttribute("copyToYearForm") CopyToYearForm form, BindingResult result, RedirectAttributes ra, ModelMap modelMap, HttpServletRequest request) throws Exception {
        form.setProgramTypes(getUserSession().getProgramTypes());
        validate(form, result);
        form.setEmployerSubGroups(getUserSession().getEmployerSubGroups());
        form.setProgramTypes(getUserSession().getProgramTypes());
        if (result.hasErrors()) {
            return "copyAllGroup";
        }

        if(form.getSelectedSubgroups() != null) {
            ArrayList<BusinessProgram> lBusinessPrograms = copyProgramsToNewYear(form);

            if(getUserSession().getBusinessPrograms() != null) {
                getUserSession().getBusinessPrograms().clear();
            }

            getUserSession().setBusinessPrograms((ArrayList<BusinessProgram>)
                    businessProgramService.getActiveBusinessPrograms(form.getGroupNo(), null, null));

            request.setAttribute("businessPrograms", lBusinessPrograms);
            modelMap.put("businessPrograms", lBusinessPrograms);

            // Set the new list parameter to true. So the pagination starts from the first page.
            setBusinessProgramPagination(request, getUserSession(), form.getActionType(), true);

            createActionMessagesForRedirect(ra, "messages.copyToYearSuccess", null);
        }

        ra.addFlashAttribute("groupNumber", form.getGroupNo());
        return "redirect:programSearch";
    }

    @PostMapping(value="/copyToYear", params="cancelCopyToYear")
    public RedirectView submitCopyToYearCancel(@ModelAttribute("copyToYearForm") CopyToYearForm form, RedirectAttributesModelMap attributes) throws Exception {
        attributes.addFlashAttribute("groupNumber", form.getGroupNo());
        return new RedirectView("programSearch");
    }

    private void searchByGroupNumber(HttpServletRequest request, ShowGroupsForm pGroupLookupForm) throws Exception {
        ArrayList<EmployerGroup> lEmployerGroups = null;
        if (getUserSession().getAvailableSites() != null) {
            getUserSession().getAvailableSites();
        }

        lEmployerGroups = (ArrayList<EmployerGroup>) businessProgramService.getGroups(pGroupLookupForm.getGroupNumber());
        getUserSession().setAvailableSites(lEmployerGroups);

        request.setAttribute("employerGroups", lEmployerGroups);
        request.setAttribute("startDates", getUserSession().getStartDates());

        if (lEmployerGroups.size() <= 0) {
            String message = getMessage("messages.info", new Object[]{"No results found for the given search attribute(s)"});
            List<String> messages = new ArrayList<>();
            messages.add(message);
            request.setAttribute("messages", messages);
        }

        getUserSession().setAvailableSites(lEmployerGroups);
        if (getUserSession().getEmployerGroups() != null && getUserSession().getEmployerGroups().size() > 0) {
            request.setAttribute("groupNameExists", BPMAdminConstants.BPM_ADMIN_TRUE);
        }
        getUserSession().setGroupName(pGroupLookupForm.getGroupName());

        return;
    }

    @Override
    public boolean supports(Class<?> clazz) {
        return ShowGroupsForm.class.isAssignableFrom(clazz);
    }

    @Override
    public void validate(Object target, Errors errors) {
        if ("showGroups".equals(getActionType(target))) {
            ShowGroupsForm form = (ShowGroupsForm) target;
            getValidationSupport().validateRequiredFieldIsNotEmpty("groupNumber", form.getGroupNumber(), errors, new Object[]{"Group Number"});
        } else {
            CopyToYearForm form = (CopyToYearForm) target;
            validateCopyToYearForm(form, errors, getUserSession());
            if (!errors.hasErrors()) {
                try {
                    checkForExistingPrograms(form, errors);
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        }

    }

    private void validateCopyToYearForm(CopyToYearForm form, Errors errors, UserSession sessionBean) {
        boolean lSelected = false;
        if (form.getGroupStartDates() != null) {
            ArrayList<EmployerGroup> lEmployerSubGroups = (ArrayList<EmployerGroup>) sessionBean.getEmployerSubGroups();
            for (int i = 0; i < form.getGroupStartDates().length; i++) {
                EmployerGroup lEmployerSubGroup = (EmployerGroup) lEmployerSubGroups.get(i);
                lSelected = false;
                if (form.getSelectedSubgroups() != null) {
                    for (int m = 0; m < form.getSelectedSubgroups().length; m++) {
                        String subgroupString = lEmployerSubGroup.getSiteNumber() + "-" + lEmployerSubGroup.getSiteName() + "-" + lEmployerSubGroup.getBusinessProgramName();
                        if (form.getSelectedSubgroups()[m].equals(subgroupString)) {
                            lSelected = true;
                            break;
                        }
                    }
                }

                if (lSelected == true) {
                    String val = form.getGroupStartDates()[i];
                    getValidationSupport().validateDateFormat("groupStartDates"+i, form.getGroupStartDates()[i], errors, new Object[]{"Group Start Date for Site " + lEmployerSubGroup.getSiteNumber() + " "});
                }
            }
        }
        if ("0".equals(form.getBusinessProgramTypeName())) {
            String errorMessage = getMessageSource().getMessage("errors.required", new Object[]{"Program Type"}, Locale.getDefault());
            errors.rejectValue("businessProgramTypeName", REQUIRED, errorMessage);
        }

    }

    private void checkForExistingPrograms(CopyToYearForm pCopyToYearForm, Errors errors) throws Exception {
        boolean lSelected = false;
        String lGroupNo = pCopyToYearForm.getGroupNo();
        ArrayList<EmployerGroup> lEmployerSubGroups = getUserSession().getEmployerSubGroups();

        for (int k = 0; k < lEmployerSubGroups.size(); k++) {
            lSelected = false;
            EmployerGroup lEmployerGroup = lEmployerSubGroups.get(k);

            if (pCopyToYearForm.getSelectedSubgroups() != null) {
                for (int m = 0; m < pCopyToYearForm.getSelectedSubgroups().length; m++) {
                    if (pCopyToYearForm.getSelectedSubgroups()[m].equals(lEmployerGroup.getSiteNumber())) {
                        lSelected = true;
                        break;
                    }
                }
            }

            if (lSelected == true) {
                java.util.Date lNewGroupStartDate = BPMAdminUtils.convertStringToDate(pCopyToYearForm.getGroupStartDates()[k]);
                ArrayList<BusinessProgram> lBusinessPrograms = (ArrayList<BusinessProgram>) businessProgramService.getActiveBusinessPrograms(lGroupNo, new java.sql.Date(lNewGroupStartDate.getTime()));
                if (lBusinessPrograms.size() > 0) {
                    String errorMessage = getMessageSource().getMessage("errors.duplicateBiz", new Object[]{lEmployerGroup.getGroupNumber(), lEmployerGroup.getSiteNumber(), pCopyToYearForm.getGroupStartDates()[k]}, Locale.getDefault());
                    errors.rejectValue("employerSubGroup", REQUIRED, errorMessage);
                }
            }
        }
    }

    private ArrayList<BusinessProgram> copyProgramsToNewYear(CopyToYearForm pCopyToYearForm) throws Exception {
        boolean lSelected = false;
        ArrayList<BusinessProgram> lNewBusinessPrograms = new ArrayList<BusinessProgram>();
        String lGroupNo = pCopyToYearForm.getGroupNo();
        String lUserID = getUserSessionSupport().getAuthenticatedUsername();

        ArrayList<EmployerGroup> lEmployerSubGroups = getUserSession().getEmployerSubGroups();

        for (int w = 0; w < lEmployerSubGroups.size(); w++) {
            lSelected = false;
            EmployerGroup lEmployerGroup = (EmployerGroup) lEmployerSubGroups.get(w);

            for (int m = 0; m < pCopyToYearForm.getSelectedSubgroups().length; m++) {
                String subgroupString = lEmployerGroup.getSiteNumber() + "-" + lEmployerGroup.getSiteName() + "-" + lEmployerGroup.getBusinessProgramName();
                if (pCopyToYearForm.getSelectedSubgroups()[m].equals(subgroupString)) {
                    lSelected = true;
                    break;
                }
            }

            if (lSelected == true) {
                ArrayList<BusinessProgram> lBusinessPrograms = (ArrayList<BusinessProgram>)
                        businessProgramService.getActiveBusinessPrograms(lGroupNo, lEmployerGroup.getSiteNumber(), lEmployerGroup.getQualificationStartDate());

                java.util.Date lNewGroupStartDate = BPMAdminUtils.convertStringToDate(pCopyToYearForm.getGroupStartDates()[w]);
                Calendar lGroupNewStartDateCalendar = Calendar.getInstance();
                lGroupNewStartDateCalendar.setTime(lNewGroupStartDate);

                for (int i = 0; i < lBusinessPrograms.size(); i++) {
                    BusinessProgram lBusinessProgram = (BusinessProgram) lBusinessPrograms.get(i);
                    if (lBusinessProgram.getProgramName().equalsIgnoreCase(lEmployerGroup.getBusinessProgramName())) {
                        Integer lExistingProgramID = lBusinessProgram.getProgramID();

                        String lProgramTypeIDName = pCopyToYearForm.getBusinessProgramTypeName();
                        StringTokenizer lProgramStringTokenizer = new StringTokenizer(lProgramTypeIDName, "-");
                        lBusinessProgram.setProgramTypeCodeID(lProgramStringTokenizer.nextToken());
                        lBusinessProgram.setProgramName(lProgramStringTokenizer.nextToken());

                        // Store the existing program ID and set the program ID to 0. So that the service
                        // will insert a new program.
                        // Also set the MembershipProcess Date and Flag to null. That date will be communicated
                        // from membership later in the year, every year.
                        lBusinessProgram.setProgramID(0);
                        lBusinessProgram.setMembershipProcessDate(null);
                        lBusinessProgram.setMembershipProcessFlag("N");

                        lBusinessProgram.setEffectiveDate(BPMAdminUtils.generateDefaultProgramEffectiveDate(lGroupNewStartDateCalendar, lBusinessProgram));
                        lBusinessProgram.setQualificationWindowStartDate(BPMAdminUtils.generateDefaultProgramEffectiveDate(lGroupNewStartDateCalendar, lBusinessProgram));
                        lBusinessProgram.setReleaseDate(BPMAdminUtils.generateDefaultProgramEffectiveDate(lGroupNewStartDateCalendar, lBusinessProgram));

                        lBusinessProgram.getEmployerGroup().setNewHireDate(BPMAdminUtils.generateDefaultEndDate());
                        lBusinessProgram.setEndDate(BPMAdminUtils.generateDefaultProgramEndDate(lGroupNewStartDateCalendar));
                        //BPM-1517
                        Calendar qualificationEndDateCal= Calendar.getInstance();
                        qualificationEndDateCal.setTime(lBusinessProgram.getQualificationWindowEndDate());
                        //set to current year.
                        qualificationEndDateCal.add(Calendar.YEAR, 1);
                        java.sql.Date qualificationEndDate = new java.sql.Date(qualificationEndDateCal.getTimeInMillis());
                        lBusinessProgram.setQualificationWindowEndDate(qualificationEndDate);

                        Calendar lTempStatusCalcEndDate = Calendar.getInstance();
                        lTempStatusCalcEndDate.setTime(lBusinessProgram.getEndDate());
                        lBusinessProgram.setStatusCalcEndDate(BPMAdminUtils.generateDefaultStatusCalcEndDate(lTempStatusCalcEndDate, lBusinessProgram));

                        lBusinessProgram.setContributionStartDate(lBusinessProgram.getEffectiveDate());
                        lBusinessProgram.setContributionEndDate(lBusinessProgram.getEndDate());
                        lBusinessProgram.setReportIndicatorCodeID(lBusinessProgram.getReportIndicatorCodeID());
                        lBusinessProgram.setFamilyParticipationRequirement(lBusinessProgram.getFamilyParticipationRequirement());

                        // Setting the programID to 0, causes a new program to be inserted. The programID is now
                        // the new program ID.
                        businessProgramService.updateBusinessProgram(lBusinessProgram, lUserID);
                        Integer lNewYearProgramID = lBusinessProgram.getProgramID();

                        lNewBusinessPrograms.add(lBusinessProgram);

                        ArrayList<EligibleActivity> lEligibleActivities = (ArrayList<EligibleActivity>)
                                businessProgramService.getEligibleActivities(lExistingProgramID);

                        for (int j = 0; j < lEligibleActivities.size(); j++) {
                            EligibleActivity lEligibleActivity = (EligibleActivity) lEligibleActivities.get(j);
                            // Set the programID, and the next year's start and end dates.
                            lEligibleActivity.setProgramID(lNewYearProgramID);
                            lEligibleActivity.setQualificationWindowEarlyStartDate(lBusinessProgram.getEffectiveDate());
                            lEligibleActivity.setQualificationWindowStartDate(lBusinessProgram.getEffectiveDate());
                            lEligibleActivity.setQualificationWindowEndDate(lBusinessProgram.getQualificationWindowEndDate());
                            lEligibleActivity.setQualificationWindowLateEndDate(lBusinessProgram.getEndDate());
                            //BPM-1517
                            java.util.Date enrollmentDeadlineDate = lEligibleActivity.getEnrollmentDeadlineDate();
                            Calendar enrollmentDeadlineDateCal = Calendar.getInstance();
                            enrollmentDeadlineDateCal.setTime(enrollmentDeadlineDate);
                            //set to current year
                            enrollmentDeadlineDateCal.add(Calendar.YEAR, 1);
                            java.sql.Date enrollDeadlineDate = new java.sql.Date(enrollmentDeadlineDateCal.getTimeInMillis());
                            lEligibleActivity.setEnrollmentDeadlineDate(enrollDeadlineDate);
                        }
                        businessProgramService.insertEligibleActivities(lEligibleActivities, lUserID);

                        ArrayList<ProgramIncentiveOption> lProgramIncentiveOptions = (ArrayList<ProgramIncentiveOption>)
                                businessProgramService.getProgramIncentiveOptions(lExistingProgramID);


                        ArrayList<ProgramContributionGrid> lProgramIncentiveContributionGrids = new ArrayList<ProgramContributionGrid>();

                        if (lProgramIncentiveOptions.size() > 0) {
                            for (int k = 0; k < lProgramIncentiveOptions.size(); k++) {
                                // Set the attributes to the "to" program's attributes.
                                lProgramIncentiveOptions.get(k).setBusinessProgramID(lNewYearProgramID);
                                lProgramIncentiveOptions.get(k).setEffectiveDate(new java.sql.Date(lNewGroupStartDate.getTime()));
                                lProgramIncentiveOptions.get(k).setEndDate(lBusinessProgram.getEndDate());
                                lProgramIncentiveOptions.get(k).setActivationDate(lBusinessProgram.getEndDate());
                                //BPM-1517
                                Calendar programEndDateCal= Calendar.getInstance();
                                programEndDateCal.setTime(lBusinessProgram.getEndDate());
                                //set to to next day.
                                programEndDateCal.add(Calendar.DAY_OF_YEAR, 1);
                                java.sql.Date programEndDate = new java.sql.Date(programEndDateCal.getTimeInMillis());
                                lProgramIncentiveOptions.get(k).setDeliveryDate(programEndDate);
                                lProgramIncentiveOptions.get(k).setCompletionDeadlineDate(lBusinessProgram.getQualificationWindowEndDate());
                                lProgramIncentiveOptions.get(k).setNewHireDate(BPMAdminUtils.generateDefaultEndDate());

                                ArrayList<ActivityIncentiveRequirement> lRequirements = (ArrayList<ActivityIncentiveRequirement>)
                                        lProgramIncentiveOptions.get(k).getActivityIncentiveRequirements();


                                // Get the existing contribution grids if any.
                                lProgramIncentiveContributionGrids.addAll((ArrayList<ProgramContributionGrid>)
                                        businessProgramService.getProgramContributionGrids(lProgramIncentiveOptions.get(k).getProgramIncentiveOptionID()));


                                for (int ia = 0; ia < lRequirements.size(); ia++) {
                                    lRequirements.get(ia).setProgramID(lNewYearProgramID);

                                    ArrayList<ActivityIncentiveDetail> lActivityDetails = (ArrayList<ActivityIncentiveDetail>)
                                            lRequirements.get(ia).getActivityIncentiveDetails();

                                    for (int actv = 0; actv < lActivityDetails.size(); actv++) {
                                        lActivityDetails.get(actv).setProgramID(lNewYearProgramID);
                                    }
                                }

                            }
                        }

                        businessProgramService.updateProgramIncentiveOption(lProgramIncentiveOptions, lNewYearProgramID, lUserID);

                        ArrayList<ProgramIncentiveOption> lNewProgramIncentiveOptions =
                                (ArrayList<ProgramIncentiveOption>) businessProgramService.getProgramIncentiveOptions(lNewYearProgramID);

                        /*
                         * Match up the incentive option ID. The assign to the contribution grid object, the
                         * new ProgramIncentiveOptionID in order to save the contribution grid for the new
                         * program.
                         */
                        for (ProgramContributionGrid lProgramContributionGrid : lProgramIncentiveContributionGrids) {
                            for (ProgramIncentiveOption lNewProgramIncentiveOption : lNewProgramIncentiveOptions) {
                                if (lNewProgramIncentiveOption.getIncentiveOption().getIncentiveOptionID().intValue() == lProgramContributionGrid.getIncentiveOptionID().intValue()) {
                                    lProgramContributionGrid.setProgramIncentiveOptionID(lNewProgramIncentiveOption.getProgramIncentiveOptionID());
                                    // Set contribution grid ID to null to force an insert.
                                    lProgramContributionGrid.setContributionGridID(null);
                                }
                            }

                            businessProgramService.updateProgramContributionGrid(lProgramContributionGrid, lUserID);
                        }

                        ArrayList<AdditionalInformation> lProgramAdditionalInfos = (ArrayList<AdditionalInformation>)
                                businessProgramService.getAdditionalInfos(lExistingProgramID);

                        if (lProgramAdditionalInfos.size() > 0) {
                            for (int k = 0; k < lProgramAdditionalInfos.size(); k++) {
                                // Set the attributes to the "to" program's attributes.
                                lProgramAdditionalInfos.get(k).setAdditionalProgramID(lNewYearProgramID);
                            }
                        }
                        if (lProgramAdditionalInfos.size() > 0) {
                            businessProgramService.deleteInsertAdditionalInfos(lProgramAdditionalInfos, lUserID);
                        }

                        ArrayList<AuthCode> lExtendedAuthCodes = (ArrayList<AuthCode>) businessProgramService.getExtendedAuthCodes(lExistingProgramID);
                        for (int ac = 0; ac < lExtendedAuthCodes.size(); ac++) {
                            lExtendedAuthCodes.get(ac).setBusinessProgramID(lNewYearProgramID);
                            lExtendedAuthCodes.get(ac).setEffectiveDate(lBusinessProgram.getEffectiveDate());
                            lExtendedAuthCodes.get(ac).setEndDate(lBusinessProgram.getEndDate());
                            businessProgramService.updateExtendedAuthCode(lExtendedAuthCodes.get(ac), lUserID);
                        }

                        // Program Checkmarks

                        // Copy and Save Program Checkmarks from one to another.
                        ArrayList<ProgramCheckmark> lProgramCheckmarks = (ArrayList<ProgramCheckmark>)
                                businessProgramService.getProgramCheckmarks(lExistingProgramID);

                        if (lProgramCheckmarks.size() > 0) {
                            for (ProgramCheckmark lProgramCheckmark : lProgramCheckmarks) {
                                lProgramCheckmark.setBusinessProgramID(lNewYearProgramID);
                            }
                            businessProgramService.updateProgramCheckmarks(lProgramCheckmarks, lBusinessProgram.getProgramID(), lUserID);
                        }

                        // EV 34938- Run a membership update on the newly created (copied) business program.
                        businessProgramService.updateAllGroupSiteMembers(BPMAdminConstants.BPM_ADMIN_MEMBERSHIP_UPDATE_PRCS_ID, lNewYearProgramID);
                    }
                }
            } // if selected
        }

        return lNewBusinessPrograms;
    }
}
