package com.healthpartners.app.bpm.controller;

import com.healthpartners.app.bpm.common.BPMAdminConstants;
import com.healthpartners.app.bpm.common.BPMAdminUtils;
import com.healthpartners.app.bpm.dto.AuthCode;
import com.healthpartners.app.bpm.dto.EmployerGroup;
import com.healthpartners.app.bpm.dto.LookUpValueCode;
import com.healthpartners.app.bpm.exception.BPMException;
import com.healthpartners.app.bpm.form.SaveExtendedAuthCodesForm;
import com.healthpartners.app.bpm.form.SaveProgramActivitySiteForm;
import com.healthpartners.app.bpm.iface.BusinessProgramService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.view.RedirectView;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;

import static org.apache.commons.lang.exception.ExceptionUtils.getStackTrace;

@Controller
public class ProgramExtendedAuthCodesController extends BaseController implements Validator {

    private static final String ACTION_ADD = "add";
    private static final String ACTION_REMOVE = "remove";
    private static final String ACTION_SAVE = "save";
    private static final String ACTION_SAVE_TO_ALL_SITES = "saveToAllSites";
    private static final String ACTION_SAVE_TO_SELECTED = "saveToSelected";
    private static final String COMMA_DELIMITER = ",";

    private final Log logger = LogFactory.getLog(getClass());
    private SimpleDateFormat fmt = new SimpleDateFormat(BPMAdminConstants.HP_BPM_ADMIN_UI_COMMON_DATE_FORMAT);
    private final BusinessProgramService businessProgramService;


    public ProgramExtendedAuthCodesController(BusinessProgramService businessProgramService) {
        this.businessProgramService = businessProgramService;
    }

    @PostMapping(value = "/saveExtendedAuthCodes", params = "cancel")
    public RedirectView submitCancelEditProgramExtendedAuthCodes(@ModelAttribute("saveExtendedAuthCodesForm") SaveExtendedAuthCodesForm form, RedirectAttributes ra) {
        ra.addFlashAttribute("groupNumber", getUserSession().getGroupNo());
        String url = "viewProgram?programID=" + form.getProgramID();
        return new RedirectView(url);
    }

    @PostMapping(value = "/saveExtendedAuthCodes", params = "download")
    public String submitDownload(@ModelAttribute("saveExtendedAuthCodesForm") SaveExtendedAuthCodesForm form, ModelMap modelMap, HttpServletRequest request, HttpServletResponse response) throws Exception {
        handleDownload(form, modelMap, response);
        return "extendedAuthCodes";
    }

    @PostMapping(value = "/saveExtendedAuthCodes")
    public String submitActivityProgram(@ModelAttribute("saveExtendedAuthCodesForm") SaveExtendedAuthCodesForm form, ModelMap modelMap, BindingResult result, RedirectAttributes ra) {
        try {
            if (ACTION_ADD.equals(form.getActionType())) {
                addExtendedAuthCode(form, modelMap);

            } else if (ACTION_REMOVE.equals(form.getActionType())) {
                removeExtendedAuthCode(form, modelMap);

            }  else if (ACTION_SAVE.equals(form.getActionType()) || ACTION_SAVE_TO_ALL_SITES.equals(form.getActionType()) || ACTION_SAVE_TO_SELECTED.equals(form.getActionType())) {
                validate(form, result);
                ArrayList<AuthCode> authCodes = populateFromForm(form);
                if (result.hasErrors()) {
                    populateRequest(form, modelMap, authCodes);
                    return "extendedAuthCodes";
                } else {
                    checkForDuplicates(authCodes, result);
                    if (result.hasErrors()) {
                        populateRequest(form, modelMap, authCodes);
                        return "extendedAuthCodes";
                    }
                    return performSave(modelMap, ra, form, authCodes);
                }
            }

        } catch (Exception e) {
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
            createErrorMessageOnModel(modelMap, getStackTrace(e));
        }

        return "extendedAuthCodes";
    }

    private void addExtendedAuthCode(SaveExtendedAuthCodesForm form, ModelMap modelMap) {
        ArrayList<AuthCode> lAuthCodes = populateFromForm(form);

        AuthCode lAuthCode = new AuthCode();
        lAuthCode.setAuthCode("");
        lAuthCode.setAuthCodeTypeCode(BPMAdminConstants.BPM_DEFAULT_FIRST_ITEM_IN_DROPDOWN);
        lAuthCode.setAuthCodeTypeCodeID(0);
        lAuthCode.setBusinessProgramID(getUserSession().getBusinessProgram().getProgramID());
        lAuthCode.setEffectiveDate(getUserSession().getBusinessProgram().getEffectiveDate());
        lAuthCode.setEndDate(getUserSession().getBusinessProgram().getEndDate());

        lAuthCodes.add(lAuthCode);

        modelMap.put("businessProgram", getUserSession().getBusinessProgram());
        modelMap.put("extendedAuthCodes", lAuthCodes);
        modelMap.put("luvExtendedAuthCodeTypes", getUserSession().getAuthCodeTypes());

        if (getUserSession().getExtendedAuthCodes() != null) {
            getUserSession().getExtendedAuthCodes().clear();
            getUserSession().getExtendedAuthCodes().addAll(lAuthCodes);
        } else {
            getUserSession().setExtendedAuthCodes(lAuthCodes);
        }

        populateRequest(form, modelMap, lAuthCodes);
    }

    private ArrayList<AuthCode> populateFromForm(SaveExtendedAuthCodesForm form) {
        ArrayList<AuthCode> lAuthCodes = new ArrayList<>();
        String[] lAuthCodeValues = form.getExtendedAuthCodeNames();

        if (lAuthCodeValues != null && lAuthCodeValues.length > 0) {
            for (int i = 0; i < lAuthCodeValues.length; i++) {
                if (lAuthCodeValues[i] != null /*&& !lAuthCodeValues[i].isEmpty()*/) {
                    AuthCode lAuthCode = new AuthCode();

                    lAuthCode.setBusinessProgramID(getUserSession().getBusinessProgram().getProgramID());
                    lAuthCode.setAuthCode(lAuthCodeValues[i]);
                    lAuthCode.setAuthCodeTypeCodeID(Integer.parseInt(form.getExtendedAuthCodeTypeCodes()[i]));

                    ArrayList<LookUpValueCode> lAuthCodeTypes = getUserSession().getAuthCodeTypes();
                    for (int luvs = 0; luvs < lAuthCodeTypes.size(); luvs++) {
                        if (lAuthCodeTypes.get(luvs).getLuvId().intValue() == lAuthCode.getAuthCodeTypeCodeID().intValue()) {
                            lAuthCode.setAuthCodeTypeCode(lAuthCodeTypes.get(luvs).getLuvVal());
                            break;
                        }
                    }

                    lAuthCode.setEffectiveDate(BPMAdminUtils.getSqlDateFromString(form.getExtendedAuthCodeEffectiveDates()[i]));
                    lAuthCode.setEndDate(BPMAdminUtils.getSqlDateFromString(form.getExtendedAuthCodeEndDates()[i]));
                    lAuthCodes.add(lAuthCode);
                    form.getExtendedAuthCodeTypeCodes()[i] = null;
                }
            }
        }

        return lAuthCodes;
    }


    private void removeExtendedAuthCode(SaveExtendedAuthCodesForm form, ModelMap modelMap) {
        String lAuthCodeValue = form.getProgramExtendedAuthCodeAddRemove();

        ArrayList<AuthCode> lAuthCodes = getUserSession().getExtendedAuthCodes();

        // Find the Program Additional Info entry whose ID matches the one selected for removal.
        for (int i = 0; i < lAuthCodes.size(); i++) {
            AuthCode lAuthCode = lAuthCodes.get(i);
            // Once the ID is found, remove the Incentive from the Program Incentive Options
            // and add it back to the list of Available Incentives.
            if (lAuthCode.getAuthCode().equalsIgnoreCase(lAuthCodeValue)) {
                lAuthCodes.remove(i);
                break;
            }
        }

        modelMap.put("businessProgram", getUserSession().getBusinessProgram());
        modelMap.put("extendedAuthCodes", lAuthCodes);
        modelMap.put("luvExtendedAuthCodeTypes", getUserSession().getAuthCodeTypes());

        populateRequest(form, modelMap, lAuthCodes);
    }

    private void populateRequest(SaveExtendedAuthCodesForm form, ModelMap modelMap, ArrayList<AuthCode> authCodes) {
        String[] extendedAuthCodeNames = new String[authCodes.size()];
        String[] extendedAuthCodeTypeCodes = new String[authCodes.size()];
        String[] extendedAuthCodeEffectiveDates = new String[authCodes.size()];
        String[] extendedAuthCodeEndDates = new String[authCodes.size()];
        int i = 0;
        for (AuthCode authCode : getUserSession().getExtendedAuthCodes()) {
            extendedAuthCodeNames[i] = authCode.getAuthCode();
            extendedAuthCodeTypeCodes[i] = authCode.getAuthCodeTypeCode();
            extendedAuthCodeEffectiveDates[i] = fmt.format(authCode.getEffectiveDate());
            extendedAuthCodeEndDates[i] = fmt.format(authCode.getEndDate());
            i++;
        }
        form.setExtendedAuthCodeNames(extendedAuthCodeNames);
        form.setExtendedAuthCodeTypeCodes(extendedAuthCodeTypeCodes);
        form.setExtendedAuthCodeEffectiveDates(extendedAuthCodeEffectiveDates);
        form.setExtendedAuthCodeEndDates(extendedAuthCodeEndDates);
        form.setProgramExtendedAuthCodeAddRemove(null);

        modelMap.put("businessProgram", getUserSession().getBusinessProgram());
        modelMap.put("extendedAuthCodes", authCodes);
        modelMap.put("luvExtendedAuthCodeTypes", getUserSession().getAuthCodeTypes());
    }

    private void handleDownload(SaveExtendedAuthCodesForm form, ModelMap modelMap, HttpServletResponse response) throws Exception {
        ArrayList<AuthCode> lAuthCodes = populateFromForm(form);

        String lFileName = getUserSession().getBusinessProgram().getEmployerGroup().getGroupNumber()
                + "-"
                + getUserSession().getBusinessProgram().getEmployerGroup().getSiteNumber()
                + "_AuthCodes.csv";

        response.setHeader("Content-Type", "text/csv");
        response.setHeader("Content-Disposition", "attachment;filename=" + lFileName);

        createCSVFile(lAuthCodes, response.getOutputStream());

        populateRequest(form, modelMap, lAuthCodes);
    }

    private void createCSVFile(ArrayList<AuthCode> pAuthCodes, OutputStream pOutputStream) throws Exception {
        BufferedWriter lWriter = new BufferedWriter(new OutputStreamWriter(pOutputStream, "UTF-8"));

        formatAuthCodesHeader(lWriter);
        formatAuthCodes(lWriter, pAuthCodes);

        lWriter.flush();
        lWriter.close();
    }

    private void formatAuthCodesHeader(BufferedWriter pWriter) throws IOException {
        pWriter.append("Auth Code");
        pWriter.append(COMMA_DELIMITER);

        pWriter.append("Auth Or Promo");
        pWriter.append(COMMA_DELIMITER);

        pWriter.append("Effective Date");
        pWriter.append(COMMA_DELIMITER);

        pWriter.append("End Date");

        pWriter.newLine();
    }

    private void formatAuthCodes(BufferedWriter pWriter, ArrayList<AuthCode> pAuthCodes) throws Exception {
        for (AuthCode lAuthCode : pAuthCodes) {
            pWriter.append(lAuthCode.getAuthCode());
            pWriter.append(COMMA_DELIMITER);

            pWriter.append(lAuthCode.getAuthCodeTypeCode());
            pWriter.append(COMMA_DELIMITER);

            pWriter.append(BPMAdminUtils.formatDateMMddyyyy(lAuthCode.getEffectiveDate()));
            pWriter.append(COMMA_DELIMITER);

            pWriter.append(BPMAdminUtils.formatDateMMddyyyy(lAuthCode.getEndDate()));

            pWriter.newLine();
        }
    }

    private String performSave(ModelMap modelMap, RedirectAttributes ra, SaveExtendedAuthCodesForm form, ArrayList<AuthCode> authCodes) throws Exception {
        String userID = getUserSessionSupport().getAuthenticatedUsername();

        populateRequest(form, modelMap, authCodes);

        if (ACTION_SAVE.equals(form.getActionType())) {
            saveExtendedAuthCodes(authCodes, ra, userID);

        } else if (ACTION_SAVE_TO_ALL_SITES.equals(form.getActionType())) {
            saveToAllSites(authCodes, ra, userID);

        } else if (ACTION_SAVE_TO_SELECTED.equals(form.getActionType())) {
            saveToSelectedSites(authCodes, modelMap, form, ra, userID);
            return "programActivitySites";
        }

        // Redirect back to the viewProgram screen upon successful process of saves
        ra.addFlashAttribute("groupNumber", form.getGroupNumber());
        String url = "viewProgram?programID=" + form.getProgramID();
        return "redirect:" + url;
    }

    private void saveExtendedAuthCodes(ArrayList<AuthCode> pAuthCodes, RedirectAttributes ra, String pUserID) throws Exception {
        // Delete the existing extended auth codes for this business program.
        businessProgramService.deleteExtendedAuthCodes(getUserSession().getBusinessProgram().getProgramID());

        // Update will check for existence. If the record does not exists, it will insert.
        for (int j = 0; j < pAuthCodes.size(); j++) {
            businessProgramService.updateExtendedAuthCode(pAuthCodes.get(j), pUserID);
        }

        ArrayList<AuthCode> lExtendedAuthCodes = (ArrayList<AuthCode>) businessProgramService.getExtendedAuthCodes(getUserSession().getBusinessProgram().getProgramID());

        getUserSession().setExtendedAuthCodes(lExtendedAuthCodes);

        ra.addFlashAttribute("businessProgram", getUserSession().getBusinessProgram());
        ra.addFlashAttribute("extendedAuthCodes", getUserSession().getExtendedAuthCodes());
    }

    private void saveToAllSites(ArrayList<AuthCode> pAuthCodes, RedirectAttributes ra, String pUserID) throws Exception {
        // Save the auth codes submitted on the form.
        saveExtendedAuthCodes(pAuthCodes, ra, pUserID);

        // Now save to all the sites in this group.
        businessProgramService.saveExtendedAuthCodesToAllSites(getUserSession().getBusinessProgram(), getUserSession().getExtendedAuthCodes(), pUserID);
    }

    private void saveToSelectedSites(ArrayList<AuthCode> pAuthCodes, ModelMap modelMap, SaveExtendedAuthCodesForm form, RedirectAttributes ra, String pUserID) throws BPMException {
        if (getUserSession().getAvailableSites() != null) {
            getUserSession().getAvailableSites().clear();
        }

        if (getUserSession().getEmployerSubGroups() != null) {
            getUserSession().getEmployerSubGroups().clear();
        }

        getUserSession().setExtendedAuthCodes(pAuthCodes);

        Collection<EmployerGroup> lSubGroups = businessProgramService.getBusinessProgramInSameYear(getUserSession().getBusinessProgram().getProgramID());

        SaveProgramActivitySiteForm saveProgramActivitySiteForm = new SaveProgramActivitySiteForm();
        saveProgramActivitySiteForm.setSubGroupID(((ArrayList<EmployerGroup>) lSubGroups).get(0).getSubgroupID());
        modelMap.put("saveProgramActivitySiteForm", saveProgramActivitySiteForm);
        modelMap.put("selectedSubGroups", lSubGroups);

        getUserSession().setEmployerSubGroups((ArrayList<EmployerGroup>) lSubGroups);
        getUserSession().setWhichSaveSelectedSite(WHICH_SAVE_SELECTED_SITES_EXTENDED_AUTH_CODES);
    }

    @Override
    public boolean supports(Class<?> clazz) {
        return SaveExtendedAuthCodesForm.class.isAssignableFrom(clazz);
    }

    @Override
    public void validate(Object target, Errors errors) {
        SaveExtendedAuthCodesForm form = (SaveExtendedAuthCodesForm) target;

        if (form.getExtendedAuthCodeNames() != null && form.getExtendedAuthCodeNames().length > 0) {
            for (int i = 0; i < form.getExtendedAuthCodeNames().length; i++) {
                getValidationSupport().validateRequiredFieldIsNotEmpty("extendedAuthCodeNames["+i+"]", form.getExtendedAuthCodeNames()[i], errors, new Object[]{"Extended Auth Code"});
                getValidationSupport().validateRequiredFieldIsNotEmpty("extendedAuthCodeTypeCodes["+i+"]", form.getExtendedAuthCodeTypeCodes()[i], errors, new Object[]{"Auth or Promo Code Type"});
                getValidationSupport().validateDateFormat("extendedAuthCodeEffectiveDates["+i+"]", form.getExtendedAuthCodeEffectiveDates()[i], errors, new Object[]{"Effective Date"});
                getValidationSupport().validateDateFormat("extendedAuthCodeEndDates["+i+"]", form.getExtendedAuthCodeEndDates()[i], errors, new Object[]{"End Date"});

                if (form.getExtendedAuthCodeTypeCodes()[i].equals("0")) {
                    getValidationSupport().validateNotSelected("extendedAuthCodeTypeCodes["+i+"]", form.getExtendedAuthCodeTypeCodes()[i], errors, new Object[]{"Auth or Promo Code Type"});
                }
            }
        }
    }

    private void checkForDuplicates(ArrayList<AuthCode> pAuthCodes, Errors errors) {
        for (int i = 0; i < (pAuthCodes.size() - 1); i++) {
            for (int j = i; j < pAuthCodes.size(); j++) {
                if (i != j && pAuthCodes.get(i).getAuthCode().equalsIgnoreCase(pAuthCodes.get(j).getAuthCode())) {
                    getValidationSupport().addValidationFailureMessage("extendedAuthCodeNames["+i+"]", errors, "errors.duplicatename", new Object[]{"Auth Code " + pAuthCodes.get(i).getAuthCode()});
                }
            }
        }
    }

}
