package com.healthpartners.app.bpm.controller;

import com.healthpartners.app.bpm.common.BPMAdminConstants;
import com.healthpartners.app.bpm.dto.AdditionalInformation;
import com.healthpartners.app.bpm.dto.EmployerGroup;
import com.healthpartners.app.bpm.exception.BPMException;
import com.healthpartners.app.bpm.form.SaveProgramActivitySiteForm;
import com.healthpartners.app.bpm.form.SaveProgramAdditionalInfoForm;
import com.healthpartners.app.bpm.iface.BusinessProgramService;
import com.healthpartners.app.bpm.iface.MemberService;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.view.RedirectView;

import java.util.ArrayList;
import java.util.Collection;

import static org.apache.commons.lang.exception.ExceptionUtils.getStackTrace;

@Controller
public class ProgramAdditionalInfoController extends BaseController implements Validator {

    private static final String ACTION_SAVE = "save";
    private static final String ACTION_SAVE_TO_ALL_SITES = "saveToAllSites";
    private static final String ACTION_SAVE_TO_SELECTED = "saveToSelected";
    public static final String ACTION_ADD_FREE_FORM = "addFreeForm";
    public static final String ACTION_ADD_FIXED_FORM = "addFixedForm";
    private static final String ACTION_REMOVE = "remove";
    protected final Log logger = LogFactory.getLog(getClass());
    private final BusinessProgramService businessProgramService;
    private final MemberService memberService;

    public ProgramAdditionalInfoController(BusinessProgramService businessProgramService, MemberService memberService) {
        this.businessProgramService = businessProgramService;
        this.memberService = memberService;
    }

    @PostMapping(value = "/saveProgramAdditionalInfo", params = "cancel")
    public RedirectView submitCancelEditProgramAdditionalInfo(@ModelAttribute("saveProgramAdditionalInfoForm") SaveProgramAdditionalInfoForm form, RedirectAttributes ra) {
        ra.addFlashAttribute("groupNumber", form.getGroupNumber());
        String url = "viewProgram?programID=" + form.getProgramID();
        return new RedirectView(url);
    }

    @PostMapping(value = "/saveProgramAdditionalInfo")
    public String submitActivityProgram(@ModelAttribute("saveProgramAdditionalInfoForm") SaveProgramAdditionalInfoForm form, ModelMap modelMap, BindingResult result, RedirectAttributes ra) {
        try {
            if (ACTION_REMOVE.equals(form.getActionType())) {
                removeProgramAdditionalInfo(form, modelMap);
                if (BPMAdminConstants.BPM_BIZ_PROGRAM_STATUS_TEMPLATE.equalsIgnoreCase(getUserSession().getBusinessProgram().getProgramStatusCodeValue())) {
                    // TODO - return to template
                    return "programAdditionalInfos";
                }

            } else if ((ACTION_ADD_FREE_FORM.equals(form.getActionType()) || ACTION_ADD_FIXED_FORM.equals(form.getActionType()))) {
                addProgramAdditionalInfo(form, modelMap);
                if (BPMAdminConstants.BPM_BIZ_PROGRAM_STATUS_TEMPLATE.equalsIgnoreCase(getUserSession().getBusinessProgram().getProgramStatusCodeValue())) {
                    // TODO - return to template
                    return "programAdditionalInfos";
                }

            } else if (ACTION_SAVE.equals(form.getActionType()) || ACTION_SAVE_TO_ALL_SITES.equals(form.getActionType()) || ACTION_SAVE_TO_SELECTED.equals(form.getActionType())) {
                validate(form, result);
                if (result.hasErrors()) {
                    populateRequest(modelMap);
                    populateFromForm(form, modelMap);
                    return "programAdditionalInfos";
                } else {
                    return performSave(modelMap, ra, form);
                }
            }
        } catch (Exception e) {
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
            createErrorMessageOnModel(modelMap, getStackTrace(e));
        }

        // Add package also forwards to the same jsp.
        return "programAdditionalInfos";
    }

    private String performSave(ModelMap modelMap, RedirectAttributes ra, SaveProgramAdditionalInfoForm form) throws Exception {
        String pUserID = getUserSessionSupport().getAuthenticatedUsername();

        populateRequest(modelMap);

        if (ACTION_SAVE.equals(form.getActionType())) {
            saveProgramAdditionalInfos(ra, form, pUserID);

        } else if (ACTION_SAVE_TO_ALL_SITES.equals(form.getActionType())) {
            saveToAllSites(form, pUserID);

        } else if (ACTION_SAVE_TO_SELECTED.equals(form.getActionType())) {
            saveToSelectedSites(form, modelMap);
            return "programActivitySites";
        }

        // Redirect back to the viewProgram screen upon successful process of saves
        ra.addFlashAttribute("groupNumber", form.getGroupNumber());
        String url = "viewProgram?programID=" + form.getProgramID();
        return "redirect:" + url;
    }

    private void saveProgramAdditionalInfos(RedirectAttributes ra, SaveProgramAdditionalInfoForm form, String pUserID) throws Exception {
        Integer[] lAdditionalInfoIDs = form.getAdditionalInfoIDs();

        if (lAdditionalInfoIDs != null && lAdditionalInfoIDs.length > 0) {
            ArrayList<AdditionalInformation> lAdditionalInfos = new ArrayList<>();
            for (int i = 0; i < lAdditionalInfoIDs.length; i++) {
                AdditionalInformation lAdditionalInformation = new AdditionalInformation();
                lAdditionalInformation.setAdditionalProgramID(getUserSession().getBusinessProgram().getProgramID());
                lAdditionalInformation.setAdditionalInfoID(lAdditionalInfoIDs[i]);
                lAdditionalInformation.setAdditionalInfoName(form.getAdditionalInfoNames()[i]);
                lAdditionalInformation.setAdditionalInfoText(form.getAdditionalInfoTexts()[i]);
                lAdditionalInformation.setSortOrder(form.getSortOrders()[i]);
                lAdditionalInformation.setAdditionalInfoTypeCode(form.getAdditionalInfoTypeCodes()[i]);
                lAdditionalInfos.add(lAdditionalInformation);
            }
            if (lAdditionalInfos.size() >= 0) {
                // The DAO will delete existing ones and insert with new and existing(update).
                businessProgramService.deleteInsertAdditionalInfos(lAdditionalInfos, pUserID);
            }
        } else {
            //No additional information passed to the form means delete remaining additional info records
            ArrayList<AdditionalInformation> lAdditionalInfos = new ArrayList<>();
            AdditionalInformation lAdditionalInformation = new AdditionalInformation();
            lAdditionalInformation.setAdditionalProgramID(getUserSession().getBusinessProgram().getProgramID());
            lAdditionalInfos.add(lAdditionalInformation);
            businessProgramService.deleteInsertAdditionalInfos(lAdditionalInfos, pUserID);
        }

        ArrayList<AdditionalInformation> lAdditionalInfos = (ArrayList<AdditionalInformation>) businessProgramService.getAdditionalInfos(getUserSession().getBusinessProgram().getProgramID());
        getUserSession().setAdditionalInfos(lAdditionalInfos);
        ra.addFlashAttribute("businessProgram", getUserSession().getBusinessProgram());
        ra.addFlashAttribute("additionalInfos", getUserSession().getAdditionalInfos());
    }

    private void saveToAllSites(SaveProgramAdditionalInfoForm form, String pUserID) throws Exception {
        ArrayList<AdditionalInformation> lAdditionalInfos = new ArrayList<>();

        Integer[] lAdditionalInfoIDs = form.getAdditionalInfoIDs();
        if (lAdditionalInfoIDs != null && lAdditionalInfoIDs.length > 0) {
            for (int i = 0; i < lAdditionalInfoIDs.length; i++) {
                AdditionalInformation lAdditionalInformation = new AdditionalInformation();
                lAdditionalInformation.setAdditionalProgramID(getUserSession().getBusinessProgram().getProgramID());
                lAdditionalInformation.setAdditionalInfoID(lAdditionalInfoIDs[i]);
                lAdditionalInformation.setAdditionalInfoName(form.getAdditionalInfoNames()[i]);
                lAdditionalInformation.setAdditionalInfoText(form.getAdditionalInfoTexts()[i]);
                lAdditionalInformation.setSortOrder(form.getSortOrders()[i]);
                lAdditionalInformation.setAdditionalInfoTypeCode(form.getAdditionalInfoTypeCodes()[i]);
                lAdditionalInfos.add(lAdditionalInformation);
            }
            businessProgramService.saveAdditionalInfoToAllSites(getUserSession().getBusinessProgram(), lAdditionalInfos, pUserID);
        } else {
            //No additional information passed to the form means delete remaining additional info records
            businessProgramService.deleteAdditionalInfosForGroup(getUserSession().getBusinessProgram());
        }
    }

    private void saveToSelectedSites(SaveProgramAdditionalInfoForm form, ModelMap modelMap) throws BPMException {
        if (getUserSession().getAvailableSites() != null) {
            getUserSession().getAvailableSites().clear();
        }

        if (getUserSession().getEmployerSubGroups() != null) {
            getUserSession().getEmployerSubGroups().clear();
        }

        ArrayList<AdditionalInformation> lAdditionalInfos = populateFromForm(form, modelMap);
        getUserSession().setAdditionalInfos(lAdditionalInfos);

        Collection<EmployerGroup> lSubGroups = businessProgramService.getBusinessProgramInSameYear(getUserSession().getBusinessProgram().getProgramID());

        SaveProgramActivitySiteForm saveProgramActivitySiteForm = new SaveProgramActivitySiteForm();
        saveProgramActivitySiteForm.setSubGroupID(((ArrayList<EmployerGroup>) lSubGroups).get(0).getSubgroupID());
        modelMap.put("saveProgramActivitySiteForm", saveProgramActivitySiteForm);
        modelMap.put("businessProgram", getUserSession().getBusinessProgram());
        modelMap.put("selectedSubGroups", lSubGroups);

        getUserSession().setEmployerSubGroups((ArrayList<EmployerGroup>) lSubGroups);
        getUserSession().setWhichSaveSelectedSite(WHICH_SAVE_SELECTED_SITES_ADD_INFOS);
    }

    protected void populateRequest(ModelMap modelMap) {
        modelMap.put("businessProgram", getUserSession().getBusinessProgram());
        if (getUserSession().getTemplateBizProgram() != null) {
            modelMap.put("templateBizProgram", getUserSession().getTemplateBizProgram());
        }
        modelMap.put("additionaInfoFixedNames", getUserSession().getAdditionalInfoFixedNames());
        modelMap.put("additionalInfos", getUserSession().getAdditionalInfos());
    }

    private void removeProgramAdditionalInfo(SaveProgramAdditionalInfoForm form, ModelMap modelMap) {
        Integer ladditionalInfoID = form.getProgramAdditionalInfoAddRemove();

        ArrayList<AdditionalInformation> lAdditionalInfos = getUserSession().getAdditionalInfos();
        // Find the Program Additional Info entry whose ID matches the one selected for removal.
        for (int i = 0; i < lAdditionalInfos.size(); i++) {
            AdditionalInformation lAdditionalInformation = lAdditionalInfos.get(i);
            // Once the ID is found, remove the Incentive from the Program Incentive Options
            // and add it back to the list of Available Incentives.
            if (lAdditionalInformation.getAdditionalInfoID().intValue() == ladditionalInfoID.intValue()) {
                lAdditionalInfos.remove(i);
                if (form.getAdditionalInfoIDs() != null && form.getAdditionalInfoIDs().length >= i) {
                    var arr = (Integer[]) ArrayUtils.remove(form.getAdditionalInfoIDs(), i);
                    form.setAdditionalInfoIDs(arr);
                }

                if (form.getAdditionalInfoNames() != null && form.getAdditionalInfoNames().length >= i) {
                    var arr = (String[]) ArrayUtils.remove(form.getAdditionalInfoNames(), i);
                    form.setAdditionalInfoNames(arr);
                }

                if (form.getAdditionalInfoTexts() != null && form.getAdditionalInfoTexts().length >= i) {
                    var arr = (String[]) ArrayUtils.remove(form.getAdditionalInfoTexts(), i);
                    form.setAdditionalInfoTexts(arr);
                }

                if (form.getAdditionalInfoTypeCodeIDs() != null && form.getAdditionalInfoTypeCodeIDs().length >= i) {
                    var arr = (Integer[]) ArrayUtils.remove(form.getAdditionalInfoTypeCodeIDs(), i);
                    form.setAdditionalInfoTypeCodeIDs(arr);
                }

                if (form.getAdditionalInfoTypeCodes() != null && form.getAdditionalInfoTypeCodes().length >= i) {
                    var arr = (String[]) ArrayUtils.remove(form.getAdditionalInfoTypeCodes(), i);
                    form.setAdditionalInfoTypeCodes(arr);
                }

                if (form.getSortOrders() != null && form.getSortOrders().length >= i) {
                    var arr = (Integer[]) ArrayUtils.remove(form.getSortOrders(), i);
                    form.setSortOrders(arr);
                }
                break;
            }
        }

        getUserSession().setAdditionalInfos(lAdditionalInfos);

        if (getUserSession().getTemplateBizProgram() != null) {
            modelMap.put("templateBizProgram", getUserSession().getTemplateBizProgram());
        }

        modelMap.put("additionaInfoFixedNames", getUserSession().getAdditionalInfoFixedNames());
        modelMap.put("businessProgram", getUserSession().getBusinessProgram());
        modelMap.put("additionalInfos", lAdditionalInfos);
    }

    private void addProgramAdditionalInfo(SaveProgramAdditionalInfoForm saveProgramAdditionalInfoForm, ModelMap modelMap) {
        String actionType = saveProgramAdditionalInfoForm.getActionType();

        ArrayList<AdditionalInformation> additionalInfos = getUserSession().getAdditionalInfos();

        additionalInfos = populateFromForm(additionalInfos, saveProgramAdditionalInfoForm);

        AdditionalInformation additionalInformation = new AdditionalInformation();

        additionalInformation.setAdditionalInfoID(Integer.valueOf("0"));
        additionalInformation.setAdditionalInfoName("");
        additionalInformation.setAdditionalInfoText("");
        additionalInformation.setAdditionalProgramID(getUserSession().getBusinessProgram().getProgramID());
        additionalInformation.setSortOrder(Integer.valueOf("0"));

        if (ACTION_ADD_FREE_FORM.equalsIgnoreCase(actionType)) {
            additionalInformation.setAdditionalInfoTypeCode(BPMAdminConstants.BPM_ADMIN_ADDL_INFO_FREE_FORM);
        } else if (ACTION_ADD_FIXED_FORM.equalsIgnoreCase(actionType)) {
            additionalInformation.setAdditionalInfoTypeCode(BPMAdminConstants.BPM_ADMIN_ADDL_INFO_FIXED);
        }

        additionalInfos.add(additionalInformation);

        modelMap.put("additionaInfoFixedNames", getUserSession().getAdditionalInfoFixedNames());
        modelMap.put("businessProgram", getUserSession().getBusinessProgram());
        modelMap.put("additionalInfos", additionalInfos);

        if (getUserSession().getTemplateBizProgram() != null) {
            modelMap.put("templateBizProgram", getUserSession().getTemplateBizProgram());
        }

        getUserSession().setAdditionalInfos(additionalInfos);
        populateSaveProgramAdditionalInfoFormArrays(saveProgramAdditionalInfoForm, additionalInfos);
    }

    private void populateSaveProgramAdditionalInfoFormArrays(SaveProgramAdditionalInfoForm saveProgramAdditionalInfoForm, ArrayList<AdditionalInformation> additionalInfos) {
        Integer[] additionalInfoIDs = new Integer[additionalInfos.size()];
        String[] additionalInfoNames = new String[additionalInfos.size()];
        String[] additionalInfoTexts = new String[additionalInfos.size()];
        Integer[] additionalInfoTypeCodeIDs = new Integer[additionalInfos.size()];
        String[] additionalInfoTypeCodes = new String[additionalInfos.size()];
        Integer[] sortOrders = new Integer[additionalInfos.size()];

        int i = 0;
        for (AdditionalInformation additionalInformation : additionalInfos) {
            additionalInfoIDs[i] = additionalInformation.getAdditionalInfoID();
            additionalInfoNames[i] = additionalInformation.getAdditionalInfoName();
            additionalInfoTexts[i] = additionalInformation.getAdditionalInfoText();
            additionalInfoTypeCodeIDs[i] = additionalInformation.getAdditionalInfoTypeID();
            additionalInfoTypeCodes[i] = additionalInformation.getAdditionalInfoTypeCode();
            sortOrders[i] = additionalInformation.getSortOrder();
            i++;
        }

        saveProgramAdditionalInfoForm.setAdditionalInfoIDs(additionalInfoIDs);
        saveProgramAdditionalInfoForm.setAdditionalInfoNames(additionalInfoNames);
        saveProgramAdditionalInfoForm.setAdditionalInfoTexts(additionalInfoTexts);
        saveProgramAdditionalInfoForm.setAdditionalInfoTypeCodeIDs(additionalInfoTypeCodeIDs);
        saveProgramAdditionalInfoForm.setAdditionalInfoTypeCodes(additionalInfoTypeCodes);
        saveProgramAdditionalInfoForm.setSortOrders(sortOrders);
    }

    /*
	 Story IFS-660
	 Method responsible for populating free form additional information entered by user back to the screen
	 when adding more than one program additional information entries.  Without this method, screen will refresh
	 and wipe out what was entered.
	 */
    private ArrayList<AdditionalInformation> populateFromForm(ArrayList<AdditionalInformation> additionalInfos, SaveProgramAdditionalInfoForm saveProgramAdditionalInfoForm) {
        String[] additionalInfoNames = saveProgramAdditionalInfoForm.getAdditionalInfoNames();
        String[] additionalInfoTexts = saveProgramAdditionalInfoForm.getAdditionalInfoTexts();

        int idx = 0;
        for (AdditionalInformation additionalInfo : additionalInfos) {
            additionalInfo.setAdditionalInfoName(additionalInfoNames[idx]);
            additionalInfo.setAdditionalInfoText(additionalInfoTexts[idx]);
            idx++;
        }

        return additionalInfos;
    }

    protected ArrayList<AdditionalInformation> populateFromForm(SaveProgramAdditionalInfoForm form, ModelMap modelMap) {
        ArrayList<AdditionalInformation> lAdditionalInfos = new ArrayList<>();
        Integer[] lAdditionalInfoIDs = form.getAdditionalInfoIDs();

        if (lAdditionalInfoIDs != null && lAdditionalInfoIDs.length > 0) {
            for (int i = 0; i < lAdditionalInfoIDs.length; i++) {
                AdditionalInformation lAdditionalInformation = new AdditionalInformation();
                lAdditionalInformation.setAdditionalProgramID(getUserSession().getBusinessProgram().getProgramID());
                lAdditionalInformation.setAdditionalInfoID(lAdditionalInfoIDs[i]);
                lAdditionalInformation.setAdditionalInfoName(form.getAdditionalInfoNames()[i]);
                lAdditionalInformation.setAdditionalInfoText(form.getAdditionalInfoTexts()[i]);
                lAdditionalInformation.setSortOrder(form.getSortOrders()[i]);
                lAdditionalInformation.setAdditionalInfoTypeCode(form.getAdditionalInfoTypeCodes()[i]);

                lAdditionalInfos.add(lAdditionalInformation);
            }
        }

        modelMap.put("additionalInfos", lAdditionalInfos);

        return lAdditionalInfos;
    }

    @Override
    public boolean supports(Class<?> clazz) {
        return SaveProgramAdditionalInfoForm.class.isAssignableFrom(clazz);
    }

    @Override
    public void validate(Object target, Errors errors) {
        SaveProgramAdditionalInfoForm form = (SaveProgramAdditionalInfoForm) target;

        if (form.getAdditionalInfoIDs() != null && form.getAdditionalInfoIDs().length > 0) {
            for (int i = 0; i < form.getAdditionalInfoIDs().length; i++) {
                getValidationSupport().validateRequiredFieldIsNotEmpty("additionalInfoNames["+i+"]", form.getAdditionalInfoNames()[i], errors, new Object[]{"Additional Info Names"});
                getValidationSupport().validateRequiredFieldIsNotEmpty("additionalInfoTexts["+i+"]", form.getAdditionalInfoTexts()[i], errors, new Object[]{"Additional Info Texts"});
                getValidationSupport().validateOnlyNumericForInteger("sortOrders["+i+"]", String.valueOf(form.getSortOrders()[i]), errors, new Object[]{"Sort Order"});
                getValidationSupport().validateNotSpecialChar("additionalInfoTexts["+i+"]",  form.getAdditionalInfoTexts()[i], errors, new Object[]{"Additional Info Texts"});
            }
        }
    }

}
