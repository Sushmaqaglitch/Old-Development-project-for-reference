package com.healthpartners.app.bpm.dto;


public class RewardEmbossedLine
{	
	
	private Integer rewardEmbossedLineID;
	private String embossName;
	private String embossedDescription;
	private Integer embossedTypeCodeID;
	private String embossedTypeCode;
	private java.sql.Date effectiveDate;
	private java.sql.Date endDate;
	
	private Integer used;
	
	public Integer getRewardEmbossedLineID() {
		return rewardEmbossedLineID;
	}
	public void setRewardEmbossedLineID(Integer rewardEmbossedLineID) {
		this.rewardEmbossedLineID = rewardEmbossedLineID;
	}
	public String getEmbossName() {
		return embossName;
	}
	public void setEmbossName(String embossName) {
		this.embossName = embossName;
	}
	public String getEmbossedDescription() {
		return embossedDescription;
	}
	public void setEmbossedDescription(String embossedDescription) {
		this.embossedDescription = embossedDescription;
	}
	public Integer getEmbossedTypeCodeID() {
		return embossedTypeCodeID;
	}
	public void setEmbossedTypeCodeID(Integer embossedTypeCodeID) {
		this.embossedTypeCodeID = embossedTypeCodeID;
	}
	
	public String getEmbossedTypeCode() {
		return embossedTypeCode;
	}
	public void setEmbossedTypeCode(String embossedTypeCode) {
		this.embossedTypeCode = embossedTypeCode;
	}
	public java.sql.Date getEffectiveDate() {
		return effectiveDate;
	}
	public void setEffectiveDate(java.sql.Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}
	public java.sql.Date getEndDate() {
		return endDate;
	}
	public void setEndDate(java.sql.Date endDate) {
		this.endDate = endDate;
	}
	public Integer getUsed() {
		return used;
	}
	public void setUsed(Integer used) {
		this.used = used;
	}
	
	
	
	
}
