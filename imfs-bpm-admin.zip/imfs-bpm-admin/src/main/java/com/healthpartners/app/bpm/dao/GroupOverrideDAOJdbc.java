package com.healthpartners.app.bpm.dao;

import com.healthpartners.app.bpm.dto.GroupOverride;
import com.healthpartners.app.bpm.exception.BPMException;
import jakarta.annotation.PostConstruct;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.jdbc.support.incrementer.DataFieldMaxValueIncrementer;
import org.springframework.jdbc.support.incrementer.OracleSequenceMaxValueIncrementer;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.sql.DataSource;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Collection;


@Repository
@Transactional(timeout = 300, rollbackFor = {DataAccessException.class, BPMException.class})

public class GroupOverrideDAOJdbc extends JdbcDaoSupport implements GroupOverrideDAO {

    private static final String selectGroupOverride = """
			Select
				grpovr.empl_grp_ovrd_id,
				grpsite.empl_grp_no,
				grpsite.empl_grp_site_id_no,
				grpsite.grp_id,
				grpsite.subgrp_id,
				grpsite.empl_grp_nm,
				grpsite.empl_grp_site_nm,
				grpovr.ovrd_rsn_desc,
				grpovr.biz_pgm_tp_cd,
				grpovr.ovrd_tp_cd_id,
				grpovr.aprvr_user_id,
				grpovr.ovrd_issue_dt,
				grpovr.eff_dt,
				grpovr.end_dt,
				(select lu_val from luv l where l.lu_id = grpovr.ovrd_tp_cd_id) luv_override_type_desc,
				(select biz_pgm_nm from business_program_type where biz_pgm_tp_cd = grpovr.biz_pgm_tp_cd) biz_pgm_desc
				FROM empl_grp_override grpovr, empl_grp_site grpsite
			where
				grpovr.grp_id = grpsite.grp_id
				and grpovr.subgrp_id = grpsite.subgrp_id
			        """;
    private static final String selectGroupOverrides = """
			SELECT
				grpovr.empl_grp_ovrd_id,
				grpsite.empl_grp_no,
				grpsite.empl_grp_site_id_no,
				grpovr.grp_id,
				grpovr.subgrp_id,
				regexp_replace(grpsite.empl_grp_nm, ',', NULL) empl_grp_nm,
				regexp_replace(grpsite.empl_grp_site_nm, ',', NULL) empl_grp_site_nm,
				grpovr.ovrd_rsn_desc,
				grpovr.biz_pgm_tp_cd,
				grpovr.ovrd_tp_cd_id,
				grpovr.aprvr_user_id,
				grpovr.ovrd_issue_dt,
				grpovr.eff_dt,
				grpovr.end_dt,
				(select lu_val from luv l where l.lu_id = grpovr.ovrd_tp_cd_id) luv_override_type_desc, 
				(select biz_pgm_desc from business_program_type where biz_pgm_tp_cd = grpovr.biz_pgm_tp_cd) biz_pgm_desc
			FROM empl_grp_override grpovr, empl_grp_site grpsite
			where grpovr.grp_id = grpsite.grp_id and grpsite.subgrp_id = grpovr.subgrp_id
			order by  grpsite.empl_grp_no asc, grpsite.empl_grp_site_id_no asc, luv_override_type_desc asc, grpovr.ovrd_issue_dt desc
			         """;
    private static final String selectAssignedSitesForGroupSiteException = """
			select egs.empl_grp_no,
				egs.empl_grp_site_id_no,
			    egs.empl_grp_site_nm,
			    egs.grp_id,
			    egs.subgrp_id,
			    t.empl_grp_ovrd_id,
			   (select l.lu_val from luv l where l.lu_id = t.ovrd_tp_cd_id) luv_override_type_desc
			from EMPL_GRP_OVERRIDE t,
				empl_grp_site egs
			where egs.empl_grp_no = ? and
				egs.grp_id = t.grp_id and
				egs.subgrp_id = t.subgrp_id
			         """;
    private static final String selectAvailableSitesForGroupSiteException = """
			select egs.empl_grp_no,
		   		egs.empl_grp_site_id_no,
		   		egs.empl_grp_site_nm,
		   		egs.grp_id,
		   		egs.subgrp_id
		 	from
			  	empl_grp_site egs
		 	where egs.empl_grp_no = ? and
			   egs.EMPL_GRP_SITE_NM NOT LIKE '*%' and
			   egs.subgrp_id NOT IN
				(select t.subgrp_id  from EMPL_GRP_OVERRIDE t where t.grp_id = egs.grp_id)
			         """;
    private static final String insertGroupOverride = """
            INSERT INTO empl_grp_override (empl_grp_ovrd_id , GRP_ID, SUBGRP_ID, BIZ_PGM_TP_CD, OVRD_TP_CD_ID, OVRD_RSN_DESC, APRVR_USER_ID, OVRD_ISSUE_DT, EFF_DT, END_DT, INSERT_TS, INSERT_USR) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, SYSDATE, ?)
            """;
    private static final String updateGroupOverride = """
            UPDATE empl_grp_override SET OVRD_TP_CD_ID = ?, BIZ_PGM_TP_CD = ?, SUBGRP_ID = ?, OVRD_RSN_DESC  = ?, APRVR_USER_ID  = ?, OVRD_ISSUE_DT = ?, EFF_DT = ?, END_DT = ?, MODIFY_TS = SYSDATE, MODIFY_USR = ?  WHERE empl_grp_ovrd_id = ?
            """;
    private static final String deleteGroupOverride = """
            DELETE FROM empl_grp_override WHERE empl_grp_ovrd_id = ?
            """;
    private static final String EGOVRD_ID_SEQ = "EGOVRD_ID_SEQ";
    protected final Log logger = LogFactory.getLog(getClass());
    private final DataSource dataSource;
    /*
     * SQL sequences
     */
    private DataFieldMaxValueIncrementer groupOverrideIdIncrementer;


    public GroupOverrideDAOJdbc(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @PostConstruct
    private void initialize() {
        setDataSource(dataSource);
        groupOverrideIdIncrementer = new OracleSequenceMaxValueIncrementer(dataSource, EGOVRD_ID_SEQ);
    }


    @Override
    public Collection<GroupOverride> getGroupOverrides() {
        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectGroupOverrides);

        Object params[] = new Object[]{};
        JdbcTemplate template = getJdbcTemplate();
        int types[] = new int[]{};

        ArrayList<GroupOverride> lGroupOverrides = (ArrayList<GroupOverride>) template.query(lQuery.toString(),
                params, types, new GroupOverrideRowMapper());

        return lGroupOverrides;
    }

    @Override
    public GroupOverride getGroupOverride(int groupOverrideId) {
        StringBuffer lQuery = new StringBuffer();

        lQuery.append(selectGroupOverride);
        lQuery.append("AND grpovr.empl_grp_ovrd_id = ? ");

        Object params[] = new Object[]{groupOverrideId};
        JdbcTemplate template = getJdbcTemplate();
        int types[] = new int[]{Types.INTEGER};

        ArrayList<GroupOverride> results = (ArrayList<GroupOverride>) template.query(lQuery.toString(),
                params, types, new GroupOverrideRowMapper());

        GroupOverride dto = null;
        if (results.size() > 0) {
            dto = (GroupOverride) results.get(0);
        }
        return dto;
    }

    @Override
	public ArrayList<GroupOverride> getGroupOverrideByGroupNumber(String groupNumber) {
        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectGroupOverride);
        lQuery.append("AND grpsite.empl_grp_no = ? ");

        Object params[] = new Object[]{groupNumber};
        JdbcTemplate template = getJdbcTemplate();
        int types[] = new int[]{Types.VARCHAR};

        ArrayList<GroupOverride> results = (ArrayList<GroupOverride>) template.query(lQuery.toString(),
                params, types, new GroupOverrideRowMapper());


        return results;
    }

    @Override
    public ArrayList<GroupOverride> getAssignedSitesForGroupSiteException(String groupNumber) {
        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectAssignedSitesForGroupSiteException);

        Object params[] = new Object[]{groupNumber};
        JdbcTemplate template = getJdbcTemplate();
        int types[] = new int[]{Types.VARCHAR};

        ArrayList<GroupOverride> results = (ArrayList<GroupOverride>) template.query(lQuery.toString(),
                params, types, new SelectedORAvailableSitesForGroupOverrideRowMapper());


        return results;
    }

    @Override
    public ArrayList<GroupOverride> getAvailableSitesForGroupSiteException(String groupNumber) {
        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectAvailableSitesForGroupSiteException);

        Object params[] = new Object[]{groupNumber};
        JdbcTemplate template = getJdbcTemplate();
        int types[] = new int[]{Types.VARCHAR};

        ArrayList<GroupOverride> results = (ArrayList<GroupOverride>) template.query(lQuery.toString(),
                params, types, new SelectedORAvailableSitesForGroupOverrideRowMapper());

        //Assign temporary override id
        int id = 0;
        for (GroupOverride lGroupOverride : results) {
            lGroupOverride.setRowNumber(id++);
        }

        return results;
    }

    @Override
    public ArrayList<GroupOverride> getGroupOverrideByGroupID(Integer groupID) {
        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectGroupOverride);
        lQuery.append("AND grpsite.grp_id = ? ");

        Object params[] = new Object[]{groupID};
        JdbcTemplate template = getJdbcTemplate();
        int types[] = new int[]{Types.INTEGER};

        ArrayList<GroupOverride> results = (ArrayList<GroupOverride>) template.query(lQuery.toString(),
                params, types, new GroupOverrideRowMapper());


        return results;
    }

    private int insertGroupOverride(GroupOverride lGroupOverride) throws DataAccessException {
        // userID value temporary until asciegi id is used
        /*
         * SQL sequences
         */

        Long groupOverrideIdSeq = new Long(groupOverrideIdIncrementer.nextLongValue());
        lGroupOverride.setGroupOverrideId(groupOverrideIdSeq.intValue());
        JdbcTemplate template = getJdbcTemplate();


        Object params[] = new Object[]{lGroupOverride.getGroupOverrideId(),
                lGroupOverride.getGroupId(), lGroupOverride.getSiteId(),
                lGroupOverride.getBizProgTypeCodeId(), lGroupOverride.getExceptionTypeCodeId(),
                lGroupOverride.getReason(), lGroupOverride.getApproverId(),
                lGroupOverride.getIssueDate(), lGroupOverride.getEffectiveDate(),
                lGroupOverride.getEndDate(), lGroupOverride.getUserId()
        };


        int types[] = new int[]{Types.INTEGER,
                Types.INTEGER, Types.INTEGER,
                Types.INTEGER, Types.INTEGER,
                Types.VARCHAR, Types.VARCHAR,
                Types.DATE, Types.DATE,
                Types.DATE, Types.VARCHAR};

        int rowsInserted = template.update(insertGroupOverride, params, types);

        return rowsInserted;
    }

    //Produces warnings during compile time to quickly identify typos or API changes
    @Override
    public int updateGroupOverride(GroupOverride lGroupOverride) throws DataAccessException {

        if (lGroupOverride.getGroupOverrideId() == null || lGroupOverride.getGroupOverrideId().equals(0)) {
            return this.insertGroupOverride(lGroupOverride);
        }

        Integer groupOverrideId = (lGroupOverride.getGroupOverrideId() != null) ? lGroupOverride.getGroupOverrideId() : null;
        Integer siteId = (lGroupOverride.getSiteId() != null) ? lGroupOverride.getSiteId() : null;
        Integer luvTypeCodeId = (lGroupOverride.getExceptionTypeCodeId() != null) ? lGroupOverride.getExceptionTypeCodeId() : null;

        String bizProgTypeCodeId = (lGroupOverride.getBizProgTypeCodeId() != null) ? lGroupOverride.getBizProgTypeCodeId() : null;

        String reason = (lGroupOverride.getReason() != null) ? lGroupOverride
                .getReason() : null;
        String approverId = (lGroupOverride.getApproverId() != null) ? lGroupOverride
                .getApproverId() : null;

        String userId = (lGroupOverride.getUserId() != null) ? lGroupOverride
                .getUserId() : null;
        Date issueDate = (lGroupOverride.getIssueDate() != null) ? lGroupOverride.getIssueDate()
                : null;
        Date effDate = (lGroupOverride.getEffectiveDate() != null) ? lGroupOverride.getEffectiveDate()
                : null;
        Date endDate = (lGroupOverride.getEndDate() != null) ? lGroupOverride.getEndDate()
                : null;

        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{luvTypeCodeId, bizProgTypeCodeId, siteId, reason,
                approverId, issueDate, effDate, endDate, userId, groupOverrideId};
        int types[] = new int[]{Types.INTEGER, Types.VARCHAR, Types.INTEGER, Types.VARCHAR, Types.VARCHAR, Types.DATE,
                Types.DATE, Types.DATE, Types.VARCHAR, Types.INTEGER};


        int rowInserted = template.update(updateGroupOverride, params, types);
        return rowInserted;

    }

    //Produces warnings during compile time to quickly identify typos or API changes
    @Override
    public int deleteGroupOverride(Integer groupOverrideId) throws DataAccessException {
        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{groupOverrideId};
        int types[] = new int[]{Types.INTEGER};
        return template.update(deleteGroupOverride, params, types);
    }

    private static final class GroupOverrideRowMapper implements RowMapper {
        public Object mapRow(ResultSet rs, int rowNum) throws SQLException {

            GroupOverride lGroupOverride = new GroupOverride();
            lGroupOverride
                    .setGroupOverrideId(rs.getObject("empl_grp_ovrd_id") != null ? new Integer(
                            rs.getInt("empl_grp_ovrd_id"))
                            : null);
            lGroupOverride.setGroupNo(rs.getString("empl_grp_no"));
            lGroupOverride.setSiteNo(rs.getString("empl_grp_site_id_no"));
            lGroupOverride.setGroupId(rs.getInt("grp_id"));
            lGroupOverride.setSiteId(rs.getInt("subgrp_id"));
            lGroupOverride.setGroupName(rs.getString("empl_grp_nm"));
            lGroupOverride.setSiteName(rs.getString("empl_grp_site_nm"));
            lGroupOverride.setReason(rs.getString("ovrd_rsn_desc"));
            lGroupOverride.setBizProgTypeCodeId(rs.getString("biz_pgm_tp_cd"));
            lGroupOverride.setBizProgramName(rs.getString("biz_pgm_desc"));
            lGroupOverride.setExceptionTypeCodeId(rs.getInt("ovrd_tp_cd_id"));
            lGroupOverride.setApproverId(rs.getString("aprvr_user_id"));
            lGroupOverride.setIssueDate(rs.getDate("ovrd_issue_dt"));
            lGroupOverride.setEffectiveDate(rs.getDate("eff_dt"));
            lGroupOverride.setEndDate(rs.getDate("end_dt"));
            lGroupOverride.setExceptionTypeDesc(rs.getString("luv_override_type_desc"));

            return lGroupOverride;

        }
    }

    private static final class SelectedORAvailableSitesForGroupOverrideRowMapper implements RowMapper {
        public Object mapRow(ResultSet rs, int rowNum) throws SQLException {

            GroupOverride lGroupOverride = new GroupOverride();

            lGroupOverride.setGroupNo(rs.getString("empl_grp_no"));
            lGroupOverride.setSiteNo(rs.getString("empl_grp_site_id_no"));
            lGroupOverride.setSiteName(rs.getString("empl_grp_site_nm"));
            lGroupOverride.setGroupId(rs.getInt("grp_id"));
            lGroupOverride.setSiteId(rs.getInt("subgrp_id"));

            return lGroupOverride;

        }
    }


}