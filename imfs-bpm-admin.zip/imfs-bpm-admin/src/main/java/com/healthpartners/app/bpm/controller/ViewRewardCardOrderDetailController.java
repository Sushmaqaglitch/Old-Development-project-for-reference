/* $Id: ViewProgram.java 217328 2012-10-04 21:33:23Z jxbourbour $ */

package com.healthpartners.app.bpm.controller;

import com.healthpartners.app.bpm.dto.RewardCardFulfillmentTrackingReportHist;
import com.healthpartners.app.bpm.iface.RewardCardService;
import jakarta.servlet.http.HttpServletRequest;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

/**
 *
 * 
 * @author tjquist
 */
@Controller
public class ViewRewardCardOrderDetailController extends BaseController {

	private final RewardCardService rewardCardService;

	protected final Log logger = LogFactory.getLog(getClass());

	public ViewRewardCardOrderDetailController(RewardCardService rewardCardService) {
		this.rewardCardService = rewardCardService;
	}


	@GetMapping("/viewRewardCardOrderDetail")
	public String viewRewardCardOrderDetail(@RequestParam(name = "rewardFulfillHistID") String rewardFulfillHistID, @RequestParam(name = "externalTransID") String externalTransID, ModelMap modelMap) {

		RewardCardFulfillmentTrackingReportHist lRewardCardFulfillmentTrackingReportHist = null;

		try {

			lRewardCardFulfillmentTrackingReportHist =
			        rewardCardService.getRewardCardFulfillmentTrackingReportHistDetail(Integer.valueOf(rewardFulfillHistID), externalTransID);

			modelMap.addAttribute("rewardCardOrderDetail", lRewardCardFulfillmentTrackingReportHist);

		} catch (Exception e) {
			createErrorMessageOnModel(modelMap, getStackTrace(e));
		}
		return "viewRewardCardOrderDetail";
	}

}
