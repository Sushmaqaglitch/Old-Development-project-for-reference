package com.healthpartners.app.bpm.form;

/**
 * @author jxbourbour
 *
 */
public class RewardCardFulfillmentSearchForm extends BaseForm {

    static final long serialVersionUID = 0L;

    private String groupNumber;
    private String groupName;
    private String siteNumber;
    private String effectiveDate;
    private String fulfillmentFromDate;
    private String fulfillmentToDate;
    private String actionType;
    private String contractNumber;
    private String memberNumber;
    private String cachePersonID;
    private String transactionID;
    private Integer rewardCardStatusID;
    private Integer rewardCardID;
    private Integer groupID;


    private String whichList;

    public RewardCardFulfillmentSearchForm() {
        super();
    }


//	public ActionMessages validateSearch(ActionMapping mapping,
//			HttpServletRequest request)
//	{
//
//		boolean noCachePersonID = false;
//		boolean noTransactionID = false;
//
//	    if (!effectiveDate.isEmpty()) {
//	    	this.validateDateFormat("Program Year Effective Date", effectiveDate, "Program Year Effective Date");
//	    }
//
//
//	    if (!fulfillmentFromDate.isEmpty()) {
//	    	this.validateDateFormat("File Sent From Date", fulfillmentFromDate, "File Sent From Date");
//	    }
//	    if (!fulfillmentToDate.isEmpty()) {
//	    	this.validateDateFormat("File Sent To Date", fulfillmentToDate, "File Sent To Date");
//	    }
//
//	    if (cachePersonID == null || cachePersonID.isEmpty() ) {
//	    	noCachePersonID = true;
//	    }
//	    if (transactionID == null || transactionID.isEmpty() ) {
//	    	noTransactionID = true;
//	    }
//
//	    if (noCachePersonID && noTransactionID) {
//		    if ((memberNumber == null || memberNumber.isEmpty()) && (groupNumber != null && !groupNumber.isEmpty())) {
//		    	this.validateNotNull("Group No", groupNumber, " Group No");
//		    } else if ((groupNumber == null || groupNumber.isEmpty()) && memberNumber != null && !memberNumber.isEmpty()) {
//		    	this.validateNotNull("Member No", memberNumber, " Member No");
//		    } else {
//		    	this.validateNotNull("Group No", groupNumber, " Group No");
//		    	this.validateNotNull("Member No", memberNumber, " Member No");
//		    }
//	    }
//
//
//	    validateNotSpecialChar("groupNumber", groupNumber, "Group No");
//	    validateNotSpecialChar("groupName", groupName, "Group Name");
//	    validateNotSpecialChar("siteNumber", siteNumber, "Site No");
//
//	    if (!contractNumber.isEmpty()) {
//	    	validateNotInteger("contractNumber", contractNumber, "Contract No");
//	    }
//
//	    //String rewardCardStatusIDStr = String.valueOf(rewardCardStatusID);
//
//	    //this.validateNotNull("Reward Card Status", rewardCardStatusIDStr, " Reward Card Status");
//
//
//		return getActionMessages();
//	}


    public String getGroupNumber() {
        if (groupNumber != null) {
            return groupNumber.trim();
        }
        return groupNumber;
    }


    public void setGroupNumber(String groupNumber) {
        this.groupNumber = groupNumber;
    }

    public String getActionType() {
        return actionType;
    }


    public void setActionType(String actionType) {
        this.actionType = actionType;
    }


    public final String getGroupName() {
        if (groupName != null) {
            return groupName.trim();
        }
        return groupName;
    }


    public final void setGroupName(String groupName) {
        this.groupName = groupName;
    }


    public final String getSiteNumber() {
        if (siteNumber != null) {
            return siteNumber.trim();
        }
        return siteNumber;
    }


    public final void setSiteNumber(String siteNumber) {
        this.siteNumber = siteNumber;
    }


    public final String getEffectiveDate() {
        return effectiveDate;
    }


    public final void setEffectiveDate(String effectiveDate) {
        this.effectiveDate = effectiveDate;
    }


    public final String getWhichList() {
        return whichList;
    }


    public final void setWhichList(String whichList) {
        this.whichList = whichList;
    }


    public String getFulfillmentFromDate() {
        return fulfillmentFromDate;
    }


    public void setFulfillmentFromDate(String fulfillmentFromDate) {
        this.fulfillmentFromDate = fulfillmentFromDate;
    }


    public String getFulfillmentToDate() {
        return fulfillmentToDate;
    }


    public void setFulfillmentToDate(String fulfillmentToDate) {
        this.fulfillmentToDate = fulfillmentToDate;
    }


    public String getContractNumber() {
        if (contractNumber != null) {
            return contractNumber.trim();
        }
        return contractNumber;
    }


    public void setContractNumber(String contractNumber) {
        this.contractNumber = contractNumber;
    }


    public String getMemberNumber() {
        if (memberNumber != null) {
            return memberNumber.trim();
        }
        return memberNumber;
    }


    public void setMemberNumber(String memberNumber) {
        this.memberNumber = memberNumber;
    }


    public String getCachePersonID() {
        return cachePersonID;
    }


    public void setCachePersonID(String cachePersonID) {
        this.cachePersonID = cachePersonID;
    }


    public String getTransactionID() {
        return transactionID;
    }


    public void setTransactionID(String transactionID) {
        this.transactionID = transactionID;
    }


    public Integer getRewardCardStatusID() {
        return rewardCardStatusID;
    }


    public void setRewardCardStatusID(Integer rewardCardStatusID) {
        this.rewardCardStatusID = rewardCardStatusID;
    }


    public Integer getRewardCardID() {
        return rewardCardID;
    }


    public void setRewardCardID(Integer rewardCardID) {
        this.rewardCardID = rewardCardID;
    }

    public Integer getGroupID() {
        return groupID;
    }

    public void setGroupID(Integer groupID) {
        this.groupID = groupID;
    }
}
