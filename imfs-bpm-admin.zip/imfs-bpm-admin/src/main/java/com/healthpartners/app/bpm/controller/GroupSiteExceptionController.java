package com.healthpartners.app.bpm.controller;

import com.healthpartners.app.bpm.common.BPMAdminConstants;
import com.healthpartners.app.bpm.common.BPMAdminUtils;
import com.healthpartners.app.bpm.common.BPMPagination;
import com.healthpartners.app.bpm.dto.EmployerGroup;
import com.healthpartners.app.bpm.dto.GroupOverride;
import com.healthpartners.app.bpm.dto.LookUpValueCode;
import com.healthpartners.app.bpm.dto.ProgramType;
import com.healthpartners.app.bpm.exception.BPMException;
import com.healthpartners.app.bpm.form.AddGroupSiteExceptionForm;
import com.healthpartners.app.bpm.form.GroupSiteExceptionSearchForm;
import com.healthpartners.app.bpm.form.SaveGroupSiteExceptionForm;
import com.healthpartners.app.bpm.iface.BusinessProgramService;
import com.healthpartners.app.bpm.pageable.PageableGroupOverride;
import com.healthpartners.app.bpm.service.GroupSiteExceptionService;
import com.healthpartners.app.bpm.session.UserSession;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Collection;

@Controller
public class GroupSiteExceptionController extends BaseController implements Validator {

    private String delimiter = ",";

    private final BusinessProgramService businessProgramService;
    private final GroupSiteExceptionService groupSiteExceptionService;
    private final Log logger = LogFactory.getLog(getClass());

    public GroupSiteExceptionController(BusinessProgramService businessProgramService, GroupSiteExceptionService groupSiteExceptionService) {
        this.businessProgramService = businessProgramService;
        this.groupSiteExceptionService = groupSiteExceptionService;
    }

    @GetMapping("/showGroupSiteException")
    public String load(ModelMap modelMap) throws BPMException {
        try {
            GroupSiteExceptionSearchForm groupSiteExceptionSearchForm = new GroupSiteExceptionSearchForm();
            modelMap.put("groupSiteExceptionSearchForm", groupSiteExceptionSearchForm);
            AddGroupSiteExceptionForm addGroupSiteExceptionForm = new AddGroupSiteExceptionForm();
            modelMap.put("addGroupSiteExceptionForm", addGroupSiteExceptionForm);
            setDefaultPagination(modelMap);
        } catch (Exception e) {
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
            modelMap.put("errorMsg", getStackTrace(e));
        }

        return "groupSiteExceptionSearch";
    }

    @GetMapping("/groupSiteExceptionSearch")
    public String reloadSearchResults(ModelMap modelMap) throws BPMException {
        try {
            String actionType = (String)modelMap.getAttribute("actionType");
            String groupNumber = (String)modelMap.getAttribute("groupNumber");
            String groupName = (String)modelMap.getAttribute("groupName");

            GroupSiteExceptionSearchForm groupSiteExceptionSearchForm = new GroupSiteExceptionSearchForm();
            groupSiteExceptionSearchForm.setActionType(actionType);
            groupSiteExceptionSearchForm.setGroupNumber(groupNumber);
            groupSiteExceptionSearchForm.setGroupName(groupName);
            modelMap.put("groupSiteExceptionSearchForm", groupSiteExceptionSearchForm);

            AddGroupSiteExceptionForm addGroupSiteExceptionForm = new AddGroupSiteExceptionForm();
            modelMap.put("addGroupSiteExceptionForm", addGroupSiteExceptionForm);

            return performSearch(groupSiteExceptionSearchForm, modelMap);
        } catch (Exception e) {
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
            modelMap.put("errorMsg", getStackTrace(e));
        }

        return "groupSiteExceptionSearch";
    }

    @PostMapping("/groupSiteExceptionSearch")
    public String submit(@ModelAttribute("groupSiteExceptionSearchForm") GroupSiteExceptionSearchForm groupSiteExceptionSearchForm, ModelMap modelMap, BindingResult result, HttpServletRequest request) throws Exception {
        String resultPage = "groupSiteExceptionSearch";

        try {
            if (ACTION_SEARCH.equals(groupSiteExceptionSearchForm.getActionType())) {
                validate(groupSiteExceptionSearchForm, result);
                if (result.hasErrors()) {
                    setDefaultPagination(modelMap);
                    return resultPage;
                }

                return performSearch(groupSiteExceptionSearchForm, modelMap);

            } else if (ACTION_DELETE.equals(groupSiteExceptionSearchForm.getActionType())) {
                return performDelete(groupSiteExceptionSearchForm, modelMap);
            }

        } catch (Exception e) {
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
            // Add error stack trace on the request, to be hidden in html.
            createErrorMessageOnModel(modelMap, getStackTrace(e));
        }

        return resultPage;
    }

    @PostMapping(value = "/groupSiteExceptionSearch", params = "next")
    public String submitNext(@ModelAttribute("groupSiteExceptionSearchForm") GroupSiteExceptionSearchForm groupSiteExceptionSearchForm, ModelMap modelMap) throws Exception {
        groupSiteExceptionSearchForm.setActionType(ACTION_PAGE_FORWARD);
        return handlePaginationActions(groupSiteExceptionSearchForm, modelMap);
    }

    @PostMapping(value = "/groupSiteExceptionSearch", params = "back")
    public String submitBack(@ModelAttribute("groupSiteExceptionSearchForm") GroupSiteExceptionSearchForm groupSiteExceptionSearchForm, ModelMap modelMap) throws Exception {
        groupSiteExceptionSearchForm.setActionType(ACTION_PAGE_BACK);
        return handlePaginationActions(groupSiteExceptionSearchForm, modelMap);
    }

    @PostMapping(value = "/groupSiteExceptionSearch", params = "download")
    public String submitDownload(@ModelAttribute("groupSiteExceptionSearchForm") GroupSiteExceptionSearchForm groupSiteExceptionSearchForm, HttpServletRequest request, ModelMap modelMap, HttpServletResponse response) throws Exception {
        return handleDownload(groupSiteExceptionSearchForm, request, modelMap, response);
    }
    @PostMapping(value = "/groupSiteExceptionSearch", params = "addGroupSiteException")
    public String submitAdd(@ModelAttribute("groupSiteExceptionSearchForm") GroupSiteExceptionSearchForm groupSiteExceptionSearchForm, ModelMap modelMap, BindingResult result, RedirectAttributes ra, HttpServletRequest request) throws BPMException {
        String resultPage = "groupSiteExceptionSearch";
        try {
            validate(groupSiteExceptionSearchForm, result);
            if (result.hasErrors()) {
                return resultPage;
            }

            return handleAdd(groupSiteExceptionSearchForm, modelMap, ra);

        } catch (Exception e) {
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
            modelMap.put("errorMsg", getStackTrace(e));
        }

        return resultPage;
    }

    private void setDefaultPagination(ModelMap modelMap) {
        BPMPagination pagination = new BPMPagination();
        pagination.disableBackNextButtons();
        modelMap.put("backPageFlag", pagination.getBackPageFlag());
        modelMap.put("nextPageFlag", pagination.getNextPageFlag());
    }

    private String performSearch(GroupSiteExceptionSearchForm groupSiteExceptionSearchForm, ModelMap modelMap) throws Exception {
        String resultPage = "groupSiteExceptionSearch";
        String lGroupNumber = groupSiteExceptionSearchForm.getGroupNumber();
        String lGroupName = groupSiteExceptionSearchForm.getGroupName();
        Integer lGroupID = groupSiteExceptionSearchForm.getGroupID();

        modelMap.put("groupNumber", lGroupNumber);
        modelMap.put("groupID", lGroupID);

        if ((lGroupID != null && lGroupID.intValue() > 0) || (lGroupNumber != null && lGroupNumber.length() > 0) || GROUP_SITE_EXCEPTION_OVERRIDES.equals(groupSiteExceptionSearchForm.getWhichList())) {
            searchByGroupIDORNumber(modelMap, groupSiteExceptionSearchForm);
            return resultPage;
        }

        if ((lGroupName != null && lGroupName.trim().length() > 0) || EMPLOYER_GROUPS_LIST.equals(groupSiteExceptionSearchForm.getWhichList())) {
            searchByGroupName(modelMap, groupSiteExceptionSearchForm);
            return resultPage;
        }

        return resultPage;
    }

    private void searchByGroupIDORNumber(ModelMap modelMap, GroupSiteExceptionSearchForm lGroupSiteExceptionSearchForm) throws Exception {
        boolean newDTOList = false;
        String actionType = lGroupSiteExceptionSearchForm.getActionType();

        ArrayList<GroupOverride> lGroupOverrides = null;
        lGroupOverrides = getUserSession().getGroupSiteExceptions();


        if (lGroupOverrides == null || actionType.equals(ACTION_SEARCH) || actionType.equals(ACTION_SITE_SEARCH)) {
            if (lGroupSiteExceptionSearchForm.getGroupNumber() != null && lGroupSiteExceptionSearchForm.getGroupNumber().length() > 0) {
                lGroupOverrides = businessProgramService.getGroupOverrideByGroupNumber(lGroupSiteExceptionSearchForm.getGroupNumber());

            } else {
                lGroupOverrides = businessProgramService.getGroupOverrideByGroupID(lGroupSiteExceptionSearchForm.getGroupID());
            }

            getUserSession().setGroupSiteExceptions(lGroupOverrides);
            newDTOList = true;
            if (lGroupOverrides.size() > 0 && lGroupOverrides.get(0).getGroupName().length() > 0) {
                String groupName = lGroupOverrides.get(0).getGroupName();
                lGroupSiteExceptionSearchForm.setGroupName(groupName);
            } else {
                lGroupSiteExceptionSearchForm.setGroupName(getUserSession().getGroupName());
            }
        }

        if (lGroupOverrides.size() <= 0) {
            createActionMessagesOnModel(modelMap, "messages.info", new Object[]{"No results found for the given search attribute(s)"});

            if (lGroupSiteExceptionSearchForm.getGroupNumber() != null && lGroupSiteExceptionSearchForm.getGroupNumber().length() > 0) {
                lGroupSiteExceptionSearchForm.setGroupName(null);
            }
        }

        getUserSession().setGroupSiteExceptions(lGroupOverrides);

        setGroupSiteExceptionPagination(modelMap, getUserSession(), actionType, newDTOList);

        getUserSession().setGroupSiteExceptionSearchForm(lGroupSiteExceptionSearchForm);
        if (getUserSession().getEmployerGroups() != null && getUserSession().getEmployerGroups().size() > 0) {
            modelMap.put("groupNameExists", "true");
        }
        getUserSession().setGroupName(lGroupSiteExceptionSearchForm.getGroupName());
    }

    private void searchByGroupName(ModelMap modelMap, GroupSiteExceptionSearchForm lGroupSiteExceptionSearchForm) throws Exception {
        boolean newDTOList = false;
        ArrayList<EmployerGroup> lEmployerGroups = getUserSession().getEmployerGroups();
        String actionType = lGroupSiteExceptionSearchForm.getActionType();

        if (lEmployerGroups == null || actionType.equals(ACTION_SEARCH)) {
            lEmployerGroups = (ArrayList<EmployerGroup>)
                    businessProgramService.getGroupsByName(lGroupSiteExceptionSearchForm.getGroupName());

            if (lEmployerGroups.size() <= 0) {
                createActionMessagesOnModel(modelMap, "messages.info", new Object[]{"No results found for the given search attribute(s)"});
            }

            getUserSession().setEmployerGroups(lEmployerGroups);
            newDTOList = true;
        }

        setEmployerGroupPaginationOnModel(modelMap, getUserSession(), actionType, newDTOList);

        if (actionType.equals(ACTION_SEARCH)) {
            modelMap.put("groupNameExists", "false");
        }
        if (actionType.equals(ACTION_SITE_SEARCH)) {
            modelMap.put("groupNameExists", "true");
        }

        getUserSession().setEmployerGroups(lEmployerGroups);
        getUserSession().setGroupSiteExceptionSearchForm(lGroupSiteExceptionSearchForm);
        getUserSession().setGroupName(lGroupSiteExceptionSearchForm.getGroupName());
        lGroupSiteExceptionSearchForm.setGroupName(getUserSession().getGroupName());
    }

    private void setGroupSiteExceptionPagination(ModelMap modelMap, UserSession sessionBean, String actionType, boolean newDTOList) {
        ArrayList<GroupOverride> lGroupSiteExceptions = sessionBean.getGroupSiteExceptions();

        /**
         * Create a Pageable wrapper for the array list.
         * Create a Pagination object and point it to the wrapper.
         */
        BPMPagination pagination = sessionBean.getPaginationMap().get(EMPLOYER_GROUPS_OVERRIDES_LIST);
        PageableGroupOverride lPGO = null;
        if (pagination == null || newDTOList)
        {
            lPGO = new PageableGroupOverride(lGroupSiteExceptions);
            lPGO.addRowNumber();
            pagination = new BPMPagination(lPGO, new ArrayList<Object>(lGroupSiteExceptions));
            sessionBean.getPaginationMap().put(EMPLOYER_GROUPS_OVERRIDES_LIST, pagination);
        }

        ArrayList<GroupOverride> lGroupSiteExceptionsPerPage = (ArrayList<GroupOverride>) determineNextOrBackAction(actionType, pagination);
        setAttributesForPaginationOnModel(modelMap, lGroupSiteExceptions.size(), pagination);
        sessionBean.setPagination(pagination);

        modelMap.put("groupSiteExceptions", lGroupSiteExceptionsPerPage);
        sessionBean.setGroupSiteExceptionsPerPage(lGroupSiteExceptionsPerPage);
    }

    private String handlePaginationActions(GroupSiteExceptionSearchForm form, ModelMap modelMap) throws Exception {
        return performSearch(form, modelMap);
    }

    private String handleAdd(GroupSiteExceptionSearchForm form, ModelMap modelMap, RedirectAttributes ra) throws BPMException {
        String resultPage = "groupSiteExceptionSearch";
        ArrayList<GroupOverride> lAssignedSitesForGroupSiteException = businessProgramService.getAssignedSitesForGroupSiteException(form.getGroupNumber());

        /*
         * If one or more group site exceptions already assigned, don't allow in to add screen.  User must perform a copy
         * from the summary screen.
         */
        if (lAssignedSitesForGroupSiteException.size() > 0) {
            String message = getMessage("errors.groupsiteexceptionadderror", new Object[]{"Group Site Exceptions"});
            createErrorMessageOnModel(modelMap, message);
            return resultPage;
        }

        ArrayList<EmployerGroup> lEmployerGroups = (ArrayList<EmployerGroup>) businessProgramService.getGroups(form.getGroupNumber());
        if(lEmployerGroups == null || lEmployerGroups.size() <= 0) {
          createNoResultsFoundMessageOnModel(modelMap);
          return resultPage;
        }
        resultPage = "redirect:addGroupSiteException";
        ra.addFlashAttribute("groupID", lEmployerGroups.get(0).getGroupID());
        return resultPage;
    }

    private String handleDownload(GroupSiteExceptionSearchForm form, HttpServletRequest request, ModelMap modelMap, HttpServletResponse response) throws IOException, BPMException {
        String resultPage = "groupSiteExceptionSearch";
        Collection<GroupOverride> groupOverrides = businessProgramService.getGroupOverridesAll();
        if (groupOverrides != null && groupOverrides.size() > 0) {
            response.setHeader("Content-Type", "text/csv");
            response.setHeader("Content-Disposition", "attachment;filename=\"report.csv\"");
            setAttributesPaginationBackNextButtonsToDisableOnModel(modelMap, getUserSession());

            writeCsv(groupOverrides, response.getOutputStream());
        } else {
            createErrorMessageOnModel(modelMap, getMessage("errors.download", null));
            // No pagination needed when list is empty.
            modelMap.put("luvRewardCardRecycleStatusTypes", getUserSession().getRewardCardFulfillRecycleStatusCodes());
        }

        return resultPage;
    }

    private void writeCsv(Collection<GroupOverride> groupOverrides, OutputStream output) throws IOException {
        BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(output, "UTF-8"));

        formatHeaderNWrite(writer);

        for (GroupOverride groupOverride : groupOverrides) {
            formatDetailNWrite(writer, groupOverride);
        }

        closeFileWriter(writer);
    }

    public void closeFileWriter(BufferedWriter writer) {
        try {
            writer.flush();
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void formatHeaderNWrite(BufferedWriter writer) throws IOException {
        writer.append("Group No");
        writer.append(delimiter);

        writer.append("Site No");
        writer.append(delimiter);

        writer.append("Group Name");
        writer.append(delimiter);

        writer.append("Site Name");
        writer.append(delimiter);

        writer.append("Program Name");
        writer.append(delimiter);

        writer.append("Exception Type");
        writer.append(delimiter);

        writer.append("Issue Date");
        writer.append(delimiter);

        writer.append("Effective Date");
        writer.append(delimiter);

        writer.append("End Date");
        writer.append(delimiter);

        writer.newLine();
    }


    private void formatDetailNWrite(BufferedWriter writer, GroupOverride groupSiteException) throws IOException {
        writer.append(groupSiteException.getGroupNo());
        writer.append(delimiter);

        writer.append(groupSiteException.getSiteNo());
        writer.append(delimiter);

        writer.append(groupSiteException.getGroupName());
        writer.append(delimiter);

        writer.append(groupSiteException.getSiteName());
        writer.append(delimiter);

        writer.append(groupSiteException.getBizProgramName());
        writer.append(delimiter);

        writer.append(groupSiteException.getExceptionTypeDesc());
        writer.append(delimiter);

        writer.append(BPMAdminUtils.formatDateMMddyyyy(groupSiteException.getIssueDate()));
        writer.append(delimiter);

        writer.append(BPMAdminUtils.formatDateMMddyyyy(groupSiteException.getEffectiveDate()));
        writer.append(delimiter);

        writer.append(BPMAdminUtils.formatDateMMddyyyy(groupSiteException.getEndDate()));

        writer.newLine();
    }

    private String performDelete(GroupSiteExceptionSearchForm groupSiteExceptionSearchForm, ModelMap modelMap) throws Exception {
        String resultPage = "groupSiteExceptionSearch";
        Integer groupOverrideID = groupSiteExceptionSearchForm.getGroupOverrideID();

        GroupOverride groupSiteException = groupSiteExceptionService.getGroupOverride(groupOverrideID);
        if (groupSiteException == null) {
            logger.error("GroupSiteException record to be deleted not found.");
            createErrorMessageOnModel(modelMap, getMessage("messages.groupSiteExceptionDeleteFailed", new Object[]{"Delete failed."}));
            return resultPage;
        }

        groupSiteExceptionService.deleteGroupOverride(groupOverrideID);
        createActionMessagesOnModel(modelMap, "messages.groupSiteExceptionDeleteSuccess", new Object[]{"Deleted successfully."});

        ArrayList<GroupOverride> lGroupSiteExceptions = groupSiteExceptionService.getGroupOverrideByGroupID(groupSiteException.getGroupId());
        getUserSession().setGroupSiteExceptions(lGroupSiteExceptions);
        modelMap.put("employerGroups", getUserSession().getEmployerGroups());

        setGroupSiteExceptionPagination(modelMap, getUserSession(), "Delete", true);

        return resultPage;
    }

    @Override
    public boolean supports(Class<?> clazz) {
        return GroupSiteExceptionSearchForm.class.isAssignableFrom(clazz);
    }

    @Override
    public void validate(Object target, Errors errors) {
        GroupSiteExceptionSearchForm form = (GroupSiteExceptionSearchForm) target;

        if(StringUtils.isEmpty(form.getGroupName())) {
            validateBothNotNull("groupNumber", form.getGroupNumber(), form.getGroupName(), "Group Name or Group Number", errors);
        }

        if (StringUtils.isNotEmpty(form.getGroupNumber()) ) {
            getValidationSupport().validateNotSpecialChar("groupNumber", form.getGroupNumber(), errors, new Object[]{"Group Number"});
        }

        if (StringUtils.isNotEmpty(form.getGroupName()) ) {
            getValidationSupport().validateNotSpecialChar("groupName", form.getGroupName(), errors, new Object[]{"Group Name"});
        }
    }

    private boolean validateBothNotNull(String fieldElement, String fieldValue, String fieldValue2, String message, Errors errors) {
        boolean result = true;
        if (fieldValue == null || fieldValue.trim().length() <= 0) {
            if(fieldValue2 == null || fieldValue2.trim().length() <= 0) {
                getValidationSupport().addValidationFailureMessage(fieldElement, errors, "errors.required", new Object[]{message});
                result = false;
            }
        }
        return result;
    }

}
