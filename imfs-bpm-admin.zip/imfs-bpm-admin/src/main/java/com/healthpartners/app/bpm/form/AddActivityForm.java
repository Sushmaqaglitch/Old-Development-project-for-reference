/**
 * 
 */
package com.healthpartners.app.bpm.form;

import com.healthpartners.app.bpm.dto.Activity;
import com.healthpartners.app.bpm.dto.LookUpValueCode;

import java.util.Collection;

/**
 * @author tjquist
 *
 */
public class AddActivityForm extends BaseForm {

	static final long serialVersionUID = 0L;

	Activity activity;
	Collection<LookUpValueCode> luvActivityTypes;
	String luvActivityTypeCodeId;
	String effectiveDate = "";
	String endDate = "";


	public AddActivityForm(Activity activity, Collection<LookUpValueCode> luvActivityTypes) {
		this.activity = activity;
		this.luvActivityTypes = luvActivityTypes;
	}

	public Activity getActivity() {
		return activity;
	}

	public void setActivity(Activity activity) {
		this.activity = activity;
	}

	public Collection<LookUpValueCode> getLuvActivityTypes() {
		return luvActivityTypes;
	}

	public void setLuvActivityTypes(Collection<LookUpValueCode> luvActivityTypes) {
		this.luvActivityTypes = luvActivityTypes;
	}

	public String getLuvActivityTypeCodeId() {
		return luvActivityTypeCodeId;
	}

	public void setLuvActivityTypeCodeId(String luvActivityTypeCodeId) {
		this.luvActivityTypeCodeId = luvActivityTypeCodeId;
	}

	public String getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(String effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
}
