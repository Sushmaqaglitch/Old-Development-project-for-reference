package com.healthpartners.app.bpm.controller;

import com.healthpartners.app.bpm.common.BPMAdminConstants;
import com.healthpartners.app.bpm.common.BPMAdminUtils;
import com.healthpartners.app.bpm.common.BPMPagination;
import com.healthpartners.app.bpm.dao.CDHPFulfillmentRptDAO;
import com.healthpartners.app.bpm.dto.CDHPFulfillmentTrackingReportHist;
import com.healthpartners.app.bpm.dto.EmployerGroup;
import com.healthpartners.app.bpm.dto.ExemptionHistory;
import com.healthpartners.app.bpm.dto.LookUpValueCode;
import com.healthpartners.app.bpm.exception.BPMException;
import com.healthpartners.app.bpm.form.CDHPFulfillmentSearchForm;
import com.healthpartners.app.bpm.form.ExemptionHistorySearchForm;
import com.healthpartners.app.bpm.iface.BusinessProgramService;
import com.healthpartners.app.bpm.iface.LookUpValueService;
import com.healthpartners.app.bpm.pageable.PageableExemptionHistory;
import com.healthpartners.app.bpm.session.UserSession;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.*;

@Controller
public class ExemptionHistorySearchController extends BaseController implements Validator {

    private static final String delimiter = ",";
    private static final String EXEMPTION_HISTORIES_LIST = "EXEMPTION_HISTORIES";

    private final BusinessProgramService businessProgramService;
    private final LookUpValueService lookUpValueService;
    private final CDHPFulfillmentRptDAO cdhpFulfillmentRptDAO;


    public ExemptionHistorySearchController(BusinessProgramService businessProgramService, LookUpValueService lookUpValueService, CDHPFulfillmentRptDAO cdhpFulfillmentRptDAO) {
        this.businessProgramService = businessProgramService;
        this.lookUpValueService = lookUpValueService;
        this.cdhpFulfillmentRptDAO = cdhpFulfillmentRptDAO;
    }

    @GetMapping("/exemptionHistorySearch")
    public String loadCDHPFulfillmentSearch(ModelMap modelMap) throws BPMException {
        ExemptionHistorySearchForm form = new ExemptionHistorySearchForm();
        form.setActionType(ACTION_SEARCH);
        loadFormSelects(form);
        setAttributesBackAndNextButtonsOnModel(modelMap, null);
        modelMap.put("exemptionHistorySearchForm", form);
        return "exemptionHistorySearch";
    }

    @PostMapping("/exemptionHistorySearch")
    public String submitSearch(@ModelAttribute("exemptionHistorySearchForm") ExemptionHistorySearchForm form, BindingResult result, ModelMap modelMap) throws Exception {
        form.setActionType(ACTION_SEARCH);
        loadFormSelects(form);
        validate(form, result);
        if (!result.hasErrors()) {
            search(form, modelMap);
        }
        return "exemptionHistorySearch";
    }

    @PostMapping(value = "/exemptionHistorySearch", params = "next")
    public String submitNext(@ModelAttribute("exemptionHistorySearchForm") ExemptionHistorySearchForm form, ModelMap modelMap) throws Exception {
        form.setActionType(ACTION_PAGE_FORWARD);
        loadFormSelects(form);
        handlePaginationActions(form, modelMap);
        return "exemptionHistorySearch";
    }

    @PostMapping(value = "/exemptionHistorySearch", params = "back")
    public String submitBack(@ModelAttribute("exemptionHistorySearchForm") ExemptionHistorySearchForm form, ModelMap modelMap) throws Exception {
        form.setActionType(ACTION_PAGE_BACK);
        loadFormSelects(form);
        handlePaginationActions(form, modelMap);
        return "exemptionHistorySearch";
    }

    @PostMapping(value = "/exemptionHistorySearch", params = "download")
    public String submitDownload(@ModelAttribute("exemptionHistorySearchForm") ExemptionHistorySearchForm form,
                                 HttpServletRequest request, ModelMap modelMap, HttpServletResponse response) throws Exception {
        form.setActionType(ACTION_DOWNLOAD_CONTRIBUTIONS_PAGE);
        handleDownload(form, request, modelMap, response);
        loadFormSelects(form);
        return "exemptionHistorySearch";
    }

    @PostMapping(value = "/exemptionHistorySearch", params = "backToGroupList")
    public String submitBackToGroupList(@ModelAttribute("exemptionHistorySearchForm") ExemptionHistorySearchForm form, ModelMap modelMap) throws Exception {
        form.setActionType(ACTION_BACK_TO_GROUP_LIST);
        form.setGroupNumber("");
        form.setGroupName(getUserSession().getGroupName());
        form.setWhichList("");
        getUserSession().setEmployerGroups(new ArrayList<>());
        backToGroupList(modelMap, form);
        loadFormSelects(form);
        search(form, modelMap);
        return "exemptionHistorySearch";
    }

    private void loadFormSelects(ExemptionHistorySearchForm form) throws BPMException {
        if (CollectionUtils.isEmpty(getUserSession().getExemptionTypes())) {
            getUserSession().setExemptionTypes((ArrayList<LookUpValueCode>) businessProgramService.getExemptionTypeCodes());
        }
        form.setExemptionTypes(getUserSession().getExemptionTypes());
    }

    private void search(ExemptionHistorySearchForm form, ModelMap modelMap) throws Exception {
        if (StringUtils.isNotEmpty(form.getGroupName()) || EMPLOYER_GROUPS_LIST.equals(form.getWhichList())) {
            searchByGroupName(modelMap, form);
        } else {
            searchByGroupID(modelMap, form);
        }
    }

    private void searchByGroupName(ModelMap modelMap, ExemptionHistorySearchForm lExemptionHistorySearchForm) throws Exception {
        boolean newDTOList = false;
        String actionType = lExemptionHistorySearchForm.getActionType();

        ArrayList<EmployerGroup> lEmployerGroups = getUserSession().getEmployerGroups();
        if (CollectionUtils.isEmpty(lEmployerGroups) || actionType.equals(ACTION_SEARCH)) {
            lEmployerGroups = (ArrayList<EmployerGroup>) businessProgramService.getGroupsByName(lExemptionHistorySearchForm.getGroupName());
            getUserSession().setEmployerGroups(lEmployerGroups);
            newDTOList = true;
        }

        //Pagination code begins here.
        setEmployerGroupPaginationOnModel(modelMap, getUserSession(), actionType, newDTOList);
        //Pagination code ends here.

        getUserSession().setEmployerGroups(lEmployerGroups);
        getUserSession().setEmployerGroupsPerPage(null);
        getUserSession().setExemptionHistorySearchForm(lExemptionHistorySearchForm);
        getUserSession().setGroupName(lExemptionHistorySearchForm.getGroupName());
        lExemptionHistorySearchForm.setGroupName(getUserSession().getGroupName());

        if (lEmployerGroups.size() <= 0) {
            createActionMessagesOnModel(modelMap, "messages.info", new Object[]{"No results found for the given search attribute(s)"});
        }
    }

    private void searchByGroupID(ModelMap modelMap, ExemptionHistorySearchForm pExemptionHistorySearchForm) throws Exception {
        boolean newDTOList = false;
        String actionType = pExemptionHistorySearchForm.getActionType();

        ArrayList<ExemptionHistory> lExemptionHistoryList = getUserSession().getExemptionHistoryList();

        if (lExemptionHistoryList == null || actionType.equals(ACTION_SEARCH) || actionType.equals(ACTION_SITE_SEARCH)) {
            lExemptionHistoryList = (ArrayList<ExemptionHistory>) businessProgramService.getExemptionHistory(pExemptionHistorySearchForm.getGroupNumber(), BPMAdminUtils.convertStringToSqlDate(pExemptionHistorySearchForm.getEffectiveDate(), BPMAdminConstants.HP_BPM_ADMIN_UI_COMMON_DATE_FORMAT), pExemptionHistorySearchForm.getSiteNumber(), pExemptionHistorySearchForm.getExemptionType(), pExemptionHistorySearchForm.getContractNumber(), pExemptionHistorySearchForm.getMemberNumber(), BPMAdminUtils.convertStringToSqlDate(pExemptionHistorySearchForm.getExemptionFromDate(), BPMAdminConstants.HP_BPM_ADMIN_UI_COMMON_DATE_FORMAT), BPMAdminUtils.convertStringToSqlDate(pExemptionHistorySearchForm.getExemptionToDate(), BPMAdminConstants.HP_BPM_ADMIN_UI_COMMON_DATE_FORMAT));

            getUserSession().setExemptionHistoryList(lExemptionHistoryList);
            newDTOList = true;
        }

        //Pagination code begins here.
        setExemptionHistoryPagination(modelMap, getUserSession(), actionType, newDTOList);
        //Pagination code ends here.

        if (lExemptionHistoryList.size() <= 0) {
            createActionMessagesOnModel(modelMap, "messages.info", new Object[]{"No results found for the given search attribute(s)"});
        }

        getUserSession().setExemptionHistoryList(lExemptionHistoryList);

        getUserSession().setExemptionHistorySearchForm(pExemptionHistorySearchForm);
        if (getUserSession().getEmployerGroups() != null && getUserSession().getEmployerGroups().size() > 0) {
            modelMap.put("groupNameExists", BPMAdminConstants.BPM_ADMIN_TRUE);
        }
    }

    private void setExemptionHistoryPagination(ModelMap modelMap, UserSession sessionBean, String actionType, boolean newDTOList) {
        ArrayList<ExemptionHistory> lExemptionHistoryList = sessionBean.getExemptionHistoryList();
        /**
         * Create a Pageable wrapper for the array list.
         * Create a Pagination object and point it to the wrapper.
         */
        BPMPagination pagination = sessionBean.getPaginationMap().get(EXEMPTION_HISTORIES_LIST);
        PageableExemptionHistory lEHL = null;
        if (pagination == null || newDTOList) {
            lEHL = new PageableExemptionHistory(lExemptionHistoryList);
            lEHL.addRowNumber();
            pagination = new BPMPagination(lEHL, new ArrayList<Object>(lExemptionHistoryList));
            sessionBean.getPaginationMap().put(EXEMPTION_HISTORIES_LIST, pagination);
        }

        ArrayList<ExemptionHistory> lExemptionHistoryPerPage = (ArrayList<ExemptionHistory>) determineNextOrBackAction(actionType, pagination);
        setAttributesForPaginationOnModel(modelMap, lExemptionHistoryList.size(), pagination);

        modelMap.put("exemptionHistories", lExemptionHistoryPerPage);
        sessionBean.setExemptionHistoryPersPage(lExemptionHistoryPerPage);
    }

    private void handlePaginationActions(ExemptionHistorySearchForm form, ModelMap modelMap) {
        ArrayList<ExemptionHistory> lExemptionHistoryList = getUserSession().getExemptionHistoryList();
        /**
         * Page through Exempt History list.
         */
        if (EXEMPTION_HISTORIES_LIST.equals(form.getWhichList())) {
            getUserSession().setExemptionHistoryList(lExemptionHistoryList);
            setExemptionHistoryPagination(modelMap, getUserSession(), form.getActionType(), false);
        }
        /**
         * Page through the Employer Groups list.
         */
        if (EMPLOYER_GROUPS_LIST.equals(form.getWhichList())) {
            ArrayList<EmployerGroup> lEmployerGroups = getUserSession().getEmployerGroups();
            setEmployerGroupPaginationOnModel(modelMap, getUserSession(), form.getActionType(), false);
            getUserSession().setEmployerGroups(lEmployerGroups);
            getUserSession().setGroupName(form.getGroupName());
            form.setGroupName(getUserSession().getGroupName());
        }

        getUserSession().setExemptionHistorySearchForm(form);
        getUserSession().setGroupNo(form.getGroupNumber());

        if (getUserSession().getEmployerGroups() != null && getUserSession().getEmployerGroups().size() > 0
                && EXEMPTION_HISTORIES_LIST.equals(form.getWhichList())) {
            modelMap.put("groupNameExists", BPMAdminConstants.BPM_ADMIN_TRUE);
        }
    }

    private void backToGroupList(ModelMap modelMap, ExemptionHistorySearchForm form) throws Exception {
        ArrayList<EmployerGroup> lEmployerGroups = getUserSession().getEmployerGroups();
        ArrayList<EmployerGroup> lEmployerGroupsPerPage = getUserSession().getEmployerGroupsPerPage();
        modelMap.put("employerGroups", lEmployerGroupsPerPage);
        BPMPagination pagination = getUserSession().getPaginationMap().get(EMPLOYER_GROUPS_LIST);
        setAttributesForPaginationOnModel(modelMap, lEmployerGroups.size(), pagination);
        modelMap.put("groupNameExists", BPMAdminConstants.BPM_ADMIN_FALSE);
        modelMap.put("whichList", EMPLOYER_GROUPS_LIST);
        getUserSession().setExemptionHistorySearchForm(form);
    }

    private void handleDownload(ExemptionHistorySearchForm form, HttpServletRequest request, ModelMap modelMap, HttpServletResponse response) throws IOException {
        if (EXEMPTION_HISTORIES_LIST.equals(form.getWhichList())) {
            if (!CollectionUtils.isEmpty(getUserSession().getExemptionHistoryList())) {
                ArrayList<ExemptionHistory> lExemptionHistoryList = getUserSession().getExemptionHistoryList();
                response.setHeader("Content-Type", "text/csv");
                response.setHeader("Content-Disposition", "attachment;filename=\"report.csv\"");
                writeExemptionHistoryCsv(lExemptionHistoryList, response.getOutputStream());
            } else {
                String message = getMessage("errors.download", null);
                List<String> messages = new ArrayList<>();
                messages.add(message);
                request.setAttribute("messages", messages);
                modelMap.put("messages", messages);
            }
        }

        if (EMPLOYER_GROUPS_LIST.equals(form.getWhichList())) {
            if (!CollectionUtils.isEmpty(getUserSession().getEmployerGroups())) {
                ArrayList<EmployerGroup> lEmployerGroupList = getUserSession().getEmployerGroups();
                response.setHeader("Content-Type", "text/csv");
                response.setHeader("Content-Disposition", "attachment;filename=\"report.csv\"");
                writeEmployerGroupCsv(lEmployerGroupList, response.getOutputStream());
            } else {
                String message = getMessage("errors.download", null);
                List<String> messages = new ArrayList<>();
                messages.add(message);
                request.setAttribute("messages", messages);
                modelMap.put("messages", messages);
            }
        }
    }

    private void writeExemptionHistoryCsv (Collection<ExemptionHistory> csv, OutputStream output) throws IOException {
        ExemptionHistory lExemptionHistory = null;
        BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(output, "UTF-8"));

        formatExemptionHistoryHeaderNWrite(writer);

        Iterator<ExemptionHistory> iter = csv.iterator();
        while (iter.hasNext()) {
            lExemptionHistory = iter.next();
            formatExemptionHistoryDetailNWrite(writer, lExemptionHistory);
        }

        closeFileWriter(writer);
    }

    private void writeEmployerGroupCsv (Collection<EmployerGroup> csv, OutputStream output) throws IOException {
        EmployerGroup lEmployerGroup = null;
        BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(output, "UTF-8"));

        formatEmployerGroupHeaderNWrite(writer);

        Iterator<EmployerGroup> iter = csv.iterator();
        while (iter.hasNext()) {
            lEmployerGroup = iter.next();
            formatEmployerGroupDetailNWrite(writer, lEmployerGroup);
        }

        closeFileWriter(writer);
    }

    private void closeFileWriter(BufferedWriter writer) {
        try {
            writer.flush();
            writer.close();
        } catch(IOException e)
        {
            e.printStackTrace();
        }
    }

    private void formatExemptionHistoryHeaderNWrite(BufferedWriter writer) throws IOException {
        writer.append("No");
        writer.append(delimiter);

        writer.append("Exemption Type");
        writer.append(delimiter);

        writer.append("Exemption Date");
        writer.append(delimiter);

        writer.append("Last Processing Date");
        writer.append(delimiter);

        writer.append("Approver");
        writer.append(delimiter);

        writer.append("Created By");
        writer.append(delimiter);

        writer.append("Created On");
        writer.append(delimiter);

        writer.append("Group No");
        writer.append(delimiter);

        writer.append("Group Name");
        writer.append(delimiter);

        writer.append("Site No");
        writer.append(delimiter);

        writer.append("Site Name");
        writer.append(delimiter);

        writer.append("Member ID");
        writer.append(delimiter);

        writer.append("Last Name");
        writer.append(delimiter);

        writer.append("First Name");
        writer.append(delimiter);

        writer.append("Middle Name");
        writer.append(delimiter);

        writer.append("Member Status");
        writer.append(delimiter);

        writer.append("Contract No");
        writer.append(delimiter);

        writer.append("Contract Status");
        writer.append(delimiter);

        writer.append("Qual Start Date");
        writer.append(delimiter);

        writer.append("Qual End Date");
        writer.append(delimiter);

        writer.append("Incentive Option");

        writer.newLine();
    }

    private void formatExemptionHistoryDetailNWrite(BufferedWriter writer, ExemptionHistory lExemptionHistory ) throws IOException {
        String notAvailableDesc = "NA";

        writer.append(Integer.toString(lExemptionHistory.getRowNumber()));
        writer.append(delimiter);

        writer.append(lExemptionHistory.getExemptionTypeCodeDesc());
        writer.append(delimiter);

        if (lExemptionHistory.getExemptionDate() != null) {
            writer.append(BPMAdminUtils.formatDateMMddyyyy(lExemptionHistory.getExemptionDate()));
            writer.append(delimiter);
        } else {
            writer.append(notAvailableDesc);
            writer.append(delimiter);
        }

        if (lExemptionHistory.getProcessingDate() != null) {
            writer.append(BPMAdminUtils.formatDateMMddyyyy(lExemptionHistory.getProcessingDate()));
            writer.append(delimiter);
        } else {
            writer.append(notAvailableDesc);
            writer.append(delimiter);
        }

        writer.append(lExemptionHistory.getApprover());
        writer.append(delimiter);

        writer.append(lExemptionHistory.getCreatedBy());
        writer.append(delimiter);

        writer.append(BPMAdminUtils.formatDateMMddyyyy(lExemptionHistory.getCreateDate()));
        writer.append(delimiter);

        writer.append(lExemptionHistory.getGroupNumber());
        writer.append(delimiter);

        writer.append(lExemptionHistory.getGroupName());
        writer.append(delimiter);

        writer.append(lExemptionHistory.getSiteNumber());
        writer.append(delimiter);

        writer.append(lExemptionHistory.getSiteName());
        writer.append(delimiter);

        writer.append(lExemptionHistory.getMemberID());
        writer.append(delimiter);

        writer.append(lExemptionHistory.getLastName());
        writer.append(delimiter);

        writer.append(lExemptionHistory.getFirstName());
        writer.append(delimiter);

        writer.append(lExemptionHistory.getMiddleName());
        writer.append(delimiter);

        writer.append(lExemptionHistory.getMemberStatus());
        writer.append(delimiter);

        writer.append(Integer.toString(lExemptionHistory.getContractNumber()));
        writer.append(delimiter);

        writer.append(lExemptionHistory.getContractStatus());
        writer.append(delimiter);

        writer.append(BPMAdminUtils.formatDateMMddyyyy(lExemptionHistory.getQualificationStartDate()));
        writer.append(delimiter);

        writer.append(BPMAdminUtils.formatDateMMddyyyy(lExemptionHistory.getQualificationEndDate()));
        writer.append(delimiter);

        writer.append(lExemptionHistory.getIncentiveOptionName());

        writer.newLine();
    }

    private void formatEmployerGroupHeaderNWrite(BufferedWriter writer) throws IOException {
        writer.append("No");
        writer.append(delimiter);

        writer.append("Group No");
        writer.append(delimiter);

        writer.append("Group Name");
        writer.append(delimiter);

        writer.append("Has Program Year");

        writer.newLine();
    }

    private void formatEmployerGroupDetailNWrite(BufferedWriter writer, EmployerGroup lEmployerGroup ) throws IOException {
        writer.append(Integer.toString(lEmployerGroup.getRowNumber()));
        writer.append(delimiter);

        writer.append(lEmployerGroup.getGroupNumber());
        writer.append(delimiter);

        writer.append(lEmployerGroup.getGroupName());
        writer.append(delimiter);

        if (lEmployerGroup.getHasProgram() != null) {
            writer.append(lEmployerGroup.getHasProgram());
        } else {
            writer.append("N");
        }

        writer.newLine();
    }

    @Override
    public boolean supports(Class<?> clazz) {
        return ExemptionHistorySearchForm.class.isAssignableFrom(clazz);
    }

    @Override
    public void validate(Object target, Errors errors) {
        ExemptionHistorySearchForm form = (ExemptionHistorySearchForm) target;
        getValidationSupport().validateRequiredFieldIsNotEmpty("effectiveDate", form.getEffectiveDate(), errors, new Object[]{"Program Year Effective Date"});
        getValidationSupport().validateRequiredFieldIsNotEmpty("exemptionType", form.getExemptionType(), errors, new Object[]{"Exemption Type"});
        getValidationSupport().validateDateFormat("effectiveDate", form.getEffectiveDate(), errors, new Object[]{"Program Year Effective Date"});
        getValidationSupport().validateDateFormat("exemptionFromDate", form.getExemptionFromDate(), errors, new Object[]{"Exemption From Date"});
        getValidationSupport().validateDateFormat("exemptionToDate", form.getExemptionToDate(), errors, new Object[]{"Exemption To Date"});
        getValidationSupport().validateNotSpecialChar("groupNumber", form.getGroupNumber(), errors, new Object[]{"Group No"});
        getValidationSupport().validateNotSpecialChar("groupName", form.getGroupName(), errors, new Object[]{"Group Name"});
    }
}
