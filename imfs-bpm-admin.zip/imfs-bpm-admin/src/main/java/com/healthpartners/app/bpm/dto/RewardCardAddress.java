package com.healthpartners.app.bpm.dto;


public class RewardCardAddress {

    private Integer rewardCardAddressID;
    private Integer rewardTransHistID;
    private String firstName;
    private String middleInit;
    private String lastName;
    private String addressLine1;
    private String addressLine2;
    private String city;
    private String stateCode;
    private String postalCode;
    private String postalCodeExt;
    private String countryCode;
    private Integer addressStatusTypeId;
    private java.sql.Date addressStatusDate;
    private Integer programID;
    private Integer personDemographicsID;
    private Integer incentiveOptionID;


    public RewardCardAddress() {
        super();
    }

    public Integer getRewardCardAddressID() {
        return rewardCardAddressID;
    }

    public void setRewardCardAddressID(Integer rewardCardAddressID) {
        this.rewardCardAddressID = rewardCardAddressID;
    }

    public Integer getRewardTransHistID() {
        return rewardTransHistID;
    }

    public void setRewardTransHistID(Integer rewardTransHistID) {
        this.rewardTransHistID = rewardTransHistID;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getMiddleInit() {
        return middleInit;
    }

    public void setMiddleInit(String middleInit) {
        this.middleInit = middleInit;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getAddressLine1() {
        return addressLine1;
    }

    public void setAddressLine1(String addressLine1) {
        this.addressLine1 = addressLine1;
    }

    public String getAddressLine2() {
        return addressLine2;
    }

    public void setAddressLine2(String addressLine2) {
        this.addressLine2 = addressLine2;
    }

    public String getCity() {
        return city;
    }


    public void setCity(String city) {
        this.city = city;
    }


    public String getStateCode() {
        return stateCode;
    }

    public void setStateCode(String stateCode) {
        this.stateCode = stateCode;
    }

    public String getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    public String getPostalCodeExt() {
        return postalCodeExt;
    }

    public void setPostalCodeExt(String postalCodeExt) {
        this.postalCodeExt = postalCodeExt;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public Integer getAddressStatusTypeId() {
        return addressStatusTypeId;
    }

    public void setAddressStatusTypeId(Integer addressStatusTypeId) {
        this.addressStatusTypeId = addressStatusTypeId;
    }

    public java.sql.Date getAddressStatusDate() {
        return addressStatusDate;
    }

    public void setAddressStatusDate(java.sql.Date addressStatusDate) {
        this.addressStatusDate = addressStatusDate;
    }

    public Integer getProgramID() {
        return programID;
    }

    public void setProgramID(Integer programID) {
        this.programID = programID;
    }

    public Integer getPersonDemographicsID() {
        return personDemographicsID;
    }

    public void setPersonDemographicsID(Integer personDemographicsID) {
        this.personDemographicsID = personDemographicsID;
    }

    public Integer getIncentiveOptionID() {
        return incentiveOptionID;
    }

    public void setIncentiveOptionID(Integer incentiveOptionID) {
        this.incentiveOptionID = incentiveOptionID;
    }


}
