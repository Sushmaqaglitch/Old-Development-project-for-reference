/**
 *
 */
package com.healthpartners.app.bpm.iface;

import com.healthpartners.app.bpm.dto.*;
import com.healthpartners.app.bpm.exception.BPMException;
import org.springframework.dao.DataAccessException;

import java.sql.Date;
import java.util.Collection;


/**
 * Provides a common interface for reward card data.
 *
 * @author tjquist
 */
public interface RewardCardService {
    ProgramIncentiveOption getProgramIncentiveOptionSupportingRewardCardAttributes(ProgramIncentiveOption lProgramIncentiveOption) throws DataAccessException;

    int updateProgramRewardControllerForBatchProcessing(Integer programID, Integer incentiveOptionID, Integer rewardCardID, Integer runFreqID, Date programEffDate, String systemID) throws BPMException, DataAccessException;

    Collection<IncentiveOptionRewardCard> getIncentiveOptionRewardCardTypes() throws DataAccessException;

    Collection<RewardCard> getRewardCardTypes() throws DataAccessException;

    Collection<RewardCardFulfillmentTrackingReportHist> getRewardCardFulfillmentTrackingReportHistSearch(RewardCardFulfillmentSearchTO lRewardCardFulfillmentSearchTO) throws DataAccessException;

    Collection<RewardCardClientData> getRewardCardClientInfo() throws DataAccessException;

    Collection<RewardTransactionMessage> getRewardCardTransMsgTypes() throws DataAccessException;
    Collection<RewardCarrierMessage> getRewardCardCarrierMessageTypes() throws DataAccessException;
    Collection<RewardEmbossedLine> getRewardCardEmbossedLineTypes() throws DataAccessException;
    Collection<RewardCardFee> getRewardCardFeeTypes() throws DataAccessException;

    public RewardCardFulfillmentTrackingReportHist getRewardCardFulfillmentTrackingReportHistDetail(Integer rewardFulfillHistID, String externalTransID)
            throws DataAccessException;
    int updateIncentiveOptionRewardCard(IncentiveOptionRewardCard pIncentiveOptionRewardCard, String pModifyUserID)
            throws BPMException, DataAccessException;
    int deleteIncentiveOptionRewardCard(Integer lIncentiveOptionRewardCardID)
            throws BPMException, DataAccessException;
}
