package com.healthpartners.app.bpm.form;

import com.healthpartners.app.bpm.dto.LookUpValueCode;

import java.util.ArrayList;


/**
 * @author tjquist
 */
public class SavePersonCDHPFulfillRecycleForm extends BaseForm {

    static final long serialVersionUID = 0L;

    private String actionType;

    private String recycleId;

    private String recycleStatusDate;

    private String recycleStatusId;
    private String recycleStatusIdCurrent;

    private ArrayList<LookUpValueCode> recycleStatusCodes;

    private String reason;
    private String approver;


    public SavePersonCDHPFulfillRecycleForm() {
        super();
    }


//	public ActionMessages validateRecycle(ActionMapping mapping,
//			HttpServletRequest request)
//	{
//
//
//
//		validateNotNull("Reason", reason);
//		validateNotNull("Approver", approver);
//
//		validateEmptyString("Reason", reason);
//		validateEmptyString("Approver", approver);
//
//		if (recycleStatusId == null || recycleStatusId.isEmpty() || recycleStatusId.length() == 0) {
//			recycleStatusId = recycleStatusIdCurrent;
//		}
//		validateNotNull("recycleStatusId", recycleStatusId, "Recycle Status Id");
//
//		Iterator<LookUpValueCode> iter = (Iterator<LookUpValueCode>)recycleStatusCodes.iterator();
//		while (iter.hasNext()) {
//			LookUpValueCode lookupValueCode = iter.next();
//			if (lookupValueCode.getLuvVal().equals(BPMAdminConstants.BPM_LUV_RECYCLE_STATUS_RELEASED)) {
//				if (lookupValueCode.getLuvId().equals(Integer.valueOf(recycleStatusId))) {
//					recycleReleaseNotAllowedError("Release", "Recycle Status Release");
//				}
//			}
//
//		}
//		return getActionMessages();
//	}


    public String getRecycleStatusDate() {
        return recycleStatusDate;
    }


    public void setRecycleStatusDate(String recycleStatusDate) {
        this.recycleStatusDate = recycleStatusDate;
    }


    public String getReason() {
        return reason;
    }


    public void setReason(String reason) {
        this.reason = reason;
    }


    public String getApprover() {
        return approver;
    }


    public void setApprover(String approver) {
        this.approver = approver;
    }


    public String getRecycleStatusId() {
        return recycleStatusId;
    }


    public void setRecycleStatusId(String recycleStatusId) {
        this.recycleStatusId = recycleStatusId;
    }


    public String getActionType() {
        return actionType;
    }


    public void setActionType(String actionType) {
        this.actionType = actionType;
    }


    public String getRecycleId() {
        return recycleId;
    }


    public void setRecycleId(String recycleId) {
        this.recycleId = recycleId;
    }


    public String getRecycleStatusIdCurrent() {
        return recycleStatusIdCurrent;
    }


    public void setRecycleStatusIdCurrent(String recycleStatusIdCurrent) {
        this.recycleStatusIdCurrent = recycleStatusIdCurrent;
    }


    public ArrayList<LookUpValueCode> getRecycleStatusCodes() {
        return recycleStatusCodes;
    }


    public void setRecycleStatusCodes(ArrayList<LookUpValueCode> recycleStatusCodes) {
        this.recycleStatusCodes = recycleStatusCodes;
    }

}
