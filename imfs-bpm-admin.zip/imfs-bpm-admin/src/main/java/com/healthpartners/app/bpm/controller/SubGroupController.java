package com.healthpartners.app.bpm.controller;

import com.healthpartners.app.bpm.dto.EmployerGroup;
import com.healthpartners.app.bpm.dto.ProgramType;
import com.healthpartners.app.bpm.exception.BPMException;
import com.healthpartners.app.bpm.form.CreateProgramForm;
import com.healthpartners.app.bpm.form.SubGroupSearchForm;
import com.healthpartners.app.bpm.iface.BusinessProgramService;
import org.springframework.stereotype.Controller;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.ArrayList;
import java.util.Map;

@Controller
public class SubGroupController extends BaseController implements Validator {

    private final BusinessProgramService businessProgramService;

    public SubGroupController(BusinessProgramService businessProgramService) {
        this.businessProgramService = businessProgramService;
    }

    @GetMapping("/subGroupSearch")
    public String loadShowGroupLookup(Map<String, Object> model, @RequestParam(name = "groupID") Integer groupID) throws BPMException {
        CreateProgramForm form = new CreateProgramForm();
        ArrayList<EmployerGroup> lEmployerSubGroups = (ArrayList<EmployerGroup>) businessProgramService.getSubGroups(groupID);
        ArrayList<ProgramType> lProgramTypes = (ArrayList<ProgramType>) businessProgramService.getProgramTypes();
        String lGroupNo = null;
        String lGroupName = null;
        if(lEmployerSubGroups != null && lEmployerSubGroups.size() > 0) {
            EmployerGroup lEmployerGroup = lEmployerSubGroups.get(0);
            lGroupNo = lEmployerGroup.getGroupNumber();
            lGroupName = lEmployerGroup.getGroupName();
        }
        form.setGroupID(groupID);
        form.setGroupNo(lGroupNo);
        form.setGroupName(lGroupName);
        form.setEmployerSubGroups(lEmployerSubGroups);
        form.setProgramTypes(lProgramTypes);
        model.put("createProgramForm", form);
        if(getUserSession().getProgramTypes() != null) {
            getUserSession().getProgramTypes().clear();
        }
        if(getUserSession().getEmployerSubGroups() != null) {
            getUserSession().getEmployerSubGroups().clear();
        }
        if(getUserSession().getAvailableSites() != null) {
            getUserSession().getAvailableSites().clear();
        }
        getUserSession().setProgramTypes(lProgramTypes);
        getUserSession().setEmployerSubGroups(lEmployerSubGroups);
        getUserSession().setAvailableSites(lEmployerSubGroups);

        return "showSubGroups";
    }

    @Override
    public boolean supports(Class<?> clazz) {
        return SubGroupSearchForm.class.isAssignableFrom(clazz);
    }

    @Override
    public void validate(Object target, Errors errors) {
        SubGroupSearchForm form = (SubGroupSearchForm) target;
        getValidationSupport().validateRequiredFieldIsNotEmpty("groupID", form.getGroupID(), errors, new Object[]{"Group Number"});
    }
}
