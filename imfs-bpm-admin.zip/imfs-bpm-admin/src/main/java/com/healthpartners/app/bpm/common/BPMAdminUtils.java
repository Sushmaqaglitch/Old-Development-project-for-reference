package com.healthpartners.app.bpm.common;

import com.healthpartners.app.bpm.dto.BusinessProgram;
import com.healthpartners.app.bpm.dto.EligibleActivity;
import com.healthpartners.app.bpm.dto.ProgramCheckmark;
import com.healthpartners.app.bpm.dto.QualificationCheckmark;
import com.healthpartners.app.bpm.session.UserSession;

import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class BPMAdminUtils {

    static SimpleDateFormat MMddyyyyFormat = new SimpleDateFormat("MM/dd/yyyy");
    static SimpleDateFormat MMddyyyyFormatNoDel = new SimpleDateFormat("MMddyyyy");

    /*
     * Converting Double to a formatted string will allow the 0 as the last digit
     * past the decimal point be retained.  A decimal of type Double will drop the zero
     * and is inaccurately displayed.
     */
    public static String convertDoubleToDecimalFormattedString(Double value) {
        DecimalFormat valueFormat = new DecimalFormat("#,##0.00;(#)");
        String valueStr = valueFormat.format(value);

        return valueStr;
    }

    public static String formatDateMMddyyyy(Date inputDate) {
        return MMddyyyyFormat.format(inputDate.getTime());
    }

    public static String formatDateMMddyyyy(Calendar inputDate) {
        return MMddyyyyFormat.format(inputDate.getTime());
    }

    public static java.sql.Date getSqlDateFromString(String dateString) {
        java.sql.Date sqlDate;
        try {
            SimpleDateFormat fmt = new SimpleDateFormat(
                    BPMAdminConstants.HP_BPM_ADMIN_UI_COMMON_DATE_FORMAT);
            java.util.Date utilDate = fmt.parse(dateString.trim());
            sqlDate = new java.sql.Date(utilDate.getTime());
        } catch (Exception e) {
            sqlDate = null;
        }

        return sqlDate;
    }

    public static boolean isDateValid(String pInputDate) {
        String lDelimiter = "/";
        String[] lDateFields = pInputDate.split(lDelimiter);
        //fields[0]   // month
        //fields[1]   // day
        //fields[2]   // year

        if (Integer.parseInt(lDateFields[0]) > 12) {
            return false;
        }
        // Construct a date with the year and the month.
        // Months start at 0, so subtract 1 from the month number extracted from the input string.
        Calendar cal = new GregorianCalendar(Integer.parseInt(lDateFields[2]), Integer.parseInt(lDateFields[0]) - 1, 1);

        // Get the number of days in that month.
        int days = cal.getActualMaximum(Calendar.DAY_OF_MONTH); // 28

        if (Integer.parseInt(lDateFields[1]) > days) {
            return false;
        }

        return true;
    }

    public static java.sql.Date convertStringToSqlDate(String dateStr, String dateFormat) {
        java.sql.Date sqlDate = null;
        if (dateStr != null && !dateStr.trim().equals("")) {
            try {
                SimpleDateFormat formater = new SimpleDateFormat(dateFormat);
                java.util.Date parsedDate = formater.parse(dateStr);
                sqlDate = new java.sql.Date(parsedDate.getTime());
            } catch (Exception e) {
                sqlDate = null;
            }
        }
        return sqlDate;
    }

    public static Calendar convertDateStrToCalendar(String str_date) throws Exception {
        Calendar calDate = Calendar.getInstance();
        try {
            DateFormat formatter;
            Date date;
            formatter = new SimpleDateFormat("MM/dd/yyyy");
            date = (Date) formatter.parse(str_date);
            calDate.setTime(date);
        } catch (ParseException e) {
            System.out.println("Exception :" + e);
        }

        return calDate;
    }

    /**
     * Generate a default value for New Hire Date based on the Program Effective Date, and the Program Type.
     * @return
     */
    public static java.sql.Date generateDefaultEndDate() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy MMM dd");
        Calendar defaultEndDate = new GregorianCalendar(9999, 0, 1);

        return new java.sql.Date(defaultEndDate.getTimeInMillis());
    }

    /**
     * Calculates the number of days between two calendar days in a manner which
     * is independent of the Calendar type used.
     *
     * @param d1
     *            The first date.
     * @param d2
     *            The second date.
     *
     * @return The number of days between the two dates. the value returned is =
     *         0 if d1 euals d2 the value returned is > 0 if d1 after d2 the
     *         value returned is < 0 if d1 before d2 If Calendar types of d1 and
     *         d2 are different, the result may not be accurate.
     */
    public static int getDaysBetweenDates(java.util.Calendar d1,
                                          java.util.Calendar d2) {
        boolean isD1afterD2 = false;
        if (d1.after(d2)) { // swap dates so that d1 is start and d2 is end
            java.util.Calendar swap = d1;
            d1 = d2;
            d2 = swap;
            isD1afterD2 = true;
        }
        int days = d2.get(java.util.Calendar.DAY_OF_YEAR)
                - d1.get(java.util.Calendar.DAY_OF_YEAR);
        int y2 = d2.get(java.util.Calendar.YEAR);
        if (d1.get(java.util.Calendar.YEAR) != y2) {
            d1 = (java.util.Calendar) d1.clone();
            do {
                days += d1.getActualMaximum(java.util.Calendar.DAY_OF_YEAR);
                d1.add(java.util.Calendar.YEAR, 1);
            } while (d1.get(java.util.Calendar.YEAR) != y2);
        }

        // if d1 < d2 send negative value
        if (!isD1afterD2) {
            days = -days;
        }
        if (days < 0) {
            days = -days;
        }
        return days;
    } // getDaysBetween()

    /**
     * Generate a default value for Qualification End Date based on the Effective Date, and the Program Type.
     * @param lProgramEffectiveDate
     * @param pBusinessProgram
     * @return
     */
    public static java.sql.Date generateDefaultQualificationEndDate(Calendar lProgramEffectiveDate, BusinessProgram pBusinessProgram) {
        // Default the Smart Steps Qualification End Date to be the same as the Program End Date.
        if (BPMAdminConstants.BPM_ADMIN_PROGRAM_TYPE_CODE_SMART_STEPS.equals(pBusinessProgram.getProgramTypeCodeID())) {
            return generateDefaultProgramEndDate(lProgramEffectiveDate);
        }
        Calendar lQualificationEndDate = (Calendar) lProgramEffectiveDate.clone();
        lQualificationEndDate.add(Calendar.MONTH, BPMAdminConstants.BPM_ADMIN_DEFAULT_QUAL_END_MONTH);
        lQualificationEndDate.set(Calendar.DAY_OF_MONTH, lQualificationEndDate.getActualMaximum(GregorianCalendar.DAY_OF_MONTH));
        return new java.sql.Date(lQualificationEndDate.getTimeInMillis());
    }

    public static java.sql.Date generateDefaultProgramEndDate(Calendar lProgramEffectiveDate) {
        Calendar lProgramEndDate = (Calendar) lProgramEffectiveDate.clone();
        lProgramEndDate.add(Calendar.MONTH, BPMAdminConstants.BPM_ADMIN_DEFAULT_GROUP_END_MONTH);
        lProgramEndDate.set(Calendar.DAY_OF_MONTH, lProgramEndDate.getActualMaximum(GregorianCalendar.DAY_OF_MONTH));
        return new java.sql.Date(lProgramEndDate.getTimeInMillis());
    }

    /**
     * Generate a default value for the status calculation end date.
     *
     * @param lProgramEndDate
     * @param pBusinessProgram
     * @return
     */
    public static java.sql.Date generateDefaultStatusCalcEndDate(Calendar lProgramEndDate, BusinessProgram pBusinessProgram) {
        // Set the default status calculation end date to be 6 months after the end date.
        Calendar lStatusCalcEndDate = (Calendar) lProgramEndDate.clone();
        lStatusCalcEndDate.add(Calendar.MONTH, BPMAdminConstants.BPM_ADMIN_DEFAULT_STATUS_CALC_END_MONTH);
        lStatusCalcEndDate.set(Calendar.DAY_OF_MONTH, lStatusCalcEndDate.getActualMaximum(GregorianCalendar.DAY_OF_MONTH));
        return new java.sql.Date(lStatusCalcEndDate.getTimeInMillis());
    }

    /**
     * Generate a default value for New Hire Date based on the Program Effective Date, and the Program Type.
     *
     * @param lProgramEffectiveDate
     * @param pBusinessProgram
     * @return
     */
    public static java.sql.Date generateDefaultNewHireDate(Calendar lProgramEffectiveDate, BusinessProgram pBusinessProgram) {
        Calendar lNewHireDate = (Calendar) lProgramEffectiveDate.clone();

        if (BPMAdminConstants.BPM_ADMIN_PROGRAM_TYPE_CODE_SMART_STEPS.equals(pBusinessProgram.getProgramTypeCodeID())) {
            lNewHireDate.set(Calendar.MONTH, 0);
            lNewHireDate.set(Calendar.DAY_OF_MONTH, 1);
            lNewHireDate.set(Calendar.YEAR, 9999);
        } else if (BPMAdminConstants.BPM_ADMIN_PROGRAM_TYPE_CODE_HEALTY_BENEFITS.equals(pBusinessProgram.getProgramTypeCodeID()) ||
                BPMAdminConstants.BPM_ADMIN_PROGRAM_TYPE_CODE_JOURNEYWELL.equals(pBusinessProgram.getProgramTypeCodeID()) ||
                BPMAdminConstants.BPM_ADMIN_PROGRAM_TYPE_CODE_JOURNEYWELL4.equals(pBusinessProgram.getProgramTypeCodeID()) ||
                BPMAdminConstants.BPM_ADMIN_PROGRAM_TYPE_CODE_OTHERWELLNESS.equals(pBusinessProgram.getProgramTypeCodeID()) ||
                BPMAdminConstants.BPM_ADMIN_PROGRAM_TYPE_CODE_NEWJOURNEYWELL.equals(pBusinessProgram.getProgramTypeCodeID())) {
            lNewHireDate.add(Calendar.MONTH, BPMAdminConstants.BPM_ADMIN_DEFAULT_GROUP_HIRE_MONTH);
        }

        return new java.sql.Date(lNewHireDate.getTimeInMillis());
    }

    /**
     * Generate a default value for Program Effective Date based on the user-entered Effective Date, and the Program Type.
     *
     * @param lProgramEffectiveDate
     * @param pBusinessProgram
     * @return
     */
    public static java.sql.Date generateDefaultProgramEffectiveDate(Calendar lProgramEffectiveDate, BusinessProgram pBusinessProgram) {
        if (BPMAdminConstants.BPM_ADMIN_PROGRAM_TYPE_CODE_SMART_STEPS.equals(pBusinessProgram.getProgramTypeCodeID())) {
            // For Smart Steps always set the Effective Date to Jan 1st of the current year.
            lProgramEffectiveDate.set(Calendar.MONTH, 0);
            lProgramEffectiveDate.set(Calendar.DAY_OF_MONTH, 1);
        } else if (BPMAdminConstants.BPM_ADMIN_PROGRAM_TYPE_CODE_HEALTY_BENEFITS.equals(pBusinessProgram.getProgramTypeCodeID())) {
            // No special logic for Effective Date
        }

        return new java.sql.Date(lProgramEffectiveDate.getTimeInMillis());
    }

    public static java.util.Date convertStringToDate(String date) throws ParseException {
        SimpleDateFormat fmt = new SimpleDateFormat(BPMAdminConstants.HP_BPM_ADMIN_UI_COMMON_DATE_FORMAT);
        return fmt.parse(date.trim());
    }

    public static java.util.Date getUtilDateFromSqlDate(java.sql.Date sqlDate) {
        java.util.Date utilDate = new java.util.Date(sqlDate.getTime());
        return utilDate;
    }

    public static void populateProgramCheckmarkDefinition(UserSession sessionBean) {
        ArrayList<ProgramCheckmark> lProgramCheckmarks = sessionBean.getProgramCheckmarks();


        ArrayList<Integer> lDistinctQualificationCheckmkarkIDs = new ArrayList<Integer>();
        ArrayList<QualificationCheckmark> lThisBizProgramQualificationCheckmarks = new ArrayList<QualificationCheckmark>();
        for (ProgramCheckmark lProgramCheckmark : lProgramCheckmarks) {
            if (lDistinctQualificationCheckmkarkIDs.contains(lProgramCheckmark.getQualificationCheckmarkID()) == false) {
                lDistinctQualificationCheckmkarkIDs.add(lProgramCheckmark.getQualificationCheckmarkID());

                QualificationCheckmark lQualificationCheckmark = new QualificationCheckmark();
                lQualificationCheckmark.setQualificationCheckmarkName(lProgramCheckmark.getQualificationCheckmarkName());
                lQualificationCheckmark.setCheckmarkRequirements(lProgramCheckmark.getCheckmarkRequirements());
                lThisBizProgramQualificationCheckmarks.add(lQualificationCheckmark);
            }
        }
        sessionBean.setQualificationCheckmarks(lThisBizProgramQualificationCheckmarks);
    }

    /**
     * Generate default Auth and Promo Codes for Health Assessment and other activities.
     *
     * @param pBusinessProgram
     * @param pEligibleActivities
     * @param pEligibleActivity
     */
    public static void generateAuthCode(BusinessProgram pBusinessProgram, ArrayList<EligibleActivity> pEligibleActivities, EligibleActivity pEligibleActivity) {
        if (BPMAdminConstants.BPM_ADMIN_PROGRAM_TYPE_CODE_HEALTY_BENEFITS.equals(pBusinessProgram.getProgramTypeCodeID()) ||
                BPMAdminConstants.BPM_ADMIN_PROGRAM_TYPE_CODE_JOURNEYWELL.equals(pBusinessProgram.getProgramTypeCodeID())) {
            if (pEligibleActivities.size() > 0) {
                pEligibleActivity.setAuthorizationCode(pEligibleActivities.get(0).getAuthorizationCode());
            } else {
                pEligibleActivity.setAuthorizationCode("");
            }
        } else if (BPMAdminConstants.BPM_ADMIN_PROGRAM_TYPE_CODE_SMART_STEPS.equals(pBusinessProgram.getProgramTypeCodeID())) {
            if (BPMAdminConstants.BPM_ADMIN_ACTIVITY_TYPE_HA.equals(pEligibleActivity.getActivity().getActivityTypeValue())) {
                pEligibleActivity.setAuthorizationCode(generateProgramAuthPromoCode(pBusinessProgram, BPMAdminConstants.BPM_ADMIN_SS_HA_AUTH_CODE_PREFIX));
            } else {
                pEligibleActivity.setAuthorizationCode(generateProgramAuthPromoCode(pBusinessProgram, BPMAdminConstants.BPM_ADMIN_SS_PROMO_CODE_PREFIX));
            }
        } else {
            pEligibleActivity.setAuthorizationCode("");
        }

        return;
    }

    /**
     * Utility method that creates the Auth or Promo code based on the Business Program Qualification
     * Start Date, and the prefix. Currently used for Smart Steps Auth Promo Codes.
     * Example SSHA200901, or SSPR200901
     *
     * @param pBusinessProgram
     * @param pAuthCodePrefix
     * @return
     */
    public static String generateProgramAuthPromoCode(BusinessProgram pBusinessProgram, String pAuthCodePrefix) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy");
        String lDateFormat = dateFormat.format(pBusinessProgram.getEffectiveDate());

        return pAuthCodePrefix + lDateFormat;
    }

    /*
     * Pass in negative day(s) if desired result is for a date in the past.
     */
    public static Calendar getDateGivenDays(Calendar calDate, int days) {
        calDate.add(Calendar.DATE, days);
        return calDate;
    }

    public static java.sql.Date calendarToSqlDate(Calendar pCalendar) {
        return pCalendar != null ? new java.sql.Date(pCalendar.getTime().getTime()) : null;
    }

    /*
     * Determine if date 1 after date 2
     */
    public static boolean isAfterDate(java.sql.Date date1, java.sql.Date date2) {
        boolean afterDate = false;

        java.util.Date date1Sql = BPMAdminUtils.getUtilDateFromSqlDate(date1);
        java.util.Date date2Sql = BPMAdminUtils.getUtilDateFromSqlDate(date2);

        if (date1Sql.after(date2Sql)) {
            afterDate = true;
        }

        return afterDate;
    }

    /*
     * Determine if date 1 before date 2
     */
    public static boolean isBeforeDate(java.sql.Date date1, java.sql.Date date2) {
        boolean beforeDate = false;

        java.util.Date date1Sql = BPMAdminUtils.getUtilDateFromSqlDate(date1);
        java.util.Date date2Sql = BPMAdminUtils.getUtilDateFromSqlDate(date2);

        if (date1Sql.before(date2Sql)) {
            beforeDate = true;
        }

        return beforeDate;
    }

    public static Integer convertStringToInteger(String value) {
        Integer valueInteger;
        if (value != null) {
            valueInteger = Integer.valueOf(value);
        } else {
            return 0;
        }

        return valueInteger;
    }

    public static Calendar dateToCalendar(Date pDate) {
        if (pDate == null) {
            return null;
        }
        Calendar lCalendar = Calendar.getInstance();
        lCalendar.setTime(pDate);
        return lCalendar;
    }

    public static boolean isValueInteger(String fieldValue) {
        boolean result = true;

        try {
            Integer integerValue = Integer.valueOf(fieldValue.trim());
        } catch (NumberFormatException ne) {
            result = false;
        }

        return result;
    }


    public static String getStringDateFromSqlDate(java.sql.Date sqlDate) {
        String dateStr;

        try {
            SimpleDateFormat fmt = new SimpleDateFormat(
                    BPMAdminConstants.HP_BPM_ADMIN_UI_COMMON_DATE_FORMAT);
            dateStr = fmt.format(sqlDate);

        } catch (Exception e) {
            dateStr = null;
        }

        return dateStr;
    }

}
