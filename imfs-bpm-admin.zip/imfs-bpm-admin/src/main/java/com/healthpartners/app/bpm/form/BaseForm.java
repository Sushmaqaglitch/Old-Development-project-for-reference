package com.healthpartners.app.bpm.form;

public class BaseForm {
    static final String REQUIRED = " is required.";
    String actionType;

    public String getActionType() {
        return actionType;
    }

    public void setActionType(String actionType) {
        this.actionType = actionType;
    }

}
