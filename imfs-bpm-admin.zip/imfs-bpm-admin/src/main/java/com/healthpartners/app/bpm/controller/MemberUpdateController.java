package com.healthpartners.app.bpm.controller;

import com.healthpartners.app.bpm.common.BPMAdminConstants;
import com.healthpartners.app.bpm.common.BPMAdminUtils;
import com.healthpartners.app.bpm.dto.*;
import com.healthpartners.app.bpm.exception.BPMException;
import com.healthpartners.app.bpm.form.MemberUpdateForm;
import com.healthpartners.app.bpm.iface.BusinessProgramService;
import com.healthpartners.app.bpm.iface.MemberService;
import com.healthpartners.app.bpm.session.UserSession;
import com.healthpartners.service.bpm.common.BPMConstants;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;

/**
 * @author mxthoutam
 * 
 */
@Controller
public class MemberUpdateController extends BaseController {

	protected final Log logger = LogFactory.getLog(getClass());

	private UserSession userSession;

	private MemberService memberService;

	private BusinessProgramService businessProgramService;

	public MemberUpdateController(BusinessProgramService businessProgramService, MemberService memberService) {
		this.businessProgramService = businessProgramService;
		this.memberService = memberService;
	}

	@GetMapping("/memberUpdate")
	public String memberUpdate(ModelMap modelMap) throws BPMException {
		String resultPage = "memberUpdate";
		try {
			MemberUpdateForm thisForm = null;
			this.userSession = getUserSession();

			if (modelMap.isEmpty()) {
				thisForm = new MemberUpdateForm();
				modelMap.put("memberUpdateForm", thisForm);
			} else {
				modelMap.put("memberUpdateForm", thisForm);
			}

			Boolean lSuperUser = (Boolean) getUserSessionSupport().getSession().getAttribute(BPMAdminConstants.BPM_SUPER_USER);
			Boolean lGroupSetup = (Boolean) getUserSessionSupport().getSession().getAttribute(BPMAdminConstants.BPM_ADMIN_GROUP_VIEW_EDIT_ACCESS);
			modelMap.put("superUser", lSuperUser);
			modelMap.put("groupSetup", lGroupSetup);


			String operationType = thisForm.getActionType();

			String userId = getUserSessionSupport().getAuthenticatedUsername();

			userSession
					.setStartDates((ArrayList<String>) businessProgramService
							.getAllStartDates());
			modelMap.addAttribute("startDates", userSession.getStartDates());
			modelMap.addAttribute("businessPrograms", userSession.getBusinessPrograms());
			modelMap.addAttribute("memberDetail", userSession.getMemberDetail());


			if (operationType != null && ACTION_SEARCH.equals(operationType)) {
				return searchAndRefreshMemberDetails(thisForm, modelMap);
			} else if (operationType != null
					&& ACTION_UPDATE_MEMBERSHIP.equals(operationType)) {
				return updateMemberDetails(thisForm, modelMap,
						BPMAdminConstants.BPM_ADMIN_MEMBERSHIP_UPDATE_PRCS_ID, userId);
			} else if (operationType != null
					&& ACTION_UPDATE_STATUS_RECALC.equals(operationType)) {
				return updateMemberDetails(
						thisForm, modelMap,
						BPMAdminConstants.BPM_ADMIN_MEMBERS_RECALCULATION_PRCS_ID, userId);
			} else if (ACTION_UPDATE_GROUP_MEMBERSHIP.equals(operationType)) {
				for (int i = 0; i < userSession.getBusinessPrograms().size(); i++) {
					businessProgramService.updateAllGroupSiteMembers(BPMAdminConstants.BPM_ADMIN_MEMBERSHIP_UPDATE_PRCS_ID, userSession.getBusinessPrograms().get(i).getProgramID());
				}
				createActionMessagesOnModel(modelMap, "messages.markedForGroupUpdate", new Object[]{"Marked for group update."});
				return resultPage;
			} else if (ACTION_UPDATE_MEMBERSHIP_ONLY.equals(operationType)) {
				for (int i = 0; i < userSession.getBusinessPrograms().size(); i++) {
					businessProgramService.updateAllGroupSiteMembers(BPMAdminConstants.BPM_ADMIN_MEMBERSHIP_UPDATE_ONLY_PRCS_ID, userSession.getBusinessPrograms().get(i).getProgramID());
				}

				createActionMessagesOnModel(modelMap, "messages.markedForUpdateOnly", new Object[]{"Marked for update only."});
				return resultPage;
			} else if (ACTION_UPDATE_GROUP_STATUS_RECALC.equals(operationType)) {
				for (int i = 0; i < userSession.getBusinessPrograms().size(); i++) {
					businessProgramService.updateAllGroupSiteMembers(BPMAdminConstants.BPM_ADMIN_MEMBERS_RECALCULATION_PRCS_ID, userSession.getBusinessPrograms().get(i).getProgramID());
				}

				createActionMessagesOnModel(modelMap, "messages.markedForGroupRecalc", new Object[]{"Marked for group recalc."});
				return resultPage;
			} else if (ACTION_REMOVE.equals(operationType)) {
				Integer pProgramID = Integer.parseInt((String) modelMap.getAttribute("programID"));
				for (int i = 0; i < userSession.getBusinessPrograms().size(); i++) {
					if (userSession.getBusinessPrograms().get(i).getProgramID() == pProgramID.intValue()) {
						userSession.getBusinessPrograms().remove(i);
						break;
					}
				}

				modelMap.addAttribute("businessPrograms", userSession.getBusinessPrograms());
				return resultPage;
			} else if (ACTION_SAVE.equalsIgnoreCase(operationType)) {
				validateForMemberSearch(thisForm, modelMap);

				saveNewMemberStatus(modelMap, thisForm, userId);

				createActionMessagesOnModel(modelMap, "messages.saveDates", new Object[]{"Save dates."});
				return resultPage;

			} else {
				return resultPage;
			}
		} catch (Exception e) {
			logger.error("An unexpected error has occured: " + e.getMessage(),
					e);
			createActionMessagesOnModel(modelMap, "messages.saveDates", new Object[]{"Save dates."});
			return "memberUpdate";
		}
	}

	@PostMapping("/memberUpdate")
	public String memberUpdate(@ModelAttribute("memberUpdateForm") MemberUpdateForm thisForm, ModelMap modelMap) throws BPMException {
		String resultPage = "memberUpdate";

		try {

			this.userSession = getUserSession();

			String userId = getUserSessionSupport().getAuthenticatedUsername();

			modelMap.addAttribute("startDates", userSession.getStartDates());
			modelMap.addAttribute("businessPrograms", userSession.getBusinessPrograms());
			modelMap.addAttribute("memberDetail", userSession.getMemberDetail());

			String operationType = thisForm.getOperationType();

			if (operationType != null && ACTION_SEARCH.equals(operationType)) {
				return searchAndRefreshMemberDetails(thisForm, modelMap);
			} else if (operationType != null
					&& ACTION_UPDATE_MEMBERSHIP.equals(operationType)) {
				return updateMemberDetails(thisForm, modelMap,
						BPMAdminConstants.BPM_ADMIN_MEMBERSHIP_UPDATE_PRCS_ID, userId);
			} else if (operationType != null
					&& ACTION_UPDATE_STATUS_RECALC.equals(operationType)) {
				return updateMemberDetails(
						thisForm, modelMap,
						BPMAdminConstants.BPM_ADMIN_MEMBERS_RECALCULATION_PRCS_ID, userId);
			} else if (ACTION_UPDATE_GROUP_MEMBERSHIP.equals(operationType)) {
				for (int i = 0; i < userSession.getBusinessPrograms().size(); i++) {
					businessProgramService.updateAllGroupSiteMembers(BPMAdminConstants.BPM_ADMIN_MEMBERSHIP_UPDATE_PRCS_ID, userSession.getBusinessPrograms().get(i).getProgramID());
				}
				createActionMessagesOnModel(modelMap, "messages.markedForGroupUpdate", new Object[]{"Marked for group update."});
				return resultPage;
			} else if (ACTION_UPDATE_MEMBERSHIP_ONLY.equals(operationType)) {
				for (int i = 0; i < userSession.getBusinessPrograms().size(); i++) {
					businessProgramService.updateAllGroupSiteMembers(BPMAdminConstants.BPM_ADMIN_MEMBERSHIP_UPDATE_ONLY_PRCS_ID, userSession.getBusinessPrograms().get(i).getProgramID());
				}

				createActionMessagesOnModel(modelMap, "messages.markedForUpdateOnly", new Object[]{"Marked for update only."});
				return resultPage;
			} else if (ACTION_UPDATE_GROUP_STATUS_RECALC.equals(operationType)) {
				for (int i = 0; i < userSession.getBusinessPrograms().size(); i++) {
					businessProgramService.updateAllGroupSiteMembers(BPMAdminConstants.BPM_ADMIN_MEMBERS_RECALCULATION_PRCS_ID, userSession.getBusinessPrograms().get(i).getProgramID());
				}

				createActionMessagesOnModel(modelMap, "messages.markedForGroupRecalc", new Object[]{"Marked for group recalc."});
				return resultPage;
			} else if (ACTION_REMOVE.equals(operationType)) {
				Integer pProgramID = Integer.parseInt((String) modelMap.getAttribute("programID"));
				for (int i = 0; i < userSession.getBusinessPrograms().size(); i++) {
					if (userSession.getBusinessPrograms().get(i).getProgramID() == pProgramID.intValue()) {
						userSession.getBusinessPrograms().remove(i);
						break;
					}
				}

				modelMap.addAttribute("businessPrograms", userSession.getBusinessPrograms());
				return resultPage;
			} else if (ACTION_SAVE.equalsIgnoreCase(operationType)) {
				validateForMemberSearch(thisForm, modelMap);

				saveNewMemberStatus(modelMap, thisForm, userId);

				createActionMessagesOnModel(modelMap, "messages.saveDates", new Object[]{"Save dates."});
				return resultPage;

			} else {
				return resultPage;
			}
		} catch (Exception e) {
			logger.error("An unexpected error has occured: " + e.getMessage(),
					e);
			createActionMessagesOnModel(modelMap, "messages.saveDates", new Object[]{"Save dates."});
			return resultPage;
		}

	}

	@GetMapping("/removeProgram")
	public String removeProgram(@ModelAttribute("programID") Integer programId, @ModelAttribute("memberUpdateForm") MemberUpdateForm thisForm, ModelMap modelMap) throws BPMException {
		String resultPage = "memberUpdate";

		try {

			this.userSession = getUserSession();

			for (int i = 0; i < userSession.getBusinessPrograms().size(); i++) {
				if (userSession.getBusinessPrograms().get(i).getProgramID() == programId.intValue()) {
					userSession.getBusinessPrograms().remove(i);
					break;
				}
			}

			modelMap.addAttribute("businessPrograms", userSession.getBusinessPrograms());
			modelMap.addAttribute("startDates", userSession.getStartDates());
			modelMap.addAttribute("memberUpdateForm", thisForm);
			modelMap.addAttribute("memberDetail", userSession.getMemberDetail());

			return resultPage;

		} catch (Exception e) {
			logger.error("An unexpected error has occured: " + e.getMessage(),
					e);
			createActionMessagesOnModel(modelMap, "messages.saveDates", new Object[]{"Save dates."});
			return resultPage;
		}

	}

	private String searchAndRefreshMemberDetails(MemberUpdateForm form, ModelMap modelMap) throws BPMException, DataAccessException {
		String resultPage = "memberUpdate";
		validateForMemberSearch(form, modelMap);
		refreshSearchResults(modelMap, form);

		return resultPage;
	}

	private String updateMemberDetails(MemberUpdateForm form, ModelMap modelMap, int pProcessID, String userId) throws Exception {
		try {

			Integer personDemographicsID = convertStringToInteger(form.getPersonDemographicsID());
			Integer processId = pProcessID;

			memberService.insertPersonProcessingStatus(personDemographicsID, processId,
					BPMConstants.PROCESSING_STATUS_PENDING, userId);

			createActionMessagesOnModel(modelMap, "messages.markedForMembershipUpdate", new Object[]{"Marked for membership update."});

			refreshSearchResults(modelMap, form);

			// Clear the memberID field.
			form.setMemberID("");
			return ("memberUpdate");

		} catch (Exception e) {
			logger.error("An unexpected error has occured: " + e.getMessage(),
					e);
			createErrorMessageOnModel(modelMap, getStackTrace(e));
			return ("memberUpdate");
		}
	}

	/**
	 * @param modelMap
	 * @param thisForm
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	private void refreshSearchResults(ModelMap modelMap,
									  MemberUpdateForm thisForm) throws BPMException, DataAccessException {
		try {
			String memberID = thisForm.getMemberID();
			String qualificationStartDateStr = thisForm
					.getQualificationStartDate();
			String lGroupNumber = thisForm.getGroupNumber();

			// qualificationStartDate is now optional
			java.sql.Date qualificationStartDate = BPMAdminUtils
					.getSqlDateFromString(qualificationStartDateStr);

			MemberDetail memberDetail = null;
			ArrayList<BusinessProgram> lBusinessPrograms = null;

			if (memberID != null && memberID.length() > 0) {
				memberDetail = memberService.getMemberDetail(memberID, qualificationStartDate);

				if (memberDetail == null) {

					createActionMessagesOnModel(modelMap, "messages.nosearchresults", new Object[]{"No search results."});
				}

				if (memberDetail.getMemberProgramDetails() != null) {
					ArrayList<MemberProgramDetail> lTermedMemberProgramDetails = (ArrayList<MemberProgramDetail>)
							memberService.getTermedMemberProgramHistoryDetails(memberID, qualificationStartDate);

					for (MemberProgramDetail lTermedMemberProgramDetail : lTermedMemberProgramDetails) {
						boolean lBizProgramIDFound = false;
						for (MemberProgramDetail lMemberProgramDetail : memberDetail.getMemberProgramDetails()) {
							if (lTermedMemberProgramDetail.getProgramID().intValue() == lMemberProgramDetail.getProgramID().intValue()) {
								lBizProgramIDFound = true;
							}
						}
						if (lBizProgramIDFound == false) {
							((ArrayList<MemberProgramDetail>) memberDetail.getMemberProgramDetails()).add(0, lTermedMemberProgramDetail);
						}
					}
				}
			}

			if (lGroupNumber != null && lGroupNumber.length() > 0) {
				lBusinessPrograms = (ArrayList<BusinessProgram>)
						businessProgramService.getActiveBusinessPrograms(lGroupNumber, qualificationStartDate);

				if (lBusinessPrograms.size() < 1) {
					createActionMessagesOnModel(modelMap, "messages.programNotFound", new Object[]{"Program not found."});
				}
			}

			modelMap.addAttribute("memberDetail", memberDetail);
			modelMap.addAttribute("businessPrograms", lBusinessPrograms);
			modelMap.addAttribute("memberStatusList", (ArrayList<LookUpValueCode>) businessProgramService.getMemberStatusCodes());
			modelMap.addAttribute("contractStatusList", (ArrayList<LookUpValueCode>) businessProgramService.getContractStatusCodes());

			if (userSession.getMemberDetail() != null && userSession.getMemberDetail().getMemberProgramDetails() != null) {
				userSession.getMemberDetail().getMemberProgramDetails().clear();
			}

			userSession.setMemberDetail(memberDetail);
			userSession.setBusinessPrograms(lBusinessPrograms);


			if (thisForm.getNewContractStatuses() != null) {
				for (int i = 0; i < thisForm.getNewContractStatuses().length; i++) {
					thisForm.getNewContractStatuses()[i] = "";
				}
			}

			if (thisForm.getNewMemberStatuses() != null) {
				for (int i = 0; i < thisForm.getNewMemberStatuses().length; i++) {
					thisForm.getNewMemberStatuses()[i] = "";
				}
			}

		} catch (Exception e) {
			throw new BPMException(e);
		}
	}

	/**
	 * @param thisForm
	 * @param pUserID
	 */
	protected void saveNewMemberStatus(ModelMap modelMap, MemberUpdateForm thisForm, String pUserID)
			throws BPMException, DataAccessException, IOException {

		String lPersonDemographicsID = thisForm.getPersonDemographicsID();
		String lPersonID = thisForm.getPersonID();

		ArrayList<MemberProgramDetail> lMemberProgramDetails = (ArrayList<MemberProgramDetail>)
				userSession.getMemberDetail().getMemberProgramDetails();

		if (thisForm.getNewMemberStatuses() != null) {
			for (int i = 0; i < thisForm.getNewMemberStatuses().length; i++) {

				int lCurrentMemberStatus = 0;
				String lCurrentMemberStatusCodeValue = "";


				String[] lNewMemberStatusString = thisForm.getNewMemberStatuses()[i].split("-");


				//if drop down is selected, it will populate and return programID, contract number, and
				//program incentive option.  So check the second occurence in array, for a value.  If no
				//value, then drop down was not selected.
				try {
					if (lNewMemberStatusString[0] != null && lNewMemberStatusString[0].length() > 0) {
						int lNewMemberStatus = Integer.parseInt(lNewMemberStatusString[0]);
						int lProgramID = Integer.parseInt(lNewMemberStatusString[1]);
						int lContractNo = Integer.parseInt(lNewMemberStatusString[2]);
						int lProgramIncentiveOptionID = Integer.parseInt(lNewMemberStatusString[3]);

						for (MemberProgramDetail lMemberProgramDetail : lMemberProgramDetails) {
							for (MemberStatusDetail lMemberStatusDetail : lMemberProgramDetail.getMemberStatusDetails()) {
								if (lMemberStatusDetail.getProgramIncentiveOptionID().intValue() == lProgramIncentiveOptionID) {
									lCurrentMemberStatus = lMemberStatusDetail.getMemberProgramStatusCodeID();
									lCurrentMemberStatusCodeValue = lMemberStatusDetail.getMemberProgramStatusCodeValue();


									if (lCurrentMemberStatus != lNewMemberStatus) {
										memberService.updateMemberStatus(Integer.parseInt(lPersonDemographicsID), lProgramID, lNewMemberStatus, pUserID, lProgramIncentiveOptionID);

										LookUpValueCode lNewMemberStatusLUV = memberService.getLUVCodeByID(lNewMemberStatus);
										// Insert a record in the qualification override table to keep track of the
										// status change.
										memberService.insertManualExemptionForMember(Integer.parseInt(lPersonDemographicsID),
												Integer.parseInt(lPersonID),
												lProgramID, lContractNo, "Changed Member Status from "
														+ lCurrentMemberStatusCodeValue + " to " + lNewMemberStatusLUV.getLuvVal()
														+ " after Status Calculation End Date.",
												Calendar.getInstance(), pUserID, pUserID, lProgramIncentiveOptionID);

										createActionMessagesOnModel(modelMap, "messages.updatedMemberStatus", new Object[]{thisForm.getSearchedMemberID()});
									}

									break;
								}
							}
						}
					}
				} catch(ArrayIndexOutOfBoundsException aioob){
					//ignore out of bounds error.  It indicates only one attribute returned representing
					// member status and the status will not need to be updated.
				}
			}
		}

		if (thisForm.getNewContractStatuses() != null) {
			for (int i = 0; i < thisForm.getNewContractStatuses().length; i++) {
			int lCurrentContractStatus = 0;
				String lCurrentContractStatusCodeValue = "";

				String[] lNewContractStatusString = thisForm.getNewContractStatuses()[i].split("-");

				try {
					if (lNewContractStatusString[0] != null && lNewContractStatusString[0].length() > 0) {
						int lNewContractStatus = Integer.parseInt(lNewContractStatusString[0]);
						int lProgramID = Integer.parseInt(lNewContractStatusString[1]);
						int lContractNo = Integer.parseInt(lNewContractStatusString[2]);
						int lProgramIncentiveOptionID = Integer.parseInt(lNewContractStatusString[3]);


						for (MemberProgramDetail lMemberProgramDetail : lMemberProgramDetails) {
							for (MemberStatusDetail lMemberStatusDetail : lMemberProgramDetail.getMemberStatusDetails()) {
								if (lMemberStatusDetail.getProgramIncentiveOptionID().intValue() == lProgramIncentiveOptionID) {
									lCurrentContractStatus = lMemberStatusDetail.getContractStatusCodeID().intValue();
									lCurrentContractStatusCodeValue = lMemberStatusDetail.getContractStatusCodeValue();
									break;
								}
							}
						}

						if (lCurrentContractStatus != lNewContractStatus) {
							LookUpValueCode lNewContractStatusLUV = memberService.getLUVCodeByID(lNewContractStatus);

							memberService.updateContractProgramStatus(lProgramID, lContractNo, lNewContractStatus, pUserID, lProgramIncentiveOptionID);
							// Insert a record in the qualification override table to keep track of the
							// status change.
							memberService.insertManualExemptionForMember(Integer.parseInt(lPersonDemographicsID),
									Integer.parseInt(lPersonID),
									lProgramID, lContractNo, "Changed Contract Status from "
											+ lCurrentContractStatusCodeValue + " to " + lNewContractStatusLUV.getLuvVal()
											+ " after Status Calculation End Date.",
									Calendar.getInstance(), pUserID, pUserID, lProgramIncentiveOptionID);


							createActionMessagesOnModel(modelMap, "messages.updatedContractStatus", new Object[]{String.valueOf(lContractNo)});
						}
					}
				} catch (ArrayIndexOutOfBoundsException aioob) {
					//ignore out of bounds error.  It indicates only one attribute returned representing
					// member status and the status will not need to be updated.
				}
			}

			if (thisForm.getParticipationEndDates() != null) {
				// Use the programIDs array to loop through because that is always populated.
				for (int i = 0; i < thisForm.getProgramIDs().length; i++) {
					java.sql.Date lParticipationEndDate = null;

					if (thisForm.getParticipationEndDates()[i] != null && thisForm.getParticipationEndDates()[i].length() > 0) {
						lParticipationEndDate = BPMAdminUtils.convertStringToSqlDate(thisForm.getParticipationEndDates()[i], BPMAdminConstants.HP_BPM_ADMIN_UI_COMMON_DATE_FORMAT);
					}

					memberService.updateParticipationEndDate(Integer.parseInt(lPersonDemographicsID)
							, thisForm.getProgramIDs()[i]
							, lParticipationEndDate);
				}
			}

			refreshSearchResults(modelMap, thisForm);
			clearFormArrays(thisForm);
		}
	}

	private void clearFormArrays(MemberUpdateForm thisForm) {
		thisForm.setCurrentContractStatuses(null);
		thisForm.setCurrentMemberStatuses(null);
		if (thisForm.getParticipationEndDates() != null) {
			for (int i = 0; i < thisForm.getParticipationEndDates().length; i++) {
				thisForm.getParticipationEndDates()[i] = "";
			}
		}
	}


	public void validateForMemberSearch(MemberUpdateForm form, ModelMap modelMap) {

		String memberID = form.getMemberID();
		String groupNumber = form.getGroupNumber();

		if (memberID == null && groupNumber == null) {
			createActionMessagesOnModel(modelMap, "errors.filtered.noselect", new Object[]{"Member ID or Employer Group Number"});
		}

	}

	public ModelMap validateForSaveDates(ModelMap modelMap) {
		String[] participationEndDates = (String[]) modelMap.get("participationEndDates");
		if (participationEndDates != null) {
			for (int i = 0; i < participationEndDates.length; i++) {
				if (participationEndDates[i] != null && participationEndDates[i].trim().length() > 0) {
					validateDateFormat("participationEndDates", participationEndDates[i], "Participation End Date");
				}
			}
		}

		return modelMap;
	}

	public MemberService getMemberService() {
		return memberService;
	}

	public void setMemberService(MemberService memberService) {
		this.memberService = memberService;
	}

	public BusinessProgramService getBusinessProgramService() {
		return businessProgramService;
	}

	public void setBusinessProgramService(
			BusinessProgramService businessProgramService) {
		this.businessProgramService = businessProgramService;
	}
}