package com.healthpartners.app.bpm.form;

import com.healthpartners.app.bpm.iface.BusinessProgramService;

/**
 * @author jxbourbour
 *
 */
public class SaveProgramContributionGridForm extends BaseForm {

    private Integer programID;
    private Integer incentiveOptionID;
    private Integer programIncentiveOptionID;
    private String groupNo;
    private String[] programBenefitContractTypeIDs;
    private String[] relationshipIDs;
    private String[] contributionAmounts;
    private String programBenefitContractTypeID;
    private String relationshipID;
    private String contributionAmount;
    private String rowID;
    private Integer groupID;


    public SaveProgramContributionGridForm() {
        super();
    }


    public String[] getProgramBenefitContractTypeIDs() {
        return programBenefitContractTypeIDs;
    }

    public void setProgramBenefitContractTypeIDs(
            String[] programBenefitContractTypeIDs) {
        this.programBenefitContractTypeIDs = programBenefitContractTypeIDs;
    }


    public String[] getRelationshipIDs() {
        return relationshipIDs;
    }

    public void setRelationshipIDs(String[] relationshipIDs) {
        this.relationshipIDs = relationshipIDs;
    }

    public String[] getContributionAmounts() {
        return contributionAmounts;
    }

    public void setContributionAmounts(String[] contributionAmounts) {
        this.contributionAmounts = contributionAmounts;
    }


    public String getRowID() {
        return rowID;
    }

    public void setRowID(String rowID) {
        this.rowID = rowID;
    }

    public String getActionType() {
        return actionType;
    }

    public void setActionType(String actionType) {
        this.actionType = actionType;
    }

    public String getProgramBenefitContractTypeID() {
        return programBenefitContractTypeID;
    }

    public void setProgramBenefitContractTypeID(String programBenefitContractTypeID) {
        this.programBenefitContractTypeID = programBenefitContractTypeID;
    }

    public String getRelationshipID() {
        return relationshipID;
    }

    public void setRelationshipID(String relationshipID) {
        this.relationshipID = relationshipID;
    }

    public String getContributionAmount() {
        return contributionAmount;
    }

    public void setContributionAmount(String contributionAmount) {
        this.contributionAmount = contributionAmount;
    }

    public Integer getProgramID() {
        return programID;
    }

    public void setProgramID(Integer programID) {
        this.programID = programID;
    }

    public Integer getIncentiveOptionID() {
        return incentiveOptionID;
    }

    public void setIncentiveOptionID(Integer incentiveOptionID) {
        this.incentiveOptionID = incentiveOptionID;
    }

    public Integer getProgramIncentiveOptionID() {
        return programIncentiveOptionID;
    }

    public void setProgramIncentiveOptionID(Integer programIncentiveOptionID) {
        this.programIncentiveOptionID = programIncentiveOptionID;
    }

    public String getGroupNo() {
        return groupNo;
    }

    public void setGroupNo(String groupNo) {
        this.groupNo = groupNo;
    }

    public Integer getGroupID() {
        return groupID;
    }

    public void setGroupID(Integer groupID) {
        this.groupID = groupID;
    }
}
