package com.healthpartners.app.bpm.dto;

import java.io.Serializable;
import java.util.ArrayList;

public class CheckmarkRequirement implements Serializable
{	
	static final long serialVersionUID = 0L;
		
	private Integer qualificationCheckmarkID;
	private Integer requirementID;	
	private Integer quantity;
	private Integer qualificationStatusCodeID;
	private String qualificationStatusCode;
	private String qualificationStatusDesc;
	
	ArrayList<CheckmarkDetail> checkmarkDetails;
	

	public ArrayList<CheckmarkDetail> getCheckmarkDetails() {
		return checkmarkDetails;
	}
	public void setCheckmarkDetails(ArrayList<CheckmarkDetail> checkmarkDetails) {
		this.checkmarkDetails = checkmarkDetails;
	}
	public Integer getQualificationCheckmarkID() {
		return qualificationCheckmarkID;
	}
	public void setQualificationCheckmarkID(Integer qualificationCheckmarkID) {
		this.qualificationCheckmarkID = qualificationCheckmarkID;
	}
	public Integer getQuantity() {
		return quantity;
	}
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
	public Integer getRequirementID() {
		return requirementID;
	}
	public void setRequirementID(Integer requirementID) {
		this.requirementID = requirementID;
	}
	public Integer getQualificationStatusCodeID() {
		return qualificationStatusCodeID;
	}
	public void setQualificationStatusCodeID(Integer qualificationStatusCodeID) {
		this.qualificationStatusCodeID = qualificationStatusCodeID;
	}
	public String getQualificationStatusCode() {
		return qualificationStatusCode;
	}
	public void setQualificationStatusCode(String qualificationStatusCode) {
		this.qualificationStatusCode = qualificationStatusCode;
	}
	public String getQualificationStatusDesc() {
		return qualificationStatusDesc;
	}
	public void setQualificationStatusDesc(String qualificationStatusDesc) {
		this.qualificationStatusDesc = qualificationStatusDesc;
	}
	
	
}
