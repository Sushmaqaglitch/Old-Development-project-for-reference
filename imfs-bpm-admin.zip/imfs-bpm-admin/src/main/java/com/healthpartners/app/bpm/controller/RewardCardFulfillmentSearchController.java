package com.healthpartners.app.bpm.controller;

import com.healthpartners.app.bpm.common.BPMAdminConstants;
import com.healthpartners.app.bpm.common.BPMAdminUtils;
import com.healthpartners.app.bpm.common.BPMPagination;
import com.healthpartners.app.bpm.dto.*;
import com.healthpartners.app.bpm.exception.BPMException;
import com.healthpartners.app.bpm.form.RewardCardFulfillmentSearchForm;
import com.healthpartners.app.bpm.iface.BusinessProgramService;
import com.healthpartners.app.bpm.iface.LookUpValueService;
import com.healthpartners.app.bpm.iface.RewardCardService;
import com.healthpartners.app.bpm.pageable.PageableRewardCardFulfillmentTrackingReportHist;
import com.healthpartners.app.bpm.session.UserSession;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

@Controller
public class RewardCardFulfillmentSearchController extends BaseController implements Validator {
    private static final String REWARD_FULFILL_HISTORIES_LIST = "REWARD_FULFILL_HISTORIES";
    private static final String ACTION_DOWNLOAD_CONTRIBUTIONS_PAGE = "downloadContributionsPage";

    private static final String DELIMETER = ",";
    private final LookUpValueService lookUpValueService;
    private final RewardCardService rewardCardService;
    private final BusinessProgramService businessProgramService;

    private final Log logger = LogFactory.getLog(getClass());

    public RewardCardFulfillmentSearchController(LookUpValueService lookUpValueService, RewardCardService rewardCardService, BusinessProgramService businessProgramService) {
        this.lookUpValueService = lookUpValueService;
        this.rewardCardService = rewardCardService;
        this.businessProgramService = businessProgramService;
    }

    @GetMapping("/rewardCardFulfillmentSearch")
    public String loadSearch(ModelMap modelMap) throws BPMException {
        try {
            load(modelMap);
        } catch (Exception e) {
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
            modelMap.put("errorMsg", getStackTrace(e));
        }

        return "rewardCardFulfillmentSearch";
    }

    @PostMapping("/rewardCardFulfillmentSearch")
    public String submitSearch(@ModelAttribute("rewardCardFulfillmentSearchForm") RewardCardFulfillmentSearchForm form, ModelMap modelMap, BindingResult result) throws Exception {
        try {
            if (StringUtils.isEmpty(form.getActionType())) {
                form.setActionType(ACTION_SEARCH);
            }
            if (ACTION_SEARCH.equals(form.getActionType())) {
                validate(form, result);
                if (result.hasErrors()) {
                    setAttributesBackAndNextButtonsOnModel(modelMap, null);
                    modelMap.put("luvRewardCardStatusTypes", getUserSession().getRewardCardStatusTypes());
                    modelMap.put("rewardCardTypes", getUserSession().getRewardCardTypes());
                    return "rewardCardFulfillmentSearch";
                }

                return performSearch(form, modelMap);
            }

        } catch (Exception e) {
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
            // Add error stack trace on the request, to be hidden in html.
            createErrorMessageOnModel(modelMap, getStackTrace(e));
        }

        return "rewardCardFulfillmentSearch";
    }

    @PostMapping(value = "/rewardCardFulfillmentSearch", params = "next")
    public String submitNext(@ModelAttribute("rewardCardFulfillmentSearchForm") RewardCardFulfillmentSearchForm form, ModelMap modelMap, HttpServletRequest request) throws Exception {
       return handlePaginationAction(modelMap, form);
    }

    @PostMapping(value = "/rewardCardFulfillmentSearch", params = "back")
    public String submitBack(@ModelAttribute("rewardCardFulfillmentSearchForm") RewardCardFulfillmentSearchForm form, ModelMap modelMap, HttpServletRequest request) throws Exception {
        return handlePaginationAction(modelMap, form);
    }

    @PostMapping(value = "/rewardCardFulfillmentSearch", params = "download")
    public String submitDownload(@ModelAttribute("rewardCardFulfillmentSearchForm") RewardCardFulfillmentSearchForm form, ModelMap modelMap, HttpServletRequest request, HttpServletResponse response) throws Exception {
        handleDownload(modelMap, form, response);
        return "rewardCardFulfillmentSearch";
    }
    
    private void load(ModelMap modelMap) throws BPMException {
        RewardCardFulfillmentSearchForm form = new RewardCardFulfillmentSearchForm();
        modelMap.put("rewardCardFulfillmentSearchForm", form);

        if (getUserSession().getRewardCardFulfillmentTrackingReportHistList() !=null && getUserSession().getRewardCardFulfillmentTrackingReportHistList().size() > 0) {
            getUserSession().getRewardCardFulfillmentTrackingReportHistList().clear();
        }

        if (getUserSession().getRewardCardTypes() == null || getUserSession().getRewardCardTypes().isEmpty() ||
                getUserSession().getRewardCardStatusTypes() == null || getUserSession().getRewardCardStatusTypes().isEmpty()) {

            ArrayList<LookUpValueCode> luvRewardCardStatusTypes = (ArrayList<LookUpValueCode>) lookUpValueService.getLUVCodesByGroup(BPMAdminConstants.REWARD_CARD_STATUS_TP);
            ArrayList<RewardCard> rewardCardTypes = (ArrayList<RewardCard>) rewardCardService.getRewardCardTypes();

            getUserSession().setRewardCardStatusTypes(luvRewardCardStatusTypes);
            getUserSession().setRewardCardTypes(rewardCardTypes);
            logger.info("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            logger.info("RewardCardStatusTypes count from luv table is " + luvRewardCardStatusTypes.size());
            logger.info("rewardCardTypes count from reward card table is " + rewardCardTypes.size());
            logger.info("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
        }

        modelMap.put("luvRewardCardStatusTypes", getUserSession().getRewardCardStatusTypes());
        modelMap.put("rewardCardTypes", getUserSession().getRewardCardTypes());
    }

    private String performSearch(RewardCardFulfillmentSearchForm form, ModelMap modelMap) throws Exception {
        if ((StringUtils.isNotEmpty(form.getGroupName())) || EMPLOYER_GROUPS_LIST.equals(form.getWhichList())) {
            modelMap.put("luvRewardCardStatusTypes", getUserSession().getRewardCardStatusTypes());
            modelMap.put("rewardCardTypes", getUserSession().getRewardCardTypes());
            searchByGroupName(modelMap, form);
        } else {
            search(modelMap, form);
        }

        return "rewardCardFulfillmentSearch";
    }

    private void searchByGroupName(ModelMap modelMap, RewardCardFulfillmentSearchForm form) throws Exception {
        boolean newDTOList = false;
        String actionType = form.getActionType();

        ArrayList<EmployerGroup> lEmployerGroupsPerPage = null;

        ArrayList<EmployerGroup> lEmployerGroups = getUserSession().getEmployerGroups();
        if (lEmployerGroups == null || actionType.equals(ACTION_SEARCH)) {
            lEmployerGroups = (ArrayList<EmployerGroup>) businessProgramService.getGroupsByName(form.getGroupName());
            getUserSession().setEmployerGroups(lEmployerGroups);
            newDTOList = true;
        }

        //Pagination code begins here.
        setEmployerGroupPaginationOnModel(modelMap, getUserSession(), actionType, newDTOList);
        //Pagination code ends here.

        getUserSession().setEmployerGroups(lEmployerGroups);
        getUserSession().setEmployerGroupsPerPage(lEmployerGroupsPerPage);
        getUserSession().setRewardCardFulfillmentSearchForm(form);
        getUserSession().setGroupName(form.getGroupName());
        form.setGroupName(getUserSession().getGroupName());

        if (lEmployerGroups.size() <= 0) {
            modelMap.put("luvRewardCardStatusTypes", getUserSession().getRewardCardStatusTypes());
            modelMap.put("rewardCardTypes", getUserSession().getRewardCardTypes());
            createNoResultsFoundMessageOnModel(modelMap);
        }
    }

    private void search(ModelMap modelMap, RewardCardFulfillmentSearchForm form) throws Exception {
        boolean newDTOList = false;
        String actionType = form.getActionType();

        ArrayList<RewardCardFulfillmentTrackingReportHist> lRewardCardFulfillmentTrackingReportHistList = getUserSession().getRewardCardFulfillmentTrackingReportHistList();

        if (lRewardCardFulfillmentTrackingReportHistList == null || actionType.equals(ACTION_SEARCH) || actionType.equals(ACTION_SITE_SEARCH)) {
            RewardCardFulfillmentSearchTO lRewardCardFulfillmentSearchTO = setRewardCardFulfillmentSearch(form);

            lRewardCardFulfillmentTrackingReportHistList = (ArrayList<RewardCardFulfillmentTrackingReportHist>)
                    rewardCardService.getRewardCardFulfillmentTrackingReportHistSearch(lRewardCardFulfillmentSearchTO);

            getUserSession().setRewardCardFulfillmentTrackingReportHistList(lRewardCardFulfillmentTrackingReportHistList);
            newDTOList = true;
        }

        //Pagination code begins here.

        String lWhichList = REWARD_FULFILL_HISTORIES_LIST;
        if (actionType.equals(ACTION_SITE_SEARCH)) {
            actionType = ACTION_SEARCH;
        }

        //Pagination code ends here.


        if (lRewardCardFulfillmentTrackingReportHistList.size() <= 0) {
            createNoResultsFoundMessageOnModel(modelMap);
        }

        setRewardCardFulfillmentTrackingReportPagination(modelMap, getUserSession(), actionType, newDTOList, lWhichList, "rewardCardFulfillHistories");

        getUserSession().setRewardCardFulfillmentSearchForm(form);
        if (getUserSession().getEmployerGroups() != null && getUserSession().getEmployerGroups().size() > 0) {
            modelMap.put("groupNameExists", BPMAdminConstants.BPM_ADMIN_TRUE);
        }

        modelMap.put("luvRewardCardStatusTypes", getUserSession().getRewardCardStatusTypes());
        modelMap.put("rewardCardTypes", getUserSession().getRewardCardTypes());
    }

    private void setRewardCardFulfillmentTrackingReportPagination(ModelMap modelMap,
                                                                  UserSession sessionBean,
                                                                  String actionType,
                                                                  boolean newDTOList,
                                                                  String pWhichList,
                                                                  String pRequestAttribute) {

        ArrayList<RewardCardFulfillmentTrackingReportHist> lRewardCardFulfillmentTrackingReportHistList = sessionBean.getRewardCardFulfillmentTrackingReportHistList();
        BPMPagination pagination = sessionBean.getPaginationMap().get(pWhichList);

        PageableRewardCardFulfillmentTrackingReportHist lPCFTR = null;
        if (pagination == null || newDTOList) {
            lPCFTR = new PageableRewardCardFulfillmentTrackingReportHist(lRewardCardFulfillmentTrackingReportHistList);
            lPCFTR.addRowNumber();
            pagination = new BPMPagination(lPCFTR, new ArrayList<Object>(lRewardCardFulfillmentTrackingReportHistList));
            sessionBean.getPaginationMap().put(pWhichList, pagination);
        }

        ArrayList<RewardCardFulfillmentTrackingReportHist>
                lRewardCardFulfillmentTrackingReportHistPerPage = (ArrayList<RewardCardFulfillmentTrackingReportHist>)
                determineNextOrBackAction(actionType, pagination);

        setAttributesForPaginationOnModel(modelMap, lRewardCardFulfillmentTrackingReportHistList.size(), pagination);

        modelMap.put(pRequestAttribute, lRewardCardFulfillmentTrackingReportHistPerPage);
        sessionBean.setRewardCardFulfillmentTrackingReportHistList(lRewardCardFulfillmentTrackingReportHistList);
        sessionBean.setRewardCardFulfillmentTrackingReportHistPerPage(lRewardCardFulfillmentTrackingReportHistPerPage);
    }

    private RewardCardFulfillmentSearchTO setRewardCardFulfillmentSearch(RewardCardFulfillmentSearchForm lRewardCardFulfillmentSearchForm) {
        RewardCardFulfillmentSearchTO lRewardCardFulfillmentSearchTO = new RewardCardFulfillmentSearchTO();

        lRewardCardFulfillmentSearchTO.setContractNo(lRewardCardFulfillmentSearchForm.getContractNumber());
        lRewardCardFulfillmentSearchTO.setGroupName(lRewardCardFulfillmentSearchForm.getGroupName());
        lRewardCardFulfillmentSearchTO.setGroupNo(lRewardCardFulfillmentSearchForm.getGroupNumber());
        lRewardCardFulfillmentSearchTO.setMemberNo(lRewardCardFulfillmentSearchForm.getMemberNumber());
        lRewardCardFulfillmentSearchTO.setCachePersonID(lRewardCardFulfillmentSearchForm.getCachePersonID());
        lRewardCardFulfillmentSearchTO.setTransactionID(lRewardCardFulfillmentSearchForm.getTransactionID());
        lRewardCardFulfillmentSearchTO.setSiteNo(lRewardCardFulfillmentSearchForm.getSiteNumber());
        lRewardCardFulfillmentSearchTO.setFulfillmentFromDate(BPMAdminUtils.convertStringToSqlDate(lRewardCardFulfillmentSearchForm.getFulfillmentFromDate(), BPMAdminConstants.HP_BPM_ADMIN_UI_COMMON_DATE_FORMAT));
        lRewardCardFulfillmentSearchTO.setFulfillmentToDate(BPMAdminUtils.convertStringToSqlDate(lRewardCardFulfillmentSearchForm.getFulfillmentToDate(), BPMAdminConstants.HP_BPM_ADMIN_UI_COMMON_DATE_FORMAT));
        lRewardCardFulfillmentSearchTO.setProgramStartDate(BPMAdminUtils.convertStringToSqlDate(lRewardCardFulfillmentSearchForm.getEffectiveDate(), BPMAdminConstants.HP_BPM_ADMIN_UI_COMMON_DATE_FORMAT));
        lRewardCardFulfillmentSearchTO.setRewardCardID(lRewardCardFulfillmentSearchForm.getRewardCardID());
        lRewardCardFulfillmentSearchTO.setRewardStatusCodeID(lRewardCardFulfillmentSearchForm.getRewardCardStatusID());

        return lRewardCardFulfillmentSearchTO;
    }

    private String handlePaginationAction(ModelMap modelMap, RewardCardFulfillmentSearchForm form) {
        modelMap.put("luvRewardCardStatusTypes", getUserSession().getRewardCardStatusTypes());
        modelMap.put("rewardCardTypes", getUserSession().getRewardCardTypes());

        if (REWARD_FULFILL_HISTORIES_LIST.equals(form.getWhichList())) {
            getUserSession().setRewardCardFulfillmentTrackingReportHistList(getUserSession().getRewardCardFulfillmentTrackingReportHistList());
            setRewardCardFulfillmentTrackingReportPagination(modelMap, getUserSession(), form.getActionType(), false, form.getWhichList(), "rewardCardFulfillHistories");
            getUserSession().setRewardCardFulfillmentTrackingReportHistPerPage(null);
        }

        if (EMPLOYER_GROUPS_LIST.equals(form.getWhichList())) {
            setEmployerGroupPaginationOnModel(modelMap, getUserSession(), form.getActionType(), false);
            getUserSession().setGroupName(form.getGroupName());
            form.setGroupName(getUserSession().getGroupName());
        }

        return "rewardCardFulfillmentSearch";
    }

    private void handleDownload(ModelMap modelMap, RewardCardFulfillmentSearchForm form, HttpServletResponse response) throws IOException {
        if(ACTION_DOWNLOAD_CONTRIBUTIONS_PAGE.equals(form.getActionType())) {
            //only download the list that is appearing on the page not
            //the whole list returned from the search.
            if (getUserSession().getRewardCardFulfillmentTrackingReportHistList() != null && getUserSession().getRewardCardFulfillmentTrackingReportHistList().size() > 0) {
                ArrayList<RewardCardFulfillmentTrackingReportHist> lRewardCardFulfillmentTrackingReportHist = getUserSession().getRewardCardFulfillmentTrackingReportHistList();

                response.setHeader("Content-Type", "text/csv");
                response.setHeader("Content-Disposition", "attachment;filename=\"report.csv\"");

                writeCsv(lRewardCardFulfillmentTrackingReportHist, response.getOutputStream());
            } else {
               String message = getMessage("errors.download", null);
                createErrorMessageOnModel(modelMap, message);
                // No pagination needed when list is empty.		
                modelMap.put("luvRewardCardStatusTypes", getUserSession().getRewardCardStatusTypes());
                modelMap.put("rewardCardTypes", getUserSession().getRewardCardTypes());
                this.setAttributesBackAndNextButtonsOnModel(modelMap, null);
            }
        }
    }

    private void writeCsv (Collection<RewardCardFulfillmentTrackingReportHist> csv, OutputStream output) throws IOException {
        BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(output, "UTF-8"));

        formatForFulfillDetailHeaderNWrite(writer);

        Iterator<RewardCardFulfillmentTrackingReportHist> iter = (Iterator<RewardCardFulfillmentTrackingReportHist>)csv.iterator();
        while (iter.hasNext()) {
            RewardCardFulfillmentTrackingReportHist lRewardCardFulfillmentTrackingReportHist = iter.next();

            formatForFulfillDetailNWrite(writer, lRewardCardFulfillmentTrackingReportHist);

        }

        closeFileWriter(writer);
    }

    public void closeFileWriter(BufferedWriter writer) {
        try {
            writer.flush();
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void formatForFulfillDetailHeaderNWrite(BufferedWriter writer) throws IOException {

        writer.append("No");
        writer.append(DELIMETER);

        writer.append("Fulfillment Date");
        writer.append(DELIMETER);

        writer.append("Group No");
        writer.append(DELIMETER);

        writer.append("Site No");
        writer.append(DELIMETER);

        writer.append("Member No");
        writer.append(DELIMETER);

        writer.append("Last Name");
        writer.append(DELIMETER);

        writer.append("First Name");
        writer.append(DELIMETER);

        writer.append("Contract No");
        writer.append(DELIMETER);

        writer.append("Activity Name");
        writer.append(DELIMETER);

        writer.append("Reward Card Amt");
        writer.append(DELIMETER);

        writer.append("Reward Date");
        writer.append(DELIMETER);

        writer.append("Status");
        writer.append(DELIMETER);

        writer.append("Status Date");
        writer.append(DELIMETER);

        writer.newLine();
    }


    private void formatForFulfillDetailNWrite(BufferedWriter writer, RewardCardFulfillmentTrackingReportHist lRewardCardFulfillmentTrackingReportHist ) throws IOException {
        writer.append(Integer.toString(lRewardCardFulfillmentTrackingReportHist.getRowNumber()));
        writer.append(DELIMETER);

        writer.append(BPMAdminUtils.formatDateMMddyyyy(lRewardCardFulfillmentTrackingReportHist.getFulfillmentDate()));
        writer.append(DELIMETER);

        writer.append(lRewardCardFulfillmentTrackingReportHist.getGroupNo());
        writer.append(DELIMETER);

        writer.append(lRewardCardFulfillmentTrackingReportHist.getSiteNo());
        writer.append(DELIMETER);

        writer.append(lRewardCardFulfillmentTrackingReportHist.getMemberNo());
        writer.append(DELIMETER);

        writer.append(lRewardCardFulfillmentTrackingReportHist.getLastName());
        writer.append(DELIMETER);

        writer.append(lRewardCardFulfillmentTrackingReportHist.getFirstName());
        writer.append(DELIMETER);

        //EV69597
        if (lRewardCardFulfillmentTrackingReportHist.getContractNo() != null) {
            writer.append(Integer.toString(lRewardCardFulfillmentTrackingReportHist.getContractNo()));
            writer.append(DELIMETER);
        } else {
            writer.append("N/A");
            writer.append(DELIMETER);
        }

        writer.append(lRewardCardFulfillmentTrackingReportHist.getActivityName().replaceAll(",", ""));
        writer.append(DELIMETER);

        writer.append(Integer.toString(lRewardCardFulfillmentTrackingReportHist.getContributionAmount()));
        writer.append(DELIMETER);


        writer.append(BPMAdminUtils.formatDateMMddyyyy(lRewardCardFulfillmentTrackingReportHist.getContributionDate()));
        writer.append(DELIMETER);

        writer.append(lRewardCardFulfillmentTrackingReportHist.getRewardCardFulfillmentReportHistStatus().getRewardStatus());
        writer.append(DELIMETER);

        writer.append(BPMAdminUtils.formatDateMMddyyyy(lRewardCardFulfillmentTrackingReportHist.getRewardCardFulfillmentReportHistStatus().getRewardStatusDate()));

        writer.newLine();
    }

    @Override
    public boolean supports(Class<?> clazz) {
        return RewardCardFulfillmentSearchForm.class.isAssignableFrom(clazz);
    }

    @Override
    public void validate(Object target, Errors errors) {
        RewardCardFulfillmentSearchForm form = (RewardCardFulfillmentSearchForm) target;

        boolean noCachePersonID = false;
        boolean noTransactionID = false;

        if (StringUtils.isNotEmpty(form.getEffectiveDate())) {
            getValidationSupport().validateDateFormat("effectiveDate", form.getEffectiveDate(), errors, new Object[]{"Program Year Effective Date"});
        }

        if (StringUtils.isNotEmpty(form.getFulfillmentFromDate())) {
            getValidationSupport().validateDateFormat("fulfillmentFromDate", form.getFulfillmentFromDate(), errors, new Object[]{"File Sent From Date"});
        }

        if (StringUtils.isNotEmpty(form.getFulfillmentToDate())) {
            getValidationSupport().validateDateFormat("fulfillmentToDate", form.getFulfillmentToDate(), errors, new Object[]{"File Sent To Date"});
        }

        if (StringUtils.isEmpty(form.getCachePersonID())) {
            noCachePersonID = true;
        }
        if (StringUtils.isEmpty(form.getTransactionID())) {
            noTransactionID = true;
        }

        if (noCachePersonID && noTransactionID) {
            if ((StringUtils.isEmpty(form.getMemberNumber())) && (StringUtils.isNotEmpty(form.getGroupNumber()))) {
                getValidationSupport().validateRequiredFieldIsNotEmpty("groupNumber", form.getGroupNumber(), errors, new Object[]{" Group No"});
            } else if ((StringUtils.isEmpty(form.getGroupNumber())) && StringUtils.isNotEmpty(form.getMemberNumber())) {
                getValidationSupport().validateRequiredFieldIsNotEmpty("memberNumber", form.getMemberNumber(), errors, new Object[]{" Member No"});
            } else {
                getValidationSupport().validateRequiredFieldIsNotEmpty("groupNumber", form.getGroupNumber(), errors, new Object[]{" Group No"});
                getValidationSupport().validateRequiredFieldIsNotEmpty("memberNumber", form.getMemberNumber(), errors, new Object[]{" Member No"});
            }
        }

        getValidationSupport().validateNotSpecialChar("groupNumber", form.getGroupNumber(), errors, new Object[]{"Group No"});
        getValidationSupport().validateNotSpecialChar("groupName", form.getGroupName(), errors, new Object[]{"Group Name"});
        getValidationSupport().validateNotSpecialChar("siteNumber", form.getSiteNumber(), errors, new Object[]{"Site No"});

        if (StringUtils.isNotEmpty(form.getContractNumber())) {
            getValidationSupport().validateNotInteger("contractNumber", form.getContractNumber(), errors, new Object[]{"Contract No"});
        }

    }
}
