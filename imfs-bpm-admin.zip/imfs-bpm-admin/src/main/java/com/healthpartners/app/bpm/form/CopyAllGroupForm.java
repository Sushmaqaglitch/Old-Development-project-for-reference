package com.healthpartners.app.bpm.form;

/**
 * @author jxbourbour
 *
 */
public class CopyAllGroupForm extends BaseForm {
	private String groupID;
	private String qualificationStartDate;
	
	public CopyAllGroupForm() {
		super();
	}

	public String getGroupID() {
		return groupID;
	}

	public void setGroupID(String groupID) {		
		this.groupID = groupID;
	}

	public String getQualificationStartDate() {
		return qualificationStartDate;
	}

	public void setQualificationStartDate(String qualificationStartDate) {
		this.qualificationStartDate = qualificationStartDate;
	}
}
