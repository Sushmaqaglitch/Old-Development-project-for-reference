package com.healthpartners.app.bpm.controller;

import com.healthpartners.app.bpm.common.BPMAdminConstants;
import com.healthpartners.app.bpm.common.BPMAdminUtils;
import com.healthpartners.app.bpm.dto.*;
import com.healthpartners.app.bpm.exception.BPMException;
import com.healthpartners.app.bpm.form.SaveProgramActivitySiteForm;
import com.healthpartners.app.bpm.form.SaveProgramCheckmarksForm;
import com.healthpartners.app.bpm.iface.BusinessProgramService;
import com.healthpartners.app.bpm.iface.MemberService;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.view.RedirectView;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;

import static org.apache.commons.lang.exception.ExceptionUtils.getStackTrace;

@Controller
public class ProgramCheckmarkController extends BaseController implements Validator {

    private static final String ACTION_SAVE = "save";
    private static final String ACTION_SAVE_TO_ALL_SITES = "saveToAllSites";
    private static final String ACTION_SAVE_TO_SELECTED = "saveToSelected";
    private static final String ACTION_ADD = "add";
    private static final String ACTION_REMOVE = "remove";
    protected final Log logger = LogFactory.getLog(getClass());
    private final BusinessProgramService businessProgramService;
    private final MemberService memberService;

    public ProgramCheckmarkController(BusinessProgramService businessProgramService, MemberService memberService) {
        this.businessProgramService = businessProgramService;
        this.memberService = memberService;
    }

    @PostMapping(value = "/saveProgramCheckmarks", params = "cancel")
    public RedirectView submitCancelEditProgram(@ModelAttribute("saveProgramCheckmarksForm") SaveProgramCheckmarksForm form, RedirectAttributes ra) {
        ra.addFlashAttribute("groupNumber", form.getGroupNumber());
        String url = "viewProgram?programID=" + form.getProgramID();
        return new RedirectView(url);
    }

    @PostMapping(value = "/saveProgramCheckmarks")
    public String submitActivityProgram(@ModelAttribute("saveProgramCheckmarksForm") SaveProgramCheckmarksForm form, ModelMap modelMap, BindingResult result, RedirectAttributes ra) {
        try {
            if (ACTION_REMOVE.equals(form.getActionType())) {
                removeProgramCheckmarks(form, modelMap);
            } else if (ACTION_ADD.equals(form.getActionType())) {
                addProgramCheckmarks(form, modelMap, getUserSession().getBusinessProgram().getProgramID());
            } else if (ACTION_SAVE.equals(form.getActionType()) || ACTION_SAVE_TO_ALL_SITES.equals(form.getActionType()) || ACTION_SAVE_TO_SELECTED.equals(form.getActionType())) {
                ArrayList<ProgramCheckmark> programCheckmarks = populateFromForm(form);
                validate(form, result);
                checkForDuplicateCheckmark(programCheckmarks, result);
                if(ACTION_SAVE_TO_ALL_SITES.equals(form.getActionType()) || ACTION_SAVE_TO_SELECTED.equals(form.getActionType())) {
                    // Make sure the incentive options of this site, are also available in the other sites.
                    checkForOtherSitesIncentiveOptions(result, getUserSession().getBusinessProgram().getProgramID());
                }
                if (result.hasErrors()) {
                    populateRequest(modelMap);
                    modelMap.put("availableCheckmarks", getUserSession().getAvailableCheckmarks());
                } else {
                    return performSave(programCheckmarks, form, modelMap, ra);
                }
            }
        } catch (Exception e) {
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
            createErrorMessageOnModel(modelMap, getStackTrace(e));
        }

        // Add package also forwards to the same jsp.
        return "programCheckmarks";
    }

    private String performSave(ArrayList<ProgramCheckmark> programCheckmarks, SaveProgramCheckmarksForm form, ModelMap modelMap, RedirectAttributes ra) throws Exception {
        String lUserID = getUserSessionSupport().getAuthenticatedUsername();

        if (ACTION_SAVE.equals(form.getActionType())) {
            deleteDeletedProgramCheckmarks();
            businessProgramService.updateProgramCheckmarks(programCheckmarks, form.getProgramID(), lUserID);
            // Set member statuses to Eligible, null the qualification checkmark.
            memberService.updateMemberStatusByCodeValue(null, form.getProgramID(), null, BPMAdminConstants.BPM_ADMIN_STATUS_ELIGIBLE, lUserID);
            // Recalculate the status of all the members in this business program.
            businessProgramService.updateAllGroupSiteMembers(BPMAdminConstants.BPM_ADMIN_MEMBERS_RECALCULATION_PRCS_ID, form.getProgramID());

        } else if (ACTION_SAVE_TO_ALL_SITES.equals(form.getActionType())) {
            deleteDeletedProgramCheckmarks();
            businessProgramService.saveProgramCheckmarksToAllSites(programCheckmarks, getUserSession().getBusinessProgram(), lUserID);
            ArrayList<EmployerGroup> lAllSitesThisYear = (ArrayList<EmployerGroup>) businessProgramService.getBusinessProgramInSameYear(getUserSession().getBusinessProgram().getProgramID());
            markMembersForStatusRecalc(lAllSitesThisYear, lUserID);

        } else if (ACTION_SAVE_TO_SELECTED.equals(form.getActionType())) {
            deleteDeletedProgramCheckmarks();
            saveToSelectedSites(form, modelMap);
            // markMembersForStatusRecalc is called in SaveProgramActivitySite in the
            // saveSelectedSitesCheckmarks method. That is where the actual Save happens.
            return "programActivitySites";
        }

        programCheckmarks.clear();
        programCheckmarks = businessProgramService.getProgramCheckmarks(form.getProgramID());

        for (ProgramCheckmark lProgramCheckmark : programCheckmarks) {
            lProgramCheckmark.setCheckmarkRequirements((ArrayList<CheckmarkRequirement>)
                    businessProgramService.getCheckmarkRequirements(lProgramCheckmark.getQualificationCheckmarkID()));
        }

        if (getUserSession().getProgramCheckmarks() != null) {
            getUserSession().getProgramCheckmarks().clear();
            getUserSession().getProgramCheckmarks().addAll(programCheckmarks);
        } else {
            getUserSession().setProgramCheckmarks(programCheckmarks);
        }

        populateRequest(modelMap);

        // Redirect back to the viewProgram screen upon successful process of saves
        ra.addFlashAttribute("groupNumber", form.getGroupNumber());
        String url = "viewProgram?programID=" + form.getProgramID();
        return "redirect:" + url;
    }

    protected void deleteDeletedProgramCheckmarks() throws BPMException {
        for(ProgramCheckmark lDeletedProgramCheckmark : getUserSession().getDeletedProgramCheckmarks()) {
            businessProgramService.deleteProgramCheckmark(lDeletedProgramCheckmark.getProgramCheckmarkID());
        }
    }

    protected void markMembersForStatusRecalc(ArrayList<EmployerGroup> pEmployerGroups, String pUserID) throws BPMException, IOException {
        for (EmployerGroup lEmployerGroup : pEmployerGroups) {
            ArrayList<BusinessProgram> lBusinessPrograms = (ArrayList<BusinessProgram>)
                    businessProgramService.getBusinessPrograms(getUserSession().getBusinessProgram().getEffectiveDate()
                            , getUserSession().getBusinessProgram().getEmployerGroup().getGroupID()
                            , lEmployerGroup.getSubgroupID());

            for (BusinessProgram lBusinessProgram : lBusinessPrograms) {
                memberService.updateMemberStatusByCodeValue(null, lBusinessProgram.getProgramID(), null, BPMAdminConstants.BPM_ADMIN_STATUS_ELIGIBLE, pUserID);
                businessProgramService.updateAllGroupSiteMembers(BPMAdminConstants.BPM_ADMIN_MEMBERS_RECALCULATION_PRCS_ID, lBusinessProgram.getProgramID());
            }
        }
    }

    /**
     * Called when user clicks on Save Selected Sites from the Edit Program Activities page.
     */
    private void saveToSelectedSites(SaveProgramCheckmarksForm form, ModelMap modelMap) throws BPMException {
        if (getUserSession().getAvailableSites() != null) {
            getUserSession().getAvailableSites().clear();
        }

        if (getUserSession().getEmployerSubGroups() != null) {
            getUserSession().getEmployerSubGroups().clear();
        }

        ArrayList<ProgramCheckmark> lProgramCheckmarks = populateFromForm(form);

        getUserSession().setProgramCheckmarks(lProgramCheckmarks);

        Collection<EmployerGroup> lSubGroups = businessProgramService.getBusinessProgramInSameYear(getUserSession().getBusinessProgram().getProgramID());

        modelMap.put("businessProgram", getUserSession().getBusinessProgram());
        modelMap.put("selectedSubGroups", lSubGroups);
        getUserSession().setEmployerSubGroups((ArrayList<EmployerGroup>) lSubGroups);
        getUserSession().setWhichSaveSelectedSite(WHICH_SAVE_SELECTED_SITES_CHECKMARKS);

        SaveProgramActivitySiteForm saveProgramActivitySiteForm = new SaveProgramActivitySiteForm();
        saveProgramActivitySiteForm.setSubGroupID(((ArrayList<EmployerGroup>) lSubGroups).get(0).getSubgroupID());
        modelMap.put("saveProgramActivitySiteForm", saveProgramActivitySiteForm);
    }

    /**
     * Add an Activity to the Program Activities.
     */
    private void addProgramCheckmarks(SaveProgramCheckmarksForm pSaveProgramCheckmarksForm, ModelMap modelMap, Integer pBusinessProgramID) {
        // The ID of the Incentive Option that was selected.
        Integer lQualificationCheckmarkID = pSaveProgramCheckmarksForm.getProgramCheckmarkAddRemove();
        Integer lDefaultAllParticipantsID = 0;
        String lParticipationGroupName = "";
        String lParticipationGroupInfo = "";

        ArrayList<QualificationCheckmark> lAvailableCheckmarks = getUserSession().getAvailableCheckmarks();

        ArrayList<ProgramCheckmark> lProgramCheckmarks = populateFromForm(pSaveProgramCheckmarksForm);

        for (ParticipationGroup lParticipationGroup : getUserSession().getParticipationGroups()) {
            if (BPMAdminConstants.BPM_PART_GROUP_DEFAULT_ALL.equalsIgnoreCase(lParticipationGroup.getParticipationGroupName())) {
                lDefaultAllParticipantsID = lParticipationGroup.getParticipationGroupID();
                lParticipationGroupName = lParticipationGroup.getParticipationGroupName();
                lParticipationGroupInfo = lParticipationGroup.getParticipationGroupInfo();
                break;
            }
        }

        // Find the activity whose ID matches the one selected.
        for (QualificationCheckmark lAvailableCheckmark : lAvailableCheckmarks) {
            // Once the ID is found, add the checkmark to the program-checkmarks.
            if (lAvailableCheckmark.getQualificationCheckmarkID().intValue() == lQualificationCheckmarkID.intValue()) {
                ProgramCheckmark lProgramCheckmark = new ProgramCheckmark();

                lProgramCheckmark.setProgramCheckmarkID(0);

                lProgramCheckmark.setQualificationCheckmarkID(lQualificationCheckmarkID);
                lProgramCheckmark.setQualificationCheckmarkName(lAvailableCheckmark.getQualificationCheckmarkName());
                lProgramCheckmark.setQualificationCheckmarkInfo(lAvailableCheckmark.getQualificationCheckmarkInfo());
                lProgramCheckmark.setQualificationCheckmarkDesc(lAvailableCheckmark.getQualificationCheckmarkDesc());
                lProgramCheckmark.setEffectiveDate(lAvailableCheckmark.getEffectiveDate());
                lProgramCheckmark.setEndDate(lAvailableCheckmark.getEndDate());
                lProgramCheckmark.setBusinessProgramID(pBusinessProgramID);
                lProgramCheckmark.setParticipationGroupID(lDefaultAllParticipantsID);
                lProgramCheckmark.setParticipationGroupName(lParticipationGroupName);
                lProgramCheckmark.setParticipationGroupInfo(lParticipationGroupInfo);
                lProgramCheckmark.setProgramIncentiveOptionID(0);
                lProgramCheckmark.setIncentiveOptionName("Select...");

                lProgramCheckmarks.add(lProgramCheckmark);
                break;
            }
        }

        getUserSession().setProgramCheckmarks(lProgramCheckmarks);
        resetFormArrays(pSaveProgramCheckmarksForm);
        populateRequest(modelMap);
        modelMap.put("availableCheckmarks", getUserSession().getAvailableCheckmarks());
    }

    /**
     * Remove an Activity from the Program Activities.
     */
    private void removeProgramCheckmarks(SaveProgramCheckmarksForm pSaveProgramCheckmarksForm, ModelMap modelMap) {
        Integer lProgramCheckmarkID = pSaveProgramCheckmarksForm.getProgramCheckmarkAddRemove();

        // Populate the program checkmarks with the values the user has entered.
        ArrayList<ProgramCheckmark> lProgramCheckmarks = populateFromForm(pSaveProgramCheckmarksForm);

        // Find the Program Eligible Activity whose ID matches the one selected.
        for (int i = 0; i < lProgramCheckmarks.size(); i++) {
            ProgramCheckmark lProgramCheckmark = lProgramCheckmarks.get(i);
            // Once the ID is found, remove the Incentive from the Program Incentive Options
            // and add it back to the list of Available Incentives.
            if (lProgramCheckmark.getProgramCheckmarkID().intValue() == lProgramCheckmarkID.intValue()) {
                getUserSession().getDeletedProgramCheckmarks().add(lProgramCheckmarks.get(i));
                lProgramCheckmarks.remove(i);
                break;
            }
        }

        getUserSession().setProgramCheckmarks(lProgramCheckmarks);
        resetFormArrays(pSaveProgramCheckmarksForm);
        populateRequest(modelMap);
        modelMap.put("availableCheckmarks", getUserSession().getAvailableCheckmarks());
    }

    protected void populateRequest(ModelMap modelMap) {
        modelMap.put("businessProgram", getUserSession().getBusinessProgram());
        modelMap.put("eligibleActivities", getUserSession().getEligibleActivities());
        modelMap.put("programIncentiveOptions", getUserSession().getProgramIncentiveOptions());
        modelMap.put("additionalInfos", getUserSession().getAdditionalInfos());
        modelMap.put("extendedAuthCodes", getUserSession().getExtendedAuthCodes());
        modelMap.put("programPackages", getUserSession().getProgramPackages());
        modelMap.put("changeLogList", getUserSession().getProgramChangeLogList());
        modelMap.put("benefitPackages", getUserSession().getBenefitPackages());
        modelMap.put("participationGroups", getUserSession().getParticipationGroups());
        modelMap.put("programCheckmarks", getUserSession().getProgramCheckmarks());
        BPMAdminUtils.populateProgramCheckmarkDefinition(getUserSession());
        modelMap.put("qualificationCheckmarks", getUserSession().getQualificationCheckmarks());
    }

    protected ArrayList<ProgramCheckmark> populateFromForm(SaveProgramCheckmarksForm pSaveProgramCheckmarksForm) {
        ArrayList<ProgramCheckmark> lProgramCheckmarks = new ArrayList<>();
        for (int i = 0; pSaveProgramCheckmarksForm.getCheckmarkIDs() != null && i < pSaveProgramCheckmarksForm.getCheckmarkIDs().length; i++) {
            ProgramCheckmark lProgramCheckmark = new ProgramCheckmark();
            lProgramCheckmark.setQualificationCheckmarkID(pSaveProgramCheckmarksForm.getCheckmarkIDs()[i]);
            lProgramCheckmark.setQualificationCheckmarkName(pSaveProgramCheckmarksForm.getCheckmarkNames()[i]);
            lProgramCheckmark.setQualificationCheckmarkInfo(pSaveProgramCheckmarksForm.getCheckmarkInfos()[i]);
            lProgramCheckmark.setBusinessProgramID(pSaveProgramCheckmarksForm.getProgramID());
            lProgramCheckmark.setParticipationGroupID(pSaveProgramCheckmarksForm.getParticipationGroupIDs()[i]);
            lProgramCheckmark.setParticipationGroupName(findParticipationGroupName(pSaveProgramCheckmarksForm.getParticipationGroupIDs()[i]));
            lProgramCheckmark.setParticipationGroupInfo(findParticipationGroupInfo(pSaveProgramCheckmarksForm.getParticipationGroupIDs()[i]));
            lProgramCheckmark.setEffectiveDate(BPMAdminUtils.convertStringToSqlDate(pSaveProgramCheckmarksForm.getEffectiveDates()[i], BPMAdminConstants.HP_BPM_ADMIN_UI_COMMON_DATE_FORMAT));
            lProgramCheckmark.setEndDate(BPMAdminUtils.convertStringToSqlDate(pSaveProgramCheckmarksForm.getEndDates()[i], BPMAdminConstants.HP_BPM_ADMIN_UI_COMMON_DATE_FORMAT));
            lProgramCheckmark.setProgramCheckmarkID(pSaveProgramCheckmarksForm.getProgramCheckmarkIDs()[i]);
            lProgramCheckmark.setProgramIncentiveOptionID(pSaveProgramCheckmarksForm.getProgramIncentiveOptionIDs()[i]);
            lProgramCheckmark.setIncentiveOptionName(findIncentiveOptionName(lProgramCheckmark.getProgramIncentiveOptionID()));
            lProgramCheckmark.setIncentiveOptionID(findIncentiveOptionID(lProgramCheckmark.getProgramIncentiveOptionID()));
            lProgramCheckmarks.add(lProgramCheckmark);
        }

        return lProgramCheckmarks;
    }

    protected String findParticipationGroupName(Integer pParticipationGroupID) {
        Collection<ParticipationGroup> lParticipationGroups = getUserSession().getParticipationGroups();
        for (ParticipationGroup lParticipationGroup : lParticipationGroups) {
            if (lParticipationGroup.getParticipationGroupID().intValue() == pParticipationGroupID.intValue()) {
                return lParticipationGroup.getParticipationGroupName();
            }
        }
        return "";
    }

    protected String findParticipationGroupInfo(Integer pParticipationGroupID) {
        Collection<ParticipationGroup> lParticipationGroups = getUserSession().getParticipationGroups();
        for (ParticipationGroup lParticipationGroup : lParticipationGroups) {
            if (lParticipationGroup.getParticipationGroupID().intValue() == pParticipationGroupID.intValue()) {
                return lParticipationGroup.getParticipationGroupInfo();
            }
        }
        return "";
    }

    protected String findIncentiveOptionName(Integer pProgramIncentiveOptionID) {
        for (ProgramIncentiveOption lProgramIncentiveOption : getUserSession().getProgramIncentiveOptions()) {
            if (lProgramIncentiveOption.getProgramIncentiveOptionID().intValue() == pProgramIncentiveOptionID.intValue()) {
                return lProgramIncentiveOption.getIncentiveOption().getIncentiveOptionName();
            }
        }
        return "";
    }

    protected Integer findIncentiveOptionID(Integer pProgramIncentiveOptionID) {
        for (ProgramIncentiveOption lProgramIncentiveOption : getUserSession().getProgramIncentiveOptions()) {
            if (lProgramIncentiveOption.getProgramIncentiveOptionID().intValue() == pProgramIncentiveOptionID.intValue()) {
                return lProgramIncentiveOption.getIncentiveOption().getIncentiveOptionID();
            }
        }
        return 0;
    }

    protected void resetFormArrays(SaveProgramCheckmarksForm pSaveProgramCheckmarksForm) {
        Integer[] participationGroupIDs = new Integer[getUserSession().getProgramCheckmarks().size()];
        Integer[] programIncentiveOptionIDs = new Integer[getUserSession().getProgramCheckmarks().size()];
        int i = 0;
        for (ProgramCheckmark lProgramCheckmark : getUserSession().getProgramCheckmarks()) {
            participationGroupIDs[i] = lProgramCheckmark.getParticipationGroupID();
            programIncentiveOptionIDs[i] = lProgramCheckmark.getProgramIncentiveOptionID();
            i++;
        }
        pSaveProgramCheckmarksForm.setParticipationGroupIDs(participationGroupIDs);
        pSaveProgramCheckmarksForm.setProgramIncentiveOptionIDs(programIncentiveOptionIDs);
        pSaveProgramCheckmarksForm.setProgramCheckmarkAddRemove(0);
    }

    @Override
    public boolean supports(Class<?> clazz) {
        return SaveProgramCheckmarksForm.class.isAssignableFrom(clazz);
    }

    @Override
    public void validate(Object target, Errors errors) {
        SaveProgramCheckmarksForm saveProgramCheckmarksForm = (SaveProgramCheckmarksForm) target;
        if(saveProgramCheckmarksForm.getCheckmarkIDs() == null || saveProgramCheckmarksForm.getCheckmarkIDs().length < 1) {
            return;
        }

        if(saveProgramCheckmarksForm.getParticipationGroupIDs() == null || saveProgramCheckmarksForm.getParticipationGroupIDs() .length < 1) {
            getValidationSupport().addValidationFailureMessage("participationGroupIDs", errors, "errors.required", new Object[]{"Participation Group"});
        } else {
            for(int i = 0; i < saveProgramCheckmarksForm.getParticipationGroupIDs().length; i++) {
                if(saveProgramCheckmarksForm.getParticipationGroupIDs()[i] == null || saveProgramCheckmarksForm.getParticipationGroupIDs()[i] == 0) {
                    getValidationSupport().addValidationFailureMessage("participationGroupIDs["+i+"]", errors, "errors.required", new Object[]{"Participation Group"});
                }
            }
        }

        if(saveProgramCheckmarksForm.getProgramIncentiveOptionIDs() == null || saveProgramCheckmarksForm.getProgramIncentiveOptionIDs() .length < 1) {
            getValidationSupport().addValidationFailureMessage("programIncentiveOptionIDs", errors, "errors.required", new Object[]{"Incentive Option"});
        } else {
            for(int i = 0; i < saveProgramCheckmarksForm.getProgramIncentiveOptionIDs().length; i++) {
                if(saveProgramCheckmarksForm.getProgramIncentiveOptionIDs()[i] == null || saveProgramCheckmarksForm.getProgramIncentiveOptionIDs()[i] == 0) {
                    getValidationSupport().addValidationFailureMessage("programIncentiveOptionIDs["+i+"]", errors, "errors.required", new Object[]{"Incentive Option"});
                }
            }
        }
    }

    private void checkForDuplicateCheckmark(ArrayList<ProgramCheckmark> pNewProgramCheckmarks, Errors errors) {
        boolean lDuplicateExists = false;

        for (int i = 0; i < (pNewProgramCheckmarks.size() - 1); i++) {
            for (int j = 1; j < pNewProgramCheckmarks.size(); j++) {
                if (pNewProgramCheckmarks.get(i).getProgramCheckmarkID().intValue() != pNewProgramCheckmarks.get(j).getProgramCheckmarkID().intValue() &&
                        pNewProgramCheckmarks.get(i).getQualificationCheckmarkID().intValue() == pNewProgramCheckmarks.get(j).getQualificationCheckmarkID().intValue() &&
                        pNewProgramCheckmarks.get(i).getProgramIncentiveOptionID().intValue() == pNewProgramCheckmarks.get(j).getProgramIncentiveOptionID().intValue()) {
                    getValidationSupport().addValidationFailureMessage("programIncentiveOptionIDs["+j+"]", errors, "errors.duplicatenumber", new Object[]{"Program Checkmark and Program Incentive Option association"});
                    lDuplicateExists = true;
                    break;
                }
            }

            if (lDuplicateExists) {
                break;
            }
        }
    }

    protected void checkForOtherSitesIncentiveOptions(Errors errors, Integer pProgramID) throws BPMException {
        ArrayList<ProgramIncentiveOption> lThisSiteIncentiveOptions = (ArrayList<ProgramIncentiveOption>) businessProgramService.getProgramIncentiveOptions(pProgramID);
        ArrayList<EmployerGroup> lBusinessProgramsInSameYear = (ArrayList<EmployerGroup>) businessProgramService.getBusinessProgramInSameYear(pProgramID);

        for (EmployerGroup lBusinessProgram : lBusinessProgramsInSameYear) {
            ArrayList<ProgramIncentiveOption> lOtherSitesIncentiveOptions = (ArrayList<ProgramIncentiveOption>) businessProgramService.getProgramIncentiveOptions(lBusinessProgram.getProgramID());

            for (ProgramIncentiveOption lThisSiteIncentiveOption : lThisSiteIncentiveOptions) {
                boolean lFound = false;

                for (ProgramIncentiveOption lOtherSitesIncentiveOption : lOtherSitesIncentiveOptions) {
                    if (lThisSiteIncentiveOption.getIncentiveOption().getIncentiveOptionID().intValue() == lOtherSitesIncentiveOption.getIncentiveOption().getIncentiveOptionID().intValue()) {
                        lFound = true;
                        break;
                    }
                }

                if (!lFound) {
                    getValidationSupport().addValidationFailureMessage("programIncentiveOptionIDs[0]", errors, "errors.programIncentiveOptionsMismatch", new Object[]{lThisSiteIncentiveOption.getIncentiveOption().getIncentiveOptionName()});
                }
            }
        }
    }
}
