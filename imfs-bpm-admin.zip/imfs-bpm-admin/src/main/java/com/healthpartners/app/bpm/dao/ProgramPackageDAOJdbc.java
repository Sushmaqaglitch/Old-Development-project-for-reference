/* $Id$ */

package com.healthpartners.app.bpm.dao;

import com.healthpartners.app.bpm.common.BPMAdminUtils;
import com.healthpartners.app.bpm.dto.PackageActivity;
import com.healthpartners.app.bpm.dto.ProgramPackage;
import com.healthpartners.app.bpm.exception.BPMException;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import jakarta.annotation.PostConstruct;
import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Collection;

@Repository
@Transactional(timeout = 300, rollbackFor = {DataAccessException.class, BPMException.class})
public class ProgramPackageDAOJdbc extends JdbcDaoSupport implements ProgramPackageDAO {
	// @formatter:off
	private String selectProgramPackages =
			" SELECT ELIG_PGM_PKG_ID, PKG_NM, PKG_INFO, PKG_DESC, EFF_DT, END_DT, CASE WHEN EXISTS (SELECT * FROM business_program biz WHERE ELIG_PGM_PKG_ID = epp.ELIG_PGM_PKG_ID) THEN 1\n" +
					"ELSE 0 END as used_flg\n" +
					"FROM ELIG_PGM_PKG epp\n" +
					"where trunc(SYSDATE) <= END_DT\n" +
					"order by epp.PKG_NM asc";

    private static final String selectProgramPackageActivities = """
                    SELECT ELIG_PGM_PKG_ID
                           ,ELIG_PGM_PKG_ACTV.ACTV_ID
                           ,ACTV_NM
                           ,(select lu_val from luv where lu_id = activity.actv_tp_cd_id) as actv_tp_cd_value
                           ,(select lu_desc from luv where lu_id = activity.actv_tp_cd_id) as actv_tp_cd_desc
                           , SRCE_ACTV_ID
                           , ACTV_DESC
                    FROM
                        ELIG_PGM_PKG_ACTV, activity
                    WHERE
                        ELIG_PGM_PKG_ID = ?
                        AND ELIG_PGM_PKG_ACTV.actv_id = activity.actv_id
                        AND trunc(SYSDATE) >= activity.ACTV_EFF_DT
                        AND trunc(SYSDATE) <= activity.ACTV_END_DT 
                        ORDER BY actv_tp_cd_value, actv_nm""";

    // @formatter:on

	private final DataSource dataSource;

	public ProgramPackageDAOJdbc(DataSource dataSource) {
		this.dataSource = dataSource;
	}

	@PostConstruct
	private void initialize() {
		setDataSource(dataSource);
	}

    //Produces warnings during compile time to quickly identify typos or API changes
    @Override
    public Collection<ProgramPackage> getProgramPackages() throws BPMException, DataAccessException {
        final ArrayList<ProgramPackage> lProgramPackageList = new ArrayList<ProgramPackage>();

        JdbcTemplate template = getJdbcTemplate();
        Object[] params = new Object[]{};
        int[] types = new int[]{};

        template.query(selectProgramPackages, params, types, new RowCallbackHandler() {
            public void processRow(ResultSet rs) throws SQLException {
                ProgramPackage lProgramPackage = new ProgramPackage();
                lProgramPackage.setPackageID(rs.getInt("ELIG_PGM_PKG_ID"));
                lProgramPackage.setPackageName(rs.getString("PKG_NM"));
                lProgramPackage.setPackageInfo(rs.getString("PKG_INFO"));
                lProgramPackage.setPackageDesc(rs.getString("PKG_DESC"));
                lProgramPackage.setEffectiveDate(rs.getDate("EFF_DT"));
                lProgramPackage.setEndDate(rs.getDate("END_DT"));

                lProgramPackage.setEffectiveDateString(BPMAdminUtils.formatDateMMddyyyy(lProgramPackage.getEffectiveDate()));
                lProgramPackage.setEndDateString(BPMAdminUtils.formatDateMMddyyyy(lProgramPackage.getEndDate()));
                lProgramPackage.setUsed(rs.getInt("used_flg"));

                lProgramPackageList.add(lProgramPackage);
            }
        });

        return lProgramPackageList;
    }

    /**
     * @param pPackageID
     * @return
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Override
    public Collection<PackageActivity> getPackageActivities(Integer pPackageID)
            throws BPMException, DataAccessException {
        final ArrayList<PackageActivity> lPackageActivityList = new ArrayList<PackageActivity>();

        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{pPackageID};
        int types[] = new int[]{Types.INTEGER};

        template.query(selectProgramPackageActivities, params, types, new RowCallbackHandler() {
            public void processRow(ResultSet rs) throws SQLException {
                PackageActivity lPackageActivity = new PackageActivity();

                lPackageActivity.setPackageID(rs.getInt("ELIG_PGM_PKG_ID"));
                lPackageActivity.setActivityID(rs.getInt("actv_id"));
                lPackageActivity.setActivityName(rs.getString("actv_nm"));
                lPackageActivity.setActivityType(rs.getString("actv_tp_cd_value"));
                lPackageActivity.setActivityTypeDesc(rs.getString("actv_tp_cd_desc"));
                lPackageActivity.setSourceSystemActivityID(rs.getString("SRCE_ACTV_ID"));
                lPackageActivity.setActivityDesc(rs.getString("ACTV_DESC"));

                lPackageActivityList.add(lPackageActivity);
            }
        });

        return lPackageActivityList;
    }
}
