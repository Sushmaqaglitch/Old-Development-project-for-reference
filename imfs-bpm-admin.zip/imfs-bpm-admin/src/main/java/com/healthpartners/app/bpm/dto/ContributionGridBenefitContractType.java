package com.healthpartners.app.bpm.dto;

import java.io.Serializable;
import java.util.Collection;

public class ContributionGridBenefitContractType implements Serializable {
    static final long serialVersionUID = 0L;


    private Integer benefitContractTypeID;
    private String luvDesc;

    private Collection<ContributionGridBenefitContractTypeRelationship> contributionGridBenefitContractTypeRelationships;


    public ContributionGridBenefitContractType() {
        super();
    }


    public Integer getBenefitContractTypeID() {
        return benefitContractTypeID;
    }


    public void setBenefitContractTypeID(Integer benefitContractTypeID) {
        this.benefitContractTypeID = benefitContractTypeID;
    }


    public String getLuvDesc() {
        return luvDesc;
    }


    public void setLuvDesc(String luvDesc) {
        this.luvDesc = luvDesc;
    }


    public Collection<ContributionGridBenefitContractTypeRelationship> getContributionGridBenefitContractTypeRelationships() {
        return contributionGridBenefitContractTypeRelationships;
    }


    public void setContributionGridBenefitContractTypeRelationships(
            Collection<ContributionGridBenefitContractTypeRelationship> contributionGridBenefitContractTypeRelationships) {
        this.contributionGridBenefitContractTypeRelationships = contributionGridBenefitContractTypeRelationships;
    }


}
