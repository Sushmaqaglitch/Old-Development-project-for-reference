package com.healthpartners.app.bpm.dto;

import java.io.Serializable;
import java.sql.Date;

public class BaselineHistory implements Serializable {
    static final long serialVersionUID = 0L;
    private String memberID;
    private String firstName;
    private String lastName;
    private Date birthDate;
    private String relationship;
    private Integer personID;
    private Integer contractNo;
    private Integer groupID;
    private Integer SubgroupID;
    private String groupName;
    private String SubgroupName;
    private String groupNo;
    private String siteNo;
    private String packageID;
    private String prodTypeCode;
    private String employeeFlag;
    private String externalID;
    private Date hireDate;
    private String divisionCode;
    private String offerCode;
    private String reportingUnit;
    private Date contractEffectiveDate;
    private Date contractEndDate;
    private Date subgroupEffectiveDate;
    private Date subgroupEndDate;
    private Date packageEffectiveDate;
    private Date packageEndDate;
    private Date programEffectiveDate;
    private Date programEndDate;
    private Date loadDate;
    private Date processDate;
    public BaselineHistory() {
        super();
    }

    public Date getContractEffectiveDate() {
        return contractEffectiveDate;
    }

    public void setContractEffectiveDate(Date contractEffectiveDate) {
        this.contractEffectiveDate = contractEffectiveDate;
    }

    public Date getContractEndDate() {
        return contractEndDate;
    }

    public void setContractEndDate(Date contractEndDate) {
        this.contractEndDate = contractEndDate;
    }

    public Integer getContractNo() {
        return contractNo;
    }

    public void setContractNo(Integer contractNo) {
        this.contractNo = contractNo;
    }

    public Integer getGroupID() {
        return groupID;
    }

    public void setGroupID(Integer groupID) {
        this.groupID = groupID;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public String getGroupNo() {
        return groupNo;
    }

    public void setGroupNo(String groupNo) {
        this.groupNo = groupNo;
    }

    public Date getLoadDate() {
        return loadDate;
    }

    public void setLoadDate(Date loadDate) {
        this.loadDate = loadDate;
    }

    public Date getPackageEffectiveDate() {
        return packageEffectiveDate;
    }

    public void setPackageEffectiveDate(Date packageEffectiveDate) {
        this.packageEffectiveDate = packageEffectiveDate;
    }

    public Date getPackageEndDate() {
        return packageEndDate;
    }

    public void setPackageEndDate(Date packageEndDate) {
        this.packageEndDate = packageEndDate;
    }

    public Integer getPersonID() {
        return personID;
    }

    public void setPersonID(Integer personID) {
        this.personID = personID;
    }

    public Date getProcessDate() {
        return processDate;
    }

    public void setProcessDate(Date processDate) {
        this.processDate = processDate;
    }

    public String getSiteNo() {
        return siteNo;
    }

    public void setSiteNo(String siteNo) {
        this.siteNo = siteNo;
    }

    public Date getSubgroupEffectiveDate() {
        return subgroupEffectiveDate;
    }

    public void setSubgroupEffectiveDate(Date subgroupEffectiveDate) {
        this.subgroupEffectiveDate = subgroupEffectiveDate;
    }

    public Date getSubgroupEndDate() {
        return subgroupEndDate;
    }

    public void setSubgroupEndDate(Date subgroupEndDate) {
        this.subgroupEndDate = subgroupEndDate;
    }

    public Integer getSubgroupID() {
        return SubgroupID;
    }

    public void setSubgroupID(Integer subgroupID) {
        SubgroupID = subgroupID;
    }

    public String getSubgroupName() {
        return SubgroupName;
    }

    public void setSubgroupName(String subgroupName) {
        SubgroupName = subgroupName;
    }

    public String getPackageID() {
        return packageID;
    }

    public void setPackageID(String packageID) {
        this.packageID = packageID;
    }

    public String getMemberID() {
        return memberID;
    }

    public void setMemberID(String memberID) {
        this.memberID = memberID;
    }

    public Date getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(Date birthDate) {
        this.birthDate = birthDate;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getRelationship() {
        return relationship;
    }

    public void setRelationship(String relationship) {
        this.relationship = relationship;
    }

    public Date getProgramEffectiveDate() {
        return programEffectiveDate;
    }

    public void setProgramEffectiveDate(Date programEffectiveDate) {
        this.programEffectiveDate = programEffectiveDate;
    }

    public Date getProgramEndDate() {
        return programEndDate;
    }

    public void setProgramEndDate(Date programEndDate) {
        this.programEndDate = programEndDate;
    }

    public final String getProdTypeCode() {
        return prodTypeCode;
    }

    public final void setProdTypeCode(String prodTypeCode) {
        this.prodTypeCode = prodTypeCode;
    }

    public final String getEmployeeFlag() {
        return employeeFlag;
    }

    public final void setEmployeeFlag(String employeeFlag) {
        this.employeeFlag = employeeFlag;
    }

    public final String getExternalID() {
        return externalID;
    }

    public final void setExternalID(String externalID) {
        this.externalID = externalID;
    }

    public final String getDivisionCode() {
        return divisionCode;
    }

    public final void setDivisionCode(String divisionCode) {
        this.divisionCode = divisionCode;
    }

    public final String getOfferCode() {
        return offerCode;
    }

    public final void setOfferCode(String offerCode) {
        this.offerCode = offerCode;
    }

    public final String getReportingUnit() {
        return reportingUnit;
    }

    public final void setReportingUnit(String reportingUnit) {
        this.reportingUnit = reportingUnit;
    }

    public final Date getHireDate() {
        return hireDate;
    }

    public final void setHireDate(Date hireDate) {
        this.hireDate = hireDate;
    }


}


