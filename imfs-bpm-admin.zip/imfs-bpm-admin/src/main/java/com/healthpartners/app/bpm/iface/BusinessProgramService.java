package com.healthpartners.app.bpm.iface;

import com.healthpartners.app.bpm.dto.*;
import com.healthpartners.app.bpm.exception.BPMException;
import org.springframework.dao.DataAccessException;

import java.io.IOException;
import java.sql.Date;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public interface BusinessProgramService {
    Collection<Activity> selectActivities() throws BPMException, DataAccessException;
    Collection<Activity> selectAllActivities() throws BPMException, DataAccessException;

    Collection<Activity> selectExpiredActivities() throws BPMException, DataAccessException;

    Collection<UserAccess> getUserAccessList(String lUserName) throws BPMException, DataAccessException;

    LookUpValueCode getDatabaseEnvironment() throws BPMException, DataAccessException;

    Activity selectActivity(int activityId) throws BPMException, DataAccessException;

    int deleteActivity(int activityId) throws BPMException, DataAccessException;

    Collection<LookUpValueCode> getActivityTypeCodes() throws BPMException, DataAccessException;

    LookUpValueCode getActivityTypeCodeById(Integer id) throws BPMException, DataAccessException;

    int updateActivity(Activity activity) throws BPMException, DataAccessException;

    Collection<Activity> getActivities() throws BPMException, DataAccessException;

    Collection<String> getAllStartDates() throws BPMException, DataAccessException;

    Collection<EmployerGroup> getGroupsByName(String pGroupName) throws BPMException, DataAccessException;

    Collection<EmployerGroup> getAllGroupSites(String pGroupNo) throws BPMException, DataAccessException;

    Collection<LookUpValueCode> getExemptionTypeCodes() throws BPMException, DataAccessException;

    Collection<ExemptionHistory> getExemptionHistory(String pGroupNo
            , java.sql.Date pProgramEffectiveDate
            , String pSiteNo
            , String pExemptionTypeCode
            , String pContractNo
            , String pMemberNo
            , java.sql.Date pExemptionFromDate
            , java.sql.Date pExemptionToDate)
            throws BPMException, DataAccessException;

    Collection<BusinessProgram> getActiveNWithdrawnBusinessPrograms(String pGroupNo, String pSiteNo, Integer pGroupID, Date pQualificationStartDate)
            throws BPMException, DataAccessException;

    Collection<EmployerGroup> getGroups(String pGroupNumber) throws BPMException, DataAccessException;

    Collection<EmployerGroup> getSubGroups(Integer pGroupID) throws BPMException, DataAccessException;

    Collection<ProgramType> getProgramTypes() throws BPMException, DataAccessException;

    ProgramType getProgramTypeByTypeID(String programTypeCode) throws BPMException, DataAccessException;

    Collection<LookUpValueCode> getProgramSpecialReportHandlingCodes() throws BPMException, DataAccessException;

    Collection<LookUpValueCode> getParticipationCodes() throws BPMException, DataAccessException;

    Collection<EligibleActivity> getEligibleActivities(Integer programID) throws BPMException, DataAccessException;

    Collection<Activity> getAvailableActivities(Integer programID) throws BPMException, DataAccessException;

    Collection<LookUpValueCode> getProgramActivationCodes() throws BPMException, DataAccessException;

    Collection<QualificationCheckmark> getQualificationCheckmarks() throws BPMException, DataAccessException;

    int updateBusinessProgram(BusinessProgram pBusinessProgram, String lUserID) throws BPMException, DataAccessException;

    void updateEmployerGroupSite(BusinessProgram pBusinessProgram, String lUserID) throws BPMException, DataAccessException;

    void deleteEmptyBusinessProgram(Integer pProgramID)
            throws BPMException, DataAccessException, SQLIntegrityConstraintViolationException;

    Collection<BusinessProgram> getActiveBusinessPrograms(String pGroupNo, Date pQualificationStartDate)
            throws BPMException, DataAccessException;

//    int updateAllGroupSiteMembers(Integer pProcessID, Integer pProgramID) throws BPMException, DataAccessException, IOException;

    BusinessProgram getBusinessProgram(Integer pProgramID, boolean all) throws BPMException, DataAccessException;

    Collection<EmployerGroup> getParticipatingSubGroups(Integer pGroupID) throws BPMException, DataAccessException;

    Collection<BusinessProgram> getActiveBusinessPrograms(String pGroupNo, String pSiteNo, Date pQualificationStartDate) throws BPMException, DataAccessException;

    void insertEligibleActivities(ArrayList<EligibleActivity> pEligibleActivities, String lUserID) throws BPMException, DataAccessException;

    Collection<ProgramIncentiveOption> getProgramIncentiveOptions(Integer programID) throws BPMException, DataAccessException;

    Collection<ActivityIncentiveRequirement> getProgramActivityIncentiveRequirements(Integer programID, Integer incentiveOptionID) throws BPMException, DataAccessException;

    Collection<ProgramContributionGrid> getProgramContributionGrids(Integer pProgramIncentiveOptionID) throws BPMException, DataAccessException;

    int updateProgramIncentiveOption(ArrayList<ProgramIncentiveOption> pProgramIncentiveOptions, Integer pBusinessProgramID, String pUserID) throws BPMException, DataAccessException;

    int updateProgramContributionGrid(ProgramContributionGrid lProgramContributionGrid, String pModifyUserID) throws BPMException, DataAccessException;

    Collection<AdditionalInformation> getAdditionalInfos(Integer programID) throws BPMException, DataAccessException;

    void deleteInsertAdditionalInfos(ArrayList<AdditionalInformation> pAdditionalInfos, String pUserID) throws BPMException, DataAccessException;

    Collection<AuthCode> getExtendedAuthCodes(Integer pProgramID) throws BPMException, DataAccessException;

    void updateExtendedAuthCode(AuthCode pAuthCode, String pUserID) throws BPMException, DataAccessException;

    ArrayList<ProgramCheckmark> getProgramCheckmarks(Integer pProgramID) throws BPMException, DataAccessException;

    int updateProgramCheckmarks(ArrayList<ProgramCheckmark> pProgramCheckmarks, Integer pBusinessProgramID, String pModifyUserID) throws BPMException, DataAccessException;

    int updateAllGroupSiteMembers(Integer pProcessID, Integer pProgramID) throws BPMException, DataAccessException, IOException;

    Collection<BusinessProgram> getProgramTemplates(Integer pProgramID) throws BPMException, DataAccessException;

    Collection<ProgramActivityIncentiveSummary> getProgramActivityIncentivesSummaryWithRequirements(Integer programID) throws BPMException, DataAccessException;

    Collection<CheckmarkRequirement> getCheckmarkRequirements(Integer pQualificationCheckmarkID) throws BPMException, DataAccessException;

    Collection<ParticipationGroup> getParticipationGroups() throws BPMException, DataAccessException;

    Collection<IncentivePackageRuleGroup> getIncentivePackageRuleGroups(Integer pProgramID) throws BPMException, DataAccessException;

    Collection<BenefitPackage> getBenefitPackages(Integer pBusinessProgramID) throws BPMException, DataAccessException;

    Collection<ProgramChangeLog> getBusinessProgramChangeLog(Integer pProgramID) throws DataAccessException;

    Collection<ProgramPackage> getProgramPackages() throws BPMException, DataAccessException;

    Integer getContractStatusCount(String pContractStatus, Integer pBusinessProgramID) throws DataAccessException;

    Collection<BusinessProgram> getBusinessPrograms(Integer pGroupID, Integer pSubgroupID) throws BPMException, DataAccessException;

    Collection<BusinessProgram> getBusinessPrograms(Date pEffectiveDate, Integer pGroupID, Integer pSubgroupID) throws BPMException, DataAccessException;

    Collection<EmployerGroup> getBusinessProgramInSameYear(Integer pBusinessProgramID) throws BPMException, DataAccessException;

    void saveEligibleActivitiesToSites(BusinessProgram pBusinessProgram, ArrayList<EligibleActivity> pEligibleActivities, String pUserID, Collection<EmployerGroup> pEmployerGroups) throws BPMException, DataAccessException;

    Collection<LookUpValueCode> getIncentiveOverrideCodeTypes() throws BPMException, DataAccessException;

    Collection<PackageActivity> getPackageActivities(Integer pPackageID) throws BPMException, DataAccessException;

    boolean isEligibleActivityUsedByParticipant(EligibleActivity pEligibleActivity) throws BPMException, DataAccessException;

    int deleteEligibleActivityByStartDate(EligibleActivity pEligibleActivity) throws BPMException, DataAccessException;

    void deleteInsertEligibleActivity(Integer lBusinessProgramID, ArrayList<EligibleActivity> pEligibleActivities, String pUserID) throws BPMException, DataAccessException;

    void saveEligibleActivitiesAllSites(BusinessProgram pBusinessProgram, ArrayList<EligibleActivity> pEligibleActivities, String pUserID) throws BPMException, DataAccessException;

    Collection<IncentiveOption> getIncentiveOptions() throws BPMException, DataAccessException;

    Collection<IncentiveOption> getActiveIncentiveOptions() throws BPMException, DataAccessException;

    Collection<LookUpValueCode> getIncentiveOptionStatusCodes() throws BPMException, DataAccessException;

    Collection<LookUpValueCode> getIncentiveFulfillTypeCodes() throws BPMException, DataAccessException;

    Collection<LookUpValueCode> getIncentiveReportNameCodeTypes() throws BPMException, DataAccessException;

    Collection<LookUpValueCode> getIncentiveStatusCodes() throws BPMException, DataAccessException;

    Collection<LookUpValueCode> getIncentiveEnrollmentRuleCodes() throws BPMException, DataAccessException;

    Collection<LookUpValueCode> getRewardRunFrequencyTypes() throws BPMException, DataAccessException;

    Collection<LookUpValueCode> getDeliveryInfoTypes() throws BPMException, DataAccessException;

    ArrayList<QualificationCheckmark> getAvailableCheckmarks(Integer pProgramID) throws BPMException, DataAccessException;

    Collection<PersonRelationshipCode> getPersonRelationshipCodes() throws BPMException, DataAccessException;

    int deleteProgramCheckmark(Integer pProgramCheckmarkID) throws BPMException, DataAccessException;

    void saveProgramCheckmarksToAllSites(ArrayList<ProgramCheckmark> pProgramCheckmarks, BusinessProgram pBusinessProgram, String pModifyUserID) throws BPMException, DataAccessException;

    void saveProgramCheckmarksToSites(BusinessProgram pBusinessProgram, ArrayList<ProgramCheckmark> pProgramCheckmarks, String pUserID, Collection<EmployerGroup> pEmployerGroups) throws BPMException, DataAccessException;

    void deleteProgramIncentiveOption(Integer pProgramIncentiveOptionID) throws BPMException, SQLIntegrityConstraintViolationException, DataAccessException, Exception;

    void saveProgramIncentiveOptionsAllSites(BusinessProgram pBusinessProgram, ArrayList<ProgramIncentiveOption> pProgramIncentiveOptions, String pUserID) throws BPMException, DataAccessException;

    void saveProgramIncentiveOptionsToSites(BusinessProgram pBusinessProgram, ArrayList<ProgramIncentiveOption> pProgramIncentiveOptions, Collection<EmployerGroup> pEmployerGroups, String pUserID) throws BPMException, DataAccessException;

    Collection<LookUpValueCode> getAdditionalInfoFixedNames() throws BPMException, DataAccessException;

    void saveAdditionalInfoToAllSites(BusinessProgram pBusinessProgram, Collection<AdditionalInformation> pAdditionalInfos, String pUserID) throws BPMException, DataAccessException;

    void deleteAdditionalInfosForGroup(BusinessProgram pBusinessProgram) throws BPMException, DataAccessException;

    void saveAdditionalInfoToSites(BusinessProgram pBusinessProgram, Collection<AdditionalInformation> pAdditionalInfos, Collection<EmployerGroup> pEmployerGroups, String pUserID) throws BPMException, DataAccessException;

    Collection<LookUpValueCode> getActivityIncentiveTypeCodes() throws BPMException, DataAccessException;

    Collection<LookUpValueCode> getActivityIncentiveStatusCodes() throws BPMException, DataAccessException;

    ArrayList<BPMCollection> getAllCollections() throws BPMException, DataAccessException;

    boolean isOneOrMoreRequirementsRegisteredToProgramTierContribution(Integer programID, Integer incentiveOptionID, String incentedStatusTypeCode) throws BPMException, DataAccessException;

    boolean isOneOrMoreRequirementsRegisteredToPersonProgramStatus(ProgramIncentiveOption lProgramIncentiveOption) throws BPMException, DataAccessException;

    boolean isActivityRequirementRegisteredToProgramTierContribution(ActivityIncentiveRequirement lActivityIncentiveRequirement) throws BPMException, DataAccessException;

    boolean isActivityRequirementRegisteredToPersonProgramActivityStatus(ActivityIncentiveDetail lActivityIncentiveDetail) throws BPMException, DataAccessException;

    ArrayList<Activity>  getActivityDefinitionsByType(int activityTypeID);

    int updateActivityIncentiveRequirement(ActivityIncentiveRequirement pActivityIncentiveRequirement, String pUserID) throws BPMException, DataAccessException;

    int updateActivityIncentiveDetailDirectly(ActivityIncentiveRequirement pActivityIncentiveRequirement, String pUserID) throws BPMException, DataAccessException;

    int deleteActivityIncentiveRequirement(Integer pProgramID, Integer pIncentiveOptionID) throws BPMException, DataAccessException;

    void saveProgramIncentiveActivitiesAllSites(BusinessProgram pBusinessProgram, ProgramIncentiveOption pProgramIncentiveOption, String pUserID) throws BPMException, DataAccessException;

    void saveProgramIncentiveActivitiesToSites(BusinessProgram pBusinessProgram, ProgramIncentiveOption pProgramIncentiveOption, Collection<EmployerGroup> pEmployerGroups, String pUserID) throws BPMException, DataAccessException;

    Collection<LookUpValueCode> getBenefitContractTypes() throws BPMException, DataAccessException;

    Collection<ContributionGridBenefitContractTypeRelationship> getContributionGridBenefitContractTypeRelationships(Integer benefitContractTypeID) throws DataAccessException;

    LookUpValueCode getBenefitContractTypeById(Integer id) throws BPMException, DataAccessException;

    int deleteProgramContributionGrids(Collection<ProgramContributionGrid> lremovedProgramContributionGrids) throws BPMException, DataAccessException;

    LookUpValueCode getContributionAmountLimit(String value) throws BPMException, DataAccessException;

    ArrayList<ProgramContributionTier> getProgramContributionIncentiveTiers(Integer programID, Integer incentiveOptionID, String incentedStatusTypeCode) throws BPMException, DataAccessException;

    ArrayList<ContributionTierBenefitContractType> getAssignedContributionTierBenefitContractTypes(Integer pTierTypeID, boolean isAllowRelationshipSelfOnly) throws BPMException, DataAccessException;

    ArrayList<ContributionTier> getAllContributionTiers() throws BPMException, DataAccessException;

    int deleteProgramContributionTiers(Collection<ProgramContributionTier> lremovedProgramContributionTiers) throws BPMException, DataAccessException;

    int updateProgramContributionTier(Integer activityIncentiveID, Integer groupID, Integer groupRequiredID, Integer qualificationCheckmarkDetailID, ProgramContributionTier lProgramContributionTier, String pModifyUserID) throws BPMException, DataAccessException;

    void saveProgramContributionGridsToSites(BusinessProgram pBusinessProgram
            , ProgramIncentiveOption pProgramIncentiveOptionSource
            , Collection<EmployerGroup> pEmployerGroups
            , ArrayList<ProgramContributionGrid> pProgramContributionGridsSource
            , String pUserID)
            throws BPMException, DataAccessException;

    Collection<LookUpValueCode> getExtendedAuthCodeTypes() throws BPMException, DataAccessException;

    void deleteExtendedAuthCodes(Integer pProgramID) throws BPMException, DataAccessException;

    void saveExtendedAuthCodesToAllSites(BusinessProgram pBusinessProgram, Collection<AuthCode> pAuthCodes, String pUserID) throws BPMException, DataAccessException;

    void saveExtendedAuthCodesToSites(BusinessProgram pBusinessProgram, Collection<AuthCode> pAuthCodes, Collection<EmployerGroup> pEmployerGroups, String pUserID) throws BPMException, DataAccessException;

    int insertProgramChangeLog(ProgramChangeLog pProgramChangeLog, String pUserID) throws DataAccessException;

    void saveChangeLogToAllSites(BusinessProgram pBusinessProgram, String pChangeLogText, String pUserID) throws BPMException, DataAccessException;


    Collection<Risk> selectRisks() throws BPMException, DataAccessException;

    List<ParticipationGroupRequirement> getParticipationGroupRequirements(Integer lParticipationGroupID) throws BPMException, DataAccessException;

    ArrayList<CollectionActivity> getCollectionActivities(Integer pCollectionID) throws BPMException, DataAccessException;

    ArrayList<ExtEmployerActivity> getExtEmployerActivities() throws DataAccessException;

    Collection<EmployerGroup> getAllBPMGroups() throws BPMException, DataAccessException;

    ArrayList<GroupOverride> getGroupOverrideByGroupNumber(String groupNumber) throws BPMException;

    ArrayList<GroupOverride> getGroupOverrideByGroupID(Integer groupID) throws BPMException;

    Collection<GroupOverride> getGroupOverridesAll() throws BPMException;

    ArrayList<GroupOverride> getAssignedSitesForGroupSiteException(String groupNumber) throws BPMException;

    ArrayList<GroupOverride> getAvailableSitesForGroupSiteException(String groupNumber) throws BPMException;

    Collection<RejectedPerson> getEmployerRecycle(Integer activityId,
                                                  String firstName, String lastName, Date lActivityDate, Date recycleStatusDate, Integer recycleStatusId)
            throws DataAccessException;

    RejectedPerson getEmployerRecycle(Integer recycleStatusId) throws BPMException, DataAccessException;
    void updateEmployerRecycle(RejectedPerson pRejectedPerson, String pUserID)
            throws BPMException, DataAccessException;

    Collection<QualificationCheckmark> getExpiredQualificationCheckmarks() throws BPMException, DataAccessException;

    int deleteQualificationCheckmark(Integer pQualificationCheckmarkID) throws BPMException, DataAccessException;

    Collection<LookUpValueCode> getQualificationStatusCodes() throws BPMException, DataAccessException;

    Collection<Activity> getActivitiesWithMemberAndTransactionDate(String memberId, Date transactionDate)
            throws BPMException, DataAccessException;

    Collection<EmployerGroup> getBPMGroupsForMemberAndTransactionDate(String memberId, Date transactionDate)
            throws BPMException, DataAccessException;

    int updateQualificationCheckmark(QualificationCheckmark pQualificationCheckmark, String pModifyUserID) throws BPMException, DataAccessException;

    public Collection<LookUpValueCode> getMemberStatusCodes()
            throws BPMException, DataAccessException;

    public Collection<LookUpValueCode> getContractStatusCodes()
            throws BPMException, DataAccessException;
}
