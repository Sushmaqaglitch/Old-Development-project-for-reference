/**
 * 
 */
package com.healthpartners.app.bpm.form;


import com.healthpartners.app.bpm.dto.LookUpValueCode;

import java.util.ArrayList;
import java.util.Collection;

/**
 * @author jxbourbour
 *
 */
public class ActivityIncentiveContributionStatusSearchForm extends BaseForm {

	private String groupNumber;
	private String groupName;
	private String siteNumber;
	private String effectiveDate;
	private String incentedDate;
	private String contractNumber;
	private String memberNumber;
	private String productType;
	private String reportType;
	private Collection<LookUpValueCode> luvReportTypes = new ArrayList<>();
	private Collection<LookUpValueCode> luvProductTypes = new ArrayList<>();
	private String whichList;

	public String getGroupNumber() {
		return groupNumber;
	}

	public void setGroupNumber(String groupNumber) {
		this.groupNumber = groupNumber;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public String getSiteNumber() {
		return siteNumber;
	}

	public void setSiteNumber(String siteNumber) {
		this.siteNumber = siteNumber;
	}

	public String getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(String effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public String getIncentedDate() {
		return incentedDate;
	}

	public void setIncentedDate(String incentedDate) {
		this.incentedDate = incentedDate;
	}

	public String getContractNumber() {
		return contractNumber;
	}

	public void setContractNumber(String contractNumber) {
		this.contractNumber = contractNumber;
	}

	public String getMemberNumber() {
		if (memberNumber != null) {
			return memberNumber.trim();
		}
		return memberNumber;
	}

	public void setMemberNumber(String memberNumber) {
		this.memberNumber = memberNumber;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	public String getReportType() {
		return reportType;
	}

	public void setReportType(String reportType) {
		this.reportType = reportType;
	}

	public Collection<LookUpValueCode> getLuvReportTypes() {
		return luvReportTypes;
	}

	public void setLuvReportTypes(Collection<LookUpValueCode> luvReportTypes) {
		this.luvReportTypes = luvReportTypes;
	}

	public Collection<LookUpValueCode> getLuvProductTypes() {
		return luvProductTypes;
	}

	public void setLuvProductTypes(Collection<LookUpValueCode> luvProductTypes) {
		this.luvProductTypes = luvProductTypes;
	}

	public String getWhichList() {
		return whichList;
	}

	public void setWhichList(String whichList) {
		this.whichList = whichList;
	}
}
