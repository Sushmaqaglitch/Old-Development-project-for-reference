package com.healthpartners.app.bpm.dto;


public class RewardCardFulfillmentReportHistStatus {

    private Integer rewardTransHistID;
    private String rewardStatus;
    private java.sql.Date rewardStatusDate;
    private java.sql.Date lastRunDate;

    public Integer getRewardTransHistID() {
        return rewardTransHistID;
    }

    public void setRewardTransHistID(Integer rewardTransHistID) {
        this.rewardTransHistID = rewardTransHistID;
    }

    public String getRewardStatus() {
        return rewardStatus;
    }

    public void setRewardStatus(String rewardStatus) {
        this.rewardStatus = rewardStatus;
    }

    public java.sql.Date getRewardStatusDate() {
        return rewardStatusDate;
    }

    public void setRewardStatusDate(java.sql.Date rewardStatusDate) {
        this.rewardStatusDate = rewardStatusDate;
    }

    public java.sql.Date getLastRunDate() {
        return lastRunDate;
    }

    public void setLastRunDate(java.sql.Date lastRunDate) {
        this.lastRunDate = lastRunDate;
    }


}
