package com.healthpartners.app.bpm.dao;

import com.healthpartners.app.bpm.dto.ParticipationGroup;
import com.healthpartners.app.bpm.dto.ParticipationGroupDetail;
import com.healthpartners.app.bpm.dto.ParticipationGroupRequirement;
import com.healthpartners.app.bpm.exception.BPMException;
import org.springframework.dao.DataAccessException;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public interface ParticipationGroupDAO {
    Collection<ParticipationGroup> getParticipationGroups() throws BPMException, DataAccessException;

    List<ParticipationGroupRequirement> getParticipationGroupRequirements(Integer lParticipationGroupID) throws BPMException, DataAccessException;

    //Produces warnings during compile time to quickly identify typos or API changes
    ArrayList<ParticipationGroupDetail> getParticipationGroupDetails(ParticipationGroupRequirement requirement)
            throws BPMException, DataAccessException;
}
