package com.healthpartners.app.bpm.dao;

import com.healthpartners.app.bpm.dto.Risk;
import com.healthpartners.app.bpm.exception.BPMException;
import jakarta.annotation.PostConstruct;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.jdbc.support.incrementer.DataFieldMaxValueIncrementer;
import org.springframework.jdbc.support.incrementer.OracleSequenceMaxValueIncrementer;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Collection;



/**
 * 
 * @author jxbourbour
 *
 */
@Repository
@Transactional(timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
public class RiskDAOJdbc extends JdbcDaoSupport implements RiskDAO 
{
	private static final String selectRiskByName = """
 	SELECT risk_id, risk_nm, risk_desc, hold_duration, risk_grp_cd_id, lu_val FROM risk, luv WHERE risk_nm = ? AND risk_grp_cd_id = lu_id
	""";
	private static final String selectRiskByGroupName = """
 	SELECT risk_id, risk_nm, risk_desc, hold_duration, risk_grp_cd_id, lu_val FROM risk, luv WHERE lu_val = ? AND risk_grp_cd_id = lu_id
	""";
	private static final String selectAllRisks = """
 	SELECT risk_id, risk_nm, risk_desc, hold_duration, risk_grp_cd_id, lu_val FROM risk, luv WHERE risk_grp_cd_id = lu_id order by risk_nm
	""";
	private static final String selectRiskById = """
 	SELECT risk_id, risk_nm, risk_desc, hold_duration, risk_grp_cd_id, lu_val, insert_usr FROM risk, luv WHERE risk_id = ?
	""";
	private static final String insertRisk = """
 	INSERT INTO RISK (RISK_ID, RISK_NM, RISK_DESC, HOLD_DURATION, RISK_GRP_CD_ID, INSERT_TS, INSERT_USR) VALUES (?, ?, ?, ?, ?, SYSDATE, ?)
	""";
	private static final String deleteRisk = """
 	DELETE FROM RISK WHERE RISK_ID = ?
	""";
	private static final String updateRisk = """
 	UPDATE RISK SET RISK_NM = ?, RISK_DESC = ?, HOLD_DURATION = ?, RISK_GRP_CD_ID = ?, MODIFY_TS = SYSDATE, MODIFY_USR = ? WHERE RISK_ID = ?
	""";

	private final DataSource dataSource;

	/*
	 * SQL sequences
	 */
	private DataFieldMaxValueIncrementer riskIdIncrementer;
	private final static String RISK_SEQ = "RISK_SEQ";

	public RiskDAOJdbc (DataSource dataSource) {
		this.dataSource = dataSource;
	}

	@PostConstruct
	private void initialize() {
		setDataSource(dataSource);
		riskIdIncrementer = new OracleSequenceMaxValueIncrementer(dataSource, RISK_SEQ);
	}

	@Override
	public Risk getRiskById(Integer riskId) {
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[]{riskId};
		int types[] = new int[]{Types.INTEGER};
		final ArrayList<Risk> lRisks = new ArrayList<Risk>();

		template.query(selectRiskById, params, types,
				new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						Risk lRisk = new Risk();

						lRisk.setRiskID(rs.getInt("risk_id"));
						lRisk.setName(rs.getString("risk_nm"));
						lRisk.setDescription(rs.getString("risk_desc"));
						lRisk.setHoldDuration(Integer.toString(rs.getInt("hold_duration")));
						lRisk.setGroupCodeID(rs.getInt("risk_grp_cd_id"));
						lRisk.setUserId(rs.getString("insert_usr"));

						lRisks.add(lRisk);
					}
				});

		return lRisks.get(0);
	}

	@Override
	public Risk getRiskByName(String pRiskName) {
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[]{pRiskName};
		int types[] = new int[]{Types.VARCHAR};
		final ArrayList<Risk> lRisks = new ArrayList<Risk>();

		template.query(selectRiskByName, params, types,
				new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						Risk lRisk = new Risk();

						lRisk.setRiskID(rs.getInt("risk_id"));
						lRisk.setName(rs.getString("risk_nm"));
						lRisk.setDescription(rs.getString("risk_desc"));
						lRisk.setHoldDuration(Integer.toString(rs.getInt("hold_duration")));
						lRisk.setGroupCodeID(rs.getInt("risk_grp_cd_id"));
						lRisk.setGroupCodeVal(rs.getString("lu_val"));
						lRisks.add(lRisk);
					}
				});

		return lRisks.get(0);
	}

	/**
	 * @param pRiskGroupName
	 * @return
	 */
	@Override
	public Risk getRiskByGroupName(String pRiskGroupName) {
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[]{pRiskGroupName};
		int types[] = new int[]{Types.VARCHAR};
		final ArrayList<Risk> lRisks = new ArrayList<Risk>();

		template.query(selectRiskByGroupName, params, types,
				new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						Risk lRisk = new Risk();

						lRisk.setRiskID(rs.getInt("risk_id"));
						lRisk.setName(rs.getString("risk_nm"));
						lRisk.setDescription(rs.getString("risk_desc"));
						lRisk.setHoldDuration(Integer.toString(rs.getInt("hold_duration")));
						lRisk.setGroupCodeID(rs.getInt("risk_grp_cd_id"));
						lRisk.setGroupCodeVal(rs.getString("lu_val"));
						lRisks.add(lRisk);
					}
				});

		return lRisks.get(0);
	}

	@Override
	public Collection<Risk> getAllRisks() {
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = null;
		int types[] = null;
		final ArrayList<Risk> lRisks = new ArrayList<Risk>();

		template.query(selectAllRisks, params, types,
				new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						Risk lRisk = new Risk();

						lRisk.setRiskID(rs.getInt("risk_id"));
						lRisk.setName(rs.getString("risk_nm"));
						lRisk.setDescription(rs.getString("risk_desc"));
						lRisk.setHoldDuration(Integer.toString(rs.getInt("hold_duration")));
						lRisk.setGroupCodeID(rs.getInt("risk_grp_cd_id"));
						lRisk.setGroupCodeVal(rs.getString("lu_val"));
						lRisks.add(lRisk);
					}
				});

		return lRisks;
	}

	@Transactional(timeout = 300, rollbackFor = {DataAccessException.class, BPMException.class})
	@Override
	public int updateRisk(Risk lRisk) throws DataAccessException {
		if (lRisk.getRiskID() == null || lRisk.getRiskID() == 0) {
			return this.insertRisk(lRisk);
		}

		String riskName = (lRisk.getName() != null) ? lRisk.getName() : null;
		String riskDesc = (lRisk.getDescription() != null) ? lRisk.getDescription() : null;
		Integer riskHoldDuration = (lRisk.getHoldDuration() != null) ? Integer.valueOf(lRisk.getHoldDuration()) : null;
		Integer riskGroupCodeID = (lRisk.getGroupCodeID() != null) ? lRisk.getGroupCodeID() : null;
		String riskUserId = (lRisk.getUserId() != null) ? lRisk.getUserId() : null;
		Integer riskID = lRisk.getRiskID();

		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[]{
				riskName,
				riskDesc,
				riskHoldDuration,
				riskGroupCodeID,
				riskUserId,
				riskID

		};
		int types[] = new int[]{Types.VARCHAR, Types.VARCHAR,
				Types.INTEGER, Types.INTEGER, Types.VARCHAR, Types.INTEGER};


		int rowInserted = template.update(updateRisk, params, types);
		return rowInserted;

	}

	@Transactional(timeout = 300, rollbackFor = {DataAccessException.class, BPMException.class})
	@Override
	public int deleteRisk(Integer riskID) throws DataAccessException {
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[]{riskID};
		int types[] = new int[]{Types.INTEGER};
		return template.update(deleteRisk, params, types);
	}

	/**
	 * private method - internal use
	 *
	 * @param lRisk
	 * @return boolean
	 * @throws DataAccessException
	 */
	@Transactional(timeout = 300, rollbackFor = {DataAccessException.class, BPMException.class})
	@Override
	public int insertRisk(Risk lRisk) throws DataAccessException {
		//userID value temporary until asciegi id is used
		/*
		 * SQL sequences
		 */
		Long riskIdSeq = riskIdIncrementer.nextLongValue();
		lRisk.setRiskID(riskIdSeq.intValue());
		JdbcTemplate template = getJdbcTemplate();


		Object params[] = new Object[]{
				lRisk.getRiskID(),
				lRisk.getName(),
				lRisk.getDescription(),
				lRisk.getHoldDuration(),
				lRisk.getGroupCodeID(),
				lRisk.getUserId(),
		};
		int types[] = new int[]{Types.INTEGER, Types.VARCHAR,
				Types.VARCHAR, Types.INTEGER, Types.INTEGER,
				Types.VARCHAR};
		int rowsInserted = template.update(insertRisk, params, types);

		return rowsInserted;
	}

}
