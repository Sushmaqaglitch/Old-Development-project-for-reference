/**
 *
 */
package com.healthpartners.app.bpm.form;

/**
 * @author tjquist
 *
 */
public class AddGroupSiteExceptionForm extends BaseForm {

    static final long serialVersionUID = 0L;

    private String groupID;
    private String groupNumber;
    private String groupName;

    public String getGroupID() {
        return groupID;
    }

    public void setGroupID(String groupID) {
        this.groupID = groupID;
    }

    public String getGroupNumber() {
        return groupNumber;
    }

    public void setGroupNumber(String groupNumber) {
        this.groupNumber = groupNumber;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

//	/**
//	 * Validate form values.
//	 *
//	 * @param mapping
//	 *            The mapping used to select this instance
//	 * @param request
//	 *            The servlet request we are processing
//	 * @return errors
//	 */
//	public ActionMessages validateAdd()
//	{
//		this.validateNotNull(groupNumber, "Group No text, or Group No selection");
//
//		return getActionMessages();
//	}

}
