/* $Id$ */

package com.healthpartners.app.bpm.dao;

import com.healthpartners.app.bpm.common.BPMAdminConstants;
import com.healthpartners.app.bpm.dto.LookUpValueCode;
import com.healthpartners.app.bpm.exception.BPMException;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jakarta.annotation.PostConstruct;
import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Collection;

/**
 * JDBC implementation of the LookUpValueDAO interface.
 * 
 * @author tjquist
 */
@Service
@Transactional(timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
public class LookUpValueDAOJdbc extends JdbcDaoSupport implements
		LookUpValueDAO {

	/*
	 * Generic Code SQL statements
	 */

	private static final String insertLUVCode = "INSERT INTO LUV (LU_ID, LU_GRP, LU_VAL, LU_DESC, LU_STATUS, INSERT_USER, LU_NUM, SORT_ORDER, LU_TXT ) VALUES (lu_id_seq.nextval, ?, ?, ?, ?, ?, ?, ?, ?)";

	private static final String updateLUVCode = "UPDATE LUV SET LU_GRP = ?, LU_VAL=?, LU_DESC = ?, LU_STATUS = ?, MODIFY_USER = ?, LU_NUM = ?, SORT_ORDER = ?, LU_TXT = ? WHERE LU_ID = ?";

	private static final String deleteLUVCode = "DELETE FROM LUV WHERE LU_GRP = ? AND LU_VAL = ?";

	private static final String getAllLUVCodes = "SELECT LU_ID, LU_GRP, LU_VAL, LU_DESC, LU_STATUS, LU_NUM, SORT_ORDER, LU_TXT FROM luv " +
			"WHERE LU_STATUS='ACTIVE' " +
			"ORDER BY LU_GRP, LU_VAL";

	private static final String getActiveLUVCodes = "SELECT LU_ID, LU_GRP, LU_VAL, LU_DESC, LU_STATUS, LU_NUM, SORT_ORDER, LU_TXT FROM luv WHERE LU_STATUS = ? ORDER BY LU_GRP, LU_VAL";

	private static final String getLUVCodeByValue = "SELECT LU_ID, LU_GRP, LU_VAL, LU_DESC, LU_STATUS, LU_NUM, SORT_ORDER, LU_TXT FROM luv WHERE LU_VAL = ? order by LU_GRP, LU_VAL asc";
	
	private static final String getLUVCodeByGroupNValue = "SELECT LU_ID, LU_GRP, LU_VAL, LU_DESC, LU_STATUS, LU_NUM, SORT_ORDER, LU_TXT FROM luv WHERE LU_GRP = ? AND LU_VAL = ? order by LU_GRP, LU_VAL asc";
	
	private static final String getLUVCodeById = "SELECT LU_ID, LU_GRP, LU_VAL, LU_DESC, LU_STATUS, LU_NUM, SORT_ORDER, LU_TXT FROM luv WHERE LU_ID = ?";

	private static final String getLUVCodesByGroup = "SELECT LU_ID, LU_GRP, LU_VAL, LU_DESC, LU_STATUS, LU_NUM, SORT_ORDER, LU_TXT FROM luv WHERE LU_GRP = ?\tAND LU_STATUS='ACTIVE' order by LU_GRP, LU_VAL asc";

	private final DataSource dataSource;

	public LookUpValueDAOJdbc (DataSource dataSource) {
		this.dataSource = dataSource;
	}


	@PostConstruct
	private void initialize() {
		setDataSource(dataSource);
	}

	@Override
	public int insertLUVCode(LookUpValueCode code) throws DataAccessException {
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] { code.getLuvGroup(), code.getLuvVal(),
				code.getLuvDesc(), code.getLuvStatus(),
				code.getLuvCreateUser(), code.getLuvNum(),
				code.getLuvSortOrder(), code.getLuvText() };
		int types[] = new int[] { Types.VARCHAR, Types.VARCHAR, Types.VARCHAR,
				Types.VARCHAR, Types.VARCHAR, Types.INTEGER, Types.INTEGER,
				Types.VARCHAR };
		return template.update(insertLUVCode, params, types);
	}

	@Override
	public int updateLUVCode(LookUpValueCode code) throws DataAccessException {
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] { code.getLuvGroup(), code.getLuvVal(),
				code.getLuvDesc(), code.getLuvStatus(),
				code.getLuvUpdateUser(), code.getLuvNum(),
				code.getLuvSortOrder(), code.getLuvText(), code.getLuvId() };
		int types[] = new int[] { Types.VARCHAR, Types.VARCHAR, 
				Types.VARCHAR, Types.VARCHAR, 
				Types.VARCHAR, Types.INTEGER, 
				Types.INTEGER, Types.VARCHAR, Types.INTEGER };
		return template.update(updateLUVCode, params, types);
	}

	@Override
	public int deleteLUVCode(String value) throws DataAccessException {
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] { value };
		int types[] = new int[] { Types.VARCHAR };
		return template.update(deleteLUVCode, params, types);
	}

	@Override
	public Collection<LookUpValueCode> getAllLUVCodes()
			throws DataAccessException {
		final ArrayList<LookUpValueCode> results = new ArrayList<LookUpValueCode>();
		JdbcTemplate template = getJdbcTemplate();
		template.query(getAllLUVCodes, new RowCallbackHandler() {
			public void processRow(ResultSet rs) throws SQLException {
				LookUpValueCode code = new LookUpValueCode();
				code.setLuvId(Integer.valueOf(rs.getInt(1)));
				code.setLuvGroup(rs.getString(2));
				code.setLuvVal(rs.getString(3));
				code.setLuvDesc(rs.getString(4));
				code.setLuvStatus(rs.getString(5));
				code.setLuvNum(rs.getObject(6) == null ? null : Integer.valueOf(rs
						.getInt(6)));
				code.setLuvSortOrder(rs.getObject(7) == null ? null
						: Integer.valueOf(rs.getInt(7)));
				code.setLuvText(rs.getString(8));
				results.add(code);
			}
		});
		return results;
	}

	@Override
	public Collection<LookUpValueCode> getActiveLUVCodes()
			throws DataAccessException {
		final ArrayList<LookUpValueCode> results = new ArrayList<LookUpValueCode>();
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] { BPMAdminConstants.ACTIVATE_STATUS };
		int types[] = new int[] { Types.VARCHAR };
		template.query(getActiveLUVCodes, params, types,
				new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						LookUpValueCode code = new LookUpValueCode();
						code.setLuvId(Integer.valueOf(rs.getInt(1)));
						code.setLuvGroup(rs.getString(2));
						code.setLuvVal(rs.getString(3));
						code.setLuvDesc(rs.getString(4));
						code.setLuvStatus(rs.getString(5));
						code.setLuvNum(rs.getObject(6) == null ? null
								: Integer.valueOf(rs.getInt(6)));
						code.setLuvSortOrder(rs.getObject(7) == null ? null
								: Integer.valueOf(rs.getInt(7)));
						code.setLuvText(rs.getString(8));
						results.add(code);
					}
				});
		return results;
	}

	@Override
	public LookUpValueCode getLUVCodeByValue(String value)
			throws DataAccessException {
		final ArrayList<LookUpValueCode> results = new ArrayList<LookUpValueCode>();

		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] { value };
		int types[] = new int[] { Types.VARCHAR };
		template.query(getLUVCodeByValue, params, types,
				new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						LookUpValueCode code = new LookUpValueCode();
						code.setLuvId(rs.getInt(1));
						code.setLuvGroup(rs.getString(2));
						code.setLuvVal(rs.getString(3));
						code.setLuvDesc(rs.getString(4));
						code.setLuvStatus(rs.getString(5));
						code.setLuvNum(rs.getObject(6) == null ? null
								: Integer.valueOf(rs.getInt(6)));
						code.setLuvSortOrder(rs.getObject(7) == null ? null
								: Integer.valueOf(rs.getInt(7)));
						code.setLuvText(rs.getString(8));						
						results.add(code);
					}
				});

		LookUpValueCode dto = null;
		if (results.size() > 0) {
			dto = (LookUpValueCode) results.get(0);
		}
		return dto;
	}

	@Override
	public LookUpValueCode getLUVCodeByGroupNValue(String group, String value)
			throws DataAccessException {
		final ArrayList<LookUpValueCode> results = new ArrayList<LookUpValueCode>();

		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] { group, value };
		int types[] = new int[] { Types.VARCHAR, Types.VARCHAR };
		template.query(getLUVCodeByGroupNValue, params, types,
				new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						LookUpValueCode code = new LookUpValueCode();
						code.setLuvId(rs.getInt(1));
						code.setLuvGroup(rs.getString(2));
						code.setLuvVal(rs.getString(3));
						code.setLuvDesc(rs.getString(4));
						code.setLuvStatus(rs.getString(5));
						code.setLuvNum(rs.getObject(6) == null ? null
								: Integer.valueOf(rs.getInt(6)));
						code.setLuvSortOrder(rs.getObject(7) == null ? null
								: Integer.valueOf(rs.getInt(7)));
						code.setLuvText(rs.getString(8));						
						results.add(code);
					}
				});

		LookUpValueCode dto = null;
		if (results.size() > 0) {
			dto = (LookUpValueCode) results.get(0);
		}
		return dto;
	}

	@Override
	public LookUpValueCode getLUVCodeById(Integer id)
			throws DataAccessException {
		final ArrayList<LookUpValueCode> results = new ArrayList<LookUpValueCode>();

		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] { id };
		int types[] = new int[] { Types.INTEGER };
		template.query(getLUVCodeById, params, types,
				new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						LookUpValueCode code = new LookUpValueCode();
						code.setLuvId(rs.getInt(1));
						code.setLuvGroup(rs.getString(2));
						code.setLuvVal(rs.getString(3));
						code.setLuvDesc(rs.getString(4));
						code.setLuvStatus(rs.getString(5));
						code.setLuvNum(rs.getObject(6) == null ? null
								: Integer.valueOf(rs.getInt(6)));
						code.setLuvSortOrder(rs.getObject(7) == null ? null
								: Integer.valueOf(rs.getInt(7)));
						code.setLuvText(rs.getString(8));						
						results.add(code);
					}
				});

		LookUpValueCode dto = null;
		if (results.size() > 0) {
			dto = (LookUpValueCode) results.get(0);
		}
		return dto;
	}

	@Override
	public Collection<LookUpValueCode> getLUVCodesByGroup(String group)
			throws DataAccessException {
		final ArrayList<LookUpValueCode> results = new ArrayList<LookUpValueCode>();

		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] { group };
		int types[] = new int[] { Types.VARCHAR };
		template.query(getLUVCodesByGroup, params, types,
				new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						LookUpValueCode code = new LookUpValueCode();
						code.setLuvId(rs.getInt(1));
						code.setLuvGroup(rs.getString(2));
						code.setLuvVal(rs.getString(3));
						code.setLuvDesc(rs.getString(4));
						code.setLuvStatus(rs.getString(5));
						code.setLuvNum(rs.getObject(6) == null ? null
								: Integer.valueOf(rs.getInt(6)));
						code.setLuvSortOrder(rs.getObject(7) == null ? null
								: Integer.valueOf(rs.getInt(7)));
						code.setLuvText(rs.getString(8));						
						results.add(code);
					}
				});

		return results;
	}

	@Override
	public int deleteLUVCode(String group, String value)
			throws DataAccessException {
		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] { group, value };
		int types[] = new int[] { Types.VARCHAR, Types.VARCHAR };
		return template.update(deleteLUVCode, params, types);
	}

}