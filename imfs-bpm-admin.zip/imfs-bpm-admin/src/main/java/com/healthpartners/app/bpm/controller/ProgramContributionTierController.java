package com.healthpartners.app.bpm.controller;

import com.healthpartners.app.bpm.common.BPMAdminConstants;
import com.healthpartners.app.bpm.dto.*;
import com.healthpartners.app.bpm.exception.BPMException;
import com.healthpartners.app.bpm.form.EditProgramForm;
import com.healthpartners.app.bpm.form.SaveProgramActivitySiteForm;
import com.healthpartners.app.bpm.form.SaveProgramContributionTierForm;
import com.healthpartners.app.bpm.iface.BusinessProgramService;
import jakarta.servlet.http.HttpServletRequest;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.view.RedirectView;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;

import static org.apache.commons.lang.exception.ExceptionUtils.getStackTrace;

@Controller
public class ProgramContributionTierController extends BaseController implements Validator {

    private static final String ACTION_SAVE = "save";
    private static final String ACTION_SAVE_TO_ALL_SITES = "saveToAllSites";
    private static final String ACTION_SAVE_TO_SELECTED = "saveToSelected";
    private static final String ACTION_SELECT_SITES = "selectSites";
    private static final String ACTION_ADD_BENEFIT_CONTRACT_TYPE = "addBenefitContractType";
    private static final String ACTION_REMOVE_BENEFIT_CONTRACT_TYPE = "removeBenefitContractType";
    private static final String ACTION_REMOVE_CONTRIBUTION_INCENTIVE_TIER = "removeContributionIncentiveTier";
    private static final String ACTION_ADD_RELATIONSHIPS = "addRelationships";

    protected final Log logger = LogFactory.getLog(getClass());
    private final BusinessProgramService businessProgramService;


    public ProgramContributionTierController(BusinessProgramService businessProgramService) {
        this.businessProgramService = businessProgramService;
    }

    @GetMapping("/editProgramContributionTier")
    public String loadProgramContributionTier(ModelMap modelMap,
                                               @RequestParam(name = "actionType") String actionType,
                                               @RequestParam(name = "programID") Integer programID,
                                               @RequestParam(name = "incentiveOptionID") Integer incentiveOptionID ) {
        try {
            SaveProgramContributionTierForm form = new SaveProgramContributionTierForm();
            form.setActionType(actionType);
            form.setProgramID(programID);
            form.setIncentiveOptionID(incentiveOptionID);
            loadInitial(form, modelMap);
        } catch (Exception e) {
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
            createErrorMessageOnModel(modelMap, getStackTrace(e));
        }

        return "editProgramContributionTier";
    }

    @PostMapping(value="/saveProgramContributionTier", params="cancel")
    public RedirectView submitCancelEdit(@ModelAttribute("saveProgramContributionTierForm") SaveProgramContributionTierForm form, RedirectAttributes ra) throws BPMException {
        try {
            EditProgramForm editProgramForm = new EditProgramForm();
            editProgramForm.setGroupNo(getUserSession().getGroupNo());
            editProgramForm.setProgramID(form.getProgramID());
            ra.addFlashAttribute("editProgramForm", editProgramForm);
            ra.addFlashAttribute("groupNumber", getUserSession().getGroupNo());
            ra.addFlashAttribute("actionType", "editIncentives");
        } catch (Exception e) {
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
        }

        String url = "editProgram";
        return new RedirectView(url);
    }

    @PostMapping(value = "/saveProgramContributionTier")
    public String submitProgramActivityIncentive(@ModelAttribute("saveProgramContributionTierForm") SaveProgramContributionTierForm form,
                                                 ModelMap modelMap,
                                                 BindingResult result,
                                                 HttpServletRequest request,
                                                 RedirectAttributes ra) {
        try {
            if (ACTION_ADD_BENEFIT_CONTRACT_TYPE.equals(form.getActionType())) {
                addBenefitContractType(form, modelMap, result);
                return "editProgramContributionTier";

            } else if (ACTION_REMOVE_BENEFIT_CONTRACT_TYPE.equals(form.getActionType())) {
                removeAssignedProgramBenefitContractTypes(form, modelMap);
                return "editProgramContributionTier";

            } else if (ACTION_REMOVE_CONTRIBUTION_INCENTIVE_TIER.equals(form.getActionType())) {
                removeContributionIncentiveTier(form, modelMap);
                return redirectToParentPage(ra, form);

            } else if (ACTION_ADD_RELATIONSHIPS.equals(form.getActionType())) {
                addAssignedRelationships(form, modelMap);
                return "editProgramContributionTier";

            } else if (ACTION_SELECT_SITES.equals(form.getActionType())) {
                selectSites(modelMap);
                return "programActivitySites";

            } else if (ACTION_SAVE.equals(form.getActionType()) || ACTION_SAVE_TO_ALL_SITES.equals(form.getActionType()) || ACTION_SAVE_TO_SELECTED.equals(form.getActionType())) {
                validate(form, result);
                if (result.hasErrors()) {
                    clearFormArrays(form);
                    populateRequest(modelMap);
                    return "editProgramContributionTier";
                } else {
                    return performSave(modelMap, ra, form, result);
                }
            }

        } catch (Exception e) {
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
            createErrorMessageOnModel(modelMap, getStackTrace(e));
        }

        // Add package also forwards to the same jsp.
        return "editProgramActivityIncentive";
    }

    private void loadInitial(SaveProgramContributionTierForm form, ModelMap modelMap) throws Exception {
        if (form.getIncentiveOptionID() == null) {
            form.setIncentiveOptionID(-1);
        }

        BusinessProgram businessProgram = getUserSession().getBusinessProgram();
        if (businessProgram == null) {
            businessProgram = businessProgramService.getBusinessProgram(form.getProgramID(), false);
        }

        ProgramContributionTier lProgramContributionTier = new ProgramContributionTier();
        ArrayList<ProgramContributionTier> programContributionTiers = new ArrayList<>();
        ArrayList<ContributionTierBenefitContractType> assignedContributionTierBenefitContractTypes = new ArrayList<>();

        ArrayList<ProgramIncentiveOption> programIncentiveOptions = (ArrayList<ProgramIncentiveOption>) businessProgramService.getProgramIncentiveOptions(form.getProgramID());
        // In the list of program incentive options, find the one that was selected.
        for (int i = 0; i < programIncentiveOptions.size(); i++) {
            if (programIncentiveOptions.get(i).getIncentiveOption().getIncentiveOptionID().intValue() == form.getIncentiveOptionID()) {
                Integer programIncentiveOptionID = programIncentiveOptions.get(i).getProgramIncentiveOptionID();
                programContributionTiers = businessProgramService.getProgramContributionIncentiveTiers(businessProgram.getProgramID(), programIncentiveOptions.get(i).getIncentiveOption().getIncentiveOptionID(), programIncentiveOptions.get(i).getIncentedStatusTypeCode());
                programIncentiveOptions.get(i).setProgramContributionTiers(programContributionTiers);
                getUserSession().setProgramIncentiveOption(programIncentiveOptions.get(i));
                break;
            }
        }

        if (CollectionUtils.isEmpty(programContributionTiers)) {
            programContributionTiers = (ArrayList<ProgramContributionTier>)
                    businessProgramService.getProgramContributionIncentiveTiers(businessProgram.getProgramID(), getUserSession().getProgramIncentiveOption().getIncentiveOption().getIncentiveOptionID(), getUserSession().getProgramIncentiveOption().getIncentedStatusTypeCode());
        }

        // If coming from "Add", create a new Program Contribution Tier and initialize it with
        // the program ID and incentive option ID.
        if (form.getActionType().equals(BPMAdminConstants.BPM_ADMIN_ACTION_ADD)) {
            lProgramContributionTier.setIncentiveOptionID(form.getIncentiveOptionID());
            lProgramContributionTier.setProgramID(form.getProgramID());
            lProgramContributionTier.setTierTypeID(0);
            lProgramContributionTier.setActivityTypeCodeID(0);

        } else {
            lProgramContributionTier = programContributionTiers.get(0);
            if (lProgramContributionTier.getActivityTypeCodeID().equals(0)) {
                lProgramContributionTier.setActivityTypeCode("Select...");
            }
            if (lProgramContributionTier.getActivityID().equals(0)) {
                lProgramContributionTier.setActivityName("Select...");
            }
            boolean isAllowRelationshipSelfOnly = false;
            if (getUserSession().getProgramIncentiveOption().getIncentedStatusTypeCode().equals(BPMAdminConstants.BPM_INCENTED_STATUS_TYPE_CONTRACT_BASED)) {
                isAllowRelationshipSelfOnly = true;
            }
            assignedContributionTierBenefitContractTypes = businessProgramService.getAssignedContributionTierBenefitContractTypes(lProgramContributionTier.getTierTypeID(), isAllowRelationshipSelfOnly);
        }

        if (getUserSession().getRemovedProgramContributionTiers() != null) {
            getUserSession().getRemovedProgramContributionTiers().clear();
        }

        Collection<LookUpValueCode> lActivityTypes = businessProgramService.getActivityTypeCodes();

        ArrayList<ContributionTierBenefitContractType> lContributionTierBenefitContractTypes = getContributionTierBenefitContractTypes(getUserSession().getProgramIncentiveOption());
        if (lContributionTierBenefitContractTypes != null && lContributionTierBenefitContractTypes.size() > 0) {
            //populate benefit contract type dropdown based on benefit contract types allowed for tier type.
            modelMap.put("contributionTierBenefitContractTypes", lContributionTierBenefitContractTypes);
            getUserSession().setContributionTierBenefitContractTypes(lContributionTierBenefitContractTypes);
            HashMap<Integer, Collection<ContributionTierBenefitContractTypeRelationship>> benefitContractTypeRelationshipHashMap = createRelationshipLookup(lContributionTierBenefitContractTypes);
            modelMap.put("benefitContractTypeRelationshipHashMap", benefitContractTypeRelationshipHashMap);
            getUserSession().setBenefitContractTypeRelationshipTierHashMap(benefitContractTypeRelationshipHashMap);
        }

        modelMap.put("contributionTierBenefitContractTypes", getUserSession().getContributionTierBenefitContractTypes());

        ArrayList<EligibleActivity> lEligibleActivities = (ArrayList<EligibleActivity>) businessProgramService.getEligibleActivities(form.getProgramID());

        ArrayList<LookUpValueCode> luvBenefitContractTypes = (ArrayList<LookUpValueCode>) businessProgramService.getBenefitContractTypes();
        ArrayList<ContributionTier> allContributionTiers = businessProgramService.getAllContributionTiers();


        modelMap.put("saveProgramContributionTierForm", form);
        modelMap.put("businessProgram", businessProgram);
        modelMap.put("programContributionTiers", programContributionTiers);

        modelMap.put("programContributionTier", lProgramContributionTier);
        modelMap.put("programIncentiveOption", getUserSession().getProgramIncentiveOption());
        modelMap.put("allContributionTiers", allContributionTiers);
        modelMap.put("availableContributionTierBenefitContractTypes", assignedContributionTierBenefitContractTypes);
        modelMap.put("benefitContractTypeRelationshipHashMap", getUserSession().getBenefitContractTypeRelationshipTierHashMap());
        modelMap.put("eligibleActivities", lEligibleActivities);


        modelMap.put("luvActivityTypes", lActivityTypes);
        modelMap.put("luvBenefitContractTypes", luvBenefitContractTypes);


        getUserSession().setAllContributionTiers(allContributionTiers);
        getUserSession().setProgramContributionTiers(programContributionTiers);

        getUserSession().setProgramContributionTier(lProgramContributionTier);
        getUserSession().setAssignedContributionTierBenefitContractTypes(assignedContributionTierBenefitContractTypes);
        getUserSession().setActivityTypeCodes((ArrayList<LookUpValueCode>) lActivityTypes);
        getUserSession().setEligibleActivities(lEligibleActivities);
        getUserSession().setBenefitContractTypes(luvBenefitContractTypes);

        if (programContributionTiers.size() > 0) {
            getUserSession().setProgramContributionTierExists(true);
        } else {
            getUserSession().setProgramContributionTierExists(false);
        }

        modelMap.put("isProgramContributionRowDisabled", getUserSession().isProgramContributionTierExists());

        // Attribute that is used to determine whether or not to display the
        // Save To Selected Sites button.
        modelMap.put(BPMAdminConstants.BPM_ADMIN_SITES_SELECTED, "false");

        form.setTierTypeID(String.valueOf(lProgramContributionTier.getTierTypeID()));
        form.setActivityID(String.valueOf(lProgramContributionTier.getActivityID()));
        form.setActivityTypeCodeID(String.valueOf(lProgramContributionTier.getActivityTypeCodeID()));
    }

    private ArrayList<ContributionTierBenefitContractType> getContributionTierBenefitContractTypes(ProgramIncentiveOption lProgramIncentiveOption) throws Exception {
        Integer tierTypeID = 0;
        ArrayList<ContributionTierBenefitContractType> lContributionTierBenefitContractTypes = null;
        Collection<ProgramContributionTier> lProgramContributionTiers = lProgramIncentiveOption.getProgramContributionTiers();

        for (ProgramContributionTier lProgramContributionTier : lProgramContributionTiers) {
            tierTypeID = lProgramContributionTier.getTierTypeID();
            break;
        }

        try {
            boolean isAllowRelationshipSelfOnly = false;
            if (lProgramIncentiveOption.getIncentedStatusTypeCode().equals(BPMAdminConstants.BPM_INCENTED_STATUS_TYPE_CONTRACT_BASED)) {
                isAllowRelationshipSelfOnly = true;
            }
            lContributionTierBenefitContractTypes = businessProgramService.getAssignedContributionTierBenefitContractTypes(tierTypeID, isAllowRelationshipSelfOnly);
        } catch (Exception e) {
            logger.error("Failed to get assigned contribution tier benefit contract types when calling businessProgramService.getAssignedContributionTierBenefitContractTypes.");
            throw e;
        }

        return lContributionTierBenefitContractTypes;
    }

    private HashMap<Integer, Collection<ContributionTierBenefitContractTypeRelationship>> createRelationshipLookup(Collection<ContributionTierBenefitContractType> lContributionTierBenefitContractTypes) {
        HashMap<Integer, Collection<ContributionTierBenefitContractTypeRelationship>> benefitContractTypeRelationshipHashMap = new HashMap<Integer, Collection<ContributionTierBenefitContractTypeRelationship>>();

        for (ContributionTierBenefitContractType lContributionTierBenefitContractType : lContributionTierBenefitContractTypes) {
            Collection<ContributionTierBenefitContractTypeRelationship> lContributionTierBenefitContractTypeRelationships = lContributionTierBenefitContractType.getContributionTierBenefitContractTypeRelationships();
            benefitContractTypeRelationshipHashMap.put(lContributionTierBenefitContractType.getBenefitContractTypeID(), lContributionTierBenefitContractTypeRelationships);
        }

        return benefitContractTypeRelationshipHashMap;

    }

    private void addBenefitContractType(SaveProgramContributionTierForm form, ModelMap modelMap, Errors errors) throws BPMException {
        //check to see if new contribution tier was selected for incentive option.
        //if so, refresh get new set of contribution tier benefit contract types.
        boolean isDiffTierTypeID = false;
        Integer currTierTypeID = 0;
        if (form.getTierTypeID() != null) {
            currTierTypeID = Integer.valueOf(form.getTierTypeID());
        }

        if (getUserSession().getContributionTierBenefitContractTypes() != null && !getUserSession().getContributionTierBenefitContractTypes().isEmpty()) {
            Integer prevTierTypeID = getUserSession().getContributionTierBenefitContractTypes().iterator().next().getTierTypeID();
            if (!currTierTypeID.equals(prevTierTypeID)) {
                if (currTierTypeID.equals(0)) {
                    currTierTypeID = prevTierTypeID;
                }
                isDiffTierTypeID = true;
            }
        }
        if (getUserSession().getContributionTierBenefitContractTypes() == null || getUserSession().getContributionTierBenefitContractTypes().size() == 0 || isDiffTierTypeID) {
            boolean isAllowRelationshipSelfOnly = false;
            if (getUserSession().getProgramIncentiveOption().getIncentedStatusTypeCode().equals(BPMAdminConstants.BPM_INCENTED_STATUS_TYPE_CONTRACT_BASED)) {
                isAllowRelationshipSelfOnly = true;
            }
            ArrayList<ContributionTierBenefitContractType> lContributionTierBenefitContractTypes = businessProgramService.getAssignedContributionTierBenefitContractTypes(currTierTypeID, isAllowRelationshipSelfOnly);
            getUserSession().setContributionTierBenefitContractTypes(lContributionTierBenefitContractTypes);
        }

        //determine if number of benefit contract type contribution rows exceeds number of benefit contract types available.
        //send error message stating number of benefit contract type rows cannot exceed number of benefit contract types available.
        //Add +1 to indicate about to add a new row when number of benefit contract type ids not reflected yet.
        //EV73140 - remove edit so that multiple relationships can be added within a benefit contract type.
				/*if (lSaveProgramContributionTierForm.getProgramBenefitContractTypeIDs() != null && lSaveProgramContributionTierForm.getProgramBenefitContractTypeIDs().length+1 > sessionBean.getContributionTierBenefitContractTypes().size()) {
					lActionMessages.add("Benefit Contract Contribution Amount ", new ActionMessage("errors.benefitContractTypeAmountRowExceeded", "Benefit Contract Contribution Amount row "));
					saveErrors(request, lActionMessages );
					assignRelationshipAtributesToProgramContributionTierContractTypes(lSaveProgramContributionTierForm);
					addAssignedRelationships(mapping, form, request);
					populateRequest(request);
					
					return mapping.findForward(FAILURE);
				}*/

        addAssignedBenefitContractType(form, modelMap);
    }

    private void addAssignedBenefitContractType(SaveProgramContributionTierForm form, ModelMap modelMap) {
        ProgramIncentiveOption lProgramIncentiveOption = getUserSession().getProgramIncentiveOption();
        SaveProgramContributionTierForm lSaveProgramContributionTierForm = (SaveProgramContributionTierForm)form;


        // When adding the first requirement
        if(lProgramIncentiveOption.getProgramContributionTiers() == null)
        {
            ArrayList<ProgramContributionTier> lProgramContributionTiers = new ArrayList<ProgramContributionTier>();
            lProgramIncentiveOption.setProgramContributionTiers(lProgramContributionTiers);
        }

        HashMap<Integer, Collection<ContributionTierBenefitContractTypeRelationship>> benefitContractTypeRelationshipHashMap = new HashMap<Integer, Collection<ContributionTierBenefitContractTypeRelationship>>();
        if (getUserSession().getBenefitContractTypeRelationshipTierHashMap() != null && getUserSession().getBenefitContractTypeRelationshipTierHashMap().size() > 0) {
            benefitContractTypeRelationshipHashMap = getUserSession().getBenefitContractTypeRelationshipTierHashMap();
        }

        //Transfer what was entered from benefit contract contribution amount row from screen into program contribution tier object.
        String[] programBenefitContractTypeIDs = lSaveProgramContributionTierForm.getProgramBenefitContractTypeIDs();
        Collection<ProgramContributionTier> lProgramContributionTiers = lProgramIncentiveOption.getProgramContributionTiers();

        if (programBenefitContractTypeIDs != null) {
            for (ProgramContributionTier lProgramContributionTier : lProgramContributionTiers) {
                for (int i = 0; i < programBenefitContractTypeIDs.length; i++) {
                    if ((i + 1) == lProgramContributionTier.getRowID() && Integer.valueOf(programBenefitContractTypeIDs[i]).equals(lProgramContributionTier.getBenefitContractTypeID())) {
                        Integer relationshipCode = Integer.valueOf(lSaveProgramContributionTierForm.getRelationshipIDs()[i]);
                        lProgramContributionTier.setRelationshipCode(relationshipCode);
                        String relationshipDesc = findRelationshipDescFromHashMap(lProgramContributionTier.getBenefitContractTypeID(), relationshipCode, benefitContractTypeRelationshipHashMap);
                        lProgramContributionTier.setRelationshipDesc(relationshipDesc);
                        lProgramContributionTier.setContributionAmount(Integer.valueOf(lSaveProgramContributionTierForm.getContributionAmounts()[i]));
                    }
                }
            }
        }
        
        ProgramContributionTier lProgramContributionTier = new ProgramContributionTier();

        lProgramContributionTier.setBenefitContractTypeID(0);
        lProgramContributionTier.setActivityID(0);
        lProgramContributionTier.setActivityTypeCodeID(0);
        lProgramContributionTier.setContributionAmount(0);
        lProgramContributionTier.setRelationshipCode(0);
        lProgramContributionTier.setRowID(lProgramIncentiveOption.getProgramContributionTiers().size() + 1);

        lProgramIncentiveOption.getProgramContributionTiers().add(lProgramContributionTier);

        ArrayList<ContributionTierBenefitContractTypeRelationship> lNewContributionTierBenefitContractTypeRelationships = new ArrayList<ContributionTierBenefitContractTypeRelationship>();
        ContributionTierBenefitContractTypeRelationship lNewContributionTierBenefitContractTypeRelationship = new ContributionTierBenefitContractTypeRelationship();
        lNewContributionTierBenefitContractTypeRelationship.setBenefitContractTypeID(0);
        lNewContributionTierBenefitContractTypeRelationship.setRelationshipCode(0);
        lNewContributionTierBenefitContractTypeRelationship.setRelationshipDesc("Select");
        lNewContributionTierBenefitContractTypeRelationships.add(lNewContributionTierBenefitContractTypeRelationship);
        benefitContractTypeRelationshipHashMap.put(0, lNewContributionTierBenefitContractTypeRelationships);
        getUserSession().setBenefitContractTypeRelationshipTierHashMap(benefitContractTypeRelationshipHashMap);

        clearFormArrays(lSaveProgramContributionTierForm);
        populateRequest(modelMap);
    }

    private void clearFormArrays(SaveProgramContributionTierForm pSaveProgramContributionTierForm) {
        pSaveProgramContributionTierForm.setProgramBenefitContractTypeIDs(null);
        pSaveProgramContributionTierForm.setRelationshipIDs(null);
        pSaveProgramContributionTierForm.setContributionAmounts(null);
        pSaveProgramContributionTierForm.setRowID("0");
    }

    private void populateRequest(ModelMap modelMap) {
        modelMap.put("businessProgram", getUserSession().getBusinessProgram());
        modelMap.put("programContributionTiers", getUserSession().getProgramContributionTiers());
        modelMap.put("programIncentiveOption", getUserSession().getProgramIncentiveOption());
        modelMap.put("allContributionTiers", getUserSession().getAllContributionTiers());

        modelMap.put("contributionTierBenefitContractTypes", getUserSession().getContributionTierBenefitContractTypes());

        modelMap.put("eligibleActivities", getUserSession().getEligibleActivities());
        modelMap.put("luvActivityTypes", getUserSession().getActivityTypeCodes());
        modelMap.put("benefitContractTypeRelationshipHashMap", getUserSession().getBenefitContractTypeRelationshipTierHashMap());

        modelMap.put("activities", getUserSession().getActivities());
        modelMap.put("luvActivityIncentiveTypes", getUserSession().getActivityIncentiveTypeCodes());

        modelMap.put("personRelationshipCodes", getUserSession().getPersonRelationshipCodes());
        modelMap.put("luvActivityIncentiveStatuses", getUserSession().getActivityIncentiveStatusCodes());
        modelMap.put("incentiveOptions", getUserSession().getActiveIncentiveOptions());

        modelMap.put("incentiveStatuses", getUserSession().getIncentiveOptionStatuses());
        modelMap.put("incentiveFulfillTypes", getUserSession().getIncentiveFulfillTypes());
        modelMap.put("programActivityIncentivesSummary", getUserSession().getProgramActivityIncentivesSummary());
        modelMap.put("collections", getUserSession().getCollections());
        modelMap.put("programIncentiveOptions", getUserSession().getProgramIncentiveOptions());
        modelMap.put("incentiveReportNameTypes", getUserSession().getIncentiveReportNameTypes());
        modelMap.put("incentedStatusCodes", getUserSession().getIncentedStatusCodes());
        modelMap.put("luvIdSendToMembership", getUserSession().getLuvIdSendToMembership());
        modelMap.put("luvIdSendToPremiumBilling", getUserSession().getLuvIdSendToPremiumBilling());
        modelMap.put("luvIdSendToIntelispend", getUserSession().getLuvIdSendToIntelispend());
        modelMap.put("luvIdSendToCDHP", getUserSession().getLuvIdSendToCDHP());
        modelMap.put("incentiveEnrollmentRuleCodes", getUserSession().getIncentiveEnrollmentRuleCodes());
        modelMap.put("luvBatchRunFrequencyTypes", getUserSession().getRewardRunFrequencyTypes());
        modelMap.put("incentiveOptionRewardCardTypes", getUserSession().getIncentiveOptionRewardCardTypes());
        modelMap.put("packageRuleGroups", getUserSession().getIncentivePackageRuleGroups());
        modelMap.put("luvDeliveryInfoTypes", getUserSession().getDeliveryInfoTypes());
        modelMap.put("programContributionTier", getUserSession().getProgramContributionTier());
        modelMap.put("isProgramContributionRowDisabled", getUserSession().isProgramContributionTierExists());
    }

    private String findRelationshipDescFromHashMap(Integer benefitContractTypeID, Integer targetRelationshipCode, HashMap<Integer, Collection<ContributionTierBenefitContractTypeRelationship>> benefitContractTypeRelationshipHashMap) {
        String relationshipDesc = "Desc Not Found";
        Collection<ContributionTierBenefitContractTypeRelationship> lContributionTierBenefitContractTypeRelationships = benefitContractTypeRelationshipHashMap.get(benefitContractTypeID);
        if (lContributionTierBenefitContractTypeRelationships != null) {
            for (ContributionTierBenefitContractTypeRelationship lContributionTierBenefitContractTypeRelationship : lContributionTierBenefitContractTypeRelationships) {

                if (targetRelationshipCode.equals(lContributionTierBenefitContractTypeRelationship.getRelationshipCode())) {
                    relationshipDesc = lContributionTierBenefitContractTypeRelationship.getRelationshipDesc();
                }
            }
        } else {
            relationshipDesc = "Select";
        }

        return relationshipDesc;
    }

    private void removeAssignedProgramBenefitContractTypes(SaveProgramContributionTierForm form, ModelMap modelMap) {
        Integer programBenefitContractTypeID = Integer.parseInt(form.getProgramBenefitContractTypeID());

        ArrayList<ProgramContributionTier> lProgramContributionTiers = (ArrayList<ProgramContributionTier>) getUserSession().getProgramIncentiveOption().getProgramContributionTiers();

        ArrayList<ProgramContributionTier> lRemovedProgramContributionTiers = new ArrayList<>();
        if (getUserSession().getRemovedProgramContributionTiers() != null) {
            lRemovedProgramContributionTiers = (ArrayList<ProgramContributionTier>) getUserSession().getRemovedProgramContributionTiers();
        }

        if (lProgramContributionTiers != null) {
            // Find the Benefit Contract Type whose ID matches the one selected.
            for (int i = 0; i < lProgramContributionTiers.size(); i++) {
                ProgramContributionTier lProgramContributionTier = (ProgramContributionTier) lProgramContributionTiers.get(i);
                if (lProgramContributionTier.getBenefitContractTypeID().equals(programBenefitContractTypeID)) {
                    lRemovedProgramContributionTiers.add(lProgramContributionTier);
                    lProgramContributionTiers.remove(i);
                    getUserSession().setRemovedProgramContributionTiers(lRemovedProgramContributionTiers);
                    break;

                }
            }
        } else {
            //remove rows added but no data selected or entered.
            getUserSession().getProgramIncentiveOption().getProgramContributionTiers().clear();
        }

        clearFormArrays(form);
        populateRequest(modelMap);
    }

    private void removeContributionIncentiveTier(SaveProgramContributionTierForm form, ModelMap modelMap) throws BPMException {
        ProgramIncentiveOption lProgramIncentiveOption = getUserSession().getProgramIncentiveOption();
        ArrayList<ProgramContributionTier> lProgramContributionTiers = lProgramIncentiveOption.getProgramContributionTiers();
        ArrayList<ProgramContributionTier> lRemovedProgramContributionTiers = new ArrayList<>();
        if (getUserSession().getRemovedProgramContributionTiers() != null) {
            lRemovedProgramContributionTiers = (ArrayList<ProgramContributionTier>) getUserSession().getRemovedProgramContributionTiers();
        }


        if (lProgramContributionTiers != null) {
            // Iterate through and removed all assigned program benefit contract types which includes the contribution incentive tier.
            // There's a one to many relationship between contribution incentive tier and benefit contract types.
            for (int i = 0; i < lProgramContributionTiers.size(); i++) {
                ProgramContributionTier lProgramContributionTier = (ProgramContributionTier) lProgramContributionTiers.get(i);

                if (lProgramContributionTier != null) {
                    lRemovedProgramContributionTiers.add(lProgramContributionTier);
                    getUserSession().setRemovedProgramContributionTiers(lRemovedProgramContributionTiers);
                    getUserSession().getProgramIncentiveOption().setProgramContributionTiers(lProgramContributionTiers);
                }

            }
        }

        Collection<ProgramIncentiveOption> pProgramIncentiveOptions = getUserSession().getProgramIncentiveOptions();

        for (ProgramIncentiveOption pProgramIncentiveOption : pProgramIncentiveOptions) {
            if (pProgramIncentiveOption.getBusinessProgramID().equals(lProgramIncentiveOption.getBusinessProgramID()) &&
                    pProgramIncentiveOption.getIncentiveOption().getIncentiveOptionID().equals(lProgramIncentiveOption.getIncentiveOption().getIncentiveOptionID())) {
                pProgramIncentiveOption.getProgramContributionTiers().clear();
            }
        }

        clearFormArrays(form);
        populateRequest(modelMap);

        try {
            deleteContributionIncentiveTier();
        } catch (BPMException e) {
            logger.error("Issues with deleting against contribution tier tables.");
            throw e;
        }
    }

    private int  deleteContributionIncentiveTier() throws BPMException {
        int numberDeleted = 0;

        Collection<ProgramContributionTier> lremovedProgramContributionTiers = getUserSession().getRemovedProgramContributionTiers();
        try {
            numberDeleted = businessProgramService.deleteProgramContributionTiers(lremovedProgramContributionTiers);
        } catch (BPMException e) {
            throw e;
        }

        getUserSession().getRemovedProgramContributionTiers().clear();

        return numberDeleted;
    }

    private void addAssignedRelationships(SaveProgramContributionTierForm form, ModelMap modelMap) {
        HashMap<Integer, Collection<ContributionTierBenefitContractTypeRelationship>> benefitContractTypeRelationshipHashMap = new HashMap<>();

        Collection<ContributionTierBenefitContractType> lContributionTierBenefitContractTypes = getUserSession().getContributionTierBenefitContractTypes();
        String[] programBenefitContractTypeIDs = form.getProgramBenefitContractTypeIDs();

        for ( int i = 0; i < programBenefitContractTypeIDs.length; i++) {
            Integer chosenBenefitContractTypeID = Integer.valueOf(programBenefitContractTypeIDs[i].toString());

            for (ContributionTierBenefitContractType lContributionTierBenefitContractType : lContributionTierBenefitContractTypes) {
                if (chosenBenefitContractTypeID.equals(lContributionTierBenefitContractType.getBenefitContractTypeID())) {

                    Collection<ContributionTierBenefitContractTypeRelationship> lContributionTierBenefitContractTypeRelationships = lContributionTierBenefitContractType.getContributionTierBenefitContractTypeRelationships();
                    if (!benefitContractTypeRelationshipHashMap.containsKey(chosenBenefitContractTypeID)) {
                        benefitContractTypeRelationshipHashMap.put(chosenBenefitContractTypeID, lContributionTierBenefitContractTypeRelationships);
                    }


                }
            }

            if (benefitContractTypeRelationshipHashMap.isEmpty()) {
                ArrayList<ContributionTierBenefitContractTypeRelationship> lNewContributionTierBenefitContractTypeRelationships = new ArrayList<ContributionTierBenefitContractTypeRelationship>();
                ContributionTierBenefitContractTypeRelationship lNewContributionTierBenefitContractTypeRelationship = new ContributionTierBenefitContractTypeRelationship();
                lNewContributionTierBenefitContractTypeRelationship.setBenefitContractTypeID(0);
                lNewContributionTierBenefitContractTypeRelationship.setRelationshipCode(0);
                lNewContributionTierBenefitContractTypeRelationship.setRelationshipDesc("");
                lNewContributionTierBenefitContractTypeRelationships.add(lNewContributionTierBenefitContractTypeRelationship);
                benefitContractTypeRelationshipHashMap.put(chosenBenefitContractTypeID, lNewContributionTierBenefitContractTypeRelationships);
            }
        }

        assignRelationshipAtributesToProgramContributionTierContractTypes(form);

        modelMap.put("benefitContractTypeRelationshipHashMap", benefitContractTypeRelationshipHashMap);
        getUserSession().setBenefitContractTypeRelationshipTierHashMap(benefitContractTypeRelationshipHashMap);

        clearFormArrays(form);
        populateRequest(modelMap);
    }

    /**
     * Not all attributes will be available during data entry form screen.  First call of this, relationship and amount will not have been added by user.
     */
    private void assignRelationshipAtributesToProgramContributionTierContractTypes(SaveProgramContributionTierForm lSaveProgramContributionTierForm) {
        Collection<ContributionTierBenefitContractType> lContributionTierBenefitContractTypes = getUserSession().getContributionTierBenefitContractTypes();
        ProgramIncentiveOption lProgramIncentiveOption = getUserSession().getProgramIncentiveOption();
        Collection<ProgramContributionTier> lProgramContributionTiers = lProgramIncentiveOption.getProgramContributionTiers();

        String[] programBenefitContractTypeIDs = lSaveProgramContributionTierForm.getProgramBenefitContractTypeIDs();
        String[] contributionAmounts = lSaveProgramContributionTierForm.getContributionAmounts();
        String[] relationshipIDs = lSaveProgramContributionTierForm.getRelationshipIDs();

        for (int i = 0; i < programBenefitContractTypeIDs.length; i++) {
            Integer chosenBenefitContractTypeID = Integer.valueOf(programBenefitContractTypeIDs[i].toString());
            Integer relationshipCode = Integer.valueOf(relationshipIDs[i].toString());
            Integer contributionAmount = Integer.valueOf(contributionAmounts[i].toString());
            for (ContributionTierBenefitContractType lContributionTierBenefitContractType : lContributionTierBenefitContractTypes) {
                if (chosenBenefitContractTypeID.equals(lContributionTierBenefitContractType.getBenefitContractTypeID())) {
                    int j = 0;
                    for (ProgramContributionTier lProgramContributionTier : lProgramContributionTiers) {
                        if (i == j) {
                            if (lProgramContributionTier.getProgramID() == null) {
                                lProgramContributionTier.setProgramID(Integer.valueOf(lSaveProgramContributionTierForm.getProgramID()));
                            }
                            lProgramContributionTier.setActivityTypeCodeID(Integer.valueOf(lSaveProgramContributionTierForm.getActivityTypeCodeID()));
                            lProgramContributionTier.setActivityID(Integer.valueOf(lSaveProgramContributionTierForm.getActivityID()));
                            lProgramContributionTier.setBenefitContractTypeID(chosenBenefitContractTypeID);
                            lProgramContributionTier.setIncentiveOptionID(Integer.valueOf(lSaveProgramContributionTierForm.getIncentiveOptionID()));
                            lProgramContributionTier.setBenefitContractType(lContributionTierBenefitContractType.getLuvDesc());
                            lProgramContributionTier.setTierValueID(lContributionTierBenefitContractType.getTierValueID());
                            lProgramContributionTier.setTierTypeID(lContributionTierBenefitContractType.getTierTypeID());
                            lProgramContributionTier.setRelationshipCode(relationshipCode);
                            String relationshipDesc = findRelationshipDescFromHashMap(chosenBenefitContractTypeID, relationshipCode, getUserSession().getBenefitContractTypeRelationshipTierHashMap());
                            lProgramContributionTier.setRelationshipDesc(relationshipDesc);
                            lProgramContributionTier.setContributionAmount(contributionAmount);

                        }
                        j++;
                    }
                }
            }
        }
    }

    private String performSave(ModelMap modelMap, RedirectAttributes ra, SaveProgramContributionTierForm form, BindingResult result) throws Exception {
        String userID = getUserSessionSupport().getAuthenticatedUsername();

        if (ACTION_SAVE.equals(form.getActionType())) {
            boolean isValid = save(form, modelMap, result, userID);
            if (!isValid || result.hasErrors()) {
                return "editProgramContributionTier";
            }

        } else {
            //save snapshot of program incentive option since it will be updated with sites business program id during save all.
            ProgramIncentiveOption saveProgramIncentiveOption = getUserSession().getProgramIncentiveOption();
            Collection<EmployerGroup> lEmployerGroups = null;

            if (ACTION_SAVE_TO_ALL_SITES.equals(form.getActionType())) {
                // Get a list of all the sites for this group.
                lEmployerGroups = businessProgramService.getSubGroups(getUserSession().getBusinessProgram()
                        .getEmployerGroup().getGroupID());
            }

            if (ACTION_SAVE_TO_SELECTED.equalsIgnoreCase(form.getActionType())) {
                lEmployerGroups = getUserSession().getEmployerSubGroups();
            }

            boolean isValid = saveProgramBenefitContractTypesAllSites(form, lEmployerGroups, modelMap, result, userID);

            //reset.
            getUserSession().setProgramIncentiveOption(saveProgramIncentiveOption);

            //Not valid
            if (!isValid) {
                assignRelationshipAtributesToProgramContributionTierContractTypes(form);
                addAssignedRelationships(form, modelMap);
                populateRequest(modelMap);
                createActionMessagesOnModel(modelMap, "errors.noCopyForContributionTier", new Object[]{ "incentiveOption"});
                return "editProgramContributionTier";
            }
        }

        return redirectToParentPage(ra, form);
    }

    private String redirectToParentPage(RedirectAttributes ra, SaveProgramContributionTierForm form) {
        // Redirect back to the editProgram incentiveOptions screen upon successful process of saves
        EditProgramForm editProgramForm = new EditProgramForm();
        editProgramForm.setGroupNo(getUserSession().getGroupNo());
        editProgramForm.setProgramID(form.getProgramID());
        getUserSession().setProgramID(form.getProgramID());
        ra.addFlashAttribute("editProgramForm", editProgramForm);
        ra.addFlashAttribute("groupNumber", getUserSession().getGroupNo());
        ra.addFlashAttribute("actionType", "editIncentives");
        ra.addAttribute("groupNumber", getUserSession().getGroupNo());
        ra.addAttribute("actionType", "editIncentives");
        return "redirect: editProgram";
    }

    private boolean save(SaveProgramContributionTierForm form, ModelMap modelMap, BindingResult result, String userID) throws Exception {
        boolean isValid = validateNSaveProgramContributionTier(getUserSession().getBusinessProgram(), getUserSession().getProgramIncentiveOption(), form, modelMap, result, userID);

        if (isValid) {
            if (getUserSession().getRemovedProgramContributionTiers() != null && getUserSession().getRemovedProgramContributionTiers().size() > 0) {
                deleteContributionIncentiveTier();
            }
        } else {
            assignRelationshipAtributesToProgramContributionTierContractTypes(form);
            populateRequest(modelMap);
        }

        return isValid;
    }

    private boolean validateNSaveProgramContributionTier(BusinessProgram lBusinessProgram, ProgramIncentiveOption lProgramIncentiveOption, SaveProgramContributionTierForm lSaveProgramContributionTierForm, ModelMap modelMap, Errors errors, String lUserID) throws Exception {
        boolean isValid = true;

        if (isBenefitContractTypeAllWithMultipleBenefitContractTypes(lSaveProgramContributionTierForm)) {
            getValidationSupport().addValidationFailureMessage("programBenefitContractTypeIDs[0]", errors, "errors.benefitContractTypeALL", new Object[] {"Benefit Contract Type ALL "});
            populateRequest(modelMap);
            return false;
        }

        if (lSaveProgramContributionTierForm.getProgramBenefitContractTypeIDs() == null || lSaveProgramContributionTierForm.getProgramBenefitContractTypeIDs().length == 0) {
            getValidationSupport().addValidationFailureMessage("contributionAmounts[0]", errors, "errors.programBenefitContractRelAmtMissing", new Object[] {"Benefit Contract Contribution Amount "});
            populateRequest(modelMap);
            return false;
        }

        //read luv record for to check for max amount allowed to be entered.
        LookUpValueCode contributionAmountLimitLuv = businessProgramService.getContributionAmountLimit(BPMAdminConstants.CONTRIBUTION_AMT_LIMIT);

        Integer contributionAmountLimit = Integer.valueOf(contributionAmountLimitLuv.getLuvVal());

        String[]  amounts = lSaveProgramContributionTierForm.getContributionAmounts();
        for (int i = 0; i < amounts.length; i++ ) {
            Integer amount = Integer.valueOf(amounts[i]);
            if (amount > contributionAmountLimit) {
                getValidationSupport().addValidationFailureMessage("contributionAmounts[0]", errors, "errors.contributionAmtExceeded", new Object[] {"Contribution Amount", contributionAmountLimit});
                populateRequest(modelMap);
                return false;
            }
        }

        try {
            // check to see if activity based, activity packaged based, or multi activity.
            if (lProgramIncentiveOption.getIncentedStatusTypeCode().equals(BPMAdminConstants.BPM_LUV_INCENTIVE_STATUS_MULTI_ACTIVITY) ||
                    lProgramIncentiveOption.getIncentedStatusTypeCode().equals(BPMAdminConstants.BPM_LUV_INCENTIVE_STATUS_ACTIVITY_PKGE_BASED) ||
                    lProgramIncentiveOption.getIncentedStatusTypeCode().equals(BPMAdminConstants.BPM_INCENTED_STATUS_TYPE_ACTIVITY_BASED)) {

                ActivityIncentiveDetail lActivityIncentiveDetail = findActivityIncentiveRequirementDetailForActivity(lProgramIncentiveOption.getBusinessProgramID(), lProgramIncentiveOption.getIncentiveOption().getIncentiveOptionID(), lSaveProgramContributionTierForm, lProgramIncentiveOption.getActivityIncentiveRequirements());
                if (lActivityIncentiveDetail == null) {
                    getValidationSupport().addValidationFailureMessage("activityTypeCodeID", errors, "errors.activityRequirementMissing", new Object[] {"Activity Requirement missing for ", lBusinessProgram.getEmployerGroup().getGroupNumber(), lBusinessProgram.getEmployerGroup().getSiteNumber()});
                    populateRequest(modelMap);
                    return false;
                }

                saveProgramBenefitContractTypes(lSaveProgramContributionTierForm, lActivityIncentiveDetail.getActivityIncentiveID(), lActivityIncentiveDetail.getGroupID(), lActivityIncentiveDetail.getGroupRequiredID(), null, lUserID);
            }

        } catch (Exception e) {
            logger.error("validateProgramContributionTierForm: error when attempting to save program benefit contract type.");
            throw (e);
        }

        try {
            // check to see if contract based or member based.
            if (lProgramIncentiveOption.getIncentedStatusTypeCode().equals(BPMAdminConstants.BPM_INCENTED_STATUS_TYPE_CONTRACT_BASED) ||
                    lProgramIncentiveOption.getIncentedStatusTypeCode().equals(BPMAdminConstants.BPM_INCENTED_STATUS_TYPE_MEMBER_BASED))  {
                CheckmarkDetail lCheckmarkDetail = findQualificationCheckmarkDetailForActivity(lSaveProgramContributionTierForm);
                if (lCheckmarkDetail == null) {
                    getValidationSupport().addValidationFailureMessage("activityID", errors, "errors.qualificationCheckmarkMissing", new Object[] {"Qualification Checkmark missing for ", lBusinessProgram.getEmployerGroup().getGroupNumber(), lBusinessProgram.getEmployerGroup().getSiteNumber()});
                    populateRequest(modelMap);
                    return false;
                }

                saveProgramBenefitContractTypes(lSaveProgramContributionTierForm, null, null, null, lCheckmarkDetail.getQualificationCheckmarkDetailID(), lUserID);
            }

        } catch (Exception e) {
            logger.error("validateProgramContributionTierForm: error when attempting to save program benefit contract type.");
            throw (e);
        }

        return isValid;
    }

    /**
     *	Check for a benefit contract type of ALL and more than one benefit contract type entered by user.  A benefit contract type of ALL will generate contribution incentive tier
     *   records for all the benfit contract types assigned to the contribution tier definition.  Therefore only one benefit contract type of ALL can be declared by the user.  Error
     *   if there is more than one.
     */
    private boolean isBenefitContractTypeAllWithMultipleBenefitContractTypes(SaveProgramContributionTierForm lSaveProgramContributionTierForm) throws BPMException {
        boolean isBenefitContractTypeAllWithMultiples = false;
        String[] programBenefitContractTypeIDs = lSaveProgramContributionTierForm.getProgramBenefitContractTypeIDs();

        if (programBenefitContractTypeIDs != null) {
            for ( int i = 0; i < programBenefitContractTypeIDs.length; i++) {
                Integer chosenBenefitContractTypeID = Integer.valueOf(programBenefitContractTypeIDs[i].toString());

                try {
                    LookUpValueCode lLookUpValueCode = businessProgramService.getBenefitContractTypeById(chosenBenefitContractTypeID);
                    if (lLookUpValueCode.getLuvVal().equals(BPMAdminConstants.BEN_CON_ALL) && programBenefitContractTypeIDs.length > 1) {
                        isBenefitContractTypeAllWithMultiples = true;
                        break;
                    }
                } catch (BPMException e) {
                    logger.error("BPMException: Read error at determineAllBenefitContractTypeNAssign");
                    throw (e);

                }
            }
        }

        return isBenefitContractTypeAllWithMultiples;
    }

    /*
     * Validate that activity or activity type selected match to the activity incentive requirement setup.
     */
    private ActivityIncentiveDetail findActivityIncentiveRequirementDetailForActivity(Integer programID, Integer programIncentiveOptionID, SaveProgramContributionTierForm lSaveProgramContributionTierForm, Collection<ActivityIncentiveRequirement> lActivityIncentiveRequirements) {
        ActivityIncentiveDetail xActivityIncentiveDetail = null;

        for (ActivityIncentiveRequirement lActivityIncentiveRequirement : lActivityIncentiveRequirements) {
            Collection<ActivityIncentiveDetail> lActivityIncentiveDetails = lActivityIncentiveRequirement.getActivityIncentiveDetails();
            for (ActivityIncentiveDetail lActivityIncentiveDetail : lActivityIncentiveDetails) {
                if (programID.equals(lActivityIncentiveDetail.getProgramID()) &&
                        programIncentiveOptionID.equals(lActivityIncentiveDetail.getIncentiveOptionID()) &&
                        (Integer.valueOf(lSaveProgramContributionTierForm.getActivityID()).equals(lActivityIncentiveDetail.getActivityID()) &&
                                Integer.valueOf(lSaveProgramContributionTierForm.getActivityTypeCodeID()).equals(lActivityIncentiveDetail.getActivityTypeCodeID()))) {
                    xActivityIncentiveDetail = lActivityIncentiveDetail;
                    break;
                }
            }
            if (xActivityIncentiveDetail != null) {
                break;
            }
        }

        return xActivityIncentiveDetail;
    }

    private void saveProgramBenefitContractTypes(SaveProgramContributionTierForm lSaveProgramContributionTierForm, Integer activityIncentiveID, Integer groupID, Integer groupRequiredID, Integer qualificationCheckmarkDetailID, String pUserID) throws Exception {
        assignRelationshipAtributesToProgramContributionTierContractTypes(lSaveProgramContributionTierForm);

        //create available benefit contract type contribution incentive tiers if benefit contract type selected is ALL.
        determineBenefitContractTypeALLNAssign(lSaveProgramContributionTierForm);

        getUserSession().getContributionTierBenefitContractTypes();

        ProgramIncentiveOption lProgramIncentiveOption = getUserSession().getProgramIncentiveOption();

        for (int i = 0; i < lProgramIncentiveOption.getProgramContributionTiers().size(); i++) {
            businessProgramService.updateProgramContributionTier(activityIncentiveID, groupID, groupRequiredID, qualificationCheckmarkDetailID, lProgramIncentiveOption.getProgramContributionTiers().get(i), pUserID);
        }
    }

    /**
     * When a benefit contract type of ALL exists, create benefit contract type contribution incentive tiers from the list of available benefit contract types.
     * This saves user from having to enter more than one benefit contract type, relationship, and amount during data entry.
     *
     */
    private void determineBenefitContractTypeALLNAssign(SaveProgramContributionTierForm lSaveProgramContributionTierForm) throws BPMException {

        ArrayList<ProgramContributionTier> lProgramContributionTierNewList = new ArrayList<>();

        Collection<ContributionTierBenefitContractType> lContributionTierBenefitContractTypes = getUserSession().getContributionTierBenefitContractTypes();

        ProgramIncentiveOption lProgramIncentiveOption = getUserSession().getProgramIncentiveOption();

        String[] programBenefitContractTypeIDs = lSaveProgramContributionTierForm.getProgramBenefitContractTypeIDs();
        String[] contributionAmounts = lSaveProgramContributionTierForm.getContributionAmounts();
        String[] relationshipIDs = lSaveProgramContributionTierForm.getRelationshipIDs();

        for ( int i = 0; i < programBenefitContractTypeIDs.length; i++) {
            Integer chosenBenefitContractTypeID = Integer.valueOf(programBenefitContractTypeIDs[i].toString());
            Integer relationshipCode = Integer.valueOf(relationshipIDs[i].toString());
            Integer contributionAmount = Integer.valueOf(contributionAmounts[i].toString());

            try {
                LookUpValueCode lLookUpValueCode = businessProgramService.getBenefitContractTypeById(chosenBenefitContractTypeID);
                if (lLookUpValueCode.getLuvVal().equals(BPMAdminConstants.BEN_CON_ALL)) {
                    for (ContributionTierBenefitContractType lContributionTierBenefitContractType : lContributionTierBenefitContractTypes) {
                        if (chosenBenefitContractTypeID.equals(lContributionTierBenefitContractType.getBenefitContractTypeID())) {
                            //Do not include Benefit Contract Type of ALL since ALL is driving the creation of available Benefit Contract Types assigned to the Tier.
                        } else {
                            ProgramContributionTier lProgramContributionTier = new ProgramContributionTier();
                            lProgramContributionTier.setProgramID(Integer.valueOf(lSaveProgramContributionTierForm.getProgramID()));
                            lProgramContributionTier.setActivityTypeCodeID(Integer.valueOf(lSaveProgramContributionTierForm.getActivityTypeCodeID()));
                            lProgramContributionTier.setActivityID(Integer.valueOf(lSaveProgramContributionTierForm.getActivityID()));
                            lProgramContributionTier.setBenefitContractTypeID(lContributionTierBenefitContractType.getBenefitContractTypeID());
                            lProgramContributionTier.setIncentiveOptionID(Integer.valueOf(lSaveProgramContributionTierForm.getIncentiveOptionID()));
                            lProgramContributionTier.setBenefitContractType(lContributionTierBenefitContractType.getLuvDesc());
                            lProgramContributionTier.setTierValueID(lContributionTierBenefitContractType.getTierValueID());
                            lProgramContributionTier.setTierTypeID(lContributionTierBenefitContractType.getTierTypeID());
                            lProgramContributionTier.setRelationshipCode(relationshipCode);
                            String relationshipDesc = findRelationshipDescFromHashMap(chosenBenefitContractTypeID, relationshipCode, getUserSession().getBenefitContractTypeRelationshipTierHashMap());
                            lProgramContributionTier.setRelationshipDesc(relationshipDesc);
                            lProgramContributionTier.setContributionAmount(contributionAmount);
                            lProgramContributionTierNewList.add(lProgramContributionTier);
                        }
                    }

                }
            } catch (BPMException e) {
                logger.error("BPMException: Read error at determineAllBenefitContractTypeNAssign");
                throw (e);
            }
        }

        if (lProgramContributionTierNewList.size() > 0) {
            lProgramIncentiveOption.setProgramContributionTiers(lProgramContributionTierNewList);
        }
    }

    /*
     * Validate that activity or activity type selected match to the qualification checkmark setup.
     */
    private CheckmarkDetail findQualificationCheckmarkDetailForActivity(SaveProgramContributionTierForm lSaveProgramContributionTierForm) throws BPMException {
        CheckmarkDetail returnCheckmarkDetail = null;

        try {
            ArrayList<ProgramCheckmark> lProgramCheckmarks = businessProgramService.getProgramCheckmarks(Integer.valueOf(lSaveProgramContributionTierForm.getProgramID()));

            for (ProgramCheckmark lProgramCheckmark : lProgramCheckmarks) {
                Collection<CheckmarkRequirement> lCheckmarkRequirements = businessProgramService.getCheckmarkRequirements(lProgramCheckmark.getQualificationCheckmarkID());

                for (CheckmarkRequirement lCheckmarkRequirement : lCheckmarkRequirements) {
                    Collection<CheckmarkDetail> lCheckmarkDetails = lCheckmarkRequirement.getCheckmarkDetails();
                    for (CheckmarkDetail lCheckmarkDetail : lCheckmarkDetails) {
                        if (!lSaveProgramContributionTierForm.getActivityID().equals("0") && Integer.valueOf(lSaveProgramContributionTierForm.getActivityID()).equals(lCheckmarkDetail.getActivityID()) ||
                                !lSaveProgramContributionTierForm.getActivityTypeCodeID().equals("0") && Integer.valueOf(lSaveProgramContributionTierForm.getActivityTypeCodeID()).equals(lCheckmarkDetail.getActivityTypeCodeID())) {
                            returnCheckmarkDetail = lCheckmarkDetail;
                            break;
                        }
                    }
                    if (returnCheckmarkDetail != null) {
                        break;
                    }
                }
                if (returnCheckmarkDetail != null) {
                    break;
                }
            }
        } catch (BPMException e) {
            logger.error("Error at findQualificationCheckmarkDetailForActivity call.");
            throw e;
        }

        return returnCheckmarkDetail;
    }

    private void selectSites(ModelMap modelMap) throws BPMException {
        if (getUserSession().getAvailableSites() != null) {
            getUserSession().getAvailableSites().clear();
        }

        if (getUserSession().getEmployerSubGroups() != null) {
            getUserSession().getEmployerSubGroups().clear();
        }

        Collection<EmployerGroup> lSubGroups = businessProgramService.getBusinessProgramInSameYear(getUserSession().getBusinessProgram().getProgramID());

        modelMap.put("businessProgram", getUserSession().getBusinessProgram());
        modelMap.put("selectedSubGroups", lSubGroups);

        SaveProgramActivitySiteForm saveProgramActivitySiteForm = new SaveProgramActivitySiteForm();
        saveProgramActivitySiteForm.setSubGroupID(((ArrayList<EmployerGroup>) lSubGroups).get(0).getSubgroupID());
        modelMap.put("saveProgramActivitySiteForm", saveProgramActivitySiteForm);

        getUserSession().setEmployerSubGroups((ArrayList<EmployerGroup>) lSubGroups);
        getUserSession().setWhichSaveSelectedSite(WHICH_SAVE_SELECTED_SITES_CONTRIBUTION);
    }

    /**
     * Saves the Program Incentive Option Contribution Tiers to all sites.
     * Removes contribution tiers from all sites if available.
     */
    private boolean saveProgramBenefitContractTypesAllSites(SaveProgramContributionTierForm lSaveProgramContributionTierForm, Collection<EmployerGroup> pEmployerGroups, ModelMap modelMap, Errors errors, String pUserID) throws Exception {
        boolean isValid = false;

        assignRelationshipAtributesToProgramContributionTierContractTypes(lSaveProgramContributionTierForm);

        BusinessProgram pBusinessProgram = getUserSession().getBusinessProgram();
        ProgramIncentiveOption lProgramIncentiveOptionOrigin = getUserSession().getProgramIncentiveOption();
        Integer incentiveOptonIDTarget = lProgramIncentiveOptionOrigin.getIncentiveOption().getIncentiveOptionID();
        Collection<ProgramContributionTier> lProgramContributionTiersToSaveFrom = lProgramIncentiveOptionOrigin.getProgramContributionTiers();

        for (EmployerGroup lEmployerGroup : pEmployerGroups) {
            ArrayList<BusinessProgram> lBusinessPrograms = (ArrayList<BusinessProgram>)
                    businessProgramService.getBusinessPrograms(pBusinessProgram.getEffectiveDate()
                            , pBusinessProgram.getEmployerGroup().getGroupID()
                            , lEmployerGroup.getSubgroupID());

            for (BusinessProgram lBusinessProgram : lBusinessPrograms) {
                ProgramIncentiveOption lProgramIncentiveOptionOnMatch = null;
                Collection<ProgramIncentiveOption> lProgramIncentiveOptions = businessProgramService.getProgramIncentiveOptions(lBusinessProgram.getProgramID());

                //using the current program incentive option as the target match to the program incentive option and incented status type in which program contribution tiers are being added.
                for (ProgramIncentiveOption lProgramIncentiveOption : lProgramIncentiveOptions) {
                    if (lProgramIncentiveOption.getIncentiveOption().getIncentiveOptionID().equals(incentiveOptonIDTarget) &&
                            lProgramIncentiveOption.getIncentedStatusTypeCode().equals(lProgramIncentiveOptionOrigin.getIncentedStatusTypeCode())) {

                        lProgramIncentiveOptionOnMatch = lProgramIncentiveOption;

                        ArrayList<ProgramContributionTier> lProgramContributionTiersToTransfer = lProgramIncentiveOptionOrigin.getProgramContributionTiers();

                        //using the original
                        for (ProgramContributionTier lProgramContributionTierToTransfer : lProgramContributionTiersToTransfer) {
                            lProgramContributionTierToTransfer.setProgramID(lProgramIncentiveOptionOnMatch.getBusinessProgramID());
                            if (lProgramIncentiveOptionOnMatch.getProgramContributionTiers().isEmpty()) {
                                lProgramContributionTierToTransfer.setTierContributionID(null);
                            }
                        }

                        lProgramIncentiveOptionOnMatch.setProgramContributionTiers(lProgramContributionTiersToTransfer);

                        getUserSession().setProgramIncentiveOption(lProgramIncentiveOptionOnMatch);
                        break;
                    }
                }

                if (lProgramIncentiveOptionOnMatch != null) {
                    for (ProgramContributionTier lProgramContributionTierToSaveFrom : lProgramContributionTiersToSaveFrom) {
                        lProgramContributionTierToSaveFrom.setProgramID(lBusinessProgram.getProgramID());
                    }
                    isValid = validateNSaveProgramContributionTier(lBusinessProgram, lProgramIncentiveOptionOnMatch, lSaveProgramContributionTierForm, modelMap, errors, pUserID);

                    //check to see if any program contribution tiers were removed.  If yes, then need to remove all associated program contribution tier by site.
                    if (getUserSession().getRemovedProgramContributionTiers() != null) {
                        Collection<ProgramContributionTier> lProgramContributionTiersRemoved = getUserSession().getRemovedProgramContributionTiers();
                        ArrayList<ProgramContributionTier> lProgramContributionTiersToRemove = new ArrayList<ProgramContributionTier>();
                        //match on program contribution tier of business program to get activity incentive id used as part of the key to the record when updating.
                        Collection<ProgramContributionTier> lProgramContributionTiers = businessProgramService.getProgramContributionIncentiveTiers(lBusinessProgram.getProgramID(), lProgramIncentiveOptionOnMatch.getIncentiveOption().getIncentiveOptionID(), lProgramIncentiveOptionOnMatch.getIncentedStatusTypeCode());
                        for (ProgramContributionTier lProgramContributionTierRemoved : lProgramContributionTiersRemoved) {
                            for (ProgramContributionTier lProgramContributionTier : lProgramContributionTiers) {
                                if (lProgramContributionTierRemoved.getActivityID().equals(lProgramContributionTier.getActivityID()) ||
                                        lProgramContributionTierRemoved.getActivityTypeCodeID().equals(lProgramContributionTier.getActivityTypeCodeID())) {
                                    lProgramContributionTiersToRemove.add(lProgramContributionTier);
                                }
                            }
                        }

                        if (isValid) {
                            if (lProgramContributionTiersToRemove != null && lProgramContributionTiersToRemove.size() > 0) {
                                getUserSession().setProgramContributionTiers(lProgramContributionTiersToRemove);
                                deleteContributionIncentiveTier();
                            }
                        }
                    }
                }
            }
        }

        //reset back to original
        getUserSession().setProgramIncentiveOption(lProgramIncentiveOptionOrigin);

        if (getUserSession().getRemovedProgramContributionTiers() != null) {
            getUserSession().getRemovedProgramContributionTiers().clear();
        }

        return isValid;
    }


    @Override
    public boolean supports(Class<?> clazz) {
        return SaveProgramContributionTierForm.class.isAssignableFrom(clazz);
    }

    @Override
    public void validate(Object target, Errors errors) {
        SaveProgramContributionTierForm form = (SaveProgramContributionTierForm) target;
        boolean isAllBenefitContractTypesSelected = false;

        getValidationSupport().validateNotSelected("tierTypeID", form.getTierTypeID(), errors, new Object[]{"Contribution Tier Definition"});

        //One or the other required
        if (form.getActivityID().equals("0") && form.getActivityTypeCodeID().equals("0")) {
            getValidationSupport().validateNotSelected("activityID", form.getActivityID(), errors, new Object[]{"activityID"});
            getValidationSupport().validateNotSelected("activityTypeCodeID", form.getActivityTypeCodeID(), errors, new Object[]{"activityTypeCode"});
        }

        if (BPMAdminConstants.ACTION_SAVE.equals(form.getActionType())) {
            if (form.getProgramBenefitContractTypeIDs() != null) {
                for (int i = 0; i < form.getProgramBenefitContractTypeIDs().length; i++) {
                    if (isAllBenefitContractTypeSelected(form.getProgramBenefitContractTypeIDs()[i])) {
                        isAllBenefitContractTypesSelected = true;
                    }
                    getValidationSupport().validateNotSelected("programBenefitContractTypeIDs[" + i + "]", form.getProgramBenefitContractTypeIDs()[i], errors, new Object[]{"Benefit Contract Type"});
                }
            }

            if (!isAllBenefitContractTypesSelected) {
                if (form.getRelationshipIDs() != null) {
                    for (int i = 0; i < form.getRelationshipIDs().length; i++) {
                        getValidationSupport().validateNotSelected("relationshipIDs[" + i + "]", form.getRelationshipIDs()[i], errors, new Object[]{"Relationship"});
                    }
                }

                if (form.getContributionAmounts() != null) {
                    for (int i = 0; i < form.getContributionAmounts().length; i++) {
                        if(getValidationSupport().validateNotInteger("contributionAmounts["+i+"]", form.getContributionAmounts()[i], errors, new Object[]{"Amount"})){
                            getValidationSupport().validateNotSelected("contributionAmounts[" + i + "]", form.getContributionAmounts()[i], errors, new Object[]{"Amount"});
                            getValidationSupport().validateNotZero("contributionAmounts[" + i + "]", form.getContributionAmounts()[i], errors, new Object[]{"Amount"});
                        }
                    }
                }
            }
        }
    }

    private boolean isAllBenefitContractTypeSelected(String chosenBenefitContractTypeID) {
        boolean isAllBenefitContractTypeSelected = false;
        if (chosenBenefitContractTypeID == null) {
            chosenBenefitContractTypeID = "0";
        }
        try {
            if (chosenBenefitContractTypeID != null && businessProgramService != null) {
                LookUpValueCode lLookUpValueCode = businessProgramService.getBenefitContractTypeById(Integer.valueOf(chosenBenefitContractTypeID));
                if (lLookUpValueCode != null && lLookUpValueCode.getLuvVal().equals(BPMAdminConstants.BEN_CON_ALL)) {
                    isAllBenefitContractTypeSelected = true;
                }
            }
        } catch (BPMException e) {
            System.out.print("Error trying to determine if all benefit contract types was selected");

        }

        return isAllBenefitContractTypeSelected;
    }
}
