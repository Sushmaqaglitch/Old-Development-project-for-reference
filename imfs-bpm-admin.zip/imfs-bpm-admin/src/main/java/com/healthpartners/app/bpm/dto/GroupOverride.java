package com.healthpartners.app.bpm.dto;

import java.io.Serializable;

public class GroupOverride implements Serializable {
    static final long serialVersionUID = 0L;

    // Database table ID.
    private Integer groupOverrideId;
    private String groupNo;
    private String siteNo;
    private Integer groupId;
    private Integer siteId;
    private String groupName;
    private String siteName;
    private String bizProgTypeCodeId;
    private String bizProgramName;
    private String exceptionTypeDesc;
    private Integer exceptionTypeCodeId;
    private String reason;
    private String approverId;
    private java.sql.Date issueDate;
    private java.sql.Date effectiveDate;
    private java.sql.Date endDate;
    private String userId;
    private Integer rowNumber;
    private Integer programID;

    public Integer getRowNumber() {
        return rowNumber;
    }

    public void setRowNumber(Integer rowNumber) {
        this.rowNumber = rowNumber;
    }

    public Integer getGroupOverrideId() {
        return groupOverrideId;
    }

    public void setGroupOverrideId(Integer groupOverrideId) {
        this.groupOverrideId = groupOverrideId;
    }


    public String getGroupNo() {
        return groupNo;
    }

    public void setGroupNo(String groupNo) {
        this.groupNo = groupNo;
    }

    public String getSiteNo() {
        return siteNo;
    }

    public void setSiteNo(String siteNo) {
        this.siteNo = siteNo;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getApproverId() {
        return approverId;
    }

    public void setApproverId(String approverId) {
        this.approverId = approverId;
    }

    public java.sql.Date getIssueDate() {
        return issueDate;
    }

    public void setIssueDate(java.sql.Date issueDate) {
        this.issueDate = issueDate;
    }

    public java.sql.Date getEffectiveDate() {
        return effectiveDate;
    }

    public void setEffectiveDate(java.sql.Date effectiveDate) {
        this.effectiveDate = effectiveDate;
    }

    public java.sql.Date getEndDate() {
        return endDate;
    }

    public void setEndDate(java.sql.Date endDate) {
        this.endDate = endDate;
    }

    public String getSiteName() {
        return siteName;
    }

    public void setSiteName(String siteName) {
        this.siteName = siteName;
    }

    public String getBizProgTypeCodeId() {
        return bizProgTypeCodeId;
    }

    public void setBizProgTypeCodeId(String bizProgTypeCodeId) {
        this.bizProgTypeCodeId = bizProgTypeCodeId;
    }

    public String getExceptionTypeDesc() {
        return exceptionTypeDesc;
    }

    public void setExceptionTypeDesc(String exceptionTypeDesc) {
        this.exceptionTypeDesc = exceptionTypeDesc;
    }

    public Integer getExceptionTypeCodeId() {
        return exceptionTypeCodeId;
    }

    public void setExceptionTypeCodeId(Integer exceptionTypeCodeId) {
        this.exceptionTypeCodeId = exceptionTypeCodeId;
    }

    public Integer getGroupId() {
        return groupId;
    }

    public void setGroupId(Integer groupId) {
        this.groupId = groupId;
    }

    public Integer getSiteId() {
        return siteId;
    }

    public void setSiteId(Integer siteId) {
        this.siteId = siteId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getBizProgramName() {
        return bizProgramName;
    }

    public void setBizProgramName(String bizProgramName) {
        this.bizProgramName = bizProgramName;
    }

    public Integer getProgramID() {
        return programID;
    }

    public void setProgramID(Integer programID) {
        this.programID = programID;
    }


}
