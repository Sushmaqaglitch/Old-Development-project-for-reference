package com.healthpartners.app.bpm.controller;

import com.healthpartners.app.bpm.common.BPMAdminConstants;
import com.healthpartners.app.bpm.common.BPMAdminUtils;
import com.healthpartners.app.bpm.dto.*;
import com.healthpartners.app.bpm.exception.BPMException;
import com.healthpartners.app.bpm.form.BaseForm;
import com.healthpartners.app.bpm.form.SaveProgramActivityForm;
import com.healthpartners.app.bpm.form.SaveProgramActivitySiteForm;
import com.healthpartners.app.bpm.iface.BusinessProgramService;
import com.healthpartners.app.bpm.iface.LookUpValueService;
import jakarta.servlet.http.HttpServletRequest;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.view.RedirectView;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.HashMap;

@Controller
public class ProgramActivityController extends BaseController implements Validator {

    private static final String ACTION_SAVE = "save";
    private static final String ACTION_SAVE_TO_ALL_SITES = "saveToAllSites";
    private static final String ACTION_SAVE_TO_SELECTED = "saveToSelected";
    private static final String ACTION_ADD_PACKAGE = "addPackage";
    private static final String ACTION_REMOVE_PACKAGE = "removePackage";
    private static final String ACTION_ADD = "add";
    private static final String ACTION_REMOVE = "remove";
    protected final Log logger = LogFactory.getLog(getClass());
    private final BusinessProgramService businessProgramService;
    private final LookUpValueService lookUpValueService;


    public ProgramActivityController(BusinessProgramService businessProgramService, LookUpValueService lookUpValueService) {
        this.businessProgramService = businessProgramService;
        this.lookUpValueService = lookUpValueService;
    }

    @PostMapping(value = "/saveProgramActivity")
    public String submitActivityProgram(@ModelAttribute("saveProgramActivityForm") SaveProgramActivityForm form, ModelMap modelMap, BindingResult result, HttpServletRequest request, RedirectAttributes ra) {
        try {
            request.setAttribute("luvIncentiveOverrideCodeTypes", getUserSession().getIncentiveOverrideCodeTypes());
            modelMap.put("luvIncentiveOverrideCodeTypes", getUserSession().getIncentiveOverrideCodeTypes());
            validate(form, result);
            if (result.hasErrors()) {
                populateFromForm(form, modelMap, request);
            } else {
                if (ACTION_ADD.equals(form.getActionType())) {
                    addProgramActivity(form, modelMap, request);
                }
                if (ACTION_REMOVE.equals(form.getActionType())) {
                    removeProgramActivity(form, modelMap, request);
                }
                if (ACTION_ADD_PACKAGE.equals(form.getActionType())) {
                    addPackageActivities(form, modelMap, request);
                }
                if (ACTION_REMOVE_PACKAGE.equals(form.getActionType())) {
                    removePackageActivities(form, modelMap, request);
                }
                if (ACTION_SAVE.equals(form.getActionType()) || ACTION_SAVE_TO_ALL_SITES.equals(form.getActionType()) || ACTION_SAVE_TO_SELECTED.equals(form.getActionType())) {
                    return performSave(form, modelMap, request, result, ra);
                }
            }
        } catch (Exception e) {
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
            // Add error stack trace on the request, to be hidden in html.
            createErrorMessageOnModel(modelMap, getStackTrace(e));
        }

        // Add package also forwards to the same jsp.
        return "programActivities";
    }

    @PostMapping(value = "/saveProgramActivity", params = "cancel")
    public RedirectView submitCancelEditProgram(@ModelAttribute("saveProgramActivityForm") SaveProgramActivityForm saveProgramActivityForm, RedirectAttributes ra) {
        ra.addFlashAttribute("groupNumber", saveProgramActivityForm.getGroupNumber());
        String url = "viewProgram?programID=" + saveProgramActivityForm.getProgramID();
        return new RedirectView(url);
    }

    private String performSave(SaveProgramActivityForm form, ModelMap modelMap, HttpServletRequest request, Errors errors, RedirectAttributes ra) throws Exception {
        modelMap.put("luvIncentiveOverrideCodeTypes", getUserSession().getIncentiveOverrideCodeTypes());
        validate(form, errors);
        if (errors.hasErrors()) {
            populateFromForm(form, modelMap, request);
            return "programActivities";
        } else {
            BusinessProgram lBusinessProgram = getUserSession().getBusinessProgram();
            String lUserID = getUserSessionSupport().getAuthenticatedUsername();
            int position = getUserSession().getEligibleActivities().size() - 1;

            if (isPrePostEnrollmentExist(form)) {

                if (isPreEnrollmentEligibleActivityDatesAfterNonPreEnrollmentEligibleActivityStartDate()) {
                    getValidationSupport().addValidationFailureMessage("incentiveOverrideCodeIDs["+position+"]", errors, "errors.preEnrollmentEndDateAfter", null);
                }

                if (isPostEnrollmentEligibleActivityDatesBeforeNonPostEnrollmentEligibleActivityEndDate()) {
                    getValidationSupport().addValidationFailureMessage("incentiveOverrideCodeIDs["+position+"]", errors, "errors.postEnrollmentStartDateBefore", null);
                }

                if (isPreEnrollmentEligibleActivityDatesAfterProgramQualificationStartDate(lBusinessProgram)) {
                    getValidationSupport().addValidationFailureMessage("incentiveOverrideCodeIDs["+position+"]", errors, "errors.preEnrollmentEndDateAfterProgramStartDate", null);
                }

                validatePostEnrollmentEligibleActivityDatesNotBeforeProgramQualificationEndDate(lBusinessProgram, form, errors);
            }

            if (isDuplicatesInEnrollmentEligibleActivities()) {
                getValidationSupport().addValidationFailureMessage("incentiveOverrideCodeIDs["+position+"]", errors, "errors.enrollmentActivityDuplicatesExist", null);
            }

            if (isMissingPrePostIncentiveOverrideForNonPrePostEnrollmentEligibleActivity()) {
                getValidationSupport().addValidationFailureMessage("incentiveOverrideCodeIDs["+position+"]", errors, "errors.missingPrePostIncentiveOverride", null);
            }
            if (errors.hasErrors()) {
                populateFromForm(form, modelMap, request);
                return "programActivities";
            }

            if (ACTION_SAVE.equals(form.getActionType())) {
                boolean eligibleActivityUpdateAllowed = saveProgramActivities(form, modelMap, lUserID);
                //if update not allowed, error.
                if (!eligibleActivityUpdateAllowed) {
                    createActionMessagesOnModel(modelMap, "errors.updateEligibleActivityNotAllowed", null);
                    position = getUserSession().getEligibleActivities().size() - 1;
                    getValidationSupport().addValidationFailureMessage("incentiveOverrideCodeIDs["+position+"]", errors, "errors.updateEligibleActivityNotAllowed", null);
                    populateFromForm(form, modelMap, request);
                    return "programActivities"; //mapping.findForward(FAILURE);
                }
            } else if (ACTION_SAVE_TO_ALL_SITES.equals(form.getActionType())) {
                // reprocessAndRecalculate is called inside saveToAllSites.
                saveToAllSites(form, modelMap, lUserID);
            } else if (ACTION_SAVE_TO_SELECTED.equals(form.getActionType())) {
                saveToSelectedSites(form, modelMap);
                return "programActivitySites";
            }

            findAvailablePackage(modelMap);
            populateRequest(form, modelMap, request);
        }

        // Redirect back to the viewProgram screen upon successful process of saves
        ra.addFlashAttribute("groupNumber", form.getGroupNumber());
        String url = "viewProgram?programID=" + form.getProgramID();
        return "redirect:" + url;
    }

    private void saveToSelectedSites(SaveProgramActivityForm form, ModelMap modelMap) throws BPMException {
        if (getUserSessionSupport().setupUserSession().getAvailableSites() != null) {
            getUserSessionSupport().setupUserSession().getAvailableSites().clear();
        }

        if (getUserSessionSupport().setupUserSession().getEmployerSubGroups() != null) {
            getUserSessionSupport().setupUserSession().getEmployerSubGroups().clear();
        }

        ArrayList<EligibleActivity> lEligibleActivities = createEligibleActivityList(form);
        getUserSessionSupport().setupUserSession().setEligibleActivities(lEligibleActivities);
        Collection<EmployerGroup> lSubGroups = businessProgramService.getBusinessProgramInSameYear(getUserSessionSupport().setupUserSession().getBusinessProgram().getProgramID());

        modelMap.put("businessProgram", getUserSessionSupport().setupUserSession().getBusinessProgram());
        modelMap.put("selectedSubGroups", lSubGroups);

        getUserSessionSupport().setupUserSession().setEmployerSubGroups((ArrayList<EmployerGroup>) lSubGroups);
        getUserSessionSupport().setupUserSession().setWhichSaveSelectedSite(WHICH_SAVE_SELECTED_SITES_ACTIVITIES);

        SaveProgramActivitySiteForm saveProgramActivitySiteForm = new SaveProgramActivitySiteForm();
        saveProgramActivitySiteForm.setSubGroupID(((ArrayList<EmployerGroup>) lSubGroups).get(0).getSubgroupID());
        modelMap.put("saveProgramActivitySiteForm", saveProgramActivitySiteForm);
    }

    private void saveToAllSites(SaveProgramActivityForm form, ModelMap modelMap, String pUserID) throws Exception {
        ArrayList<EligibleActivity> lEligibleActivities = createEligibleActivityList(form);

        businessProgramService.saveEligibleActivitiesAllSites(getUserSession().getBusinessProgram(), lEligibleActivities, pUserID);

        // Now that the new eligible activities have been saved, get a fresh list from the database.
        lEligibleActivities = (ArrayList<EligibleActivity>) businessProgramService.getEligibleActivities(getUserSession().getBusinessProgram().getProgramID());

        businessProgramService.updateBusinessProgram(getUserSession().getBusinessProgram(), pUserID);

        // Boolean indicates all programs and not just ACTIVEs.
        // Just retrieve ACTIVEs.
        BusinessProgram lBusinessProgram = businessProgramService.getBusinessProgram(getUserSession().getBusinessProgram().getProgramID(), false);

        getUserSession().setBusinessProgram(lBusinessProgram);
        getUserSession().setEligibleActivities(lEligibleActivities);

        modelMap.put("programIncentiveOptions", getUserSession().getProgramIncentiveOptions());
        modelMap.put("businessProgram", getUserSession().getBusinessProgram());
        modelMap.put("eligibleActivities", getUserSession().getEligibleActivities());
        modelMap.put("additionalInfos", getUserSession().getAdditionalInfos());
    }

    private ArrayList<EligibleActivity> createEligibleActivityList(SaveProgramActivityForm pSaveProgramActivityForm) {
        Integer[] lActivityIDs = pSaveProgramActivityForm.getActivityIDs();
        ArrayList<EligibleActivity> lEligibleActivities = new ArrayList<>();

        if (lActivityIDs != null && lActivityIDs.length > 0) {
            for (int i = 0; i < lActivityIDs.length; i++) {
                EligibleActivity lEligibleActivity = new EligibleActivity();

                if (getUserSessionSupport().setupUserSession().getEligibleActivities() != null) {
                    for (EligibleActivity lSessionEligibleActivity : getUserSessionSupport().setupUserSession().getEligibleActivities()) {
                        if (lSessionEligibleActivity.getActivity().getActivityID().intValue() == lActivityIDs[i].intValue()) {
                            lEligibleActivity.setActivity(lSessionEligibleActivity.getActivity());
                        }
                    }
                }

                lEligibleActivity.setProgramID(getUserSessionSupport().setupUserSession().getBusinessProgram().getProgramID());
                lEligibleActivity.setQualificationWindowEarlyStartDate(BPMAdminUtils.getSqlDateFromString(pSaveProgramActivityForm.getActivityStartDates()[i]));
                lEligibleActivity.setQualificationWindowLateEndDate(BPMAdminUtils.getSqlDateFromString(pSaveProgramActivityForm.getActivityEndDates()[i]));

                // 11/24/08: The plain start and end date are not used anymore. But populate them so they don't cause null pointer exceptions.
                lEligibleActivity.setQualificationWindowStartDate(BPMAdminUtils.getSqlDateFromString(pSaveProgramActivityForm.getActivityStartDates()[i]));
                lEligibleActivity.setQualificationWindowEndDate(BPMAdminUtils.getSqlDateFromString(pSaveProgramActivityForm.getActivityEndDates()[i]));

                lEligibleActivity.setEnrollmentDeadlineDate(BPMAdminUtils.getSqlDateFromString(pSaveProgramActivityForm.getEnrollDeadlineDates()[i]));

                // Initialize the Exclusion Flag to N.
                lEligibleActivity.setExclusionOptionFlag("N");

                lEligibleActivity.getActivity().setActivityID(pSaveProgramActivityForm.getActivityIDs()[i]);

                lEligibleActivity.setIncentiveOverrideCodeID(Integer.valueOf(pSaveProgramActivityForm.getIncentiveOverrideCodeIDs()[i]));

                if (i < pSaveProgramActivityForm.getActivityNames().length) {
                    lEligibleActivity.setActivityName(pSaveProgramActivityForm.getActivityNames()[i]);
                }

                if (i < pSaveProgramActivityForm.getActivityDescs().length) {
                    lEligibleActivity.setActivityDesc(pSaveProgramActivityForm.getActivityDescs()[i]);
                }

                lEligibleActivities.add(lEligibleActivity);
            }
        }

        return lEligibleActivities;
    }

    private boolean saveProgramActivities(SaveProgramActivityForm form, ModelMap modelMap, String pUserID) throws Exception {
        boolean eligibleActivityUpdateAllowed = true;

        Integer[] lActivityIDs = form.getActivityIDs();
        ArrayList<EligibleActivity> lEligibleActivities = new ArrayList<>();

        if (lActivityIDs != null && lActivityIDs.length > 0) {
            for (int i = 0; i < lActivityIDs.length; i++) {
                //EV58500 - no longer use extended auth code for pre or post enrollment.
		    	/*if (lSaveProgramActivityForm.getIncentiveOverrideCodeIDs()[i] != null && Integer.valueOf(lSaveProgramActivityForm.getIncentiveOverrideCodeIDs()[i]) > 0) {

	            	Collection<AuthCode> lAuthCodes = businessProgramService.getExtendedAuthCode(sessionBean.getBusinessProgram().getProgramID(), lSaveProgramActivityForm.getAuthCodes()[i]);

	            	if (lAuthCodes.isEmpty()) {
	            		extendedAuthCodeMissing = true;
	            		break;
	            	}
	            }*/

                EligibleActivity lEligibleActivity = new EligibleActivity();
                Activity lActivity = new Activity();
                lEligibleActivity.setActivity(lActivity);

                lEligibleActivity.setProgramID(getUserSession().getBusinessProgram().getProgramID());
                lEligibleActivity.setQualificationWindowEarlyStartDate(BPMAdminUtils.getSqlDateFromString(form.getActivityStartDates()[i]));
                lEligibleActivity.setQualificationWindowLateEndDate(BPMAdminUtils.getSqlDateFromString(form.getActivityEndDates()[i]));

                // 11/24/08: The plain start and end date are not used anymore. But populate them so they don't cause null pointer exceptions.
                lEligibleActivity.setQualificationWindowStartDate(BPMAdminUtils.getSqlDateFromString(form.getActivityStartDates()[i]));
                lEligibleActivity.setQualificationWindowEndDate(BPMAdminUtils.getSqlDateFromString(form.getActivityEndDates()[i]));

                //EV58500 - add incentive override indicator for pre and post enrollment activities.
                lEligibleActivity.setIncentiveOverrideCodeID(Integer.valueOf(form.getIncentiveOverrideCodeIDs()[i]));

                /*Derive enrollment deadline date from qualification end date minus  activity duration.
                 * If enrollment date is null, calculate otherwise use the date entered by the user which overrides a date
                 *calculation off of the activity duration.
                 */
                java.sql.Date enrollmentDeadlineDate = BPMAdminUtils.getSqlDateFromString(form.getEnrollDeadlineDates()[i]);
                if (enrollmentDeadlineDate == null) {
                    enrollmentDeadlineDate = calculateEnrollmentDeadlineDate(getUserSession().getBusinessProgram().getQualificationWindowEndDate(), form.getActivityDurations()[i]);
                }
                lEligibleActivity.setEnrollmentDeadlineDate(enrollmentDeadlineDate);

                // Initialize the Exclusion Flag to N.
                lEligibleActivity.setExclusionOptionFlag("N");

                lEligibleActivity.getActivity().setActivityID(form.getActivityIDs()[i]);

                if (i < form.getActivityNames().length) {
                    lEligibleActivity.setActivityName(form.getActivityNames()[i]);
                }

                if (i < form.getActivityDescs().length) {
                    lEligibleActivity.setActivityDesc(form.getActivityDescs()[i]);
                }


                lEligibleActivities.add(lEligibleActivity);
            }
        }

        if (getUserSession().getEligibleActivitiesRemoved() != null && getUserSession().getEligibleActivitiesRemoved().size() > 0) {
            ArrayList<EligibleActivity> lEligibleActivitiesToRemove = getUserSession().getEligibleActivitiesRemoved();
            for (EligibleActivity lEligibleActivityToRemove : lEligibleActivitiesToRemove) {
                if (businessProgramService.isEligibleActivityUsedByParticipant(lEligibleActivityToRemove)) {
                    //restore removed activities to list of assigned activities.
                    eligibleActivityUpdateAllowed = false;
                    //add remove activities back to assigned activities
                    getUserSession().getEligibleActivities().add(lEligibleActivityToRemove);
                } else {
                    businessProgramService.deleteEligibleActivityByStartDate(lEligibleActivityToRemove);
                }
            }
            //Update not allowed.return back to screen with error.
            if (!eligibleActivityUpdateAllowed) {
                getUserSession().getEligibleActivitiesRemoved().clear();
                modelMap.put("programIncentiveOptions", getUserSession().getProgramIncentiveOptions());
                modelMap.put("businessProgram", getUserSession().getBusinessProgram());
                modelMap.put("eligibleActivities", getUserSession().getEligibleActivities());
                modelMap.put("additionalInfos", getUserSession().getAdditionalInfos());
                return eligibleActivityUpdateAllowed;
            }
        }

        // The DAO will find existing ones for Update, and Insert new ones.
        businessProgramService.deleteInsertEligibleActivity(getUserSession().getBusinessProgram().getProgramID(), lEligibleActivities, pUserID);

        int updateEligCt = lEligibleActivities.size();

        lEligibleActivities = (ArrayList<EligibleActivity>) businessProgramService.getEligibleActivities(getUserSession().getBusinessProgram().getProgramID());

        int afterEligCt = lEligibleActivities.size();

        /*
         * Check to see if a remove of eligible activities was allowed.  If number of eligible activities read
         * is more than what was attempted to be updated, it indicates that one or more eligible activities were attempted to
         * be removed but not allowed.  If any participants are active with an activity, then no eligible activities can be removed.
         */
        if (afterEligCt > updateEligCt) {
            eligibleActivityUpdateAllowed = false;
        }

        businessProgramService.updateBusinessProgram(getUserSession().getBusinessProgram(), pUserID);

        // Boolean indicates all programs and not just ACTIVEs.
        // Just retrieve ACTIVEs.
        BusinessProgram lBusinessProgram =
                businessProgramService.getBusinessProgram(getUserSession().getBusinessProgram().getProgramID(), false);

        getUserSession().setBusinessProgram(lBusinessProgram);
        getUserSession().setEligibleActivities(lEligibleActivities);

        modelMap.put("programIncentiveOptions", getUserSession().getProgramIncentiveOptions());
        modelMap.put("businessProgram", getUserSession().getBusinessProgram());
        modelMap.put("eligibleActivities", getUserSession().getEligibleActivities());
        modelMap.put("additionalInfos", getUserSession().getAdditionalInfos());

        return eligibleActivityUpdateAllowed;
    }

    /*
     * Assign field attributes from form to eligible activity DTO in preparation for date edits besides determining if a
     * pre or post enrollment eligible activity exists.
     */
    private boolean isPrePostEnrollmentExist(SaveProgramActivityForm lSaveProgramActivityForm) throws BPMException {
        boolean prePostEnrollmentExist = false;
        ArrayList<EligibleActivity> lEligibleActivities = getUserSession().getEligibleActivities();

        String[] lIncentiveOverrideCodeIDs = lSaveProgramActivityForm.getIncentiveOverrideCodeIDs();
        Integer[] lActivityIDs = lSaveProgramActivityForm.getActivityIDs();
        String[] lActivityStartDates = lSaveProgramActivityForm.getActivityStartDates();
        String[] lActivityEndDates = lSaveProgramActivityForm.getActivityEndDates();

        try {
            //Match on activity and qualification start date. Assign incentive activity override code and effective dates.
            if (lIncentiveOverrideCodeIDs != null) {
                for (int i = 0; i < lIncentiveOverrideCodeIDs.length; i++) {
                    boolean isNonPrePostEnrollmentExist = false;
                    //check for pre or post enrollment activity.
                    if (lIncentiveOverrideCodeIDs[i] != null && Integer.parseInt(lIncentiveOverrideCodeIDs[i]) > 0) {
                        prePostEnrollmentExist = true;
                        for (EligibleActivity lEligibleActivity : lEligibleActivities) {
                            if (lActivityIDs[i].equals(lEligibleActivity.getActivity().getActivityID()) && BPMAdminUtils.getSqlDateFromString(lActivityStartDates[i]).equals(lEligibleActivity.getQualificationWindowStartDate())) {
                                isNonPrePostEnrollmentExist = true;
                                assignFormAttributesToEligibleActivity(lEligibleActivity, lIncentiveOverrideCodeIDs[i], lActivityStartDates[i],  lActivityEndDates[i]);
                                break;
                            }
                        }
                    }
                }
            }
        } catch (BPMException e) {
            throw e;
        }

        return prePostEnrollmentExist;
    }

    /*
     * Compare pre enrollment activity effective dates to make sure they are before qualification start date of non pre/post
     * enrollment eligible activity.
     */
    private boolean isPreEnrollmentEligibleActivityDatesAfterNonPreEnrollmentEligibleActivityStartDate() {
        boolean afterActivityStartDateForNonPreEnrollment = false;

        ArrayList<EligibleActivity> lEligibleActivities = getUserSession().getEligibleActivities();
        HashMap<Integer, EligibleActivity> activityAuthCodeMap = new HashMap<>();

        for (EligibleActivity lEligibleActivity : lEligibleActivities) {
            if (lEligibleActivity.getIncentiveOverrideCodeID() != null)  {
                if(activityAuthCodeMap.containsKey(lEligibleActivity.getActivity().getActivityID())){
                    //detect pre enrollment activity already registered to hashmap.  If already registered,
                    //compare activities effective dates.
                    EligibleActivity lEligibleActivityFromMap = activityAuthCodeMap.get(lEligibleActivity.getActivity().getActivityID());
                    if (lEligibleActivity.getIncentiveOverrideCode().equals(BPMAdminConstants.INCENT_TYPE_PRE_ENROLLMENT) &&
                            lEligibleActivityFromMap.getIncentiveOverrideCode().equals(BPMAdminConstants.BPM_DEFAULT_FIRST_ITEM_IN_DROPDOWN)) {
                        afterActivityStartDateForNonPreEnrollment = isPreEnrollmentDateAfterNonPreEnrollmentStartDate(lEligibleActivity.getQualificationWindowLateEndDate(), lEligibleActivityFromMap.getQualificationWindowEarlyStartDate());
                    }
                    if (!afterActivityStartDateForNonPreEnrollment) {
                        if (lEligibleActivityFromMap.getIncentiveOverrideCode().equals(BPMAdminConstants.INCENT_TYPE_PRE_ENROLLMENT) &&
                                lEligibleActivity.getIncentiveOverrideCode().equals(BPMAdminConstants.BPM_DEFAULT_FIRST_ITEM_IN_DROPDOWN)) {

                            afterActivityStartDateForNonPreEnrollment = isPreEnrollmentDateAfterQualificationStartDate(lEligibleActivityFromMap.getQualificationWindowLateEndDate(), lEligibleActivity.getQualificationWindowEarlyStartDate());
                        }
                    }

                } else {
                    activityAuthCodeMap.put(lEligibleActivity.getActivity().getActivityID(), lEligibleActivity);
                }

            }

        }
        return afterActivityStartDateForNonPreEnrollment;
    }

    private boolean isPreEnrollmentDateAfterNonPreEnrollmentStartDate(java.sql.Date preEnrollmentEndDate, java.sql.Date nonPreEnrollmentStartDate) {

        boolean afterActivityStartDateForNonPreEnrollment = BPMAdminUtils.isAfterDate(preEnrollmentEndDate, nonPreEnrollmentStartDate);

        return afterActivityStartDateForNonPreEnrollment;
    }

    private boolean isPreEnrollmentDateAfterQualificationStartDate(java.sql.Date preEnrollmentEndDate, java.sql.Date programQualificationStartDate) {

        boolean afterProgramQualificationStartDate = false;

        if (BPMAdminUtils.isAfterDate(preEnrollmentEndDate, programQualificationStartDate)) {
            afterProgramQualificationStartDate = true;
        }

        return afterProgramQualificationStartDate;
    }

    /*
     * Compare post enrollment activity effective dates to make sure they are after qualification end date of non pre/post
     * enrollment eligible activity.
     */
    private boolean isPostEnrollmentEligibleActivityDatesBeforeNonPostEnrollmentEligibleActivityEndDate() {
        boolean beforeActivityEndDateForNonPreEnrollment = false;

        ArrayList<EligibleActivity> lEligibleActivities = getUserSession().getEligibleActivities();
        HashMap<Integer, EligibleActivity> activityAuthCodeMap = new HashMap<Integer, EligibleActivity>();

        for (EligibleActivity lEligibleActivity : lEligibleActivities) {
            if (lEligibleActivity.getIncentiveOverrideCodeID() != null) {
                if (activityAuthCodeMap.containsKey(lEligibleActivity.getActivity().getActivityID())) {
                    //detect post enrollment activity already registered to hashmap.  If already registered,
                    //compare activities effective dates.
                    EligibleActivity lEligibleActivityFromMap = activityAuthCodeMap.get(lEligibleActivity.getActivity().getActivityID());
                    if (lEligibleActivity.getIncentiveOverrideCode().equals(BPMAdminConstants.INCENT_TYPE_POST_ENROLLMENT) &&
                            lEligibleActivityFromMap.getIncentiveOverrideCode().equals(BPMAdminConstants.BPM_DEFAULT_FIRST_ITEM_IN_DROPDOWN)) {

                        beforeActivityEndDateForNonPreEnrollment = isPostEnrollmentDateBeforeQualificationEndDate(lEligibleActivity.getQualificationWindowEarlyStartDate(), lEligibleActivityFromMap.getQualificationWindowLateEndDate());
                    }
                    if (!beforeActivityEndDateForNonPreEnrollment) {
                        if (lEligibleActivityFromMap.getIncentiveOverrideCode().equals(BPMAdminConstants.INCENT_TYPE_POST_ENROLLMENT) &&
                                lEligibleActivity.getIncentiveOverrideCode().equals(BPMAdminConstants.BPM_DEFAULT_FIRST_ITEM_IN_DROPDOWN)) {

                            beforeActivityEndDateForNonPreEnrollment = isPostEnrollmentDateBeforeQualificationEndDate(lEligibleActivityFromMap.getQualificationWindowEarlyStartDate(), lEligibleActivity.getQualificationWindowLateEndDate());
                        }
                    }

                } else {
                    activityAuthCodeMap.put(lEligibleActivity.getActivity().getActivityID(), lEligibleActivity);
                }

            }

        }

        return beforeActivityEndDateForNonPreEnrollment;
    }

    private boolean isPostEnrollmentDateBeforeQualificationEndDate(java.sql.Date postEnrollmentEndDate, java.sql.Date programQualificationEndDate) {
        boolean beforeProgramQualificationEndDate = false;

        if (BPMAdminUtils.isBeforeDate(postEnrollmentEndDate, programQualificationEndDate)) {
            beforeProgramQualificationEndDate = true;
        }

        return beforeProgramQualificationEndDate;
    }

    /*
     * Compare pre enrollment activity effective dates to make sure they are after program qualification start date. of non pre/post
     * enrollment eligible activity.
     */
    private boolean isPreEnrollmentEligibleActivityDatesAfterProgramQualificationStartDate(BusinessProgram lBusinessProgram) {
        boolean afterQualificationStartDate = false;

        ArrayList<EligibleActivity> lEligibleActivities = getUserSession().getEligibleActivities();
        for (EligibleActivity lEligibleActivity : lEligibleActivities) {
            if (lEligibleActivity.getIncentiveOverrideCodeID() != null && lEligibleActivity.getIncentiveOverrideCodeID() > 0) {
                if (lEligibleActivity.getIncentiveOverrideCode().equals(BPMAdminConstants.INCENT_TYPE_PRE_ENROLLMENT)) {
                    afterQualificationStartDate = isPreEnrollmentDateAfterQualificationStartDate(lEligibleActivity.getQualificationWindowLateEndDate(), lBusinessProgram.getQualificationWindowStartDate());
                }
            }

        }

        return afterQualificationStartDate;
    }

    /*
     * Compare post enrollment activity effective dates to make sure they are after the program qualification end date.
     */
    private void validatePostEnrollmentEligibleActivityDatesNotBeforeProgramQualificationEndDate(BusinessProgram lBusinessProgram, SaveProgramActivityForm form, Errors errors) {
        ArrayList<EligibleActivity> lEligibleActivities = getUserSession().getEligibleActivities();
        HashMap<Integer, EligibleActivity> activityAuthCodeMap = new HashMap<Integer, EligibleActivity>();

        int i = 0;
        for (EligibleActivity lEligibleActivity : lEligibleActivities) {
            int code = Integer.valueOf(form.getIncentiveOverrideCodeIDs()[i]);
            if (lEligibleActivity.getIncentiveOverrideCodeID() != null && lEligibleActivity.getIncentiveOverrideCodeID() > 0 && code > 0) {
                if (lEligibleActivity.getIncentiveOverrideCode().equals(BPMAdminConstants.INCENT_TYPE_POST_ENROLLMENT)) {
                    if (isPostEnrollmentDateBeforeQualificationEndDate(lEligibleActivity.getQualificationWindowEarlyStartDate(), lBusinessProgram.getQualificationWindowEndDate())) {
                        getValidationSupport().addValidationFailureMessage("activityStartDates["+i+"]", errors, "errors.postEnrollmentStartDateBeforeProgramEndDate", null);
                    }
                }
            }
            i++;
        }
    }

    /*
     * Program ID, activity ID, and activity start date make up the primary key in the eligible program activity table.  Don't allow
     * duplicate program id, activity id, and start date to be entered.
     */
    private boolean isDuplicatesInEnrollmentEligibleActivities() {
        boolean isDuplicatesInEnrollmentEligibleActivity = false;

        ArrayList<EligibleActivity> lEligibleActivities = getUserSession().getEligibleActivities();
        HashMap<Integer, EligibleActivity> eligibleActivityMap = new HashMap<Integer, EligibleActivity>();

        for (EligibleActivity lEligibleActivity : lEligibleActivities) {
            if (lEligibleActivity.getIncentiveOverrideCodeID() != null) {
                if (eligibleActivityMap.containsKey(lEligibleActivity.getActivity().getActivityID())) {
                    //detect pre enrollment activity already registered to hashmap.  If already registered,
                    //compare activities effective dates.
                    EligibleActivity lEligibleActivityFromMap = eligibleActivityMap.get(lEligibleActivity.getActivity().getActivityID());
                    if (lEligibleActivity.getQualificationWindowEarlyStartDate().equals(lEligibleActivityFromMap.getQualificationWindowEarlyStartDate())) {
                        isDuplicatesInEnrollmentEligibleActivity = true;
                        break;
                    }

                } else {
                    eligibleActivityMap.put(lEligibleActivity.getActivity().getActivityID(), lEligibleActivity);
                }
            }
        }

        return isDuplicatesInEnrollmentEligibleActivity;
    }

    /*
     * Prevent more that one of the same activity from being entered if no incentive override has been selected.
     */
    private boolean isMissingPrePostIncentiveOverrideForNonPrePostEnrollmentEligibleActivity() {
        boolean isMissingPrePostIncentiveOverrideForNonPrePostEnrollmentEligibleActivity = false;

        ArrayList<EligibleActivity> lEligibleActivities = getUserSession().getEligibleActivities();
        HashMap<Integer, EligibleActivity> eligibleActivityMap = new HashMap<Integer, EligibleActivity>();

        for (EligibleActivity lEligibleActivity : lEligibleActivities) {
            if (lEligibleActivity.getIncentiveOverrideCodeID() != null) {
                if (eligibleActivityMap.containsKey(lEligibleActivity.getActivity().getActivityID())) {
                    //detect pre enrollment activity already registered to hashmap.  If already registered,
                    //check for activities incentive override indicator.
                    EligibleActivity lEligibleActivityFromMap = eligibleActivityMap.get(lEligibleActivity.getActivity().getActivityID());
                    if (lEligibleActivity.getIncentiveOverrideCodeID() == 0 &&
                            lEligibleActivityFromMap.getIncentiveOverrideCodeID().intValue() == 0) {
                        isMissingPrePostIncentiveOverrideForNonPrePostEnrollmentEligibleActivity = true;
                        break;
                    }

                } else {
                    eligibleActivityMap.put(lEligibleActivity.getActivity().getActivityID(), lEligibleActivity);
                }
            }
        }

        return isMissingPrePostIncentiveOverrideForNonPrePostEnrollmentEligibleActivity;
    }

    private void assignFormAttributesToEligibleActivity(EligibleActivity lEligibleActivity, String lIncentiveOverrideCodeID, String lActivityStartDate,  String lActivityEndDate) throws BPMException {
        lEligibleActivity.setIncentiveOverrideCodeID(Integer.valueOf(lIncentiveOverrideCodeID));
        try {
            LookUpValueCode lLookUpValueCode = lookUpValueService.getLUVCodeByID(Integer.valueOf(lIncentiveOverrideCodeID));
            lEligibleActivity.setIncentiveOverrideCode(lLookUpValueCode.getLuvVal());
        } catch(BPMException e) {
            logger.error("SaveProgramActivity.isPrePostEnrollmentExist:  BPMException error " + e);
            throw e;
        }

        lEligibleActivity.setQualificationWindowEarlyStartDate(BPMAdminUtils.getSqlDateFromString(lActivityStartDate));
        lEligibleActivity.setQualificationWindowLateEndDate(BPMAdminUtils.getSqlDateFromString(lActivityEndDate));
    }

    /**
     * Populate the Eligible Activity with the values the user entered.
     * Otherwise when going back to the page with lActionMessages , the values entered by the user would be lost.
     *
     * @param pSaveProgramActivityForm
     */
    private void populateFromForm(SaveProgramActivityForm pSaveProgramActivityForm, ModelMap modelMap, HttpServletRequest pRequest) throws BPMException {
        Integer[] lActivityIDs = pSaveProgramActivityForm.getActivityIDs();
        String[] lActivityStartDates = pSaveProgramActivityForm.getActivityStartDates();
        ArrayList<EligibleActivity> lEligibleActivities = getUserSession().getEligibleActivities();

        boolean removeAction = false;

        //if removeAction flag is true, indicates program activities are being removed so match on start date as part of matching criteria.
        if (lEligibleActivities != null && lActivityIDs != null && lEligibleActivities.size() < lActivityIDs.length) {
            removeAction = true;
        }

        if (lActivityIDs != null && lActivityIDs.length > 0) {
            int j = 0;
            for (int i = 0; i < lActivityIDs.length; i++) {
                for (j = i; j < lEligibleActivities.size(); j++) {
                    EligibleActivity lEligibleActivity = lEligibleActivities.get(j);
                    if (removeAction) {
                        if (lEligibleActivity.getActivity().getActivityID().intValue() == lActivityIDs[i].intValue() && lEligibleActivity.getQualificationWindowEarlyStartDate().equals(BPMAdminUtils.getSqlDateFromString(lActivityStartDates[i]))) {
                            lEligibleActivity.setEnrollmentDeadlineDate(BPMAdminUtils.getSqlDateFromString(pSaveProgramActivityForm.getEnrollDeadlineDates()[i]));
                            lEligibleActivity.setQualificationWindowEarlyStartDate(BPMAdminUtils.getSqlDateFromString(pSaveProgramActivityForm.getActivityStartDates()[i]));
                            lEligibleActivity.setQualificationWindowLateEndDate(BPMAdminUtils.getSqlDateFromString(pSaveProgramActivityForm.getActivityEndDates()[i]));
                            lEligibleActivity.setIncentiveOverrideCodeID(Integer.valueOf(pSaveProgramActivityForm.getIncentiveOverrideCodeIDs()[i]));
                            if (i < pSaveProgramActivityForm.getActivityNames().length) {
                                lEligibleActivity.setActivityName(pSaveProgramActivityForm.getActivityNames()[i]);
                            }

                            if (i < pSaveProgramActivityForm.getActivityDescs().length) {
                                lEligibleActivity.setActivityDesc(pSaveProgramActivityForm.getActivityDescs()[i]);
                            }
                            break;
                        }

                    } else if (i == j) {
                        lEligibleActivity.setEnrollmentDeadlineDate(BPMAdminUtils.getSqlDateFromString(pSaveProgramActivityForm.getEnrollDeadlineDates()[i]));
                        lEligibleActivity.setQualificationWindowEarlyStartDate(BPMAdminUtils.getSqlDateFromString(pSaveProgramActivityForm.getActivityStartDates()[i]));
                        lEligibleActivity.setQualificationWindowLateEndDate(BPMAdminUtils.getSqlDateFromString(pSaveProgramActivityForm.getActivityEndDates()[i]));
                        lEligibleActivity.setIncentiveOverrideCodeID(Integer.valueOf(pSaveProgramActivityForm.getIncentiveOverrideCodeIDs()[i]));

                        if (pSaveProgramActivityForm.getActivityNames() != null && i < pSaveProgramActivityForm.getActivityNames().length) {
                            lEligibleActivity.setActivityName(pSaveProgramActivityForm.getActivityNames()[i]);
                        }

                        if (pSaveProgramActivityForm.getActivityDescs() != null && i < pSaveProgramActivityForm.getActivityDescs().length) {
                            lEligibleActivity.setActivityDesc(pSaveProgramActivityForm.getActivityDescs()[i]);
                        }
                        break;
                    }
                }
            }
        }

        populateRequest(pSaveProgramActivityForm, modelMap, pRequest);
    }

    protected void populateRequest(SaveProgramActivityForm pSaveProgramActivityForm, ModelMap modelMap, HttpServletRequest pRequest) {
        modelMap.put("programPackages", getUserSession().getProgramPackages());
        modelMap.put("businessProgram", getUserSession().getBusinessProgram());
        modelMap.put("eligibleActivities", getUserSession().getEligibleActivities());
        modelMap.put("availableActivities", getUserSession().getAvailableActivities());
        modelMap.put("luvIncentiveOverrideCodeTypes", getUserSession().getIncentiveOverrideCodeTypes());
        modelMap.put("programCheckmarks", getUserSession().getProgramCheckmarks());
        modelMap.put("extendedAuthCodes", getUserSession().getExtendedAuthCodes());
        modelMap.put("changeLogList", getUserSession().getProgramChangeLogList());
        modelMap.put("benefitPackages", getUserSession().getBenefitPackages());
        modelMap.put("programIncentiveOptions", getUserSession().getProgramIncentiveOptions());
        modelMap.put("additionalInfos", getUserSession().getAdditionalInfos());
        BPMAdminUtils.populateProgramCheckmarkDefinition(getUserSession());
        modelMap.put("qualificationCheckmarks", getUserSession().getQualificationCheckmarks());
        modelMap.put("saveProgramActivityForm", pSaveProgramActivityForm);
    }

    private void addPackageActivities(SaveProgramActivityForm form, ModelMap modelMap, HttpServletRequest request) throws Exception {
        Integer lPackageID = form.getPackageID();
        ArrayList<PackageActivity> lPackageActivities = (ArrayList<PackageActivity>) businessProgramService.getPackageActivities(lPackageID);
        ArrayList<EligibleActivity> lEligibleActivities = getUserSession().getEligibleActivities();

        boolean lFound = false;
        // Loop through the Package Activities. If an activity is already selected as one of
        // the eligible activities of this biz program, skip it.
        for (int i = 0; i < lPackageActivities.size(); i++) {
            lFound = false;
            PackageActivity lPackageActivity = lPackageActivities.get(i);

            if (lEligibleActivities.size() == 0) {
                lFound = false;
            } else {
                for (int j = 0; (j < lEligibleActivities.size() && !lFound); j++) {
                    if (lEligibleActivities.get(j).getActivity().getActivityID().intValue() == lPackageActivity.getActivityID().intValue()) {
                        lFound = true;
                    }
                }
            }

            if (lFound == false) {
                // If activity is not already an eligible program activity, add it.
                addProgramActivity(lPackageActivity.getActivityID(), form);
            }
        }

        // Save the packageID of the package that was selected.
        getUserSession().getBusinessProgram().setPackageID(lPackageID);
        populateFromForm(form, modelMap, request);
        modelMap.put("eligibleActivities", lEligibleActivities);
    }

    private void addProgramActivity(SaveProgramActivityForm form, ModelMap modelMap, HttpServletRequest request) throws BPMException {
        Integer lActivityID = Integer.parseInt((String) request.getParameter("activityID"));

        if (lActivityID == null) {
            lActivityID = form.getActivityID();
        }

        populateFromFormForAdd(form, modelMap, request);
        addProgramActivity(lActivityID, form);
    }

    private void populateFromFormForAdd(SaveProgramActivityForm pSaveProgramActivityForm, ModelMap modelMap, HttpServletRequest pRequest) throws BPMException {
        Integer[] lActivityIDs = pSaveProgramActivityForm.getActivityIDs();
        ArrayList<EligibleActivity> lEligibleActivities = getUserSession().getEligibleActivities();

        if (lActivityIDs != null && lActivityIDs.length > 0) {
            for (int i = 0; i < lActivityIDs.length; i++) {
                for (EligibleActivity lEligibleActivity : lEligibleActivities) {
                    if (lEligibleActivity.getActivity().getActivityID().intValue() == lActivityIDs[i].intValue()) {
                        lEligibleActivity.setEnrollmentDeadlineDate(BPMAdminUtils.getSqlDateFromString(pSaveProgramActivityForm.getEnrollDeadlineDates()[i]));
                        lEligibleActivity.setQualificationWindowEarlyStartDate(BPMAdminUtils.getSqlDateFromString(pSaveProgramActivityForm.getActivityStartDates()[i]));
                        lEligibleActivity.setQualificationWindowLateEndDate(BPMAdminUtils.getSqlDateFromString(pSaveProgramActivityForm.getActivityEndDates()[i]));
                        lEligibleActivity.setIncentiveOverrideCodeID(Integer.valueOf(pSaveProgramActivityForm.getIncentiveOverrideCodeIDs()[i]));

                        if (pSaveProgramActivityForm.getActivityNames() != null && i < pSaveProgramActivityForm.getActivityNames().length) {
                            lEligibleActivity.setActivityName(pSaveProgramActivityForm.getActivityNames()[i]);
                        }

                        if (pSaveProgramActivityForm.getActivityDescs() != null && i < pSaveProgramActivityForm.getActivityDescs().length) {
                            lEligibleActivity.setActivityDesc(pSaveProgramActivityForm.getActivityDescs()[i]);
                        }
                    }
                }
            }
        }

        populateRequest(pSaveProgramActivityForm, modelMap, pRequest);
    }

    /**
     * Add the given activitiy to the eligible program activities. Remove it from the list of
     * available activities.
     *
     * @param lActivityID
     * @param lSaveProgramActivityForm
     */
    private void addProgramActivity(Integer lActivityID, SaveProgramActivityForm lSaveProgramActivityForm) {
        ArrayList<Activity> lAvailableActivities = (ArrayList<Activity>) getUserSession().getAvailableActivities();
        ArrayList<EligibleActivity> lEligibleActivities = (ArrayList<EligibleActivity>) getUserSession().getEligibleActivities();

        EligibleActivity lEligibleActivity = new EligibleActivity();
        lEligibleActivity.setProgramID(getUserSession().getBusinessProgram().getProgramID());

        // 11/24/08: The plain start and end date are not used anymore. But populate them so they don't cause null pointer exceptions.
        lEligibleActivity.setQualificationWindowStartDate(getUserSession().getBusinessProgram().getQualificationWindowStartDate());
        lEligibleActivity.setQualificationWindowEndDate(getUserSession().getBusinessProgram().getQualificationWindowEndDate());

        // Find the activity from the list of availables whose ID matches the one selected.
        for (int i = 0; i < lAvailableActivities.size(); i++) {
            Activity lActivity = (Activity) lAvailableActivities.get(i);
            // Once the ID is found, add the Activity to the Eligible Program Activities.
            if (lActivity.getActivityID().intValue() == lActivityID.intValue()) {
                lEligibleActivity.setActivity(lActivity);
                lEligibleActivity.setActivityName(lActivity.getName());
                lEligibleActivity.setActivityDesc(lActivity.getDescription());
                lEligibleActivities.add(lEligibleActivity);
                // Remove the activity from the list of available activities.
                // EV58500 - No longer remove from available list. Same activity can be selected multiple times
                // as long as a different auth code and dates do not overlap.
                //lAvailableActivities.remove(i);

                // If activity is HA, use the user-entered auth code.
                if (BPMAdminConstants.BPM_ADMIN_ACTIVITY_TYPE_HA.equals(lActivity.getActivityTypeValue())) {
                    // EV 18817 - For HA use Release Date (Communication Date) and Qual End Date.
                    lEligibleActivity.setQualificationWindowEarlyStartDate(getUserSession().getBusinessProgram().getReleaseDate());
                    lEligibleActivity.setQualificationWindowLateEndDate(getUserSession().getBusinessProgram().getEndDate());

                } else {
                    // If the activity is non-HA, use the user-entered promo code.

                    // EV 18817 - For non-HA use Qual Start Date, and Program End Date.
                    lEligibleActivity.setQualificationWindowEarlyStartDate(getUserSession().getBusinessProgram().getQualificationWindowStartDate());
                    lEligibleActivity.setQualificationWindowLateEndDate(getUserSession().getBusinessProgram().getEndDate());
                }

                java.sql.Date enrollmentDeadlineDate = calculateEnrollmentDeadlineDate(getUserSession().getBusinessProgram().getQualificationWindowEndDate(), lActivity.getDuration());

                lEligibleActivity.setEnrollmentDeadlineDate(enrollmentDeadlineDate);

                // If user had not entered an auth or promo code, generate one.
                if (lEligibleActivity.getAuthorizationCode() == null || lEligibleActivity.getAuthorizationCode().length() <= 0) {
                    BPMAdminUtils.generateAuthCode(getUserSession().getBusinessProgram(), lEligibleActivities, lEligibleActivity);
                }

                break;
            }
        }
    }

    /*Derive enrollment deadline date from qualification end date minus  activity duration.
     */
    private java.sql.Date calculateEnrollmentDeadlineDate(java.sql.Date qualificationEndDate, int duration) {
        Calendar calDate = Calendar.getInstance();
        calDate.setTime(qualificationEndDate);
        Calendar calEnrollDeadlineDate = BPMAdminUtils.getDateGivenDays(calDate, duration * -1);
        java.sql.Date enrollmentDeadlineDate = BPMAdminUtils.calendarToSqlDate(calEnrollDeadlineDate);

        return enrollmentDeadlineDate;
    }

    /**
     * Remove package activities from the list of eligible program activities.
     *
     * @param form
     * @param request
     * @throws Exception
     */
    private void removePackageActivities(SaveProgramActivityForm form, ModelMap modelMap, HttpServletRequest request) throws Exception {
        Integer lPackageID = form.getPackageID();
        java.sql.Date lActivityStartDate = BPMAdminUtils.getSqlDateFromString(request.getParameter("activityStartDate"));

        ArrayList<PackageActivity> lPackageActivities = (ArrayList<PackageActivity>) businessProgramService.getPackageActivities(lPackageID);

        for (int i = 0; i < lPackageActivities.size(); i++) {
            removeProgramActivity(lPackageActivities.get(i).getActivityID(), lActivityStartDate);
        }

        getUserSession().getBusinessProgram().setPackageID(0);
        populateFromForm(form, modelMap, request);
    }

    private void removeProgramActivity(Integer pActivityID, java.sql.Date activityStartDate) {
        ArrayList<Activity> lAvailableActivities = (ArrayList<Activity>) getUserSession().getAvailableActivities();
        ArrayList<EligibleActivity> lEligibleActivities = (ArrayList<EligibleActivity>) getUserSession().getEligibleActivities();
        ArrayList<EligibleActivity> lEligibleActivitiesRemoved = (ArrayList<EligibleActivity>) getUserSession().getEligibleActivitiesRemoved();

        if (lEligibleActivitiesRemoved == null) {
            lEligibleActivitiesRemoved = new ArrayList<>();
        }

        // Find the Program Eligible Activity whose ID matches the one selected.
        for (int i = 0; i < lEligibleActivities.size(); i++) {
            EligibleActivity lEligibleActivity = (EligibleActivity) lEligibleActivities.get(i);
            // Once the ID is found, remove the Incentive from the Program Incentive Options
            // and add it back to the list of Available Incentives.
            if (lEligibleActivity.getActivity().getActivityID().intValue() == pActivityID.intValue() &&
                    lEligibleActivity.getQualificationWindowEarlyStartDate().equals(activityStartDate)) {
                //EV58500 no longer remove available activities
//				lAvailableActivities.add(lEligibleActivity.getActivity());
                lEligibleActivities.remove(i);
                lEligibleActivitiesRemoved.add(lEligibleActivity);
                break;
            }
        }

        getUserSession().setEligibleActivities(lEligibleActivities);
        getUserSession().setAvailableActivities(lAvailableActivities);
        getUserSession().setEligibleActivitiesRemoved(lEligibleActivitiesRemoved);
    }

    /**
     * Remove an Activity from the Program Activities.
     *
     * @param form
     * @param request
     */
    private void removeProgramActivity(SaveProgramActivityForm form, ModelMap modelMap, HttpServletRequest request) throws BPMException {
        // The ID of the activity that was selected.
        Integer lActivityID = Integer.parseInt((String) request.getParameter("activityID"));

        // The ID of the activity that was selected.
        java.sql.Date lActivityStartDate = BPMAdminUtils.getSqlDateFromString((String) request.getParameter("activityStartDate"));

        if (lActivityID == null) {
            lActivityID = form.getActivityID();
        }
        if (lActivityStartDate == null) {
            String[] activityStartDates = form.getActivityStartDates();
            int activityIndex = Integer.parseInt(form.getActivityIndex());
            if (activityIndex >= 0 && activityIndex < activityStartDates.length) {
                lActivityStartDate = BPMAdminUtils.getSqlDateFromString(activityStartDates[activityIndex]);
            }
        }

        removeProgramActivity(lActivityID, lActivityStartDate);
        populateFromForm(form, modelMap, request);
    }

    protected void findAvailablePackage(ModelMap modelMap) throws Exception {
        ArrayList<ProgramPackage> lProgramPackages = (ArrayList<ProgramPackage>) businessProgramService.getProgramPackages();
        modelMap.put("programPackages", lProgramPackages);
        if (getUserSession().getProgramPackages() != null) {
            getUserSession().getProgramPackages().clear();
        }
        getUserSession().setProgramPackages(lProgramPackages);
    }

    @Override
    public boolean supports(Class<?> clazz) {
        return SaveProgramActivityForm.class.isAssignableFrom(clazz);
    }

    @Override
    public void validate(Object target, Errors errors) {
        BaseForm baseForm = (BaseForm) target;
        if (ACTION_ADD_PACKAGE.equals(baseForm.getActionType())) {
            SaveProgramActivityForm saveProgramActivityForm = (SaveProgramActivityForm) target;
            validatePackageAndProgramDates(getUserSession().getBusinessProgram(), getUserSession().getProgramPackages(), saveProgramActivityForm, errors);
        } else if (baseForm.getActionType().contains("save")) {
            SaveProgramActivityForm saveProgramActivityForm = (SaveProgramActivityForm) target;
            validateSaveProgramActivity(saveProgramActivityForm, errors);
        }
    }

    private void validatePackageAndProgramDates(BusinessProgram pBusinessProgram, ArrayList<ProgramPackage> pProgramPackages, SaveProgramActivityForm form, Errors errors) {
        ProgramPackage lProgramPackage = null;
        String businessProgramEffectiveDate = BPMAdminUtils.formatDateMMddyyyy(pBusinessProgram.getEffectiveDate());

        for (int i = 0; i < pProgramPackages.size(); i++) {
            lProgramPackage = pProgramPackages.get(i);
            if (lProgramPackage.getPackageID().intValue() == form.getProgramID().intValue()) {
                getValidationSupport().validateAfter("businessProgramEffDate", businessProgramEffectiveDate, lProgramPackage.getEffectiveDateString(), errors, new Object[]{"Program Effective Date", "Package Effective Date"});
                getValidationSupport().validateBeforeOrEqual("businessProgramEffDate", businessProgramEffectiveDate, lProgramPackage.getEndDateString(), "Program Effective Date", errors, new Object[]{"Package End Date"});
                break;
            }
        }
    }

    private void validateSaveProgramActivity(SaveProgramActivityForm form, Errors errors) {
        if (form.getActivityIDs() != null && form.getActivityIDs().length > 0) {
            for (int i = 0; i < form.getActivityIDs().length; i++) {
                getValidationSupport().validateDateFormat("activityStartDates["+i+"]", form.getActivityStartDates()[i], errors, new Object[]{"Start Date"});
                getValidationSupport().validateDateFormat("activityEndDates["+i+"]", form.getActivityEndDates()[i], errors, new Object[]{"End Date"});

                if (form.getEnrollDeadlineDates()[i].length() > 0) {
                    getValidationSupport().validateDateFormat("enrollDeadlineDates["+i+"]", form.getEnrollDeadlineDates()[i], errors, new Object[]{"Enrollment Deadline Date"});
                }

                if (form.getEnrollDeadlineDates()[i].length() > 0) {
                    getValidationSupport().validateAfter("enrollDeadlineDates["+i+"]", form.getEnrollDeadlineDates()[i], form.getActivityStartDates()[i], errors, new Object[]{"Enrollment Deadline Date", "Activity Start Date"});
                    getValidationSupport().validateBeforeOrEqual("enrollDeadlineDates["+i+"]", form.getEnrollDeadlineDates()[i], form.getActivityEndDates()[i], "enrollDeadlineDates["+i+"]", errors, new Object[]{"Enrollment Deadline Date", "Activity End Date"});
                }
            }
        }
    }
}
