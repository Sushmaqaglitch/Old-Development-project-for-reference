/* $Id$ */

package com.healthpartners.app.bpm.dao;

import com.healthpartners.app.bpm.dto.LookUpValueCode;
import org.springframework.dao.DataAccessException;

import java.util.Collection;

/**
 * Retrieves instances of <code>LookUpValueCode</code> from the
 * <code>LUV</code> table.
 * 
 * @author axpagey
 */
public interface LookUpValueDAO {

		
	/**
	 * Retrieves active LUV codes.
	 * 
	 * @return Collection of <code>LookUpValueCode</code> objects
	 * @throws DataAccessException
	 *             when a database-related error is encountered
	 */
	public Collection<LookUpValueCode> getActiveLUVCodes() throws DataAccessException;
	
	/**
	 * Retrieves all LUV codes.
	 * 
	 * @return Collection of <code>LookUpValueCode</code> objects
	 * @throws DataAccessException
	 *             when a database-related error is encountered
	 */
	public Collection<LookUpValueCode> getAllLUVCodes() throws DataAccessException;


	
	/**
	 * Retrieves a LUV record using the specified value code.
	 * 
	 * @param value
	 *            specifies the value code
	 * @return <code>LookUpValueCode</code> object, or null if not found
	 * @throws DataAccessException
	 *             when a database-related error is encountered
	 */
	public LookUpValueCode getLUVCodeByValue(String value)
			throws DataAccessException;
	
	/**
	 * Retrieves a LUV record using the specified group and value codes.
	 * 
	 * @param value
	 *            specifies the group and value code
	 * @return <code>LookUpValueCode</code> object, or null if not found
	 * @throws DataAccessException
	 *             when a database-related error is encountered
	 */
	public LookUpValueCode getLUVCodeByGroupNValue(String group, String value)
			throws DataAccessException;
	
	/**
	 * Retrieves a LUV record using the specified value code.
	 * 
	 * @param id
	 *            specifies the value code
	 * @return <code>LookUpValueCode</code> object, or null if not found
	 * @throws DataAccessException
	 *             when a database-related error is encountered
	 */
	public LookUpValueCode getLUVCodeById(Integer id)
			throws DataAccessException;
	
	/**
	 * Retrieves a LUV record using the specified group code.
	 * 
	 * @param group
	 *            specifies the group code
	 * @return <code>LookUpValueCode</code> object, or null if not found
	 * @throws DataAccessException
	 *             when a database-related error is encountered
	 */
	public Collection<LookUpValueCode> getLUVCodesByGroup(String group)
			throws DataAccessException;
	
	int insertLUVCode(LookUpValueCode code) throws DataAccessException;
	int updateLUVCode(LookUpValueCode code) throws DataAccessException;
	int deleteLUVCode(String group, String value)
	throws DataAccessException;
	
	public int deleteLUVCode(String value) throws DataAccessException;


}
