/**
 * 
 */
package com.healthpartners.app.bpm.form;


/**
 * @author f5929
 *
 */
public class AddInctvOptionRewardCardForm extends BaseForm {

	static final long serialVersionUID = 0L;
	
	private String actionType;

	public AddInctvOptionRewardCardForm() {
		super();
	}

	public String getActionType() {
		return actionType;
	}

	public void setActionType(String actionType) {
		this.actionType = actionType;
	}
		
	
}
