package com.healthpartners.app.bpm.dao;

import com.healthpartners.app.bpm.dto.BPMCollection;
import com.healthpartners.app.bpm.dto.CollectionActivity;
import com.healthpartners.app.bpm.exception.BPMException;
import jakarta.annotation.PostConstruct;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;

@Repository
@Transactional(timeout = 300, rollbackFor = {DataAccessException.class, BPMException.class})
public class CollectionDAOJdbc extends JdbcDaoSupport implements CollectionDAO {

    private static final String selectCollections = """
            SELECT
            collection_id
            , collection_nm
            , collection_info
            , collection_desc
            , reqrd_qty	
            , collection_tp_id	
            , (SELECT lu_val FROM luv WHERE lu_id  = collection_tp_id) collection_tp_code
            , (SELECT lu_desc FROM luv WHERE lu_id  = collection_tp_id) collection_tp_desc
            , eff_dt	
            , end_dt
            FROM collection			
            """;

    private static final String selectCollectionActivities = """
            SELECT collection_id
                 , collection_activity.ACTV_ID
                 , ACTV_NM
                 , (select lu_val from luv where lu_id = activity.actv_tp_cd_id) as actv_tp_code
                 , SRCE_ACTV_ID
            FROM
                 collection_activity, activity
            WHERE
            collection_id = ?
              AND collection_activity.actv_id = activity.actv_id
              AND trunc(SYSDATE) >= activity.ACTV_EFF_DT
              AND trunc(SYSDATE) <= activity.ACTV_END_DT
              ORDER BY actv_tp_code, actv_nm
            """;
	private final DataSource dataSource;


    public CollectionDAOJdbc(DataSource dataSource) {
		this.dataSource = dataSource;
    }

	@PostConstruct
	private void initialize() {
		setDataSource(dataSource);
	}

    @Override
    public ArrayList<BPMCollection> getAllCollections() throws DataAccessException {
        final ArrayList<BPMCollection> results = new ArrayList<BPMCollection>();

        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectCollections);
        lQuery.append(" ORDER BY collection_nm ");

        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{};
        int types[] = new int[]{};
        template.query(lQuery.toString(), params, types,
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        BPMCollection lBPMCollection = new BPMCollection();

                        lBPMCollection.setCollectionID(rs.getInt("collection_id"));
                        lBPMCollection.setCollectionName(rs.getString("collection_nm"));
                        lBPMCollection.setCollectionInfo(rs.getString("collection_info"));
                        lBPMCollection.setCollectionDesc(rs.getString("collection_desc"));
                        lBPMCollection.setRequiredQuantity(rs.getInt("reqrd_qty"));
                        lBPMCollection.setCollectionTypeCodeID(rs.getInt("collection_tp_id"));
                        lBPMCollection.setCollectionTypeCode("collection_tp_code");
                        lBPMCollection.setCollectionTypeDesc("collection_tp_desc");
                        lBPMCollection.setEffectiveDate(rs.getDate("eff_dt"));
                        lBPMCollection.setEndDate(rs.getDate("end_dt"));

                        results.add(lBPMCollection);
                    }
                });

        return results;
    }

    /**
     *
     * @param pCollectionID
     * @return
     */
    @Override
    public ArrayList<CollectionActivity> getCollectionActivities(Integer pCollectionID) throws BPMException, DataAccessException {
        final ArrayList<CollectionActivity> lCollectionActivityList = new ArrayList<CollectionActivity>();

        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{pCollectionID};
        int types[] = new int[]{Types.INTEGER};

        template.query(selectCollectionActivities, params, types, new RowCallbackHandler() {
            public void processRow(ResultSet rs) throws SQLException {
                CollectionActivity lCollectionActivity = new CollectionActivity();

                lCollectionActivity.setCollectionID(rs.getInt("collection_id"));
                lCollectionActivity.setActivityID(rs.getInt("actv_id"));
                lCollectionActivity.setActivityName(rs.getString("actv_nm"));
                lCollectionActivity.setActivityTypeCode(rs.getString("actv_tp_code"));
                lCollectionActivity.setSourceActivityID(rs.getString("SRCE_ACTV_ID"));

                lCollectionActivityList.add(lCollectionActivity);
            }
        });

        return lCollectionActivityList;
    }
}
