package com.healthpartners.app.bpm.dao;

import com.healthpartners.app.bpm.dto.RejectedPerson;
import com.healthpartners.app.bpm.exception.BPMException;
import jakarta.annotation.PostConstruct;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.jdbc.support.incrementer.DataFieldMaxValueIncrementer;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.sql.DataSource;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Collection;

@Repository
@Transactional(timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
public class EmployerRecycleDAOJdbc extends JdbcDaoSupport implements EmployerRecycleDAO{


    private final DataSource dataSource;

    public EmployerRecycleDAOJdbc (DataSource dataSource) {
        this.dataSource = dataSource;
    }

    private static final String selectEmployerRecycleWOptions = """
            SELECT	EPR_ID, 
					FIRST_NM, 
					MIDDLE_NM, 
					LAST_NM, 
					DOB_DT, 
					GENDER_CD, 
					(select LU_VAL from luv where lu_id=recycle_stat_cd_id) as RECYCLE_STATUS,
					RECYCLE_STAT_DT, 
					RSN_DESC, 
					CONTRIB_AMT,
					EXT_PRSN_ID, 
					APRV_USR_ID, 
					PRSN_DMGRPHCS_ID, 
					RECYC.ACTV_ID, 
					ACTV_DT,
					ACTV_NM
				
				FROM 
				  EMPL_PGM_RECYCLE RECYC,
				  ACTIVITY ACT
				WHERE
				  RECYC.ACTV_ID = ACT.ACTV_ID AND
				  RECYCLE_STAT_CD_ID = ? 
				  """;

    private static final String selectEmployerRecycle = """
            SELECT \s
            			  EPR_ID,\s
            			  FIRST_NM,\s
            			  MIDDLE_NM,\s
            			  LAST_NM,\s
            			  DOB_DT,\s
            			  GENDER_CD,\s
            			  (SELECT LU_VAL FROM luv WHERE lu_id = RECYCLE_STAT_CD_ID) recycle_status_cd,
            			  RECYCLE_STAT_CD_ID,
            			  RECYCLE_STAT_DT,\s
            			  RSN_DESC,
            			  CONTRIB_AMT,
            			  EXT_PRSN_ID,\s
            			  APRV_USR_ID,\s
            			  PRSN_DMGRPHCS_ID,
            			  CASE
            	             WHEN epr.PRSN_DMGRPHCS_ID is not null\s
            	             then (SELECT pd.HP_MEM_ID FROM PRSN_DEMOGRAPHICS PD WHERE epr.PRSN_DMGRPHCS_ID = pd.prsn_dmgrphcs_id)
            	             ELSE 'NOT AVAILABLE'
            	          END MEMBER_NO,\s
            			  epr.ACTV_ID,\s
            			  ACTV_DT,
            			  a.ACTV_NM,
            			  a.SRCE_ACTV_ID
            			FROM empl_pgm_recycle epr,
            			     activity a
            			WHERE EPR_ID = ? AND
            			      epr.actv_id = a.actv_id\s
            """;

    private static final String updateEmployerRecycle = """
        UPDATE empl_pgm_recycle
        SET FIRST_NM = ?, MIDDLE_NM = ?, LAST_NM = ?, DOB_DT = ?, GENDER_CD = ?
        , RECYCLE_STAT_CD_ID = (SELECT lu_id FROM  luv WHERE lu_grp = 'EMPL_RECYCLE_STATUS' and lu_val = ?)
        , RECYCLE_STAT_DT = SYSDATE, RSN_DESC = ?,\s
        APRV_USR_ID = ?, PRSN_DMGRPHCS_ID = ?, ACTV_ID = ?, ACTV_DT = ?,\s
        MODIFY_USR = ?,\s
        MODIFY_TS = SYSDATE\s
         WHERE EPR_ID = ?
    """;
    @PostConstruct
    private void initialize() {
        setDataSource(dataSource);
    }
    /**
     *
     * @param
     * 		  firstName
     * 		  lastName,
     * 		  recycleStatusDate
     *        recycleStatusId
     * @return
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Override
    public Collection<RejectedPerson> getEmployerRecycle(Integer activityId,
                                                         String firstName, String lastName, Date activityDate, Date recycleStatusDate, Integer recycleStatusId)
            throws DataAccessException {
        final Collection<RejectedPerson> results = new ArrayList<RejectedPerson>();
        StringBuffer query = new StringBuffer();
        query.append(selectEmployerRecycleWOptions);

        ArrayList<Object> lParameters = new ArrayList<Object>();
        ArrayList<Integer> lTypes = new ArrayList();


        lParameters.add(recycleStatusId);
        lTypes.add(Types.INTEGER);

        if (activityId != null && activityId != 0) {
            query.append("AND RECYC.ACTV_ID = ? ");
            lParameters.add(activityId);
            lTypes.add(Types.INTEGER);
        }

        if (firstName != null && firstName.length() > 0) {
            query.append("AND RECYC.FIRST_NM = UPPER(?) ");
            lParameters.add(firstName);
            lTypes.add(Types.VARCHAR);
        }

        if (lastName != null && lastName.length() > 0) {
            query.append("AND RECYC.LAST_NM = UPPER(?) ");
            lParameters.add(lastName);
            lTypes.add(Types.VARCHAR);
        }

        if (activityDate != null) {
            query.append("AND TRUNC(RECYC.ACTV_DT) = ? ");
            lParameters.add(activityDate);
            lTypes.add(Types.DATE);
        }

        if (recycleStatusDate != null) {
            query.append("AND TRUNC(RECYC.RECYCLE_STAT_DT) = ? ");
            lParameters.add(recycleStatusDate);
            lTypes.add(Types.DATE);
        }

        query.append("ORDER BY RECYC.LAST_NM, RECYC.FIRST_NM DESC");

        // Convert the parameter and types ArrayLists to arrays of primitive types.
        Object params[] = new Object[lParameters.size()];
        lParameters.toArray(params);

        int types[] = new int[lTypes.size()];
        for(int j = 0; j < lTypes.size(); j++)
        {
            types[j] = ((Integer)lTypes.get(j)).intValue();
        }

        JdbcTemplate template = getJdbcTemplate();

        template.query(query.toString(), params, types,
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        RejectedPerson lRejectedPerson = new RejectedPerson();

                        lRejectedPerson.setEmployerRecycleID(rs.getInt("EPR_ID"));
                        lRejectedPerson.setFirstName(rs.getString("first_nm"));
                        lRejectedPerson.setMiddleName(rs.getString("middle_nm"));
                        lRejectedPerson.setLastName(rs.getString("last_nm"));
                        lRejectedPerson.setDateOfBirth(rs.getDate("dob_dt"));
                        lRejectedPerson.setGender(rs.getString("gender_cd"));
                        lRejectedPerson.setRecycleStatusCode(rs.getString("RECYCLE_STATUS"));
                        lRejectedPerson.setRecycleStatusDate(rs.getDate("RECYCLE_STAT_DT"));
                        lRejectedPerson.setReasonDesc(rs.getString("RSN_DESC"));
                        lRejectedPerson.setApproverUserID(rs.getString("APRV_USR_ID"));
                        lRejectedPerson.setPersonDemographicsID(rs.getInt("PRSN_DMGRPHCS_ID"));
                        lRejectedPerson.setActivityID(rs.getInt("actv_id"));
                        lRejectedPerson.setActivityDate(rs.getDate("ACTV_DT"));
                        lRejectedPerson.setContributionAmount(rs.getInt("CONTRIB_AMT"));
                        lRejectedPerson.setExternalEmployerPersonId(rs.getString("EXT_PRSN_ID"));
                        lRejectedPerson.setActivityName(rs.getString("actv_nm"));

                        results.add(lRejectedPerson);
                    }
                });
        return results;
    }

    /**
     *
     * @param pRecycleStatusId
     * @return
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Override
    public RejectedPerson getEmployerRecycle(Integer pRecycleStatusId)
    {

        final ArrayList<RejectedPerson> results = new ArrayList<RejectedPerson>();
        Object params[] = new Object[]
                {
                        pRecycleStatusId
                };
        JdbcTemplate template = getJdbcTemplate();
        int types[] = new int[] { Types.INTEGER  };

        StringBuffer query = new StringBuffer();
        query.append(selectEmployerRecycle);


        template.query(query.toString(), params, types,
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        RejectedPerson lRejectedPerson = new RejectedPerson();

                        lRejectedPerson.setEmployerRecycleID(rs.getInt("EPR_ID"));
                        lRejectedPerson.setFirstName(rs.getString("first_nm"));
                        lRejectedPerson.setMiddleName(rs.getString("middle_nm"));
                        lRejectedPerson.setLastName(rs.getString("last_nm"));
                        lRejectedPerson.setDateOfBirth(rs.getDate("dob_dt"));
                        lRejectedPerson.setGender(rs.getString("gender_cd"));
                        lRejectedPerson.setRecycleStatusCode(rs.getString("recycle_status_cd"));
                        lRejectedPerson.setRecycleStatusCodeID(rs.getInt("RECYCLE_STAT_CD_ID"));
                        lRejectedPerson.setRecycleStatusDate(rs.getDate("RECYCLE_STAT_DT"));
                        lRejectedPerson.setReasonDesc(rs.getString("RSN_DESC"));
                        lRejectedPerson.setApproverUserID(rs.getString("APRV_USR_ID"));
                        lRejectedPerson.setPersonDemographicsID(rs.getInt("PRSN_DMGRPHCS_ID"));
                        lRejectedPerson.setMemberNo(rs.getString("MEMBER_NO"));
                        lRejectedPerson.setActivityID(rs.getInt("ACTV_ID"));
                        lRejectedPerson.setActivityName(rs.getString("ACTV_NM"));
                        lRejectedPerson.setSourceActivityID(rs.getString("SRCE_ACTV_ID"));
                        lRejectedPerson.setContributionAmount(rs.getInt("CONTRIB_AMT"));
                        lRejectedPerson.setExternalEmployerPersonId(rs.getString("EXT_PRSN_ID"));
                        lRejectedPerson.setActivityDate(rs.getDate("ACTV_DT"));

                        results.add(lRejectedPerson);
                    }
                });

        RejectedPerson dto = null;
        if (results.size() > 0) {
            dto = (RejectedPerson) results.get(0);
            if (dto.getPersonDemographicsID() == 0) {
                dto.setPersonDemographicsID(null);
            }
        }

        return dto;
    }

    /**
     *
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Override
    public void updateEmployerRecycle(RejectedPerson pRejectedPerson, String pUserID)
            throws BPMException, DataAccessException
    {
        JdbcTemplate template = getJdbcTemplate();

        Object params[] = new Object[]
                {
                        pRejectedPerson.getFirstName(),
                        pRejectedPerson.getMiddleName(),
                        pRejectedPerson.getLastName(),
                        pRejectedPerson.getDateOfBirth(),
                        pRejectedPerson.getGender(),
                        pRejectedPerson.getRecycleStatusCode(),
                        pRejectedPerson.getReasonDesc(),
                        pRejectedPerson.getApproverUserID(),
                        pRejectedPerson.getPersonDemographicsID(),
                        pRejectedPerson.getActivityID(),
                        pRejectedPerson.getActivityDate(),
                        pUserID,
                        pRejectedPerson.getEmployerRecycleID()
                };

        int types[] = new int[] {
                Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.DATE, Types.VARCHAR,
                Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.INTEGER,
                Types.INTEGER,  Types.DATE, Types.VARCHAR, Types.INTEGER };

        template.update(updateEmployerRecycle, params, types);

        return;
    }

}
