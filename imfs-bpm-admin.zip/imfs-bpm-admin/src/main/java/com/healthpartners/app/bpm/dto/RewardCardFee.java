package com.healthpartners.app.bpm.dto;


public class RewardCardFee
{	
	
	private Integer rewardCardFeeID;
	private String vendorName;
	private Integer vendorCodeID;
	private Double cardFeeAmount;
	private String cardFeeName;
	private String cardFeeDescription;
	private java.sql.Date effectiveDate;
	private java.sql.Date endDate;
	
	private Integer used;
	
	public Integer getRewardCardFeeID() {
		return rewardCardFeeID;
	}
	public void setRewardCardFeeID(Integer rewardCardFeeID) {
		this.rewardCardFeeID = rewardCardFeeID;
	}
	
	
	public String getVendorName() {
		return vendorName;
	}
	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}
	
	
	public Double getCardFeeAmount() {
		return cardFeeAmount;
	}
	public void setCardFeeAmount(Double cardFeeAmount) {
		this.cardFeeAmount = cardFeeAmount;
	}
	public String getCardFeeName() {
		return cardFeeName;
	}
	public void setCardFeeName(String cardFeeName) {
		this.cardFeeName = cardFeeName;
	}
	public String getCardFeeDescription() {
		return cardFeeDescription;
	}
	public void setCardFeeDescription(String cardFeeDescription) {
		this.cardFeeDescription = cardFeeDescription;
	}
	public java.sql.Date getEffectiveDate() {
		return effectiveDate;
	}
	public void setEffectiveDate(java.sql.Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}
	public java.sql.Date getEndDate() {
		return endDate;
	}
	public void setEndDate(java.sql.Date endDate) {
		this.endDate = endDate;
	}
	public Integer getUsed() {
		return used;
	}
	public void setUsed(Integer used) {
		this.used = used;
	}
	public Integer getVendorCodeID() {
		return vendorCodeID;
	}
	public void setVendorCodeID(Integer vendorCodeID) {
		this.vendorCodeID = vendorCodeID;
	}
	
	
	
}
