package com.healthpartners.app.bpm.service;

import com.healthpartners.app.bpm.dao.GroupOverrideDAO;
import com.healthpartners.app.bpm.dto.GroupOverride;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

@Service
public class GroupSiteExceptionServiceImpl implements GroupSiteExceptionService {
    private final GroupOverrideDAO groupOverrideDAO;

    public GroupSiteExceptionServiceImpl (GroupOverrideDAO groupOverrideDAO) {
        this.groupOverrideDAO = groupOverrideDAO;
    }

    @Override
    public GroupOverride getGroupOverride(int groupOverrideID) {
        return groupOverrideDAO.getGroupOverride(groupOverrideID);
    }

    @Override
    public ArrayList<GroupOverride> getGroupOverrideByGroupID(Integer groupID) {
        return groupOverrideDAO.getGroupOverrideByGroupID(groupID);
    }

    @Override
    public int deleteGroupOverride(Integer groupOverrideID) throws DataAccessException {
        return groupOverrideDAO.deleteGroupOverride(groupOverrideID);
    }

    @Override
    public int updateGroupOverride(GroupOverride groupSiteException) {
        return groupOverrideDAO.updateGroupOverride(groupSiteException);
    }

    @Override
    public ArrayList<GroupOverride> getGroupOverrideByGroupNumber(String groupNumber) {
        return groupOverrideDAO.getGroupOverrideByGroupNumber(groupNumber);
    }
}
