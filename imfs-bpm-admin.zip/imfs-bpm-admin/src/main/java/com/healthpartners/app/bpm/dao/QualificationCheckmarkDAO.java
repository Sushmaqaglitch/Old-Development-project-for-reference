package com.healthpartners.app.bpm.dao;

import com.healthpartners.app.bpm.dto.CheckmarkDetail;
import com.healthpartners.app.bpm.dto.CheckmarkRequirement;
import com.healthpartners.app.bpm.dto.ProgramCheckmark;
import com.healthpartners.app.bpm.dto.QualificationCheckmark;
import com.healthpartners.app.bpm.exception.BPMException;
import org.springframework.dao.DataAccessException;

import java.util.ArrayList;
import java.util.Collection;

public interface QualificationCheckmarkDAO {
    Collection<QualificationCheckmark> getActiveQualificationCheckmarks() throws BPMException, DataAccessException;

    ArrayList<ProgramCheckmark> getProgramCheckmarks(Integer pProgramID) throws BPMException, DataAccessException;

    int updateProgramCheckmark(ProgramCheckmark pProgramCheckmark, String pUserID) throws BPMException, DataAccessException;

    Collection<CheckmarkRequirement> getCheckmarkRequirements(Integer pQualificationCheckmarkID) throws BPMException, DataAccessException;

    Collection<CheckmarkDetail> getCheckmarkDetails(Integer pQualificationCheckmarkID, Integer pRequirementID) throws BPMException, DataAccessException;

    ArrayList<QualificationCheckmark> getAvailableCheckmarks(Integer pProgramID) throws BPMException, DataAccessException;

    int deleteProgramCheckmark(Integer pProgramCheckmarkID) throws BPMException, DataAccessException;

    Collection<QualificationCheckmark> getExpiredQualificationCheckmarks()
            throws BPMException, DataAccessException;

    //Produces warnings during compile time to quickly identify typos or API changes
    int deleteCheckmarkDetails(Integer pQualificationCheckmarkID)
            throws BPMException, DataAccessException;

    int deleteCheckmarkRequirements(Integer pQualificationCheckmarkID) throws BPMException, DataAccessException;

    //Produces warnings during compile time to quickly identify typos or API changes
    int deleteQualificationCheckmark(Integer pPackageID) throws BPMException, DataAccessException;

    int updateQualificationCheckmark(QualificationCheckmark pQualificationCheckmark, String pModifyUserID) throws BPMException, DataAccessException;

    //Produces warnings during compile time to quickly identify typos or API changes
    int insertQualificationCheckmark(QualificationCheckmark pQualificationCheckmark, String pModifyUserID) throws BPMException, DataAccessException;

    //Produces warnings during compile time to quickly identify typos or API changes
    int insertCheckmarkRequirements(ArrayList<CheckmarkRequirement> pCheckmarkRequirements, String pModifyUserID)
            throws BPMException, DataAccessException;

    //Produces warnings during compile time to quickly identify typos or API changes
    int insertCheckmarkDetails(ArrayList<CheckmarkDetail> pCheckmarkDetails, String pModifyUserID)
            throws BPMException, DataAccessException;

    ArrayList<Integer> getProgramsForCheckmark(Integer pQualificationCheckmarkID) throws BPMException, DataAccessException;

    int updateCheckmarkRequirementsDirectly(ArrayList<CheckmarkRequirement> pCheckmarkRequirements, String pModifyUserID) throws BPMException, DataAccessException;

    //Produces warnings during compile time to quickly identify typos or API changes
    CheckmarkRequirement getCheckmarkRequirement(Integer pRequirementID, Integer pQualificationCheckmarkID)
            throws BPMException, DataAccessException;

    int updateCheckmarkDetailsDirectly(ArrayList<CheckmarkDetail> pCheckmarkDetails, String pModifyUserID) throws BPMException, DataAccessException;
}
