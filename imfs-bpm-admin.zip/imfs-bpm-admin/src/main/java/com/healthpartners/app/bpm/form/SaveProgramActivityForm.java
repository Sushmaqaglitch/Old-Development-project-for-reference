package com.healthpartners.app.bpm.form;

/**
 * @author jxbourbour
 *
 */
public class SaveProgramActivityForm extends BaseForm {
    private Integer programID;
    private Integer packageID;
    private Integer activityID;
    private String activityIndex;

    private Integer[] activityDurations;
    private Integer[] activityIDs;

    private String[] activityStartDates;
    private String[] activityEndDates;
    private String[] enrollDeadlineDates;

    private String[] incentiveOverrideCodeIDs;

    private Integer[] exclusionOptionFlags;

    private String recalculate;

    private String userAuthCode;
    private String userPromoCode;

    private Integer groupID;
    private Integer subGroupID;

    private String[] activityNames;
    private String[] activityDescs;
    private String programTypeCodeID;
    private String groupNumber;
    private String groupName;
    private String siteNumber;
    private String siteName;



    public SaveProgramActivityForm() {
        super();
    }


//	public ActionMessages validateSaveProgramActivity(ActionMapping mapping,
//			HttpServletRequest request)
//	{
//		if(activityIDs != null && activityIDs.length > 0)
//		{
//			for(int i = 0; i < activityIDs.length; i++)
//			{
//	            validateNotDate("activityStartDates", activityStartDates[i], "Start Date");
//	            validateNotDate("activityEndDates", activityEndDates[i], "End Date");
//	            if (enrollDeadlineDates[i].length() > 0) {
//	            	validateNotDate("enrollDeadlineDates", enrollDeadlineDates[i], "Enrollment Deadline Date");
//	            }
//
//	            if (enrollDeadlineDates[i].length() > 0) {
//		            validateAfter("enrollmentDeadlineDate", enrollDeadlineDates[i], "Enrollment Deadline Date", activityStartDates[i], "Activity Start Date");
//		    	    validateBeforeOrEqual("enrollmentDeadlineDate", enrollDeadlineDates[i], "Enrollment Deadline Date", activityEndDates[i], "Activity End Date");
//	            }
//			}
//		}
//	    return this.getActionMessages();
//	}
//
//	public ActionMessages validatePackageAndProgramDates(BusinessProgram pBusinessProgram,
//			ArrayList<ProgramPackage> pProgramPackages)
//	{
//		ProgramPackage lProgramPackage = null;
//		String businessProgramEffectiveDate = BPMAdminUtils.formatDateMMddyyyy(pBusinessProgram.getEffectiveDate());
//
//		for(int i = 0; i < pProgramPackages.size(); i++)
//		{
//			lProgramPackage = pProgramPackages.get(i);
//			if(lProgramPackage.getPackageID().intValue() == packageID.intValue())
//			{
//			    validateAfter("businessProgramEffDate", businessProgramEffectiveDate, "Program Effective Date", lProgramPackage.getEffectiveDateString(), "Package Effective Date");
//			    validateBeforeOrEqual("businessProgramEffDate", businessProgramEffectiveDate, "Program Effective Date", lProgramPackage.getEndDateString(), "Package End Date");
//				break;
//			}
//		}
//
//	    return this.getActionMessages();
//	}
    public Integer[] getActivityDurations() {
        return activityDurations;
    }

    public void setActivityDurations(Integer[] activityDurations) {
        this.activityDurations = activityDurations;
    }

    public final Integer[] getActivityIDs() {
        return activityIDs;
    }

    public final void setActivityIDs(Integer[] activityIDs) {
        this.activityIDs = activityIDs;
    }

    public String getActivityIndex() {
        return activityIndex;
    }

    public void setActivityIndex(String activityIndex) {
        this.activityIndex = activityIndex;
    }

    public final Integer getProgramID() {
        return programID;
    }

    public final void setProgramID(Integer programID) {
        this.programID = programID;
    }

    public final String[] getActivityEndDates() {
        return activityEndDates;
    }

    public final void setActivityEndDates(String[] activityEndDates) {
        this.activityEndDates = activityEndDates;
    }

    public final String[] getActivityStartDates() {
        return activityStartDates;
    }

    public final void setActivityStartDates(String[] activityStartDates) {
        this.activityStartDates = activityStartDates;
    }

    public String[] getEnrollDeadlineDates() {
        return enrollDeadlineDates;
    }

    public void setEnrollDeadlineDates(String[] enrollDeadlineDates) {
        this.enrollDeadlineDates = enrollDeadlineDates;
    }

    public String[] getIncentiveOverrideCodeIDs() {
        return incentiveOverrideCodeIDs;
    }

    public void setIncentiveOverrideCodeIDs(String[] incentiveOverrideCodeIDs) {
        this.incentiveOverrideCodeIDs = incentiveOverrideCodeIDs;
    }


    public Integer[] getExclusionOptionFlags() {
        return exclusionOptionFlags;
    }

    public void setExclusionOptionFlags(Integer[] exclusionOptionFlags) {
        this.exclusionOptionFlags = exclusionOptionFlags;
    }

    public final String getRecalculate() {
        return recalculate;
    }

    public final void setRecalculate(String recalculate) {
        this.recalculate = recalculate;
    }

    public String getUserAuthCode() {
        return userAuthCode;
    }

    public void setUserAuthCode(String userAuthCode) {
        this.userAuthCode = userAuthCode;
    }

    public String getUserPromoCode() {
        return userPromoCode;
    }

    public void setUserPromoCode(String userPromoCode) {
        this.userPromoCode = userPromoCode;
    }

    public Integer getActivityID() {
        return activityID;
    }

    public void setActivityID(Integer activityID) {
        this.activityID = activityID;
    }

    public Integer getPackageID() {
        return packageID;
    }

    public void setPackageID(Integer packageID) {
        this.packageID = packageID;
    }

    public Integer getGroupID() {
        return groupID;
    }

    public void setGroupID(Integer groupID) {
        this.groupID = groupID;
    }

    public Integer getSubGroupID() {
        return subGroupID;
    }

    public void setSubGroupID(Integer subGroupID) {
        this.subGroupID = subGroupID;
    }


    public String[] getActivityNames() {

        return activityNames;
    }


    public void setActivityNames(String[] activityNames) {

        this.activityNames = activityNames;
    }


    public String[] getActivityDescs() {
        return activityDescs;
    }


    public void setActivityDescs(String[] activityDescs) {
        this.activityDescs = activityDescs;
    }

    public String getProgramTypeCodeID() {
        return programTypeCodeID;
    }

    public void setProgramTypeCodeID(String programTypeCodeID) {
        this.programTypeCodeID = programTypeCodeID;
    }

    public String getGroupNumber() {
        return groupNumber;
    }

    public void setGroupNumber(String groupNumber) {
        this.groupNumber = groupNumber;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public String getSiteNumber() {
        return siteNumber;
    }

    public void setSiteNumber(String siteNumber) {
        this.siteNumber = siteNumber;
    }

    public String getSiteName() {
        return siteName;
    }

    public void setSiteName(String siteName) {
        this.siteName = siteName;
    }
}
