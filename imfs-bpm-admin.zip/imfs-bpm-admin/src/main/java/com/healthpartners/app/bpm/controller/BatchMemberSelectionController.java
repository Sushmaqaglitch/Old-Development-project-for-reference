package com.healthpartners.app.bpm.controller;

import com.healthpartners.app.bpm.common.BPMAdminConstants;
import com.healthpartners.app.bpm.dto.LookUpValueCode;
import com.healthpartners.app.bpm.dto.MemberProcessingStatusLog;
import com.healthpartners.app.bpm.exception.BPMException;
import com.healthpartners.app.bpm.form.BatchMemberSelectionForm;
import com.healthpartners.app.bpm.form.SaveProgramActivityForm;
import com.healthpartners.app.bpm.iface.MemberService;
import com.healthpartners.service.bpm.rules.StatusCalculationCommand;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.view.RedirectView;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;

@Controller
public class BatchMemberSelectionController extends BaseController implements Validator {

    private static final String BATCH_MEMBERSHIP_UPDATE = "Membership Update";
    private static final String BATCH_MEMBERSHIP_UPDATE_ONLY = "Membership Update Only";
    private static final String BATCH_MENBER_RECALCULATION = "Member status Re-Calculation";
    private static final String REMOVE_MEMBERS = "Remove Members";
    private static final Integer batchSize = 100;

    private final MemberService memberService;

    private final Log logger = LogFactory.getLog(getClass());

    public BatchMemberSelectionController(MemberService memberService) {
        this.memberService = memberService;
    }

    @PostMapping("/batchMemberSelection")
    public String submitOperation(@ModelAttribute("batchMemberSelectionForm") BatchMemberSelectionForm form, ModelMap modelMap, BindingResult result, RedirectAttributes ra, HttpServletRequest request) throws Exception {
        boolean success = true;
        try {
            String operationType = form.getOperationType();
            if (StringUtils.isNotEmpty(operationType)) {
                String sanitizedOperationType = operationType.replaceAll("[\\r\\n]", "");
                if (sanitizedOperationType.matches("\\w*")) {
                    logger.info("BatchJobsAction - operationType=" + sanitizedOperationType);
                }
                if (REMOVE_MEMBERS.endsWith(operationType)) {
                    return removeSelectedMembers(modelMap, form, ra, request);
                } else {
                    return runBatchJob(modelMap, form, ra, request);
                }
            }
        } catch (Exception e) {
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
            // Add error stack trace on the request, to be hidden in html.
            createErrorMessageOnModel(modelMap, getStackTrace(e));
        }

        return "batchMemberSelection";
    }

    @PostMapping(value = "/batchMemberSelection", params = "cancel")
    public RedirectView submitCancel(@ModelAttribute("batchMemberSelectionForm") BatchMemberSelectionForm batchMemberSelectionForm, RedirectAttributes ra) {
        return new RedirectView("batchJobs");
    }

    private String runBatchJob(ModelMap modelMap, BatchMemberSelectionForm form, RedirectAttributes ra, HttpServletRequest request) throws IOException, ServletException {
        boolean batchTypeOK;
        try {
            String operationType = form.getOperationType();
            if (StringUtils.isNotEmpty(operationType)) {
                StatusCalculationCommand calculationCommand = new StatusCalculationCommand();
                if (BATCH_MEMBERSHIP_UPDATE_ONLY.equals(operationType)) {
                    calculationCommand.setEtlMembershipUpdateOnlyCommand();
                    calculationCommand.setProcessIDForEtlMembershipUpdateCommand(BPMAdminConstants.BPM_ADMIN_MEMBERSHIP_UPDATE_ONLY_PRCS_ID);
                    batchTypeOK = true;

                } else if (BATCH_MEMBERSHIP_UPDATE.equals(operationType)) {
                    calculationCommand.setEtlMembershipUpdateCommand();
                    calculationCommand.setProcessIDForEtlMembershipUpdateCommand(BPMAdminConstants.BPM_ADMIN_MEMBERSHIP_UPDATE_PRCS_ID);
                    batchTypeOK = true;

                } else if (BATCH_MENBER_RECALCULATION.equals(operationType)) {
                    calculationCommand.setMembersReCalculationCommand();
                    calculationCommand.setProcessIDForMembersReCalculationCommand(BPMAdminConstants.BPM_ADMIN_MEMBERS_RECALCULATION_PRCS_ID);
                    batchTypeOK = true;

                } else {
                    batchTypeOK = false;
                }

                if (batchTypeOK) {
                    calculationCommand.setBatchSizeCommand(batchSize);
                    String userId = getUserSessionSupport().getAuthenticatedUsername();
                    calculationCommand.setUserID(userId);

                    //BPM-926 - hit openshift rest endpoint and pass in command to kick off service.
                    if (calculationCommand.isEtlMembershipUpdateCommand()) {
                        LookUpValueCode luvRestEndpoint = memberService.getLUVCodeByGroupNValue(BPMAdminConstants.OS_REST_URL_COMMAND, BPMAdminConstants.OS_URL_KS_MEMBERSHIP_UPDATE);
                        String urlRestEndpointCommand = luvRestEndpoint.getLuvDesc();
                        memberService.kickStartBatchProcessOnOpenshift(urlRestEndpointCommand);
                    }
                    if (calculationCommand.isMembersReCalculationCommand()) {
                        LookUpValueCode luvRestEndpoint = memberService.getLUVCodeByGroupNValue(BPMAdminConstants.OS_REST_URL_COMMAND, BPMAdminConstants.OS_URL_KS_MEMBERSTATUS_RECALC);
                        String urlRestEndpointCommand = luvRestEndpoint.getLuvDesc();
                        memberService.kickStartBatchProcessOnOpenshift(urlRestEndpointCommand);
                    }
                    if (calculationCommand.isMbrShipPremiumBillingFeedCommand()) {
                        LookUpValueCode luvRestEndpoint = memberService.getLUVCodeByGroupNValue(BPMAdminConstants.OS_REST_URL_COMMAND, BPMAdminConstants.OS_URL_KS_MEMBERSHIP_PREM_BILLING);
                        String urlRestEndpointCommand = luvRestEndpoint.getLuvDesc();
                        memberService.kickStartBatchProcessOnOpenshift(urlRestEndpointCommand);
                    }

                    // send message with batch command
//					memberService.sendJMSCommand(calculationCommand);
                    createActionMessagesForRedirect(ra, "messages.batchjob.started", new Object[]{operationType});

                    // log the batch job for audit
                    SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss z");
                    String sanitizedOperationType = operationType.replaceAll("[\\r\\n]", "");
                    if (sanitizedOperationType.matches("\\w*")) {
                        logger.info("@@@Batch job named '" + sanitizedOperationType
                                + "' has been started by user '" + userId
                                + "' at time '" + dateFormat.format(new Date())
                                + "' through BPM-ADMIN application @@@");
                    }
                } else {
                    createActionMessagesForRedirect(ra, "messages.info", new Object[]{"Unknown batch job named '" + operationType + "'."});
                }
            }

            return "redirect:batchJobs";

        } catch (Exception e) {
            logger.error("An unexpected error has occured: " + e.getMessage(), e);
            createErrorMessageOnModel(modelMap, getStackTrace(e));
            return "batchMemberSelection";
        }
    }

    private String removeSelectedMembers(ModelMap modelMap, BatchMemberSelectionForm form, RedirectAttributes ra, HttpServletRequest request) throws IOException, ServletException {
        try {
            String[] strRemovalIDs = form.getSelectedProcessLogIDs();
            if (strRemovalIDs != null && strRemovalIDs.length > 0) {
                Collection<Long> lngRemovalIDs = convertStringsToLongs(strRemovalIDs);
                memberService.deleteProcessingStatusLogRecords(lngRemovalIDs);
                createActionMessagesOnModel(modelMap, "messages.info", new Object[]{"Selected member(s) have been removed sucessfully."});
            } else {
                createActionMessagesOnModel(modelMap, "messages.info", new Object[]{"No member has been selected for removal."});
            }

            setMemberSelectionPageRequestAttributes(modelMap, form);

        } catch (Exception e) {
            logger.error("An unexpected error has occured: " + e.getMessage(), e);
            request.setAttribute("errorMsg", getStackTrace(e));
        }

        return "batchMemberSelection";
    }

    private void setMemberSelectionPageRequestAttributes(ModelMap modelMap, BatchMemberSelectionForm thisForm) throws BPMException {
        // Setting processID to zero will retrieve all pending rows in the
        // processing_status_log table.
        Integer lProcessID = thisForm.getStatusLogProcessID();

        try {
            Collection<MemberProcessingStatusLog> pendingProcessMembers = memberService.getPendingPersonsFromProcessingStatusLog(lProcessID);
            modelMap.put("pendingProcessMembers", pendingProcessMembers);
            modelMap.put("statusLogProcessID", lProcessID);

        } catch (Exception e) {
            throw new BPMException(e);
        }
    }

    @Override
    public boolean supports(Class<?> clazz) {
        return BatchMemberSelectionForm.class.isAssignableFrom(clazz);
    }

    @Override
    public void validate(Object target, Errors errors) {
        BatchMemberSelectionForm form = (BatchMemberSelectionForm) target;
    }
}
