package com.healthpartners.app.bpm.dao;

import com.healthpartners.app.bpm.dto.AdditionalInformation;
import com.healthpartners.app.bpm.exception.BPMException;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.jdbc.support.incrementer.DataFieldMaxValueIncrementer;
import org.springframework.jdbc.support.incrementer.OracleSequenceMaxValueIncrementer;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import jakarta.annotation.PostConstruct;
import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Collection;

@Repository
@Transactional(timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
public class AdditionalInfoDAOJdbc extends JdbcDaoSupport implements AdditionalInfoDAO {

    private String deleteAdditionalInfos = "DELETE FROM BIZ_PGM_ADDITIONAL_INFO WHERE BIZ_PGM_ID = ?";

    private static final String selectAdditionalInformationByIDs =
            "SELECT\n" +
                    "  ADDL_INFO_ID,\n" +
                    "  BIZ_PGM_ID,\n" +
                    "  ADDL_INFO_NM,\n" +
                    "  ADDL_INFO_TXT,\n" +
                    "  SORT_ORDR,\n" +
                    "  ADDL_INFO_TP_CD_ID,\n" +
                    "  lu_val ADDL_INFO_TP_CD_ID \n" +
                    "FROM\n" +
                    "  BIZ_PGM_ADDITIONAL_INFO \n" +
                    "  , luv  \n" +
                    "WHERE\n" +
                    "   BIZ_PGM_ID = ? " +
                    "   AND  ADDL_INFO_ID = ?\n" +
                    "   AND ADDL_INFO_TP_CD_ID = lu_id ";

    private static final String updateAdditionalInformation =
            "UPDATE BIZ_PGM_ADDITIONAL_INFO SET \n" +
                    "  ADDL_INFO_NM = ?,\n" +
                    "  ADDL_INFO_TXT = ?,\n" +
                    "  SORT_ORDR = ?,\n" +
                    "  ADDL_INFO_TP_CD_ID = ?,\n" +
                    "  MODIFY_TS = SYSDATE, \n" +
                    "  MODIFY_USR = ? \n" +
                    "  WHERE BIZ_PGM_ID = ? AND ADDL_INFO_ID = ?";

    private static final String insertAdditionalInformation =
            "INSERT INTO BIZ_PGM_ADDITIONAL_INFO (\n" +
                    "  ADDL_INFO_ID,\n" +
                    "  BIZ_PGM_ID,\n" +
                    "  ADDL_INFO_NM,\n" +
                    "  ADDL_INFO_TXT,\n" +
                    "  SORT_ORDR,\n" +
                    "  ADDL_INFO_TP_CD_ID, \n" +
                    "  INSERT_TS, \n" +
                    "  INSERT_USR) \n" +
                    "  VALUES (?, ?, ?, ?, ?, (SELECT lu_id FROM luv WHERE lu_val=?), SYSDATE, ?)";

    private static final String selectAdditionalInformation =
            "SELECT\n" +
                    "  ADDL_INFO_ID,\n" +
                    "  BIZ_PGM_ID,\n" +
                    "  ADDL_INFO_NM,\n" +
                    "  ADDL_INFO_TXT,\n" +
                    "  SORT_ORDR,\n" +
                    "  ADDL_INFO_TP_CD_ID,\n" +
                    "  lu_val ADDL_INFO_TP_CD \n" +
                    "FROM\n" +
                    "  BIZ_PGM_ADDITIONAL_INFO \n" +
                    "  , luv\n" +
                    "WHERE\n" +
                    "    BIZ_PGM_ID = ? \n" +
                    "AND ADDL_INFO_TP_CD_ID = lu_id    \n" +
                    "ORDER BY SORT_ORDR, addl_info_id";

    private final DataSource dataSource;

    private DataFieldMaxValueIncrementer additionalInfoIdIncrementer;
    private static final String ADDL_INFO_ID_SEQ = "ADDL_INFO_ID_SEQ";

    public AdditionalInfoDAOJdbc (DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @PostConstruct
    private void initialize() {
        setDataSource(dataSource);
        additionalInfoIdIncrementer = new OracleSequenceMaxValueIncrementer(dataSource, ADDL_INFO_ID_SEQ);
    }

    /**
     * Delete all the Additional Information records for the given Program ID.
     *
     * @param pBusinessProgramID
     * @return
     * @throws DataAccessException
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Override
    public int deleteAdditionalInfos(Integer pBusinessProgramID)
            throws DataAccessException {
        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{pBusinessProgramID};
        int types[] = new int[]{Types.INTEGER};

        int rowDeleted = template.update(deleteAdditionalInfos, params, types);

        return rowDeleted;
    }

    @Override
    public void updateAdditionalInformation(AdditionalInformation pAdditionalInformation, String lUserID) {
        ArrayList<AdditionalInformation> lAdditionalInfos = (ArrayList<AdditionalInformation>) getAdditionalInformation(pAdditionalInformation.getAdditionalProgramID(), pAdditionalInformation.getAdditionalInfoID());

        if (lAdditionalInfos.size() <= 0) {
            this.insertAdditionalInformation(pAdditionalInformation, lUserID);
            return;
        }

        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{
                pAdditionalInformation.getAdditionalInfoName(),
                pAdditionalInformation.getAdditionalInfoText(),
                pAdditionalInformation.getSortOrder(),
                pAdditionalInformation.getAdditionalInfoTypeID(),
                lUserID,
                pAdditionalInformation.getAdditionalProgramID(),
                pAdditionalInformation.getAdditionalInfoID()
        };

        int types[] = new int[]{
                Types.VARCHAR, Types.VARCHAR,
                Types.INTEGER, Types.INTEGER, Types.VARCHAR,
                Types.INTEGER, Types.INTEGER};


        template.update(updateAdditionalInformation, params, types);
        return;
    }

    @Override
    public Collection<AdditionalInformation> getAdditionalInformation(Integer programID, Integer additionalInfoID) {
        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{programID, additionalInfoID};
        int types[] = new int[]{Types.INTEGER, Types.INTEGER};
        final ArrayList<AdditionalInformation> lAdditionalInfos = new ArrayList<AdditionalInformation>();

        template.query(selectAdditionalInformationByIDs, params, types,
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        AdditionalInformation lAdditionalInfo = new AdditionalInformation();

                        lAdditionalInfo.setAdditionalInfoID(rs.getInt("addl_info_id"));
                        lAdditionalInfo.setAdditionalProgramID(rs.getInt("biz_pgm_id"));
                        lAdditionalInfo.setAdditionalInfoName(rs.getString("addl_info_nm"));
                        lAdditionalInfo.setAdditionalInfoText(rs.getString("addl_info_txt"));
                        lAdditionalInfo.setSortOrder(rs.getInt("sort_ordr"));
                        lAdditionalInfo.setAdditionalInfoTypeID(rs.getInt("ADDL_INFO_TP_CD_ID"));
                        lAdditionalInfo.setAdditionalInfoTypeCode(rs.getString("ADDL_INFO_TP_CD"));

                        lAdditionalInfos.add(lAdditionalInfo);
                    }
                });

        return lAdditionalInfos;
    }

    @Override
    public void insertAdditionalInformation(AdditionalInformation pAdditionalInformation, String lUserID) {
        // Retrieve the next sequence number for the audit log entry.
        Integer addInfoId = additionalInfoIdIncrementer.nextIntValue();

        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[] {
                addInfoId,
                pAdditionalInformation.getAdditionalProgramID(),
                pAdditionalInformation.getAdditionalInfoName(),
                pAdditionalInformation.getAdditionalInfoText(),
                pAdditionalInformation.getSortOrder(),
                pAdditionalInformation.getAdditionalInfoTypeCode(),
                lUserID };

        int types[] = new int[] { Types.INTEGER,Types.INTEGER,
                Types.VARCHAR, Types.VARCHAR,
                Types.INTEGER, Types.VARCHAR, Types.VARCHAR};

        template.update(insertAdditionalInformation, params, types);
        return;
    }

    @Override
    public Collection<AdditionalInformation> getAdditionalInformation(Integer programID) {
        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{programID};
        int types[] = new int[]{Types.INTEGER};
        final ArrayList<AdditionalInformation> lAdditionalInfos = new ArrayList<AdditionalInformation>();

        template.query(selectAdditionalInformation, params, types,
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        AdditionalInformation lAdditionalInfo = new AdditionalInformation();

                        lAdditionalInfo.setAdditionalInfoID(rs.getInt("addl_info_id"));
                        lAdditionalInfo.setAdditionalProgramID(rs.getInt("biz_pgm_id"));
                        lAdditionalInfo.setAdditionalInfoName(rs.getString("addl_info_nm"));
                        lAdditionalInfo.setAdditionalInfoText(rs.getString("addl_info_txt"));
                        lAdditionalInfo.setSortOrder(rs.getInt("sort_ordr"));
                        lAdditionalInfo.setAdditionalInfoTypeID(rs.getInt("ADDL_INFO_TP_CD_ID"));
                        lAdditionalInfo.setAdditionalInfoTypeCode(rs.getString("ADDL_INFO_TP_CD"));

                        lAdditionalInfos.add(lAdditionalInfo);
                    }
                });

        return lAdditionalInfos;
    }
}
