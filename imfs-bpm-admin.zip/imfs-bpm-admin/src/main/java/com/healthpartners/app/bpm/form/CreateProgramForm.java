package com.healthpartners.app.bpm.form;


import com.healthpartners.app.bpm.dto.EmployerGroup;
import com.healthpartners.app.bpm.dto.ProgramType;

import java.util.ArrayList;
import java.util.Collection;

public class CreateProgramForm extends BaseForm {
    private String businessProgramType;
    private String businessProgramName;

    private String businessProgramTypeName;

    private Integer groupID;
    private Integer subgroupID;
    private String groupNo;
    private String groupName;
    private String siteIDSiteName;

    private String groupStartDate;

    private Collection<EmployerGroup> employerSubGroups = new ArrayList<>();
    private Collection<ProgramType> programTypes = new ArrayList<>();

    public Integer getGroupID() {
        return groupID;
    }

    public void setGroupID(Integer groupID) {
        this.groupID = groupID;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public String getGroupNo() {
        return groupNo;
    }

    public void setGroupNo(String groupNo) {
        this.groupNo = groupNo;
    }

    public Integer getSubgroupID() {
        return subgroupID;
    }

    public void setSubgroupID(Integer subgroupID) {
        this.subgroupID = subgroupID;
    }

    public String getBusinessProgramName() {
        return businessProgramName;
    }

    public void setBusinessProgramName(String businessProgramName) {
        this.businessProgramName = businessProgramName;
    }

    public String getBusinessProgramType() {
        return businessProgramType;
    }

    public void setBusinessProgramType(String businessProgramType) {
        this.businessProgramType = businessProgramType;
    }

    public String getSiteIDSiteName() {
        return siteIDSiteName;
    }

    public void setSiteIDSiteName(String siteIDSiteName) {

        this.siteIDSiteName = siteIDSiteName;
    }

    public String getBusinessProgramTypeName() {
        return businessProgramTypeName;
    }

    public void setBusinessProgramTypeName(String businessProgramTypeName) {
        this.businessProgramTypeName = businessProgramTypeName;
    }

    public String getGroupStartDate() {
        return groupStartDate;
    }

    public void setGroupStartDate(String groupStartDate) {
        this.groupStartDate = groupStartDate;
    }

    public Collection<EmployerGroup> getEmployerSubGroups() {
        return employerSubGroups;
    }

    public void setEmployerSubGroups(Collection<EmployerGroup> employerSubGroups) {
        this.employerSubGroups = employerSubGroups;
    }

    public Collection<ProgramType> getProgramTypes() {
        return programTypes;
    }

    public void setProgramTypes(Collection<ProgramType> programTypes) {
        this.programTypes = programTypes;
    }
}
