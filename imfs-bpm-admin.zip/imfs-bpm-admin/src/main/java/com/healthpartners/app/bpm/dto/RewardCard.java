package com.healthpartners.app.bpm.dto;

import java.io.Serializable;
import java.sql.Date;

public class RewardCard implements Serializable {
    static final long serialVersionUID = 0L;

    private Integer rewardCardID;
    private String quoteNo;
    private String quoteDesc;
    private Date effectiveDate;
    private Date endDate;

    private Integer used;

    public Integer getRewardCardID() {
        return rewardCardID;
    }

    public void setRewardCardID(Integer rewardCardID) {
        this.rewardCardID = rewardCardID;
    }

    public String getQuoteNo() {
        return quoteNo;
    }

    public void setQuoteNo(String quoteNo) {
        this.quoteNo = quoteNo;
    }

    public String getQuoteDesc() {
        return quoteDesc;
    }

    public void setQuoteDesc(String quoteDesc) {
        this.quoteDesc = quoteDesc;
    }

    public Date getEffectiveDate() {
        return effectiveDate;
    }

    public void setEffectiveDate(Date effectiveDate) {
        this.effectiveDate = effectiveDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public Integer getUsed() {
        return used;
    }

    public void setUsed(Integer used) {
        this.used = used;
    }


}
