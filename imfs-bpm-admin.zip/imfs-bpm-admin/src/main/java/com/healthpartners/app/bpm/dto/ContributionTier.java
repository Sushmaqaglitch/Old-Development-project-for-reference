package com.healthpartners.app.bpm.dto;

import java.io.Serializable;
import java.util.ArrayList;

public class ContributionTier implements Serializable {
    static final long serialVersionUID = 0L;

    private Integer tierTypeID;
    private Integer tierTypeName;
    private String tierTypeDesc;
    private String tierTypeInfo;

    private Integer benefitContractTypeID;

    private String benefitContractType;

    private Integer tierValueID;


    private boolean used;

    private ArrayList<ContributionTierBenefitContractType> assignedContributionTierBenefitContractTypes;

    private ArrayList<ContributionTierBenefitContractType> availableContributionTierBenefitContractTypes;


    public ContributionTier() {
        super();
    }


    public Integer getTierTypeID() {
        return tierTypeID;
    }


    public void setTierTypeID(Integer tierTypeID) {
        this.tierTypeID = tierTypeID;
    }


    public Integer getTierTypeName() {
        return tierTypeName;
    }


    public void setTierTypeName(Integer tierTypeName) {
        this.tierTypeName = tierTypeName;
    }


    public String getTierTypeDesc() {
        return tierTypeDesc;
    }


    public void setTierTypeDesc(String tierTypeDesc) {
        this.tierTypeDesc = tierTypeDesc;
    }


    public String getTierTypeInfo() {
        return tierTypeInfo;
    }


    public void setTierTypeInfo(String tierTypeInfo) {
        this.tierTypeInfo = tierTypeInfo;
    }


    public Integer getBenefitContractTypeID() {
        return benefitContractTypeID;
    }


    public void setBenefitContractTypeID(Integer benefitContractTypeID) {
        this.benefitContractTypeID = benefitContractTypeID;
    }


    public String getBenefitContractType() {
        return benefitContractType;
    }


    public void setBenefitContractType(String benefitContractType) {
        this.benefitContractType = benefitContractType;
    }


    public Integer getTierValueID() {
        return tierValueID;
    }


    public void setTierValueID(Integer tierValueID) {
        this.tierValueID = tierValueID;
    }


    public boolean isUsed() {
        return used;
    }


    public void setUsed(boolean used) {
        this.used = used;
    }


    public ArrayList<ContributionTierBenefitContractType> getAssignedContributionTierBenefitContractTypes() {
        return assignedContributionTierBenefitContractTypes;
    }


    public void setAssignedContributionTierBenefitContractTypes(
            ArrayList<ContributionTierBenefitContractType> assignedContributionTierBenefitContractTypes) {
        this.assignedContributionTierBenefitContractTypes = assignedContributionTierBenefitContractTypes;
    }


    public ArrayList<ContributionTierBenefitContractType> getAvailableContributionTierBenefitContractTypes() {
        return availableContributionTierBenefitContractTypes;
    }


    public void setAvailableContributionTierBenefitContractTypes(
            ArrayList<ContributionTierBenefitContractType> availableContributionTierBenefitContractTypes) {
        this.availableContributionTierBenefitContractTypes = availableContributionTierBenefitContractTypes;
    }


}
