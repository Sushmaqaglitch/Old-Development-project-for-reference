package com.healthpartners.app.bpm.controller;

import com.healthpartners.app.bpm.common.BPMAdminConstants;
import com.healthpartners.app.bpm.common.BPMAdminUtils;
import com.healthpartners.app.bpm.common.BPMPagination;
import com.healthpartners.app.bpm.dto.LookUpValueCode;
import com.healthpartners.app.bpm.dto.PersonContractRecycle;
import com.healthpartners.app.bpm.dto.RecycleSearchCriteria;
import com.healthpartners.app.bpm.exception.BPMException;
import com.healthpartners.app.bpm.form.PersonContractRecycleSearchForm;
import com.healthpartners.app.bpm.iface.MemberService;
import com.healthpartners.app.bpm.pageable.PageablePersonContractRecycle;
import com.healthpartners.app.bpm.session.UserSession;
import com.healthpartners.service.bpm.common.BPMConstants;
import jakarta.servlet.http.HttpServletRequest;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

@Controller
public class PersonContractRecycleSearchController extends BaseController implements Validator {

    private final MemberService memberService;

    public PersonContractRecycleSearchController(MemberService memberService) {
        this.memberService = memberService;
    }

    @GetMapping("/showPersonContractRecycleSearch")
    public String loadSearch(ModelMap modelMap) throws BPMException {
        PersonContractRecycleSearchForm form = new PersonContractRecycleSearchForm();
        modelMap.put("personContractRecycleSearchForm", form);

        try {
            loadInitial(modelMap);
        } catch (Exception e) {
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
            modelMap.put("errorMsg", getStackTrace(e));
        }
        return "personContractRecycleSearch";
    }

    @PostMapping(value = "/personContractRecycleSearch", params = "next")
    public String submitNext(@ModelAttribute("personContractRecycleSearchForm") PersonContractRecycleSearchForm form, ModelMap modelMap, HttpServletRequest request) throws Exception {
        return performPaginationAction(form, modelMap);
    }

    @PostMapping(value = "/personContractRecycleSearch", params = "back")
    public String submitBack(@ModelAttribute("personContractRecycleSearchForm") PersonContractRecycleSearchForm form, ModelMap modelMap, HttpServletRequest request) throws Exception {
        return performPaginationAction(form, modelMap);
    }

    @PostMapping("/personContractRecycleSearch")
    public String submit(@ModelAttribute("personContractRecycleSearchForm") PersonContractRecycleSearchForm form, ModelMap modelMap, BindingResult result) throws Exception {
        try {
            populateSelects(modelMap);
            if (ACTION_SEARCH.equals(form.getActionType())) {
                validate(form, result);
                if (!result.hasErrors()) {
                    search(form, modelMap);
                }

            } else if (ACTION_UPDATE.equals(form.getActionType())) {
                validateForRecycleUpdate(form, modelMap, result);
                if (!result.hasErrors()) {
                    update(form, modelMap);
                }
                form.setActionType(ACTION_SEARCH);
                search(form, modelMap);
            }
        } catch (Exception e) {
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
            // Add error stack trace on the request, to be hidden in html.
            modelMap.put("errorMsg", getStackTrace(e));
        }

        return "personContractRecycleSearch";
    }

    @GetMapping("/personContractRecycleSearch")
    public String loadSearchFromBackButtonAction(@ModelAttribute("personContractRecycleSearchForm") PersonContractRecycleSearchForm form, ModelMap modelMap, BindingResult result) throws Exception {
        try {
            getUserSession().reset();
            RecycleSearchCriteria lRecycleSearchCriteria = getUserSession().getRecycleSearchCriteria();
            form.setActionType(ACTION_SEARCH);
            form.setGroupNo(lRecycleSearchCriteria.getGroupNo());
            form.setMemberId(lRecycleSearchCriteria.getMemberID());
            form.setContractNo(lRecycleSearchCriteria.getContractNo());
            form.setProgramName(lRecycleSearchCriteria.getProgramName());
            form.setRecycleStatusId(lRecycleSearchCriteria.getRecycleStatusID());
            form.setRecycleStatusDate(lRecycleSearchCriteria.getRecycleStatusDateString());

            populateSelects(modelMap);

            PersonContractRecycle personContractRecycle = getUserSession().getPersonContractRecycle();
            if (personContractRecycle != null) {
                form.setApprover(personContractRecycle.getApproverUserId());
                form.setRecycleStatusUpdateId(personContractRecycle.getRecycleStatusId() != null ? String.valueOf(personContractRecycle.getRecycleStatusId()) : null);
                form.setReason(personContractRecycle.getReasonDesc());
            }

            search(form, modelMap);

        } catch (Exception e) {
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
            // Add error stack trace on the request, to be hidden in html.
            modelMap.put("errorMsg", getStackTrace(e));
        }

        return "personContractRecycleSearch";
    }

    private void loadInitial(ModelMap modelMap) throws BPMException {
        getUserSession().reset();

        populateSelects(modelMap);

        BPMPagination pagination = new BPMPagination();
        pagination.setBackPageFlag(BPMAdminConstants.BPM_ADMIN_PAGINATION_END);
        pagination.setNextPageFlag(BPMAdminConstants.BPM_ADMIN_PAGINATION_END);
        modelMap.put("backPageFlag", pagination.getBackPageFlag());
        modelMap.put("nextPageFlag", pagination.getNextPageFlag());
    }

    private void populateSelects(ModelMap modelMap) throws BPMException {
        if (CollectionUtils.isEmpty(getUserSession().getRecycleStatusCodes())) {
            ArrayList<LookUpValueCode> lLuvRecycleStatusCodes = (ArrayList<LookUpValueCode>) memberService.getLUVCodesByGroup(BPMConstants.BPM_TYPE_RECYCLE_STATUS);
            getUserSession().setRecycleStatusCodes(lLuvRecycleStatusCodes);
        }
        modelMap.put("recycleStatusCodes", getUserSession().getRecycleStatusCodes());
    }

    private void search(PersonContractRecycleSearchForm form, ModelMap modelMap) throws ParseException {
        boolean newDTOList = false;
        Integer lRecycleStatusIdInt = 0;
        java.util.Date lRecycleStatusDate = null;
        java.sql.Date lSearchDate = null;
        ArrayList<PersonContractRecycle> lPersonContractsRecycle = null;

        String lMemberId = form.getMemberId();
        String lContractNo = form.getContractNo();
        String lGroupNo = form.getGroupNo();
        String lProgramName = form.getProgramName();
        String lRecycleStatusId = form.getRecycleStatusId();
        String lRecycleStatusDateString = form.getRecycleStatusDate();

        // Save the search criteria, so after modifying (approving, denying) and committing the changes
        // retrieve a fresh list with the same criteria.
        RecycleSearchCriteria lRecycleSearchCriteria = new RecycleSearchCriteria();
        lRecycleSearchCriteria.setMemberID(lMemberId);
        lRecycleSearchCriteria.setContractNo(lContractNo);
        lRecycleSearchCriteria.setGroupNo(lGroupNo);
        lRecycleSearchCriteria.setProgramName(lProgramName);
        lRecycleSearchCriteria.setRecycleStatusID(lRecycleStatusId);
        lRecycleSearchCriteria.setRecycleStatusDateString(lRecycleStatusDateString);
        getUserSession().setRecycleSearchCriteria(lRecycleSearchCriteria);

        if (lRecycleStatusDateString != null && lRecycleStatusDateString.length() > 0) {
            lRecycleStatusDate = getFmt().parse(lRecycleStatusDateString);
            lSearchDate = new java.sql.Date(lRecycleStatusDate.getTime());
        }

        if (lRecycleStatusId != null && BPMAdminUtils.isValueInteger(lRecycleStatusId)) {
            lRecycleStatusIdInt = Integer.valueOf(lRecycleStatusId);
        }

        lPersonContractsRecycle = getUserSession().getPersonContractsRecycle();

        if (CollectionUtils.isEmpty(lPersonContractsRecycle) || form.getActionType().equals(ACTION_SEARCH)) {
            lPersonContractsRecycle = (ArrayList<PersonContractRecycle>) memberService.getMemberContractsRecycle(lMemberId, lGroupNo, lContractNo, lSearchDate, lRecycleStatusIdInt, lProgramName);
            getUserSession().setPersonContractsRecycle(lPersonContractsRecycle);
            newDTOList = true;
        }

        if (lPersonContractsRecycle.size() < 1) {
            createNoResultsFoundMessageOnModel(modelMap);
        }

        setPersonContractRecyclePagination(modelMap, getUserSession(), form.getActionType(), newDTOList);
    }

    protected void setPersonContractRecyclePagination(ModelMap modelMap,
                                                      UserSession sessionBean,
                                                      String actionType,
                                                      boolean newDTOList) {
        ArrayList<PersonContractRecycle> lPersonContractsRecycleList = sessionBean.getPersonContractsRecycle();

        /**
         * Create a Pageable wrapper for the array list.
         * Create a Pagination object and point it to the wrapper.
         */
        BPMPagination pagination = sessionBean.getPaginationMap().get(PERSON_CONTRACT_RECYCLE_LIST);
        PageablePersonContractRecycle lPPR = null;
        if (pagination == null || newDTOList) {
            lPPR = new PageablePersonContractRecycle(lPersonContractsRecycleList);
            lPPR.addRowNumber();
            pagination = new BPMPagination(lPPR, new ArrayList<Object>(lPersonContractsRecycleList));
            sessionBean.getPaginationMap().put(PERSON_CONTRACT_RECYCLE_LIST, pagination);
        }

        ArrayList<PersonContractRecycle> lPersonContractsRecyclePerPage =
                (ArrayList<PersonContractRecycle>) determineNextOrBackAction(actionType, pagination);
        setAttributesForPaginationOnModel(modelMap, lPersonContractsRecycleList.size(), pagination);
        sessionBean.setPagination(pagination);

        modelMap.put("personContractsRecycle", lPersonContractsRecyclePerPage);
        sessionBean.setPersonContractsRecyclePerPage(lPersonContractsRecyclePerPage);
    }

    private void update(PersonContractRecycleSearchForm form, ModelMap modelMap) throws ParseException, BPMException {
        Integer lRecycleStatusIdInt = 0;
        java.util.Date lRecycleStatusDate = null;
        java.sql.Date lSearchDate = null;
        boolean newDTOList = false;
        ArrayList<PersonContractRecycle> lPersonContractsRecycleList = null;
        String lRecycleStatusDateString = form.getRecycleStatusUpdateDate();
        String recycleStatusUpdateId = form.getRecycleStatusUpdateId();
        String lReason = form.getReason();
        String lApprover = form.getApprover();
        ArrayList<LookUpValueCode> lLuvRecycleStatusCodes = getUserSession().getRecycleStatusCodes();

        SimpleDateFormat fmt = new SimpleDateFormat(BPMAdminConstants.HP_BPM_ADMIN_UI_COMMON_DATE_FORMAT);

        if (lRecycleStatusDateString != null && lRecycleStatusDateString.length() > 0) {
            lRecycleStatusDate = getFmt().parse(lRecycleStatusDateString);
            lSearchDate = new java.sql.Date(lRecycleStatusDate.getTime());
        }
        if (recycleStatusUpdateId != null && BPMAdminUtils.isValueInteger(recycleStatusUpdateId)) {
            lRecycleStatusIdInt = Integer.valueOf(recycleStatusUpdateId);
        }

        // For all the ones that are checked
        lPersonContractsRecycleList = getUserSession().getPersonContractsRecycle();
        for (int i = 0; i < lPersonContractsRecycleList.size(); i++) {
            PersonContractRecycle lPersonContractRecycle = lPersonContractsRecycleList.get(i);
            // If checked
            if (isRecycleRecordChecked(lPersonContractRecycle, form)) {
                lPersonContractRecycle.setApproverUserId(lApprover);
                lPersonContractRecycle.setRecycleStatusId(lRecycleStatusIdInt);
                lPersonContractRecycle.setReasonDesc(lReason);

                memberService.updatePersonContractRecycle(lPersonContractRecycle);

                for (int luvs = 0; luvs < lLuvRecycleStatusCodes.size(); luvs++) {
                    if (lLuvRecycleStatusCodes.get(luvs).getLuvId().intValue() == lRecycleStatusIdInt.intValue()) {
                        if (BPMAdminConstants.BPM_RECYCLE_STATUS_APPROVED.equals(lLuvRecycleStatusCodes.get(luvs).getLuvVal())) {
                            // If the status is set to Approved, set the member status date so that it is picked up
                            // by the membership feed process.
                            memberService.updateMemberProgramStatusContractStatusDate(lPersonContractRecycle.getPersonNumber(), lPersonContractRecycle.getProgramId());
                        }
                    }
                }
            }
        }

        // After having saved the changes, retrieve a fresh list of recycles using the same criteria that
        // were used before. This way the records that were changed will not re-appear on the screen.
        RecycleSearchCriteria lRecycleSearchCriteria = getUserSession().getRecycleSearchCriteria();
        String lRecycleStatusDateSearchString = lRecycleSearchCriteria.getRecycleStatusDateString();
        java.sql.Date lRecycleSearchDate = null;
        Integer lRecycleStatusSearchIdInt = 0;
        if (lRecycleSearchCriteria.getRecycleStatusID() != null && BPMAdminUtils.isValueInteger(lRecycleSearchCriteria.getRecycleStatusID())) {
            lRecycleStatusSearchIdInt = Integer.valueOf(lRecycleSearchCriteria.getRecycleStatusID());
        }

        if (lRecycleStatusDateString != null && lRecycleStatusDateString.length() > 0) {
            lRecycleSearchDate = BPMAdminUtils.convertStringToSqlDate(lRecycleStatusDateSearchString, BPMAdminConstants.HP_BPM_ADMIN_UI_COMMON_DATE_FORMAT);
        }
        lPersonContractsRecycleList =
                (ArrayList<PersonContractRecycle>) memberService.getMemberContractsRecycle(lRecycleSearchCriteria.getMemberID()
                        , lRecycleSearchCriteria.getGroupNo()
                        , lRecycleSearchCriteria.getContractNo()
                        , lRecycleSearchDate
                        , lRecycleStatusSearchIdInt
                        , lRecycleSearchCriteria.getProgramName());

        getUserSession().setPersonContractsRecycle(lPersonContractsRecycleList);
        newDTOList = true;
        // Set actionType to empty string to start pagination from the beginning.
        setPersonContractRecyclePagination(modelMap, getUserSession(), "", newDTOList);
    }

    private boolean isRecycleRecordChecked(PersonContractRecycle pPersonContractRecycle, PersonContractRecycleSearchForm pPersonContractRecycleSearchForm) {
        String[] lSelectedRecycleIDs = pPersonContractRecycleSearchForm.getSelectedRecycleIDs();

        if (lSelectedRecycleIDs != null) {
            for (int recID = 0; recID < lSelectedRecycleIDs.length; recID++) {
                if (pPersonContractRecycle.getRecycleId().intValue() == Integer.parseInt(lSelectedRecycleIDs[recID])) {
                    return true;
                }
            }
        }

        return false;
    }

    private String performPaginationAction(PersonContractRecycleSearchForm form, ModelMap modelMap) throws BPMException, ParseException {
        setPersonContractRecyclePagination(modelMap, getUserSession(), form.getActionType(), false);
        populateSelects(modelMap);
        RecycleSearchCriteria foo = getUserSession().getRecycleSearchCriteria();
        getUserSession().setMemberId(foo.getMemberID());
        getUserSession().setContractNo(foo.getContractNo());
        getUserSession().setGroupNo(foo.getGroupNo());
        getUserSession().setProgramName(foo.getProgramName());
        getUserSession().setRecycleStatusId(StringUtils.isNotEmpty(foo.getRecycleStatusID())  ? Integer.valueOf(foo.getRecycleStatusID()) : null);


        return "personContractRecycleSearch";
    }

    @Override
    public boolean supports(Class<?> clazz) {
        return PersonContractRecycleSearchForm.class.isAssignableFrom(clazz);
    }

    @Override
    public void validate(Object target, Errors errors) {
        PersonContractRecycleSearchForm form = (PersonContractRecycleSearchForm) target;

        boolean minimumOneSearchTarget = false;
        if (form.getMemberId().length() > 0) {
            getValidationSupport().validateNotInteger("memberId", form.getMemberId(), errors, new Object[]{"Member ID"});
            minimumOneSearchTarget = true;
        }
        if (form.getGroupNo().length() > 0) {
            getValidationSupport().validateNotInteger("groupNo", form.getGroupNo(), errors, new Object[]{"Group Number"});
            minimumOneSearchTarget = true;
        }
        if (form.getContractNo().length() > 0) {
            getValidationSupport().validateNotInteger("contractNo", form.getContractNo(), errors, new Object[]{"Contract Number"});
            minimumOneSearchTarget = true;
        }
        if (form.getProgramName().length() > 0) {
            minimumOneSearchTarget = true;
        }
        if (form.getRecycleStatusId().length() > 0 && !form.getRecycleStatusId().equals("select")) {
            minimumOneSearchTarget = true;
        }
        if (form.getRecycleStatusId().equals("select")) {
            form.setRecycleStatusId("");
        }

        if (form.getRecycleStatusDate().length() > 0) {
            getValidationSupport().validateDateFormat("recycleStatusDate", form.getRecycleStatusDate(), errors, new Object[]{"Contract Status Date "});
            minimumOneSearchTarget = true;
        }

        if (!minimumOneSearchTarget) {
            String[] fieldValues = {};
            getValidationSupport().validateAtleastOneSelection("memberId", "", errors, new Object[]{"field element to search on"});
        }
    }

    private void validateForRecycleUpdate(PersonContractRecycleSearchForm form, ModelMap modelMap, Errors errors) {
        if (form.getRecycleStatusId().equalsIgnoreCase("select")) {
            form.setRecycleStatusId("");
        }

        if (form.getRecycleStatusUpdateId().length() <= 0 || form.getRecycleStatusUpdateId().equals("select")) {
            getValidationSupport().addValidationFailureMessage("recycleStatusUpdateId", errors, "errors.required", new Object[]{"Recycle Status"});
        }

        if (form.getRecycleStatusUpdateDate().length() > 0) {
            getValidationSupport().validateDateFormat("recycleStatusUpdateDate", form.getRecycleStatusUpdateDate(), errors, new Object[]{"Status Date"});
        }

        getValidationSupport().validateRequiredFieldIsNotEmpty("approver", form.getApprover(), errors, new Object[]{"Approver"});
        getValidationSupport().validateRequiredFieldIsNotEmpty("reason", form.getReason(), errors, new Object[]{"Approver"});
    }

}
