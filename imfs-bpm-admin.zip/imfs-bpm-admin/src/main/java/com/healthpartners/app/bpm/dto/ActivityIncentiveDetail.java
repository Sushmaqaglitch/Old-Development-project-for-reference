package com.healthpartners.app.bpm.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;


public class ActivityIncentiveDetail implements Serializable
{	
	static final long serialVersionUID = 0L;

	 // Database table ID.
	private Integer rowID;
	private Integer activityIncentiveID;
	private Integer groupID;
	private Integer groupRequiredID;
	private Integer incentiveOptionID;
	private String  incentiveOptionName;
	private Integer programID;
	private Integer activityID;
	private String activityName;
	private Integer activityTypeCodeID;
	private Collection<Activity> activityDefinitions;
    private Integer incentedStatusTypeCodeID;
    private Integer incentiveQuantity;
    private String insertUserId;	
	private String modifyUserId;
	private java.sql.Date modifyDate;
	private java.sql.Date insertDate;
	
	private String activityTypeVal;
	private String ativityTypeDesc;
	private Integer activityIncentiveTypeCodeID;
	private String activityIncentiveTypeVal;
	private String activityIncentiveTypeDesc;
	
	private String activityIncentedStatusTypeVal;
	private String activityIncentedStatusTypeDesc;
	
	private Integer participantRelationshipCode;
	private String participantRelationshipDesc;
	private Integer participantRelationshipQty;
	
	private Integer collectionID;
	private String collectionName;
	
	private ArrayList<IncentiveParticipantRelationship> incentiveParticipantRelationships;
	private ArrayList<IncentiveParticipantRelationship> incentiveParticipantRelationshipsToRemove;

	
	
	public Integer getRowID() {
		return rowID;
	}
	public void setRowID(Integer rowID) {
		this.rowID = rowID;
	}
	public Integer getActivityIncentiveID() {
		return activityIncentiveID;
	}
	public void setActivityIncentiveID(Integer activityIncentiveID) {
		this.activityIncentiveID = activityIncentiveID;
	}
	public Integer getGroupID() {
		return groupID;
	}
	public void setGroupID(Integer groupID) {
		this.groupID = groupID;
	}
	public Integer getGroupRequiredID() {
		return groupRequiredID;
	}
	public void setGroupRequiredID(Integer groupRequiredID) {
		this.groupRequiredID = groupRequiredID;
	}
	public Integer getIncentiveOptionID() {
		return incentiveOptionID;
	}
	public void setIncentiveOptionID(Integer incentiveOptionID) {
		this.incentiveOptionID = incentiveOptionID;
	}
	public Integer getProgramID() {
		return programID;
	}
	public void setProgramID(Integer programID) {
		this.programID = programID;
	}
	public Integer getActivityID() {
		return activityID;
	}
	public void setActivityID(Integer activityID) {
		this.activityID = activityID;
	}
	public Integer getActivityTypeCodeID() {
		return activityTypeCodeID;
	}
	public void setActivityTypeCodeID(Integer activityTypeCodeID) {
		this.activityTypeCodeID = activityTypeCodeID;
	}
	
	
	
	public Collection<Activity> getActivityDefinitions() {
		return activityDefinitions;
	}
	public void setActivityDefinitions(Collection<Activity> activityDefinitions) {
		this.activityDefinitions = activityDefinitions;
	}
	public Integer getIncentedStatusTypeCodeID() {
		return incentedStatusTypeCodeID;
	}
	public void setIncentedStatusTypeCodeID(Integer incentedStatusTypeCodeID) {
		this.incentedStatusTypeCodeID = incentedStatusTypeCodeID;
	}
	public Integer getIncentiveQuantity() {
		return incentiveQuantity;
	}
	public void setIncentiveQuantity(Integer incentiveQuantity) {
		this.incentiveQuantity = incentiveQuantity;
	}
	public String getInsertUserId() {
		return insertUserId;
	}
	public void setInsertUserId(String insertUserId) {
		this.insertUserId = insertUserId;
	}
	public String getModifyUserId() {
		return modifyUserId;
	}
	public void setModifyUserId(String modifyUserId) {
		this.modifyUserId = modifyUserId;
	}
	public java.sql.Date getModifyDate() {
		return modifyDate;
	}
	public void setModifyDate(java.sql.Date modifyDate) {
		this.modifyDate = modifyDate;
	}
	public java.sql.Date getInsertDate() {
		return insertDate;
	}
	public void setInsertDate(java.sql.Date insertDate) {
		this.insertDate = insertDate;
	}
	public String getActivityTypeVal() {
		return activityTypeVal;
	}
	public void setActivityTypeVal(String activityTypeVal) {
		this.activityTypeVal = activityTypeVal;
	}
	public String getAtivityTypeDesc() {
		return ativityTypeDesc;
	}
	public void setAtivityTypeDesc(String ativityTypeDesc) {
		this.ativityTypeDesc = ativityTypeDesc;
	}
	
	public String getActivityIncentiveTypeVal() {
		return activityIncentiveTypeVal;
	}
	public void setActivityIncentiveTypeVal(String activityIncentiveTypeVal) {
		this.activityIncentiveTypeVal = activityIncentiveTypeVal;
	}
	
	public Integer getActivityIncentiveTypeCodeID() {
		return activityIncentiveTypeCodeID;
	}
	public void setActivityIncentiveTypeCodeID(Integer activityIncentiveTypeCodeID) {
		this.activityIncentiveTypeCodeID = activityIncentiveTypeCodeID;
	}
	public String getActivityIncentiveTypeDesc() {
		return activityIncentiveTypeDesc;
	}
	public void setActivityIncentiveTypeDesc(String activityIncentiveTypeDesc) {
		this.activityIncentiveTypeDesc = activityIncentiveTypeDesc;
	}
	public String getActivityIncentedStatusTypeVal() {
		return activityIncentedStatusTypeVal;
	}
	public void setActivityIncentedStatusTypeVal(
			String activityIncentedStatusTypeVal) {
		this.activityIncentedStatusTypeVal = activityIncentedStatusTypeVal;
	}
	public String getActivityIncentedStatusTypeDesc() {
		return activityIncentedStatusTypeDesc;
	}
	public void setActivityIncentedStatusTypeDesc(
			String activityIncentedStatusTypeDesc) {
		this.activityIncentedStatusTypeDesc = activityIncentedStatusTypeDesc;
	}
	public Integer getParticipantRelationshipCode() {
		return participantRelationshipCode;
	}
	public void setParticipantRelationshipCode(Integer participantRelationshipCode) {
		this.participantRelationshipCode = participantRelationshipCode;
	}
	public String getParticipantRelationshipDesc() {
		return participantRelationshipDesc;
	}
	public void setParticipantRelationshipDesc(String participantRelationshipDesc) {
		this.participantRelationshipDesc = participantRelationshipDesc;
	}
	public Integer getParticipantRelationshipQty() {
		return participantRelationshipQty;
	}
	public void setParticipantRelationshipQty(Integer participantRelationshipQty) {
		this.participantRelationshipQty = participantRelationshipQty;
	}
	public String getIncentiveOptionName() {
		return incentiveOptionName;
	}
	public void setIncentiveOptionName(String incentiveOptionName) {
		this.incentiveOptionName = incentiveOptionName;
	}
	public ArrayList<IncentiveParticipantRelationship> getIncentiveParticipantRelationships() {
		return incentiveParticipantRelationships;
	}
	public void setIncentiveParticipantRelationships(
			ArrayList<IncentiveParticipantRelationship> incentiveParticipantRelationships) {
		this.incentiveParticipantRelationships = incentiveParticipantRelationships;
	}
	public String getActivityName() {
		return activityName;
	}
	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}
	public final Integer getCollectionID() {
		return collectionID;
	}
	public final void setCollectionID(Integer collectionID) {
		this.collectionID = collectionID;
	}
	public final String getCollectionName() {
		return collectionName;
	}
	public final void setCollectionName(String collectionName) {
		this.collectionName = collectionName;
	}
	public ArrayList<IncentiveParticipantRelationship> getIncentiveParticipantRelationshipsToRemove() {
		return incentiveParticipantRelationshipsToRemove;
	}
	public void setIncentiveParticipantRelationshipsToRemove(
			ArrayList<IncentiveParticipantRelationship> incentiveParticipantRelationshipsToRemove) {
		this.incentiveParticipantRelationshipsToRemove = incentiveParticipantRelationshipsToRemove;
	}
	
	
}
