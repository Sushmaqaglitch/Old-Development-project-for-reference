package com.healthpartners.app.bpm.dao;

import com.healthpartners.app.bpm.common.BPMAdminConstants;
import com.healthpartners.app.bpm.common.BPMAdminUtils;
import com.healthpartners.app.bpm.dto.*;
import com.healthpartners.app.bpm.exception.BPMException;
import jakarta.annotation.PostConstruct;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.jdbc.support.incrementer.DataFieldMaxValueIncrementer;
import org.springframework.jdbc.support.incrementer.OracleSequenceMaxValueIncrementer;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.sql.DataSource;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Collection;

@Repository
@Transactional(timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
public class RewardCardDAOJdbc extends JdbcDaoSupport implements RewardCardDAO {

	protected final Log logger = LogFactory.getLog(getClass());

	private static final String selectRewardCardAddress =
	"select, /n" +
	"  t.reward_txn_hist_id, /n" +
	"  t.first_nm, /n" +
	"  t.middle_initial, /n" +
	"  t.last_nm, /n" +
			" t.addr_line_1, /n" +
	"  t.addr_line_2, /n" +
	"  t.city, /n" +
	"  t.state_cd, /n" +
	"  t.postal_code, /n" +
	"  t.postal_code_ext, /n" +
	"  t.country_cd, /n" +
	"  t.address_sts_tp_id, /n" +
	"  t.address_sts_dt, /n" +
	"  t.biz_pgm_id, /n" +
	"  t.prsn_dmgrphcs_id, /n" +
	"  t.incntv_optn_id, /n" +
	"  MAX(insert_ts) max_insert_dt /n" +
	"  from  reward_card_address t";


	// @formatter:off
	private static final String selectIncentiveOptionRewardCards =
			"select t.incntv_optn_reward_card_id,\n" +
					"	t.reward_card_id,\n" +
					"	r.quote_no,\n" +
					"	r.quote_desc,\n" +
					"	t.reward_card_fee_id,\n" +
					"	(SELECT REWARD_CARD_FEE_NM FROM reward_card_fee rcf WHERE rcf.REWARD_CARD_FEE_ID = t.reward_card_fee_id ) REWARD_CARD_FEE_NM, \n" +
					"	t.reward_embossed_line_id,\n" +
					"	(SELECT EMBOSS_NAME FROM reward_embossed_line rel WHERE rel.reward_embossed_line_id = t.reward_embossed_line_id) EMBOSS_NAME, \n" +
					"	t.reward_carrier_msg_id,\n" +
					"	(SELECT REWARD_CARRIER_MSG_NM FROM reward_carrier_msg rcm WHERE rcm.REWARD_CARRIER_MSG_ID = t.REWARD_CARRIER_MSG_ID) REWARD_CARRIER_MSG_NM , \n" +
					"	t.reward_trnsctn_msg_id,\n" +
					"	(SELECT REWARD_TRNSCTN_MSG_NM FROM reward_trnsctn_msg rtm WHERE rtm.REWARD_TRNSCTN_MSG_ID = t.reward_trnsctn_msg_id) REWARD_TRNSCTN_MSG_NM, \n" +
					"	t.incntv_optn_reward_card_nm,\n" +
					"	t.incntv_optn_reward_card_desc,\n" +
					"	t.eff_dt,\n" +
					"	t.end_dt,\n" +
					"	t.REWARD_CARD_CLIENT_CNTCT_ID,\n" +
					"	(SELECT REWARD_CARD_CLIENT_INFO_NM FROM REWARD_CARD_CLIENT_CNTCT rccc WHERE rccc.REWARD_CARD_CLIENT_CNTCT_ID = t.REWARD_CARD_CLIENT_CNTCT_ID) REWARD_CARD_CLIENT_INFO_NM\n" +
					"	from INCNTV_OPTN_REWARD_CARD t,\n" +
					"	reward_card r\n" +
					"where t.reward_card_id = r.reward_card_id";
	
	private static final String selectRewardCard =
			"select t.reward_card_id,\n" +
					"	t.quote_no,\n" +
					"	t.quote_desc,\n" +
					"	t.eff_dt,\n" +
					"	t.end_dt\n" +
					"  from REWARD_CARD t,\n" +
					"	incntv_optn_reward_card iorc\n" +
					"  where iorc.incntv_optn_reward_card_id = ? and\n" +
					"        iorc.reward_card_id = t.reward_card_id";
	
	private static final String updateProgramRewardControllerForBatchProcessing =
			"UPDATE reward_cntrl_biz_pgm rcbp\n" +
					"SET rcbp.run_freq_id = ?,\n" +
					"	rcbp.reward_card_id = ?,\n" +
					"	rcbp.modify_ts = sysdate,\n" +
					"	rcbp.modify_usr = ?\n" +
					"WHERE rcbp.biz_pgm_id = ?\n" +
					"AND   rcbp.incntv_optn_id = ?";

	private static final String findProgramRewardController =
			"select count(*) COUNT from reward_cntrl_biz_pgm t\n" +
					"where t.biz_pgm_id = ? and\n" +
					"t.incntv_optn_id = ? ";
	
	private static final String insertProgramRewardControllerForBatchProcessing =
			"INSERT INTO reward_cntrl_biz_pgm t\n" +
					"	(t.reward_cntrl_pgm_id, \n" +
					"	t.biz_pgm_id, \n" +
					"	t.run_freq_id,\n" +
					"	t.reward_card_id,\n" +
					"	t.incntv_optn_id,\n" +
					"	t.scrty_tp_id,\n" +
					"	t.insert_usr,\n" +
					"	t.insert_ts) \n" +
					"\n" +
					"VALUES (?, \n" +
					"	?, \n" +
					"	?, \n" +
					"	?, \n" +
					"	?, \n" +
					"	(select l.lu_id from luv l where l.lu_grp = 'REWARD_SCRTY_TP' and l.lu_val = ?), \n" +
					"	?,\n" +
					"	SYSDATE) ";
	
	private static final String insertProgramRewardControllerProcessTracker =
			"INSERT INTO reward_cntrl_pgm_prcs_tracker t\n" +
					"	(t.reward_cntrl_pgm_id, \n" +
					"	t.dt_last_processed, \n" +
					"	t.prcs_status_tp_id,\n" +
					"	t.records_sent)\n" +
					"\n" +
					"VALUES (?, \n" +
					"	?, \n" +
					"	(select l.lu_id from luv l where l.lu_grp = 'REWARD_PRCS_TP' and l.lu_val = ?), \n" +
					"	?) ";
	// @formatter:on
	private static final String selectRewardCards = """
			select t.reward_card_id,
				  t.quote_no,
				  t.quote_desc,
				  t.eff_dt,
				  t.end_dt
			 from REWARD_CARD t
			 where sysdate between t.eff_dt and t.end_dt
			""";

	private static String groupByRewardCardAddress =
			" group by t.reward_txn_hist_id, " +
					"t.first_nm, " +
					"t.middle_initial, " +
					"t.last_nm, " +
					"t.addr_line_1, " +
					"t.addr_line_2, " +
					"t.city, " +
					"t.state_cd, " +
					"t.postal_code, " +
					"t.postal_code_ext, " +
					"t.country_cd, " +
					"t.address_sts_tp_id, " +
					"t.address_sts_dt," +
					"t.biz_pgm_id," +
					"t.prsn_dmgrphcs_id," +
					"t.incntv_optn_id";

	private static final String selectRewardCardFulfillmentTrackingReportHist = """
						 select
			                t.reward_txn_hist_id,
			                t.biz_pgm_id,
			                bp.grp_id,
			                egs.empl_grp_no,
			                egs.empl_grp_site_id_no,
			                egs.empl_grp_nm,
			                egs.empl_grp_site_nm,
			                t.contract_no,
			                t.prsn_dmgrphcs_id,
			                pd.prsn_id,
			                pd.hp_mem_id,
			                pd.first_nm,
			                pd.last_nm,
			                pd.middle_nm,
			                pd.dob_dt,
			                bp.contribution_start_dt,
			                bp.contribution_end_dt,
			                t.reward_amt,
			                t.tier_contrib_id,
			                t.reward_dt,
			                t.actv_id,
			                (select l.actv_nm from activity l where l.actv_id = t.actv_id) activity_name, \s
			                a.srce_actv_id,
			                t.incntv_optn_id,
			                t.external_txn_id,
			                t.order_id,
			                t.reward_card_no_mskd,
			                t.reward_card_vendor_fee,
			                t.insert_ts,
			                (select l.lu_desc from luv l where l.lu_id = bp_io.incntv_rpt_desc_id) incntv_rpt_name,
			                rc.quote_no,
			                rc.quote_desc,
			                rcf.card_fee_amt,
			                rcf.card_fee_desc,
			                rcm.reward_carrier_msg_nm,
			                rcm.reward_carrier_msg_desc,
			                rcm.reward_carrier_msg_desc_2,
			                rel.emboss_name,
			                rel.embossed_desc,
			                rtm.reward_trnsctn_msg_nm,
			                rtm.reward_trnsctn_msg_desc
			             
			             from REWARD_FULFILL_RPT_TRCK_HIST t,
			                  business_program bp,
			                  biz_pgm_incentive_option bp_io,
			                  empl_grp_site egs,
			                  activity a,
			                  prsn_demographics pd,
			                  incntv_optn_reward_card io_rc,
			                  reward_card rc,
			                  reward_card_fee rcf,
			                  reward_carrier_msg rcm,
			                  reward_trnsctn_msg rtm,
			                  reward_embossed_line rel
			             where
			                 t.biz_pgm_id = bp.biz_pgm_id
			                 AND  bp.grp_id = egs.grp_id
			                 AND  bp.subgrp_id = egs.subgrp_id
			                 AND  t.actv_id = a.actv_id
			                 AND  bp.biz_pgm_id = bp_io.biz_pgm_id
			                 AND  bp_io.incntv_optn_id = t.incntv_optn_id
			                 AND  pd.prsn_dmgrphcs_id = t.prsn_dmgrphcs_id
			                 AND  bp_io.incntv_optn_reward_card_id = io_rc.incntv_optn_reward_card_id
			                 AND  io_rc.reward_card_id = rc.reward_card_id
			                 AND  io_rc.reward_card_fee_id = rcf.reward_card_fee_id
			                 AND  io_rc.reward_embossed_line_id = rel.reward_embossed_line_id
			                 AND  io_rc.reward_trnsctn_msg_id = rtm.reward_trnsctn_msg_id
			                 AND  io_rc.reward_carrier_msg_id = rcm.reward_carrier_msg_id
			             	 AND (t.external_txn_id not like '%HPD%' or t.external_txn_id is null)
			""";

	private static final String selectRewardCardFulfillmentTrackingReportHistManual = """
			  select
					 t.reward_txn_hist_id,
					 rsdr.reward_card_cstmr_id empl_grp_no,
					 rsdr.reward_card_cstmr_nm empl_grp_nm,
					 rsdr.reward_card_prsn_id prsn_id,
					 pd.hp_mem_id,
					 pd.first_nm,
					 pd.last_nm,
					 pd.middle_nm,
					 pd.dob_dt,
					 rsdr.reward_card_addr_line_1,
					 rsdr.reward_card_addr_line_2,
					 rsdr.reward_card_city,
					 rsdr.reward_card_st,
					 rsdr.reward_card_pstl_cd,
					 t.reward_amt,
					 t.reward_dt,
					 t.external_txn_id,
					 t.order_id,
					 t.reward_card_no_mskd,
					 t.reward_card_vendor_fee,
					 t.insert_ts,
					 rsdr.reward_card_quote_nmbr quote_no,
					 rc.quote_desc
					 
			  from REWARD_FULFILL_RPT_TRCK_HIST t,
				   REWARD_SHPNG_DTL_RPT rsdr,
				   prsn_demographics pd,
				   reward_card rc

			 where
			  	t.prsn_dmgrphcs_id = pd.prsn_dmgrphcs_id
			  	AND  t.external_txn_id = rsdr.reward_card_txn_id
			  	AND  rsdr.reward_card_quote_nmbr = rc.quote_no
			  	AND t.external_txn_id like '%HPD%'
			""";

	private static final String selectRewardCardFulfillmentTrackingReportStatus = """
			SELECT
				rfths.reward_txn_hist_id,
				(select l.lu_val from luv l where l.lu_id = rfths.reward_card_sts_id) status,
				rfths.reward_card_sts_dt,
				MAX(rfths.INSERT_TS) last_run_dt
			FROM reward_fulfill_trck_hist_sts rfths
			""";

	private static final String selectRewardCardFees = """
   		select t.reward_card_fee_id,
			t.vendor_id,
			(SELECT lu_val FROM luv where lu_id = t.vendor_id) vendor_name,
			t.card_fee_amt,
			t.reward_card_fee_nm,
			t.card_fee_desc,
			t.eff_dt,
			t.end_dt
			from REWARD_CARD_FEE t
			where sysdate between t.eff_dt and t.end_dt
		""";

	private static final String selectRewardCardEmbossedLines = """
		select t.reward_embossed_line_id,
							   t.emboss_name,
							   t.embossed_desc,
							   t.embossed_tp_cd_id,
							   (select l.lu_val from luv l where l.lu_id = t.embossed_tp_cd_id) embossedTypCode,
							   t.eff_dt,
							   t.end_dt
						   from REWARD_EMBOSSED_LINE t
						   where sysdate between t.eff_dt and t.end_dt
		""";

	private static final String selectRewardCarrierMessages = """
		select t.reward_carrier_msg_id,
  				       t.reward_carrier_msg_nm,
  				       t.reward_carrier_msg_desc,
  				       t.reward_carrier_msg_desc_2,
  				       t.eff_dt,
  				       t.end_dt\s
  				   from REWARD_CARRIER_MSG t\s
  				   where sysdate between t.eff_dt and t.end_dt
	""";

	private static final String selectRewardTransactionMessages = """
		select t.reward_trnsctn_msg_id,
								   t.reward_trnsctn_msg_nm,
								   t.reward_trnsctn_msg_desc,
								   t.eff_dt,
								   t.end_dt\s
						   from REWARD_TRNSCTN_MSG t
						   where sysdate between t.eff_dt and t.end_dt
	""";

	private static final String selectRewardCardClientInfo = """
		SELECT REWARD_CARD_CLIENT_CNTCT_ID,\s
				 REWARD_CARD_CLIENT_INFO_NM,
				 CLIENT_CMPNY_NM, \s
				 CLIENT_CNTCT_NM,
				 CLIENT_ADDR_LINE_1,
				 CLIENT_ADDR_LINE_2,
				 CLIENT_CITY,
				 CLIENT_STATE_CD,
				 CLIENT_POSTAL_CODE,
				 CLIENT_POSTAL_CD_EXT,
				 CLIENT_TAX_ID,
				 CLIENT_CNTCT_EFF_DT,
				 CLIENT_CNTXT_END_DT,
				 CASE WHEN (SELECT DISTINCT REWARD_CARD_CLIENT_CNTCT_ID\s
							  FROM incntv_optn_reward_card iorc\s
							 WHERE iorc.REWARD_CARD_CLIENT_CNTCT_ID = rccc.REWARD_CARD_CLIENT_CNTCT_ID)
				 IS NOT NULL THEN 'Y'
				 ELSE 'N'
				 END used_flg
				   FROM REWARD_CARD_CLIENT_CNTCT rccc
		""";

	private static final String updateIncentiveOptionRewardCard = """
			UPDATE incntv_optn_reward_card
		SET
		INCNTV_OPTN_REWARD_CARD_NM = ?
		, INCNTV_OPTN_REWARD_CARD_DESC = ?
		, REWARD_CARD_ID = ?
		, REWARD_CARD_FEE_ID = ?
		, REWARD_EMBOSSED_LINE_ID = ?
		, REWARD_CARRIER_MSG_ID = ?
		, REWARD_TRNSCTN_MSG_ID = ?
		, EFF_DT = ?
		, END_DT = ?
		, REWARD_CARD_CLIENT_CNTCT_ID = ?
		, MODIFY_USR = ?
		, MODIFY_TS = SYSDATE
		WHERE
		INCNTV_OPTN_REWARD_CARD_ID = ?
""";
	public static final String insertIncentiveOptionRewardCard = """
		INSERT INTO incntv_optn_reward_card
				(INCNTV_OPTN_REWARD_CARD_ID
		, INCNTV_OPTN_REWARD_CARD_NM
		, INCNTV_OPTN_REWARD_CARD_DESC
		, REWARD_CARD_ID
		, REWARD_CARD_FEE_ID
		, REWARD_EMBOSSED_LINE_ID
		, REWARD_CARRIER_MSG_ID
		, REWARD_TRNSCTN_MSG_ID
		, EFF_DT
		, END_DT
		, REWARD_CARD_CLIENT_CNTCT_ID
		, INSERT_USR
		, MODIFY_USR
		, INSERT_TS
		, MODIFY_TS
		)
		VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, SYSDATE, SYSDATE)
	""";

	public static final String deleteIncentiveOptionRewardCard = """
		DELETE FROM incntv_optn_reward_card WHERE INCNTV_OPTN_REWARD_CARD_ID = ?
	""";
	private final DataSource dataSource;

	private DataFieldMaxValueIncrementer rewardControlBusPgmIDIncrementer;
	private DataFieldMaxValueIncrementer incentiveOptionRewardCardIDIncrementer;
	private static final String REWARD_CNTRL_BIZ_PGM_SEQ = "REWARD_CNTRL_BIZ_PGM_SEQ";
	private static final String INCNTV_OPTN_RWRD_CARD_ID_SEQ= "INCNTV_OPTN_RWRD_CARD_ID_SEQ";


	public RewardCardDAOJdbc (DataSource dataSource) {
		this.dataSource = dataSource;
	}


	@PostConstruct
	private void initialize() {
		setDataSource(dataSource);
		rewardControlBusPgmIDIncrementer = new OracleSequenceMaxValueIncrementer(dataSource, REWARD_CNTRL_BIZ_PGM_SEQ);
		incentiveOptionRewardCardIDIncrementer = new OracleSequenceMaxValueIncrementer(dataSource, INCNTV_OPTN_RWRD_CARD_ID_SEQ);

	}

	@Override
	public IncentiveOptionRewardCard getIncentiveOptionRewardCard(Integer incentiveOptionRewardCardID)
															throws DataAccessException {
		final ArrayList<IncentiveOptionRewardCard> lIncentiveOptionRewardCards;

		IncentiveOptionRewardCard lIncentiveOptionRewardCard = new IncentiveOptionRewardCard();

		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] { incentiveOptionRewardCardID };
		int types[] = new int[] { Types.INTEGER };
		StringBuffer lQuery = new StringBuffer();

		lQuery.append(selectIncentiveOptionRewardCards);

		lQuery.append("AND t.incntv_optn_reward_card_id = ?");


		lIncentiveOptionRewardCards = (ArrayList<IncentiveOptionRewardCard>) template.query(
				lQuery.toString(), params, types,
				new IncentiveOptionRewardCardMapper());


		if (!lIncentiveOptionRewardCards.isEmpty()) {
			lIncentiveOptionRewardCard = lIncentiveOptionRewardCards.get(0);
		}

		return lIncentiveOptionRewardCard;
	}

	private static final class IncentiveOptionRewardCardMapper implements RowMapper {
		public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
			IncentiveOptionRewardCard lIncentiveOptionRewardCard = new IncentiveOptionRewardCard();

			lIncentiveOptionRewardCard.setIncentiveOptionRewardCardID(rs.getInt("incntv_optn_reward_card_id"));
			lIncentiveOptionRewardCard.setRewardCardID(rs.getInt("reward_card_id"));

			lIncentiveOptionRewardCard.setQuoteNo(rs.getString("quote_no"));
			lIncentiveOptionRewardCard.setQuoteDesc(rs.getString("quote_desc"));

			lIncentiveOptionRewardCard.setRewardCardFeeID(rs.getInt("reward_card_fee_id"));
			lIncentiveOptionRewardCard.setRewardCardFeeDesc(rs.getString("REWARD_CARD_FEE_NM"));

			lIncentiveOptionRewardCard.setRewardEmbossedLineID(rs.getInt("reward_embossed_line_id"));
			lIncentiveOptionRewardCard.setRewardEmbossedLineDesc(rs.getString("EMBOSS_NAME"));

			lIncentiveOptionRewardCard.setRewardCarrierMessageID(rs.getInt("reward_carrier_msg_id"));
			lIncentiveOptionRewardCard.setRewardCarrierMessageDesc(rs.getString("REWARD_CARRIER_MSG_NM"));

			lIncentiveOptionRewardCard.setRewardTransactionMessageID(rs.getInt("reward_trnsctn_msg_id"));
			lIncentiveOptionRewardCard.setRewardTransactionMessageDesc(rs.getString("REWARD_TRNSCTN_MSG_NM"));

			lIncentiveOptionRewardCard.setIncentiveOptionRewardCardName(rs.getString("incntv_optn_reward_card_nm"));
			lIncentiveOptionRewardCard.setIncentiveOptionRewardCardDesc(rs.getString("incntv_optn_reward_card_desc"));
			lIncentiveOptionRewardCard.setEffectiveDate(rs.getDate("eff_dt"));
			lIncentiveOptionRewardCard.setEndDate(rs.getDate("end_dt"));
			lIncentiveOptionRewardCard.setRewardCardClientContactID(rs.getInt("REWARD_CARD_CLIENT_CNTCT_ID"));
			lIncentiveOptionRewardCard.setRewardCardClientDataName(rs.getString("REWARD_CARD_CLIENT_INFO_NM"));

			return lIncentiveOptionRewardCard;
		}
	}

	@Override
	public RewardCard getRewardCardDef(Integer incentiveOptionRewardCardID) throws DataAccessException {
		final ArrayList<RewardCard> lRewardCards;

		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] { incentiveOptionRewardCardID};
		int types[] = new int[] { Types.INTEGER};

		lRewardCards = (ArrayList<RewardCard>) template.query(
				selectRewardCard, params, types,
				new RewardCardMapper());

		return lRewardCards.get(0);
	}

	private static final class RewardCardMapper implements RowMapper {
		public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
			RewardCard lRewardCard = new RewardCard();

			lRewardCard.setRewardCardID(rs.getInt("reward_card_id"));
			lRewardCard.setQuoteNo(rs.getString("quote_no"));
			lRewardCard.setQuoteDesc(rs.getString("quote_desc"));
			lRewardCard.setEffectiveDate(rs.getDate("eff_dt"));
			lRewardCard.setEndDate(rs.getDate("end_dt"));


			return lRewardCard;
		}
	}

	/**
	 * Update or add new program reward controller record maintained through the program incentive option screen.
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Override
	public int updateProgramRewardControllerForBatchProcessing(Integer programID, Integer incentiveOptionID, Integer rewardCardID, Integer runFreqID, Date programEffDate, String systemID) throws DataAccessException {
		boolean programRewardControllerFound = findProgramRewardController(programID, incentiveOptionID);

		//if not found, add new control record
		if (!programRewardControllerFound) {
			return this.insertProgramRewardControllerForBatchProcessing(programID, incentiveOptionID, rewardCardID, runFreqID, programEffDate);
		}

		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[]{
				runFreqID,
				rewardCardID,
				systemID,
				programID,
				incentiveOptionID};

		int types[] = new int[]{Types.INTEGER,
				Types.INTEGER,
				Types.VARCHAR,
				Types.INTEGER,
				Types.INTEGER};

		return template.update(updateProgramRewardControllerForBatchProcessing, params, types);
	}

	@Override
	public boolean findProgramRewardController(Integer programID, Integer incentiveOptionID) throws DataAccessException {
		boolean programRewardControllerFound = false;

		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] {programID, incentiveOptionID};
		int types[] = new int[] {Types.INTEGER, Types.INTEGER};
		final ArrayList<Integer> recFoundCt = new ArrayList<Integer>();

		template.query(findProgramRewardController, params, types,
				new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						Integer foundCt = Integer.valueOf(rs.getString("COUNT"));
						recFoundCt.add(foundCt);
					}
				});

		if (recFoundCt.get(0) > 0) {
			programRewardControllerFound = true;
		}

		return programRewardControllerFound;
	}

	@Override
	public Integer insertProgramRewardControllerForBatchProcessing(Integer programID, Integer incentiveOptionID, Integer rewardCardID, Integer runFreqID, Date programEffDate) throws DataAccessException {
		Integer rewardControlBusPgmID = rewardControlBusPgmIDIncrementer.nextIntValue();

		JdbcTemplate template = getJdbcTemplate();

		Object params[] = new Object[] {
				rewardControlBusPgmID,
				programID,
				runFreqID,
				rewardCardID,
				incentiveOptionID,
				BPMAdminConstants.ACTIVATE_STATUS,
				BPMAdminConstants.BPM_USER_SYSTEM};
		int types[] = new int[] { Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.VARCHAR, Types.VARCHAR};

		int returnCode = template.update(insertProgramRewardControllerForBatchProcessing, params, types);

		if (returnCode > 0) {
			this.insertProgramRewardControllerProcessTracker(rewardControlBusPgmID, programEffDate);
		}

		return returnCode;

	}

	/*
	 * Initialize the reward program control record with a corresponding tracker record.  The tracker record will use
	 * the program start date that will allow processing to look back to the beginning of the program year when looking
	 * for reward fulfillment records.
	 */
	private Integer insertProgramRewardControllerProcessTracker(Integer rewardControlBusPgmID, Date programEffDate) throws DataAccessException {

		int noOfRecordsProcessed = 0;

		JdbcTemplate template = getJdbcTemplate();

		Object params[] = new Object[] {
				rewardControlBusPgmID,
				programEffDate,
				BPMAdminConstants.RESULT_SUCCESS,
				noOfRecordsProcessed};
		int types[] = new int[] { Types.INTEGER, Types.DATE, Types.VARCHAR, Types.INTEGER};

		int returnCode = template.update(insertProgramRewardControllerProcessTracker, params, types);


		return returnCode;

	}

	@Override
	public Collection<IncentiveOptionRewardCard> getIncentiveOptionRewardCards() throws DataAccessException {
		final ArrayList<IncentiveOptionRewardCard> lIncentiveOptionRewardCards;

		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] {  };
		int types[] = new int[] { };

		lIncentiveOptionRewardCards = (ArrayList<IncentiveOptionRewardCard>) template.query(
				selectIncentiveOptionRewardCards, params, types,
				new IncentiveOptionRewardCardMapper());

		return lIncentiveOptionRewardCards;
	}

	@Override
	public Collection<RewardCard> getRewardCards()
			throws DataAccessException {
		final ArrayList<RewardCard> lRewardCards;

		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] {  };
		int types[] = new int[] { };

		lRewardCards = (ArrayList<RewardCard>) template.query(
				selectRewardCards, params, types,
				new RewardCardMapper());

		return lRewardCards;
	}

	@Override
	public Collection<RewardCardFulfillmentTrackingReportHist> getRewardCardFulfillmentTrackingReportHistSearch(RewardCardFulfillmentSearchTO lRewardCardFulfillmentSearchTO) throws DataAccessException {
		ArrayList<Object> lParameters = new ArrayList<Object>();
		ArrayList<Integer> lTypes = new ArrayList<Integer>();
		StringBuffer lQuery = new StringBuffer();
		lQuery.append(selectRewardCardFulfillmentTrackingReportHist);
		JdbcTemplate template = getJdbcTemplate();

		boolean searchOnManuallyEnterdTransaction = false;

		if (lRewardCardFulfillmentSearchTO.getTransactionID() != null
				&& lRewardCardFulfillmentSearchTO.getTransactionID().length() > 0) {
			if (BPMAdminUtils.isValueInteger(lRewardCardFulfillmentSearchTO.getTransactionID())) {
				lQuery.append(" AND t.reward_txn_hist_id = ?");
				lParameters.add(Integer.valueOf(lRewardCardFulfillmentSearchTO.getTransactionID()));
				lTypes.add(Types.INTEGER);
			} else {
				//CHP transaction id entered to search on.
				searchOnManuallyEnterdTransaction = true;
			}
		}

		if (lRewardCardFulfillmentSearchTO.getGroupNo() != null && lRewardCardFulfillmentSearchTO.getGroupNo().length() > 0) {
			lQuery.append(" AND egs.empl_grp_no = ?");
			lParameters.add(lRewardCardFulfillmentSearchTO.getGroupNo());
			lTypes.add(Types.VARCHAR);
		}

		if (lRewardCardFulfillmentSearchTO.getGroupName() != null && lRewardCardFulfillmentSearchTO.getGroupName().length() > 0) {
			lQuery.append(" AND egs.empl_grp_nm like upper(?)");
			lParameters.add("%" + lRewardCardFulfillmentSearchTO.getGroupName() + "%");
			lTypes.add(Types.VARCHAR);
		}

		if (lRewardCardFulfillmentSearchTO.getSiteNo() != null && lRewardCardFulfillmentSearchTO.getSiteNo().length() > 0) {
			lQuery.append(" AND egs.empl_grp_site_id_no = ?");
			lParameters.add(lRewardCardFulfillmentSearchTO.getSiteNo());
			lTypes.add(Types.VARCHAR);
		}

		if (lRewardCardFulfillmentSearchTO.getContractNo() != null && lRewardCardFulfillmentSearchTO.getContractNo().length() > 0) {
			lQuery.append(" AND t.contract_no = ?");
			lParameters.add(lRewardCardFulfillmentSearchTO.getContractNo());
			lTypes.add(Types.VARCHAR);
		}

		if (lRewardCardFulfillmentSearchTO.getMemberNo() != null && lRewardCardFulfillmentSearchTO.getMemberNo().length() > 0) {
			lQuery.append(" AND pd.hp_mem_id = ?");
			lParameters.add(lRewardCardFulfillmentSearchTO.getMemberNo());
			lTypes.add(Types.VARCHAR);
		}

		if (lRewardCardFulfillmentSearchTO.getCachePersonID() != null && lRewardCardFulfillmentSearchTO.getCachePersonID().length() > 0) {
			lQuery.append(" AND pd.prsn_id = ?");
			lParameters.add(Integer.valueOf(lRewardCardFulfillmentSearchTO.getCachePersonID()));
			lTypes.add(Types.INTEGER);
		}

		if (lRewardCardFulfillmentSearchTO.getProgramStartDate() != null) {
			lQuery.append(" AND bp.eff_dt = ?");
			lParameters.add(lRewardCardFulfillmentSearchTO.getProgramStartDate());
			lTypes.add(Types.DATE);
		}

		//Reward Card ID of 0 indicates that no reward card search target was selected.
		if (lRewardCardFulfillmentSearchTO.getRewardCardID() != null && lRewardCardFulfillmentSearchTO.getRewardCardID() > 0) {
			lQuery.append(" AND rc.reward_card_id = ?");
			lParameters.add(lRewardCardFulfillmentSearchTO.getRewardCardID());
			lTypes.add(Types.INTEGER);
		}

		if ((lRewardCardFulfillmentSearchTO.getFulfillmentFromDate() != null)
				&& (lRewardCardFulfillmentSearchTO.getFulfillmentToDate() != null)) {
			lQuery.append(" AND trunc(t.insert_ts) >= ? AND trunc(t.insert_ts) <= ?");
			lParameters.add(lRewardCardFulfillmentSearchTO.getFulfillmentFromDate());
			lParameters.add(lRewardCardFulfillmentSearchTO.getFulfillmentToDate());
			lTypes.add(Types.DATE);
			lTypes.add(Types.DATE);
		} else if (lRewardCardFulfillmentSearchTO.getFulfillmentFromDate() != null) {
			lQuery.append(" AND trunc(t.insert_ts) = ?");
			lParameters.add(lRewardCardFulfillmentSearchTO.getFulfillmentFromDate());
			lTypes.add(Types.DATE);
		}

		Collection<RewardCardFulfillmentTrackingReportHist> lRewardCardFulfillmentTrackingReportsHist = new ArrayList<RewardCardFulfillmentTrackingReportHist>();

		//If attempting to search with manually entered transaction id, avoid performing search for reward card transaction sent via the Intelispend batch process using webservice.

		if (!searchOnManuallyEnterdTransaction) {
			// Convert the parameter arraylists to arrays.
			Object params[] = new Object[lParameters.size()];
			lParameters.toArray(params);

			int types[] = new int[lTypes.size()];
			for (int j = 0; j < lTypes.size(); j++) {
				types[j] = lTypes.get(j);
			}

			lRewardCardFulfillmentTrackingReportsHist = (ArrayList<RewardCardFulfillmentTrackingReportHist>) template.query(
					lQuery.toString(), params, types,
					new FulfillmentTrackingReportHistMapper());
		}

		Collection<RewardCardFulfillmentTrackingReportHist> lRewardCardFulfillmentTrackingReportsHistManual = this.getRewardCardFulfillmentTrackingReportHistSearchManual(lRewardCardFulfillmentSearchTO);
		lRewardCardFulfillmentTrackingReportsHist.addAll(lRewardCardFulfillmentTrackingReportsHistManual);

		return lRewardCardFulfillmentTrackingReportsHist;
	}

	@Override
	public Collection<RewardCardFulfillmentTrackingReportHist> getRewardCardFulfillmentTrackingReportHistSearchManual(RewardCardFulfillmentSearchTO lRewardCardFulfillmentSearchTO) throws DataAccessException {
		ArrayList<Object> lParameters = new ArrayList<>();
		ArrayList<Integer> lTypes = new ArrayList<>();
		StringBuffer lQuery = new StringBuffer();
		lQuery.append(selectRewardCardFulfillmentTrackingReportHistManual);
		JdbcTemplate template = getJdbcTemplate();

		boolean searchOnFulfillHistTransaction = false;

		if (lRewardCardFulfillmentSearchTO.getTransactionID() != null
				&& lRewardCardFulfillmentSearchTO.getTransactionID().length() > 0) {
			if (BPMAdminUtils.isValueInteger(lRewardCardFulfillmentSearchTO.getTransactionID())) {
				//flag prevents search to occur on manually entered reward orders since users intention
				//was to search on orders sent via the Intelispend batch process.
				searchOnFulfillHistTransaction = true;
			} else {
				lQuery.append(" AND t.external_txn_id = ?");
				lParameters.add(lRewardCardFulfillmentSearchTO.getTransactionID());
				lTypes.add(Types.VARCHAR);
			}
		}


		if (lRewardCardFulfillmentSearchTO.getGroupNo() != null && lRewardCardFulfillmentSearchTO.getGroupNo().length() > 0) {
			lQuery.append(" AND rsdr.reward_card_cstmr_id = ?");
			lParameters.add(lRewardCardFulfillmentSearchTO.getGroupNo());
			lTypes.add(Types.VARCHAR);
		}

		if (lRewardCardFulfillmentSearchTO.getMemberNo() != null && lRewardCardFulfillmentSearchTO.getMemberNo().length() > 0) {
			lQuery.append(" AND pd.hp_mem_id = ?");
			lParameters.add(lRewardCardFulfillmentSearchTO.getMemberNo());
			lTypes.add(Types.VARCHAR);
		}

		if (lRewardCardFulfillmentSearchTO.getCachePersonID() != null && lRewardCardFulfillmentSearchTO.getCachePersonID().length() > 0) {
			lQuery.append(" AND pd.prsn_id = ?");
			lParameters.add(Integer.valueOf(lRewardCardFulfillmentSearchTO.getCachePersonID()));
			lTypes.add(Types.INTEGER);
		}


		//Reward Card ID of 0 indicates that no reward card search target was selected.
		if (lRewardCardFulfillmentSearchTO.getRewardCardID() != null && lRewardCardFulfillmentSearchTO.getRewardCardID() > 0) {
			lQuery.append(" AND rc.reward_card_id = ?");
			lParameters.add(lRewardCardFulfillmentSearchTO.getRewardCardID());
			lTypes.add(Types.INTEGER);
		}

		if ((lRewardCardFulfillmentSearchTO.getFulfillmentFromDate() != null)
				&& (lRewardCardFulfillmentSearchTO.getFulfillmentToDate() != null)) {
			lQuery.append(" AND trunc(t.insert_ts) >= ? AND trunc(t.insert_ts) <= ?");
			lParameters.add(lRewardCardFulfillmentSearchTO.getFulfillmentFromDate());
			lParameters.add(lRewardCardFulfillmentSearchTO.getFulfillmentToDate());
			lTypes.add(Types.DATE);
			lTypes.add(Types.DATE);
		} else if (lRewardCardFulfillmentSearchTO.getFulfillmentFromDate() != null) {
			lQuery.append(" AND trunc(t.insert_ts) = ?");
			lParameters.add(lRewardCardFulfillmentSearchTO.getFulfillmentFromDate());
			lTypes.add(Types.DATE);
		}

		Collection<RewardCardFulfillmentTrackingReportHist> lRewardCardFulfillmentTrackingReportsHist = new ArrayList<RewardCardFulfillmentTrackingReportHist>();

		//Avoid performing search if user entered a fulfillment history transaction id to search on.
		if (!searchOnFulfillHistTransaction) {
			// Convert the parameter arraylists to arrays.
			Object params[] = new Object[lParameters.size()];
			lParameters.toArray(params);

			int types[] = new int[lTypes.size()];
			for (int j = 0; j < lTypes.size(); j++) {
				types[j] = lTypes.get(j).intValue();
			}

			lRewardCardFulfillmentTrackingReportsHist = (ArrayList<RewardCardFulfillmentTrackingReportHist>) template.query(
					lQuery.toString(), params, types,
					new FulfillmentTrackingReportHistManualMapper());
		}

		return lRewardCardFulfillmentTrackingReportsHist;
	}

	/*
	 * Get the latest to the oldest reward card statuses using reward fulfill status id.
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Override
	public Collection<RewardCardFulfillmentReportHistStatus> getRewardCardFulfillmentTrackingReportStatuses(Integer rewardFulfillHistID)
			throws DataAccessException {

		final ArrayList<RewardCardFulfillmentReportHistStatus> lRewardCardFulfillmentReportsHistStatus = new ArrayList<RewardCardFulfillmentReportHistStatus>();

		ArrayList<Object> lParameters = new ArrayList<Object>();
		ArrayList<Integer> lTypes = new ArrayList<Integer>();
		StringBuffer lQuery = new StringBuffer();
		lQuery.append(selectRewardCardFulfillmentTrackingReportStatus);
		JdbcTemplate template = getJdbcTemplate();


		lQuery.append(" WHERE rfths.reward_txn_hist_id = ?");
		lParameters.add(rewardFulfillHistID);
		lTypes.add(Types.INTEGER);

		lQuery.append(" group by rfths.reward_txn_hist_sts_id, rfths.reward_txn_hist_id, rfths.reward_card_sts_dt, rfths.reward_card_sts_id");
		lQuery.append(" order by last_run_dt desc ");

		// Convert the parameter arraylists to arrays.
		Object params[] = new Object[lParameters.size()];
		lParameters.toArray(params);

		int types[] = new int[lTypes.size()];
		for(int j = 0; j < lTypes.size(); j++)
		{
			types[j] = ((Integer)lTypes.get(j)).intValue();
		}

		template.query(lQuery.toString(), params, types,
				new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException
					{
						RewardCardFulfillmentReportHistStatus lRewardCardFulfillmentReportHistStatus = new RewardCardFulfillmentReportHistStatus();
						lRewardCardFulfillmentReportHistStatus.setRewardTransHistID(rs.getInt("reward_txn_hist_id"));
						lRewardCardFulfillmentReportHistStatus.setRewardStatus(rs.getString("status"));
						lRewardCardFulfillmentReportHistStatus.setRewardStatusDate(rs.getDate("reward_card_sts_dt"));
						lRewardCardFulfillmentReportHistStatus.setLastRunDate(new java.sql.Date(rs.getTimestamp("last_run_dt").getTime()));


						lRewardCardFulfillmentReportsHistStatus.add(lRewardCardFulfillmentReportHistStatus);

					}
				});




		return lRewardCardFulfillmentReportsHistStatus;
	}

	//Produces warnings during compile time to quickly identify typos or API changes
	@Override
	public RewardCardFulfillmentTrackingReportHist getRewardCardFulfillmentTrackingReportHistManualDetail(Integer rewardFulfillHistID)
			throws DataAccessException {

		ArrayList<RewardCardFulfillmentTrackingReportHist> lRewardCardFulfillmentTrackingReportsHist = new ArrayList<RewardCardFulfillmentTrackingReportHist>();
		ArrayList<Object> lParameters = new ArrayList<Object>();
		ArrayList<Integer> lTypes = new ArrayList<Integer>();
		StringBuffer lQuery = new StringBuffer();
		lQuery.append(selectRewardCardFulfillmentTrackingReportHistManual);
		JdbcTemplate template = getJdbcTemplate();

		lQuery.append("AND t.reward_txn_hist_id = ?");
		lParameters.add(rewardFulfillHistID);
		lTypes.add(new Integer(Types.INTEGER));


		// Convert the parameter arraylists to arrays.
		Object params[] = new Object[lParameters.size()];
		lParameters.toArray(params);

		int types[] = new int[lTypes.size()];
		for(int j = 0; j < lTypes.size(); j++)
		{
			types[j] = ((Integer)lTypes.get(j)).intValue();
		}

		lRewardCardFulfillmentTrackingReportsHist = (ArrayList<RewardCardFulfillmentTrackingReportHist>) template.query(
				lQuery.toString(), params, types,
				new FulfillmentTrackingReportHistManualMapper());

		RewardCardFulfillmentTrackingReportHist lRewardCardFulfillmentTrackingReportHist = lRewardCardFulfillmentTrackingReportsHist.get(0);


		return lRewardCardFulfillmentTrackingReportHist;
	}


	//Produces warnings during compile time to quickly identify typos or API changes
	@Override
	public RewardCardFulfillmentTrackingReportHist getRewardCardFulfillmentTrackingReportHistDetail(Integer rewardFulfillHistID)
			throws DataAccessException {

		ArrayList<RewardCardFulfillmentTrackingReportHist> lRewardCardFulfillmentTrackingReportsHist = new ArrayList<RewardCardFulfillmentTrackingReportHist>();
		ArrayList<Object> lParameters = new ArrayList<Object>();
		ArrayList<Integer> lTypes = new ArrayList<Integer>();
		StringBuffer lQuery = new StringBuffer();
		lQuery.append(selectRewardCardFulfillmentTrackingReportHist);
		JdbcTemplate template = getJdbcTemplate();

		lQuery.append("AND t.reward_txn_hist_id = ?");
		lParameters.add(rewardFulfillHistID);
		lTypes.add(new Integer(Types.INTEGER));


		// Convert the parameter arraylists to arrays.
		Object params[] = new Object[lParameters.size()];
		lParameters.toArray(params);

		int types[] = new int[lTypes.size()];
		for(int j = 0; j < lTypes.size(); j++)
		{
			types[j] = ((Integer)lTypes.get(j)).intValue();
		}

		lRewardCardFulfillmentTrackingReportsHist = (ArrayList<RewardCardFulfillmentTrackingReportHist>) template.query(
				lQuery.toString(), params, types,
				new FulfillmentTrackingReportHistMapper());

		RewardCardFulfillmentTrackingReportHist lRewardCardFulfillmentTrackingReportHist = lRewardCardFulfillmentTrackingReportsHist.get(0);


		return lRewardCardFulfillmentTrackingReportHist;
	}

	/**
	 * Retrieve address information required by vendor Intelispend using programID, personDemographicsID, and incentiveOptionID.
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Override
	public RewardCardAddress getRewardCardAddress(Integer programID, Integer personDemographicsID, Integer incentiveOptionID) throws DataAccessException
	{
		RewardCardAddress lRewardCardAddress = new RewardCardAddress();

		StringBuffer lQuery = new StringBuffer();
		lQuery.append(selectRewardCardAddress);
		lQuery.append("where t.biz_pgm_id = ?");
		lQuery.append("AND t.prsn_dmgrphcs_id = ?");
		lQuery.append("AND t.incntv_optn_id = ? ");
		lQuery.append(groupByRewardCardAddress);


		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] { programID, personDemographicsID, incentiveOptionID};
		int types[] = new int[] { Types.INTEGER, Types.INTEGER, Types.INTEGER};

		ArrayList<RewardCardAddress> lRewardCardAddresses = (ArrayList<RewardCardAddress>) template.query(lQuery.toString(),
				params, types, new RewardCardAddressRowMapper());

		if (lRewardCardAddresses.size() > 0) {
			lRewardCardAddress = lRewardCardAddresses.get(0);
		}

		return lRewardCardAddress;
	}


	/**
	 * Retrieve address information required by vendor Intelispend.
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Override
	public RewardCardAddress getRewardCardAddress(Integer rewardTransHistID, Integer programID, Integer personDemographicsID, Integer incentiveOptionID) throws DataAccessException
	{

		RewardCardAddress lRewardCardAddress = new RewardCardAddress();

		StringBuffer lQuery = new StringBuffer();
		lQuery.append(selectRewardCardAddress);
		lQuery.append("where t.reward_txn_hist_id = ? ");
		lQuery.append(groupByRewardCardAddress);


		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] { rewardTransHistID};
		int types[] = new int[] { Types.INTEGER};

		ArrayList<RewardCardAddress> lRewardCardAddresses = (ArrayList<RewardCardAddress>) template.query(lQuery.toString(),
				params, types, new RewardCardAddressRowMapper());


		//if no address returned based on using the trans hist id in the lookup,
		// try using program ID person demographic id and incentive option
		if (lRewardCardAddresses.isEmpty()) {
			lRewardCardAddress = getRewardCardAddress(programID, personDemographicsID, incentiveOptionID);
		} else {
			lRewardCardAddress = lRewardCardAddresses.get(0);
		}

		return lRewardCardAddress;
	}


	@Override
	public RewardCardFulfillmentReportHistStatus getRewardCardFulfillmentTrackingReportStatus(RewardCardFulfillmentSearchTO lRewardCardFulfillmentSearchTO, RewardCardFulfillmentRecycleSearchTO lRewardCardFulfillmentRecycleSearchTO) throws DataAccessException {

		final ArrayList<RewardCardFulfillmentReportHistStatus> lRewardCardFulfillmentReportsHistStatus = new ArrayList<>();

		RewardCardFulfillmentReportHistStatus lRewardCardFulfillmentReportHistStatus = new RewardCardFulfillmentReportHistStatus();

		ArrayList<Object> lParameters = new ArrayList<>();
		ArrayList<Integer> lTypes = new ArrayList<>();
		StringBuffer lQuery = new StringBuffer();
		lQuery.append(selectRewardCardFulfillmentTrackingReportStatus);
		JdbcTemplate template = getJdbcTemplate();

		//use when reading the reward card status table

		if (lRewardCardFulfillmentSearchTO != null) {
			lQuery.append(" WHERE rfths.reward_txn_hist_id = ?");
			lParameters.add(lRewardCardFulfillmentSearchTO.getRewardFulfillHistID());
			lTypes.add(Types.INTEGER);

		} else if (lRewardCardFulfillmentRecycleSearchTO != null) {
			lQuery.append(" WHERE rfths.reward_txn_hist_id = ?");
			lParameters.add(lRewardCardFulfillmentRecycleSearchTO.getRewardFulfillHistID());
			lTypes.add(Types.INTEGER);

			if (lRewardCardFulfillmentRecycleSearchTO.getRecycleStatusID() != null) {
				lQuery.append(" AND rfths.reward_card_sts_id = ?");
				lParameters.add(lRewardCardFulfillmentRecycleSearchTO.getRecycleStatusID());
				lTypes.add(Types.INTEGER);
			}
		}

		lQuery.append(" group by rfths.reward_card_sts_dt, rfths.reward_txn_hist_id, rfths.reward_card_sts_id");
		lQuery.append(" order by last_run_dt desc");


		// Convert the parameter arraylists to arrays.
		Object params[] = new Object[lParameters.size()];
		lParameters.toArray(params);

		int types[] = new int[lTypes.size()];
		for (int j = 0; j < lTypes.size(); j++) {
			types[j] = lTypes.get(j).intValue();
		}

		template.query(lQuery.toString(), params, types,
				new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						RewardCardFulfillmentReportHistStatus lRewardCardFulfillmentReportHistStatus = new RewardCardFulfillmentReportHistStatus();
						lRewardCardFulfillmentReportHistStatus.setRewardTransHistID(rs.getInt("reward_txn_hist_id"));
						lRewardCardFulfillmentReportHistStatus.setRewardStatus(rs.getString("status"));
						lRewardCardFulfillmentReportHistStatus.setRewardStatusDate(rs.getDate("reward_card_sts_dt"));
						lRewardCardFulfillmentReportHistStatus.setLastRunDate(new java.sql.Date(rs.getTimestamp("last_run_dt").getTime()));


						lRewardCardFulfillmentReportsHistStatus.add(lRewardCardFulfillmentReportHistStatus);

					}
				});


		if (!lRewardCardFulfillmentReportsHistStatus.isEmpty()) {
			lRewardCardFulfillmentReportHistStatus = lRewardCardFulfillmentReportsHistStatus.get(0);
		} else {
			lRewardCardFulfillmentReportHistStatus.setRewardStatus(BPMAdminConstants.REWARD_STATUS_NOT_FOUND);

		}

		return lRewardCardFulfillmentReportHistStatus;
	}

	@Override
	public Collection<RewardCardFee> getRewardCardFees() throws DataAccessException {
		final ArrayList<RewardCardFee> lRewardCardFees;

		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] { };
		int types[] = new int[] { };
		StringBuffer lQuery = new StringBuffer();



		lRewardCardFees = (ArrayList<RewardCardFee>) template.query(
				selectRewardCardFees, params, types,
				new RewardCardFeeMapper());

		return lRewardCardFees;
	}

	@Override
	public Collection<RewardEmbossedLine> getRewardCardEmbossedLines() throws DataAccessException {
		final ArrayList<RewardEmbossedLine> lRewardCardEmbossedLines;

		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] {  };
		int types[] = new int[] { };


		lRewardCardEmbossedLines = (ArrayList<RewardEmbossedLine>) template.query(
				selectRewardCardEmbossedLines, params, types,
				new RewardEmbossedLineMapper());

		return lRewardCardEmbossedLines;
	}

	@Override
	public Collection<RewardCarrierMessage> getRewardCarrierMessages() throws DataAccessException {
		final ArrayList<RewardCarrierMessage> lRewardCarrierMessages;

		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] {  };
		int types[] = new int[] { };


		lRewardCarrierMessages = (ArrayList<RewardCarrierMessage>) template.query(
				selectRewardCarrierMessages, params, types,
				new RewardCarrierMessageMapper());

		return lRewardCarrierMessages;
	}

	@Override
	public Collection<RewardTransactionMessage> getRewardTransactionMessages() throws DataAccessException {
		final ArrayList<RewardTransactionMessage> lRewardTransactionMessages;

		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] {  };
		int types[] = new int[] { };


		lRewardTransactionMessages = (ArrayList<RewardTransactionMessage>) template.query(
				selectRewardTransactionMessages, params, types,
				new RewardTransactionMessageMapper());

		return lRewardTransactionMessages;
	}

	@Override
	public Collection<RewardCardClientData> getRewardCardClientInfo() throws DataAccessException {
		final ArrayList<RewardCardClientData> lRewardCardClientDataList = new ArrayList<RewardCardClientData>();

		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] {  };
		int types[] = new int[] { };

		template.query(selectRewardCardClientInfo, params, types, new RowCallbackHandler() {
			public void processRow(ResultSet rs) throws SQLException {
				RewardCardClientData lRewardCardClientData = new RewardCardClientData();

				lRewardCardClientData.setRewardCardClientContactID(rs.getInt("REWARD_CARD_CLIENT_CNTCT_ID"));
				lRewardCardClientData.setRewardCardClientDataName(rs.getString("REWARD_CARD_CLIENT_INFO_NM"));
				lRewardCardClientData.setCompanyName(rs.getString("CLIENT_CMPNY_NM"));
				lRewardCardClientData.setContactName(rs.getString("CLIENT_CNTCT_NM"));

				lRewardCardClientData.setAddressLine1(rs.getString("CLIENT_ADDR_LINE_1"));
				lRewardCardClientData.setAddressLine2(rs.getString("CLIENT_ADDR_LINE_2"));
				lRewardCardClientData.setCity(rs.getString("CLIENT_CITY"));
				lRewardCardClientData.setState(rs.getString("CLIENT_STATE_CD"));
				lRewardCardClientData.setZip(rs.getString("CLIENT_POSTAL_CODE"));
				lRewardCardClientData.setExtension(rs.getString("CLIENT_POSTAL_CD_EXT"));
				lRewardCardClientData.setTaxID(rs.getString("CLIENT_TAX_ID"));

				lRewardCardClientData.setEffectiveDate(rs.getDate("CLIENT_CNTCT_EFF_DT"));
				lRewardCardClientData.setEndDate(rs.getDate("CLIENT_CNTXT_END_DT"));
				lRewardCardClientData.setUsed(rs.getString("used_flg"));

				lRewardCardClientDataList.add(lRewardCardClientData);
			}
		});

		return lRewardCardClientDataList;
	}
	/**
	 *
	 * @param pIncentiveOptionRewardCard
	 * @param pModifyUserID
	 * @return
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Override
	public int updateIncentiveOptionRewardCard(IncentiveOptionRewardCard pIncentiveOptionRewardCard, String pModifyUserID)
			throws BPMException, DataAccessException
	{
		JdbcTemplate template = getJdbcTemplate();
		int rowInserted = 0;


		if(pIncentiveOptionRewardCard.getIncentiveOptionRewardCardID().intValue() == 0)
		{
			rowInserted = this.insertIncentiveOptionRewardCard(pIncentiveOptionRewardCard, pModifyUserID);
		}
		else
		{
			Object params[] = new Object[] {
					pIncentiveOptionRewardCard.getIncentiveOptionRewardCardName()
					, pIncentiveOptionRewardCard.getIncentiveOptionRewardCardDesc()
					, pIncentiveOptionRewardCard.getRewardCardID()
					, pIncentiveOptionRewardCard.getRewardCardFeeID()
					, pIncentiveOptionRewardCard.getRewardEmbossedLineID()
					, pIncentiveOptionRewardCard.getRewardCarrierMessageID()
					, pIncentiveOptionRewardCard.getRewardTransactionMessageID()
					, pIncentiveOptionRewardCard.getEffectiveDate()
					, pIncentiveOptionRewardCard.getEndDate()
					, pIncentiveOptionRewardCard.getRewardCardClientContactID()
					, pModifyUserID
					, pIncentiveOptionRewardCard.getIncentiveOptionRewardCardID()
			};

			int types[] = new int[] {
					Types.VARCHAR, Types.VARCHAR
					, Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.INTEGER
					, Types.DATE, Types.DATE
					, Types.INTEGER
					, Types.VARCHAR
					, Types.INTEGER};

			rowInserted = template.update(updateIncentiveOptionRewardCard, params, types);
		}

		return rowInserted;
	}
	/**
	 *
	 * @param pIncentiveOptionRewardCard
	 * @param pModifyUserID
	 * @return
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	public int insertIncentiveOptionRewardCard(IncentiveOptionRewardCard pIncentiveOptionRewardCard, String pModifyUserID)
			throws BPMException, DataAccessException
	{
		JdbcTemplate template = getJdbcTemplate();
		int rowInserted = 0;

		Long lIncentiveOptionRewardCardID = incentiveOptionRewardCardIDIncrementer.nextLongValue();

		Object params[] = new Object[] {lIncentiveOptionRewardCardID
				, pIncentiveOptionRewardCard.getIncentiveOptionRewardCardName()
				, pIncentiveOptionRewardCard.getIncentiveOptionRewardCardDesc()
				, pIncentiveOptionRewardCard.getRewardCardID()
				, pIncentiveOptionRewardCard.getRewardCardFeeID()
				, pIncentiveOptionRewardCard.getRewardEmbossedLineID()
				, pIncentiveOptionRewardCard.getRewardCarrierMessageID()
				, pIncentiveOptionRewardCard.getRewardTransactionMessageID()
				, pIncentiveOptionRewardCard.getEffectiveDate()
				, pIncentiveOptionRewardCard.getEndDate()
				, pIncentiveOptionRewardCard.getRewardCardClientContactID()
				, pModifyUserID, pModifyUserID
		};

		int types[] = new int[] {Types.INTEGER
				, Types.VARCHAR, Types.VARCHAR
				, Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.INTEGER
				, Types.DATE, Types.DATE
				, Types.INTEGER
				, Types.VARCHAR, Types.VARCHAR};

		rowInserted = template.update(insertIncentiveOptionRewardCard, params, types);

		pIncentiveOptionRewardCard.setRewardTransactionMessageID(Integer.valueOf(lIncentiveOptionRewardCardID.intValue()));

		return rowInserted;
	}

	@Override
	public int deleteIncentiveOptionRewardCard(Integer lIncentiveOptionRewardCardID)
			throws BPMException, DataAccessException
	{
		JdbcTemplate template = getJdbcTemplate();
		int rowInserted = 0;

		Object params[] = new Object[] { lIncentiveOptionRewardCardID };
		int types[] = new int[] { Types.INTEGER };

		rowInserted = template.update(deleteIncentiveOptionRewardCard, params, types);

		return rowInserted;
	}

	private static final class FulfillmentTrackingReportHistMapper implements RowMapper {
		public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
			RewardCardFulfillmentTrackingReportHist lRewardCardFulfillmentTrackingReportHist = new RewardCardFulfillmentTrackingReportHist();
			lRewardCardFulfillmentTrackingReportHist.setRewardFulfillHistID(rs.getInt("reward_txn_hist_id"));
			lRewardCardFulfillmentTrackingReportHist.setProgramID(rs.getInt("biz_pgm_id"));
			lRewardCardFulfillmentTrackingReportHist.setGroupID(rs.getInt("grp_id"));
			lRewardCardFulfillmentTrackingReportHist.setGroupNo(rs.getString("empl_grp_no"));
			lRewardCardFulfillmentTrackingReportHist.setSiteNo(rs.getString("empl_grp_site_id_no"));
			lRewardCardFulfillmentTrackingReportHist.setEmployerGroupName(rs.getString("empl_grp_nm"));
			lRewardCardFulfillmentTrackingReportHist.setEmployerSiteName(rs.getString("empl_grp_site_nm"));
			lRewardCardFulfillmentTrackingReportHist.setContractNo(rs.getInt("contract_no"));
			lRewardCardFulfillmentTrackingReportHist.setPersonDemographicsID(rs.getInt("prsn_dmgrphcs_id"));
			lRewardCardFulfillmentTrackingReportHist.setPersonID(rs.getInt("prsn_id"));
			lRewardCardFulfillmentTrackingReportHist.setMemberNo(rs.getString("hp_mem_id"));
			lRewardCardFulfillmentTrackingReportHist.setFirstName(rs.getString("first_nm"));
			lRewardCardFulfillmentTrackingReportHist.setLastName(rs.getString("last_nm"));
			lRewardCardFulfillmentTrackingReportHist.setMiddleName(rs.getString("middle_nm"));
			lRewardCardFulfillmentTrackingReportHist.setDateOfBirth(rs.getDate("dob_dt"));
			lRewardCardFulfillmentTrackingReportHist.setContributionStartDate(rs.getDate("contribution_start_dt"));
			lRewardCardFulfillmentTrackingReportHist.setContributionEndDate(rs.getDate("contribution_end_dt"));
			lRewardCardFulfillmentTrackingReportHist.setContributionAmount(rs.getInt("reward_amt"));
			lRewardCardFulfillmentTrackingReportHist.setContributionTypeCodeId(rs.getInt("tier_contrib_id"));
			lRewardCardFulfillmentTrackingReportHist.setContributionDate(rs.getDate("reward_dt"));
			lRewardCardFulfillmentTrackingReportHist.setFulfillmentDate(rs.getDate("insert_ts"));
			lRewardCardFulfillmentTrackingReportHist.setActivityID(rs.getInt("actv_id"));
			lRewardCardFulfillmentTrackingReportHist.setActivityName(rs.getString("activity_name"));
			lRewardCardFulfillmentTrackingReportHist.setSourceActivityID(rs.getString("srce_actv_id"));
			lRewardCardFulfillmentTrackingReportHist.setIncentiveReportName(rs.getString("incntv_rpt_name"));
			lRewardCardFulfillmentTrackingReportHist.setIncentiveOptionID(rs.getInt("incntv_optn_id"));
			lRewardCardFulfillmentTrackingReportHist.setExternalTransactionID(rs.getString("external_txn_id"));
			lRewardCardFulfillmentTrackingReportHist.setOrderNumber(rs.getString("order_id"));
			lRewardCardFulfillmentTrackingReportHist.setRewardCardNoMasked(rs.getString("reward_card_no_mskd"));
			lRewardCardFulfillmentTrackingReportHist.setVendorFee(rs.getInt("reward_card_vendor_fee"));

			lRewardCardFulfillmentTrackingReportHist.setQuoteNo(rs.getString("quote_no"));
			lRewardCardFulfillmentTrackingReportHist.setQuoteDesc(rs.getString("quote_desc"));
			lRewardCardFulfillmentTrackingReportHist.setFeeAmount(BPMAdminUtils.convertDoubleToDecimalFormattedString(Double.parseDouble(rs.getString("card_fee_amt"))));
			lRewardCardFulfillmentTrackingReportHist.setFeeDesc(rs.getString("card_fee_desc"));
			lRewardCardFulfillmentTrackingReportHist.setCarrierMessageName(rs.getString("reward_carrier_msg_nm"));
			lRewardCardFulfillmentTrackingReportHist.setCarrierMessageDesc(rs.getString("reward_carrier_msg_desc"));
			lRewardCardFulfillmentTrackingReportHist.setCarrierMessageDesc2(rs.getString("reward_carrier_msg_desc_2"));
			lRewardCardFulfillmentTrackingReportHist.setEmbossName(rs.getString("emboss_name"));
			lRewardCardFulfillmentTrackingReportHist.setEmbossedDesc(rs.getString("embossed_desc"));
			lRewardCardFulfillmentTrackingReportHist.setTransactionMessageName(rs.getString("reward_trnsctn_msg_nm"));
			lRewardCardFulfillmentTrackingReportHist.setTransactionMessageDesc(rs.getString("reward_trnsctn_msg_desc"));

			return lRewardCardFulfillmentTrackingReportHist;
		}
	}

	private static final class FulfillmentTrackingReportHistManualMapper implements RowMapper {
		public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
			RewardCardFulfillmentTrackingReportHist lRewardCardFulfillmentTrackingReportHist = new RewardCardFulfillmentTrackingReportHist();
			RewardCardAddress lRewardCardAddress = new RewardCardAddress();

			lRewardCardFulfillmentTrackingReportHist.setRewardFulfillHistID(rs.getInt("reward_txn_hist_id"));
			lRewardCardFulfillmentTrackingReportHist.setGroupNo(rs.getString("empl_grp_no"));
			lRewardCardFulfillmentTrackingReportHist.setSiteNo(BPMAdminConstants.REWARD_FULFILL_MANUAL);
			lRewardCardFulfillmentTrackingReportHist.setEmployerGroupName(rs.getString("empl_grp_nm"));
			lRewardCardFulfillmentTrackingReportHist.setEmployerSiteName(BPMAdminConstants.REWARD_FULFILL_MANUAL);
			lRewardCardFulfillmentTrackingReportHist.setContractNo(null);
			lRewardCardFulfillmentTrackingReportHist.setPersonID(rs.getInt("prsn_id"));
			lRewardCardFulfillmentTrackingReportHist.setMemberNo(rs.getString("hp_mem_id"));
			lRewardCardFulfillmentTrackingReportHist.setFirstName(rs.getString("first_nm"));
			lRewardCardFulfillmentTrackingReportHist.setLastName(rs.getString("last_nm"));
			lRewardCardFulfillmentTrackingReportHist.setMiddleName(rs.getString("middle_nm"));
			lRewardCardFulfillmentTrackingReportHist.setDateOfBirth(rs.getDate("dob_dt"));
			lRewardCardFulfillmentTrackingReportHist.setContributionAmount(rs.getInt("reward_amt"));
			lRewardCardFulfillmentTrackingReportHist.setContributionDate(rs.getDate("reward_dt"));
			lRewardCardFulfillmentTrackingReportHist.setFulfillmentDate(rs.getDate("insert_ts"));
			lRewardCardFulfillmentTrackingReportHist.setActivityName(BPMAdminConstants.REWARD_FULFILL_MANUAL);
			lRewardCardFulfillmentTrackingReportHist.setExternalTransactionID(rs.getString("external_txn_id"));
			lRewardCardFulfillmentTrackingReportHist.setOrderNumber(rs.getString("order_id"));
			lRewardCardFulfillmentTrackingReportHist.setRewardCardNoMasked(rs.getString("reward_card_no_mskd"));
			lRewardCardFulfillmentTrackingReportHist.setVendorFee(rs.getInt("reward_card_vendor_fee"));
			lRewardCardFulfillmentTrackingReportHist.setQuoteNo(rs.getString("quote_no"));
			lRewardCardFulfillmentTrackingReportHist.setQuoteDesc(rs.getString("quote_desc"));
			lRewardCardFulfillmentTrackingReportHist.setFeeDesc(BPMAdminConstants.REWARD_FULFILL_MANUAL);
			lRewardCardFulfillmentTrackingReportHist.setCarrierMessageName(BPMAdminConstants.REWARD_FULFILL_MANUAL);
			lRewardCardFulfillmentTrackingReportHist.setCarrierMessageDesc(BPMAdminConstants.REWARD_FULFILL_MANUAL);
			lRewardCardFulfillmentTrackingReportHist.setCarrierMessageDesc2(BPMAdminConstants.REWARD_FULFILL_MANUAL);
			lRewardCardFulfillmentTrackingReportHist.setEmbossName(BPMAdminConstants.REWARD_FULFILL_MANUAL);
			lRewardCardFulfillmentTrackingReportHist.setEmbossedDesc(BPMAdminConstants.REWARD_FULFILL_MANUAL);
			lRewardCardFulfillmentTrackingReportHist.setTransactionMessageName(BPMAdminConstants.REWARD_FULFILL_MANUAL);
			lRewardCardFulfillmentTrackingReportHist.setTransactionMessageDesc(BPMAdminConstants.REWARD_FULFILL_MANUAL);

			lRewardCardAddress.setAddressLine1(rs.getString("reward_card_addr_line_1"));
			lRewardCardAddress.setAddressLine2(rs.getString("reward_card_addr_line_2"));
			lRewardCardAddress.setCity(rs.getString("reward_card_city"));
			lRewardCardAddress.setStateCode(rs.getString("reward_card_st"));
			lRewardCardAddress.setPostalCode(rs.getString("reward_card_pstl_cd"));

			lRewardCardFulfillmentTrackingReportHist.setRewardCardAddress(lRewardCardAddress);

			return lRewardCardFulfillmentTrackingReportHist;
		}
	}

private static final class RewardCardAddressRowMapper implements RowMapper {
	public Object mapRow(ResultSet rs, int rowNum) throws SQLException {

		RewardCardAddress lRewardCardAddress = new RewardCardAddress();

		lRewardCardAddress.setRewardTransHistID(rs.getInt("reward_txn_hist_id"));
		lRewardCardAddress.setFirstName(rs.getString("first_nm"));
		lRewardCardAddress.setMiddleInit(rs.getString("middle_initial"));
		lRewardCardAddress.setLastName(rs.getString("last_nm"));
		lRewardCardAddress.setAddressLine1(rs.getString("addr_line_1"));
		lRewardCardAddress.setAddressLine2(rs.getString("addr_line_2"));
		lRewardCardAddress.setCity(rs.getString("city"));
		lRewardCardAddress.setStateCode(rs.getString("state_cd"));
		lRewardCardAddress.setPostalCode(rs.getString("postal_code"));
		lRewardCardAddress.setPostalCodeExt(rs.getString("postal_code_ext"));
		lRewardCardAddress.setCountryCode(rs.getString("country_cd"));
		lRewardCardAddress.setAddressStatusTypeId(rs.getInt("address_sts_tp_id"));
		lRewardCardAddress.setAddressStatusDate(rs.getDate("address_sts_dt"));
		lRewardCardAddress.setProgramID(rs.getInt("biz_pgm_id"));
		lRewardCardAddress.setPersonDemographicsID(rs.getInt("prsn_dmgrphcs_id"));
		lRewardCardAddress.setIncentiveOptionID(rs.getInt("incntv_optn_id"));

		return lRewardCardAddress;
	}
}


private static final class RewardCardFeeMapper implements RowMapper {
		public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
			RewardCardFee lRewardCardFee = new RewardCardFee();

			lRewardCardFee.setRewardCardFeeID(rs.getInt("reward_card_fee_id"));
			lRewardCardFee.setVendorCodeID(rs.getInt("vendor_id"));
			lRewardCardFee.setVendorName(rs.getString("vendor_name"));
			lRewardCardFee.setCardFeeAmount(rs.getDouble("CARD_FEE_AMT"));
			lRewardCardFee.setCardFeeName(rs.getString("REWARD_CARD_FEE_NM"));
			lRewardCardFee.setCardFeeDescription(rs.getString("CARD_FEE_DESC"));
			lRewardCardFee.setEffectiveDate(rs.getDate("eff_dt"));
			lRewardCardFee.setEndDate(rs.getDate("end_dt"));


			return lRewardCardFee;
		}
	}

	private static final class RewardEmbossedLineMapper implements RowMapper {
		public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
			RewardEmbossedLine lRewardEmbossedLine = new RewardEmbossedLine();

			lRewardEmbossedLine.setRewardEmbossedLineID(rs.getInt("reward_embossed_line_id"));
			lRewardEmbossedLine.setEmbossName(rs.getString("emboss_name"));
			lRewardEmbossedLine.setEmbossedDescription(rs.getString("embossed_desc"));
			lRewardEmbossedLine.setEmbossedTypeCodeID(rs.getInt("embossed_tp_cd_id"));
			lRewardEmbossedLine.setEmbossedTypeCode(rs.getString("embossedTypCode"));
			lRewardEmbossedLine.setEffectiveDate(rs.getDate("eff_dt"));
			lRewardEmbossedLine.setEndDate(rs.getDate("end_dt"));


			return lRewardEmbossedLine;
		}
	}

	private static final class RewardCarrierMessageMapper implements RowMapper {
		public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
			RewardCarrierMessage lRewardCarrierMessage = new RewardCarrierMessage();

			lRewardCarrierMessage.setRewardCarrierMessageID(rs.getInt("reward_carrier_msg_id"));
			lRewardCarrierMessage.setRewardCarrierMessageName(rs.getString("reward_carrier_msg_nm"));
			lRewardCarrierMessage.setRewardCarrierMessageDescription(rs.getString("reward_carrier_msg_desc"));
			lRewardCarrierMessage.setRewardCarrierMessageDescriptionContinued(rs.getString("reward_carrier_msg_desc_2"));
			lRewardCarrierMessage.setEffectiveDate(rs.getDate("eff_dt"));
			lRewardCarrierMessage.setEndDate(rs.getDate("end_dt"));


			return lRewardCarrierMessage;
		}
	}
	private static final class RewardTransactionMessageMapper implements RowMapper {
		public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
			RewardTransactionMessage lRewardTransactionMessage = new RewardTransactionMessage();

			lRewardTransactionMessage.setRewardTransactionMessageID(rs.getInt("reward_trnsctn_msg_id"));
			lRewardTransactionMessage.setRewardTransactionMessageName(rs.getString("reward_trnsctn_msg_nm"));
			lRewardTransactionMessage.setRewardTransactionMessageDescription(rs.getString("reward_trnsctn_msg_desc"));
			lRewardTransactionMessage.setEffectiveDate(rs.getDate("eff_dt"));
			lRewardTransactionMessage.setEndDate(rs.getDate("end_dt"));


			return lRewardTransactionMessage;
		}
	}
}