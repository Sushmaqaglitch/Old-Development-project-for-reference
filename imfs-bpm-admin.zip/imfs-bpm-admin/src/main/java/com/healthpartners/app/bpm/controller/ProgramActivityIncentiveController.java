package com.healthpartners.app.bpm.controller;

import com.healthpartners.app.bpm.dto.*;
import com.healthpartners.app.bpm.exception.BPMException;
import com.healthpartners.app.bpm.form.EditProgramForm;
import com.healthpartners.app.bpm.form.SaveProgramActivityIncentiveForm;
import com.healthpartners.app.bpm.form.SaveProgramActivitySiteForm;
import com.healthpartners.app.bpm.iface.BusinessProgramService;
import com.healthpartners.app.bpm.iface.MemberService;
import com.healthpartners.service.bpm.common.BPMConstants;
import jakarta.servlet.http.HttpServletRequest;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.view.RedirectView;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;

import static org.apache.commons.lang.exception.ExceptionUtils.getStackTrace;

@Controller
public class ProgramActivityIncentiveController extends BaseController implements Validator {

    public static final String ACTION_REMOVE_RELATIONSHIP = "removeRelationship";
    private static final String ACTION_SAVE = "save";
    private static final String ACTION_SAVE_TO_ALL_SITES = "saveToAllSites";
    private static final String ACTION_SAVE_TO_SELECTED = "saveToSelected";
    private static final String ACTION_ADD_ACTIVTY = "addActivity";
    private static final String ACTION_REMOVE_ACTIVTY = "removeActivity";
    private static final String ACTION_REMOVE_ACTIVTY_TYPE = "removeActivityType";
    private static final String ACTION_ADD_REQUIREMENT = "addRequirement";
    private static final String ACTION_REMOVE_REQUIREMENT = "removeRequirement";
    private static final String ACTION_ADD_RELATIONSHIP = "addRelationship";
    protected final Log logger = LogFactory.getLog(getClass());
    private final BusinessProgramService businessProgramService;
    private final MemberService memberService;

    public ProgramActivityIncentiveController(BusinessProgramService businessProgramService, MemberService memberService) {
        this.businessProgramService = businessProgramService;
        this.memberService = memberService;
    }

    @GetMapping("/editProgramActivityIncentive")
    public String loadProgramActivityIncentive(ModelMap modelMap, @RequestParam(name = "actionType") String actionType, @RequestParam(name = "programID") Integer programID, @RequestParam(name = "incentiveOptionID") Integer incentiveOptionID) throws BPMException {
        SaveProgramActivityIncentiveForm form = new SaveProgramActivityIncentiveForm();
        form.setActionType(actionType);
        form.setProgramID(programID);
        form.setIncentiveOptionID(incentiveOptionID);

        loadInitial(form, modelMap);

        return "editProgramActivityIncentive";
    }

    @PostMapping(value = "/saveProgramActivityIncentive", params = "cancel")
    public RedirectView submitCancelEditProgramActivityIncentive(@ModelAttribute("saveProgramActivityIncentiveForm") SaveProgramActivityIncentiveForm form, RedirectAttributes ra) {
        try {
            EditProgramForm editProgramForm = new EditProgramForm();
            editProgramForm.setGroupNo(getUserSession().getGroupNo());
            editProgramForm.setProgramID(form.getProgramID());
            ra.addFlashAttribute("editProgramForm", editProgramForm);
            ra.addFlashAttribute("groupNumber", getUserSession().getGroupNo());
            ra.addFlashAttribute("actionType", "editIncentives");
        } catch (Exception e) {
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
        }

        String url = "editProgram";
        return new RedirectView(url);
    }

    @PostMapping(value = "/saveProgramActivityIncentive")
    public String submitProgramActivityIncentive(@ModelAttribute("saveProgramActivityIncentiveForm") SaveProgramActivityIncentiveForm form, ModelMap modelMap, BindingResult result, HttpServletRequest request, RedirectAttributes ra) {
        try {
            if (ACTION_ADD_REQUIREMENT.equals(form.getActionType())) {
                addRequirement(form, modelMap);
                return "editProgramActivityIncentive";
            } else if (ACTION_REMOVE_REQUIREMENT.equals(form.getActionType())) {
                removeRequirement(form, modelMap);
                return "editProgramActivityIncentive";
            } else if (ACTION_ADD_ACTIVTY.equals(form.getActionType())) {
                addActivity(form, modelMap);
                return "editProgramActivityIncentive";
            } else if (ACTION_REMOVE_ACTIVTY.equals(form.getActionType())) {
                removeActivity(form, modelMap);
                return "editProgramActivityIncentive";
            } else if (ACTION_ADD_RELATIONSHIP.equals(form.getActionType())) {
                addRelationship(form, modelMap);
                return "editProgramActivityIncentive";
            } else if (ACTION_REMOVE_RELATIONSHIP.equals(form.getActionType())) {
                removeRelationship(form, modelMap);
                return "editProgramActivityIncentive";
            } else if (ACTION_SAVE.equals(form.getActionType()) || ACTION_SAVE_TO_ALL_SITES.equals(form.getActionType()) || ACTION_SAVE_TO_SELECTED.equals(form.getActionType())) {
                validate(form, result);
                validateMultiActivity(result);
                if (result.hasErrors()) {
                    clearFormArrays(form);
                    populateRequest(modelMap);
                    return "editProgramActivityIncentive";
                } else {
                    return performSave(modelMap, ra, form, result);
                }
            }
        } catch (Exception e) {
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
            createErrorMessageOnModel(modelMap, getStackTrace(e));
        }

        // Add package also forwards to the same jsp.
        return "editProgramActivityIncentive";
    }

    private String performSave(ModelMap modelMap, RedirectAttributes ra, SaveProgramActivityIncentiveForm form, BindingResult result) throws Exception {
        String userID = getUserSessionSupport().getAuthenticatedUsername();
        ProgramIncentiveOption programIncentiveOption = getUserSession().getProgramIncentiveOption();

        populateRequest(modelMap);
        saveRequirements(form, programIncentiveOption);

        boolean isOneOrMoreActivityRequirementsRegistered = determineIncentiveOptionRequirementsRegistered(programIncentiveOption);

        // if trying to remove activity incentive requirement that is used
        // in the tier contribution tables then don't allow it to be
        // deleted.
        if (isOneOrMoreActivityRequirementsRegistered) {
            //evaluate activity incentive requirements
            boolean isClearToEvaluateWithNoActivityRequirementAdds = clearToEvaluateWithNoActivityRequirementAdds(programIncentiveOption.getActivityIncentiveRequirements());
            boolean isClearToEvaluateWithNoActivityIncentiveDetailAdds = clearToEvaluateWithNoActivityIncentiveDetailAdds(programIncentiveOption.getActivityIncentiveRequirements());

            if (isClearToEvaluateWithNoActivityRequirementAdds && isClearToEvaluateWithNoActivityIncentiveDetailAdds) {
                //evaluate existing activity requirements.
                evaluateActivityRequirementsRegisteredForlActionMessages(programIncentiveOption.getActivityIncentiveRequirements(), result, modelMap);
            }

            //evaluate activity incentive requirements to be removed.  Edit needs to stay in play
            //even though user is attempting to add an activity requirement at the same time an activity requirement is being removed.
            evaluateActivityRequirementsRegisteredForlActionMessages(programIncentiveOption.getActivityIncentiveRequirementsToRemove(), result, modelMap);

        }

        if (ACTION_SAVE.equals(form.getActionType())) {
            saveProgramIncentiveRequirements(ra, form, userID, isOneOrMoreActivityRequirementsRegistered);

        } else if (ACTION_SAVE_TO_ALL_SITES.equals(form.getActionType())) {
            saveProgramIncentiveRequirements(ra, form, userID, isOneOrMoreActivityRequirementsRegistered);
            ArrayList<ProgramIncentiveOption> lProgramIncentiveOptions = (ArrayList<ProgramIncentiveOption>) businessProgramService.getProgramIncentiveOptions(form.getProgramID());
            getUserSession().setProgramIncentiveOptions(lProgramIncentiveOptions);
            saveProgramIncentiveRequirementsAllSites(userID);

        } else if (ACTION_SAVE_TO_SELECTED.equals(form.getActionType())) {
            saveToSelectedSites(modelMap);
            return "programActivitySites";
        }

        // Redirect back to the editProgram incentiveOptions screen upon successful process of saves
        EditProgramForm editProgramForm = new EditProgramForm();
        editProgramForm.setGroupNo(getUserSession().getGroupNo());
        editProgramForm.setProgramID(form.getProgramID());
        getUserSession().setProgramID(form.getProgramID());
        ra.addFlashAttribute("editProgramForm", editProgramForm);
        ra.addFlashAttribute("groupNumber", getUserSession().getGroupNo());
        ra.addFlashAttribute("actionType", "editIncentives");
        ra.addAttribute("groupNumber", getUserSession().getGroupNo());
        ra.addAttribute("actionType", "editIncentives");
        return "redirect: editProgram";
    }

    private void saveProgramIncentiveRequirements(RedirectAttributes ra, SaveProgramActivityIncentiveForm form, String pUserID, boolean isOneOrMoreActivityRequirementsRegistered) throws Exception {
        ProgramIncentiveOption lProgramIncentiveOption = getUserSession().getProgramIncentiveOption();

        if (isOneOrMoreActivityRequirementsRegistered) {
            Collection<ActivityIncentiveRequirement> lActivityIncentiveRequirements = lProgramIncentiveOption.getActivityIncentiveRequirements();
            for (ActivityIncentiveRequirement lActivityIncentiveRequirement : lActivityIncentiveRequirements) {
                //group id of null indicates new activity requirement.
                if (lActivityIncentiveRequirement.getGroupID() == null) {
                    businessProgramService.updateActivityIncentiveRequirement(lActivityIncentiveRequirement, pUserID);
                } else {
                    //determine if new activity detail exists and then add to activity requirement.
                    businessProgramService.updateActivityIncentiveDetailDirectly(lActivityIncentiveRequirement, pUserID);
                }
            }

        } else {
            // delete everything and insert.
            businessProgramService.deleteActivityIncentiveRequirement(lProgramIncentiveOption.getBusinessProgramID(), lProgramIncentiveOption.getIncentiveOption().getIncentiveOptionID());

            for (int i = 0; i < lProgramIncentiveOption.getActivityIncentiveRequirements().size(); i++) {
                businessProgramService.updateActivityIncentiveRequirement(lProgramIncentiveOption.getActivityIncentiveRequirements().get(i), pUserID);
            }
        }
    }

    private void saveProgramIncentiveRequirementsAllSites(String pUserID) throws Exception {
        businessProgramService.saveProgramIncentiveActivitiesAllSites(getUserSession().getBusinessProgram(), getUserSession().getProgramIncentiveOption(), pUserID);
    }

    private void saveToSelectedSites(ModelMap modelMap) throws BPMException {
        if (getUserSession().getAvailableSites() != null) {
            getUserSession().getAvailableSites().clear();
        }

        if (getUserSession().getEmployerSubGroups() != null) {
            getUserSession().getEmployerSubGroups().clear();
        }

        // The method saveRequirements is called in the main body of the
        // action controller before this method is called,
        // to save the activities and
        // the requirements in the ProgramIncentiveOption in the sessionBean.

        Collection<EmployerGroup> lSubGroups = businessProgramService.getBusinessProgramInSameYear(getUserSession().getBusinessProgram().getProgramID());

        modelMap.put("businessProgram", getUserSession().getBusinessProgram());
        modelMap.put("selectedSubGroups", lSubGroups);

        SaveProgramActivitySiteForm saveProgramActivitySiteForm = new SaveProgramActivitySiteForm();
        saveProgramActivitySiteForm.setSubGroupID(((ArrayList<EmployerGroup>) lSubGroups).get(0).getSubgroupID());
        modelMap.put("saveProgramActivitySiteForm", saveProgramActivitySiteForm);

        getUserSession().setEmployerSubGroups((ArrayList<EmployerGroup>) lSubGroups);
        getUserSession().setWhichSaveSelectedSite(WHICH_SAVE_SELECTED_SITES_INCENTIVE_ACTIVITIES);
    }

    public boolean determineIncentiveOptionRequirementsRegistered(ProgramIncentiveOption lProgramIncentiveOption) throws BPMException, DataAccessException {
        Integer programID = lProgramIncentiveOption.getBusinessProgramID();
        Integer incentiveOptionID = lProgramIncentiveOption.getIncentiveOption().getIncentiveOptionID();
        String incentedStatusTypeCode = lProgramIncentiveOption.getIncentedStatusTypeCode();

        boolean isOneOrMoreRequirementsRegistered = false;
        isOneOrMoreRequirementsRegistered = businessProgramService.isOneOrMoreRequirementsRegisteredToProgramTierContribution(programID, incentiveOptionID, incentedStatusTypeCode);

        if (isOneOrMoreRequirementsRegistered) {
            return isOneOrMoreRequirementsRegistered;
        } else {
            isOneOrMoreRequirementsRegistered = businessProgramService.isOneOrMoreRequirementsRegisteredToPersonProgramStatus(lProgramIncentiveOption);
        }

        return isOneOrMoreRequirementsRegistered;
    }

    private boolean clearToEvaluateWithNoActivityRequirementAdds(Collection<ActivityIncentiveRequirement> lActivityIncentiveRequirements) {
        boolean clearToEvaluateWithNoAdds = true;

        for (ActivityIncentiveRequirement lActivityIncentiveRequirement : lActivityIncentiveRequirements) {
            if (lActivityIncentiveRequirement.getGroupID() == null) {
                clearToEvaluateWithNoAdds = false;
            }
        }

        return clearToEvaluateWithNoAdds;
    }

    /*
     * If an activity incentive detail exists with an activity incentive ID of null, indicates user is adding a activity to requirement as an update.
     */
    private boolean clearToEvaluateWithNoActivityIncentiveDetailAdds(Collection<ActivityIncentiveRequirement> lActivityIncentiveRequirements) {
        boolean clearToEvaluateWithNoAdds = true;

        for (ActivityIncentiveRequirement lActivityIncentiveRequirement : lActivityIncentiveRequirements) {
            Collection<ActivityIncentiveDetail> lActivityIncentiveDetails = lActivityIncentiveRequirement.getActivityIncentiveDetails();
            for (ActivityIncentiveDetail lActivityIncentiveDetail : lActivityIncentiveDetails) {
                if (lActivityIncentiveDetail.getActivityIncentiveID() == null) {
                    clearToEvaluateWithNoAdds = false;
                }
            }
        }

        return clearToEvaluateWithNoAdds;
    }


    private void evaluateActivityRequirementsRegisteredForlActionMessages(Collection<ActivityIncentiveRequirement> lActivityIncentiveRequirements, Errors errors, ModelMap modelMap) throws BPMException {
        try {

            //evaluate activity requirements to be removed.

            if (lActivityIncentiveRequirements != null
                    && lActivityIncentiveRequirements.size() > 0) {
                for (ActivityIncentiveRequirement lActivityIncentiveRequirement : lActivityIncentiveRequirements) {
                    if (lActivityIncentiveRequirement.getGroupID() != null) {
                        boolean thisRequirementRegisteredToProgramTierContribution = determineActivityRequirementRegisteredToProgramTierContribution(lActivityIncentiveRequirement);
                        if (thisRequirementRegisteredToProgramTierContribution) {
                            createActionMessagesOnModel(modelMap, "errors.registeredToProgramTierContributionGrid", new Object[]{"Activity Incentive Requirement "});

                        } else {

                            boolean activityTaken = false;
                            ArrayList<ActivityIncentiveDetail> lActivityIncentiveDetails = lActivityIncentiveRequirement.getActivityIncentiveDetails();
                            for (ActivityIncentiveDetail lActivityIncentiveDetail : lActivityIncentiveDetails) {

                                if (lActivityIncentiveDetail.getActivityID() != null) {
                                    activityTaken = determineActivityRequirementRegisteredToActivityTaken(lActivityIncentiveDetail);
                                } else if (lActivityIncentiveDetail.getActivityTypeCodeID() != null) {
                                    ArrayList<Activity> lActivityDefinitions = businessProgramService.getActivityDefinitionsByType(lActivityIncentiveDetail.getActivityTypeCodeID());
                                    lActivityIncentiveDetail.setActivityDefinitions(lActivityDefinitions);

                                    activityTaken = determineActivityRequirementRegisteredToActivityTaken(lActivityIncentiveDetail);
                                    if (activityTaken) {
                                        break;
                                    }
                                }

                                if (activityTaken) {
                                    createActionMessagesOnModel(modelMap, "errors.registeredToProgramActivityTaken", new Object[]{"Activity Incentive Requirement "});
                                }
                            }
                            lActivityIncentiveRequirement.setRegistered(activityTaken);
                        }
                    }
                }
            }
        } catch (BPMException e) {
            throw e;
        }
    }

    private boolean determineActivityRequirementRegisteredToActivityTaken(
            ActivityIncentiveDetail lActivityIncentiveDetail) throws BPMException {

        boolean activityTaken = false;

        try {
            activityTaken = businessProgramService.isActivityRequirementRegisteredToPersonProgramActivityStatus(lActivityIncentiveDetail);

        } catch (BPMException e) {
            throw e;
        }

        return activityTaken;
    }

    /*
     * If multiple requirements defined to a program activity incentive and user is removing a requirement, check to make sure it is not already
     * registered to the program tier contribution table.
     */
    private boolean determineActivityRequirementRegisteredToProgramTierContribution(
            ActivityIncentiveRequirement lActivityIncentiveRequirement) throws BPMException {

        boolean activityRequirementRegisteredToProgramTierContribution = false;

        try {
            activityRequirementRegisteredToProgramTierContribution = businessProgramService.isActivityRequirementRegisteredToProgramTierContribution(lActivityIncentiveRequirement);
        } catch (BPMException e) {
            throw e;
        }

        lActivityIncentiveRequirement.setRegistered(activityRequirementRegisteredToProgramTierContribution);

        return activityRequirementRegisteredToProgramTierContribution;

    }


    private void loadInitial(SaveProgramActivityIncentiveForm form, ModelMap modelMap) throws BPMException {
        if (form.getIncentiveOptionID() == null) {
            form.setIncentiveOptionID(-1);
        }

        BusinessProgram businessProgram = getUserSession().getBusinessProgram();
        if (businessProgram == null) {
            businessProgram = businessProgramService.getBusinessProgram(form.getProgramID(), false);
        }

        ArrayList<ProgramIncentiveOption> programIncentiveOptions = (ArrayList<ProgramIncentiveOption>) businessProgramService.getProgramIncentiveOptions(form.getProgramID());
        // In the list of program incentive options, find the one that was selected.
        for (int i = 0; i < programIncentiveOptions.size(); i++) {
            if (programIncentiveOptions.get(i).getIncentiveOption().getIncentiveOptionID().intValue() == form.getIncentiveOptionID().intValue()) {
                programIncentiveOptions.get(i).setActivityIncentiveRequirements((ArrayList<ActivityIncentiveRequirement>) businessProgramService.getProgramActivityIncentiveRequirements(form.getProgramID(), programIncentiveOptions.get(i).getIncentiveOption().getIncentiveOptionID()));
                getUserSession().setProgramIncentiveOption(programIncentiveOptions.get(i));
                break;
            }
        }
        // If coming from "Add", create a new Program Incentive Option and initialize it with
        // the program ID and incentive option ID.
        if (getUserSession().getProgramIncentiveOption() == null) {
            ProgramIncentiveOption lNewProgramIncentiveOption = new ProgramIncentiveOption();
            IncentiveOption lNewIncentiveOption = new IncentiveOption();
            lNewIncentiveOption.setIncentiveOptionID(form.getIncentiveOptionID());
            lNewProgramIncentiveOption.setIncentiveOption(lNewIncentiveOption);
            lNewProgramIncentiveOption.setBusinessProgramID(form.getProgramID());
            getUserSession().setProgramIncentiveOption(lNewProgramIncentiveOption);
        }

        Collection<LookUpValueCode> lActivityTypes = businessProgramService.getActivityTypeCodes();
        getUserSession().setActivityTypeCodes((ArrayList<LookUpValueCode>) lActivityTypes);

        ArrayList<Activity> lActivities = (ArrayList<Activity>) businessProgramService.getActivities();
        getUserSession().setActivities(lActivities);

        ArrayList<LookUpValueCode> lActivityIncentiveTypeCodes = (ArrayList<LookUpValueCode>) businessProgramService.getActivityIncentiveTypeCodes();
        getUserSession().setActivityIncentiveTypeCodes(lActivityIncentiveTypeCodes);

        ArrayList<PersonRelationshipCode> lPersonRelationshipCodes = (ArrayList<PersonRelationshipCode>) businessProgramService.getPersonRelationshipCodes();
        getUserSession().setPersonRelationshipCodes(lPersonRelationshipCodes);

        ArrayList<LookUpValueCode> lActivityIncentiveStatusCodes = (ArrayList<LookUpValueCode>) businessProgramService.getActivityIncentiveStatusCodes();
        getUserSession().setActivityIncentiveStatusCodes(lActivityIncentiveStatusCodes);

        ArrayList<BPMCollection> lBPMCollections = businessProgramService.getAllCollections();
        getUserSession().setCollections(lBPMCollections);

        modelMap.put("saveProgramActivityIncentiveForm", form);
        modelMap.put("businessProgram", businessProgram);
        modelMap.put("programIncentiveOption", getUserSession().getProgramIncentiveOption());
        modelMap.put("luvActivityTypes", lActivityTypes);
        modelMap.put("activities", lActivities);
        modelMap.put("luvActivityIncentiveTypes", lActivityIncentiveTypeCodes);
        modelMap.put("personRelationshipCodes", lPersonRelationshipCodes);
        modelMap.put("luvActivityIncentiveStatuses", lActivityIncentiveStatusCodes);
        modelMap.put("collections", lBPMCollections);
    }

    private void populateRequest(ModelMap modelMap) throws BPMException {
        modelMap.put("businessProgram", getUserSession().getBusinessProgram());
        modelMap.put("programIncentiveOption", getUserSession().getProgramIncentiveOption());
        modelMap.put("luvActivityTypes", getUserSession().getActivityTypeCodes());
        modelMap.put("activities", getUserSession().getActivities());
        modelMap.put("luvActivityIncentiveTypes", getUserSession().getActivityIncentiveTypeCodes());
        modelMap.put("personRelationshipCodes", getUserSession().getPersonRelationshipCodes());
        modelMap.put("luvActivityIncentiveStatuses", getUserSession().getActivityIncentiveStatusCodes());
        modelMap.put("collections", getUserSession().getCollections());
    }

    private void addRequirement(SaveProgramActivityIncentiveForm form, ModelMap modelMap) throws BPMException {
        ProgramIncentiveOption lProgramIncentiveOption = getUserSession().getProgramIncentiveOption();

        // Save any potential values that the user may have entered on the form.
        saveRequirements(form, lProgramIncentiveOption);

        // When adding the first requirement
        if (lProgramIncentiveOption.getActivityIncentiveRequirements() == null) {
            ArrayList<ActivityIncentiveRequirement> lActivityIncentiveRequirements = new ArrayList<ActivityIncentiveRequirement>();
            lProgramIncentiveOption.setActivityIncentiveRequirements(lActivityIncentiveRequirements);
        }

        ActivityIncentiveRequirement lActivityIncentiveRequirement = new ActivityIncentiveRequirement();
        lActivityIncentiveRequirement.setProgramID(lProgramIncentiveOption.getBusinessProgramID());
        lActivityIncentiveRequirement.setIncentiveOptionID(lProgramIncentiveOption.getIncentiveOption().getIncentiveOptionID());
        lActivityIncentiveRequirement.setGroupRequirementID(lProgramIncentiveOption.getActivityIncentiveRequirements().size() + 1);
        lActivityIncentiveRequirement.setQuantity(0);
        ArrayList<ActivityIncentiveDetail> lActivityIncentiveDetails = new ArrayList<ActivityIncentiveDetail>();
        lActivityIncentiveRequirement.setActivityIncentiveDetails(lActivityIncentiveDetails);
        lProgramIncentiveOption.getActivityIncentiveRequirements().add(lActivityIncentiveRequirement);
        getUserSession().setProgramIncentiveOption(lProgramIncentiveOption);

        clearFormArrays(form);
        populateRequest(modelMap);
    }

    private void removeRequirement(SaveProgramActivityIncentiveForm form, ModelMap modelMap) throws BPMException {
        ProgramIncentiveOption lProgramIncentiveOption = getUserSession().getProgramIncentiveOption();

        // Save any potential values that the user may have entered on the form.
        saveRequirements(form, lProgramIncentiveOption);

        for (int i = 0; i < lProgramIncentiveOption.getActivityIncentiveRequirements().size(); i++) {
            if (lProgramIncentiveOption.getActivityIncentiveRequirements().get(i).getGroupRequirementID() == form.getRequirementID().intValue()) {
                lProgramIncentiveOption.getActivityIncentiveRequirements().get(i).getActivityIncentiveDetails().clear();
                // EV54252 - add to remove array
                if (lProgramIncentiveOption.getActivityIncentiveRequirementsToRemove() == null) {
                    lProgramIncentiveOption.setActivityIncentiveRequirementsToRemove(new ArrayList<ActivityIncentiveRequirement>());
                }
                lProgramIncentiveOption.getActivityIncentiveRequirementsToRemove().add(lProgramIncentiveOption.getActivityIncentiveRequirements().get(i));
                lProgramIncentiveOption.getActivityIncentiveRequirements().remove(i);
                break;
            }
        }

        clearFormArrays(form);
        populateRequest(modelMap);
    }

    private void addActivity(SaveProgramActivityIncentiveForm form, ModelMap modelMap) throws BPMException {
        ProgramIncentiveOption lProgramIncentiveOption = getUserSession().getProgramIncentiveOption();

        // Save any potential values that the user may have entered on the form.
        saveRequirements(form, lProgramIncentiveOption);

        for (int i = 0; i < lProgramIncentiveOption.getActivityIncentiveRequirements().size(); i++) {
            if (lProgramIncentiveOption.getActivityIncentiveRequirements().get(i).getGroupRequirementID().intValue() == form.getRequirementID().intValue()) {
                ArrayList<ActivityIncentiveDetail> lActivityIncentiveDetails = lProgramIncentiveOption.getActivityIncentiveRequirements().get(i).getActivityIncentiveDetails();

                if (lActivityIncentiveDetails == null) {
                    lActivityIncentiveDetails = new ArrayList<ActivityIncentiveDetail>();
                    lProgramIncentiveOption.getActivityIncentiveRequirements().get(i).setActivityIncentiveDetails(lActivityIncentiveDetails);
                }

                ActivityIncentiveDetail lActivityIncentiveDetail = new ActivityIncentiveDetail();
                lActivityIncentiveDetail.setProgramID(lProgramIncentiveOption.getBusinessProgramID());
                lActivityIncentiveDetail.setIncentiveOptionID(lProgramIncentiveOption.getIncentiveOption().getIncentiveOptionID());
                lActivityIncentiveDetail.setGroupRequiredID(form.getRequirementID().intValue());
                lActivityIncentiveDetail.setActivityID(0);
                lActivityIncentiveDetail.setActivityTypeCodeID(0);
                lActivityIncentiveDetail.setCollectionID(0);
                lActivityIncentiveDetail.setActivityIncentiveTypeCodeID(0);
                lActivityIncentiveDetail.setIncentedStatusTypeCodeID(0);

                ArrayList<IncentiveParticipantRelationship> lIncentiveParticipantRelationships = lActivityIncentiveDetail.getIncentiveParticipantRelationships();

                if (lIncentiveParticipantRelationships == null) {
                    lIncentiveParticipantRelationships = new ArrayList<>();
                    lActivityIncentiveDetail.setIncentiveParticipantRelationships(lIncentiveParticipantRelationships);
                }

                ArrayList<IncentiveParticipantRelationship> lIncentiveParticipantRelationshipsToRemove = lActivityIncentiveDetail.getIncentiveParticipantRelationshipsToRemove();
                if (lIncentiveParticipantRelationshipsToRemove == null) {
                    lIncentiveParticipantRelationshipsToRemove = new ArrayList<>();
                    lActivityIncentiveDetail.setIncentiveParticipantRelationshipsToRemove(lIncentiveParticipantRelationshipsToRemove);
                }

                IncentiveParticipantRelationship lIncentiveParticipantRelationship = new IncentiveParticipantRelationship();
                lIncentiveParticipantRelationship.setRelationshipCode(0);
                lIncentiveParticipantRelationship.setMaxQauntity(0);

                // Add the relationship array to the Activity Incentive Detail.
                lIncentiveParticipantRelationships.add(lIncentiveParticipantRelationship);

                // Add the Activity Incentive Detail to the
                // ActivityIncentiveDetail List.
                lProgramIncentiveOption.getActivityIncentiveRequirements().get(i).getActivityIncentiveDetails().add(lActivityIncentiveDetail);
                break;
            }
        }

        clearFormArrays(form);
        populateRequest(modelMap);
    }

    private void removeActivity(SaveProgramActivityIncentiveForm form, ModelMap modelMap) throws BPMException {
        ProgramIncentiveOption lProgramIncentiveOption = getUserSession().getProgramIncentiveOption();
        int lRowID = form.getRowID().intValue();

        // Save any potential values that the user may have entered on the form.
        saveRequirements(form, lProgramIncentiveOption);

        for (int i = 0; i < lProgramIncentiveOption.getActivityIncentiveRequirements().size(); i++) {
            if (lProgramIncentiveOption.getActivityIncentiveRequirements().get(i).getGroupRequirementID().intValue() == form.getRequirementID().intValue()) {
                // EV54252
                if (lProgramIncentiveOption.getActivityIncentiveRequirements().get(i).getActivityIncentiveDetailsToRemove() == null) {
                    lProgramIncentiveOption.getActivityIncentiveRequirements().get(i).setActivityIncentiveDetailsToRemove(new ArrayList<ActivityIncentiveDetail>());
                }
                lProgramIncentiveOption.getActivityIncentiveRequirements().get(i).getActivityIncentiveDetailsToRemove().add(lProgramIncentiveOption.getActivityIncentiveRequirements().get(i).getActivityIncentiveDetails().get(lRowID));
                lProgramIncentiveOption.getActivityIncentiveRequirements().get(i).getActivityIncentiveDetails().remove(lRowID);
                break;
            }
        }

        clearFormArrays(form);
        populateRequest(modelMap);
    }

    private void addRelationship(SaveProgramActivityIncentiveForm form, ModelMap modelMap) throws BPMException {
        ProgramIncentiveOption lProgramIncentiveOption = getUserSession().getProgramIncentiveOption();

        int lRowID = form.getRowID().intValue();
        int lActivityRowID = form.getActivityRowID().intValue();

        // Save any potential values that the user may have entered on the form.
        saveRequirements(form, lProgramIncentiveOption);

        for (int i = 0; i < lProgramIncentiveOption.getActivityIncentiveRequirements().size(); i++) {
            if (i == lRowID) {
                ArrayList<ActivityIncentiveDetail> lActivityIncentiveDetails = lProgramIncentiveOption.getActivityIncentiveRequirements().get(lRowID).getActivityIncentiveDetails();

                for (int j = 0; j < lActivityIncentiveDetails.size(); j++) {
                    if (j == lActivityRowID) {
                        IncentiveParticipantRelationship lIncentiveParticipantRelationship = new IncentiveParticipantRelationship();
                        lIncentiveParticipantRelationship.setActivityIncentiveID(lActivityIncentiveDetails.get(lActivityRowID).getActivityIncentiveID());
                        lIncentiveParticipantRelationship.setRelationshipCode(0);
                        lIncentiveParticipantRelationship.setMaxQauntity(0);

                        lActivityIncentiveDetails.get(j).getIncentiveParticipantRelationships().add(lIncentiveParticipantRelationship);
                        break;
                    }
                }
            }
        }

        clearFormArrays(form);
        populateRequest(modelMap);
    }

    protected void removeRelationship(SaveProgramActivityIncentiveForm form, ModelMap modelMap) throws BPMException {
        ProgramIncentiveOption lProgramIncentiveOption = getUserSession().getProgramIncentiveOption();
        int lRowID = form.getRowID().intValue();
        int lActivityRowID = form.getActivityRowID().intValue();
        int lRelRowID = form.getRelRowID().intValue();

        // Save any potential values that the user may have entered on the form.
        saveRequirements(form, lProgramIncentiveOption);

        for (int i = 0; i < lProgramIncentiveOption.getActivityIncentiveRequirements().size(); i++) {
            ArrayList<ActivityIncentiveDetail> lActivityIncentiveDetails = lProgramIncentiveOption.getActivityIncentiveRequirements().get(i).getActivityIncentiveDetails();
            if (i == lRowID) {
                for (int j = 0; j < lActivityIncentiveDetails.size(); j++) {
                    if (lActivityRowID == j) {
                        if (lActivityIncentiveDetails.get(lActivityRowID).getIncentiveParticipantRelationshipsToRemove() == null) {
                            lActivityIncentiveDetails.get(lActivityRowID).setIncentiveParticipantRelationshipsToRemove(new ArrayList<>());
                        }
                        // EV54252 - add relationships to be removed
                        lActivityIncentiveDetails.get(lActivityRowID).getIncentiveParticipantRelationshipsToRemove().add(lActivityIncentiveDetails.get(lActivityRowID).getIncentiveParticipantRelationships().get(lRelRowID));
                        lActivityIncentiveDetails.get(lActivityRowID).getIncentiveParticipantRelationships().remove(lRelRowID);
                        break;
                    }
                }
            }
        }

        clearFormArrays(form);
        populateRequest(modelMap);
    }

    private void clearFormArrays(SaveProgramActivityIncentiveForm pSaveProgramActivityIncentiveForm) {
        pSaveProgramActivityIncentiveForm.setActivityIDs(null);
        pSaveProgramActivityIncentiveForm.setActivityTypeCodeIDs(null);
        pSaveProgramActivityIncentiveForm.setGroupRequirementIDs(null);
        pSaveProgramActivityIncentiveForm.setRelationshipIDs(null);

        pSaveProgramActivityIncentiveForm.setCollectionIDs(null);
        pSaveProgramActivityIncentiveForm.setRowID(0);
        pSaveProgramActivityIncentiveForm.setActivityRowID(0);
    }

    private void saveRequirements(SaveProgramActivityIncentiveForm lSaveProgramActivityIncentiveForm, ProgramIncentiveOption pProgramIncentiveOption) {
        String[] lActivityIDs = lSaveProgramActivityIncentiveForm.getActivityIDs();
        String[] lActivityTypeCodeIDs = lSaveProgramActivityIncentiveForm.getActivityTypeCodeIDs();
        String[][] lRelationshipIDs = lSaveProgramActivityIncentiveForm.getRelationshipIDs();
        String[][] lIncentiveQuantities = lSaveProgramActivityIncentiveForm.getIncentiveQuantities();
        String[] lIncentiveTypes = lSaveProgramActivityIncentiveForm.getActivityIncentiveTypeIDs();
        String[] lIncentedStatuses = lSaveProgramActivityIncentiveForm.getActivityIncentedStatusIDs();
        String[] lCollectionIDs = lSaveProgramActivityIncentiveForm.getCollectionIDs();

        int lRelationshipRowCounter = 0;
        int hashMapCounter = 0;

        HashMap<Integer, ActivityIncentiveDetail> activityIncentiveDetailMap = new HashMap<Integer, ActivityIncentiveDetail>();
        if (pProgramIncentiveOption != null && pProgramIncentiveOption.getActivityIncentiveRequirements() != null) {
            for (int i = 0; i < pProgramIncentiveOption.getActivityIncentiveRequirements().size(); i++) {

                // Store the quantities in the corresponding Requirements.
                if (lSaveProgramActivityIncentiveForm.getRequiredQuantities() != null) {
                    pProgramIncentiveOption.getActivityIncentiveRequirements().get(i).setQuantity(Integer.parseInt(lSaveProgramActivityIncentiveForm.getRequiredQuantities()[i]));
                }

                // Then store the Activity ID, or the Activity Type Code ID in
                // the corresponding
                // Activity Incentive Detail.
                // tjquist EV6226 - store activity incentive requirements in a
                // hashmap and iterate through
                // while matching up to data arrays from form. Then update from
                // the arrays back
                // to the hashmap. Array size from each array data field has to
                // be the same as the
                // number of activity incentive detail records stored in the
                // hashmap.
                if (pProgramIncentiveOption.getActivityIncentiveRequirements().get(i).getActivityIncentiveDetails() != null) {
                    for (int lActivityRowCounter = 0; lActivityRowCounter < pProgramIncentiveOption.getActivityIncentiveRequirements().get(i).getActivityIncentiveDetails().size(); lActivityRowCounter++) {
                        ActivityIncentiveDetail lActivityIncentiveDetail = pProgramIncentiveOption.getActivityIncentiveRequirements().get(i).getActivityIncentiveDetails().get(lActivityRowCounter);
                        activityIncentiveDetailMap.put(hashMapCounter, lActivityIncentiveDetail);
                        hashMapCounter++;
                    }
                }
            }

            // tjquist EV6226 - in order for the update to work the number of
            // incentive details must match array size from the form
            // representive of
            // data that is being updated back to activity incentive detail.
            if (lActivityIDs != null && activityIncentiveDetailMap.size() == lActivityIDs.length) {

                Collection<ActivityIncentiveDetail> lActivityIncentiveDetails = activityIncentiveDetailMap.values();
                int lActivityIncentiveDetailRowCounter = 0;

                for (ActivityIncentiveDetail lActivityIncentiveDetail : lActivityIncentiveDetails) {
                    lActivityIncentiveDetail.setActivityIncentiveTypeCodeID(Integer.parseInt(lIncentiveTypes[lActivityIncentiveDetailRowCounter]));
                    lActivityIncentiveDetail.setIncentedStatusTypeCodeID(Integer.parseInt(lIncentedStatuses[lActivityIncentiveDetailRowCounter]));

                    if (lActivityIDs != null && Integer.parseInt(lActivityIDs[lActivityIncentiveDetailRowCounter]) > 0) {
                        lActivityIncentiveDetail.setActivityID(Integer.parseInt(lActivityIDs[lActivityIncentiveDetailRowCounter]));

                        ArrayList<Activity> lActivities = getUserSession().getActivities();
                        for (int k = 0; k < lActivities.size(); k++) {
                            if (lActivities.get(k).getActivityID().intValue() == lActivityIncentiveDetail.getActivityID().intValue()) {
                                lActivityIncentiveDetail.setActivityName(lActivities.get(k).getName());
                                break;
                            }
                        }

                    } else if (lActivityTypeCodeIDs != null && Integer.parseInt(lActivityTypeCodeIDs[lActivityIncentiveDetailRowCounter]) > 0) {
                        lActivityIncentiveDetail.setActivityTypeCodeID(Integer.parseInt(lActivityTypeCodeIDs[lActivityIncentiveDetailRowCounter]));

                        ArrayList<LookUpValueCode> lActivityTypeCodes = getUserSession().getActivityTypeCodes();
                        for (int k = 0; k < lActivityTypeCodes.size(); k++) {
                            if (lActivityTypeCodes.get(k).getLuvId().intValue() == lActivityIncentiveDetail.getActivityTypeCodeID().intValue()) {
                                lActivityIncentiveDetail.setActivityTypeVal(lActivityTypeCodes.get(k).getLuvDesc());
                                break;
                            }
                        }
                    } else if (lCollectionIDs != null && Integer.parseInt(lCollectionIDs[lActivityIncentiveDetailRowCounter]) > 0) {
                        lActivityIncentiveDetail.setCollectionID(Integer.parseInt(lCollectionIDs[lActivityIncentiveDetailRowCounter]));

                        ArrayList<BPMCollection> lBPMCollections = getUserSession().getCollections();
                        for (BPMCollection lBPMCollection : lBPMCollections) {
                            if (lBPMCollection.getCollectionID().intValue() == lActivityIncentiveDetail.getCollectionID().intValue()) {
                                lActivityIncentiveDetail.setCollectionName(lBPMCollection.getCollectionName());
                                break;
                            }
                        }
                    }
                    lActivityIncentiveDetailRowCounter++;
                    // Store the Relationship Code ID in the corresponding
                    // Incentive Participant Relationship.
                    if (lActivityIncentiveDetail.getIncentiveParticipantRelationships() != null) {
                        int relationshipsSize = lActivityIncentiveDetail.getIncentiveParticipantRelationships().size();
                        ArrayList<IncentiveParticipantRelationship> relationships = lActivityIncentiveDetail.getIncentiveParticipantRelationships();
                        for (int rel = 0; rel < lActivityIncentiveDetail.getIncentiveParticipantRelationships().size(); rel++) {
                            IncentiveParticipantRelationship lIncentiveParticipantRelationship = lActivityIncentiveDetail.getIncentiveParticipantRelationships().get(rel);

                            if (lRelationshipIDs != null /*&& lRelationshipIDs[lRelationshipRowCounter].length > 0*/) {
                                lIncentiveParticipantRelationship.setRelationshipCode(Integer.parseInt(lRelationshipIDs[lRelationshipRowCounter][rel]));
                                lIncentiveParticipantRelationship.setMaxQauntity(Integer.parseInt(lIncentiveQuantities[lRelationshipRowCounter][rel]));

                                ArrayList<PersonRelationshipCode> lPersonRelationshipCodes = getUserSession().getPersonRelationshipCodes();
                                for (int k = 0; k < lPersonRelationshipCodes.size(); k++) {
                                    if (lPersonRelationshipCodes.get(k).getRelationshipCodeID().intValue() == lIncentiveParticipantRelationship.getRelationshipCode().intValue()) {
                                        lIncentiveParticipantRelationship.setRelationshipName(lPersonRelationshipCodes.get(k).getRelationshipName());
                                        break;
                                    }
                                }
                            }
                        }
                    }
                    lRelationshipRowCounter++;
                }
                lActivityIncentiveDetailRowCounter++;
            }// If activity detail is not null.

        }
    }

    @Override
    public boolean supports(Class<?> clazz) {
        return SaveProgramActivityIncentiveForm.class.isAssignableFrom(clazz);
    }

    @Override
    public void validate(Object target, Errors errors) {
        SaveProgramActivityIncentiveForm form = (SaveProgramActivityIncentiveForm) target;

        for (int i = 0; i < form.getActivityIncentiveTypeIDs().length; i++) {
            getValidationSupport().validateNotZero("activityIncentiveTypeIDs[" + i + "]", form.getActivityIncentiveTypeIDs()[i], errors, new Object[]{"Activity Incentive Type"});
        }

        for (int i = 0; i < form.getActivityIncentedStatusIDs().length; i++) {
            getValidationSupport().validateNotZero("activityIncentedStatusIDs[" + i + "]", form.getActivityIncentedStatusIDs()[i], errors, new Object[]{"Incentive Status"});
        }

        for (int i = 0; i < form.getRelationshipIDs().length; i++) {
            for (int j = 0; j < form.getRelationshipIDs()[i].length; j++) {
                getValidationSupport().validateNotZero("relationshipIDs[" + i + "][" + j + "]", form.getRelationshipIDs()[i][j], errors, new Object[]{"Relationship"});
            }
        }

        for (int i = 0; i < form.getRequiredQuantities().length; i++) {
            getValidationSupport().validateNotZero("requiredQuantities[" + i + "]", form.getRequiredQuantities()[i], errors, new Object[]{"Required Quantities"});
        }

        for (int i = 0; form.getActivityIDs() != null && i < form.getActivityIDs().length; i++) {
            if (form.getActivityIDs()[i] != null && form.getActivityTypeCodeIDs() != null && form.getCollectionIDs() != null) {
                if (Integer.parseInt(form.getActivityIDs()[i]) > 0 && Integer.parseInt(form.getActivityIDs()[i]) > 0 && Integer.parseInt(form.getCollectionIDs()[i]) > 0) {
                    getValidationSupport().addValidationFailureMessage("activityIDs[" + i + "]", errors, "errors.cannotSelectActivityAndType", null);
                }

                if (Integer.parseInt(form.getActivityIDs()[i]) <= 0 && Integer.parseInt(form.getActivityTypeCodeIDs()[i]) <= 0 && Integer.parseInt(form.getCollectionIDs()[i]) <= 0) {
                    getValidationSupport().addValidationFailureMessage("activityIDs[" + i + "]", errors, "errors.noselect", new Object[]{"Activity or Activity Type"});
                }
            }
        }

        for (int i = 0; form.getActivityTypeCodeIDs() != null && i < form.getActivityTypeCodeIDs().length; i++) {
            if (form.getActivityTypeCodeIDs()[i] != null && form.getActivityIDs() != null && form.getCollectionIDs() != null) {
                if (Integer.parseInt(form.getActivityTypeCodeIDs()[i]) > 0 && Integer.parseInt(form.getActivityIDs()[i]) > 0 && Integer.parseInt(form.getCollectionIDs()[i]) > 0) {
                    getValidationSupport().addValidationFailureMessage("activityTypeCodeIDs[" + i + "]", errors, "errors.cannotSelectActivityAndType", null);
                }

                if (Integer.parseInt(form.getActivityIDs()[i]) <= 0 && Integer.parseInt(form.getActivityTypeCodeIDs()[i]) <= 0 && Integer.parseInt(form.getCollectionIDs()[i]) <= 0) {
                    getValidationSupport().addValidationFailureMessage("activityTypeCodeIDs[" + i + "]", errors, "errors.noselect", new Object[]{"Activity or Activity Type"});
                }
            }
        }

        for (int i = 0; form.getCollectionIDs() != null && i < form.getCollectionIDs().length; i++) {
            if (form.getCollectionIDs()[i] != null && form.getActivityIDs() != null && form.getActivityTypeCodeIDs() != null) {
                if (Integer.parseInt(form.getActivityTypeCodeIDs()[i]) > 0 && Integer.parseInt(form.getActivityIDs()[i]) > 0 && Integer.parseInt(form.getCollectionIDs()[i]) > 0) {
                    getValidationSupport().addValidationFailureMessage("collectionIDs[" + i + "]", errors, "errors.cannotSelectActivityAndType", null);
                }

                if (Integer.parseInt(form.getActivityIDs()[i]) <= 0 && Integer.parseInt(form.getActivityTypeCodeIDs()[i]) <= 0 && Integer.parseInt(form.getCollectionIDs()[i]) <= 0) {
                    getValidationSupport().addValidationFailureMessage("collectionIDs[" + i + "]", errors, "errors.noselect", new Object[]{"Activity or Activity Type"});
                }
            }
        }
    }

    private void validateMultiActivity(Errors errors) {
        //EV50511 - edit rule to make sure admin selects incentive status MULTI_ACTIVITY for the incentive option when adding more than one
        //incentive requirement.

        if (getUserSession().getProgramIncentiveOption() != null) {
            if (getUserSession().getProgramIncentiveOption().getActivityIncentiveRequirements() != null && getUserSession().getProgramIncentiveOption().getActivityIncentiveRequirements().size() > 1) {
                if (getUserSession().getProgramIncentiveOption().getIncentedStatusTypeCode() != null && !getUserSession().getProgramIncentiveOption().getIncentedStatusTypeCode().equals(BPMConstants.BPM_INCENTED_STATUS_TYPE_MULTI_ACTIVITY)) {
                    getValidationSupport().addValidationFailureMessage("activityIncentiveTypeIDs[0]", errors, "errors.cannotSelectActivityAndType", null);
                }
            }
        }
    }

}
