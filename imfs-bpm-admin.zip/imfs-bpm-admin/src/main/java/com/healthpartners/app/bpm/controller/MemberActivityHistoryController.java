package com.healthpartners.app.bpm.controller;

import com.healthpartners.app.bpm.common.BPMAdminConstants;
import com.healthpartners.app.bpm.common.BPMAdminUtils;
import com.healthpartners.app.bpm.dto.MemberDetail;
import com.healthpartners.app.bpm.dto.MemberProgramActivity;
import com.healthpartners.app.bpm.exception.BPMException;
import com.healthpartners.app.bpm.form.MemberActivityHistorySearchForm;
import com.healthpartners.app.bpm.form.ProgramSearchForm;
import com.healthpartners.app.bpm.iface.BusinessProgramService;
import com.healthpartners.app.bpm.iface.LookUpValueService;
import com.healthpartners.app.bpm.iface.MemberService;
import jakarta.servlet.ServletException;
import org.apache.commons.lang.StringUtils;
import org.eclipse.tags.shaded.org.apache.xpath.operations.Mod;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.ArrayList;
import java.util.Collection;

@Controller
public class MemberActivityHistoryController extends BaseController implements Validator {

    private final LookUpValueService lookUpValueService;
    private final BusinessProgramService businessProgramService;
    private final MemberService memberService;

    public MemberActivityHistoryController(LookUpValueService lookUpValueService, BusinessProgramService businessProgramService, MemberService memberService) {
        this.lookUpValueService = lookUpValueService;
        this.businessProgramService = businessProgramService;
        this.memberService = memberService;
    }

    @GetMapping("/memberActivityHistorySearch")
    public String loadSearch(ModelMap modelMap) throws BPMException {
        MemberActivityHistorySearchForm memberActivityHistorySearchForm = new MemberActivityHistorySearchForm();
        modelMap.put("memberActivityHistorySearchForm", memberActivityHistorySearchForm);
        try {
            getUserSession().setStartDates((ArrayList<String>) businessProgramService.getAllStartDates());
            modelMap.put("startDates", getUserSession().getStartDates());

        } catch (Exception e) {
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
            modelMap.put("errorMsg", getStackTrace(e));
        }
        return "memberActivityHistorySearch";
    }

    @PostMapping("/memberActivityHistorySearch")
    public String submitSearch(@ModelAttribute("memberActivityHistorySearchForm") MemberActivityHistorySearchForm form, ModelMap modelMap, BindingResult result) throws Exception {
        try {
            if (StringUtils.isEmpty(form.getActionType())) {
                form.setActionType(ACTION_SEARCH);
            }
            if (ACTION_SEARCH.equals(form.getActionType())) {
                validate(form, result);
            }
            if (!result.hasErrors()) {
                return searchAndRefreshActivityHistory(form, modelMap);
            } else {
                getUserSession().setStartDates((ArrayList<String>) businessProgramService.getAllStartDates());
                modelMap.put("startDates", getUserSession().getStartDates());
            }
        } catch (Exception e) {
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
            // Add error stack trace on the request, to be hidden in html.
            createErrorMessageOnModel(modelMap, getStackTrace(e));
        }

        return "memberActivityHistorySearch";
    }

    private String searchAndRefreshActivityHistory(MemberActivityHistorySearchForm form, ModelMap modelMap) throws Exception, ServletException {
        refreshSearchResults(form, modelMap);
        return "memberActivityHistory";
    }
    private void refreshSearchResults(MemberActivityHistorySearchForm form, ModelMap modelMap) throws BPMException, DataAccessException {
        try {
            String memberID = form.getMemberID();
            String qualificationStartDateStr = form.getQualificationStartDate();

            // qualificationStartDate is now optional
            java.sql.Date qualificationStartDate = BPMAdminUtils.getSqlDateFromString(qualificationStartDateStr);

            Collection<MemberProgramActivity> lMemberActivities = memberService.getActivityHistory(memberID, qualificationStartDate);

            MemberDetail lMemberDetail = memberService.getMemberDetail(memberID, qualificationStartDate);

            if (lMemberActivities == null) {
                createActionMessagesOnModel(modelMap, "messages.nosearchresults", null);
            }

            modelMap.put("memberActivities", lMemberActivities);
            modelMap.put("memberDetail", lMemberDetail);

        } catch (Exception e) {
            throw new BPMException(e);
        }
    }

    @Override
    public boolean supports(Class<?> clazz) {
        return MemberActivityHistorySearchForm.class.isAssignableFrom(clazz);
    }

    @Override
    public void validate(Object target, Errors errors) {
        MemberActivityHistorySearchForm form = (MemberActivityHistorySearchForm) target;
        getValidationSupport().validateRequiredFieldIsNotEmpty("memberID", form.getMemberID(), errors, new Object[]{"member ID"});
    }
}
