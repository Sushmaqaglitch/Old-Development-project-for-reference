package com.healthpartners.app.bpm.dao;


import com.healthpartners.app.bpm.dto.GroupActivityProgressTracker;
import com.healthpartners.app.bpm.exception.BPMException;
import org.springframework.dao.DataAccessException;

import java.util.Collection;


public interface GroupActivityProgressTrackerDAO {
    Collection<GroupActivityProgressTracker> getGroupActivityProgressionTracker(String groupNo, String pInputFileName, java.sql.Date pBatchDate, Integer trackingStatusID);

    void updateGroupActivityProgressionTrackerStatus(int uid, int pTrackingStatusID, Integer postprocessCount, Integer postprocessAmount, String trackingReason, String pUserID) throws BPMException, DataAccessException;
}
