package com.healthpartners.app.bpm.controller;

import com.healthpartners.app.bpm.common.BPMAdminConstants;
import com.healthpartners.app.bpm.common.BPMAdminEmailUtility;
import com.healthpartners.app.bpm.common.BPMAdminUtils;
import com.healthpartners.app.bpm.dao.AuditLogDAO;
import com.healthpartners.app.bpm.dto.*;
import com.healthpartners.app.bpm.exception.BPMException;
import com.healthpartners.app.bpm.form.CreateProgramForm;
import com.healthpartners.app.bpm.form.EditProgramForm;
import com.healthpartners.app.bpm.form.SaveProgramActivitySiteForm;
import com.healthpartners.app.bpm.form.SaveProgramForm;
import com.healthpartners.app.bpm.iface.BusinessProgramService;
import com.healthpartners.app.bpm.iface.MemberService;
import com.healthpartners.app.bpm.service.ProgramValidationService;
import com.healthpartners.service.bpm.common.BPMConstants;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.view.RedirectView;

import jakarta.servlet.http.HttpServletRequest;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.StringTokenizer;

import static org.apache.commons.lang.exception.ExceptionUtils.getStackTrace;

@Controller
public class ProgramSaveController extends BaseController implements Validator {

    private static final String ACTION_SAVE = "save";
    private static final String ACTION_SAVE_TO_ALL_SITES = "saveToAllSites";
    private static final String ACTION_SAVE_TO_SELECTED = "saveToSelected";
    private static final String WHICH_SAVE_SELECTED_SITES_BIZ_PROGRAM = "BusinessProgram";

    private SimpleDateFormat fmt = new SimpleDateFormat(BPMAdminConstants.HP_BPM_ADMIN_UI_COMMON_DATE_FORMAT);
    private final BusinessProgramService businessProgramService;
    private final MemberService memberService;
    private final BPMAdminEmailUtility bpmAdminEmailUtility;
    private final AuditLogDAO auditLogDAO;
    private final ProgramValidationService programValidationService;

    private String hostName = "http://localhost";

    protected final Log logger = LogFactory.getLog(getClass());

    public ProgramSaveController(BusinessProgramService businessProgramService, MemberService memberService, BPMAdminEmailUtility bpmAdminEmailUtility, AuditLogDAO auditLogDAO, ProgramValidationService programValidationService) {
        this.businessProgramService = businessProgramService;
        this.memberService = memberService;
        this.bpmAdminEmailUtility = bpmAdminEmailUtility;
        this.auditLogDAO = auditLogDAO;
        this.programValidationService = programValidationService;
    }

    @PostMapping(value="/saveProgram", params=ACTION_SAVE)
    public String submitSaveProgram(@ModelAttribute("saveProgramForm") SaveProgramForm saveProgramForm, ModelMap modelMap, BindingResult result, RedirectAttributes ra) throws Exception {
       try {
           saveProgramForm.setActionType(ACTION_SAVE);
           return processSaveRequest(saveProgramForm, modelMap, result, ra);
       } catch (Exception e) {
           logger.error("An unexpected error has occurred: " + e.getMessage(), e);
           createErrorMessageOnModel(modelMap, getStackTrace(e));
       }
       return "editProgram";
    }

    @PostMapping(value="/saveProgram", params=ACTION_SAVE_TO_ALL_SITES)
    public String submitSaveProgramToAllSites(@ModelAttribute("saveProgramForm") SaveProgramForm saveProgramForm, ModelMap modelMap, BindingResult result, RedirectAttributes ra) throws Exception {
        try {
            saveProgramForm.setActionType(ACTION_SAVE_TO_ALL_SITES);
            return processSaveRequest(saveProgramForm, modelMap, result, ra);
        } catch (Exception e) {
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
            createErrorMessageOnModel(modelMap, getStackTrace(e));
        }
        return "editProgram";
    }

    @PostMapping(value="/saveProgram", params=ACTION_SAVE_TO_SELECTED)
    public String submitSaveProgramToSelectedSites(@ModelAttribute("saveProgramForm") SaveProgramForm saveProgramForm, ModelMap modelMap, BindingResult result, RedirectAttributes ra) throws Exception {
        try {
            saveProgramForm.setActionType(ACTION_SAVE_TO_SELECTED);
            validate(saveProgramForm, result);
            if (result.hasErrors()) {
                return "editProgram";
            }
            SaveProgramActivitySiteForm saveProgramActivitySiteForm = new SaveProgramActivitySiteForm();
            saveProgramActivitySiteForm.setSubGroupID(saveProgramForm.getSubgroupID());
            modelMap.put("saveProgramActivitySiteForm", saveProgramActivitySiteForm);
            performSave(saveProgramForm, modelMap);
        } catch (Exception e) {
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
            createErrorMessageOnModel(modelMap, getStackTrace(e));
        }
        return "programActivitySites";
    }

    @PostMapping(value="/saveProgram", params="cancelCopyProgram")
    public String submitCancelCopyProgram(@ModelAttribute("saveProgramForm") SaveProgramForm saveProgramForm, ModelMap modelMap) throws BPMException {
        try {
            BusinessProgram businessProgram = businessProgramService.getBusinessProgram(saveProgramForm.getCopyFromPogramID(), false);
            EditProgramForm editProgramForm = new EditProgramForm();
            editProgramForm.setProgramID(saveProgramForm.getCopyFromPogramID());
            editProgramForm.setGroupNo(saveProgramForm.getGroupNumber());
            modelMap.put("editProgramForm", editProgramForm);
            modelMap.put("businessProgram", businessProgram);
        } catch (Exception e) {
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
            createErrorMessageOnModel(modelMap, getStackTrace(e));
        }
        return "viewProgram";
    }

    @PostMapping(value="/saveProgram", params="cancelEditProgram")
    public RedirectView submitCancelEditProgram(@ModelAttribute("saveProgramForm") SaveProgramForm saveProgramForm, RedirectAttributes ra) {
        ra.addFlashAttribute("groupNumber", saveProgramForm.getGroupNumber());
        String url = "viewProgram?programID=" + saveProgramForm.getProgramID();
        return new RedirectView(url);
    }

    @GetMapping("/copyProgram")
    public String copyProgram(@RequestParam(name = "programID") Integer programID, ModelMap modelMap) throws BPMException {
        try {
            BusinessProgram businessProgram = businessProgramService.getBusinessProgram(programID, false);
            getUserSession().setBusinessProgram(businessProgram);
            businessProgram.setProgramID(0);
            businessProgram.setMembershipProcessDate(null);
            businessProgram.setMembershipProcessFlag("N");
            SaveProgramForm form = populateSaveProgramForm(businessProgram);
            form.setActionType("copy");
            loadFormSelects(form);
            form.setCopyFromPogramID(programID);
            modelMap.put("membershipProcessFlag", false);
            modelMap.put("saveProgramForm", form);
        } catch (Exception e) {
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
            createErrorMessageOnModel(modelMap, getStackTrace(e));
        }
        return "copyProgram";
    }

    private String processSaveRequest(SaveProgramForm saveProgramForm, ModelMap modelMap, BindingResult result, RedirectAttributes ra) throws Exception {
        loadFormSelects(saveProgramForm);
        modelMap.put("membershipProcessFlag", false);
        validate(saveProgramForm, result);
        String lWhichFailurePage = FAILURE;
        if (saveProgramForm.getGroupID().intValue() == 0) {
            // If the group ID is 0, it's a Program Template.
            lWhichFailurePage = FAILURE_ALTFLOW1;
        }
        if (result.hasErrors()) {
            return "editProgram";
        }
        performSave(saveProgramForm, modelMap);
        ra.addFlashAttribute("groupNumber", saveProgramForm.getGroupNumber());
        String url = "viewProgram?programID=" + saveProgramForm.getProgramID();
        return "redirect:" + url;
    }

    private BusinessProgram performSave(SaveProgramForm saveProgramForm, ModelMap modelMap) throws Exception {
        /**
         String lUserID = getUserSessionSupport().getAuthenticatedUsername();
         BusinessProgram lBusinessProgram = populateBusinessProgramFromSaveProgramForm(saveProgramForm);
         businessProgramService.updateBusinessProgram(lBusinessProgram, lUserID);
         businessProgramService.updateEmployerGroupSite(lBusinessProgram, lUserID);
         **/

        String lUserID = getUserSessionSupport().getAuthenticatedUsername();
        String actionType = saveProgramForm.getActionType();
        String recalculate = saveProgramForm.getRecalculate();

        // When Editing an existing business program,
        // When the flag is set to Y, the date field is disabled on the page.
        // When the field is disabled, the value is not being set in the form.
        if (getUserSessionSupport().setupUserSession().getBusinessProgram() != null &&
                getUserSessionSupport().setupUserSession().getBusinessProgram().getMembershipProcessDate() != null &&
                getUserSessionSupport().setupUserSession().getBusinessProgram().getMembershipProcessFlag() != null &&
                getUserSessionSupport().setupUserSession().getBusinessProgram().getMembershipProcessFlag().endsWith("Y") &&
                saveProgramForm.getMembershipActivationDate() == null) {

            saveProgramForm.setMembershipActivationDate(fmt.format(getUserSessionSupport().setupUserSession().getBusinessProgram().getMembershipProcessDate()));
        }

        BusinessProgram lBusinessProgram = populateBusinessProgramFromSaveProgramForm(saveProgramForm);
        lBusinessProgram.setPackageID(getUserSessionSupport().setupUserSession().getBusinessProgram().getPackageID());
        EmployerGroup lEmployerGroup = new EmployerGroup();
        lBusinessProgram.setEmployerGroup(lEmployerGroup);
        lEmployerGroup.setGroupID(saveProgramForm.getGroupID());
        lEmployerGroup.setSubgroupID(saveProgramForm.getSubgroupID());
        lEmployerGroup.setGroupNumber(saveProgramForm.getGroupNumber());
        lEmployerGroup.setGroupName(saveProgramForm.getGroupName());
        lEmployerGroup.setGroupReportName(saveProgramForm.getGroupReportName() != null ? saveProgramForm.getGroupReportName() : saveProgramForm.getGroupName());
        lEmployerGroup.setGroupAbbreviatedName(saveProgramForm.getGroupAbbreviatedName() != null ? saveProgramForm.getGroupAbbreviatedName() : saveProgramForm.getGroupName());
        lEmployerGroup.setSiteReportName(saveProgramForm.getSiteReportName() != null ? saveProgramForm.getSiteReportName() : saveProgramForm.getSiteName());
        lEmployerGroup.setSiteAbbreviatedName(saveProgramForm.getSiteAbbreviatedName() != null ? saveProgramForm.getSiteAbbreviatedName() : saveProgramForm.getSiteName());
        lEmployerGroup.setNewHireDate(new java.sql.Date(fmt.parse(saveProgramForm.getNewHireDate()).getTime()));

        // Get the Site number and name for the email notification.
        // If coming from Copy Program, an available site was selected.
        if (getUserSessionSupport().setupUserSession().getAvailableSites() != null) {
            ArrayList<EmployerGroup> lAvailableSites = (ArrayList<EmployerGroup>) getUserSessionSupport().setupUserSession().getAvailableSites();
            for (int i = 0; i < lAvailableSites.size(); i++) {
                EmployerGroup lAvailableSite = (EmployerGroup) lAvailableSites.get(i);

                if (lAvailableSite.getSubgroupID().intValue() == saveProgramForm.getSubgroupID().intValue()) {
                    lEmployerGroup.setSiteNumber(lAvailableSite.getSiteNumber());
                    lEmployerGroup.setSiteName(lAvailableSite.getSiteName());
                }
            }

            // Add - Remove Sites may have populated the AvailableSites, and the site that was being
            // worked on may have been removed from the list. So try the form.
            if (lEmployerGroup.getSiteNumber() == null || lEmployerGroup.getSiteName() == null) {
                lEmployerGroup.setSiteNumber(saveProgramForm.getSiteNumber());
                lEmployerGroup.setSiteName(saveProgramForm.getSiteName());
            }

        } else { // If coming from Edit Program, the site is already on the form.
            lEmployerGroup.setSiteNumber(saveProgramForm.getSiteNumber());
            lEmployerGroup.setSiteName(saveProgramForm.getSiteName());
        }

        lBusinessProgram.setProgramID(saveProgramForm.getProgramID());
        lBusinessProgram.setProgramTypeCodeID(saveProgramForm.getProgramTypeCodeID());

        // Perform saves
        if(ACTION_SAVE.equals(actionType)) {
            // Save here
            businessProgramService.updateBusinessProgram(lBusinessProgram, lUserID);
            businessProgramService.updateEmployerGroupSite(lBusinessProgram, lUserID);

        } else if (ACTION_SAVE_TO_ALL_SITES.equals(actionType)) {
            saveToAllSites(lBusinessProgram, saveProgramForm, lUserID);
            businessProgramService.updateEmployerGroupSite(lBusinessProgram, lUserID);

        } else if (ACTION_SAVE_TO_SELECTED.equals(actionType)) {
            saveToSelectedSites(lBusinessProgram, modelMap);
            return lBusinessProgram;
        }
        businessProgramService.updateBusinessProgram(lBusinessProgram, lUserID);
        businessProgramService.updateEmployerGroupSite(lBusinessProgram, lUserID);

        // If this is not a Template.
        if (saveProgramForm.getGroupID().intValue() > 0) {
            // Compare with the existing Business Program to see if the date has changed.
            checkMembershipDateChange(getUserSessionSupport().setupUserSession().getBusinessProgram(), saveProgramForm);

            // EV 40748 The saveToAllSites method, calls notify membership data change.
            // Here, only call it for Action_Save.
            if ("save".equals(actionType)) {
                // Mark all the members of this biz program for a status re-caluclation
                businessProgramService.updateAllGroupSiteMembers(BPMAdminConstants.BPM_ADMIN_MEMBERSHIP_UPDATE_PRCS_ID, lBusinessProgram.getProgramID());
                // For the email notification, use the attributes of the newly created Business Program.
                setAndNotifyMembershipDateChange(lBusinessProgram
                        , businessProgramService
                        , memberService
                        , bpmAdminEmailUtility
                        , saveProgramForm.getMembershipActivationDate()
                        , hostName);
            }

            // Boolean indicates all programs and not just ACTIVEs.
            lBusinessProgram = businessProgramService.getBusinessProgram(lBusinessProgram.getProgramID(), true);

            getUserSessionSupport().setupUserSession().setBusinessPrograms((ArrayList<BusinessProgram>) businessProgramService.getActiveBusinessPrograms(saveProgramForm.getGroupNumber(), null));

        } else { // If Template, call getProgramTemplates.
            ArrayList<BusinessProgram> lBusinessPrograms = (ArrayList<BusinessProgram>) businessProgramService.getProgramTemplates(lBusinessProgram.getProgramID());
            lBusinessProgram = lBusinessPrograms.get(0);
        }

        ArrayList<EligibleActivity> lEligibleActivities = (ArrayList<EligibleActivity>) businessProgramService.getEligibleActivities(lBusinessProgram.getProgramID());
        ArrayList<Activity> lAvailableActivities = (ArrayList<Activity>) businessProgramService.getAvailableActivities(lBusinessProgram.getProgramID());
        ArrayList<ProgramIncentiveOption> lProgramIncentiveOptions = (ArrayList<ProgramIncentiveOption>) businessProgramService.getProgramIncentiveOptions(lBusinessProgram.getProgramID());
        ArrayList<AdditionalInformation> lAdditionalInfos = (ArrayList<AdditionalInformation>) businessProgramService.getAdditionalInfos(lBusinessProgram.getProgramID());
        ArrayList<AuthCode> lExtendedAuthCodes = (ArrayList<AuthCode>) businessProgramService.getExtendedAuthCodes(lBusinessProgram.getProgramID());

        getUserSessionSupport().setupUserSession().setEligibleActivities(lEligibleActivities);
        getUserSessionSupport().setupUserSession().setAvailableActivities(lAvailableActivities);
        getUserSessionSupport().setupUserSession().setProgramIncentiveOptions(lProgramIncentiveOptions);
        getUserSessionSupport().setupUserSession().setAdditionalInfos(lAdditionalInfos);
        getUserSessionSupport().setupUserSession().setExtendedAuthCodes(lExtendedAuthCodes);

        getUserSession().setBusinessProgram(lBusinessProgram);
        modelMap.put("businessPrograms", getUserSessionSupport().setupUserSession().getBusinessPrograms());
        modelMap.put("programTypes", getUserSessionSupport().setupUserSession().getProgramTypes());
        modelMap.put("participationList", getUserSessionSupport().setupUserSession().getParticipationList());
        modelMap.put("businessProgram", lBusinessProgram);
        modelMap.put("eligibleActivities", lEligibleActivities);
        modelMap.put("availableActivities", lAvailableActivities);
        modelMap.put("additionalInfos", lAdditionalInfos);
        modelMap.put("programIncentiveOptions", getUserSessionSupport().setupUserSession().getProgramIncentiveOptions());
        modelMap.put("qualificationCheckmarks", getUserSessionSupport().setupUserSession().getQualificationCheckmarks());
        modelMap.put("programCheckmarks", getUserSessionSupport().setupUserSession().getProgramCheckmarks());
        modelMap.put("extendedAuthCodes", lExtendedAuthCodes);
        modelMap.put("changeLogList", getUserSessionSupport().setupUserSession().getProgramChangeLogList());
        modelMap.put("benefitPackages", getUserSessionSupport().setupUserSession().getBenefitPackages());

        if (getUserSessionSupport().setupUserSession().getProgramPackages() == null) {
            getUserSessionSupport().setupUserSession().setProgramPackages((ArrayList<ProgramPackage>) businessProgramService.getProgramPackages());
        }

        modelMap.put("programPackages", getUserSessionSupport().setupUserSession().getProgramPackages());
        return lBusinessProgram;
    }

    private BusinessProgram populateBusinessProgramFromSaveProgramForm(SaveProgramForm saveProgramForm) throws ParseException {
        BusinessProgram lBusinessProgram = new BusinessProgram();
        EmployerGroup lEmployerGroup = new EmployerGroup();
        lBusinessProgram.setEmployerGroup(lEmployerGroup);

        lBusinessProgram.setProgramID(saveProgramForm.getProgramID());
        lBusinessProgram.setMembershipProcessDate(convertUIDateToSqlDate(saveProgramForm.getMembershipActivationDate()));
        lBusinessProgram.setMembershipProcessFlag("N");

        lBusinessProgram.setProgramName(saveProgramForm.getProgramName());

        lBusinessProgram.setEffectiveDate(convertUIDateToSqlDate(saveProgramForm.getEffectiveDate()));
        lBusinessProgram.setQualificationWindowStartDate(convertUIDateToSqlDate(saveProgramForm.getQualificationWindowStartDate()));
        lBusinessProgram.setReleaseDate(convertUIDateToSqlDate(saveProgramForm.getReleaseDate()));
        lEmployerGroup.setSubgroupID(saveProgramForm.getSubgroupID());
        lEmployerGroup.setSiteNumber(saveProgramForm.getSiteNumber());
        lEmployerGroup.setSiteName(saveProgramForm.getSiteName());

        lEmployerGroup.setGroupID(saveProgramForm.getGroupID());
        lEmployerGroup.setGroupNumber(saveProgramForm.getGroupNumber());
        lEmployerGroup.setGroupName(saveProgramForm.getGroupName());
        lEmployerGroup.setSubgroupID(saveProgramForm.getSubgroupID());

        lEmployerGroup.setGroupReportName(saveProgramForm.getGroupName());
        lEmployerGroup.setGroupAbbreviatedName(saveProgramForm.getGroupAbbreviatedName());
        lEmployerGroup.setSiteReportName(saveProgramForm.getSiteReportName());
        lEmployerGroup.setSiteAbbreviatedName(saveProgramForm.getSiteAbbreviatedName());

        lEmployerGroup.setNewHireDate(convertUIDateToSqlDate(saveProgramForm.getNewHireDate()));
        lBusinessProgram.setEndDate(convertUIDateToSqlDate(saveProgramForm.getEndDate()));
        lBusinessProgram.setQualificationWindowEndDate(convertUIDateToSqlDate(saveProgramForm.getQualificationWindowEndDate()));
        lBusinessProgram.setStatusCalcEndDate(convertUIDateToSqlDate(saveProgramForm.getStatusCalcEndDate()));
        lBusinessProgram.setContributionStartDate(convertUIDateToSqlDate(saveProgramForm.getEffectiveDate()));
        lBusinessProgram.setContributionEndDate(convertUIDateToSqlDate(saveProgramForm.getContributionEndDate()));

        lBusinessProgram.setProgramTypeCodeID(saveProgramForm.getProgramTypeCodeID());
        lBusinessProgram.setFamilyParticipationRequirement(saveProgramForm.getFamilyParticipationRequirement());
        lBusinessProgram.setAdditionalGroupProgramInfo(saveProgramForm.getAdditionalGroupProgramInfo());
        lBusinessProgram.setProgramStatusCodeID(saveProgramForm.getProgramStatusCodeID());
        lBusinessProgram.setQualificationCheckmarkID(saveProgramForm.getQualificationCheckmarkID());
        lBusinessProgram.setReportIndicatorCodeID(saveProgramForm.getReportIndicatorCodeID());

        return lBusinessProgram;
    }

    private SaveProgramForm populateSaveProgramForm(BusinessProgram lBusinessProgram) throws BPMException {
        SaveProgramForm saveProgramForm = new SaveProgramForm();
        saveProgramForm.setProgramID(lBusinessProgram.getProgramID());
        saveProgramForm.setProgramName(lBusinessProgram.getProgramName());
        saveProgramForm.setProgramStatusCodeID(lBusinessProgram.getProgramStatusCodeID());
        saveProgramForm.setActivationCodes(getUserSession().getActivationCodes());
        saveProgramForm.setGroupID(lBusinessProgram.getEmployerGroup().getGroupID());
        saveProgramForm.setGroupNumber(lBusinessProgram.getEmployerGroup().getGroupNumber());
        saveProgramForm.setSiteName(lBusinessProgram.getEmployerGroup().getSiteName());
        saveProgramForm.setSiteNumber(lBusinessProgram.getEmployerGroup().getSiteNumber());
        saveProgramForm.setGroupName(lBusinessProgram.getEmployerGroup().getGroupName());
        saveProgramForm.setGroupReportName(lBusinessProgram.getEmployerGroup().getGroupReportName());
        saveProgramForm.setGroupAbbreviatedName(lBusinessProgram.getEmployerGroup().getGroupAbbreviatedName());
        saveProgramForm.setSiteReportName(lBusinessProgram.getEmployerGroup().getSiteReportName());
        saveProgramForm.setSiteAbbreviatedName(lBusinessProgram.getEmployerGroup().getSiteAbbreviatedName());
        saveProgramForm.setReleaseDate(fmt.format(lBusinessProgram.getReleaseDate()));
        saveProgramForm.setStatusCalcEndDate(fmt.format(lBusinessProgram.getStatusCalcEndDate()));
        saveProgramForm.setQualificationWindowStartDate(fmt.format(lBusinessProgram.getQualificationWindowStartDate()));
        saveProgramForm.setEffectiveDate(fmt.format(lBusinessProgram.getEffectiveDate()));
        saveProgramForm.setQualificationWindowEndDate(fmt.format(lBusinessProgram.getQualificationWindowEndDate()));
        saveProgramForm.setEndDate(fmt.format(lBusinessProgram.getEndDate()));
        saveProgramForm.setNewHireDate(fmt.format(lBusinessProgram.getEmployerGroup().getNewHireDate()));
        // Also set the MembershipProcess Date and Flag to null. That date will be communicated
        // from membership later in the year, every year.
        saveProgramForm.setMembershipActivationDate(null);
        saveProgramForm.setMembershipActivationFlag(false);
        saveProgramForm.setContributionStartDate(fmt.format(lBusinessProgram.getContributionStartDate()));
        saveProgramForm.setContributionEndDate(fmt.format(lBusinessProgram.getContributionEndDate()));
        saveProgramForm.setFamilyParticipationRequirement(lBusinessProgram.getFamilyParticipationRequirement());

        if (CollectionUtils.isEmpty(getUserSession().getActivationCodes())) {
            ArrayList<LookUpValueCode> lActivationCodes = (ArrayList<LookUpValueCode>) businessProgramService.getProgramActivationCodes();
            getUserSession().setActivationCodes(lActivationCodes);
        }

        if (CollectionUtils.isEmpty(getUserSession().getParticipationList())) {
            ArrayList<LookUpValueCode> lParticipationList = (ArrayList<LookUpValueCode>) businessProgramService.getParticipationCodes();
            getUserSession().setParticipationList(lParticipationList);
        }

        if (CollectionUtils.isEmpty(getUserSession().getProgramSpecialReportHandlingCodes())) {
            ArrayList<LookUpValueCode> lProgramSpecialReportHandlingCodes = (ArrayList<LookUpValueCode>) businessProgramService.getProgramSpecialReportHandlingCodes();
            getUserSession().setProgramSpecialReportHandlingCodes(lProgramSpecialReportHandlingCodes);
        }

        if (CollectionUtils.isEmpty(getUserSession().getAvailableSites())) {
            ArrayList<EmployerGroup> availableSites = (ArrayList<EmployerGroup>) businessProgramService.getSubGroups(lBusinessProgram.getEmployerGroup().getGroupID());
            getUserSession().setAvailableSites(availableSites);
        }

        saveProgramForm.setParticipationList(getUserSession().getParticipationList());
        saveProgramForm.setReportIndicatorList(getUserSession().getProgramSpecialReportHandlingCodes());
        saveProgramForm.setAvailableSites(getUserSession().getAvailableSites());

        saveProgramForm.setReportIndicatorCodeID(lBusinessProgram.getReportIndicatorCodeID());
        saveProgramForm.setReportIndicatorCodeValue(lBusinessProgram.getReportIndicatorCodeValue());

        saveProgramForm.setProgramTypeCodeID(lBusinessProgram.getProgramTypeCodeID());
        saveProgramForm.setProgramStatusCodeID(lBusinessProgram.getProgramStatusCodeID());
        saveProgramForm.setQualificationCheckmarkID(lBusinessProgram.getQualificationCheckmarkID() != null ? lBusinessProgram.getQualificationCheckmarkID() : 0);
        saveProgramForm.setSubgroupID(lBusinessProgram.getEmployerGroup().getSubgroupID());

        saveProgramForm.setAdditionalGroupProgramInfo(lBusinessProgram.getAdditionalGroupProgramInfo());

        return saveProgramForm;
    }

    private void loadFormSelects(SaveProgramForm form) throws BPMException {
        // Program Status
        if (CollectionUtils.isEmpty(getUserSession().getActivationCodes())) {
            ArrayList<LookUpValueCode> lActivationCodes = (ArrayList<LookUpValueCode>) businessProgramService.getProgramActivationCodes();
            getUserSession().setActivationCodes(lActivationCodes);
        }

        if (CollectionUtils.isEmpty(getUserSession().getParticipationList())) {
            ArrayList<LookUpValueCode> lParticipationList = (ArrayList<LookUpValueCode>) businessProgramService.getParticipationCodes();
            getUserSession().setParticipationList(lParticipationList);
        }

        if (CollectionUtils.isEmpty(getUserSession().getProgramSpecialReportHandlingCodes())) {
            ArrayList<LookUpValueCode> lProgramSpecialReportHandlingCodes = (ArrayList<LookUpValueCode>) businessProgramService.getProgramSpecialReportHandlingCodes();
            getUserSession().setProgramSpecialReportHandlingCodes(lProgramSpecialReportHandlingCodes);
        }

        form.setActivationCodes(getUserSession().getActivationCodes());
        form.setParticipationList(getUserSession().getParticipationList());
        form.setReportIndicatorList(getUserSession().getProgramSpecialReportHandlingCodes());
    }

    // If the membership process date has changed, record in the Audit Log table.
    private void checkMembershipDateChange(BusinessProgram businessProgram, SaveProgramForm saveProgramForm) {
        String membershipProcessDateInDB = null;
        String membershipActivationDateInForm = null;

        if (getUserSessionSupport().setupUserSession().getBusinessProgram() != null &&
                getUserSessionSupport().setupUserSession().getBusinessProgram().getMembershipProcessDate() != null) {
            membershipProcessDateInDB = BPMAdminUtils.formatDateMMddyyyy(getUserSessionSupport().setupUserSession().getBusinessProgram().getMembershipProcessDate());
        }

        if (saveProgramForm.getMembershipActivationDate() != null) {
            membershipActivationDateInForm = saveProgramForm.getMembershipActivationDate();
        }

        if ((membershipActivationDateInForm != null && membershipProcessDateInDB == null) ||
                (membershipActivationDateInForm != null && membershipProcessDateInDB != null && !membershipActivationDateInForm.equals(membershipProcessDateInDB))) {
            // Membership process date was set or edited.
            // Record in the Audit Log table.
            BPMAuditRecord bpmAuditRecord = new BPMAuditRecord();
            bpmAuditRecord.setApplicationId(getUserSessionSupport().getAuthenticatedUsername());
            bpmAuditRecord.setEventResult("SUCCESS");
            bpmAuditRecord.setParam4("Group:" + businessProgram.getEmployerGroup().getGroupNumber()
                    + ", Site:"
                    + businessProgram.getEmployerGroup().getSiteNumber()
                    + ", Process date changed from " + membershipProcessDateInDB
                    + " to " + membershipActivationDateInForm);
            bpmAuditRecord.setApplicationEvent("processMbrShipFeedCommand");
            this.createAuditEventLogEntry(bpmAuditRecord);
        }
    }

    private Integer createAuditEventLogEntry(BPMAuditRecord bpmAuditRecord) {
        Integer auditLogId = null;

        try {
            auditLogId = auditLogDAO.insertAuditLog(bpmAuditRecord);
        } catch (Exception e) {
            logger.error("Error writing AuditEventLogEntry " + e);
        }

        return auditLogId;
    }

    protected void setAndNotifyMembershipDateChange(BusinessProgram businessProgram, BusinessProgramService businessProgramService, MemberService memberService, BPMAdminEmailUtility bpmAdminEmailUtility, String pMembershipActivationDate, String hostName) throws Exception {
        if (pMembershipActivationDate != null &&
                pMembershipActivationDate.trim().length() > 0) {
            //This statement moved to main method right before update to Business Program DAO.
            //businessProgram.setMembershipProcessDate(new java.sql.Date(fmt.parse(saveProgramForm.getMembershipActivationDate()).getTime()));

            // If Membership Process Date is within 2 days of Today, send a email notification
            // to Membership.
            Calendar lToday = Calendar.getInstance();
            Calendar lMembershipActivationDate = Calendar.getInstance();
            lMembershipActivationDate.setTime(new java.util.Date(businessProgram.getMembershipProcessDate().getTime()));

            if (BPMAdminUtils.getDaysBetweenDates(lMembershipActivationDate, lToday) <= 1) {
                // Send an email notification
                Integer lNumberOfQualifieds = businessProgramService.getContractStatusCount(BPMAdminConstants.BPM_ADMIN_CONTRACT_STATUS_QUALIFIED, businessProgram.getProgramID());

                Integer lNumberOfNotQualifieds = businessProgramService.getContractStatusCount(BPMAdminConstants.BPM_ADMIN_CONTRACT_STATUS_DID_NOT_QUALIFIY, businessProgram.getProgramID());

                prepareAndSendSummaryEmail(businessProgram
                        , memberService
                        , bpmAdminEmailUtility
                        , lNumberOfQualifieds
                        , lNumberOfNotQualifieds
                        , hostName);
            }
        }
    }

    /**
     * @param pBusinessProgram
     * @param pUserID
     * @throws Exception
     */
    protected void saveToAllSites(BusinessProgram pBusinessProgram, SaveProgramForm pSaveProgramForm, String pUserID) throws Exception {
        Collection<EmployerGroup> lEmployerGroups = businessProgramService.getSubGroups(pBusinessProgram.getEmployerGroup().getGroupID());

        Integer lCurrentSubgroupID = pSaveProgramForm.getSubgroupID();

        for (EmployerGroup lEmployerGroup : lEmployerGroups) {
            BusinessProgram lBusinessProgram = populateBusinessProgramFromSaveProgramForm(pSaveProgramForm);
            lBusinessProgram.setEmployerGroup(lEmployerGroup);

            ArrayList<BusinessProgram> lExistingPrograms = (ArrayList<BusinessProgram>)
                    businessProgramService.getBusinessPrograms(lBusinessProgram.getEffectiveDate(), lEmployerGroup.getGroupID(), lEmployerGroup.getSubgroupID());

            if (lExistingPrograms != null && lExistingPrograms.size() > 0) {
                lBusinessProgram.setProgramID(lExistingPrograms.get(0).getProgramID());
                lBusinessProgram.setPackageID(lExistingPrograms.get(0).getPackageID());

                businessProgramService.updateBusinessProgram(lBusinessProgram, pUserID);
                businessProgramService.updateAllGroupSiteMembers(BPMAdminConstants.BPM_ADMIN_MEMBERSHIP_UPDATE_PRCS_ID, lBusinessProgram.getProgramID());
                // EV 40748 For the email notification, use the attributes of the newly created Business Program.
                setAndNotifyMembershipDateChange(lBusinessProgram
                        , businessProgramService
                        , memberService
                        , bpmAdminEmailUtility
                        , pSaveProgramForm.getMembershipActivationDate()
                        , hostName);

                // Now that this program has been saved, it has a database programID.
                // Find it's subgroup and assign it's programID to the one from the form.
                if (lCurrentSubgroupID.intValue() == lBusinessProgram.getEmployerGroup().getSubgroupID().intValue()) {
                    pBusinessProgram.setProgramID(lBusinessProgram.getProgramID());
                }
            }
        }
    }

    private void saveToSelectedSites(BusinessProgram pBusinessProgram, ModelMap modelMap) throws Exception {
        if (getUserSession().getAvailableSites() != null) {
            getUserSession().getAvailableSites().clear();
        }

        if (getUserSession().getEmployerSubGroups() != null) {
            getUserSession().getEmployerSubGroups().clear();
        }

        Collection<EmployerGroup> lSubGroups = businessProgramService.getBusinessProgramInSameYear(getUserSession().getBusinessProgram().getProgramID());

        modelMap.put("businessProgram", pBusinessProgram);
        modelMap.put("selectedSubGroups", lSubGroups);

        getUserSession().setBusinessProgram(pBusinessProgram);
        getUserSession().setEmployerSubGroups((ArrayList<EmployerGroup>) lSubGroups);
        getUserSession().setWhichSaveSelectedSite(WHICH_SAVE_SELECTED_SITES_BIZ_PROGRAM);
    }

    @Override
    public boolean supports(Class<?> clazz) {
        return CreateProgramForm.class.isAssignableFrom(clazz);
    }

    @Override
    public void validate(Object target, Errors errors) {
        SaveProgramForm form = (SaveProgramForm) target;
        programValidationService.validateSaveProgram(form, errors);
    }

}
