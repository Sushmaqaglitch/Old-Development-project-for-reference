package com.healthpartners.app.bpm.dto;

import java.io.Serializable;
import java.util.ArrayList;

public class TemplateIncentiveOption implements Serializable {
    static final long serialVersionUID = 0L;

    private Integer programID;
    private Integer incentiveOptionID;
    private Integer programIncentiveOptionID;

    private Integer incentiveOptionTypeCodeID;
    private Integer incentiveOptionTypeCode;

    private String incentiveOptionName;
    private String incentiveOptionType;

    private Integer effectiveDateMonth;
    private Integer effectiveDateDay;
    private Integer endDateMonth;
    private Integer endDateDay;

    private String enrollmentDeadlineDateMonth;
    private String enrollmentDeadlineDateDay;

    private Integer completionDateMonth;
    private Integer completionDateDay;

    private Integer activationDateMonth;
    private Integer activationDateDay;

    private Integer deliveryDateMonth;
    private Integer deliveryDateDay;

    private IncentiveOption incentiveOption;


    private String incentiveOptionInfo;
    private String incentiveOptionAddInfo;

    private String incentiveOptionDeliveryInfo;

    private Integer programIncentiveFulfillReqID;
    private Integer programIncentiveReportNameID;
    private Integer incentedStatusTypeCodeID;
    private Integer incentiveRuleTypeCodeID;
    private Integer incentiveParticipationGroupID;
    private Integer incentiveOptionStatusCodeID;

    private String incentiveOptionStatusCode;
    private String incentiveReportNameCode;
    private String incentiveFulfillmentCode;
    private String incentedStatusTypeCode;
    private String incentiveRuleTypeCode;
    private String incentiveParticipationGroupName;
    private String incentiveParticipationGroupInfo;

    private String participantCap;
    private String familyCap;

    private String activityCompletionPeriod;

    private Integer newHireDateMonth;
    private Integer newHireDateDay;

    private Integer unitTypeCodeID;
    private String unitTypeDesc;

    private Integer runFrequencyID;
    private String runFrequencyDesc;

    private Integer incentiveOptionRewardCardID;
    private String incentiveOptionRewardCardDesc;

    private Integer packageRuleGroupID;
    private String packageRuleGroupName;

    private ArrayList<ProgramCheckmarkIncentiveOption> programCheckmarkIncentiveOptions;

    private Integer deliveryInfoID;
    private String deliveryInfoDesc;

    public TemplateIncentiveOption() {
        super();
    }


    public Integer getProgramID() {
        return programID;
    }

    public void setProgramID(Integer programID) {
        this.programID = programID;
    }

    public Integer getIncentiveOptionID() {
        return incentiveOptionID;
    }

    public void setIncentiveOptionID(Integer incentiveOptionID) {
        this.incentiveOptionID = incentiveOptionID;
    }

    public Integer getEffectiveDateMonth() {
        return effectiveDateMonth;
    }


    public void setEffectiveDateMonth(Integer effectiveDateMonth) {
        this.effectiveDateMonth = effectiveDateMonth;
    }

    public Integer getEffectiveDateDay() {
        return effectiveDateDay;
    }

    public void setEffectiveDateDay(Integer effectiveDateDay) {
        this.effectiveDateDay = effectiveDateDay;
    }

    public Integer getEndDateMonth() {
        return endDateMonth;
    }

    public void setEndDateMonth(Integer endDateMonth) {
        this.endDateMonth = endDateMonth;
    }

    public Integer getEndDateDay() {
        return endDateDay;
    }

    public void setEndDateDay(Integer endDateDay) {
        this.endDateDay = endDateDay;
    }

    public Integer getActivationDateMonth() {
        return activationDateMonth;
    }

    public void setActivationDateMonth(Integer activationDateMonth) {
        this.activationDateMonth = activationDateMonth;
    }

    public Integer getActivationDateDay() {
        return activationDateDay;
    }

    public void setActivationDateDay(Integer activationDateDay) {
        this.activationDateDay = activationDateDay;
    }

    public Integer getDeliveryDateMonth() {
        return deliveryDateMonth;
    }

    public void setDeliveryDateMonth(Integer deliveryDateMonth) {
        this.deliveryDateMonth = deliveryDateMonth;
    }

    public Integer getDeliveryDateDay() {
        return deliveryDateDay;
    }

    public void setDeliveryDateDay(Integer deliveryDateDay) {
        this.deliveryDateDay = deliveryDateDay;
    }

    public Integer getCompletionDateMonth() {
        return completionDateMonth;
    }

    public void setCompletionDateMonth(Integer completionDateMonth) {
        this.completionDateMonth = completionDateMonth;
    }

    public Integer getCompletionDateDay() {
        return completionDateDay;
    }

    public void setCompletionDateDay(Integer completionDateDay) {
        this.completionDateDay = completionDateDay;
    }


    public String getIncentiveOptionName() {
        return incentiveOptionName;
    }


    public void setIncentiveOptionName(String incentiveOptionName) {
        this.incentiveOptionName = incentiveOptionName;
    }


    public String getIncentiveOptionType() {
        return incentiveOptionType;
    }


    public void setIncentiveOptionType(String incentiveOptionType) {
        this.incentiveOptionType = incentiveOptionType;
    }


    public Integer getIncentiveOptionTypeCodeID() {
        return incentiveOptionTypeCodeID;
    }


    public void setIncentiveOptionTypeCodeID(Integer incentiveOptionTypeCodeID) {
        this.incentiveOptionTypeCodeID = incentiveOptionTypeCodeID;
    }


    public IncentiveOption getIncentiveOption() {
        return incentiveOption;
    }


    public void setIncentiveOption(IncentiveOption incentiveOption) {
        this.incentiveOption = incentiveOption;
    }


    public Integer getIncentiveOptionTypeCode() {
        return incentiveOptionTypeCode;
    }


    public void setIncentiveOptionTypeCode(Integer incentiveOptionTypeCode) {
        this.incentiveOptionTypeCode = incentiveOptionTypeCode;
    }


    public String getIncentiveOptionInfo() {
        return incentiveOptionInfo;
    }


    public void setIncentiveOptionInfo(String incentiveOptionInfo) {
        this.incentiveOptionInfo = incentiveOptionInfo;
    }


    public String getIncentiveOptionAddInfo() {
        return incentiveOptionAddInfo;
    }


    public void setIncentiveOptionAddInfo(String incentiveOptionAddInfo) {
        this.incentiveOptionAddInfo = incentiveOptionAddInfo;
    }


    public String getIncentiveOptionDeliveryInfo() {
        return incentiveOptionDeliveryInfo;
    }


    public void setIncentiveOptionDeliveryInfo(String incentiveOptionDeliveryInfo) {
        this.incentiveOptionDeliveryInfo = incentiveOptionDeliveryInfo;
    }


    public Integer getProgramIncentiveFulfillReqID() {
        return programIncentiveFulfillReqID;
    }


    public void setProgramIncentiveFulfillReqID(Integer programIncentiveFulfillReqID) {
        this.programIncentiveFulfillReqID = programIncentiveFulfillReqID;
    }


    public Integer getProgramIncentiveReportNameID() {
        return programIncentiveReportNameID;
    }


    public void setProgramIncentiveReportNameID(Integer programIncentiveReportNameID) {
        this.programIncentiveReportNameID = programIncentiveReportNameID;
    }


    public Integer getIncentedStatusTypeCodeID() {
        return incentedStatusTypeCodeID;
    }


    public void setIncentedStatusTypeCodeID(Integer incentedStatusTypeCodeID) {
        this.incentedStatusTypeCodeID = incentedStatusTypeCodeID;
    }


    public Integer getIncentiveRuleTypeCodeID() {
        return incentiveRuleTypeCodeID;
    }


    public void setIncentiveRuleTypeCodeID(Integer incentiveRuleTypeCodeID) {
        this.incentiveRuleTypeCodeID = incentiveRuleTypeCodeID;
    }

    public String getParticipantCap() {
        return participantCap;
    }

    public void setParticipantCap(String participantCap) {
        this.participantCap = participantCap;
    }

    public String getFamilyCap() {
        return familyCap;
    }


    public void setFamilyCap(String familyCap) {
        this.familyCap = familyCap;
    }


    public String getIncentiveOptionStatusCode() {
        return incentiveOptionStatusCode;
    }


    public void setIncentiveOptionStatusCode(String incentiveOptionStatusCode) {
        this.incentiveOptionStatusCode = incentiveOptionStatusCode;
    }


    public String getIncentiveReportNameCode() {
        return incentiveReportNameCode;
    }


    public void setIncentiveReportNameCode(String incentiveReportNameCode) {
        this.incentiveReportNameCode = incentiveReportNameCode;
    }


    public String getIncentiveFulfillmentCode() {
        return incentiveFulfillmentCode;
    }


    public void setIncentiveFulfillmentCode(String incentiveFulfillmentCode) {
        this.incentiveFulfillmentCode = incentiveFulfillmentCode;
    }


    public String getIncentedStatusTypeCode() {
        return incentedStatusTypeCode;
    }


    public void setIncentedStatusTypeCode(String incentedStatusTypeCode) {
        this.incentedStatusTypeCode = incentedStatusTypeCode;
    }


    public String getIncentiveRuleTypeCode() {
        return incentiveRuleTypeCode;
    }


    public void setIncentiveRuleTypeCode(String incentiveRuleTypeCode) {
        this.incentiveRuleTypeCode = incentiveRuleTypeCode;
    }


    public Integer getIncentiveParticipationGroupID() {
        return incentiveParticipationGroupID;
    }


    public void setIncentiveParticipationGroupID(Integer incentiveParticipationGroupID) {
        this.incentiveParticipationGroupID = incentiveParticipationGroupID;
    }


    public String getIncentiveParticipationGroupName() {
        return incentiveParticipationGroupName;
    }


    public void setIncentiveParticipationGroupName(String incentiveParticipationGroupName) {
        this.incentiveParticipationGroupName = incentiveParticipationGroupName;
    }


    public Integer getIncentiveOptionStatusCodeID() {
        return incentiveOptionStatusCodeID;
    }


    public void setIncentiveOptionStatusCodeID(Integer incentiveOptionStatusCodeID) {
        this.incentiveOptionStatusCodeID = incentiveOptionStatusCodeID;
    }


    public String getEnrollmentDeadlineDateMonth() {
        return enrollmentDeadlineDateMonth;
    }


    public void setEnrollmentDeadlineDateMonth(String enrollmentDeadlineDateMonth) {
        this.enrollmentDeadlineDateMonth = enrollmentDeadlineDateMonth;
    }


    public String getEnrollmentDeadlineDateDay() {
        return enrollmentDeadlineDateDay;
    }


    public void setEnrollmentDeadlineDateDay(String enrollmentDeadlineDateDay) {
        this.enrollmentDeadlineDateDay = enrollmentDeadlineDateDay;
    }


    public String getActivityCompletionPeriod() {
        return activityCompletionPeriod;
    }


    public void setActivityCompletionPeriod(String activityCompletionPeriod) {
        this.activityCompletionPeriod = activityCompletionPeriod;
    }


    public ArrayList<ProgramCheckmarkIncentiveOption> getProgramCheckmarkIncentiveOptions() {
        return programCheckmarkIncentiveOptions;
    }


    public void setProgramCheckmarkIncentiveOptions(ArrayList<ProgramCheckmarkIncentiveOption> programCheckmarkIncentiveOptions) {
        this.programCheckmarkIncentiveOptions = programCheckmarkIncentiveOptions;
    }


    public Integer getProgramIncentiveOptionID() {
        return programIncentiveOptionID;
    }


    public void setProgramIncentiveOptionID(Integer programIncentiveOptionID) {
        this.programIncentiveOptionID = programIncentiveOptionID;
    }


    public Integer getNewHireDateMonth() {
        return newHireDateMonth;
    }


    public void setNewHireDateMonth(Integer newHireDateMonth) {
        this.newHireDateMonth = newHireDateMonth;
    }


    public Integer getNewHireDateDay() {
        return newHireDateDay;
    }


    public void setNewHireDateDay(Integer newHireDateDay) {
        this.newHireDateDay = newHireDateDay;
    }


    public final Integer getUnitTypeCodeID() {
        return unitTypeCodeID;
    }


    public final void setUnitTypeCodeID(Integer unitTypeCodeID) {
        this.unitTypeCodeID = unitTypeCodeID;
    }


    public final String getUnitTypeDesc() {
        return unitTypeDesc;
    }


    public final void setUnitTypeDesc(String unitTypeDesc) {
        this.unitTypeDesc = unitTypeDesc;
    }


    public final Integer getRunFrequencyID() {
        return runFrequencyID;
    }


    public final void setRunFrequencyID(Integer runFrequencyID) {
        this.runFrequencyID = runFrequencyID;
    }


    public final String getRunFrequencyDesc() {
        return runFrequencyDesc;
    }


    public final void setRunFrequencyDesc(String runFrequencyDesc) {
        this.runFrequencyDesc = runFrequencyDesc;
    }


    public final Integer getIncentiveOptionRewardCardID() {
        return incentiveOptionRewardCardID;
    }


    public final void setIncentiveOptionRewardCardID(Integer incentiveOptionRewardCardID) {
        this.incentiveOptionRewardCardID = incentiveOptionRewardCardID;
    }


    public final String getIncentiveOptionRewardCardDesc() {
        return incentiveOptionRewardCardDesc;
    }


    public final void setIncentiveOptionRewardCardDesc(String incentiveOptionRewardCardDesc) {
        this.incentiveOptionRewardCardDesc = incentiveOptionRewardCardDesc;
    }


    public final Integer getPackageRuleGroupID() {
        return packageRuleGroupID;
    }


    public final void setPackageRuleGroupID(Integer packageRuleGroupID) {
        this.packageRuleGroupID = packageRuleGroupID;
    }


    public final String getPackageRuleGroupName() {
        return packageRuleGroupName;
    }


    public final void setPackageRuleGroupName(String packageRuleGroupName) {
        this.packageRuleGroupName = packageRuleGroupName;
    }


    public final Integer getDeliveryInfoID() {
        return deliveryInfoID;
    }


    public final void setDeliveryInfoID(Integer deliveryInfoID) {
        this.deliveryInfoID = deliveryInfoID;
    }


    public final String getDeliveryInfoDesc() {
        return deliveryInfoDesc;
    }


    public final void setDeliveryInfoDesc(String deliveryInfoDesc) {
        this.deliveryInfoDesc = deliveryInfoDesc;
    }


    public String getIncentiveParticipationGroupInfo() {
        return incentiveParticipationGroupInfo;
    }


    public void setIncentiveParticipationGroupInfo(String incentiveParticipationGroupInfo) {
        this.incentiveParticipationGroupInfo = incentiveParticipationGroupInfo;
    }


}
