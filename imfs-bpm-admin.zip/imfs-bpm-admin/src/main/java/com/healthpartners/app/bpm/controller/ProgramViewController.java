package com.healthpartners.app.bpm.controller;

import com.healthpartners.app.bpm.common.BPMAdminConstants;
import com.healthpartners.app.bpm.dto.*;
import com.healthpartners.app.bpm.form.CreateProgramForm;
import com.healthpartners.app.bpm.form.EditProgramForm;
import com.healthpartners.app.bpm.iface.BusinessProgramService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import jakarta.servlet.http.HttpServletRequest;
import java.util.ArrayList;

import static org.apache.commons.lang.exception.ExceptionUtils.getStackTrace;

@Controller
public class ProgramViewController extends BaseController implements Validator {
    private final BusinessProgramService businessProgramService;

    public ProgramViewController(BusinessProgramService businessProgramService) {
        this.businessProgramService = businessProgramService;
    }

    @GetMapping("/viewProgram")
    public String viewProgram(@RequestParam(name = "programID") Integer programID, ModelMap modelMap, HttpServletRequest request) throws Exception {
        EditProgramForm form = new EditProgramForm();
        modelMap.put("editProgramForm", form);
        try {
            String lTemplate = request.getParameter("template");
            String lMemberID = request.getParameter("memberID");

            if (lMemberID != null) {
                getUserSession().setMemberId(lMemberID);
                modelMap.put("memberID", lMemberID);
            }

            loadViewProgram(modelMap, form, programID, lTemplate);
        } catch (Exception e) {
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
            // Add error stack trace on the request, to be hidden in html.
            createErrorMessageOnModel(modelMap, getStackTrace(e));
        }
        return "viewProgram";
    }

    private void loadViewProgram(ModelMap modelMap, EditProgramForm form, Integer lProgramID , String lTemplate) throws Exception {
        BusinessProgram businessProgram;

        if (BPMAdminConstants.BPM_ADMIN_TRUE.equalsIgnoreCase(lTemplate)) {
            ArrayList<BusinessProgram> lBusinessPrograms = (ArrayList<BusinessProgram>) businessProgramService.getProgramTemplates(lProgramID);
            businessProgram = lBusinessPrograms.get(0);
        } else {
            // Boolean indicates all programs and not just ACTIVEs.
            // Just retrieve ACTIVEs.
            businessProgram = businessProgramService.getBusinessProgram(lProgramID, false);
        }

        ArrayList<EligibleActivity> lEligibleActivities = (ArrayList<EligibleActivity>) businessProgramService.getEligibleActivities(lProgramID);

        // Don't reset everything in case they hit cancel.
        if (getUserSession().getEligibleActivities() != null) {
            getUserSession().getEligibleActivities().clear();
        }
        getUserSession().setEligibleActivities(lEligibleActivities);

        ArrayList<ProgramIncentiveOption> lProgramIncentiveOptions = (ArrayList<ProgramIncentiveOption>) businessProgramService.getProgramIncentiveOptions(lProgramID);
        if (CollectionUtils.isEmpty(lProgramIncentiveOptions)) {
            lProgramIncentiveOptions = new ArrayList<>();
        }

        if (getUserSession().getProgramIncentiveOptions() != null) {
            getUserSession().getProgramIncentiveOptions().clear();
        }
        getUserSession().setProgramIncentiveOptions(lProgramIncentiveOptions);

        ArrayList<AdditionalInformation> lAdditionalInfos = (ArrayList<AdditionalInformation>) businessProgramService.getAdditionalInfos(lProgramID);
        ArrayList<AuthCode> lExtendedAuthCodes = (ArrayList<AuthCode>) businessProgramService.getExtendedAuthCodes(lProgramID);

        if (getUserSession().getAdditionalInfos() != null) {
            getUserSession().getAdditionalInfos().clear();
        }
        getUserSession().setAdditionalInfos(lAdditionalInfos);

        if (getUserSession().getExtendedAuthCodes() != null) {
            getUserSession().getExtendedAuthCodes().clear();
        }
        getUserSession().setExtendedAuthCodes(lExtendedAuthCodes);

        ArrayList<ProgramActivityIncentiveSummary> lProgramActivityIncentivesSummary = getUserSession().getProgramActivityIncentivesSummary();

        if (lProgramActivityIncentivesSummary == null) {
            lProgramActivityIncentivesSummary = (ArrayList<ProgramActivityIncentiveSummary>) businessProgramService.getProgramActivityIncentivesSummaryWithRequirements(lProgramID);
        }

        ArrayList<ProgramCheckmark> lProgramCheckmarks = businessProgramService.getProgramCheckmarks(lProgramID);
        if (CollectionUtils.isEmpty(lProgramCheckmarks)) {
            lProgramCheckmarks = new ArrayList<>();
        }
        if (getUserSession().getProgramCheckmarks() != null) {
            getUserSession().getProgramCheckmarks().clear();
        }

        getUserSession().setProgramCheckmarks(lProgramCheckmarks);

        ArrayList<Integer> lDistinctQualificationCheckmkarkIDs = new ArrayList<>();
        ArrayList<QualificationCheckmark> lThisBizProgramQualificationCheckmarks = new ArrayList<>();
        for (ProgramCheckmark lProgramCheckmark : lProgramCheckmarks) {
            lProgramCheckmark.setCheckmarkRequirements((ArrayList<CheckmarkRequirement>) businessProgramService.getCheckmarkRequirements((lProgramCheckmark.getQualificationCheckmarkID())));

            if (!lDistinctQualificationCheckmkarkIDs.contains(lProgramCheckmark.getQualificationCheckmarkID())) {
                lDistinctQualificationCheckmkarkIDs.add(lProgramCheckmark.getQualificationCheckmarkID());
                QualificationCheckmark lQualificationCheckmark = new QualificationCheckmark();
                lQualificationCheckmark.setQualificationCheckmarkName(lProgramCheckmark.getQualificationCheckmarkName());
                lQualificationCheckmark.setCheckmarkRequirements(lProgramCheckmark.getCheckmarkRequirements());
                lThisBizProgramQualificationCheckmarks.add(lQualificationCheckmark);
            }
        }
        getUserSession().setQualificationCheckmarks(lThisBizProgramQualificationCheckmarks);
        ArrayList<ParticipationGroup> lParticipationGroups = (ArrayList<ParticipationGroup>) businessProgramService.getParticipationGroups();
        getUserSession().setParticipationGroups(lParticipationGroups);
        ArrayList<IncentivePackageRuleGroup> lIncentivePackageRuleGroups = (ArrayList<IncentivePackageRuleGroup>) businessProgramService.getIncentivePackageRuleGroups(lProgramID);
        getUserSession().setIncentivePackageRuleGroups(lIncentivePackageRuleGroups);
        getUserSession().setBenefitPackages(businessProgramService.getBenefitPackages(lProgramID));
        getUserSession().setBusinessProgram(businessProgram);
        getUserSession().setProgramChangeLogList((ArrayList<ProgramChangeLog>) businessProgramService.getBusinessProgramChangeLog(lProgramID));

        ArrayList<ProgramPackage> programPackages = findAvailablePackage();
        modelMap.put("programPackages", programPackages);
        modelMap.put("programIncentiveOptions", getUserSession().getProgramIncentiveOptions());
        modelMap.put("businessProgram", businessProgram);
        modelMap.put("additionalInfos", lAdditionalInfos);
        modelMap.put("eligibleActivities", lEligibleActivities);
        modelMap.put("programActivityIncentivesSummary", lProgramActivityIncentivesSummary);
        modelMap.put("extendedAuthCodes", getUserSession().getExtendedAuthCodes());
        modelMap.put("programCheckmarks", getUserSession().getProgramCheckmarks());
        modelMap.put("participationGroups", lParticipationGroups);
        modelMap.put("benefitPackages", getUserSession().getBenefitPackages());
        modelMap.put("changeLogList", getUserSession().getProgramChangeLogList());
        modelMap.put("packageRuleGroups", getUserSession().getIncentivePackageRuleGroups());
        modelMap.put("qualificationCheckmarks", getUserSession().getQualificationCheckmarks());


        form.setProgramID(lProgramID);
        form.setGroupNo(businessProgram.getEmployerGroup().getGroupNumber());

        Boolean groupViewAndEditAccess = (Boolean)getUserSessionSupport().getSession().getAttribute(BPMAdminConstants.BPM_ADMIN_GROUP_VIEW_EDIT_ACCESS);
        Boolean memberServicesAdminRole = (Boolean)getUserSessionSupport().getSession().getAttribute(BPMAdminConstants.BPM_MEMBER_SERVICES_ADMIN_ROLE);
        modelMap.put("groupViewAndEditAccess", groupViewAndEditAccess);
        modelMap.put("memberServicesAdminRole", memberServicesAdminRole);
        modelMap.put("printerFriendlyPageAccess", (Boolean)getUserSessionSupport().getSession().getAttribute(BPMAdminConstants.BPM_ADMIN_PRINTER_FRIENDLY_ACCESS));
    }

    protected ArrayList<ProgramPackage> findAvailablePackage() throws Exception {
        ArrayList<ProgramPackage> lProgramPackages = (ArrayList<ProgramPackage>) businessProgramService.getProgramPackages();

        if (getUserSession().getProgramPackages() != null) {
            getUserSession().getProgramPackages().clear();
        }
        getUserSession().setProgramPackages(lProgramPackages);

        return lProgramPackages;
    }

    @Override
    public boolean supports(Class<?> clazz) {
        return CreateProgramForm.class.isAssignableFrom(clazz);
    }

    @Override
    public void validate(Object target, Errors errors) {

    }
}
