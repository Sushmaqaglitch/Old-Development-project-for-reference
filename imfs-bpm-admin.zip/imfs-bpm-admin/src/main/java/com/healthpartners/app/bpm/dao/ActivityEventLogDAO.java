package com.healthpartners.app.bpm.dao;

import org.springframework.dao.DataAccessException;

import java.sql.Date;
import java.util.Collection;

/**
 * 
 * @author f5929
 * 
 */
public interface ActivityEventLogDAO {
	
	Collection<Integer> getNumberOfActivityEventLog(String pProcessingStatus)
	throws DataAccessException;
	int updateFilteredActivities(String pMemberID, Date pInsertDate, Integer pGroupID, Integer pActivityID, String pActivityStatusToProcess, String pProcessingStatus)
			throws DataAccessException;
}
