package com.healthpartners.app.bpm.dto;

import java.io.Serializable;
import java.sql.Date;
import java.util.Calendar;
import java.util.Collection;

public class RewardCardFulfillmentTrackingReportHist implements Serializable {
    static final long serialVersionUID = 0L;

    private Integer rewardFulfillHistID;
    private Integer programID;
    private String groupNo;
    private String siteNo;
    private Calendar qualificationStartDate;
    private Integer personID;
    private Integer personDemographicsID;
    private Integer groupID;
    private Integer packageID;
    private String memberNo;
    private Integer contractNo;
    private String firstName;
    private String lastName;
    private String middleName;
    private String formattedName;
    private Date dateOfBirth;
    private Integer contributionAmount;
    private String contributionTypeCode;
    private Integer contributionTypeCodeId;
    private Date fulfillmentDate;
    private Date contributionStartDate;
    private Date contributionEndDate;
    private Date contributionDate;
    private Integer memberCount;
    private Integer activityID;
    private String activityName;
    private String packageSubTypeName;
    private String sourceActivityID;
    private String incentiveReportName;
    private Integer incentiveOptionID;
    private Integer rowNumber;
    private String employerGroupName;
    private String employerSiteName;
    private String contributionType;
    private String fulfillmentRoutingType;
    private String externalTransactionID;
    private String orderNumber;
    private String rewardCardNoMasked;
    private Integer vendorFee;
    private String quoteNo;
    private String quoteDesc;
    private String feeAmount;
    private String feeDesc;
    private String carrierMessageName;
    private String carrierMessageDesc;
    private String carrierMessageDesc2;
    private String embossName;
    private String embossedDesc;
    private String transactionMessageName;
    private String transactionMessageDesc;

    private RewardCardFulfillmentReportHistStatus rewardCardFulfillmentReportHistStatus;
    private Collection<RewardCardFulfillmentReportHistStatus> rewardCardFulfillmentReportHistStatuses;

    private RewardCardAddress rewardCardAddress;


    public Integer getRewardFulfillHistID() {
        return rewardFulfillHistID;
    }

    public void setRewardFulfillHistID(Integer rewardFulfillHistID) {
        this.rewardFulfillHistID = rewardFulfillHistID;
    }

    public Integer getProgramID() {
        return programID;
    }

    public void setProgramID(Integer programID) {
        this.programID = programID;
    }

    public String getGroupNo() {
        return groupNo;
    }

    public void setGroupNo(String groupNo) {
        this.groupNo = groupNo;
    }

    public String getSiteNo() {
        return siteNo;
    }

    public void setSiteNo(String siteNo) {
        this.siteNo = siteNo;
    }

    public Calendar getQualificationStartDate() {
        return qualificationStartDate;
    }

    public void setQualificationStartDate(Calendar qualificationStartDate) {
        this.qualificationStartDate = qualificationStartDate;
    }

    public Integer getPersonID() {
        return personID;
    }

    public void setPersonID(Integer personID) {
        this.personID = personID;
    }

    public Integer getPersonDemographicsID() {
        return personDemographicsID;
    }

    public void setPersonDemographicsID(Integer personDemographicsID) {
        this.personDemographicsID = personDemographicsID;
    }


    public Integer getGroupID() {
        return groupID;
    }

    public void setGroupID(Integer groupID) {
        this.groupID = groupID;
    }

    public Integer getPackageID() {
        return packageID;
    }

    public void setPackageID(Integer packageID) {
        this.packageID = packageID;
    }

    public String getMemberNo() {
        return memberNo;
    }

    public void setMemberNo(String memberNo) {
        this.memberNo = memberNo;
    }

    public Integer getContractNo() {
        return contractNo;
    }

    public void setContractNo(Integer contractNo) {
        this.contractNo = contractNo;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getFormattedName() {
        return formattedName = this.firstName.trim() + " " + this.lastName.trim();
    }

    public void setFormattedName(String formattedName) {
        this.formattedName = formattedName;
    }

    public Date getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(Date dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public Integer getContributionAmount() {
        return contributionAmount;
    }

    public void setContributionAmount(Integer contributionAmount) {
        this.contributionAmount = contributionAmount;
    }

    public String getContributionTypeCode() {
        return contributionTypeCode;
    }

    public void setContributionTypeCode(String contributionTypeCode) {
        this.contributionTypeCode = contributionTypeCode;
    }

    public Integer getContributionTypeCodeId() {
        return contributionTypeCodeId;
    }

    public void setContributionTypeCodeId(Integer contributionTypeCodeId) {
        this.contributionTypeCodeId = contributionTypeCodeId;
    }


    public Date getFulfillmentDate() {
        return fulfillmentDate;
    }

    public void setFulfillmentDate(Date fulfillmentDate) {
        this.fulfillmentDate = fulfillmentDate;
    }

    public Date getContributionStartDate() {
        return contributionStartDate;
    }

    public void setContributionStartDate(Date contributionStartDate) {
        this.contributionStartDate = contributionStartDate;
    }

    public Date getContributionEndDate() {
        return contributionEndDate;
    }

    public void setContributionEndDate(Date contributionEndDate) {
        this.contributionEndDate = contributionEndDate;
    }

    public Date getContributionDate() {
        return contributionDate;
    }

    public void setContributionDate(Date contributionDate) {
        this.contributionDate = contributionDate;
    }

    public Integer getMemberCount() {
        return memberCount;
    }

    public void setMemberCount(Integer memberCount) {
        this.memberCount = memberCount;
    }

    public Integer getActivityID() {
        return activityID;
    }

    public void setActivityID(Integer activityID) {
        this.activityID = activityID;
    }


    public String getActivityName() {
        return activityName;
    }

    public void setActivityName(String activityName) {
        this.activityName = activityName;
    }

    public String getPackageSubTypeName() {
        return packageSubTypeName;
    }

    public void setPackageSubTypeName(String packageSubTypeName) {
        this.packageSubTypeName = packageSubTypeName;
    }

    public String getSourceActivityID() {
        return sourceActivityID;
    }

    public void setSourceActivityID(String sourceActivityID) {
        this.sourceActivityID = sourceActivityID;
    }

    public String getIncentiveReportName() {
        return incentiveReportName;
    }

    public void setIncentiveReportName(String incentiveReportName) {
        this.incentiveReportName = incentiveReportName;
    }

    public Integer getIncentiveOptionID() {
        return incentiveOptionID;
    }

    public void setIncentiveOptionID(Integer incentiveOptionID) {
        this.incentiveOptionID = incentiveOptionID;
    }

    public Integer getRowNumber() {
        return rowNumber;
    }

    public void setRowNumber(Integer rowNumber) {
        this.rowNumber = rowNumber;
    }

    public String getEmployerGroupName() {
        return employerGroupName;
    }

    public void setEmployerGroupName(String employerGroupName) {
        this.employerGroupName = employerGroupName;
    }


    public String getEmployerSiteName() {
        return employerSiteName;
    }

    public void setEmployerSiteName(String employerSiteName) {
        this.employerSiteName = employerSiteName;
    }

    public String getContributionType() {
        return contributionType;
    }

    public void setContributionType(String contributionType) {
        this.contributionType = contributionType;
    }

    public String getFulfillmentRoutingType() {
        return fulfillmentRoutingType;
    }

    public void setFulfillmentRoutingType(String fulfillmentRoutingType) {
        this.fulfillmentRoutingType = fulfillmentRoutingType;
    }

    public String getExternalTransactionID() {
        return externalTransactionID;
    }

    public void setExternalTransactionID(String externalTransactionID) {
        this.externalTransactionID = externalTransactionID;
    }

    public String getOrderNumber() {
        return orderNumber;
    }

    public void setOrderNumber(String orderNumber) {
        this.orderNumber = orderNumber;
    }

    public String getRewardCardNoMasked() {
        return rewardCardNoMasked;
    }

    public void setRewardCardNoMasked(String rewardCardNoMasked) {
        this.rewardCardNoMasked = rewardCardNoMasked;
    }

    public Integer getVendorFee() {
        return vendorFee;
    }

    public void setVendorFee(Integer vendorFee) {
        this.vendorFee = vendorFee;
    }

    public String getQuoteNo() {
        return quoteNo;
    }

    public void setQuoteNo(String quoteNo) {
        this.quoteNo = quoteNo;
    }

    public String getQuoteDesc() {
        return quoteDesc;
    }

    public void setQuoteDesc(String quoteDesc) {
        this.quoteDesc = quoteDesc;
    }

    public String getFeeAmount() {
        return feeAmount;
    }

    public void setFeeAmount(String feeAmount) {
        this.feeAmount = feeAmount;
    }

    public String getFeeDesc() {
        return feeDesc;
    }

    public void setFeeDesc(String feeDesc) {
        this.feeDesc = feeDesc;
    }

    public String getCarrierMessageName() {
        return carrierMessageName;
    }

    public void setCarrierMessageName(String carrierMessageName) {
        this.carrierMessageName = carrierMessageName;
    }

    public String getCarrierMessageDesc() {
        return carrierMessageDesc;
    }

    public void setCarrierMessageDesc(String carrierMessageDesc) {
        this.carrierMessageDesc = carrierMessageDesc;
    }

    public String getCarrierMessageDesc2() {
        return carrierMessageDesc2;
    }

    public void setCarrierMessageDesc2(String carrierMessageDesc2) {
        this.carrierMessageDesc2 = carrierMessageDesc2;
    }

    public String getEmbossName() {
        return embossName;
    }

    public void setEmbossName(String embossName) {
        this.embossName = embossName;
    }

    public String getEmbossedDesc() {
        return embossedDesc;
    }

    public void setEmbossedDesc(String embossedDesc) {
        this.embossedDesc = embossedDesc;
    }

    public String getTransactionMessageName() {
        return transactionMessageName;
    }

    public void setTransactionMessageName(String transactionMessageName) {
        this.transactionMessageName = transactionMessageName;
    }

    public String getTransactionMessageDesc() {
        return transactionMessageDesc;
    }

    public void setTransactionMessageDesc(String transactionMessageDesc) {
        this.transactionMessageDesc = transactionMessageDesc;
    }

    public RewardCardFulfillmentReportHistStatus getRewardCardFulfillmentReportHistStatus() {
        return rewardCardFulfillmentReportHistStatus;
    }

    public void setRewardCardFulfillmentReportHistStatus(
            RewardCardFulfillmentReportHistStatus rewardCardFulfillmentReportHistStatus) {
        this.rewardCardFulfillmentReportHistStatus = rewardCardFulfillmentReportHistStatus;
    }

    public Collection<RewardCardFulfillmentReportHistStatus> getRewardCardFulfillmentReportHistStatuses() {
        return rewardCardFulfillmentReportHistStatuses;
    }

    public void setRewardCardFulfillmentReportHistStatuses(
            Collection<RewardCardFulfillmentReportHistStatus> rewardCardFulfillmentReportHistStatuses) {
        this.rewardCardFulfillmentReportHistStatuses = rewardCardFulfillmentReportHistStatuses;
    }

    public RewardCardAddress getRewardCardAddress() {
        return rewardCardAddress;
    }

    public void setRewardCardAddress(RewardCardAddress rewardCardAddress) {
        this.rewardCardAddress = rewardCardAddress;
    }


}
