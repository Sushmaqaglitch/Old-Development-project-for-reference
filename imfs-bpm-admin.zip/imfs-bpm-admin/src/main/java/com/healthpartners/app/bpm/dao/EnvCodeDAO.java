
package com.healthpartners.app.bpm.dao;

import com.healthpartners.app.bpm.dto.BPMEnvCode;
import org.springframework.dao.DataAccessException;

import java.util.Collection;


public interface EnvCodeDAO 
{
	public int insertEnvCode(BPMEnvCode code) 
			throws DataAccessException;
	
	public int updateEnvCode(BPMEnvCode code) 
			throws DataAccessException;
	
	public int deleteEnvCode(BPMEnvCode pEnvCode) 
			throws DataAccessException;
	
	public Collection<BPMEnvCode> getAllEnvCodes()
			throws DataAccessException;

}
