package com.healthpartners.app.bpm.dto;

import java.io.Serializable;
import java.sql.Date;

public class ContributionGridBenefitContractTypeRelationship implements Serializable {
    static final long serialVersionUID = 0L;

    private Integer uid;
    private Integer benefitContractTypeID;
    private Integer relationshipCode;
    private String relationshipDesc;
    private Date effectiveDate;
    private Date endDate;
    private Date insertDate;
    private Date modifyDate;
    private String insertUser;
    private String modifyUser;


    public ContributionGridBenefitContractTypeRelationship() {
        super();
    }

    public Integer getUid() {
        return uid;
    }

    public void setUid(Integer uid) {
        this.uid = uid;
    }

    public Integer getBenefitContractTypeID() {
        return benefitContractTypeID;
    }

    public void setBenefitContractTypeID(Integer benefitContractTypeID) {
        this.benefitContractTypeID = benefitContractTypeID;
    }

    public Integer getRelationshipCode() {
        return relationshipCode;
    }

    public void setRelationshipCode(Integer relationshipCode) {
        this.relationshipCode = relationshipCode;
    }

    public String getRelationshipDesc() {
        return relationshipDesc;
    }

    public void setRelationshipDesc(String relationshipDesc) {
        this.relationshipDesc = relationshipDesc;
    }

    public Date getEffectiveDate() {
        return effectiveDate;
    }

    public void setEffectiveDate(Date effectiveDate) {
        this.effectiveDate = effectiveDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public Date getInsertDate() {
        return insertDate;
    }

    public void setInsertDate(Date insertDate) {
        this.insertDate = insertDate;
    }

    public Date getModifyDate() {
        return modifyDate;
    }

    public void setModifyDate(Date modifyDate) {
        this.modifyDate = modifyDate;
    }

    public String getInsertUser() {
        return insertUser;
    }

    public void setInsertUser(String insertUser) {
        this.insertUser = insertUser;
    }

    public String getModifyUser() {
        return modifyUser;
    }

    public void setModifyUser(String modifyUser) {
        this.modifyUser = modifyUser;
    }


}
