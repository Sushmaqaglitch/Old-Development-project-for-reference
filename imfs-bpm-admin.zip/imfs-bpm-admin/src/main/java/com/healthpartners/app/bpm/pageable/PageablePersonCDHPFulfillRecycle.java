package com.healthpartners.app.bpm.pageable;

import com.healthpartners.app.bpm.dto.CDHPFulfillmentTrackingRecycle;

import java.util.ArrayList;
import java.util.Iterator;

/**
 * The pageable class serves as a wrapper for the array list of objects, and
 * operations that are performed on those objects. For ex. adding a row number
 * for display.
 * The BPMPagination then has a pointer to an instance of this class.
 *
 * @author jxbourbour
 */
public class PageablePersonCDHPFulfillRecycle implements BPMPageable {
    ArrayList<CDHPFulfillmentTrackingRecycle> personCDHPFulfillRecycles;

    public PageablePersonCDHPFulfillRecycle() {
        super();
    }

    public PageablePersonCDHPFulfillRecycle(ArrayList<CDHPFulfillmentTrackingRecycle> pPersonCDHPFulfillRecycles) {
        personCDHPFulfillRecycles = pPersonCDHPFulfillRecycles;
    }


    public ArrayList<CDHPFulfillmentTrackingRecycle> getPersonCDHPFulfillRecycles() {
        return personCDHPFulfillRecycles;
    }

    public void setPersonCDHPFulfillRecycles(
            ArrayList<CDHPFulfillmentTrackingRecycle> personCDHPFulfillRecycles) {
        this.personCDHPFulfillRecycles = personCDHPFulfillRecycles;
    }

    public void addRowNumber() {
        int startRowNumber = 1;
        Iterator<CDHPFulfillmentTrackingRecycle> iter = (Iterator<CDHPFulfillmentTrackingRecycle>) personCDHPFulfillRecycles.iterator();
        while (iter.hasNext()) {
            CDHPFulfillmentTrackingRecycle personCDHPFulfillRecycle = (CDHPFulfillmentTrackingRecycle) iter.next();
            personCDHPFulfillRecycle.setRowNumber(startRowNumber);
            startRowNumber++;
        }
    }

}
