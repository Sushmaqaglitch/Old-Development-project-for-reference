package com.healthpartners.app.bpm.dao;


import com.healthpartners.app.bpm.dto.*;
import com.healthpartners.app.bpm.exception.BPMException;
import com.healthpartners.service.bpm.common.BPMConstants;
import com.healthpartners.service.bpm.dto.ActivityDefinition;
import com.healthpartners.service.bpm.dto.GenericStatusType;
import com.healthpartners.service.bpm.dto.MemberActivity;
import jakarta.annotation.PostConstruct;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.sql.DataSource;
import java.sql.*;
import java.util.ArrayList;
import java.util.Collection;


@Repository
@Transactional(timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
public class PersonDAOJdbc extends JdbcDaoSupport implements PersonDAO {

    private static final String selectPersonActivityNonEmployerSponsoredContributionsPending = " SELECT \n" +
            "DISTINCT\n" +
            "  \n" +
            "    demo.prsn_id\n" +
            ", demo.PRSN_DMGRPHCS_ID\n" +
            ", pbl.CONTRACT_NO\n" +
            ", demo.hp_mem_id\n" +
            ", demo.first_nm\n" +
            ", demo.last_nm\n" +
            ",  biz.GRP_ID\n" +
            ", biz.SUBGRP_ID\n" +
            ", pbl.ben_pkg_id\n" +
            ", egs.empl_grp_no\n" +
            ", egs.empl_grp_site_id_no\n" +
            ", pb.purch_sub_tp_nm\n" +
            ", ppais.actv_id\n" +
            ", ppais.biz_pgm_id\n" +
            ", a.srce_actv_id\n" +
            ", (select l.actv_nm from activity l where l.actv_id = ppais.actv_id) activity_name\n" +
            ", trunc(ppais.actv_stat_incntv_dt) activity_stat_dt\n" +
            ", 'PENDING (SYSTEM)' activity_incntv_status\n" +
            ", biz_type.biz_pgm_nm program_type\n" +
            ", biz.biz_pgm_id\n" +
            ", biz.biz_pgm_tp_cd\n" +
            ", biz_io.particip_cap\n" +
            ", biz_io.family_cap\n" +
            ", tc.contrib_amt amount_achieved\n" +
            ", CASE WHEN \n" +
            "           ppais.actv_stat_incntv_dt between biz.contribution_start_dt and biz.contribution_end_dt\n" +
            "                   THEN ppais.actv_stat_incntv_dt\n" +
            "       WHEN ppais.actv_stat_incntv_dt < biz.contribution_start_dt\n" +
            "                    THEN biz.contribution_start_dt\n" +
            "       WHEN ppais.actv_stat_incntv_dt > biz.contribution_end_dt\n" +
            "                    THEN biz.contribution_end_dt\n" +
            "       END as contribution_date \n" +
            ", (select l.lu_val from luv l where l.lu_id = ppais.ben_contr_tp_lu_id) benefit_contract_type\n" +
            ", biz_io.incntv_optn_id\n" +
            ", ppais.insert_ts incented_date\n" +
            "FROM  \n" +
            "prsn_baseline_ds pbl\n" +
            ", business_program biz\n" +
            ", empl_grp_site egs\n" +
            ", biz_pgm_incentive_option biz_io\n" +
            ", tier_contribution tc\n" +
            ", tier_incentive_contribution tic\n" +
            ", tier_value tv\n" +
            ", business_program_type biz_type\n" +
            ", prsn_pgm_actv_incntv_sts ppais\n" +
            ", prsn_demographics demo\n" +
            ", activity_incentive ai\n" +
            ", incentive_particip_rel ipr\n" +
            ", activity a\n" +
            ", pkg_baseline_ds pb\n" +
            ", incentive_option io\n" +
            "WHERE  \n" +
            "\n" +
            "trunc(ppais.insert_ts) >= trunc(?) \n" +
            "AND ppais.biz_pgm_id = biz.biz_pgm_id\n" +
            "\n" +
            "AND ((ppais.actv_stat_cd_id = (SELECT lu_id FROM  luv  WHERE lu_grp='BPM_ACTIVITY_STATUS' AND lu_val='COMPLETE')) \n" +
            "  OR\n" +
            "   (ppais.actv_stat_cd_id = (SELECT lu_id FROM  luv  WHERE lu_grp='BPM_ACTIVITY_STATUS' AND lu_val='WAIVE'))\n" +
            "\tOR\n" +
            "   (ppais.actv_stat_cd_id = (SELECT lu_id FROM  luv  WHERE lu_grp='BPM_ACTIVITY_STATUS' AND lu_val='ACTIVE') \n" +
            "    AND\n" +
            "     biz_io.incntv_rule_tp_id = (SELECT lu_id FROM  luv  WHERE lu_grp='INCNTV_RULE_TP' AND lu_val='ENROLL_BY'))\n" +
            "    OR\n" +
            "   (ppais.actv_stat_cd_id = (SELECT lu_id FROM  luv  WHERE lu_grp='BPM_ACTIVITY_STATUS' AND lu_val='ACTIVE') \n" +
            "    AND\n" +
            "     a.actv_tp_cd_id = (SELECT lu_id FROM  luv  WHERE lu_grp='BPM_ACTIVITY_TP' AND lu_val='DISEASE_MGMT')\n" +
            "    ))\n" +
            "    \n" +
            "-- match person program activity incentive status to biz pgm activity incentive\n" +
            "AND ppais.biz_pgm_id = ai.biz_pgm_id\n" +
            "AND ppais.actv_incntv_id = ai.actv_incntv_id\n" +
            "\n" +
            "-- match up to tier incentive contribution (tic).  If match, then person relationship will\n" +
            "-- determine the contribution amount later in sql.  TIC lines up with tier_contribution (tc). \n" +
            "\n" +
            "AND ai.actv_incntv_id = tic.actv_incntv_id\n" +
            "AND ai.incntv_optn_id = tic.incntv_option_id\n" +
            "AND ai.actv_incntv_grp_id = tic.actv_incntv_grp_id\n" +
            "AND ai.actv_incntv_grp_req_id = tic.actv_incntv_grp_req_id\n" +
            "\n" +
            "-- join tiering activity contribution (tic) layer to determine\n" +
            "-- contribution amount awarded at the activity level\n" +
            "AND ppais.biz_pgm_id = tic.biz_pgm_id\n" +
            "AND ppais.actv_incntv_id = tic.actv_incntv_id\n" +
            "-- this match should lock in the right contribution amt\n" +
            "AND tic.tier_contrib_id = tc.tier_contrib_id\n" +
            "AND ppais.ben_contr_tp_lu_id = tv.ben_contr_tp_lu_id\n" +
            "AND tv.tier_tp_id  = tc.tier_tp_id\n" +
            "AND tic.biz_pgm_id = tc.biz_pgm_id\n" +
            "AND tv.tier_value_id = tc.tier_value_id\n" +
            "\n" +
            "\n" +
            "-- join activity table to get source activity id\n" +
            "AND ppais.actv_id = a.actv_id\n" +
            "\n" +
            "-- match up to biz pgm incentive opton to determine incentive status type and where to send\n" +
            "AND biz.biz_pgm_id = biz_io.biz_pgm_id\n" +
            "AND ai.incntv_optn_id = biz_io.incntv_optn_id\n" +
            "AND biz_io.fulfillment_rtng_tp_cd_id = (SELECT lu_id FROM  luv  WHERE lu_grp='FLFLMNT_RTNG_TP' AND lu_val='SND_TO_CDHP')\n" +
            "AND (biz_io.incntd_sts_tp_cd_id = (SELECT lu_id FROM  luv  WHERE lu_grp='BPM_INCENTED_BASED' AND lu_val='ACTIVITY_PKGE_BASED') OR\n" +
            "    biz_io.incntd_sts_tp_cd_id = (SELECT lu_id FROM  luv  WHERE lu_grp='BPM_INCENTED_BASED' AND lu_val='MULTI_ACTIVITY'))\n" +
            "\n" +
            "-- match up to active person base line record\n" +
            "AND biz.grp_id = pbl.grp_id\n" +
            "AND biz.subgrp_id = pbl.subgrp_id\n" +
            "AND ppais.prsn_dmgrphcs_id = demo.prsn_dmgrphcs_id\n" +
            "AND demo.prsn_id = pbl.person_no\n" +
            "--EV51301 comment out date boundary check when person changes subgroup, package or contract in same program year.\n" +
            "--TJQ AND ppais.actv_stat_incntv_dt between pbl.contract_eff_dt and pbl.contract_end_dt\n" +
            "--TJQ AND ppais.actv_stat_incntv_dt between pbl.subgrp_eff_dt and pbl.subgrp_end_dt\n" +
            "--TJQ AND ppais.actv_stat_incntv_dt between pbl.ben_pkg_eff_dt and pbl.ben_pkg_end_dt\n" +
            "-- EV51301\n" +
            "AND ppais.actv_stat_incntv_dt between pbl.biz_pgm_eff_dt and pbl.biz_pgm_end_dt\n" +
            "\n" +
            "-- match up to employer group site\n" +
            "AND biz.grp_id = egs.grp_id\n" +
            "AND biz.subgrp_id = egs.subgrp_id\n" +
            "\n" +
            "-- match up to HRA in package baseline \n" +
            "AND pbl.grp_id = pb.grp_id\n" +
            "AND pbl.subgrp_id = pb.subgrp_id\n" +
            "AND pbl.ben_pkg_id = pb.ben_pkg_id\n" +
            "AND ppais.actv_stat_incntv_dt between pb.eff_dt and pb.end_dt\n" +
            "\n" +
            "\n" +
            "-- match up to incentive option definition for incentive option type\n" +
            "AND biz_io.incntv_optn_id = io.incntv_optn_id\n" +
            "AND io.incntv_optn_tp_cd_id = (select lu_id from luv where lu_grp = 'BPM_INCNTV_TP' AND lu_val = ?) \n" +
            "\n" +
            "AND biz.biz_pgm_tp_cd = biz_type.biz_pgm_tp_cd\n" +
            "\n" +
            "-- match up to ipr to get contribution earned based on person relationship\n" +
            "AND ppais.actv_incntv_id = ai.actv_incntv_id\n" +
            "AND ai.actv_incntv_id = ipr.actv_incntv_id\n" +
            "AND pbl.rel_cd = ipr.rel_cd\n" +
            "AND pbl.rel_cd = tc.rel_cd\n" +
            "\n" +
            "-- determine if already passed to tracking history \n" +
            "AND NOT EXISTS \n" +
            "    (SELECT * FROM CDHP_FULFILL_RPT_TRACKING_HIST CFRTH\n" +
            "              WHERE\n" +
            "                   CFRTH.BIZ_PGM_ID = PPAIS.BIZ_PGM_ID\n" +
            "               AND CFRTH.PRSN_DMGRPHCS_ID = PPAIS.PRSN_DMGRPHCS_ID\n" +
            "               AND CFRTH.PKG_ID = PBL.BEN_PKG_ID\n" +
            "               AND CFRTH.CONTRACT_NO = PBL.CONTRACT_NO\n" +
            "               AND CFRTH.ACTV_ID = PPAIS.ACTV_ID\n" +
            "               )\n" +
            "AND pb.purch_sub_tp_nm = ?\n" +
            "AND io.incntv_optn_tp_cd_id = (select lu_id from luv where lu_grp = 'BPM_INCNTV_TP' AND lu_val = ?)\n" +
            "--order by egs.empl_grp_no, pbl.CONTRACT_NO asc\n" +
            "--AND pb.purch_sub_tp_nm = 'GROUP - HRA'\n";

    private static final String selectPersonActivityEmployerSponsoredContributionsPending = "SELECT \n" +
            "DISTINCT " +
            "  demo.prsn_id " +
            ", demo.PRSN_DMGRPHCS_ID " +
            ", pbl.CONTRACT_NO " +
            ", demo.hp_mem_id " +
            ", demo.first_nm " +
            ", demo.last_nm " +
            ", pbl.ben_pkg_id " +
            ",  biz.GRP_ID " +
            ", biz.SUBGRP_ID " +
            ", egs.empl_grp_no " +
            ", egs.empl_grp_site_id_no " +
            ", pb.purch_sub_tp_nm " +
            ", ppais.biz_pgm_id " +
            ", a.srce_actv_id " +
            ", (select l.actv_nm from activity l where l.actv_id = ppais.actv_id) activity_name " +
            ", trunc(ppais.actv_stat_incntv_dt) activity_stat_dt " +
            ", 'PENDING' activity_incntv_status " +
            ", biz_type.biz_pgm_nm program_type " +
            ", biz.biz_pgm_id " +
            ", biz.biz_pgm_tp_cd " +
            ", biz_io.incntv_optn_id " +
            ", biz_io.particip_cap " +
            ", biz_io.family_cap " +
            ", ppais.contrib_amt amount_achieved " +
            ", CASE WHEN  " +
            "           ppais.actv_stat_incntv_dt between biz.contribution_start_dt and biz.contribution_end_dt " +
            "                   THEN ppais.actv_stat_incntv_dt " +
            "       WHEN ppais.actv_stat_incntv_dt < biz.contribution_start_dt " +
            "                    THEN biz.contribution_start_dt " +
            "       WHEN ppais.actv_stat_incntv_dt > biz.contribution_end_dt " +
            "                    THEN biz.contribution_end_dt " +
            "       END as contribution_date " +
            ", (select l.lu_val from luv l where l.lu_id = ppais.ben_contr_tp_lu_id) benefit_contract_type " +
            ", ppais.insert_ts incented_date " +
            "FROM  " +
            "prsn_baseline_ds pbl " +
            ", business_program biz " +
            ", empl_grp_site egs " +
            ", biz_pgm_incentive_option biz_io " +
            ", business_program_type biz_type " +
            ", prsn_pgm_actv_incntv_sts ppais " +
            ", prsn_demographics demo " +
            ", activity_incentive ai " +
            ", activity a " +
            ", pkg_baseline_ds pb " +
            ", incentive_option io " +
            "WHERE   " +
            "trunc(ppais.insert_ts) >= trunc(?)  " +
            "AND ppais.biz_pgm_id = biz.biz_pgm_id " +
            "AND ppais.actv_stat_cd_id = (SELECT lu_id FROM  luv  WHERE lu_grp='BPM_ACTIVITY_STATUS' AND lu_val='COMPLETE') " +
            "-- match person program activity incentive status to biz pgm activity incentive " +
            "AND ppais.biz_pgm_id = ai.biz_pgm_id " +
            "AND ppais.actv_incntv_id = ai.actv_incntv_id " +
            "AND ppais.contrib_amt > 0 " +
            "-- join activity table to get source activity id " +
            "AND ppais.actv_id = a.actv_id " +
            "-- match up to biz pgm incentive opton to determine incentive status type and where to send " +
            "AND biz.biz_pgm_id = biz_io.biz_pgm_id " +
            "AND ai.incntv_optn_id = biz_io.incntv_optn_id " +
            "AND biz_io.fulfillment_rtng_tp_cd_id = (SELECT lu_id FROM  luv  WHERE lu_grp='FLFLMNT_RTNG_TP' AND lu_val='SND_TO_CDHP') " +
            "AND (biz_io.incntd_sts_tp_cd_id = (SELECT lu_id FROM  luv  WHERE lu_grp='BPM_INCENTED_BASED' AND lu_val='ACTIVITY_PKGE_BASED') OR " +
            "    biz_io.incntd_sts_tp_cd_id = (SELECT lu_id FROM  luv  WHERE lu_grp='BPM_INCENTED_BASED' AND lu_val='MULTI_ACTIVITY')) " +
            "-- match up to active person base line record " +
            "AND biz.grp_id = pbl.grp_id " +
            "AND biz.subgrp_id = pbl.subgrp_id " +
            "AND ppais.prsn_dmgrphcs_id = demo.prsn_dmgrphcs_id " +
            "AND demo.prsn_id = pbl.person_no " +
            "--EV51301 comment out date boundary check when person changes subgroup, package or contract in same program year. " +
            "--TJQ AND ppais.actv_stat_incntv_dt between pbl.contract_eff_dt and pbl.contract_end_dt " +
            "--TJQ AND ppais.actv_stat_incntv_dt between pbl.subgrp_eff_dt and pbl.subgrp_end_dt " +
            "--TJQ AND ppais.actv_stat_incntv_dt between pbl.ben_pkg_eff_dt and pbl.ben_pkg_end_dt " +
            "-- EV51301 " +
            "AND ppais.actv_stat_incntv_dt between pbl.biz_pgm_eff_dt and pbl.biz_pgm_end_dt " +
            "-- match up to employer group site " +
            "AND biz.grp_id = egs.grp_id " +
            "AND biz.subgrp_id = egs.subgrp_id " +
            "-- match up to HRA in package baseline " +
            "AND pbl.grp_id = pb.grp_id " +
            "AND pbl.subgrp_id = pb.subgrp_id " +
            "AND pbl.ben_pkg_id = pb.ben_pkg_id " +
            "AND ppais.actv_stat_incntv_dt between pb.eff_dt and pb.end_dt " +
            "-- match up to incentive option definition for incentive option type " +
            "AND biz_io.incntv_optn_id = io.incntv_optn_id " +
            "AND io.incntv_optn_tp_cd_id = (select lu_id from luv where lu_grp = 'BPM_INCNTV_TP' AND lu_val = ?) " +
            "AND biz.biz_pgm_tp_cd = biz_type.biz_pgm_tp_cd " +
            "-- determine if already passed to tracking history  " +
            "AND NOT EXISTS  " +
            "    (SELECT * FROM CDHP_FULFILL_RPT_TRACKING_HIST CFRTH " +
            "              WHERE " +
            "                   CFRTH.BIZ_PGM_ID = PPAIS.BIZ_PGM_ID " +
            "               AND CFRTH.PRSN_DMGRPHCS_ID = PPAIS.PRSN_DMGRPHCS_ID " +
            "               AND CFRTH.PKG_ID = PBL.BEN_PKG_ID " +
            "               AND CFRTH.CONTRACT_NO = PBL.CONTRACT_NO " +
            "               AND CFRTH.ACTV_ID = PPAIS.ACTV_ID " +
            "               ) " +
            "AND pb.purch_sub_tp_nm = ? " +
            "AND io.incntv_optn_tp_cd_id = (select lu_id from luv where lu_grp = 'BPM_INCNTV_TP' AND lu_val = ?)";

    private static final String deletePersonProgramActivities = "DELETE FROM person_program_activity_status ";

    private static final String deletePersonPrograms = "DELETE FROM person_program_status WHERE ";

    private static final String selectPersonRelationshipCodes =
            """
            select rlshp_cd, rlshp_txt from pes_rel_ds
            """;
    String getTermedMemberProgramHistoryDetails = "SELECT DISTINCT\n" +
            "pers_stat.PRSN_DMGRPHCS_ID,\n" +
            "person.prsn_id,\n" +
            "person.HP_MEM_ID,\n" +
            "biz.biz_pgm_id,\n" +
            "con_stat.contract_no,\n" +
            "con_stat.cntr_stat_cd_id,\n" +
            "(select LU_VAL from luv WHERE lu_id=con_stat.cntr_stat_cd_id) as cntr_stat_val,\n" +
            "pers_stat.stat_cd_id,\n" +
            "(select LU_VAL from luv WHERE lu_id=pers_stat.stat_cd_id) as pers_stat_val,\n" +
            "biz.biz_pgm_tp_cd as pgm_tp_cd_id,\n" +
            "biz_type.BIZ_PGM_NM,\n" +
            "biz.QUALFCTN_START_DT,\n" +
            "biz.QUALFCTN_END_DT,\n" +
            "biz.eff_dt,\n" +
            "biz.pgm_end_dt,\n" +
            "biz.GRP_ID as group_id," +
            "GROUP_DS.EMPL_GRP_NO as GRP_NO,\n" +
            "GROUP_DS.EMPL_GRP_NM as group_name,\n" +
            "biz.SUBGRP_ID as site_id,\n" +
            "GROUP_DS.EMPL_GRP_SITE_NM as site_name,\n" +
            "GROUP_DS.EMPL_GRP_SITE_ID_NO as site_id_no,\n" +
            "biz.NEW_HIRE_DT,\n" +
            "pers_stat.STAT_DT as member_status_date,\n" +
            "con_stat.CNTR_STAT_DT as contract_status_date,\n" +
            "rel_ds.RLSHP_TXT rel_txt,\n" +
            "pers_stat.PARTICIPATION_END_DT,\n" +
            "biz.biz_pgm_stat_cd_id,\n" +
            "(select LU_DESC from luv where lu_id=biz.biz_pgm_stat_cd_id) as program_status_desc,\n" +
            "(select LU_VAL from  luv where lu_id=biz.biz_pgm_stat_cd_id) as program_status_val,\n" +
            "(select max(insert_ts) from prsn_cntr_pgm_hist  where PRSN_DMGRPHCS_ID = ? ) last_push_date,\n" +
            "(CASE WHEN max_history_record.contract_end_dt = '01-JAN-9999' THEN NULL ELSE max_history_record.contract_end_dt END) contract_end_dt,\n" +
            "biz.STAT_CALC_END_DT,\n" +
            "(CASE WHEN trunc(biz.STAT_CALC_END_DT) < trunc(SYSDATE) THEN 'Y' ELSE 'N' END) stat_calc_date_passed,\n" +
            "(select LU_DESC from luv where lu_id=biz.PART_REQUIREMENT_CD_ID) as program_participation_desc,\n" +
            "(select LU_VAL from  luv where lu_id=biz.PART_REQUIREMENT_CD_ID) as program_participation_val,\n" +
            "(select LU_VAL from luv where lu_id = pers_stat.HLTH_PLAN_CD_ID) as health_plan_code,\n" +
            "(select LU_DESC from luv where lu_id = pers_stat.HLTH_PLAN_CD_ID) as health_plan_desc,\n" +
            "baseline.EXT_EMP_ID_NO,\n" +
            "baseline.EMPLOYEE_FLG,\n" +
            "baseline.ELIG_HIRE_DT,\n" +
            "pers_stat.CVRGE_EFF_DT,\n" +
            "(SELECT QUALFCTN_CHKMRK_NM FROM qualfctn_chkmrk WHERE QUALFCTN_CHKMRK_ID = pers_stat.QUALFCTN_CHKMRK_ID) QUALFCTN_CHKMRK_NM,\n" +
            "(SELECT count('s') FROM qualification_override qo WHERE qo.PRSN_DMGRPHCS_ID = pers_stat.PRSN_DMGRPHCS_ID\n" +
            "AND pers_stat.biz_pgm_incntv_optn_ID = qo.biz_pgm_incntv_optn_ID) has_exemption,\n" +
            "pers_stat.biz_pgm_incntv_optn_id,\n" +
            "io.incntv_optn_nm\n" +
            "FROM\n" +
            "business_program_type biz_type,\n" +
            "(SELECT baseline.person_no, baseline.rel_cd, baseline.contract_no, baseline.contract_end_dt, grp_id, subgrp_id, ben_pkg_id, con1.biz_pgm_id, MAX(load_dt) max_load_dt,\n" +
            "max(con1.insert_ts) max_con_stat\n" +
            "FROM prsn_baseline_hist_ds baseline, prsn_demographics demo1,\n" +
            "contract_program_status con1\n" +
            "WHERE PRSN_DMGRPHCS_ID = ?  AND demo1.prsn_id = baseline.person_no\n" +
            "AND baseline.contract_no=con1.contract_no\n" +
            "AND SYSDATE BETWEEN baseline.biz_pgm_eff_dt AND baseline.biz_pgm_end_dt\n" +
            "GROUP BY baseline.person_no, baseline.rel_cd, baseline.contract_no, baseline.contract_end_dt, grp_id, subgrp_id, ben_pkg_id, con1.biz_pgm_id) max_history_record,\n" +
            "pes_rel_ds rel_ds,\n" +
            "empl_grp_site GROUP_DS,\n" +
            "contract_program_status con_stat,\n" +
            "business_program biz,\n" +
            "person_program_status pers_stat,\n" +
            "prsn_demographics   person,\n" +
            "prsn_baseline_hist_ds baseline,\n" +
            "biz_pgm_incentive_option bpio,\n" +
            "incentive_option io\n" +
            "WHERE\n" +
            "person.PRSN_DMGRPHCS_ID = ?\n" +
            "AND person.PRSN_DMGRPHCS_ID = pers_stat.PRSN_DMGRPHCS_ID\n" +
            "AND pers_stat.biz_pgm_id = biz.biz_pgm_id\n" +
            "AND pers_stat.biz_pgm_incntv_optn_id = bpio.biz_pgm_incntv_optn_id\n" +
            "AND bpio.incntv_optn_id = io.incntv_optn_id\n" +
            "AND pers_stat.biz_pgm_id = con_stat.biz_pgm_id\n" +
            "AND con_stat.contract_no = baseline.contract_no\n" +
            "AND biz.biz_pgm_tp_cd = biz_type.biz_pgm_tp_cd\n" +
            "AND biz.GRP_ID = GROUP_DS.GRP_ID\n" +
            "AND biz.SUBGRP_ID = GROUP_DS.SUBGRP_ID\n" +
            "AND baseline.rel_cd = rel_ds.RLSHP_CD\n" +
            "AND biz.GRP_ID = baseline.GRP_ID\n" +
            "AND biz.SUBGRP_ID = baseline.SUBGRP_ID\n" +
            "AND biz.eff_dt = baseline.biz_pgm_eff_dt\n" +
            "AND biz.pgm_end_dt = baseline.biz_pgm_end_dt\n" +
            "AND max_history_record.rel_cd = pers_stat.rel_cd_id\n" +
            "AND max_history_record.rel_cd = rel_ds.RLSHP_CD\n" +
            "AND max_history_record.person_no = baseline.person_no\n" +
            "AND max_history_record.contract_no = baseline.contract_no\n" +
            "AND max_history_record.grp_id = baseline.grp_id\n" +
            "AND max_history_record.subgrp_id = baseline.subgrp_id\n" +
            "AND max_history_record.contract_no = baseline.contract_no\n" +
            "AND max_history_record.ben_pkg_id = baseline.ben_pkg_id\n" +
            "AND SYSDATE BETWEEN baseline.biz_pgm_eff_dt AND baseline.biz_pgm_end_dt";

    private String updateMemberStatus = "UPDATE person_program_status SET STAT_CD_ID = ?, stat_dt = SYSDATE, MODIFY_TS = SYSDATE,\n" +
            "MODIFY_USR = ? WHERE PRSN_DMGRPHCS_ID = ? AND biz_pgm_id = ? AND biz_pgm_incntv_optn_ID = ?";

    private static final String updateMemberStatusByCodeValue =
            """
            UPDATE person_program_status SET STAT_CD_ID = (SELECT lu_id FROM luv WHERE lu_grp='BPM_MEMBER_STATUS' AND lu_val=?)
            , stat_dt = SYSDATE, MODIFY_TS = SYSDATE, QUALFCTN_CHKMRK_ID = NULL,
             MODIFY_USR = ?      
            """;

    private static final String countProgramActivity =
            """
            select count(*) countProgramActivity
            from PERSON_PROGRAM_ACTIVITY_STATUS t
            where t.biz_pgm_id = ? and
            t.actv_id = ?
            """;

    private static final String getPersonIDFromMemberID =
            """
            SELECT PRSN_DMGRPHCS_ID FROM  prsn_demographics   WHERE HP_MEM_ID = ? 
            """;

    private static final String getPersonDetails =
            """
            SELECT PRSN_DMGRPHCS_ID, HP_MEM_ID, FIRST_NM, LAST_NM, MIDDLE_NM, DOB_DT, PRSN_ID
            , (SELECT DISTINCT PRSN_DMGRPHCS_ID
                 FROM person_program_status stat
                     , business_program biz
                WHERE stat.PRSN_DMGRPHCS_ID = ? AND stat.biz_pgm_id = biz.biz_pgm_id
                  AND SYSDATE BETWEEN biz.eff_dt AND biz.pgm_end_dt
                ) program_demog_id
            FROM  prsn_demographics   WHERE PRSN_DMGRPHCS_ID = ?
            """;

    private static final String getMemberProgramDetails =
            """
            SELECT DISTINCT
            pers_stat.PRSN_DMGRPHCS_ID
            , person.prsn_id
            , person.HP_MEM_ID
            , biz.biz_pgm_id
            , con_stat.contract_no
            --, con_stat.cntr_stat_cd_id
            --, (select LU_VAL from luv WHERE lu_id=con_stat.cntr_stat_cd_id) as cntr_stat_val
            --, pers_stat.stat_cd_id
            --, (select LU_VAL from luv WHERE lu_id=pers_stat.stat_cd_id) as pers_stat_val
            , biz.biz_pgm_tp_cd as pgm_tp_cd_id
            , biz_type.BIZ_PGM_NM
            , biz.QUALFCTN_START_DT
            , biz.QUALFCTN_END_DT
            , biz.eff_dt
            , biz.pgm_end_dt
            , biz.GRP_ID as group_id
            , GROUP_DS.EMPL_GRP_NO as GRP_NO
            , GROUP_DS.EMPL_GRP_NM as group_name
            , biz.SUBGRP_ID as site_id
            , GROUP_DS.EMPL_GRP_SITE_NM as site_name
            , GROUP_DS.EMPL_GRP_SITE_ID_NO as site_id_no
            , biz.NEW_HIRE_DT
            --, pers_stat.STAT_DT as member_status_date
            --, con_stat.CNTR_STAT_DT as contract_status_date
            , rel_ds.RLSHP_TXT rel_txt
            , pers_stat.PARTICIPATION_END_DT
            , biz.biz_pgm_stat_cd_id
            , (select LU_DESC from luv where lu_id=biz.biz_pgm_stat_cd_id) as program_status_desc
            , (select LU_VAL from  luv where lu_id=biz.biz_pgm_stat_cd_id) as program_status_val
            , (select max(insert_ts) from prsn_cntr_pgm_hist  where PRSN_DMGRPHCS_ID = ?) last_push_date
            , (CASE WHEN max_record.contract_end_dt = '01-JAN-9999' THEN NULL ELSE max_record.contract_end_dt END) contract_end_dt
            , biz.STAT_CALC_END_DT
            , (CASE WHEN trunc(biz.STAT_CALC_END_DT) < trunc(SYSDATE) THEN 'Y' ELSE 'N' END) stat_calc_date_passed
            , (select LU_DESC from luv where lu_id=biz.PART_REQUIREMENT_CD_ID) as program_participation_desc
            , (select LU_VAL from  luv where lu_id=biz.PART_REQUIREMENT_CD_ID) as program_participation_val
            , (select LU_VAL from luv where lu_id = pers_stat.HLTH_PLAN_CD_ID) as health_plan_code
            , (select LU_DESC from luv where lu_id = pers_stat.HLTH_PLAN_CD_ID) as health_plan_desc 
            , baseline.EXT_EMP_ID_NO
            , baseline.EMPLOYEE_FLG
            , baseline.ELIG_HIRE_DT
            --, (SELECT QUALFCTN_CHKMRK_NM FROM qualfctn_chkmrk WHERE QUALFCTN_CHKMRK_ID = pers_stat.QUALFCTN_CHKMRK_ID) QUALFCTN_CHKMRK_NM
            , (SELECT lu_desc FROM luv WHERE lu_id = biz.PART_REQUIREMENT_CD_ID) program_participation_desc 
            , pers_stat.CVRGE_EFF_DT       
            FROM
              business_program_type biz_type
            , (SELECT baseline.person_no, baseline.rel_cd, baseline.contract_no, baseline.contract_end_dt, grp_id, subgrp_id, ben_pkg_id, con1.biz_pgm_id, MAX(load_dt) max_load_dt
                     , max(con1.insert_ts) max_con_stat
                FROM prsn_baseline_ds baseline, prsn_demographics demo1
                     , contract_program_status con1
               WHERE PRSN_DMGRPHCS_ID = ? AND demo1.prsn_id = baseline.person_no
                     AND baseline.contract_no=con1.contract_no
                 GROUP BY baseline.person_no, baseline.rel_cd, baseline.contract_no, baseline.contract_end_dt, grp_id, subgrp_id, ben_pkg_id, con1.biz_pgm_id) max_record
            , biz_pgm_incentive_option bpio
            , incentive_option io    
            , pes_rel_ds rel_ds
            , empl_grp_site GROUP_DS
            , contract_program_status con_stat
            , business_program biz
            , person_program_status pers_stat
            , prsn_demographics   person
            , prsn_baseline_ds baseline
            WHERE
                 person.PRSN_DMGRPHCS_ID = ?    
             AND person.PRSN_DMGRPHCS_ID = pers_stat.PRSN_DMGRPHCS_ID
             AND pers_stat.biz_pgm_id = biz.biz_pgm_id
             AND pers_stat.biz_pgm_incntv_optn_id = bpio.biz_pgm_incntv_optn_id
             AND bpio.incntv_optn_id = io.incntv_optn_id 
             AND person.prsn_id = max_record.person_no
             AND max_record.contract_no = con_stat.contract_no
             AND pers_stat.biz_pgm_id = con_stat.biz_pgm_id
             AND biz.biz_pgm_tp_cd = biz_type.biz_pgm_tp_cd
             AND biz.GRP_ID = GROUP_DS.GRP_ID
             AND biz.SUBGRP_ID = GROUP_DS.SUBGRP_ID
             AND con_stat.insert_ts = max_record.max_con_stat
             AND pers_stat.biz_pgm_id = max_record.biz_pgm_id
             AND max_record.rel_cd = rel_ds.RLSHP_CD
             AND max_record.person_no = baseline.person_no
             AND max_record.contract_no = baseline.contract_no
             AND max_record.grp_id = baseline.grp_id
             AND max_record.subgrp_id = baseline.subgrp_id  
             AND max_record.contract_no = baseline.contract_no 
             AND max_record.ben_pkg_id = baseline.ben_pkg_id  
             AND baseline.rel_cd = rel_ds.RLSHP_CD
             AND biz.GRP_ID = baseline.GRP_ID
             AND biz.SUBGRP_ID = baseline.SUBGRP_ID
             AND biz.eff_dt = baseline.biz_pgm_eff_dt
             AND biz.pgm_end_dt = baseline.biz_pgm_end_dt
             AND max_record.rel_cd = pers_stat.rel_cd_id 
             """;

    private static final String selectMemberProgramActivies =
            """
            SELECT DISTINCT
            activity_def.actv_id,
            person.PRSN_DMGRPHCS_ID,
            person.prsn_id,
            stat.BIZ_PGM_ID,
            activity_def.ACTV_ID,
            NVL(elig.cstm_actv_nm, activity_def.actv_nm) actv_nm,
            activity_def.SRCE_ACTV_ID,
            alog.REGISTRATION_ID,
            alog.STAT_CD as activity_stat_val,
            alog.STAT_EFF_DT ACTV_STAT_DT,
            alog.STAT_OUTCM
            , alog.auth_cd
            , alog.PRCSNG_STAT_VAL
            , alog.RSN_DESC
            , alog.insert_ts
            , alog.MODIFY_TS
            , alog.STAT_EFF_DT
            FROM
            prsn_demographics   person
            , person_program_status stat
            , business_program biz
            , activity_event_log alog
            , biz_pgm_auth_code_extended bpace
            , ACTIVITY activity_def LEFT OUTER JOIN eligible_program_activity elig ON activity_def.actv_id = elig.actv_id
            WHERE
            stat.PRSN_DMGRPHCS_ID = ?
            AND stat.BIZ_PGM_ID = ?
            AND stat.biz_pgm_Id = elig.biz_pgm_id
            AND alog.hp_mem_id = person.hp_mem_id
            AND person.PRSN_DMGRPHCS_ID = stat.PRSN_DMGRPHCS_ID
            AND stat.biz_pgm_id = biz.biz_pgm_id
            AND activity_def.srce_actv_id = '0001' --HA
            AND activity_def.SRCE_ACTV_ID = alog.actv_id
            and bpace.biz_pgm_id = stat.biz_pgm_id
            AND alog.auth_cd = bpace.auth_cd
            AND alog.STAT_EFF_DT BETWEEN biz.eff_dt AND biz.pgm_end_dt
            --ORDER BY alog.STAT_EFF_DT
            UNION
            SELECT DISTINCT
            activity_def.actv_id,
            person.PRSN_DMGRPHCS_ID,
            person.prsn_id,
            stat.BIZ_PGM_ID,
            activity_def.ACTV_ID,
            NVL(elig.cstm_actv_nm, activity_def.actv_nm) actv_nm,
            activity_def.SRCE_ACTV_ID,
            alog.REGISTRATION_ID,
            alog.STAT_CD as activity_stat_val,
            alog.STAT_EFF_DT ACTV_STAT_DT,
            alog.STAT_OUTCM
            , alog.auth_cd
            , alog.PRCSNG_STAT_VAL
            , alog.RSN_DESC
            , alog.insert_ts
            , alog.MODIFY_TS
            , alog.STAT_EFF_DT
            FROM
            prsn_demographics   person
            , person_program_status stat
            , business_program biz
            , activity_event_log alog
            , ACTIVITY activity_def LEFT OUTER JOIN eligible_program_activity elig ON activity_def.actv_id = elig.actv_id
            WHERE
            stat.PRSN_DMGRPHCS_ID = ?
            AND stat.BIZ_PGM_ID = ?
            AND stat.biz_pgm_Id = elig.biz_pgm_id
            AND alog.hp_mem_id = person.hp_mem_id
            AND person.PRSN_DMGRPHCS_ID = stat.PRSN_DMGRPHCS_ID
            AND stat.biz_pgm_id = biz.biz_pgm_id
            AND activity_def.srce_actv_id <> '0001' -- not HA
            AND activity_def.SRCE_ACTV_ID = alog.ACTV_ID
            AND alog.STAT_EFF_DT BETWEEN biz.eff_dt AND biz.pgm_end_dt 
            --ORDER BY alog.STAT_EFF_DT;
            """;

    private static final String selectMemberProgramActiviesOutsideEnrollment =
            """
            --EV58500
            SELECT DISTINCT
            person.PRSN_DMGRPHCS_ID,
            person.prsn_id,
            stat.BIZ_PGM_ID,
            activity_def.ACTV_ID,
            activity_def.ACTV_NM,
            activity_def.SRCE_ACTV_ID,
            alog.REGISTRATION_ID,
            alog.STAT_CD as activity_stat_val,
            alog.STAT_EFF_DT ACTV_STAT_DT,
            alog.STAT_OUTCM
            , alog.auth_cd
            , alog.PRCSNG_STAT_VAL
            , alog.RSN_DESC
            , alog.INSERT_TS
            , alog.MODIFY_TS
            FROM
              ACTIVITY activity_def 
            , activity_event_log alog
            ,  prsn_demographics   person
            , person_program_status stat
            , business_program biz
            , eligible_program_activity epa
                        
            WHERE
                stat.PRSN_DMGRPHCS_ID = ?
            AND stat.BIZ_PGM_ID = ?
            AND alog.hp_mem_id = person.hp_mem_id
            AND person.PRSN_DMGRPHCS_ID = stat.PRSN_DMGRPHCS_ID
            AND stat.biz_pgm_id = biz.biz_pgm_id
            AND activity_def.SRCE_ACTV_ID = alog.ACTV_ID
            AND activity_def.SRCE_ACTV_ID = alog.ACTV_ID
            AND alog.STAT_EFF_DT NOT BETWEEN biz.eff_dt AND biz.pgm_end_dt
            --determine enrollment override
            AND epa.biz_pgm_id = biz.biz_pgm_id
            AND activity_def.actv_id = epa.actv_id
            AND epa.incntv_ovrd_tp_cd_id > 0
            AND alog.stat_eff_dt between epa.elig_pgm_actv_eff_dt and epa.elig_pgm_actv_end_dt
            ORDER BY alog.STAT_EFF_DT
                    """;

    private static final String selectMemberProgramActiviesNoDupsToWaive =
            """
            SELECT DISTINCT
            person.PRSN_DMGRPHCS_ID,
            person.prsn_id,
            stat.BIZ_PGM_ID,
            activity_def.ACTV_ID,
            NVL(elig.cstm_actv_nm, activity_def.actv_nm) actv_nm,
            activity_def.SRCE_ACTV_ID,
            ppas.REGISTRATION_ID,
            ppas.STAT_OUTCM,
            (SELECT lu_val FROM luv WHERE lu_id  = ppas.ACTV_STAT_CD_ID) as activity_stat_val,
            ppas.ACTV_STAT_DT as STAT_EFF_DT,
            elig.auth_cd,
            activity_def.INSERT_USR,
            activity_def.MODIFY_USR,
            (CASE (SELECT lu_val FROM luv WHERE lu_id  = ppas.ACTV_STAT_CD_ID) WHEN 'WAIVE' THEN 'WAIVE' WHEN 'ACTV_EXMPT' THEN 'WAIVE' ELSE '' END) as Waive_Flag,
            (ppas.insert_usr) as waive_Insert_User,
            alog.rsn_desc as RSN_DESC
            FROM
              ACTIVITY activity_def  
            , person_program_activity_status ppas
            ,  prsn_demographics   person
            , person_program_status stat
            , business_program biz
            , eligible_program_activity elig
            , activity_event_log alog
            WHERE
                stat.PRSN_DMGRPHCS_ID = ?
            AND stat.BIZ_PGM_ID = ?
            AND stat.PRSN_DMGRPHCS_ID = ppas.PRSN_DMGRPHCS_ID
            AND stat.biz_pgm_id = ppas.biz_pgm_id
            AND stat.PRSN_DMGRPHCS_ID = person.PRSN_DMGRPHCS_ID
            AND stat.biz_pgm_id = biz.biz_pgm_id
            AND biz.BIZ_PGM_STAT_CD_ID = (SELECT lu_id FROM luv WHERE lu_grp='BPM_ACTVTN_STATUS' AND lu_val='ACTIVE')
            AND biz.biz_pgm_id = elig.biz_pgm_id
            AND biz.stat_calc_end_dt >= trunc(SYSDATE)
            AND elig.actv_id = activity_def.actv_id
            AND (NOT (activity_def.actv_id = '0001') OR elig.auth_cd = ppas.auth_cd)
            AND activity_def.ACTV_ID = ppas.ACTV_ID
            --AND alog.STAT_EFF_DT BETWEEN biz.eff_dt AND biz.pgm_end_dt
            AND ppas.ACTV_STAT_DT BETWEEN biz.eff_dt AND biz.pgm_end_dt
            AND person.hp_mem_id = alog.hp_mem_id
            AND alog.actv_id = activity_def.srce_actv_id
            AND trunc(ppas.ACTV_STAT_DT) = trunc(alog.stat_eff_dt)
            AND ppas.REGISTRATION_ID = alog.registration_id
            AND (NOT (activity_def.actv_id = '0001') OR alog.auth_cd = ppas.auth_cd)
            AND NOT (alog.prcsng_stat_val = 'FILTERD_OUT') 
            """;

    private static final String selectMemberProgramActiviesNoDupsToWaiveOutsideEnrollment =
            """
            SELECT DISTINCT
            person.PRSN_DMGRPHCS_ID,
            person.prsn_id,
            stat.BIZ_PGM_ID,
            activity_def.ACTV_ID,
            activity_def.ACTV_NM,
            activity_def.SRCE_ACTV_ID,
            ppas.REGISTRATION_ID,
            ppas.STAT_OUTCM,
            (SELECT lu_val FROM luv WHERE lu_id  = ppas.ACTV_STAT_CD_ID) as activity_stat_val,
            ppas.ACTV_STAT_DT as STAT_EFF_DT,
            elig.auth_cd,
            activity_def.INSERT_USR,
            activity_def.MODIFY_USR,
            (CASE (SELECT lu_val FROM luv WHERE lu_id  = ppas.ACTV_STAT_CD_ID) WHEN 'WAIVE' THEN 'WAIVE' WHEN 'ACTV_EXMPT' THEN 'WAIVE' ELSE '' END) as Waive_Flag,
            (ppas.insert_usr) as waive_Insert_User,
            alog.rsn_desc as RSN_DESC
            FROM
              ACTIVITY activity_def  
            , person_program_activity_status ppas
            ,  prsn_demographics   person
            , person_program_status stat
            , business_program biz
            , eligible_program_activity elig
            , activity_event_log alog
            , eligible_program_activity epa
                        
            WHERE
                stat.PRSN_DMGRPHCS_ID = ?
            AND stat.BIZ_PGM_ID = ?
            AND stat.PRSN_DMGRPHCS_ID = ppas.PRSN_DMGRPHCS_ID
            AND stat.biz_pgm_id = ppas.biz_pgm_id
            AND stat.PRSN_DMGRPHCS_ID = person.PRSN_DMGRPHCS_ID
            AND stat.biz_pgm_id = biz.biz_pgm_id
            AND biz.BIZ_PGM_STAT_CD_ID = (SELECT lu_id FROM luv WHERE lu_grp='BPM_ACTVTN_STATUS' AND lu_val='ACTIVE')
            AND biz.biz_pgm_id = elig.biz_pgm_id
            AND elig.actv_id = activity_def.actv_id
            AND (NOT (activity_def.actv_id = '0001') OR elig.auth_cd = ppas.auth_cd)
            AND activity_def.ACTV_ID = ppas.ACTV_ID
            --AND alog.STAT_EFF_DT BETWEEN biz.eff_dt AND biz.pgm_end_dt
            AND ppas.ACTV_STAT_DT NOT BETWEEN biz.eff_dt AND biz.pgm_end_dt
                        
            --determine enrollment override
            AND epa.biz_pgm_id = biz.biz_pgm_id
            AND activity_def.actv_id = epa.actv_id
            AND epa.incntv_ovrd_tp_cd_id > 0
            AND ppas.ACTV_STAT_DT between epa.qualfctn_early_start_dt and epa.qualfctn_late_end_dt
                        
            AND person.hp_mem_id = alog.hp_mem_id
            AND alog.actv_id = activity_def.srce_actv_id
            AND trunc(ppas.ACTV_STAT_DT) = trunc(alog.stat_eff_dt)
            AND ppas.REGISTRATION_ID = alog.registration_id
            AND (NOT (activity_def.actv_id = '0001') OR alog.auth_cd = ppas.auth_cd)
            AND NOT (alog.prcsng_stat_val = 'FILTERD_OUT')        
            """;

    private static final String selectPersonProgramActivityStatus =
            """
            SELECT DISTINCT
              PERSON_ACTIVITY.PRSN_DMGRPHCS_ID
            , PERSON_ACTIVITY.actv_id
            , biz.biz_pgm_id
            , actv_tp_cd_id
            , (select LU_DESC from luv where lu_id=actv_tp_cd_id) as actv_type_desc
            , (select LU_VAL from  luv where lu_id=actv_tp_cd_id) as actv_type_code_val
            , host_srce
            , completion_duration
            , NVL(elig.cstm_actv_nm, activity.actv_nm) actv_nm
            , NVL(elig.cstm_actv_desc, activity.actv_desc) actv_desc
            , actv_link
            , actv_cost
            , registration_id
            , actv_stat_cd_id
            , statuses.lu_desc as active_stat_desc
            , statuses.lu_val active_stat_code_val
            , actv_stat_dt 
            , srce_actv_id
            , PERSON_ACTIVITY.stat_outcm as active_stat_outcome_val
            , person_activity.auth_cd
            FROM
             business_program BIZ
            ,  prsn_demographics   PERSON
            , eligible_program_activity elig
            , person_program_activity_status PERSON_ACTIVITY
            , activity
            , person_program_status stat
            , luv statuses
            where
                PERSON_ACTIVITY.PRSN_DMGRPHCS_ID = ?
            AND PERSON_ACTIVITY.biz_pgm_id = ?   
            AND PERSON_ACTIVITY.actv_id = activity.actv_id
            AND PERSON.PRSN_DMGRPHCS_ID = PERSON_ACTIVITY.PRSN_DMGRPHCS_ID
            AND stat.PRSN_DMGRPHCS_ID=PERSON.PRSN_DMGRPHCS_ID
            AND biz.biz_pgm_id=stat.biz_pgm_id
            AND PERSON_ACTIVITY.biz_pgm_id = biz.biz_pgm_id
            AND biz.biz_pgm_id = elig.biz_pgm_id
            AND elig.actv_id = activity.actv_id
            AND actv_stat_cd_id = statuses.lu_id          
            """;

    private static final String selectPersonActivityIncentive =
            """
            SELECT
              ppais.biz_pgm_id
              , ppais.prsn_dmgrphcs_id
              , ppais.actv_id
              , NVL(elig.cstm_actv_nm, activity.actv_nm) actv_nm
              , ppais.actv_incntv_id
              , actv_inctv.INCNTV_OPTN_ID
              , iop.INCNTV_OPTN_NM
              , iop.INCNTV_OPTN_DESC
              , iop.INCNTV_URL
              , ppais.registration_id
              , ppais.ACTV_STAT_INCNTV_DT
              , ppais.ACTV_STAT_CD_ID
              , (SELECT lu_val FROM luv WHERE lu_grp='BPM_ACTIVITY_STATUS' and lu_id =ACTV_STAT_CD_ID) ACTV_STAT_CD
              , (SELECT lu_val FROM luv WHERE lu_id = bpiop.incntv_cap_tp_cd_id) incentive_option_unit_cd
              , (SELECT lu_val FROM luv WHERE lu_id = bpiop.INCNTD_STS_TP_CD_ID) incented_status_type_cd
              , bpiop.PARTICIP_CAP
              , bpiop.FAMILY_CAP
              , activity.srce_actv_id
            FROM
              prsn_pgm_actv_incntv_sts ppais
            , activity
            , eligible_program_activity elig
            , activity_incentive actv_inctv
            , incentive_option iop
            , biz_pgm_incentive_option bpiop
            WHERE
                ppais.prsn_dmgrphcs_id = ?
            AND ppais.biz_pgm_id = ?   
            AND ppais.actv_id = activity.actv_id
            AND ppais.ACTV_INCNTV_ID = actv_inctv.ACTV_INCNTV_ID
            AND actv_inctv.INCNTV_OPTN_ID = iop.INCNTV_OPTN_ID
            AND ppais.biz_pgm_id = bpiop.biz_pgm_id
            AND actv_inctv.INCNTV_OPTN_ID = bpiop.INCNTV_OPTN_ID
            AND ppais.biz_pgm_id = elig.biz_pgm_id
            AND ppais.actv_id = elig.actv_id 
            """;

    private static final String selectContractProgramIncentive =
            """
             SELECT
              cpis.BIZ_PGM_ID
            , cpis.CNTR_PGM_STAT_ID
            , cpis.CONTRACT_NO 
            , cpis.CNTR_STAT_CD_ID 
            , (SELECT lu_val from luv where lu_id = CNTR_STAT_CD_ID) CNTR_STAT_CD
            , cpis.CNTR_STS_ACHV_DT 
            , cpis.CNTR_STAT_INCNTV_DT
            , cpis.INCNTV_OPTN_ID
            , iop.INCNTV_OPTN_NM
            , iop.INCNTV_OPTN_DESC
            , iop.INCNTV_URL
            , cpis.ACTVN_STS_TP_CD_ID
            , (SELECT lu_val FROM luv WHERE lu_id = ACTVN_STS_TP_CD_ID) ACTVN_STS_TP_CD
            FROM
              contract_pgm_incntv_sts cpis
            , incentive_option iop
            WHERE
                cpis.contract_no = ?
            AND cpis.biz_pgm_id = ?
            AND cpis.incntv_optn_id = iop.incntv_optn_id   
            """;

    private static final String selectMemberProgramIncentive =
            """
            SELECT
              pmis.PGM_MEM_INCNTV_STAT_ID
            , pmis.BIZ_PGM_ID
            , pmis.INCNTV_OPTN_ID 
            , (SELECT INCNTV_OPTN_NM FROM incentive_option io WHERE io.INCNTV_OPTN_ID = pmis.INCNTV_OPTN_ID) as INCNTV_OPTN_NM\s
            , pmis.PRSN_DMGRPHCS_ID
            , pmis.CONTRACT_NO    
            , pmis.QUALFCTN_CHKMRK_ID
            , (SELECT lu_val FROM luv WHERE lu_id = pmis.MBR_STAT_CD_ID) MBR_STAT_CD\s
            , pmis.modify_ts
            , pmis.mbr_stat_achv_dt
            , pmis.ACTVN_STS_TP_CD_ID
            , (SELECT lu_val FROM luv WHERE lu_id = ACTVN_STS_TP_CD_ID) ACTVN_STS_TP_CD
             FROM pgm_mem_incntv_status pmis
             WHERE
                 pmis.PRSN_DMGRPHCS_ID = ? 
             AND pmis.BIZ_PGM_ID = ?   
             AND pmis.CONTRACT_NO = ?
                                
            """;

    private static final String selectMemberPackages =
            """
            SELECT DISTINCT biz.biz_pgm_id, pkg.ben_pkg_id, pkg.ben_pkg_cd
                 , pkg.ben_pkg_nm
                 , pkg.BEN_PKG_TP
                 , COALESCE((SELECT lu_val FROM luv WHERE lu_id = pkg.PURCH_SUB_TP_CD_ID), pkg.PURCH_SUB_TP_NM) PURCH_SUB_TP_NM
                 , pbl.ben_pkg_eff_dt, pbl.ben_pkg_end_dt
            FROM
                  prsn_demographics demo
                , person_program_status stat
                , business_program biz
                , prsn_baseline_ds pbl
                , pkg_baseline_ds pkg
            WHERE 
                demo.prsn_dmgrphcs_id = ?			
                and demo.prsn_id = pbl.person_no
                and demo.prsn_dmgrphcs_id = stat.prsn_dmgrphcs_id
                and biz.biz_pgm_id = ?
                and stat.biz_pgm_id = biz.biz_pgm_id
                and biz.grp_id = pbl.grp_id
                and biz.subgrp_id = pbl.subgrp_id
                and biz.eff_dt = pbl.biz_Pgm_eff_dt
                and biz.pgm_end_dt = pbl.biz_Pgm_end_dt
                and pbl.grp_id = pkg.grp_id
                and pbl.subgrp_id = pkg.subgrp_id
                and pbl.ben_pkg_id = pkg.ben_pkg_id
                AND pbl.contract_no = ? 
            """;

    private static final String selectMemberStatusDetail =
            """
            SELECT DISTINCT
              pers_stat.PRSN_DMGRPHCS_ID
            , person.prsn_id
            , person.HP_MEM_ID
            , biz.biz_pgm_id
            , con_stat.contract_no
            , con_stat.cntr_stat_cd_id
            , (select LU_VAL from luv WHERE lu_id=con_stat.cntr_stat_cd_id) as cntr_stat_val
            , pers_stat.stat_cd_id
            , (select LU_VAL from luv WHERE lu_id=pers_stat.stat_cd_id) as pers_stat_val
            , trunc(pers_stat.STAT_DT) as member_status_date
            , trunc(con_stat.CNTR_STAT_DT) as contract_status_date
            , (SELECT QUALFCTN_CHKMRK_NM FROM qualfctn_chkmrk WHERE QUALFCTN_CHKMRK_ID = pers_stat.QUALFCTN_CHKMRK_ID) QUALFCTN_CHKMRK_NM
            , io.incntv_optn_nm
            , (SELECT lu_val FROM luv WHERE lu_id = bpio.INCNTD_STS_TP_CD_ID) INCNTD_STS_TP_CD
            , pers_stat.biz_pgm_incntv_optn_ID
            , (SELECT count('s') FROM qualification_override qo WHERE qo.PRSN_DMGRPHCS_ID = pers_stat.PRSN_DMGRPHCS_ID\s
                  AND pers_stat.biz_pgm_incntv_optn_ID = qo.biz_pgm_incntv_optn_ID) has_exemption\s
              FROM
              business_program_type biz_type
            , (SELECT baseline.person_no, baseline.rel_cd, baseline.contract_no, baseline.contract_end_dt, grp_id, subgrp_id, ben_pkg_id, con1.biz_pgm_id, MAX(load_dt) max_load_dt
                FROM prsn_baseline_ds baseline, prsn_demographics demo1
                     , contract_program_status con1
               WHERE PRSN_DMGRPHCS_ID = ? AND demo1.prsn_id = baseline.person_no
                     AND baseline.contract_no=con1.contract_no
                 GROUP BY baseline.person_no, baseline.rel_cd, baseline.contract_no, baseline.contract_end_dt, grp_id, subgrp_id, ben_pkg_id, con1.biz_pgm_id) max_record
            , contract_program_status con_stat
            , business_program biz
            , person_program_status pers_stat
            , prsn_demographics   person
            , prsn_baseline_ds baseline
            , incentive_option io
            , biz_pgm_incentive_option bpio
            WHERE
                 person.PRSN_DMGRPHCS_ID = ?
             AND pers_stat.biz_pgm_id = ?
             AND con_stat.contract_no = ?
             AND person.PRSN_DMGRPHCS_ID = pers_stat.PRSN_DMGRPHCS_ID
             AND pers_stat.biz_pgm_id = biz.biz_pgm_id
             AND person.prsn_id = max_record.person_no
             AND max_record.contract_no = con_stat.contract_no
             AND pers_stat.biz_pgm_id = con_stat.biz_pgm_id
             AND biz.biz_pgm_tp_cd = biz_type.biz_pgm_tp_cd
             AND pers_stat.biz_pgm_id = max_record.biz_pgm_id
             AND max_record.person_no = baseline.person_no
             AND max_record.contract_no = baseline.contract_no
             AND max_record.grp_id = baseline.grp_id
             AND max_record.subgrp_id = baseline.subgrp_id
             AND max_record.contract_no = baseline.contract_no
             AND max_record.ben_pkg_id = baseline.ben_pkg_id
             AND biz.GRP_ID = baseline.GRP_ID
             AND biz.SUBGRP_ID = baseline.SUBGRP_ID
             AND biz.eff_dt = baseline.biz_pgm_eff_dt
             AND biz.pgm_end_dt = baseline.biz_pgm_end_dt
             AND max_record.rel_cd = pers_stat.rel_cd_id
             AND biz.biz_pgm_id = bpio.biz_pgm_id
             AND bpio.incntv_optn_id = io.incntv_optn_id
             AND pers_stat.biz_pgm_incntv_optn_id = bpio.biz_pgm_incntv_optn_id
             AND con_stat.biz_pgm_incntv_optn_id = bpio.biz_pgm_incntv_optn_id
            ORDER BY INCNTV_OPTN_NM
            """;

    private static final String selectMemberIDFromPersonDetails = """
            select hp_mem_id from prsn_demographics
            where 1 = 1 
            """;

    private static final String selectPersonProgramRelationship = """
            SELECT DISTINCT
                demo.prsn_dmgrphcs_id
                , demo.prsn_id
            	, demo.hp_mem_id
            	, baseline.rel_cd
            	, family_codes.lu_val participationCodeValue
            	, family_codes.lu_desc participationCodeDesc
            	, rel_codes.rlshp_txt relationshipText
            	, egs.empl_grp_nm
            	, egs.empl_grp_no
            	, egs.empl_grp_site_id_no
            	, egs.empl_grp_site_nm
            	, biz.eff_dt
            	, biz.pgm_end_dt
            	, biz_type.biz_pgm_nm
            FROM
              prsn_demographics demo
            , prsn_baseline_ds baseline
            , business_program biz
            , business_program_type biz_type
            , luv family_codes
            , pes_rel_ds rel_codes
            , empl_grp_site egs
            WHERE
                demo.hp_mem_id= ?
            AND demo.prsn_id = baseline.person_no
            AND baseline.grp_id = biz.grp_id
            AND baseline.subgrp_id = biz.subgrp_id
            AND biz.grp_id = egs.grp_id
            AND biz.subgrp_id = egs.subgrp_id
            AND baseline.biz_pgm_eff_dt = biz.eff_dt
            AND baseline.biz_pgm_end_dt = biz.pgm_end_dt
            AND biz.part_requirement_cd_id = family_codes.lu_id
            AND baseline.rel_cd = rel_codes.RLSHP_CD
            AND biz.BIZ_PGM_TP_CD = biz_type.BIZ_PGM_TP_CD	
            AND (biz.BIZ_PGM_STAT_CD_ID = (SELECT lu_id FROM  luv  WHERE lu_grp='BPM_ACTVTN_STATUS' AND lu_val='ACTIVE'))
            AND SYSDATE BETWEEN biz.eff_dt AND biz.pgm_end_dt	
            """;
    private static final String getRelatedPersonIDFromMemberID = """
            SELECT DISTINCT PRSN_DMGRPHCS_ID, HP_MEM_ID, FIRST_NM, LAST_NM, rel_ds.RLSHP_TXT rel_txt, baseline.contract_no
            		              , person.prsn_id
            FROM
               prsn_demographics   person
            , prsn_baseline_ds baseline
            , (SELECT max(load_dt) max_load_date FROM prsn_baseline_ds,  prsn_demographics  prsn WHERE hp_mem_id = ? AND person_no = prsn_id) max_record
            , (SELECT contract_no, max(load_dt) max_contract  FROM prsn_baseline_ds,  prsn_demographics   prsn WHERE hp_mem_id = ? AND person_no = prsn_id group by contract_no) contracts
            , pes_rel_ds rel_ds
            WHERE
            baseline.contract_no = contracts.contract_no
            AND contracts.max_contract = max_record.max_load_date
            AND baseline.person_no = person.prsn_id
            AND baseline.rel_cd in (1, 2, 3, 4, 5, 6, 7, 8, 9, 12, 13, 14)
            AND person.hp_mem_id <> ?
            AND baseline.rel_cd = rel_ds.RLSHP_CD
            """;

    private static final String  selectPersonContractsHistory = "select "+
            "PERSON.HP_MEM_ID MEMBER_ID," +
            "HIST.PRSN_CNTR_PGM_HIST_SEQ_ID PERSON_CONTRACT_ID_SEQ, " +
            "HIST.ELIG_CNTR_NO CONTRACT_NO, " +
            "HIST.ELIG_CNTR_STAT CONTRACT_STATUS, " +
            "HIST.ELIG_CNTR_STAT_DT CONTRACT_STAT_DATE, " +
            "HIST.MEM_QUALFCTN_STAT MEMBER_STATUS, " +
            "HIST.MEM_QUALFCTN_STAT_DT MEMBER_STATUS_DATE, " +
            "HIST.GRP_ID, " +
            "HIST.SUBGRP_ID, " +
            "HIST.PRSN_DMGRPHCS_ID, " +
            "HIST.BIZ_PGM_TP_CD PROGRAM_TYPE, " +
            "HIST.QUALFCTN_END_DT, " +
            "HIST.QUALFCTN_START_DT, " +
            "bp.pgm_end_dt, " +
            "bp.eff_dt pgm_eff_dt, " +
            "HIST.INSERT_TS RUN_DT, " +
            "GROUPSITE.EMPL_GRP_NO GROUP_NO, " +
            "GROUPSITE.EMPL_GRP_SITE_ID_NO GROUP_SITE_NO, " +
            "GROUPSITE.EMPL_GRP_NM GROUP_NAME, " +
            "GROUPSITE.EMPL_GRP_SITE_NM GROUP_SITE_NAME, " +
            "BIZ_PGM_TYPE.BIZ_PGM_NM PROGRAM_NAME, " +
            "(select io.incntv_optn_nm from biz_pgm_incentive_option bpio, " +
            "incentive_option io " +
            "where bpio.biz_pgm_incntv_optn_id = hist.biz_pgm_incntv_optn_id and " +
            "bpio.incntv_optn_id = io.incntv_optn_id) incentive_option_name " +
            ", hist.actvn_sts_tp_cd_id " +
            ", (SELECT lu_val FROM luv WHERE lu_id = hist.actvn_sts_tp_cd_id ) actvn_sts_tp_cd " +
            "from prsn_cntr_pgm_hist hist, " +
            "prsn_demographics person, " +
            "empl_grp_site groupsite, " +
            "business_program_type biz_pgm_type, " +
            "person_program_status person_stat, " +
            "business_program bp, " +
            "biz_pgm_incentive_option bpio " +
            "where " +
            "HIST.PRSN_DMGRPHCS_ID = PERSON.PRSN_DMGRPHCS_ID " +
            "AND GROUPSITE.GRP_ID = HIST.GRP_ID " +
            "AND GROUPSITE.SUBGRP_ID = HIST.SUBGRP_ID " +
            "AND BIZ_PGM_TYPE.BIZ_PGM_TP_CD = HIST.BIZ_PGM_TP_CD " +
            "AND person_stat.biz_pgm_id = hist.biz_pgm_id " +
            "AND person_stat.PRSN_DMGRPHCS_ID = hist.PRSN_DMGRPHCS_ID " +
            "AND hist.biz_pgm_id = bp.biz_pgm_id " +
            "and bp.biz_pgm_id = bpio.biz_pgm_id " +
            "and bpio.biz_pgm_incntv_optn_id = hist.biz_pgm_incntv_optn_id " +
            "and bpio.biz_pgm_incntv_optn_id = person_stat.biz_pgm_incntv_optn_id";


    private static final String selectPersonContractsHistoryArchive = "select\n" +
            "\n" +
            "PERSON.HP_MEM_ID MEMBER_ID,\n" +
            "HIST.PRSN_CNTR_PGM_HIST_ARCH_SEQ_ID PERSON_CONTRACT_ID_SEQ, \n" +
            "HIST.ELIG_CNTR_NO CONTRACT_NO,\n" +
            "HIST.ELIG_CNTR_STAT CONTRACT_STATUS,\n" +
            "HIST.ELIG_CNTR_STAT_DT CONTRACT_STAT_DATE,\n" +
            "HIST.MEM_QUALFCTN_STAT MEMBER_STATUS,\n" +
            "HIST.MEM_QUALFCTN_STAT_DT MEMBER_STATUS_DATE,\n" +
            "HIST.GRP_ID,\n" +
            "HIST.SUBGRP_ID,\n" +
            "HIST.PRSN_DMGRPHCS_ID,\n" +
            "HIST.BIZ_PGM_TP_CD PROGRAM_TYPE,\n" +
            "HIST.QUALFCTN_END_DT,\n" +
            "HIST.QUALFCTN_START_DT,\n" +
            "bp.pgm_end_dt,\n" +
            "bp.eff_dt pgm_eff_dt,\n" +
            "HIST.INSERT_TS RUN_DT,\n" +
            "GROUPSITE.EMPL_GRP_NO GROUP_NO,\n" +
            "GROUPSITE.EMPL_GRP_SITE_ID_NO GROUP_SITE_NO,\n" +
            "GROUPSITE.EMPL_GRP_NM GROUP_NAME,\n" +
            "GROUPSITE.EMPL_GRP_SITE_NM GROUP_SITE_NAME,\n" +
            "BIZ_PGM_TYPE.BIZ_PGM_NM PROGRAM_NAME,\n" +
            "(select io.incntv_optn_nm from biz_pgm_incentive_option bpio,\n" +
            "                   incentive_option io\n" +
            "         where bpio.biz_pgm_incntv_optn_id = hist.biz_pgm_incntv_optn_id and\n" +
            "               bpio.incntv_optn_id = io.incntv_optn_id) incentive_option_name\n" +
            ", hist.actvn_sts_tp_cd_id \n" +
            ", (SELECT lu_val FROM luv WHERE lu_id = hist.actvn_sts_tp_cd_id ) actvn_sts_tp_cd               \n" +
            " from prsn_cntr_pgm_hist_archive hist,\n" +
            "      prsn_demographics person,\n" +
            "      empl_grp_site groupsite,\n" +
            "      business_program_type biz_pgm_type,\n" +
            "      person_program_status person_stat,\n" +
            "      business_program bp\n" +
            " where \n" +
            " HIST.PRSN_DMGRPHCS_ID = PERSON.PRSN_DMGRPHCS_ID\n" +
            " AND GROUPSITE.GRP_ID = HIST.GRP_ID\n" +
            " AND GROUPSITE.SUBGRP_ID = HIST.SUBGRP_ID\n" +
            " AND BIZ_PGM_TYPE.BIZ_PGM_TP_CD = HIST.BIZ_PGM_TP_CD\n" +
            " AND person_stat.biz_pgm_id = hist.biz_pgm_id\n" +
            " AND person_stat.PRSN_DMGRPHCS_ID = hist.PRSN_DMGRPHCS_ID\n" +
            " AND hist.biz_pgm_id = bp.biz_pgm_id";

    private static final String selectPersonCDHPFulfillsRecycle = """
            select
              RECYC.CDHP_RECYC_ID
            , CONTRACT_NO
            , GROUP_SITE.EMPL_GRP_NO GROUP_NO
            , RECYC.PRSN_DMGRPHCS_ID
            , PERSON.HP_MEM_ID MEMBER_ID
            , BUS_PROGRAM.BIZ_PGM_ID
            , RECYC.RECYCLE_STAT_ID
            , (select LU_VAL from luv where lu_id=recycle_stat_id) as RECYCLE_STATUS
            , RECYC.RECYCLE_STAT_DT
            , ACTV_ID
            , ACTV_STAT_INCNTV_DT
            , PURCH_SUB_TP_NM
            , RECYC.RSN_DESC
            , RSN_TOLLGATE_RULE
            , RECYC.APRV_USER_ID
            ,(SELECT BIZ_PGM_NM  FROM BUSINESS_PROGRAM_TYPE WHERE  BIZ_PGM_TP_CD = BUS_PROGRAM.BIZ_PGM_TP_CD) as PROGRAM_NAME
            , BUS_PROGRAM.EFF_DT PROGRAM_EFF_DT
            FROM
            CDHP_FULFILL_RECYCLE RECYC
            ,  prsn_demographics   PERSON
            , BUSINESS_PROGRAM BUS_PROGRAM
            , EMPL_GRP_SITE GROUP_SITE
            WHERE
                PERSON.PRSN_DMGRPHCS_ID = RECYC.PRSN_DMGRPHCS_ID
            AND RECYC.BIZ_PGM_ID = BUS_PROGRAM.BIZ_PGM_ID
            AND BUS_PROGRAM.GRP_ID = GROUP_SITE.GRP_ID
            AND BUS_PROGRAM.SUBGRP_ID = GROUP_SITE.SUBGRP_ID
            """;

    private static final String updatePersonCDHPFulfillRecycle = """
            UPDATE cdhp_fulfill_recycle
            SET  recycle_stat_id = ?,
                 rsn_desc = ?,
                 aprv_user_id = ?,
                 modify_usr = ?,
                 recycle_stat_dt = sysdate,
                 modify_ts = sysdate
            WHERE cdhp_recyc_id = ?
            """;

    private static final String updatePersonActivityIncentiveModificationDate = """
            UPDATE prsn_pgm_actv_incntv_sts
            SET
            modify_ts = SYSDATE,
            MODIFY_USR = ?
            WHERE PRSN_DMGRPHCS_ID = ?
            AND BIZ_PGM_ID = ?
            AND ACTV_ID = ?
            """;

    private static final String selectPersonCDHPFulfillRecycle = """
            select
              CDHP_RECYC_ID
            , BIZ_PGM_ID
            , PRSN_DMGRPHCS_ID
            , CONTRACT_NO
            , RECYCLE_STAT_ID
            , (select LU_VAL from luv where lu_id=recycle_stat_id) as RECYCLE_STATUS
            , RECYCLE_STAT_DT
            , ACTV_ID
            , ACTV_STAT_INCNTV_DT
            , PURCH_SUB_TP_NM
            , RSN_DESC
            , RSN_TOLLGATE_RULE
            , APRV_USER_ID
            FROM
            CDHP_FULFILL_RECYCLE
            
            WHERE
                CDHP_RECYC_ID = ?
            """;

    private static final String getMemberProgramDetailsByProgram = """
            SELECT DISTINCT
            pers_stat.PRSN_DMGRPHCS_ID
            , person.prsn_id
            , person.HP_MEM_ID
            , biz.biz_pgm_id
            , con_stat.contract_no
            , (select LU_VAL from luv WHERE lu_id=con_stat.cntr_stat_cd_id) as cntr_stat_val
            , (select LU_VAL from luv WHERE lu_id=pers_stat.stat_cd_id) as pers_stat_val
            , biz.biz_pgm_tp_cd as pgm_tp_cd_id
            , biz_type.BIZ_PGM_NM
            , biz.QUALFCTN_START_DT
            , biz.QUALFCTN_END_DT
            , biz.eff_dt
            , biz.pgm_end_dt
            , GROUP_DS.EMPL_GRP_NO as GRP_NO
            , GROUP_DS.EMPL_GRP_NM as group_name
            , GROUP_DS.EMPL_GRP_SITE_ID_NO as site_id_no
            , GROUP_DS.EMPL_GRP_SITE_NM as site_name
            , biz.NEW_HIRE_DT
            , pers_stat.STAT_DT as member_status_date
            , con_stat.CNTR_STAT_DT as contract_status_date
            , rel_ds.RLSHP_TXT rel_txt
            , (SELECT lu_desc FROM luv WHERE lu_id = biz.PART_REQUIREMENT_CD_ID) program_participation_desc
            , pers_stat.PARTICIPATION_END_DT
            , (CASE WHEN baseline.contract_end_dt = '01-JAN-9999' THEN NULL ELSE contract_end_dt END) contract_end_dt
            , biz_pgm_stat_cd_id
            , (select LU_DESC from luv where lu_id=biz.biz_pgm_stat_cd_id) as program_status_val\s
            , (select LU_DESC from luv where lu_id=biz.biz_pgm_stat_cd_id) as program_status_desc
            , (select LU_VAL from luv where lu_id = pers_stat.HLTH_PLAN_CD_ID) as health_plan_code
            , (select LU_DESC from luv where lu_id = pers_stat.HLTH_PLAN_CD_ID) as health_plan_desc
            , baseline.EXT_EMP_ID_NO
            , baseline.EMPLOYEE_FLG
            , baseline.ELIG_HIRE_DT
            , (SELECT QUALFCTN_CHKMRK_NM FROM qualfctn_chkmrk WHERE QUALFCTN_CHKMRK_ID = pers_stat.QUALFCTN_CHKMRK_ID) QUALFCTN_CHKMRK_NM \s
            , pers_stat.stat_cd_id
            , cntr_stat_cd_id
            , (select max(insert_ts) from prsn_cntr_pgm_hist  where PRSN_DMGRPHCS_ID = ?) last_push_date
            , biz.stat_calc_end_dt
            , (CASE WHEN trunc(biz.STAT_CALC_END_DT) < trunc(SYSDATE) THEN 'Y' ELSE 'N' END) stat_calc_date_passed\s
            , pers_stat.CVRGE_EFF_DT
            , (SELECT count('s') FROM qualification_override qo WHERE qo.PRSN_DMGRPHCS_ID = pers_stat.PRSN_DMGRPHCS_ID\s
                  AND pers_stat.biz_pgm_incntv_optn_ID = qo.biz_pgm_incntv_optn_ID) has_exemption
            , pers_stat.biz_pgm_incntv_optn_id
            , io.incntv_optn_nm
            FROM
            person_program_status pers_stat
            ,  prsn_demographics   person
            , contract_program_status con_stat
            , business_program biz
            , business_program_type biz_type
            , empl_grp_site GROUP_DS
            , prsn_baseline_ds baseline
            , (SELECT contract_no, grp_id, subgrp_id, ben_pkg_id, rel_cd, MAX(load_dt) max_load_dt\s
                 FROM prsn_baseline_ds baseline, prsn_demographics demo1
               WHERE PRSN_DMGRPHCS_ID=? AND demo1.prsn_id = baseline.person_no
               GROUP BY contract_no, grp_id, subgrp_id, ben_pkg_id, rel_cd) max_record
            , pes_rel_ds rel_ds
            , biz_pgm_incentive_option bpio
            , incentive_option io
            WHERE
            pers_stat.PRSN_DMGRPHCS_ID = ?
            AND person.PRSN_DMGRPHCS_ID = pers_stat.PRSN_DMGRPHCS_ID\s
            AND biz.biz_pgm_id = ?
            AND biz.biz_pgm_id = pers_stat.biz_pgm_id
            AND pers_stat.biz_pgm_incntv_optn_id = bpio.biz_pgm_incntv_optn_id
            AND bpio.incntv_optn_id = io.incntv_optn_id\s
            AND biz.biz_pgm_tp_cd = biz_type.biz_pgm_tp_cd
            AND GROUP_DS.GRP_ID = biz.GRP_ID
            AND GROUP_DS.SUBGRP_ID = biz.SUBGRP_ID
            AND con_stat.BIZ_PGM_ID = pers_stat.biz_pgm_id
            AND baseline.person_no = person.prsn_id
             AND baseline.contract_no = con_stat.contract_no
             AND baseline.grp_id = biz.grp_id
             AND baseline.subgrp_id = biz.subgrp_id
             AND baseline.load_dt = max_record.max_load_dt
             AND baseline.grp_id = max_record.grp_id
             AND baseline.subgrp_id = max_record.subgrp_id\s
             AND baseline.contract_no = max_record.contract_no
             AND baseline.ben_pkg_id = max_record.ben_pkg_id\s
             AND baseline.rel_cd = rel_ds.RLSHP_CD
             AND max_record.rel_cd = pers_stat.rel_cd_id
            """;

    private static final String selectPersonContractsRecycle = """
            select
              RECYC.PRSN_CNTR_PGM_RECYCLE_SEQ_ID
            , ELIG_CNTR_NO CONTRACT_NO
            , GROUP_SITE.EMPL_GRP_NO GROUP_NO
            , RECYC.PRSN_DMGRPHCS_ID
            , PERSON.HP_MEM_ID MEMBER_ID
            , BUS_PROGRAM.BIZ_PGM_ID
            , RECYC.PREV_ELIG_CNTR_STAT_ID
            , (select LU_VAL from luv where lu_id=prev_elig_cntr_stat_id) as CONTRACT_STATUS_PREV
            , RECYC.CUR_ELIG_CNTR_STAT_ID
            , (select LU_VAL from luv where lu_id=cur_elig_cntr_stat_id) as CONTRACT_STATUS_CUR
            , RECYC.RECYCLE_STAT_ID
            , (select LU_VAL from luv where lu_id=recycle_stat_id) as RECYCLE_STATUS
            , RECYC.RECYCLE_STAT_DT
            , RECYC.RSN_DESC
            , RECYC.APRV_USR_ID
              , RECYC.INSERT_TS
            ,(SELECT BIZ_PGM_NM  FROM BUSINESS_PROGRAM_TYPE WHERE  BIZ_PGM_TP_CD = BUS_PROGRAM.BIZ_PGM_TP_CD) as PROGRAM_NAME
            , BUS_PROGRAM.EFF_DT PROGRAM_EFF_DT
            FROM
            PRSN_CNTR_PGM_RECYCLE RECYC
            ,  prsn_demographics   PERSON
            , BUSINESS_PROGRAM BUS_PROGRAM
            , EMPL_GRP_SITE GROUP_SITE
            WHERE
                PERSON.PRSN_DMGRPHCS_ID = RECYC.PRSN_DMGRPHCS_ID
            AND RECYC.BIZ_PGM_ID = BUS_PROGRAM.BIZ_PGM_ID
            AND BUS_PROGRAM.GRP_ID = GROUP_SITE.GRP_ID
            AND BUS_PROGRAM.SUBGRP_ID = GROUP_SITE.SUBGRP_ID
            """;

    private static final String updatePersonContractRecycle = """
            UPDATE prsn_cntr_pgm_recycle
            SET  recycle_stat_id = ?, rsn_desc = ?, aprv_usr_id = ?, modify_usr_id = ?, recycle_stat_dt = sysdate, modify_ts = sysdate
            WHERE prsn_cntr_pgm_recycle_seq_id = ?
            """;

    private static final String updateMemberProgramStatusContractStatusDate = """
            UPDATE PERSON_PROGRAM_STATUS SET STAT_DT = SYSDATE WHERE PRSN_DMGRPHCS_ID = ? AND BIZ_PGM_ID = ?
            """;

    private static final String selectPersonContractRecycle = """
            select
              PRSN_CNTR_PGM_RECYCLE_SEQ_ID
            , ELIG_CNTR_NO CONTRACT_NO
            , PRSN_DMGRPHCS_ID
            , BIZ_PGM_ID
            , PREV_ELIG_CNTR_STAT_ID
            , (select LU_VAL from luv where lu_id=prev_elig_cntr_stat_id) as CONTRACT_STATUS_PREV
            , CUR_ELIG_CNTR_STAT_ID
            , (select LU_VAL from luv where lu_id=cur_elig_cntr_stat_id) as CONTRACT_STATUS_CUR
            , RECYCLE_STAT_ID
            , (select LU_VAL from luv where lu_id=recycle_stat_id) as RECYCLE_STATUS
            , RECYCLE_STAT_DT
            , RSN_DESC
            , APRV_USR_ID
            FROM
            PRSN_CNTR_PGM_RECYCLE
            WHERE
                PRSN_CNTR_PGM_RECYCLE_SEQ_ID = ?
            """;

    private String updateParticipationEndDate = "UPDATE person_program_status SET PARTICIPATION_END_DT = ?\n" +
            " WHERE \n" +
            "     PRSN_DMGRPHCS_ID = ?  \n" +
            " AND BIZ_PGM_ID = ?";
    private final DataSource dataSource;
    private final QualificationOverrideDAO qualificationOverrideDAO;



    public PersonDAOJdbc (DataSource dataSource, QualificationOverrideDAO qualificationOverrideDAO) {
        this.dataSource = dataSource;
        this.qualificationOverrideDAO = qualificationOverrideDAO;
    }


    @PostConstruct
    private void initialize() {
        setDataSource(dataSource);
    }

    @Override
    public Collection<PersonActivityContributionPending> getPersonActivityNonEmployerSponsoredContributionsPending(PersonActivityIncentiveSearch lPersonActivityIncentiveSearch)
            throws DataAccessException {

        final ArrayList<PersonActivityContributionPending> lPersonActivityPendingContributions = new ArrayList<PersonActivityContributionPending>();
        ArrayList<Object> lParameters = new ArrayList<Object>();
        ArrayList<Integer> lTypes = new ArrayList<Integer>();
        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectPersonActivityNonEmployerSponsoredContributionsPending);
        JdbcTemplate template = getJdbcTemplate();



        lParameters.add(lPersonActivityIncentiveSearch.getIncentedDate());
        lTypes.add(Integer.valueOf(Types.DATE));

        lParameters.add(lPersonActivityIncentiveSearch.getProductType().substring(8, 11));
        lTypes.add(Integer.valueOf(Types.VARCHAR));

        lParameters.add(lPersonActivityIncentiveSearch.getProductType());
        lTypes.add(Integer.valueOf(Types.VARCHAR));

        lParameters.add(lPersonActivityIncentiveSearch.getProductType().substring(8, 11));
        lTypes.add(Integer.valueOf(Types.VARCHAR));


        if (lPersonActivityIncentiveSearch.getGroupNo() != null && lPersonActivityIncentiveSearch.getGroupNo().length() > 0) {
            lQuery.append(" AND egs.empl_grp_no = ?");
            lParameters.add(lPersonActivityIncentiveSearch.getGroupNo());
            lTypes.add(Integer.valueOf(Types.VARCHAR));
        }

        if (lPersonActivityIncentiveSearch.getSiteNo() != null && lPersonActivityIncentiveSearch.getSiteNo().length() > 0) {
            lQuery.append(" AND egs.empl_grp_site_id_no = ?");
            lParameters.add(lPersonActivityIncentiveSearch.getSiteNo());
            lTypes.add(Integer.valueOf(Types.VARCHAR));
        }

        if (lPersonActivityIncentiveSearch.getContractNo() != null && lPersonActivityIncentiveSearch.getContractNo().length() > 0) {
            lQuery.append(" AND pbl.contract_no = ?");
            lParameters.add(lPersonActivityIncentiveSearch.getContractNo());
            lTypes.add(Integer.valueOf(Types.VARCHAR));
        }

        if (lPersonActivityIncentiveSearch.getMemberNo() != null && lPersonActivityIncentiveSearch.getMemberNo().length() > 0) {
            lQuery.append(" AND demo.hp_mem_id = ?");
            lParameters.add(lPersonActivityIncentiveSearch.getMemberNo());
            lTypes.add(Integer.valueOf(Types.VARCHAR));
        }


        if (lPersonActivityIncentiveSearch.getProgramStartDate() != null) {
            lQuery.append(" AND biz.eff_dt = ?");
            lParameters.add(lPersonActivityIncentiveSearch.getProgramStartDate());
            lTypes.add(Integer.valueOf(Types.DATE));
        }




        lQuery.append(" order by egs.empl_grp_no, pbl.CONTRACT_NO asc");


        // Convert the parameter arraylists to arrays.
        Object params[] = new Object[lParameters.size()];
        lParameters.toArray(params);

        int types[] = new int[lTypes.size()];
        for(int j = 0; j < lTypes.size(); j++)
        {
            types[j] = ((Integer)lTypes.get(j)).intValue();
        }

        try {
            template.query(lQuery.toString(), params, types,
                    new RowCallbackHandler() {
                        public void processRow(ResultSet rs) throws SQLException {
                            PersonActivityContributionPending personPendingContribution = new PersonActivityContributionPending();
                            personPendingContribution.setPersonID(Integer.valueOf(rs
                                    .getInt("PRSN_ID")));
                            personPendingContribution.setPersonDemographicsID(rs.getInt("PRSN_DMGRPHCS_ID"));
                            personPendingContribution.setContractNo(Integer.valueOf(rs
                                    .getInt("CONTRACT_NO")));
                            personPendingContribution.setMemberNo(rs
                                    .getString("HP_MEM_ID"));
                            personPendingContribution.setFirstName(rs
                                    .getString("first_nm"));
                            personPendingContribution.setLastName(rs
                                    .getString("last_nm"));
                            personPendingContribution.setGroupID(Integer.valueOf(rs
                                    .getInt("GRP_ID")));
                            personPendingContribution.setSubgroupID(Integer.valueOf(rs
                                    .getInt("SUBGRP_ID")));
                            personPendingContribution.setPackageID(Integer.valueOf(rs
                                    .getInt("ben_pkg_id")));

                            personPendingContribution.setGroupNo(rs
                                    .getString("empl_grp_no"));
                            personPendingContribution.setSiteNo(rs
                                    .getString("empl_grp_site_id_no"));
                            personPendingContribution.setPackageSubTypeName(rs
                                    .getString("purch_sub_tp_nm"));

                            personPendingContribution.setSourceActivityID(rs
                                    .getString("SRCE_ACTV_ID"));
                            personPendingContribution.setActivityName(rs
                                    .getString("activity_name"));
                            personPendingContribution.setActivityStatDate(rs
                                    .getDate("activity_stat_dt"));

                            personPendingContribution.setActivityIncentiveStatus((rs
                                    .getString("activity_incntv_status")));
                            personPendingContribution.setProgramType((rs
                                    .getString("program_type")));
                            personPendingContribution.setProgramID(Integer.valueOf(rs
                                    .getInt("biz_pgm_id")));
                            personPendingContribution.setBusinessProgramTypeCode(Integer.valueOf(rs
                                    .getInt("biz_pgm_tp_cd")));
                            personPendingContribution.setParticipantCap(Integer.valueOf(rs
                                    .getInt("particip_cap")));
                            personPendingContribution.setFamilyCap(Integer.valueOf(rs
                                    .getInt("family_cap")));
                            personPendingContribution.setContributionAmt(Integer.valueOf(rs
                                    .getInt("amount_achieved")));
                            personPendingContribution.setContributionDate(rs
                                    .getDate("contribution_date"));
                            personPendingContribution.setBenefitContractType(rs
                                    .getString("benefit_contract_type"));
                            personPendingContribution.setIncentiveOptionID(rs
                                    .getInt("incntv_optn_id"));
                            personPendingContribution.setIncentedDate(rs
                                    .getDate("incented_date"));


                            lPersonActivityPendingContributions.add(personPendingContribution);

                        }
                    });

        } catch (Exception e) {
            logger.error(e);
        }
        return lPersonActivityPendingContributions;
    }
    //Produces warnings during compile time to quickly identify typos or API changes
    @Override
    public Collection<PersonActivityContributionPending> getPersonActivityEmployerSponsoredContributionsPending(PersonActivityIncentiveSearch lPersonActivityIncentiveSearch)
            throws DataAccessException {

        final ArrayList<PersonActivityContributionPending> lPersonActivityPendingContributions = new ArrayList<PersonActivityContributionPending>();
        ArrayList<Object> lParameters = new ArrayList<Object>();
        ArrayList<Integer> lTypes = new ArrayList<Integer>();
        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectPersonActivityEmployerSponsoredContributionsPending);
        JdbcTemplate template = getJdbcTemplate();



        lParameters.add(lPersonActivityIncentiveSearch.getIncentedDate());
        lTypes.add(Integer.valueOf(Types.DATE));

        lParameters.add(lPersonActivityIncentiveSearch.getProductType().substring(8, 11));
        lTypes.add(Integer.valueOf(Types.VARCHAR));

        lParameters.add(lPersonActivityIncentiveSearch.getProductType());
        lTypes.add(Integer.valueOf(Types.VARCHAR));

        lParameters.add(lPersonActivityIncentiveSearch.getProductType().substring(8, 11));
        lTypes.add(Integer.valueOf(Types.VARCHAR));


        if (lPersonActivityIncentiveSearch.getGroupNo() != null && lPersonActivityIncentiveSearch.getGroupNo().length() > 0) {
            lQuery.append(" AND egs.empl_grp_no = ?");
            lParameters.add(lPersonActivityIncentiveSearch.getGroupNo());
            lTypes.add(Integer.valueOf(Types.VARCHAR));
        }

        if (lPersonActivityIncentiveSearch.getSiteNo() != null && lPersonActivityIncentiveSearch.getSiteNo().length() > 0) {
            lQuery.append(" AND egs.empl_grp_site_id_no = ?");
            lParameters.add(lPersonActivityIncentiveSearch.getSiteNo());
            lTypes.add(Integer.valueOf(Types.VARCHAR));
        }

        if (lPersonActivityIncentiveSearch.getContractNo() != null && lPersonActivityIncentiveSearch.getContractNo().length() > 0) {
            lQuery.append(" AND pbl.contract_no = ?");
            lParameters.add(lPersonActivityIncentiveSearch.getContractNo());
            lTypes.add(Integer.valueOf(Types.VARCHAR));
        }

        if (lPersonActivityIncentiveSearch.getMemberNo() != null && lPersonActivityIncentiveSearch.getMemberNo().length() > 0) {
            lQuery.append(" AND demo.hp_mem_id = ?");
            lParameters.add(lPersonActivityIncentiveSearch.getMemberNo());
            lTypes.add(Integer.valueOf(Types.VARCHAR));
        }


        if (lPersonActivityIncentiveSearch.getProgramStartDate() != null) {
            lQuery.append(" AND biz.eff_dt = ?");
            lParameters.add(lPersonActivityIncentiveSearch.getProgramStartDate());
            lTypes.add(Integer.valueOf(Types.DATE));
        }


        lQuery.append(" order by egs.empl_grp_no, pbl.CONTRACT_NO asc");


        // Convert the parameter arraylists to arrays.
        Object params[] = new Object[lParameters.size()];
        lParameters.toArray(params);

        int types[] = new int[lTypes.size()];
        for(int j = 0; j < lTypes.size(); j++)
        {
            types[j] = ((Integer)lTypes.get(j)).intValue();
        }

        template.query(lQuery.toString(), params, types,
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException
                    {
                        PersonActivityContributionPending personPendingContribution = new PersonActivityContributionPending();
                        personPendingContribution.setPersonID(Integer.valueOf(rs
                                .getInt("PRSN_ID")));
                        personPendingContribution.setPersonDemographicsID(rs.getInt("PRSN_DMGRPHCS_ID"));
                        personPendingContribution.setContractNo(Integer.valueOf(rs
                                .getInt("CONTRACT_NO")));
                        personPendingContribution.setMemberNo(rs
                                .getString("HP_MEM_ID"));
                        personPendingContribution.setFirstName(rs
                                .getString("first_nm"));
                        personPendingContribution.setLastName(rs
                                .getString("last_nm"));
                        personPendingContribution.setPackageID(Integer.valueOf(rs
                                .getInt("ben_pkg_id")));
                        personPendingContribution.setGroupID(Integer.valueOf(rs
                                .getInt("GRP_ID")));
                        personPendingContribution.setSubgroupID(Integer.valueOf(rs
                                .getInt("SUBGRP_ID")));
                        personPendingContribution.setGroupNo(rs
                                .getString("empl_grp_no"));
                        personPendingContribution.setSiteNo(rs
                                .getString("empl_grp_site_id_no"));
                        personPendingContribution.setPackageSubTypeName(rs
                                .getString("purch_sub_tp_nm"));

                        personPendingContribution.setSourceActivityID(rs
                                .getString("SRCE_ACTV_ID"));
                        personPendingContribution.setActivityName(rs
                                .getString("ACTIVITY_NAME"));
                        personPendingContribution.setActivityStatDate(rs
                                .getDate("activity_stat_dt"));
                        personPendingContribution.setActivityIncentiveStatus((rs
                                .getString("activity_incntv_status")));
                        personPendingContribution.setProgramType((rs
                                .getString("program_type")));
                        personPendingContribution.setProgramID(Integer.valueOf(rs
                                .getInt("biz_pgm_id")));
                        personPendingContribution.setBusinessProgramTypeCode(Integer.valueOf(rs
                                .getInt("biz_pgm_tp_cd")));
                        personPendingContribution.setIncentiveOptionID(rs
                                .getInt("incntv_optn_id"));
                        personPendingContribution.setParticipantCap(Integer.valueOf(rs
                                .getInt("particip_cap")));
                        personPendingContribution.setFamilyCap(Integer.valueOf(rs
                                .getInt("family_cap")));
                        personPendingContribution.setContributionAmt(Integer.valueOf(rs
                                .getInt("amount_achieved")));
                        personPendingContribution.setContributionDate(rs
                                .getDate("contribution_date"));
                        personPendingContribution.setBenefitContractType(rs
                                .getString("benefit_contract_type"));
                        personPendingContribution.setIncentedDate(rs
                                .getDate("incented_date"));


                        lPersonActivityPendingContributions.add(personPendingContribution);

                    }
                });


        return lPersonActivityPendingContributions;
    }


    /**
     * Delete all entries in the person_program_activity_status for the given biz_pgm_id.
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Override
    public int deletePersonProgramActivities(Integer businessProgramID)
            throws DataAccessException
    {
        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[] { businessProgramID };
        int types[] = new int[] { Types.INTEGER };

        StringBuffer lQuery = new StringBuffer();
        lQuery.append(deletePersonProgramActivities);
        lQuery.append(" WHERE biz_pgm_id = ? ");

        return template.update(lQuery.toString(), params, types);
    }


    /**
     *
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Override
    public int deletePersonPrograms(Integer pProgramIncentiveOptionID)
            throws DataAccessException
    {
        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[] { pProgramIncentiveOptionID };
        int types[] = new int[] { Types.INTEGER };

        StringBuffer lQuery = new StringBuffer();
        lQuery.append(deletePersonPrograms);
        lQuery.append(" BIZ_PGM_INCNTV_OPTN_ID = ? ");

        return template.update(lQuery.toString(), params, types);
    }

    /**
     * Return a collection of person relationship code objects
     *

     * @return
     */
    @Override
    public Collection<PersonRelationshipCode> getPersonRelationshipCodes() throws DataAccessException {
        final ArrayList<PersonRelationshipCode> lPersonRelationshipCodes = new ArrayList<PersonRelationshipCode>();

        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{};
        int types[] = new int[]{};

        template.query(selectPersonRelationshipCodes, params, types,
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        PersonRelationshipCode lPersonRelationshipCode = new PersonRelationshipCode();

                        lPersonRelationshipCode.setRelationshipCodeID(rs.getInt("RLSHP_CD"));
                        lPersonRelationshipCode.setRelationshipName(rs.getString("RLSHP_TXT"));

                        lPersonRelationshipCodes.add(lPersonRelationshipCode);
                    }
                });

        return lPersonRelationshipCodes;
    }

    /**
     * Update member status given the luv Code Value of the new status.
     *
     * @param pPersonID
     * @param pProgramID
     * @param pNewStatus
     * @param pUserID
     * @return
     * @throws DataAccessException
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Override
    public int updateMemberStatusByCodeValue(Integer pPersonID, Integer pProgramID, Integer pGroupID, String pNewStatus, String pUserID) throws DataAccessException {
        StringBuffer lQuery = new StringBuffer();
        lQuery.append(updateMemberStatusByCodeValue);
        JdbcTemplate template = getJdbcTemplate();
        Object params[] = null;
        int types[] = null;

        if ((pPersonID != null && pPersonID > 0) || (pProgramID != null && pProgramID > 0)) {
            lQuery.append("WHERE 1=1 ");

            params = new Object[]{pNewStatus, pUserID};
            types = new int[]{Types.VARCHAR, Types.CHAR};

            if (pPersonID != null && pPersonID > 0) {
                lQuery.append("AND PRSN_DMGRPHCS_ID = ");
                lQuery.append(pPersonID);
            }
            if (pProgramID != null && pProgramID > 0) {
                lQuery.append("AND biz_pgm_id = ");
                lQuery.append(pProgramID);
            }
        } else if (pGroupID != null && pGroupID > 0) {
            lQuery.append("WHERE biz_pgm_id IN ");
            lQuery.append("(");
            lQuery.append("SELECT biz_pgm_id FROM business_program WHERE grp_id = ? AND trunc(sysdate) <= STAT_CALC_END_DT ");
            lQuery.append(")");
            params = new Object[]{pNewStatus, pUserID, pGroupID};
            types = new int[]{Types.VARCHAR, Types.CHAR, Types.INTEGER};
        }


        return template.update(lQuery.toString(), params, types);
    }

    @Override
    public int deletePersonProgramsByProgramIncentiveOptionID(Integer pProgramIncentiveOptionID) throws DataAccessException {
        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{pProgramIncentiveOptionID};
        int types[] = new int[]{Types.INTEGER};

        StringBuffer lQuery = new StringBuffer();
        lQuery.append(deletePersonPrograms);
        lQuery.append(" BIZ_PGM_INCNTV_OPTN_ID = ? ");

        return template.update(lQuery.toString(), params, types);
    }

    @Override
    public boolean isActivityRequirementRegisteredToPersonProgramActivityStatus(Integer programID, Integer activityID) throws BPMException, DataAccessException {
        boolean isActivityRequirementRegisteredToPersonProgramActivityStatus = false;

        final ArrayList<Integer> result = new ArrayList<Integer>();

        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{programID,
                activityID};
        int types[] = new int[]{Types.INTEGER, Types.INTEGER};

        template.query(countProgramActivity, params, types, new RowCallbackHandler() {
            public void processRow(ResultSet rs) throws SQLException {

                result.add(rs.getInt("countProgramActivity"));

            }
        });

        if (result.get(0) > 0) {
            isActivityRequirementRegisteredToPersonProgramActivityStatus = true;
        }

        return isActivityRequirementRegisteredToPersonProgramActivityStatus;
    }

    @Override
    public Integer getPersonID(String memberID) throws DataAccessException {
        final ArrayList<Integer> results = new ArrayList<Integer>();
        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{memberID};
        int types[] = new int[]{Types.VARCHAR};
        template.query(getPersonIDFromMemberID, params, types,
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        results.add((rs.getObject(1) != null) ? rs
                                .getInt(1) : null);
                    }
                });

        Integer personID = null;
        if (results.size() > 0) {
            personID = (Integer) results.get(0);
        }
        return personID;
    }

    @Override
    public MemberDetail getMemberDetail(Integer personID, Date qualificationStartDate) throws DataAccessException {
        final ArrayList<MemberDetail> results = new ArrayList<MemberDetail>();
        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{personID, personID};
        int types[] = new int[]{Types.INTEGER, Types.INTEGER};
        template.query(getPersonDetails, params, types,
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        MemberDetail memberDetail = new MemberDetail();
                        memberDetail.setPersonID(rs.getInt("prsn_id"));
                        memberDetail.setMemberID(rs.getString("hp_mem_id"));
                        memberDetail.setFirstName(rs.getString("first_nm"));
                        memberDetail.setLastName(rs.getString("last_nm"));
                        memberDetail.setMiddleInitial(rs.getString("middle_nm"));
                        memberDetail.setBirthDate(rs.getDate("dob_dt"));
                        memberDetail.setPersonDemographicsID(rs.getInt("prsn_dmgrphcs_id"));

                        if (rs.getInt("program_demog_id") > 0) {
                            memberDetail.setHasBPMProgram("Y");
                        } else {
                            memberDetail.setHasBPMProgram("");
                        }

                        results.add(memberDetail);
                    }
                });

        MemberDetail memberDetail = null;
        if (results.size() > 0) {
            memberDetail = results.get(0);
            //memberDetail.setMemberProgramDetails(getMemberProgramDetails(
            //		personID, qualificationStartDate));
        }

        return memberDetail;
    }

    @Override
    public Collection<MemberProgramDetail> getMemberProgramDetails(Integer personID, Date qualificationStartDate) throws DataAccessException, DataAccessException {
        StringBuffer query = new StringBuffer();
        query.append(getMemberProgramDetails);
        Object params[];
        int types[];
        if (qualificationStartDate != null) {
            query.append("AND biz.QUALFCTN_START_DT >= ? ");
            params = new Object[]{personID, personID, personID, qualificationStartDate};
            types = new int[]{Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.DATE};
        } else {
            params = new Object[]{personID, personID, personID};
            types = new int[]{Types.INTEGER, Types.INTEGER, Types.INTEGER};
        }

        query.append(" ORDER BY biz.QUALFCTN_START_DT DESC, pers_stat.PARTICIPATION_END_DT DESC ");

        JdbcTemplate template = getJdbcTemplate();

        ArrayList<MemberProgramDetail> lMemberProgramDetails = (ArrayList<MemberProgramDetail>)
                template.query(query.toString(), params, types, new MemberProgramRowMapper());

        for (MemberProgramDetail memberProgramDetail : lMemberProgramDetails) {
            memberProgramDetail
                    .setMemberExemptions(qualificationOverrideDAO
                            .getAllQualificationOverrides(
                                    memberProgramDetail
                                            .getPersonDemographicsID(),
                                    memberProgramDetail
                                            .getProgramID()));

            Collection<MemberProgramActivity> memberActivities = getMemberProgramActivities(
                    memberProgramDetail.getPersonDemographicsID(),
                    memberProgramDetail.getProgramID());
            memberProgramDetail
                    .setMemberActivities(memberActivities);

            Collection<MemberProgramActivity> memberActivitiesNoDupsToWaive = getMemberProgramActivitiesNoDupsToWaive(
                    memberProgramDetail.getPersonDemographicsID(),
                    memberProgramDetail.getProgramID());
            memberProgramDetail
                    .setMemberActivitiesNoDups(memberActivitiesNoDupsToWaive);

            memberProgramDetail.setPersonProgramActivities(getPersonProgramActivityStatus(memberProgramDetail.getPersonDemographicsID(),
                    memberProgramDetail.getProgramID()));

            memberProgramDetail.setPersonActivityIncentives(selectPersonActivityIncentive(memberProgramDetail.getPersonDemographicsID(),
                    memberProgramDetail.getProgramID()));

            memberProgramDetail.setContractProgramIncentives(selectContractProgramIncentive(memberProgramDetail.getContractNumber(),
                    memberProgramDetail.getProgramID()));

            memberProgramDetail.setMemberProgramIncentives(getMemberProgramIncentive(memberProgramDetail.getPersonDemographicsID(),
                    memberProgramDetail.getProgramID(), memberProgramDetail.getContractNumber()));

            memberProgramDetail.setMemberPackages(getMemberPackages(memberProgramDetail.getPersonDemographicsID(),
                    memberProgramDetail.getProgramID(), memberProgramDetail.getContractNumber()));

            memberProgramDetail.setMemberStatusDetails(getMemberStatusDetails(memberProgramDetail.getPersonDemographicsID(), memberProgramDetail.getProgramID(), memberProgramDetail.getContractNumber()));

        }

        return lMemberProgramDetails;
    }

    @Override
    public Collection<MemberProgramActivity> getMemberProgramActivities(Integer personID, Integer programID) throws DataAccessException, DataAccessException {
        ArrayList<MemberProgramActivity> results = new ArrayList<MemberProgramActivity>();
        Collection<MemberProgramActivity> resultsOutsideEnrollment = new ArrayList<MemberProgramActivity>();

        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{personID, programID, personID, programID};
        int types[] = new int[]{Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.INTEGER};
        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectMemberProgramActivies);

        results = (ArrayList<MemberProgramActivity>) template.query(lQuery
                .toString(), params, types, new memberProgramActivityMapper());

        resultsOutsideEnrollment = getMemberProgramActivitiesOutsideEnrollment(personID, programID);

        if (resultsOutsideEnrollment.size() > 0) {
            results.addAll(resultsOutsideEnrollment);
        }

        return results;
    }

    @Override
    public Collection<MemberProgramActivity> getMemberProgramActivitiesOutsideEnrollment(Integer personID, Integer programID) throws DataAccessException, DataAccessException {
        ArrayList<MemberProgramActivity> results = new ArrayList<MemberProgramActivity>();
        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{personID, programID};
        int types[] = new int[]{Types.INTEGER, Types.INTEGER};
        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectMemberProgramActiviesOutsideEnrollment);

        results = (ArrayList<MemberProgramActivity>) template.query(lQuery
                .toString(), params, types, new memberProgramActivityMapper());

        return results;
    }

    @Override
    public Collection<MemberProgramActivity> getMemberProgramActivitiesNoDupsToWaive(Integer personID, Integer programID) throws DataAccessException, DataAccessException {
        ArrayList<MemberProgramActivity> results = new ArrayList<MemberProgramActivity>();
        Collection<MemberProgramActivity> resultsOutsideEnrollment = new ArrayList<MemberProgramActivity>();

        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{personID, programID};
        int types[] = new int[]{Types.INTEGER, Types.INTEGER};
        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectMemberProgramActiviesNoDupsToWaive);

        results = (ArrayList<MemberProgramActivity>) template.query(lQuery
                .toString(), params, types, new memberProgramActivityNoDupsToWaiveMapper());

        resultsOutsideEnrollment = getMemberProgramActivitiesNoDupsToWaiveOutsideEnrollment(personID, programID);

        if (resultsOutsideEnrollment.size() > 0) {
            results.addAll(resultsOutsideEnrollment);
        }


        return results;
    }

    @Override
    public Collection<MemberProgramActivity> getMemberProgramActivitiesNoDupsToWaiveOutsideEnrollment(Integer personID, Integer programID) throws DataAccessException, DataAccessException {
        ArrayList<MemberProgramActivity> results = new ArrayList<MemberProgramActivity>();
        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{personID, programID};
        int types[] = new int[]{Types.INTEGER, Types.INTEGER};
        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectMemberProgramActiviesNoDupsToWaiveOutsideEnrollment);

        results = (ArrayList<MemberProgramActivity>) template.query(lQuery
                .toString(), params, types, new memberProgramActivityNoDupsToWaiveMapper());


        return results;
    }

    /**
     * Retrieve the list of member activities by person ID and business program ID.
     *
     * @param personId
     * @param programID
     * @return
     */
    @Override
    public Collection<MemberActivity> getPersonProgramActivityStatus(Integer personId, Integer programID) {
        ArrayList<MemberActivity> lMemberActivities = new ArrayList<MemberActivity>();

        JdbcTemplate template = getJdbcTemplate();
        StringBuffer lQuery = new StringBuffer();
        Object params[] = null;
        int types[] = null;

        lQuery.append(selectPersonProgramActivityStatus);

        params = new Object[]{personId, programID};
        types = new int[]{Types.INTEGER, Types.INTEGER};

        lQuery.append(" ORDER BY PERSON_ACTIVITY.actv_stat_dt ");

        lMemberActivities = (ArrayList<MemberActivity>) template.query(lQuery
                .toString(), params, types, new activityMapper());

        for (int i = 0; i < params.length; i++) {
            params[i] = null;
        }
        types = null;

        return lMemberActivities;
    }

    /**
     * Return a collection of Person Program Activity Incentive Status objects.
     *
     * @param pPersonDemographicsID
     * @return
     */
    @Override
    public Collection<PersonActivityIncentive> selectPersonActivityIncentive(Integer pPersonDemographicsID, Integer pBusinessProgramID) {
        final ArrayList<PersonActivityIncentive> lPersonActivityIncentives = new ArrayList<PersonActivityIncentive>();

        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{pPersonDemographicsID, pBusinessProgramID};
        int types[] = new int[]{Types.INTEGER, Types.INTEGER};

        template.query(selectPersonActivityIncentive, params, types,
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        PersonActivityIncentive lPersonActivityIncentive = new PersonActivityIncentive();

                        lPersonActivityIncentive.setPersonDemographicsID(rs.getInt("PRSN_DMGRPHCS_ID"));
                        lPersonActivityIncentive.setBusinessProgramID(rs.getInt("BIZ_PGM_ID"));
                        lPersonActivityIncentive.setActivityID(rs.getInt("ACTV_ID"));
                        lPersonActivityIncentive.setActivityName(rs.getString("ACTV_NM"));
                        lPersonActivityIncentive.setActivityStatusCodeID(rs.getInt("ACTV_STAT_CD_ID"));
                        lPersonActivityIncentive.setActivityStatusCode(rs.getString("ACTV_STAT_CD"));
                        lPersonActivityIncentive.setActivityDate(rs.getDate("ACTV_STAT_INCNTV_DT"));
                        lPersonActivityIncentive.setIncentiveOptionID(rs.getInt("INCNTV_OPTN_ID"));
                        lPersonActivityIncentive.setIncentiveOptionName(rs.getString("INCNTV_OPTN_NM"));
                        lPersonActivityIncentive.setIncentiveOptionDesc(rs.getString("INCNTV_OPTN_DESC"));
                        lPersonActivityIncentive.setRegistrationID(rs.getString("registration_id"));
                        lPersonActivityIncentive.setIncentedStatusTypeCode(rs.getString("incented_status_type_cd"));
                        lPersonActivityIncentive.setIncentiveOptionUnitTypeCode(rs.getString("incentive_option_unit_cd"));
                        lPersonActivityIncentive.setParticipantCap(rs.getInt("PARTICIP_CAP"));
                        lPersonActivityIncentive.setFamilyCap(rs.getInt("FAMILY_CAP"));
                        lPersonActivityIncentive.setSourceActivityID(rs.getString("srce_actv_id"));

                        lPersonActivityIncentives.add(lPersonActivityIncentive);
                    }
                });

        return lPersonActivityIncentives;
    }

    /**
     * Returns a collection of Contract Program Incentive objects.
     *
     * @param pContractNo
     * @param pBusinessProgramID
     * @return
     */
    @Override
    public Collection<ContractProgramIncentive> selectContractProgramIncentive(Integer pContractNo, Integer pBusinessProgramID) {
        final ArrayList<ContractProgramIncentive> lContractProgramIncentives = new ArrayList<ContractProgramIncentive>();

        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{pContractNo, pBusinessProgramID};
        int types[] = new int[]{Types.INTEGER, Types.INTEGER};

        template.query(selectContractProgramIncentive, params, types,
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        ContractProgramIncentive lContractProgramIncentive = new ContractProgramIncentive();

                        lContractProgramIncentive.setBusinessProgramID(rs.getInt("BIZ_PGM_ID"));
                        lContractProgramIncentive.setContractNumber(rs.getInt("CONTRACT_NO"));
                        lContractProgramIncentive.setContractStatusCode(rs.getString("CNTR_STAT_CD"));
                        lContractProgramIncentive.setContractStatusCodeID(rs.getInt("CNTR_STAT_CD_ID"));
                        lContractProgramIncentive.setContractStatusAchievedDate(rs.getDate("CNTR_STS_ACHV_DT"));
                        lContractProgramIncentive.setContractStatusDate(rs.getDate("CNTR_STAT_INCNTV_DT"));
                        lContractProgramIncentive.setIncentiveOptionID(rs.getInt("INCNTV_OPTN_ID"));
                        lContractProgramIncentive.setIncentiveOptionName(rs.getString("INCNTV_OPTN_NM"));
                        lContractProgramIncentive.setIncentiveOptionDesc(rs.getString("INCNTV_OPTN_DESC"));
                        lContractProgramIncentive.setActivationStatusCodeID(rs.getInt("ACTVN_STS_TP_CD_ID"));
                        lContractProgramIncentive.setActivationStatusCode(rs.getString("ACTVN_STS_TP_CD"));

                        lContractProgramIncentives.add(lContractProgramIncentive);
                    }
                });

        return lContractProgramIncentives;
    }

    @Override
    public Collection<MemberProgramIncentiveTO> getMemberProgramIncentive(Integer pPersonDemographicsID, Integer pBusinessProgramID, Integer pContractNo) throws DataAccessException {
        final ArrayList<MemberProgramIncentiveTO> lMemberProgramIncentives = new ArrayList<MemberProgramIncentiveTO>();

        JdbcTemplate template = getJdbcTemplate();
        ArrayList<Object> lParameters = new ArrayList<Object>();
        ArrayList<Integer> lTypes = new ArrayList<Integer>();

        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectMemberProgramIncentive);

        lParameters.add(pPersonDemographicsID);
        lParameters.add(pBusinessProgramID);
        lParameters.add(pContractNo);

        lTypes.add(Types.INTEGER);
        lTypes.add(Types.INTEGER);
        lTypes.add(Types.INTEGER);

        Object params[] = new Object[lParameters.size()];
        lParameters.toArray(params);

        int types[] = new int[lTypes.size()];
        for (int j = 0; j < lTypes.size(); j++) {
            types[j] = ((Integer) lTypes.get(j)).intValue();
        }

        template.query(lQuery.toString(), params, types, new RowCallbackHandler() {
            public void processRow(ResultSet rs) throws SQLException {
                MemberProgramIncentiveTO lMemberProgramIncentiveTO = new MemberProgramIncentiveTO();
                lMemberProgramIncentiveTO.setMemberProgramStatusID(rs.getInt("PGM_MEM_INCNTV_STAT_ID"));
                lMemberProgramIncentiveTO.setBusinessProgramID(rs.getInt("BIZ_PGM_ID"));
                lMemberProgramIncentiveTO.setIncentiveOptionID(rs.getInt("INCNTV_OPTN_ID"));
                lMemberProgramIncentiveTO.setIncentiveOptionName(rs.getString("INCNTV_OPTN_NM"));
                lMemberProgramIncentiveTO.setPersonDemographicsID(rs.getInt("PRSN_DMGRPHCS_ID"));
                lMemberProgramIncentiveTO.setContractNo(rs.getInt("CONTRACT_NO"));
                lMemberProgramIncentiveTO.setQualificationCheckmarkID(rs.getInt("QUALFCTN_CHKMRK_ID"));
                lMemberProgramIncentiveTO.setMemberIncentiveStatusCode(rs.getString("MBR_STAT_CD"));
                lMemberProgramIncentiveTO.setMemberIncentiveStatusDate(rs.getDate("MODIFY_TS"));
                lMemberProgramIncentiveTO.setMemberIncentiveAchievedDate(rs.getDate("MBR_STAT_ACHV_DT"));
                lMemberProgramIncentiveTO.setActivationStatusCodeID(rs.getInt("ACTVN_STS_TP_CD_ID"));
                lMemberProgramIncentiveTO.setActivationStatusCode(rs.getString("ACTVN_STS_TP_CD"));

                lMemberProgramIncentives.add(lMemberProgramIncentiveTO);
            }
        });

        return lMemberProgramIncentives;
    }

    /**
     * @param pPersonDemographicsID
     * @param pBusinessProgramID
     * @return
     * @throws DataAccessException
     */
    @Override
    public Collection<MemberPackage> getMemberPackages(Integer pPersonDemographicsID, Integer pBusinessProgramID, Integer pContractNo) throws DataAccessException {
        final ArrayList<MemberPackage> lMemberPackages = new ArrayList<MemberPackage>();

        JdbcTemplate template = getJdbcTemplate();
        ArrayList<Object> lParameters = new ArrayList<Object>();
        ArrayList<Integer> lTypes = new ArrayList<Integer>();

        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectMemberPackages);

        lParameters.add(pPersonDemographicsID);
        lParameters.add(pBusinessProgramID);
        lParameters.add(pContractNo);

        lTypes.add(Types.INTEGER);
        lTypes.add(Types.INTEGER);
        lTypes.add(Types.INTEGER);


        Object params[] = new Object[lParameters.size()];
        lParameters.toArray(params);

        int types[] = new int[lTypes.size()];
        for (int j = 0; j < lTypes.size(); j++) {
            types[j] = ((Integer) lTypes.get(j)).intValue();
        }

        template.query(lQuery.toString(), params, types, new RowCallbackHandler() {
            public void processRow(ResultSet rs) throws SQLException {
                MemberPackage lMemberPackage = new MemberPackage();

                lMemberPackage.setBusinessProgramID(rs.getInt("biz_pgm_id"));
                lMemberPackage.setPackageID(rs.getInt("ben_pkg_id"));
                lMemberPackage.setPackageCode(rs.getString("ben_pkg_cd"));
                lMemberPackage.setPackageName(rs.getString("ben_pkg_nm"));
                lMemberPackage.setPackageType(rs.getString("BEN_PKG_TP"));
                lMemberPackage.setPurchaserSubTypeName(rs.getString("purch_sub_tp_nm"));
                lMemberPackage.setEffectiveDate(rs.getDate("ben_pkg_eff_dt"));
                lMemberPackage.setEndDate(rs.getDate("ben_pkg_end_dt"));

                lMemberPackages.add(lMemberPackage);
            }
        });

        return lMemberPackages;
    }

    @Override
    public Collection<MemberStatusDetail> getMemberStatusDetails(Integer pPersonDemographicsID, Integer pProgramID, Integer pContractNo) throws DataAccessException {
        final ArrayList<MemberStatusDetail> lMemberStatusDetails = new ArrayList<MemberStatusDetail>();

        JdbcTemplate template = getJdbcTemplate();
        ArrayList<Object> lParameters = new ArrayList<Object>();
        ArrayList<Integer> lTypes = new ArrayList<Integer>();

        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectMemberStatusDetail);

        lParameters.add(pPersonDemographicsID);
        lParameters.add(pPersonDemographicsID);
        lParameters.add(pProgramID);
        lParameters.add(pContractNo);
        lTypes.add(Types.INTEGER);
        lTypes.add(Types.INTEGER);
        lTypes.add(Types.INTEGER);
        lTypes.add(Types.INTEGER);

        Object params[] = new Object[lParameters.size()];
        lParameters.toArray(params);

        int types[] = new int[lTypes.size()];
        for (int j = 0; j < lTypes.size(); j++) {
            types[j] = ((Integer) lTypes.get(j)).intValue();
        }

        template.query(lQuery.toString(), params, types, new RowCallbackHandler() {
            public void processRow(ResultSet rs) throws SQLException {
                MemberStatusDetail lMemberStatusDetail = new MemberStatusDetail();

                lMemberStatusDetail.setPersonDemographicsID(rs.getInt("PRSN_DMGRPHCS_ID"));
                lMemberStatusDetail.setMemberID(rs.getString("hp_mem_id"));
                lMemberStatusDetail.setProgramID(rs.getInt("BIZ_PGM_ID"));
                lMemberStatusDetail.setContractNumber(rs.getInt("CONTRACT_NO"));
                lMemberStatusDetail.setContractStatusCodeID(rs.getInt("cntr_stat_cd_id"));
                lMemberStatusDetail.setContractStatusCodeValue(rs.getString("cntr_stat_val"));
                lMemberStatusDetail.setMemberProgramStatusCodeID(rs.getInt("stat_cd_id"));
                lMemberStatusDetail.setMemberProgramStatusCodeValue(rs.getString("pers_stat_val"));
                lMemberStatusDetail.setMemberStatusDate(rs.getDate("member_status_date"));
                lMemberStatusDetail.setContractStatusDate(rs.getDate("contract_status_date"));
                lMemberStatusDetail.setQualificationCheckmarkName(rs.getString("QUALFCTN_CHKMRK_NM"));
                lMemberStatusDetail.setIncentiveOptionName(rs.getString("incntv_optn_nm"));
                lMemberStatusDetail.setProgramIncentedType(rs.getString("INCNTD_STS_TP_CD"));
                lMemberStatusDetail.setProgramIncentiveOptionID(rs.getInt("biz_pgm_incntv_optn_ID"));
                if (rs.getInt("has_exemption") > 0) {
                    lMemberStatusDetail.setHavingManualExemption(true);
                } else {
                    lMemberStatusDetail.setHavingManualExemption(false);
                }

                lMemberStatusDetails.add(lMemberStatusDetail);
            }
        });

        return lMemberStatusDetails;
    }

    private static final class activityMapper implements RowMapper {
        public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
            MemberActivity lMemberActivity = new MemberActivity();
            ActivityDefinition lActivity = new ActivityDefinition();
            lActivity
                    .setActivityID(rs.getObject("actv_id") != null ? rs.getInt("actv_id")
                            : null);
            lActivity.setActivityTypeDesc(rs.getString("actv_type_desc"));
            lActivity.setActivityTypeValue(rs.getString("actv_type_code_val"));
            lActivity.setName(rs.getString("actv_nm"));
            lActivity.setDescription(rs.getString("actv_desc"));
            lActivity.setCost(rs.getDouble("actv_cost"));
            lActivity.setDuration(rs.getInt("completion_duration"));
            lActivity.setSource(rs.getString("host_srce"));
            lActivity.setWebLink(rs.getString("actv_link"));
            lActivity.setSourceActivityID(rs.getString("srce_actv_id"));
            lMemberActivity.setBusinessProgramID(rs.getInt("biz_pgm_id"));
            lMemberActivity.setActivity(lActivity);
            lMemberActivity.setRegistrationID(rs.getString("registration_id"));
            lMemberActivity.setAuthPromoCode(rs.getString("auth_cd"));

            com.healthpartners.service.bpm.dto.GenericStatusType lStatusType = new GenericStatusType();
            lStatusType.setStatusCodeID((rs.getInt("actv_stat_cd_id")));
            lStatusType.setStatusCodeDesc(rs.getString("active_stat_desc"));
            lStatusType
                    .setStatusCodeValue(rs.getString("active_stat_code_val"));
            lStatusType.setStatusEffectiveDate((rs
                    .getDate("actv_stat_dt")));
            lStatusType.setOutCome(rs.getString("active_stat_outcome_val"));
            lMemberActivity.setActivityStatus(lStatusType);
            return lMemberActivity;
        }
    }

    private static final class memberProgramActivityNoDupsToWaiveMapper implements RowMapper {
        public Object mapRow(ResultSet rs, int rowNum) throws SQLException {

            MemberProgramActivity activity = new MemberProgramActivity();

            activity.setPersonDemographicsID(rs.getInt("PRSN_DMGRPHCS_ID"));
            activity.setPersonID(rs.getInt("PRSN_ID"));
            activity
                    .setProgramID((rs.getObject("BIZ_PGM_ID") != null) ? rs.getInt("BIZ_PGM_ID")
                            : null);
            activity
                    .setActivityID((rs.getObject("ACTV_ID") != null) ? rs.getInt("ACTV_ID")
                            : null);
            activity.setActivityName(rs.getString("ACTV_NM"));
            activity.setSourceActivityID(rs
                    .getString("SRCE_ACTV_ID"));
            activity.setStatusDate(rs
                    .getDate("STAT_EFF_DT"));
            activity.setRegistrationID(rs
                    .getString("REGISTRATION_ID"));

            activity.setStatusOutComeValue(rs.getString("STAT_OUTCM"));
            activity.setStatusCodeValue(rs.getString("activity_stat_val"));

            activity.setAuthCode(rs.getString("auth_cd"));

            activity.setInsertUserId(rs.getString("INSERT_USR"));
            activity.setModifyUserId(rs.getString("MODIFY_USR"));

            activity
                    .setWaiveFlag((rs.getString("WAIVE_FLAG") != null) ? rs.getString("WAIVE_FLAG") : new String(""));
            activity.setWaiveInsertUser(rs.getString("WAIVE_INSERT_USER"));
            activity.setOverrideReason(rs.getString("RSN_DESC"));
            return activity;
        }
    }

    private static final class memberProgramActivityMapper implements RowMapper {
        public Object mapRow(ResultSet rs, int rowNum) throws SQLException {

            MemberProgramActivity activity = new MemberProgramActivity();

            activity.setPersonDemographicsID(rs.getInt("PRSN_DMGRPHCS_ID"));
            activity.setPersonID(rs.getInt("prsn_id"));
            activity
                    .setProgramID((rs.getObject("BIZ_PGM_ID") != null) ? rs.getInt("BIZ_PGM_ID")
                            : null);
            activity
                    .setActivityID((rs.getObject("ACTV_ID") != null) ? rs.getInt("ACTV_ID")
                            : null);
            activity.setActivityName(rs.getString("ACTV_NM"));
            activity.setSourceActivityID(rs
                    .getString("SRCE_ACTV_ID"));
            activity.setRegistrationID(rs
                    .getString("REGISTRATION_ID"));
            activity.setStatusCodeValue(rs
                    .getString("activity_stat_val"));
            activity.setStatusDate(rs.getDate("ACTV_STAT_DT"));
            activity.setStatusOutComeValue(rs
                    .getString("STAT_OUTCM"));

            activity.setAuthCode(rs.getString("auth_cd"));
            activity.setProcessingStatus(rs.getString("PRCSNG_STAT_VAL"));
            activity.setOverrideReason(rs.getString("RSN_DESC"));
            if (rs.getTimestamp("INSERT_TS") != null) {
                activity.setInsertDate(new java.sql.Date(rs.getTimestamp("INSERT_TS").getTime()));
            }
            if (rs.getTimestamp("MODIFY_TS") != null) {
                activity.setModifyDate(new java.sql.Date(rs.getTimestamp("MODIFY_TS").getTime()));
            }

            return activity;
        }
    }

    @Override
    public Collection<String> getMemberIDFromPersonDetails(String firstName, String middleInitial, String lastName, String gender, java.sql.Date dateOfBirth) throws DataAccessException {
        final ArrayList<String> results = new ArrayList<String>();

        ArrayList<Object> lParameters = new ArrayList<Object>();
        ArrayList<Integer> lTypes = new ArrayList<Integer>();

        JdbcTemplate template = getJdbcTemplate();
        StringBuffer lQuery = new StringBuffer();

        lQuery.append(selectMemberIDFromPersonDetails);

        if (firstName != null && firstName.trim().length() > 0) {
            lQuery.append(" AND upper(first_nm) = upper(?)");
            lParameters.add(firstName);
            lTypes.add(Types.VARCHAR);
        }

        if (middleInitial != null && middleInitial.trim().length() > 0) {
            lQuery.append(" AND upper(middle_nm) = upper(?)");
            lParameters.add(middleInitial);
            lTypes.add(Types.VARCHAR);
        }

        if (lastName != null && lastName.trim().length() > 0) {
            lQuery.append(" AND upper(last_nm) like upper(?)");
            lParameters.add(lastName + "%");
            lTypes.add(Types.VARCHAR);
        }

        if (gender != null && gender.trim().length() > 0) {
            lQuery.append(" and upper(GENDER_CD) = upper(?)");
            lParameters.add(gender);
            lTypes.add(Types.VARCHAR);
        }

        if (dateOfBirth != null) {
            lQuery.append(" AND dob_dt = ?");
            lParameters.add(dateOfBirth);
            lTypes.add(Types.DATE);
        }

        lQuery.append(" ORDER BY last_nm, first_nm, middle_nm ");

        // Convert the parameter and types ArrayLists to arrays of primitive types.
        Object params[] = new Object[lParameters.size()];
        lParameters.toArray(params);

        int types[] = new int[lTypes.size()];
        for (int j = 0; j < lTypes.size(); j++) {
            types[j] = (lTypes.get(j)).intValue();
        }

        template.query(lQuery.toString(), params, types,
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        results.add(rs.getString(1));
                    }
                });

        return results;
    }

    @Override
    public ArrayList<MemberProgramDetail> selectPersonProgramRelationship(String pMemberID) throws DataAccessException {
        final ArrayList<MemberProgramDetail> lMemberProgramDetails = new ArrayList<MemberProgramDetail>();
        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{pMemberID};
        int types[] = new int[]{Types.VARCHAR};
        template.query(selectPersonProgramRelationship, params, types,
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        MemberProgramDetail lMemberProgramDetail = new MemberProgramDetail();

                        lMemberProgramDetail.setMemberID(rs.getString("hp_mem_id"));
                        lMemberProgramDetail.setPersonID(rs.getInt("prsn_id"));
                        lMemberProgramDetail.setPersonDemographicsID(rs.getInt("prsn_dmgrphcs_id"));
                        lMemberProgramDetail.setRelationshipCode(rs.getString("relationshipText"));
                        lMemberProgramDetail.setParticipationCodeValue(rs.getString("participationCodeValue"));
                        lMemberProgramDetail.setParticipationCodeDesc(rs.getString("participationCodeDesc"));
                        lMemberProgramDetail.setRelationshipCode(rs.getString("relationshipText"));
                        lMemberProgramDetail.setGroupName(rs.getString("empl_grp_nm"));
                        lMemberProgramDetail.setGroupNumber(rs.getString("empl_grp_no"));
                        lMemberProgramDetail.setSiteName(rs.getString("empl_grp_site_nm"));
                        lMemberProgramDetail.setSiteNumber(rs.getString("empl_grp_site_id_no"));
                        lMemberProgramDetail.setEffectiveDate(rs.getDate("eff_dt"));
                        lMemberProgramDetail.setEndDate(rs.getDate("pgm_end_dt"));
                        lMemberProgramDetail.setProgramName(rs.getString("BIZ_PGM_NM"));

                        lMemberProgramDetails.add(lMemberProgramDetail);
                    }
                });

        return lMemberProgramDetails;
    }

    /**
     * Return the person_id of another person on the same contract as the given person.
     * (For ex. Spouse, or Domestice Partner)
     *
     * @param memberID
     * @return
     * @throws DataAccessException
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Override
    public Collection<MemberDetail> getRelatedMemberDetails(String memberID) throws DataAccessException {
        final ArrayList<MemberDetail> results = new ArrayList<MemberDetail>();
        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{memberID, memberID, memberID};
        int types[] = new int[]{Types.VARCHAR, Types.VARCHAR, Types.VARCHAR};
        template.query(getRelatedPersonIDFromMemberID, params, types,
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        MemberDetail lMemberDetail = new MemberDetail();
                        MemberProgramDetail lMemberProgramDetail = new MemberProgramDetail();
                        ArrayList<MemberProgramDetail> lMemberProgramDetails = new ArrayList<MemberProgramDetail>();

                        lMemberDetail.setMemberID(rs.getString("hp_mem_id"));
                        lMemberDetail.setPersonID(rs.getInt("prsn_id"));
                        lMemberDetail.setPersonDemographicsID(rs.getInt("prsn_dmgrphcs_id"));

                        lMemberProgramDetail.setMemberID(rs.getString("hp_mem_id"));
                        lMemberProgramDetail.setRelationshipCode(rs.getString("rel_txt"));
                        lMemberProgramDetail.setContractNumber(rs.getInt("contract_no"));

                        lMemberProgramDetails.add(lMemberProgramDetail);
                        lMemberDetail.setMemberProgramDetails(lMemberProgramDetails);

                        results.add(lMemberDetail);
                    }
                });

        return results;
    }

    @Override
    public ArrayList<PersonContractHist> getPersonContractsHistory(String memberId, String contractNo, Date programEffectiveDate, String groupNo, String luvContractHistResultCodeValue) throws DataAccessException, SQLTimeoutException {

        final ArrayList<PersonContractHist> personContractsHistAll = new ArrayList<PersonContractHist>();

        StringBuffer query = new StringBuffer();
        query.append(selectPersonContractsHistory);

        JdbcTemplate template = getJdbcTemplate();

        ArrayList<Object> lParameters = new ArrayList<Object>();
        ArrayList<Integer> lTypes = new ArrayList();



        if (memberId != null && memberId.length() > 0) {
            query.append(" AND PERSON.HP_MEM_ID = ? ");
            lParameters.add(memberId);
            lTypes.add(Types.VARCHAR);
        }

        if (contractNo != null && contractNo.length() > 0) {
            query.append(" AND HIST.ELIG_CNTR_NO = ? ");
            Integer contractNoInt = Integer.valueOf(contractNo);
            lParameters.add(contractNoInt);
            lTypes.add(Types.INTEGER);
        }

        if (groupNo != null && groupNo.length() > 0) {
            query.append(" AND GROUPSITE.EMPL_GRP_NO = ?");
            lParameters.add(groupNo);
            lTypes.add(Types.VARCHAR);
        }

        if (programEffectiveDate != null) {
            query.append(" AND TRUNC(bp.eff_dt) = TRUNC(?)");
            lParameters.add(programEffectiveDate);
            lTypes.add(Types.DATE);
        }


        query.append(" ORDER BY groupsite.empl_grp_no DESC, PERSON.HP_MEM_ID ASC, HIST.ELIG_CNTR_STAT_DT DESC ");

        Object params[] = new Object[lParameters.size()];
        lParameters.toArray(params);

        int types[] = new int[lTypes.size()];
        for(int j = 0; j < lTypes.size(); j++)
        {
            types[j] = ((Integer)lTypes.get(j)).intValue();
        }

        ArrayList<PersonContractHist> personContractHistCurrent = (ArrayList<PersonContractHist>)
                template.query(query.toString(), params, types, new personProgramContractHistoryMapper());

        if (personContractHistCurrent != null && personContractHistCurrent.size() > 0) {
            personContractsHistAll.addAll(personContractHistCurrent);
        }

        //EV84911
        if (luvContractHistResultCodeValue != null && luvContractHistResultCodeValue.equals(BPMConstants.BPM_CONTRACT_HIST_RESULT_ALL)) {
            Collection<PersonContractHist> personContractsHistArchive = getPersonContractsHistoryArchive(memberId, contractNo, programEffectiveDate, groupNo);
            personContractsHistAll.addAll(personContractsHistArchive);
        }

        return personContractsHistAll;
    }

    public Collection<PersonContractHist> getPersonContractsHistoryArchive(
            String memberId, String contractNo, Date programEffectiveDate, String groupNo)
            throws DataAccessException, SQLTimeoutException {

        StringBuffer query = new StringBuffer();
        query.append(selectPersonContractsHistoryArchive);

        JdbcTemplate template = getJdbcTemplate();

        ArrayList<Object> lParameters = new ArrayList<Object>();
        ArrayList<Integer> lTypes = new ArrayList();



        if (memberId != null && memberId.length() > 0) {
            query.append(" AND PERSON.HP_MEM_ID = ? ");
            lParameters.add(memberId);
            lTypes.add(Types.VARCHAR);
        }

        if (contractNo != null && contractNo.length() > 0) {
            query.append(" AND HIST.ELIG_CNTR_NO = ? ");
            Integer contractNoInt = Integer.valueOf(contractNo);
            lParameters.add(contractNoInt);
            lTypes.add(Types.INTEGER);
        }

        if (groupNo != null && groupNo.length() > 0) {
            query.append(" AND GROUPSITE.EMPL_GRP_NO = ?");
            lParameters.add(groupNo);
            lTypes.add(Types.VARCHAR);
        }

        if (programEffectiveDate != null) {
            query.append(" AND TRUNC(bp.eff_dt) = TRUNC(?)");
            lParameters.add(programEffectiveDate);
            lTypes.add(Types.DATE);
        }


        query.append(" ORDER BY groupsite.empl_grp_no DESC, PERSON.HP_MEM_ID ASC, HIST.ELIG_CNTR_STAT_DT DESC ");

        Object params[] = new Object[lParameters.size()];
        lParameters.toArray(params);

        int types[] = new int[lTypes.size()];
        for(int j = 0; j < lTypes.size(); j++)
        {
            types[j] = ((Integer)lTypes.get(j)).intValue();
        }

        ArrayList<PersonContractHist> personContractHistArchive = (ArrayList<PersonContractHist>)
                template.query(query.toString(), params, types, new personProgramContractHistoryMapper());


        return personContractHistArchive;
    }


    public Collection<MemberProgramDetail> getTermedMemberProgramHistoryDetails(
            Integer personID, Date qualificationStartDate)
            throws DataAccessException
    {
        StringBuffer query = new StringBuffer();
        query.append(getTermedMemberProgramHistoryDetails);
        Object params[];
        int types[];
        if (qualificationStartDate != null) {
            query.append("AND biz.QUALFCTN_START_DT >= ? ");
            params = new Object[] { personID, personID, personID, qualificationStartDate };
            types = new int[] { Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.DATE };
        } else {
            params = new Object[] { personID, personID, personID };
            types = new int[] { Types.INTEGER, Types.INTEGER, Types.INTEGER };
        }

        query.append(" ORDER BY biz.QUALFCTN_START_DT DESC, pers_stat.PARTICIPATION_END_DT DESC ");

        JdbcTemplate template = getJdbcTemplate();

        ArrayList<MemberProgramDetail> lMemberProgramDetails = (ArrayList<MemberProgramDetail>)
                template.query(query.toString(), params, types, new MemberProgramRowMapper());


        return lMemberProgramDetails;
    }

    @Override
    public Collection<CDHPFulfillmentTrackingRecycle> getPersonCDHPFulfillsRecycle(
            String memberId, String groupNo, String contractNo, Date recycleStatusDate, Integer recycleStatusId, String programName)
            throws DataAccessException {

        StringBuffer query = new StringBuffer();
        query.append(selectPersonCDHPFulfillsRecycle);

        ArrayList<Object> lParameters = new ArrayList<Object>();
        ArrayList<Integer> lTypes = new ArrayList();

        if (memberId != null && memberId.length() > 0) {
            query.append("AND PERSON.HP_MEM_ID = ? ");
            Integer memberIdInt = Integer.valueOf(memberId);
            lParameters.add(memberIdInt);
            lTypes.add(Types.INTEGER);
        }

        if (contractNo != null && contractNo.length() > 0) {
            query.append("AND RECYC.CONTRACT_NO = ? ");
            Integer contractNoInt = Integer.valueOf(contractNo);
            lParameters.add(contractNoInt);
            lTypes.add(Types.INTEGER);
        }
        if (groupNo != null && groupNo.length() > 0) {
            query.append("AND GROUP_SITE.EMPL_GRP_NO = ? ");
            lParameters.add(groupNo);
            lTypes.add(Types.VARCHAR);
        }

        if (programName != null && programName.length() > 0) {
            query.append("AND BUS_PROGRAM.BIZ_PGM_TP_CD = (SELECT BIZ_PGM_TP_CD FROM BUSINESS_PROGRAM_TYPE WHERE BIZ_PGM_NM = ?)");
            lParameters.add(programName);
            lTypes.add(Types.VARCHAR);
        }

        if (recycleStatusId != null && recycleStatusId != 0) {
            query.append("AND RECYCLE_STAT_ID = ?");
            lParameters.add(recycleStatusId);
            lTypes.add(Types.INTEGER);
        }


        if (recycleStatusDate != null) {
            query.append("AND TRUNC(RECYC.RECYCLE_STAT_DT) = ? ");
            lParameters.add(recycleStatusDate);
            lTypes.add(Types.DATE);
        }

        query.append("ORDER BY RECYC.RECYCLE_STAT_DT DESC");

        // Convert the parameter and types ArrayLists to arrays of primitive types.
        Object params[] = new Object[lParameters.size()];
        lParameters.toArray(params);

        int types[] = new int[lTypes.size()];
        for(int j = 0; j < lTypes.size(); j++)
        {
            types[j] = ((Integer)lTypes.get(j)).intValue();
        }

        JdbcTemplate template = getJdbcTemplate();

        Collection<CDHPFulfillmentTrackingRecycle> results = (ArrayList<CDHPFulfillmentTrackingRecycle>)
                template.query(query.toString(), params, types, new personCDHPFulfillsRecycleMapper());


        return results;
    }

    @Override
    public int updatePersonCDHPFulfillRecycle(CDHPFulfillmentTrackingRecycle lCDHPFulfillmentTrackingRecycle) throws DataAccessException {
        Integer recycleId = lCDHPFulfillmentTrackingRecycle.getCdhpRecycleId();


        String reason = lCDHPFulfillmentTrackingRecycle.getReasonDesc();
        String approver = lCDHPFulfillmentTrackingRecycle.getApproverUserId();
        Integer recycleStatusId = lCDHPFulfillmentTrackingRecycle.getRecycleStatusId();
        String userId = lCDHPFulfillmentTrackingRecycle.getInsertUser();


        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{recycleStatusId, reason, approver, userId, recycleId};
        int types[] = new int[]{Types.INTEGER, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.INTEGER};

        return template.update(updatePersonCDHPFulfillRecycle, params, types);
    }

    //Produces warnings during compile time to quickly identify typos or API changes
    @Override
    public int updateMemberStatus(Integer pPersonID, Integer pProgramID, Integer pNewStatus, String pUserID, Integer pProgramIncentiveOptionID)
            throws DataAccessException
    {
        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[] { pNewStatus, pUserID, pPersonID, pProgramID, pProgramIncentiveOptionID };
        int types[] = new int[] { Types.INTEGER, Types.CHAR, Types.INTEGER, Types.INTEGER, Types.INTEGER };

        return template.update(updateMemberStatus, params, types);
    }

    @Override
    public int updateMemberProgramActivityIncentiveModifyDate(Integer personDemographicsID, Integer programID, Integer activityID, String userID) throws DataAccessException {
        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[] {  userID, personDemographicsID,  programID, activityID };
        int types[] = new int[] {Types.VARCHAR, Types.INTEGER, Types.INTEGER, Types.INTEGER };

        return template.update(updatePersonActivityIncentiveModificationDate, params, types);
    }

    @Override
    public CDHPFulfillmentTrackingRecycle getPersonCDHPFulfillRecycle(Integer recycleID) throws DataAccessException {

        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[] { recycleID };
        int types[] = new int[] { Types.INTEGER };

        StringBuffer query = new StringBuffer();
        query.append(selectPersonCDHPFulfillRecycle);

        ArrayList<CDHPFulfillmentTrackingRecycle> results = (ArrayList<CDHPFulfillmentTrackingRecycle>)
                template.query(query.toString(), params, types, new personCDHPFulfillRecycleMapper());

        CDHPFulfillmentTrackingRecycle personCDHPFulfillRecycle = null;
        if (results.size() > 0) {
            personCDHPFulfillRecycle = results.get(0);
        }

        return personCDHPFulfillRecycle;
    }

    @Override
    public MemberDetail getMemberDetail(Integer personID, Integer programID) throws DataAccessException {
        final ArrayList<MemberDetail> results = new ArrayList<>();
        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{personID, personID};
        int types[] = new int[]{Types.INTEGER, Types.INTEGER};
        template.query(getPersonDetails, params, types,
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        MemberDetail memberDetail = new MemberDetail();
                        memberDetail.setPersonID(rs.getInt("prsn_id"));
                        memberDetail.setMemberID(rs.getString("hp_mem_id"));
                        memberDetail.setFirstName(rs.getString("first_nm"));
                        memberDetail.setLastName(rs.getString("last_nm"));
                        memberDetail.setMiddleInitial(rs.getString("middle_nm"));
                        memberDetail.setBirthDate(rs.getDate("dob_dt"));
                        memberDetail.setPersonDemographicsID(rs.getInt("prsn_dmgrphcs_id"));

                        if (rs.getInt("program_demog_id") > 0) {
                            memberDetail.setHasBPMProgram("Y");
                        } else {
                            memberDetail.setHasBPMProgram("");
                        }

                        results.add(memberDetail);
                    }
                });

        MemberDetail memberDetail = null;
        if (results.size() > 0) {
            memberDetail = results.get(0);
            MemberProgramDetail memberProgramDetail = getMemberProgramDetail(personID, programID);
            Collection<MemberProgramDetail> memberProgramDetails = new ArrayList<>();
            memberProgramDetails.add(memberProgramDetail);
            memberDetail.setMemberProgramDetails(memberProgramDetails);
        }

        return memberDetail;
    }

    @Override
    public MemberProgramDetail getMemberProgramDetail(Integer personID, Integer programID) throws DataAccessException {
        final ArrayList<MemberProgramDetail> results = new ArrayList<>();
        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{personID, personID, personID, programID};
        int types[] = new int[]{Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.INTEGER};

        ArrayList<MemberProgramDetail> lMemberProgramDetails = (ArrayList<MemberProgramDetail>)
                template.query(getMemberProgramDetailsByProgram, params, types, new MemberProgramRowMapper());

        for (MemberProgramDetail memberProgramDetail : lMemberProgramDetails) {
            memberProgramDetail
                    .setMemberExemptions(qualificationOverrideDAO
                            .getAllQualificationOverrides(
                                    memberProgramDetail
                                            .getPersonDemographicsID(),
                                    memberProgramDetail
                                            .getProgramID()));

            Collection<MemberProgramActivity> memberActivities = getMemberProgramActivities(
                    memberProgramDetail.getPersonDemographicsID(),
                    memberProgramDetail.getProgramID());
            memberProgramDetail
                    .setMemberActivities(memberActivities);

            Collection<MemberProgramActivity> memberActivitiesNoDups = getMemberProgramActivitiesNoDupsToWaive(
                    memberProgramDetail.getPersonDemographicsID(),
                    memberProgramDetail.getProgramID());
            memberProgramDetail
                    .setMemberActivitiesNoDups(memberActivitiesNoDups);
            memberProgramDetail.setPersonProgramActivities(getPersonProgramActivityStatus(memberProgramDetail.getPersonDemographicsID(),
                    memberProgramDetail.getProgramID()));

            memberProgramDetail.setMemberStatusDetails(getMemberStatusDetails(memberProgramDetail.getPersonDemographicsID(), memberProgramDetail.getProgramID(), memberProgramDetail.getContractNumber()));

            results.add(memberProgramDetail);

        }

        MemberProgramDetail detail = null;
        if (results.size() > 0) {
            detail = results.get(0);
        }

        return detail;
    }

    @Override
    public Collection<PersonContractRecycle> getPersonContractsRecycle(
            String memberId, String groupNo, String contractNo, Date recycleStatusDate, Integer recycleStatusId, String programName)
            throws DataAccessException {
        final Collection<PersonContractRecycle> results = new ArrayList<PersonContractRecycle>();
        StringBuffer query = new StringBuffer();
        query.append(selectPersonContractsRecycle);

        ArrayList<Object> lParameters = new ArrayList<Object>();
        ArrayList<Integer> lTypes = new ArrayList();

        if (memberId != null && memberId.length() > 0) {
            query.append("AND PERSON.HP_MEM_ID = ? ");
            Integer memberIdInt = Integer.valueOf(memberId);
            lParameters.add(memberIdInt);
            lTypes.add(Types.INTEGER);
        }

        if (contractNo != null && contractNo.length() > 0) {
            query.append("AND RECYC.ELIG_CNTR_NO = ? ");
            Integer contractNoInt = Integer.valueOf(contractNo);
            lParameters.add(contractNoInt);
            lTypes.add(Types.INTEGER);
        }
        if (groupNo != null && groupNo.length() > 0) {
            query.append("AND GROUP_SITE.EMPL_GRP_NO = ? ");
            lParameters.add(groupNo);
            lTypes.add(Types.VARCHAR);
        }

        if (programName != null && programName.length() > 0) {
            query.append("AND BUS_PROGRAM.BIZ_PGM_TP_CD = (SELECT BIZ_PGM_TP_CD FROM BUSINESS_PROGRAM_TYPE WHERE BIZ_PGM_NM = ?)");
            lParameters.add(programName);
            lTypes.add(Types.VARCHAR);
        }

        if (recycleStatusId != null && recycleStatusId != 0) {
            query.append("AND RECYCLE_STAT_ID = ?");
            lParameters.add(recycleStatusId);
            lTypes.add(Types.INTEGER);
        }


        if (recycleStatusDate != null) {
            query.append("AND TRUNC(RECYC.RECYCLE_STAT_DT) = ? ");
            lParameters.add(recycleStatusDate);
            lTypes.add(Types.DATE);
        }

        query.append("ORDER BY RECYC.RECYCLE_STAT_DT DESC");

        // Convert the parameter and types ArrayLists to arrays of primitive types.
        Object params[] = new Object[lParameters.size()];
        lParameters.toArray(params);

        int types[] = new int[lTypes.size()];
        for(int j = 0; j < lTypes.size(); j++)
        {
            types[j] = ((Integer)lTypes.get(j)).intValue();
        }

        JdbcTemplate template = getJdbcTemplate();

        template.query(query.toString(), params, types,
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        PersonContractRecycle personContractRecycle = new PersonContractRecycle();
                        personContractRecycle.setRecycleId(rs
                                .getInt("PRSN_CNTR_PGM_RECYCLE_SEQ_ID"));
                        personContractRecycle.setProgramId(rs
                                .getInt("BIZ_PGM_ID"));
                        personContractRecycle.setPersonNumber(rs
                                .getInt("PRSN_DMGRPHCS_ID"));
                        personContractRecycle.setMemberId(rs
                                .getString("MEMBER_ID"));
                        personContractRecycle.setGroupNumber(rs
                                .getString("GROUP_NO"));
                        personContractRecycle.setApproverUserId(rs
                                .getString("APRV_USR_ID"));
                        personContractRecycle.setContractNumber(rs
                                .getInt("CONTRACT_NO"));
                        personContractRecycle.setContractStatusCurrent(rs
                                .getString("CONTRACT_STATUS_CUR"));
                        personContractRecycle.setContractStatusPrev(rs
                                .getString("CONTRACT_STATUS_PREV"));
                        personContractRecycle.setRecycleStatus(rs
                                .getString("RECYCLE_STATUS"));
                        personContractRecycle.setRecycleStatDate(rs
                                .getDate("RECYCLE_STAT_DT"));
                        personContractRecycle.setProgramName(rs
                                .getString("PROGRAM_NAME"));
                        personContractRecycle.setProgramEffDate(rs
                                .getDate("PROGRAM_EFF_DT"));
                        personContractRecycle.setReasonDesc(rs.getString("RSN_DESC"));
                        personContractRecycle.setInsertDate(rs
                                .getDate("INSERT_TS"));

                        results.add(personContractRecycle);
                    }
                });
        return results;
    }

    /**
     * For the given recycle id update the person contract recycle table.
     *
     * @param personContractRecycle
     * @return
     * @throws DataAccessException
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Override
    public int updatePersonContractRecycle(PersonContractRecycle personContractRecycle)
            throws DataAccessException
    {
        Integer recycleId = personContractRecycle.getRecycleId();


        String reason = personContractRecycle.getReasonDesc();
        String approver = personContractRecycle.getApproverUserId();
        Integer recycleStatusId= personContractRecycle.getRecycleStatusId();
        String userId = personContractRecycle.getInsertUser();


        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[] {  recycleStatusId, reason, approver, userId, recycleId };
        int types[] = new int[] { Types.INTEGER, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.INTEGER };

        return template.update(updatePersonContractRecycle, params, types);
    }

    /**
     * Update member program contract status date with system date triggering member contract membership information to come over in the
     * Membership feed batch process.
     *
     * @param personId
     * @param programId
     * @return
     * @throws DataAccessException
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Override
    public int updateMemberProgramStatusContractStatusDate(Integer personId, Integer programId) throws DataAccessException {

        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{personId, programId};
        int types[] = new int[]{Types.INTEGER, Types.INTEGER};

        return template.update(updateMemberProgramStatusContractStatusDate, params, types);
    }

    @Override
    public PersonContractRecycle getPersonContractRecycle(Integer recycleID) throws DataAccessException {

        final ArrayList<PersonContractRecycle> results = new ArrayList<PersonContractRecycle>();
        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{recycleID};
        int types[] = new int[]{Types.INTEGER};
        template.query(selectPersonContractRecycle, params, types,
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        PersonContractRecycle personContractRecycle = new PersonContractRecycle();
                        personContractRecycle.setRecycleId(rs
                                .getInt("PRSN_CNTR_PGM_RECYCLE_SEQ_ID"));
                        personContractRecycle.setPersonNumber(rs
                                .getInt("PRSN_DMGRPHCS_ID"));
                        personContractRecycle.setProgramId(rs
                                .getInt("BIZ_PGM_ID"));
                        personContractRecycle.setApproverUserId(rs
                                .getString("APRV_USR_ID"));
                        personContractRecycle.setContractNumber(rs
                                .getInt("CONTRACT_NO"));
                        personContractRecycle.setContractStatusCurrent(rs
                                .getString("CONTRACT_STATUS_CUR"));
                        personContractRecycle.setContractStatusPrev(rs
                                .getString("CONTRACT_STATUS_PREV"));
                        personContractRecycle.setRecycleStatus(rs
                                .getString("RECYCLE_STATUS"));
                        personContractRecycle.setRecycleStatusId(rs
                                .getInt("RECYCLE_STAT_ID"));
                        personContractRecycle.setRecycleStatDate(rs
                                .getDate("RECYCLE_STAT_DT"));
                        personContractRecycle.setReasonDesc(rs.getString("RSN_DESC"));
                        results.add(personContractRecycle);
                    }
                });
        PersonContractRecycle personContractRecycle = null;
        if (results.size() > 0) {
            personContractRecycle = results.get(0);
        }

        return personContractRecycle;
    }

    private static final class personProgramContractHistoryMapper implements RowMapper {
        public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
            PersonContractHist lPersonContractHist = new PersonContractHist();
            lPersonContractHist.setMemberID(rs
                    .getString("MEMBER_ID"));
            lPersonContractHist.setPersonContractSeqId(rs
                    .getInt("PERSON_CONTRACT_ID_SEQ"));
            lPersonContractHist.setContractNumber(rs
                    .getInt("CONTRACT_NO"));
            lPersonContractHist.setContractStatus(rs
                    .getString("CONTRACT_STATUS"));
            lPersonContractHist.setContractStatusDate(rs
                    .getDate("CONTRACT_STAT_DATE"));
            lPersonContractHist.setMemberStatus(rs
                    .getString("MEMBER_STATUS"));
            lPersonContractHist.setMemberStatusDate(rs
                    .getDate("MEMBER_STATUS_DATE"));
            lPersonContractHist.setGroupId(rs
                    .getInt("GRP_ID"));
            lPersonContractHist.setGroupSiteId(rs
                    .getInt("SUBGRP_ID"));
            lPersonContractHist.setPersonNumber(rs
                    .getInt("PRSN_DMGRPHCS_ID"));
            lPersonContractHist.setProgramTypeId(rs
                    .getInt("PROGRAM_TYPE"));
            lPersonContractHist.setQualificationEndDate(rs
                    .getDate("QUALFCTN_END_DT"));
            lPersonContractHist.setQualificationStartDate(rs
                    .getDate("QUALFCTN_START_DT"));
            lPersonContractHist.setProgramEndDate(rs
                    .getDate("PGM_END_DT"));
            lPersonContractHist.setProgramStartDate(rs
                    .getDate("PGM_EFF_DT"));
            lPersonContractHist.setRunDate(rs
                    .getDate("RUN_DT"));
            lPersonContractHist.setGroupNumber(rs
                    .getString("GROUP_NO"));
            lPersonContractHist.setGroupSiteNumber(rs
                    .getString("GROUP_SITE_NO"));
            lPersonContractHist.setGroupName(rs
                    .getString("GROUP_NAME"));
            lPersonContractHist.setGroupSiteName(rs
                    .getString("GROUP_SITE_NAME"));
            lPersonContractHist.setProgramName(rs
                    .getString("PROGRAM_NAME"));
            lPersonContractHist.setIncentiveOptionName(rs
                    .getString("incentive_option_name"));
            lPersonContractHist.setActivationStatusCodeID(rs.getInt("actvn_sts_tp_cd_id"));
            lPersonContractHist.setActivationStatusCode(rs.getString("actvn_sts_tp_cd"));

            return lPersonContractHist;
        }
    }

    private static final class personCDHPFulfillsRecycleMapper implements RowMapper {
        public Object mapRow(ResultSet rs, int rowNum) throws SQLException {

            CDHPFulfillmentTrackingRecycle personCDHPFulfillRecycle = new CDHPFulfillmentTrackingRecycle();
            personCDHPFulfillRecycle.setCdhpRecycleId(rs
                    .getInt("CDHP_RECYC_ID"));
            personCDHPFulfillRecycle.setProgramId(rs
                    .getInt("BIZ_PGM_ID"));
            personCDHPFulfillRecycle.setPersonDemographicsID(rs
                    .getInt("PRSN_DMGRPHCS_ID"));
            personCDHPFulfillRecycle.setMemberNumber(rs
                    .getString("MEMBER_ID"));
            personCDHPFulfillRecycle.setGroupNumber(rs
                    .getString("GROUP_NO"));
            personCDHPFulfillRecycle.setApproverUserId(rs
                    .getString("APRV_USER_ID"));
            personCDHPFulfillRecycle.setContractNumber(rs
                    .getInt("CONTRACT_NO"));
            personCDHPFulfillRecycle.setRecycleStatusId(rs
                    .getInt("RECYCLE_STAT_ID"));
            personCDHPFulfillRecycle.setRecycleStatus(rs
                    .getString("RECYCLE_STATUS"));
            personCDHPFulfillRecycle.setRecycleStatDate(rs
                    .getDate("RECYCLE_STAT_DT"));
            personCDHPFulfillRecycle.setActivityId(rs
                    .getInt("ACTV_ID"));
            personCDHPFulfillRecycle.setProgramName(rs
                    .getString("PROGRAM_NAME"));
            personCDHPFulfillRecycle.setProgramEffDate(rs
                    .getDate("PROGRAM_EFF_DT"));
            personCDHPFulfillRecycle.setReasonDesc(rs.getString("RSN_DESC"));

            return personCDHPFulfillRecycle;
        }
    }

    private static final class personCDHPFulfillRecycleMapper implements RowMapper {
        public Object mapRow(ResultSet rs, int rowNum) throws SQLException {

            CDHPFulfillmentTrackingRecycle personCDHPFulfillRecycle = new CDHPFulfillmentTrackingRecycle();
            personCDHPFulfillRecycle.setCdhpRecycleId(rs
                    .getInt("CDHP_RECYC_ID"));
            personCDHPFulfillRecycle.setProgramId(rs
                    .getInt("BIZ_PGM_ID"));
            personCDHPFulfillRecycle.setPersonDemographicsID(rs
                    .getInt("PRSN_DMGRPHCS_ID"));
            personCDHPFulfillRecycle.setRecycleStatusId(rs
                    .getInt("RECYCLE_STAT_ID"));
            personCDHPFulfillRecycle.setRecycleStatus(rs
                    .getString("RECYCLE_STATUS"));
            personCDHPFulfillRecycle.setRecycleStatDate(rs
                    .getDate("RECYCLE_STAT_DT"));
            personCDHPFulfillRecycle.setActivityId(rs.getInt("ACTV_ID"));
            personCDHPFulfillRecycle.setActivityStatusIncentiveDate(rs.getDate("ACTV_STAT_INCNTV_DT"));
            personCDHPFulfillRecycle.setPackageSubTypeName(rs.getString("PURCH_SUB_TP_NM"));
            personCDHPFulfillRecycle.setReasonDesc(rs.getString("RSN_DESC"));
            personCDHPFulfillRecycle.setReasonTollgateRule(rs.getString("RSN_TOLLGATE_RULE"));
            personCDHPFulfillRecycle.setApproverUserId(rs.getString("APRV_USER_ID"));

            return personCDHPFulfillRecycle;
        }
    }

    //Produces warnings during compile time to quickly identify typos or API changes
    @Override
    public int updateParticipationEndDate(Integer pPersonDemographicsID, Integer pProgramID, java.sql.Date pParticipationEndDate)
            throws DataAccessException
    {
        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[] { pParticipationEndDate, pPersonDemographicsID, pProgramID };
        int types[] = new int[] { Types.DATE, Types.INTEGER, Types.INTEGER };
        return template.update(updateParticipationEndDate, params, types);
    }
}
