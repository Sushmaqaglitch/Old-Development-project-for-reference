package com.healthpartners.app.bpm.dao;

import com.healthpartners.app.bpm.dto.MemberProcessingStatusLog;
import org.springframework.dao.DataAccessException;

import java.util.Collection;

/**
 * @author jxbourbour
 * 
 */
public interface ProcessingStatusLogDAO {

	long insertPersonProcessingStatusLog(Integer personId, Integer processId, String processingStatusValue, String userId) throws DataAccessException;

	Collection<MemberProcessingStatusLog> getPendingPersonsFromProcessingStatusLog(int pProcessID) throws DataAccessException;

	int[] deleteProcessingStatusLogRecords(Collection<Long> processLogIDs) throws DataAccessException;
	
	Collection<Integer> getNumberOfProcessingStatusLogPending() throws DataAccessException;
	
	Collection<Integer> getNumberOfProcessingStatusLogInProcess() throws DataAccessException;
}
