package com.healthpartners.app.bpm.dao;

import com.healthpartners.app.bpm.common.BPMAdminUtils;
import com.healthpartners.app.bpm.exception.BPMException;
import com.healthpartners.service.bpm.common.BPMConstants;
import com.healthpartners.service.bpm.dto.QualificationOverride;
import jakarta.annotation.PostConstruct;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.jdbc.support.incrementer.DataFieldMaxValueIncrementer;
import org.springframework.jdbc.support.incrementer.OracleSequenceMaxValueIncrementer;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;

@Repository
@Transactional(timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
public class QualificationOverrideDAOJdbc extends JdbcDaoSupport implements QualificationOverrideDAO {

    private static final String deleteExemptionsForBizProgram = "DELETE FROM qualification_override  WHERE BIZ_PGM_ID = ?";
    private static final String deleteQualificationOverrideForIncentive =
            """
            DELETE FROM qualification_override  WHERE biz_pgm_incntv_optn_ID = ?
            """;
    private String insertQualificationOverride = "INSERT INTO QUALIFICATION_OVERRIDE (QOV_ID, BIZ_PGM_ID, CNTR_NO, PRSN_DMGRPHCS_ID, PRSN_ID, OVRD_TP_CD_ID, APRVR_USER_ID, EXEMPTION_ISSUE_DT, EXEMPTION_RSN_DESC, INSERT_TS, INSERT_USR, biz_pgm_incntv_optn_ID) VALUES (?, ?, ?, ?, ?, (SELECT LU_ID FROM LUV WHERE LU_GRP = ? AND LU_VAL = ?), ?, ?, ?, SYSDATE, ?, ?)";
    private static final String getAllQualificationOverrides =
            """
            SELECT ovrd.qov_id,
            ovrd.BIZ_PGM_ID,
            ovrd.PRSN_DMGRPHCS_ID,
            ovrd.CNTR_NO,
            lu.LU_GRP as OVRD_TYPE,
            lu.LU_VAL as OVRD_VALUE,
            ovrd.APRVR_USER_ID,
            ovrd.EXEMPTION_ISSUE_DT,
            ovrd.EXEMPTION_RSN_DESC,
            ovrd.INSERT_USR,
            ovrd.MODIFY_USR,
            ovrd.insert_ts,
            ovrd.modify_ts,  
            ovrd.biz_pgm_incntv_optn_ID,
            io.INCNTV_OPTN_NM
            FROM qualification_override  ovrd, LUV lu
            , biz_pgm_incentive_option bpio, incentive_option io
           WHERE ovrd.PRSN_DMGRPHCS_ID = ? AND ovrd.BIZ_PGM_ID = ?
           AND ovrd.OVRD_TP_CD_ID = lu.LU_ID
           AND ovrd.biz_pgm_incntv_optn_ID = bpio.biz_pgm_incntv_optn_ID
           AND bpio.INCNTV_OPTN_ID = io.INCNTV_OPTN_ID 
            """;

    private DataFieldMaxValueIncrementer qualificationOverrideIdIncrementer;
    private final DataSource dataSource;

    public QualificationOverrideDAOJdbc (DataSource dataSource) {
        this.dataSource = dataSource;
    }


    @PostConstruct
    private void initialize() {

        setDataSource(dataSource);
        qualificationOverrideIdIncrementer = new OracleSequenceMaxValueIncrementer(dataSource, "QUALFCTN_OVRD_SEQ");
    }

    @Override
    public int deleteExemptionsForBizProgram(Integer businessProgramID)
            throws DataAccessException {
        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{businessProgramID};
        int types[] = new int[]{Types.INTEGER};
        return template.update(deleteExemptionsForBizProgram, params, types);
    }

    @Override
    public int deleteQualificationOverrideForIncentive(Integer pProgramIncentiveOptionID)
            throws DataAccessException {
        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{pProgramIncentiveOptionID};
        int types[] = new int[]{Types.INTEGER};
        return template.update(deleteQualificationOverrideForIncentive, params, types);
    }

    @Override
    public Collection<QualificationOverride> getAllQualificationOverrides(Integer personID, Integer businessProgramID) throws DataAccessException {
        final ArrayList<QualificationOverride> results = new ArrayList<QualificationOverride>();
        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{personID, businessProgramID};
        int types[] = new int[]{Types.INTEGER, Types.INTEGER};
        template.query(getAllQualificationOverrides, params, types,
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        QualificationOverride qualOverride = new QualificationOverride();
                        qualOverride.setId(rs.getLong("qov_id")); // QUALFCTN_OVRD_ID
                        qualOverride
                                .setProgramID(rs.getObject("BIZ_PGM_ID") != null ? Integer
                                        .valueOf(rs.getInt("BIZ_PGM_ID")) : null); // BIZ_PGM_ID
                        qualOverride
                                .setPersonID(rs.getObject("PRSN_DMGRPHCS_ID") != null ? Integer
                                        .valueOf(rs.getInt("PRSN_DMGRPHCS_ID")) : null); // PRSN_DMGRPHCS_ID
                        qualOverride.setOverrideType(rs.getString("OVRD_TYPE"));
                        qualOverride.setOverrideCode(rs.getString("OVRD_VALUE"));
                        qualOverride.setApproverUserId(rs.getString("APRVR_USER_ID")); // APRVR_USER_ID
                        qualOverride
                                .setIssueDate(rs.getObject("EXEMPTION_ISSUE_DT") != null ? BPMAdminUtils
                                        .dateToCalendar(rs.getDate("EXEMPTION_ISSUE_DT"))
                                        : null); // EXEMPTION_ISSUE_DT
                        qualOverride.setReasonCode(rs.getString("EXEMPTION_RSN_DESC")); // EXEMPTION_RSN_DESC
                        qualOverride.setInsertUserId(rs.getString("INSERT_USR")); // INSERT_USER
                        qualOverride.setModifyUserId(rs.getString("MODIFY_USR")); // MODIFY_USER
                        qualOverride.setContractNo(rs.getInt("CNTR_NO"));
                        qualOverride.setInsertDate(rs.getDate("insert_ts"));
                        qualOverride.setModifyDate(rs.getDate("modify_ts"));
                        qualOverride.setProgramIncentiveOptionID(rs.getInt("biz_pgm_incntv_optn_ID"));
                        qualOverride.setIncentiveOptionName(rs.getString("INCNTV_OPTN_NM"));

                        results.add(qualOverride);
                    }
                });

        return results;
    }

    @Override
    public long insertManualExemptionForMember(Integer personDemographicsID, Integer personID,
                                               Integer businessProgramID, Integer contractNo, String exemptionReason,
                                               Calendar issueDate, String approverUser, String userId, Integer pProgramIncentiveOptionID)
            throws DataAccessException {

        long result = 0;

        Long qualificationOverrideId = new Long(
                qualificationOverrideIdIncrementer.nextLongValue());
        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[] { qualificationOverrideId,
                businessProgramID, contractNo, personDemographicsID, personID,
                BPMConstants.BPM_TYPE_OVERRIDE,
                BPMConstants.OVERRIDE_CODE_MANUAL_EXEMPTION, approverUser,
                issueDate, exemptionReason, userId, pProgramIncentiveOptionID };
        int types[] = new int[] { Types.BIGINT, Types.INTEGER,
                Types.INTEGER, Types.INTEGER, Types.INTEGER,
                Types.VARCHAR, Types.VARCHAR, Types.VARCHAR,
                Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR,
                Types.INTEGER };
        template.update(insertQualificationOverride, params, types);
        result = qualificationOverrideId.longValue();

        return result;
    }
}
