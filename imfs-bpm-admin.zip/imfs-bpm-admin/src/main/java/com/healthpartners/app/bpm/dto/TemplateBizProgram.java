package com.healthpartners.app.bpm.dto;

import com.healthpartners.app.bpm.common.BPMAdminConstants;
import com.healthpartners.app.bpm.common.BPMAdminUtils;

import java.io.Serializable;

public class TemplateBizProgram implements Serializable {
    static final long serialVersionUID = 0L;

    private Integer programID;
    private String programTypeCodeID;

    private Integer groupID;
    private Integer subgroupID;
    private String groupNumber;
    private String siteNumber;

    private Integer effectiveDateMonth;
    private Integer effectiveDateDay;
    private Integer endDateMonth;
    private Integer endDateDay;

    private Integer qualStartDateMonth;
    private Integer qualStartDateDay;
    private Integer qualEndDateMonth;
    private Integer qualEndDateDay;

    private Integer newHireDateMonth;
    private Integer newHireDateDay;

    private Integer statusCalcEndDateMonth;
    private Integer statusCalcEndDateDay;

    private Integer contributionStartDateMonth;
    private Integer contributionStartDateDay;
    private Integer contributionEndDateMonth;
    private Integer contributionEndDateDay;

    private String templateEffectiveDate;
    private String templateEndDate;

    private String additionalGroupProgramInfo;

    private int familyParticipationRequirement;

    private int programStatusCodeID;

    private Integer reportIndicatorCodeID;

    public TemplateBizProgram() {
        super();
    }


    public Integer getProgramID() {
        return programID;
    }


    public void setProgramID(Integer programID) {
        this.programID = programID;
    }


    public String getProgramTypeCodeID() {
        return programTypeCodeID;
    }


    public void setProgramTypeCodeID(String programTypeCodeID) {
        this.programTypeCodeID = programTypeCodeID;
    }


    public Integer getEffectiveDateMonth() {
        return effectiveDateMonth;
    }


    public void setEffectiveDateMonth(Integer effectiveDateMonth) {
        this.effectiveDateMonth = effectiveDateMonth;
    }


    public Integer getEffectiveDateDay() {
        return effectiveDateDay;
    }


    public void setEffectiveDateDay(Integer effectiveDateDay) {
        this.effectiveDateDay = effectiveDateDay;
    }


    public Integer getEndDateMonth() {
        return endDateMonth;
    }


    public void setEndDateMonth(Integer endDateMonth) {
        this.endDateMonth = endDateMonth;
    }


    public Integer getEndDateDay() {
        return endDateDay;
    }


    public void setEndDateDay(Integer endDateDay) {
        this.endDateDay = endDateDay;
    }


    public Integer getQualStartDateMonth() {
        return qualStartDateMonth;
    }


    public void setQualStartDateMonth(Integer qualStartDateMonth) {
        this.qualStartDateMonth = qualStartDateMonth;
    }


    public Integer getQualStartDateDay() {
        return qualStartDateDay;
    }


    public void setQualStartDateDay(Integer qualStartDateDay) {
        this.qualStartDateDay = qualStartDateDay;
    }


    public Integer getQualEndDateMonth() {
        return qualEndDateMonth;
    }


    public void setQualEndDateMonth(Integer qualEndDateMonth) {
        this.qualEndDateMonth = qualEndDateMonth;
    }


    public Integer getQualEndDateDay() {
        return qualEndDateDay;
    }


    public void setQualEndDateDay(Integer qualEndDateDay) {
        this.qualEndDateDay = qualEndDateDay;
    }


    public Integer getNewHireDateMonth() {
        return newHireDateMonth;
    }


    public void setNewHireDateMonth(Integer newHireDateMonth) {
        this.newHireDateMonth = newHireDateMonth;
    }


    public Integer getNewHireDateDay() {
        return newHireDateDay;
    }


    public void setNewHireDateDay(Integer newHireDateDay) {
        this.newHireDateDay = newHireDateDay;
    }


    public Integer getStatusCalcEndDateMonth() {
        return statusCalcEndDateMonth;
    }


    public void setStatusCalcEndDateMonth(Integer statusCalcEndDateMonth) {
        this.statusCalcEndDateMonth = statusCalcEndDateMonth;
    }


    public Integer getStatusCalcEndDateDay() {
        return statusCalcEndDateDay;
    }


    public void setStatusCalcEndDateDay(Integer statusCalcEndDateDay) {
        this.statusCalcEndDateDay = statusCalcEndDateDay;
    }


    public Integer getContributionStartDateMonth() {
        return contributionStartDateMonth;
    }


    public void setContributionStartDateMonth(Integer contributionStartDateMonth) {
        this.contributionStartDateMonth = contributionStartDateMonth;
    }


    public Integer getContributionStartDateDay() {
        return contributionStartDateDay;
    }


    public void setContributionStartDateDay(Integer contributionStartDateDay) {
        this.contributionStartDateDay = contributionStartDateDay;
    }


    public Integer getContributionEndDateMonth() {
        return contributionEndDateMonth;
    }


    public void setContributionEndDateMonth(Integer contributionEndDateMonth) {
        this.contributionEndDateMonth = contributionEndDateMonth;
    }


    public Integer getContributionEndDateDay() {
        return contributionEndDateDay;
    }


    public void setContributionEndDateDay(Integer contributionEndDateDay) {
        this.contributionEndDateDay = contributionEndDateDay;
    }


    public String getTemplateEffectiveDate() {
        return templateEffectiveDate;
    }


    public void setTemplateEffectiveDate(String templateEffectiveDate) {
        this.templateEffectiveDate = templateEffectiveDate;
    }


    public String getTemplateEndDate() {
        return templateEndDate;
    }


    public void setTemplateEndDate(String templateEndDate) {
        this.templateEndDate = templateEndDate;
    }


    public String getAdditionalGroupProgramInfo() {
        return additionalGroupProgramInfo;
    }


    public void setAdditionalGroupProgramInfo(String additionalGroupProgramInfo) {
        this.additionalGroupProgramInfo = additionalGroupProgramInfo;
    }


    public int getFamilyParticipationRequirement() {
        return familyParticipationRequirement;
    }


    public void setFamilyParticipationRequirement(int familyParticipationRequirement) {
        this.familyParticipationRequirement = familyParticipationRequirement;
    }


    public int getProgramStatusCodeID() {
        return programStatusCodeID;
    }


    public void setProgramStatusCodeID(int programStatusCodeID) {
        this.programStatusCodeID = programStatusCodeID;
    }


    public Integer getGroupID() {
        return groupID;
    }


    public void setGroupID(Integer groupID) {
        this.groupID = groupID;
    }


    public Integer getSubgroupID() {
        return subgroupID;
    }


    public void setSubgroupID(Integer subGroupID) {
        this.subgroupID = subGroupID;
    }

    public java.sql.Date getTemplateEffectiveDateDate() {
        if (templateEffectiveDate != null) {
            return BPMAdminUtils.convertStringToSqlDate(templateEffectiveDate, BPMAdminConstants.HP_BPM_ADMIN_UI_COMMON_DATE_FORMAT);
        } else {
            return null;
        }
    }

    public java.sql.Date getTemplateEndDateDate() {
        if (templateEffectiveDate != null) {
            return BPMAdminUtils.convertStringToSqlDate(templateEndDate, BPMAdminConstants.HP_BPM_ADMIN_UI_COMMON_DATE_FORMAT);
        } else {
            return null;
        }
    }


    public Integer getReportIndicatorCodeID() {
        return reportIndicatorCodeID;
    }


    public void setReportIndicatorCodeID(Integer reportIndicatorCodeID) {
        this.reportIndicatorCodeID = reportIndicatorCodeID;
    }


    public String getGroupNumber() {
        return groupNumber;
    }


    public void setGroupNumber(String groupNumber) {
        this.groupNumber = groupNumber;
    }


    public String getSiteNumber() {
        return siteNumber;
    }


    public void setSiteNumber(String siteNumber) {
        this.siteNumber = siteNumber;
    }

}

