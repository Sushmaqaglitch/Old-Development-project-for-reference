/* $Id: RewardCardDAP.java 155594 2008-10-16 22:04:58Z tjquist $ */

package com.healthpartners.app.bpm.dao;

import com.healthpartners.app.bpm.dto.*;
import com.healthpartners.app.bpm.exception.BPMException;
import org.springframework.dao.DataAccessException;

import java.sql.Date;
import java.util.Collection;


/**
 * @author tjquist
 */
public interface RewardCardDAO {

    public Collection<RewardCardFulfillmentReportHistStatus> getRewardCardFulfillmentTrackingReportStatuses(Integer rewardFulfillHistID)
            throws DataAccessException;

    public RewardCardAddress getRewardCardAddress(Integer rewardTransHistID, Integer programID, Integer personDemographicsID, Integer incentiveOptionID)
            throws DataAccessException;

    public RewardCardAddress getRewardCardAddress(Integer programID, Integer personDemographicsID, Integer incentiveOptionID)
            throws DataAccessException;

    public RewardCardFulfillmentTrackingReportHist getRewardCardFulfillmentTrackingReportHistManualDetail(Integer rewardFulfillHistID)
            throws DataAccessException;

    public RewardCardFulfillmentTrackingReportHist getRewardCardFulfillmentTrackingReportHistDetail(Integer rewardFulfillHistID)
            throws DataAccessException;
    IncentiveOptionRewardCard getIncentiveOptionRewardCard(Integer incentiveOptionRewardCardID) throws DataAccessException;

    RewardCard getRewardCardDef(Integer incentiveOptionRewardCardID) throws DataAccessException;

    int updateProgramRewardControllerForBatchProcessing(Integer programID, Integer incentiveOptionID, Integer rewardCardID, Integer runFreqID, Date programEffDate, String systemID) throws DataAccessException;

    boolean findProgramRewardController(Integer programID, Integer incentiveOptionID) throws DataAccessException;

    Integer insertProgramRewardControllerForBatchProcessing(Integer programID, Integer incentiveOptionID, Integer rewardCardID, Integer runFreqID, Date programEffDate) throws DataAccessException;

    Collection<IncentiveOptionRewardCard> getIncentiveOptionRewardCards() throws DataAccessException;

    Collection<RewardCard> getRewardCards()
            throws DataAccessException;

    Collection<RewardCardFulfillmentTrackingReportHist> getRewardCardFulfillmentTrackingReportHistSearch(RewardCardFulfillmentSearchTO lRewardCardFulfillmentSearchTO) throws DataAccessException;

    Collection<RewardCardFulfillmentTrackingReportHist> getRewardCardFulfillmentTrackingReportHistSearchManual(RewardCardFulfillmentSearchTO lRewardCardFulfillmentSearchTO)
            throws DataAccessException;

    RewardCardFulfillmentReportHistStatus getRewardCardFulfillmentTrackingReportStatus(RewardCardFulfillmentSearchTO lRewardCardFulfillmentSearchTO, RewardCardFulfillmentRecycleSearchTO lRewardCardFulfillmentRecycleSearchTO) throws DataAccessException;
    Collection<RewardCardFee> getRewardCardFees() throws DataAccessException;
    Collection<RewardEmbossedLine> getRewardCardEmbossedLines() throws DataAccessException;
    Collection<RewardCarrierMessage> getRewardCarrierMessages() throws DataAccessException;
    Collection<RewardTransactionMessage> getRewardTransactionMessages() throws DataAccessException;
    Collection<RewardCardClientData> getRewardCardClientInfo() throws DataAccessException;

    int updateIncentiveOptionRewardCard(IncentiveOptionRewardCard pIncentiveOptionRewardCard, String pModifyUserID)
            throws BPMException, DataAccessException;
    int deleteIncentiveOptionRewardCard(Integer lIncentiveOptionRewardCardID)
            throws BPMException, DataAccessException;
}