package com.healthpartners.app.bpm.dao;

import com.healthpartners.app.bpm.dto.PackageActivity;
import com.healthpartners.app.bpm.dto.ProgramPackage;
import com.healthpartners.app.bpm.exception.BPMException;
import org.springframework.dao.DataAccessException;

import java.util.Collection;

public interface ProgramPackageDAO {
    Collection<ProgramPackage> getProgramPackages() throws BPMException, DataAccessException;

    Collection<PackageActivity> getPackageActivities(Integer pPackageID) throws BPMException, DataAccessException;
}
