package com.healthpartners.app.bpm.dao;

import com.healthpartners.app.bpm.dto.BPMCollection;
import com.healthpartners.app.bpm.dto.CollectionActivity;
import com.healthpartners.app.bpm.exception.BPMException;
import org.springframework.dao.DataAccessException;

import java.util.ArrayList;

public interface CollectionDAO {
    ArrayList<BPMCollection> getAllCollections() throws BPMException, DataAccessException;

    ArrayList<CollectionActivity> getCollectionActivities(Integer pCollectionID) throws BPMException, DataAccessException;
}
