package com.healthpartners.app.bpm.controller;

import com.healthpartners.app.bpm.common.BPMAdminConstants;
import com.healthpartners.app.bpm.form.MemberProcessingMonitorForm;
import com.healthpartners.app.bpm.iface.MemberService;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.ArrayList;

@Controller
public class MemberProcessingMonitorController extends BaseController implements Validator {

    private MemberService memberService;

    public MemberProcessingMonitorController(MemberService memberService) {
        this.memberService = memberService;
    }

    @GetMapping("/memberProcessingMonitor")
    public String loadSearch(ModelMap modelMap, HttpServletRequest request) throws Exception {
        MemberProcessingMonitorForm memberProcessingMonitorForm = new MemberProcessingMonitorForm();
        memberProcessingMonitorForm.setActionType(ACTION_SEARCH);
        load(request);
        modelMap.put("memberProcessingMonitorForm", memberProcessingMonitorForm);
        return "memberProcessingMonitor";
    }

    private void load(HttpServletRequest request) {
        ArrayList<Integer> lPendingRecordsList = (ArrayList<Integer>)
                memberService.getNumberOfProcessingStatusLogPending();

        ArrayList<Integer> lInProcessRecordsList = (ArrayList<Integer>)
                memberService.getNumberOfProcessingStatusLogInProcess();

        ArrayList<Integer> lPendingActivitiesList = (ArrayList<Integer>)
                memberService.getNumberOfActivityEventLog(BPMAdminConstants.BPM_ACTIVITY_EVENT_PENDING);

        ArrayList<Integer> lInProcessActivitiesList = (ArrayList<Integer>)
                memberService.getNumberOfActivityEventLog(BPMAdminConstants.BPM_ACTIVITY_EVENT_IN_PROCESS);

        int lNumberOfPendingRecordsProcessingStatusLog = 0;
        int lNumberOfInProcessRecordsProcessingStatusLog = 0;
        int lNumberOfPendingActivitiesLog = 0;
        int lNumberOfInProcessActivitiesLog = 0;

        if(lPendingRecordsList != null && lPendingRecordsList.size() > 0)
        {
            lNumberOfPendingRecordsProcessingStatusLog = lPendingRecordsList.get(0);
        }

        if(lInProcessRecordsList != null && lInProcessRecordsList.size() > 0)
        {
            lNumberOfInProcessRecordsProcessingStatusLog = lInProcessRecordsList.get(0);
        }

        if(lPendingActivitiesList != null && lPendingActivitiesList.size() > 0)
        {
            lNumberOfPendingActivitiesLog = lPendingActivitiesList.get(0);
        }

        if(lInProcessActivitiesList != null && lInProcessActivitiesList.size() > 0)
        {
            lNumberOfInProcessActivitiesLog = lInProcessActivitiesList.get(0);
        }

        request.setAttribute("lNumberOfPendingRecordsProcessingStatusLog", lNumberOfPendingRecordsProcessingStatusLog);
        request.setAttribute("lNumberOfInProcessRecordsProcessingStatusLog", lNumberOfInProcessRecordsProcessingStatusLog);
        request.setAttribute("lNumberOfPendingActivitiesLog", lNumberOfPendingActivitiesLog);
        request.setAttribute("lNumberOfInProcessActivitiesLog", lNumberOfInProcessActivitiesLog);

        populateRequest(request);
    }

    protected void populateRequest(HttpServletRequest request)
    {
        getUserSession().reset();
    }


    @Override
    public boolean supports(Class<?> clazz) {
        return false;
    }

    @Override
    public void validate(Object target, Errors errors) {

    }
}
