package com.healthpartners.app.bpm.dto;

import com.healthpartners.service.bpm.common.BPMConstants;

import java.io.Serializable;
import java.sql.Date;

public class MemberProgramActivity implements Serializable {

	static final long serialVersionUID = 0L;
	
	public MemberProgramActivity() {
		super();
	}

	private Integer personID;
	private Integer personDemographicsID;
	
	private Integer programID;
	
	private Integer activityID;
	
	private String  sourceActivityID;
	
	private String activityName;
	
	private String registrationID;
	
	private String statusCodeValue;
	
	private Date statusDate;
	
	private String statusOutComeValue;
	
	private String authCode;
	
	private String processingStatus;
	
	private String insertUserId;
	
	private String modifyUserId;
	
	private Date insertDate;
	private Date modifyDate;
	
	private String waiveFlag;
	private String overrideReason;
	
	
	private String waiveInsertUser;
	
	private boolean havingTaskStatusOverride;
	
	private Integer eventLogID;
	

	public String getInsertUserId() {
		return insertUserId;
	}

	public void setInsertUserId(String insertUserId) {
		this.insertUserId = insertUserId;
	}

	public String getModifyUserId() {
		return modifyUserId;
	}

	public void setModifyUserId(String modifyUserId) {
		this.modifyUserId = modifyUserId;
	}

	public boolean isHavingActivityStatusOverride() {
		
		boolean havingActivityStatusOverride = false;
		
		if (waiveFlag.equals(BPMConstants.PROCESSING_STATUS_WAIVE)
				|| waiveFlag.equals(BPMConstants.PROCESSING_STATUS_ACTV_EXMPT)) 
		{
			havingActivityStatusOverride = true;
		}
		return havingActivityStatusOverride;
	}	    

	public Integer getActivityID() {
		return activityID;
	}

	public void setActivityID(Integer activityID) {
		this.activityID = activityID;
	}

	public String getActivityName() {
		return activityName;
	}

	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}

	public Integer getProgramID() {
		return programID;
	}

	public void setProgramID(Integer programID) {
		this.programID = programID;
	}

	public String getRegistrationID() {
		return registrationID;
	}

	public void setRegistrationID(String registrationID) {
		this.registrationID = registrationID;
	}

	public String getStatusCodeValue() {
		return statusCodeValue;
	}

	public void setStatusCodeValue(String statusCodeValue) {
		this.statusCodeValue = statusCodeValue;
	}

	public Date getStatusDate() {
		return statusDate;
	}

	public void setStatusDate(Date statusDate) {
		this.statusDate = statusDate;
	}

	public Integer getPersonID() {
		return personID;
	}

	public void setPersonID(Integer personID) {
		this.personID = personID;
	}

	public String getSourceActivityID() {
		return sourceActivityID;
	}

	public void setSourceActivityID(String sourceActivityID) {
		this.sourceActivityID = sourceActivityID;
	}

	public String getStatusOutComeValue() {
		return statusOutComeValue;
	}

	public void setStatusOutComeValue(String statusOutComeValue) {
		this.statusOutComeValue = statusOutComeValue;
	}

	public final String getAuthCode() {
		return authCode;
	}

	public final void setAuthCode(String authCode) {
		this.authCode = authCode;
	}

	public final String getProcessingStatus() {
		return processingStatus;
	}

	public final void setProcessingStatus(String processingStatus) {
		this.processingStatus = processingStatus;
	}

	public String getWaiveFlag() {
		return waiveFlag;
	}

	public void setWaiveFlag(String waiveFlag) {
		this.waiveFlag = waiveFlag;
	}


	public String getWaiveInsertUser() {
		return waiveInsertUser;
	}

	public void setWaiveInsertUser(String waiveInsertUser) {
		this.waiveInsertUser = waiveInsertUser;
	}

	public final Date getModifyDate() {
		return modifyDate;
	}

	public final void setModifyDate(Date modifyDate) {
		this.modifyDate = modifyDate;
	}

	public String getOverrideReason() {
		return overrideReason;
	}

	public void setOverrideReason(String overrideReason) {
		this.overrideReason = overrideReason;
	}

	public boolean isHavingTaskStatusOverride() {
		return havingTaskStatusOverride;
	}

	public void setHavingTaskStatusOverride(boolean havingTaskStatusOverride) {
		this.havingTaskStatusOverride = havingTaskStatusOverride;
	}

	public final Integer getEventLogID() {
		return eventLogID;
	}

	public final void setEventLogID(Integer eventLogID) {
		this.eventLogID = eventLogID;
	}

	public Integer getPersonDemographicsID() {
		return personDemographicsID;
	}

	public void setPersonDemographicsID(Integer personDemographicsID) {
		this.personDemographicsID = personDemographicsID;
	}

	public Date getInsertDate() {
		return insertDate;
	}

	public void setInsertDate(Date insertDate) {
		this.insertDate = insertDate;
	}


	
}
