package com.healthpartners.app.bpm.controller;

import com.healthpartners.app.bpm.common.BPMAdminConstants;
import com.healthpartners.app.bpm.common.BPMAdminUtils;
import com.healthpartners.app.bpm.dto.*;
import com.healthpartners.app.bpm.exception.BPMException;
import com.healthpartners.app.bpm.form.CreateProgramForm;
import com.healthpartners.app.bpm.form.SaveProgramForm;
import com.healthpartners.app.bpm.iface.BusinessProgramService;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.StringTokenizer;

@Controller
public class ProgramCreateController extends BaseController implements Validator {

    private SimpleDateFormat fmt = new SimpleDateFormat(BPMAdminConstants.HP_BPM_ADMIN_UI_COMMON_DATE_FORMAT);
    private final BusinessProgramService businessProgramService;


    private String hostName = "http://localhost";

    protected final Log logger = LogFactory.getLog(getClass());

    public ProgramCreateController(BusinessProgramService businessProgramService) {
        this.businessProgramService = businessProgramService;
    }

    @PostMapping("/createProgram")
    public String submitCreateProgram(@ModelAttribute("createProgramForm") CreateProgramForm createProgramForm, ModelMap modelMap, BindingResult result) throws BPMException, ParseException {
        createProgramForm.setActionType("create");
        validate(createProgramForm, result);
        if (result.hasErrors()) {
            createProgramForm.setProgramTypes(getUserSession().getProgramTypes());
            createProgramForm.setEmployerSubGroups(getUserSession().getEmployerSubGroups());
            return "showSubGroups";
        }
        populateForEdit(modelMap, createProgramForm);
        modelMap.put("membershipProcessFlag", false);
        return "editProgram";
    }

    private void populateForEdit(ModelMap modelMap, CreateProgramForm createProgramForm) throws ParseException, BPMException {
        BusinessProgram lBusinessProgram = populateBusinessProgram(createProgramForm);
        ProgramType lProgramType = businessProgramService.getProgramTypeByTypeID(lBusinessProgram.getProgramTypeCodeID());
        ArrayList<LookUpValueCode> lProgramSpecialReportHandlingCodes = (ArrayList<LookUpValueCode>) businessProgramService.getProgramSpecialReportHandlingCodes();
        assignDefaultReportIndicator(lBusinessProgram, lProgramType, lProgramSpecialReportHandlingCodes);
        populateUserSessionAndRequest(lBusinessProgram, lProgramSpecialReportHandlingCodes, modelMap);
        SaveProgramForm saveProgramForm = populateSaveProgramForm(lBusinessProgram);
        modelMap.put("saveProgramForm", saveProgramForm);
    }

    private BusinessProgram populateBusinessProgram(CreateProgramForm createProgramForm) throws ParseException {
        BusinessProgram lBusinessProgram = new BusinessProgram();
        EmployerGroup lEmployerGroup = new EmployerGroup();

        // Also set the MembershipProcess Date and Flag to null. That date will be communicated
        // from membership later in the year, every year.
        lBusinessProgram.setProgramID(0);
        lBusinessProgram.setMembershipProcessDate(null);
        lBusinessProgram.setMembershipProcessFlag("N");

        String lProgramTypeIDName = createProgramForm.getBusinessProgramTypeName();
        StringTokenizer lProgramStringTokenizer = new StringTokenizer(lProgramTypeIDName, "-");
        lBusinessProgram.setProgramTypeCodeID(lProgramStringTokenizer.nextToken());
        lBusinessProgram.setProgramName(lProgramStringTokenizer.nextToken());
        lBusinessProgram.setProgramStatusDesc("Select...");
        lBusinessProgram.setFamilyParticipationDesc("Select...");
        String lGroupStartDateString = createProgramForm.getGroupStartDate();
        java.util.Date lGroupStartDate = fmt.parse(lGroupStartDateString);

        Calendar lGroupStartDateCalendar = Calendar.getInstance();
        lGroupStartDateCalendar.setTime(lGroupStartDate);

        lBusinessProgram.setEffectiveDate(BPMAdminUtils.generateDefaultProgramEffectiveDate(lGroupStartDateCalendar, lBusinessProgram));
        lBusinessProgram.setQualificationWindowStartDate(BPMAdminUtils.generateDefaultProgramEffectiveDate(lGroupStartDateCalendar, lBusinessProgram));
        lBusinessProgram.setReleaseDate(BPMAdminUtils.generateDefaultProgramEffectiveDate(lGroupStartDateCalendar, lBusinessProgram));

        String lSubgrpIDSiteIDSiteName = createProgramForm.getSiteIDSiteName();

        StringTokenizer lSiteStringTokenizer = new StringTokenizer(lSubgrpIDSiteIDSiteName, "-");
        lEmployerGroup.setSubgroupID(Integer.parseInt(lSiteStringTokenizer.nextToken()));
        lEmployerGroup.setSiteNumber(lSiteStringTokenizer.nextToken());
        lEmployerGroup.setSiteName(lSiteStringTokenizer.nextToken());

        lEmployerGroup.setGroupID(createProgramForm.getGroupID());
        lEmployerGroup.setGroupNumber(createProgramForm.getGroupNo());
        lEmployerGroup.setGroupName(createProgramForm.getGroupName());

        lEmployerGroup.setGroupReportName(createProgramForm.getGroupName());
        lEmployerGroup.setGroupAbbreviatedName(createProgramForm.getGroupName());
        lEmployerGroup.setSiteReportName(lEmployerGroup.getSiteName());
        lEmployerGroup.setSiteAbbreviatedName(lEmployerGroup.getSiteName());

        lBusinessProgram.setEmployerGroup(lEmployerGroup);

        lBusinessProgram.getEmployerGroup().setNewHireDate(BPMAdminUtils.generateDefaultEndDate());
        lBusinessProgram.setEndDate(BPMAdminUtils.generateDefaultProgramEndDate(lGroupStartDateCalendar));
        lBusinessProgram.setQualificationWindowEndDate(BPMAdminUtils.generateDefaultQualificationEndDate(lGroupStartDateCalendar, lBusinessProgram));
        Calendar lTempStatusCalcEndDate = Calendar.getInstance();
        lTempStatusCalcEndDate.setTime(lBusinessProgram.getEndDate());
        lBusinessProgram.setStatusCalcEndDate(BPMAdminUtils.generateDefaultStatusCalcEndDate(lTempStatusCalcEndDate, lBusinessProgram));

        lBusinessProgram.setContributionStartDate(lBusinessProgram.getEffectiveDate());
        lBusinessProgram.setContributionEndDate(lBusinessProgram.getEndDate());

        lBusinessProgram.setQualificationCheckmarkID(0);

        return lBusinessProgram;
    }

    private SaveProgramForm populateSaveProgramForm(BusinessProgram lBusinessProgram) throws BPMException {
        SaveProgramForm saveProgramForm = new SaveProgramForm();
        saveProgramForm.setProgramID(lBusinessProgram.getProgramID());
        saveProgramForm.setProgramName(lBusinessProgram.getProgramName());
        saveProgramForm.setProgramStatusCodeID(lBusinessProgram.getProgramStatusCodeID());
        saveProgramForm.setActivationCodes(getUserSession().getActivationCodes());
        saveProgramForm.setGroupID(lBusinessProgram.getEmployerGroup().getGroupID());
        saveProgramForm.setGroupNumber(lBusinessProgram.getEmployerGroup().getGroupNumber());
        saveProgramForm.setSiteName(lBusinessProgram.getEmployerGroup().getSiteName());
        saveProgramForm.setSiteNumber(lBusinessProgram.getEmployerGroup().getSiteNumber());
        saveProgramForm.setGroupName(lBusinessProgram.getEmployerGroup().getGroupName());
        saveProgramForm.setGroupReportName(lBusinessProgram.getEmployerGroup().getGroupReportName());
        saveProgramForm.setGroupAbbreviatedName(lBusinessProgram.getEmployerGroup().getGroupAbbreviatedName());
        saveProgramForm.setSiteReportName(lBusinessProgram.getEmployerGroup().getSiteReportName());
        saveProgramForm.setSiteAbbreviatedName(lBusinessProgram.getEmployerGroup().getSiteAbbreviatedName());
        saveProgramForm.setReleaseDate(fmt.format(lBusinessProgram.getReleaseDate()));
        saveProgramForm.setStatusCalcEndDate(fmt.format(lBusinessProgram.getStatusCalcEndDate()));
        saveProgramForm.setQualificationWindowStartDate(fmt.format(lBusinessProgram.getQualificationWindowStartDate()));
        saveProgramForm.setEffectiveDate(fmt.format(lBusinessProgram.getEffectiveDate()));
        saveProgramForm.setQualificationWindowEndDate(fmt.format(lBusinessProgram.getQualificationWindowEndDate()));
        saveProgramForm.setEndDate(fmt.format(lBusinessProgram.getEndDate()));
        saveProgramForm.setNewHireDate(fmt.format(lBusinessProgram.getEmployerGroup().getNewHireDate()));
        // Also set the MembershipProcess Date and Flag to null. That date will be communicated
        // from membership later in the year, every year.
        saveProgramForm.setMembershipActivationDate(null);
        saveProgramForm.setMembershipActivationFlag(false);
        saveProgramForm.setContributionStartDate(fmt.format(lBusinessProgram.getContributionStartDate()));
        saveProgramForm.setContributionEndDate(fmt.format(lBusinessProgram.getContributionEndDate()));
        saveProgramForm.setFamilyParticipationRequirement(lBusinessProgram.getFamilyParticipationRequirement());

        if (CollectionUtils.isEmpty(getUserSession().getActivationCodes())) {
            ArrayList<LookUpValueCode> lActivationCodes = (ArrayList<LookUpValueCode>) businessProgramService.getProgramActivationCodes();
            getUserSession().setActivationCodes(lActivationCodes);
        }

        if (CollectionUtils.isEmpty(getUserSession().getParticipationList())) {
            ArrayList<LookUpValueCode> lParticipationList = (ArrayList<LookUpValueCode>) businessProgramService.getParticipationCodes();
            getUserSession().setParticipationList(lParticipationList);
        }

        if (CollectionUtils.isEmpty(getUserSession().getProgramSpecialReportHandlingCodes())) {
            ArrayList<LookUpValueCode> lProgramSpecialReportHandlingCodes = (ArrayList<LookUpValueCode>) businessProgramService.getProgramSpecialReportHandlingCodes();
            getUserSession().setProgramSpecialReportHandlingCodes(lProgramSpecialReportHandlingCodes);
        }

        if (CollectionUtils.isEmpty(getUserSession().getAvailableSites())) {
            ArrayList<EmployerGroup> availableSites = (ArrayList<EmployerGroup>) businessProgramService.getSubGroups(lBusinessProgram.getEmployerGroup().getGroupID());
            getUserSession().setAvailableSites(availableSites);
        }

        saveProgramForm.setParticipationList(getUserSession().getParticipationList());
        saveProgramForm.setReportIndicatorList(getUserSession().getProgramSpecialReportHandlingCodes());
        saveProgramForm.setAvailableSites(getUserSession().getAvailableSites());

        saveProgramForm.setReportIndicatorCodeID(lBusinessProgram.getReportIndicatorCodeID());
        saveProgramForm.setReportIndicatorCodeValue(lBusinessProgram.getReportIndicatorCodeValue());

        saveProgramForm.setProgramTypeCodeID(lBusinessProgram.getProgramTypeCodeID());
        saveProgramForm.setProgramStatusCodeID(lBusinessProgram.getProgramStatusCodeID());
        saveProgramForm.setQualificationCheckmarkID(lBusinessProgram.getQualificationCheckmarkID() != null ? lBusinessProgram.getQualificationCheckmarkID() : 0);
        saveProgramForm.setSubgroupID(lBusinessProgram.getEmployerGroup().getSubgroupID());

        saveProgramForm.setAdditionalGroupProgramInfo(lBusinessProgram.getAdditionalGroupProgramInfo());

        return saveProgramForm;
    }

    private void populateUserSessionAndRequest(BusinessProgram lBusinessProgram, ArrayList<LookUpValueCode> lProgramSpecialReportHandlingCodes, ModelMap modelMap) throws BPMException {
        ArrayList<LookUpValueCode> lParticipationList = (ArrayList<LookUpValueCode>) businessProgramService.getParticipationCodes();
        ArrayList<EligibleActivity> lEligibleActivities = (ArrayList<EligibleActivity>) businessProgramService.getEligibleActivities(lBusinessProgram.getProgramID());
        ArrayList<Activity> lAvailableActivities = (ArrayList<Activity>) businessProgramService.getAvailableActivities(lBusinessProgram.getProgramID());
        ArrayList<LookUpValueCode> lActivationCodes = (ArrayList<LookUpValueCode>) businessProgramService.getProgramActivationCodes();
        ArrayList<QualificationCheckmark> lQualificationCheckmarks = (ArrayList<QualificationCheckmark>) businessProgramService.getQualificationCheckmarks();

        modelMap.put("reportIndicatorList", getUserSession().getProgramSpecialReportHandlingCodes());
        modelMap.put("businessProgram", lBusinessProgram);
        modelMap.put("eligibleActivities", lEligibleActivities);
        modelMap.put("availableActivities", lAvailableActivities);
        modelMap.put("participationList", lParticipationList);
        modelMap.put("activationCodes", lActivationCodes);
        modelMap.put("qualificationCheckmarks", lQualificationCheckmarks);

        getUserSession().setBusinessProgram(lBusinessProgram);
        if (getUserSession().getEligibleActivities() != null) {
            getUserSession().getEligibleActivities().clear();
        }
        if (getUserSession().getAvailableActivities() != null) {
            getUserSession().getAvailableActivities().clear();
        }
        if (getUserSession().getParticipationList() != null) {
            getUserSession().getParticipationList().clear();
        }
        if (getUserSession().getActivationCodes() != null) {
            getUserSession().getActivationCodes().clear();
        }
        if (getUserSession().getQualificationCheckmarks() != null) {
            getUserSession().getQualificationCheckmarks().clear();
        }
        if (getUserSession().getProgramSpecialReportHandlingCodes() != null) {
            getUserSession().getProgramSpecialReportHandlingCodes().clear();
        }
        getUserSession().setEligibleActivities(lEligibleActivities);
        getUserSession().setAvailableActivities(lAvailableActivities);
        getUserSession().setParticipationList(lParticipationList);
        getUserSession().setActivationCodes(lActivationCodes);
        getUserSession().setQualificationCheckmarks(lQualificationCheckmarks);
        getUserSession().setProgramSpecialReportHandlingCodes(lProgramSpecialReportHandlingCodes);
    }

    private void assignDefaultReportIndicator(BusinessProgram pBusinessProgram, ProgramType pProgramType, ArrayList<LookUpValueCode> pProgramSpecialReportHandlingCodes) {
        if (BPMAdminConstants.BPM_ADMIN_REPORT_TYPE_BUSG.equals(pProgramType.getReportIndicatorTypeCode())) {
            for (LookUpValueCode lLookUpValueCode : pProgramSpecialReportHandlingCodes) {
                if (BPMAdminConstants.BPM_ADMIN_REPORT_IND_INCLUDE.equals(lLookUpValueCode.getLuvVal())) {
                    pBusinessProgram.setReportIndicatorCodeID(lLookUpValueCode.getLuvId());
                    pBusinessProgram.setReportIndicatorCodeValue(lLookUpValueCode.getLuvDesc());
                    break;
                }
            }
        } else if (BPMAdminConstants.BPM_ADMIN_REPORT_TYPE_NONE.equals(pProgramType.getReportIndicatorTypeCode())) {
            for (LookUpValueCode lLookUpValueCode : pProgramSpecialReportHandlingCodes) {
                if (BPMAdminConstants.BPM_ADMIN_REPORT_IND_EXCLUDE.equals(lLookUpValueCode.getLuvVal())) {
                    pBusinessProgram.setReportIndicatorCodeID(lLookUpValueCode.getLuvId());
                    pBusinessProgram.setReportIndicatorCodeValue(lLookUpValueCode.getLuvDesc());
                    break;
                }
            }
        }
    }

    @Override
    public boolean supports(Class<?> clazz) {
        return CreateProgramForm.class.isAssignableFrom(clazz);
    }

    @Override
    public void validate(Object target, Errors errors) {
        CreateProgramForm form = (CreateProgramForm) target;
        getValidationSupport().validateRequiredFieldIsNotEmpty("groupID", form.getGroupID(), errors, new Object[]{"Group Number"});
        getValidationSupport().validateRequiredFieldIsNotEmpty("groupStartDate", form.getGroupStartDate(), errors, new Object[]{"Group Start Date"});
    }
}
