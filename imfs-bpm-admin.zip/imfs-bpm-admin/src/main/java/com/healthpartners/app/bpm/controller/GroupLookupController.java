package com.healthpartners.app.bpm.controller;

import com.healthpartners.app.bpm.common.BPMAdminConstants;
import com.healthpartners.app.bpm.common.BPMPagination;
import com.healthpartners.app.bpm.dto.EmployerGroup;
import com.healthpartners.app.bpm.exception.BPMException;
import com.healthpartners.app.bpm.form.GroupLookupForm;
import com.healthpartners.app.bpm.iface.BusinessProgramService;
import com.healthpartners.app.bpm.pageable.PageableEmployerGroup;
import com.healthpartners.app.bpm.session.UserSession;
import org.apache.commons.lang.StringUtils;
import org.springframework.boot.Banner;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import jakarta.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

@Controller
public class GroupLookupController extends BaseController implements Validator {

    private static final String BUSINESS_PROGRAMS_LIST = "BUSINESS_PROGRAMS";
    private static final String EMPLOYER_GROUPS_LIST = "EMPLOYER_GROUPS";
    private static final String EMPLOYER_GROUP_SITE_LIST = "EMPLOYER_GROUP_SITES";
    private final BusinessProgramService businessProgramService;


    public GroupLookupController(BusinessProgramService businessProgramService) {
        this.businessProgramService = businessProgramService;
    }

    @GetMapping("/showGroupLookup")
    public String loadShowGroupLookup(ModelMap modelMap, HttpServletRequest request) throws BPMException {
        GroupLookupForm form = new GroupLookupForm();
        form.setActionType(ACTION_SEARCH);
        UserSession userSession = getUserSession();
        userSession.reset();
        userSession.setStartDates((ArrayList<String>) businessProgramService.getAllStartDates());
        userSession.setGroupName("");

        BPMPagination pagination = new BPMPagination();
        pagination.disableBackNextButtons();
        modelMap.put("backPageFlag", pagination.getBackPageFlag());
        modelMap.put("nextPageFlag", pagination.getNextPageFlag());
        modelMap.put("startDates", userSession.getStartDates());
        modelMap.put(BPMAdminConstants.BPM_MEMBER_SERVICES_ADMIN_ROLE, Boolean.TRUE);

        String lActionType = request.getParameter("actionType");
        modelMap.put("actionType", lActionType);

        modelMap.put("groupLookupForm", form);
        return "groupLookup";
    }

    @PostMapping("/groupLookup")
    public String submitGroupLookup(@ModelAttribute("groupLookupForm") GroupLookupForm form, BindingResult result, ModelMap modelMap) throws Exception {
        validate(form, result);
        if (!result.hasErrors()) {
            loadGroups(form, modelMap);
            if (ACTION_SITE_SEARCH.equals(form.getActionType())) {
                modelMap.put("startDates", getUserSession().getStartDates());
                getUserSession().setGroupLookupForm(form);
                getUserSession().setGroupNo(form.getGroupNumber());
                if(getUserSession().getEmployerGroups() != null && getUserSession().getEmployerGroups().size() > 0) {
                    modelMap.put("groupNameExists", BPMAdminConstants.BPM_ADMIN_TRUE);
                }
            }
        }
        return "groupLookup";
    }

    @PostMapping(value="/groupLookup", params="next")
    public String submitNext(@ModelAttribute("groupLookupForm") GroupLookupForm form, ModelMap modelMap) throws Exception {
        form.setActionType(ACTION_PAGE_FORWARD);
        loadGroups(form, modelMap);
        return "groupLookup";
    }

    @PostMapping(value="/groupLookup", params="back")
    public String submitBack(@ModelAttribute("groupLookupForm") GroupLookupForm form, ModelMap modelMap) throws Exception {
        form.setActionType(ACTION_PAGE_BACK);
        loadGroups(form, modelMap);
        return "groupLookup";
    }

    @PostMapping(value="/groupLookup", params="backToGroupList")
    public String submitBackToGroupList(@ModelAttribute("groupLookupForm") GroupLookupForm form, ModelMap modelMap) throws Exception {
        form.setActionType(ACTION_BACK_TO_GROUP_LIST);
        form.setGroupNumber("");
        form.setGroupName(getUserSession().getGroupName());
        form.setWhichList("");
        getUserSession().setEmployerGroups(new ArrayList<>());
        backToGroupList(modelMap, form);
        loadGroups(form, modelMap);
        return "groupLookup";
    }

    private void loadGroups(GroupLookupForm groupLookupForm, ModelMap modelMap) throws Exception {
        UserSession sessionBean = getUserSession();
        String groupNumber = groupLookupForm.getGroupNumber();
        String groupName = groupLookupForm.getGroupName();

        if ((groupName != null && groupName.trim().length() > 0)) {
            searchByGroupName(modelMap, groupLookupForm, sessionBean);
        }

        if ((groupNumber != null && groupNumber.trim().length() > 0)) {
            searchByGroupNumber(modelMap, groupLookupForm, sessionBean);
        }
    }

    protected void searchByGroupName(ModelMap modelMap, GroupLookupForm groupLookupForm, UserSession sessionBean) throws Exception {
        boolean newDTOList = false;
        ArrayList<EmployerGroup> lEmployerGroups = sessionBean.getEmployerGroups();
        String actionType = groupLookupForm.getActionType();

        if (CollectionUtils.isEmpty(lEmployerGroups)) {
            lEmployerGroups = (ArrayList<EmployerGroup>) businessProgramService.getGroupsByName(groupLookupForm.getGroupName());
            sessionBean.setEmployerGroups(lEmployerGroups);
            newDTOList = true;
        }

        //Pagination code begins here.
        setEmployerGroupPaginationOnModel(modelMap, sessionBean, actionType, newDTOList);
        //Pagination code ends here.

        modelMap.put("groupNameExists", BPMAdminConstants.BPM_ADMIN_FALSE);
        modelMap.put("whichList", EMPLOYER_GROUPS_LIST);

        if (lEmployerGroups.size() <= 0) {
            createNoResultsFoundMessageOnModel(modelMap);
        }

        sessionBean.setEmployerGroups(lEmployerGroups);
        sessionBean.setGroupLookupForm(groupLookupForm);
        sessionBean.setGroupName(groupLookupForm.getGroupName());
        groupLookupForm.setGroupName(sessionBean.getGroupName());
    }

    protected void searchByGroupNumber(ModelMap modelMap, GroupLookupForm groupLookupForm, UserSession sessionBean) throws Exception {
        String actionType = groupLookupForm.getActionType();
        boolean newDTOList = false;

        ArrayList<EmployerGroup> lEmployerGroups = sessionBean.getAvailableSites();

        if (CollectionUtils.isEmpty(lEmployerGroups) || actionType.equals(ACTION_SEARCH) || actionType.equals(ACTION_SITE_SEARCH)) {
            lEmployerGroups = (ArrayList<EmployerGroup>) businessProgramService.getAllGroupSites(groupLookupForm.getGroupNumber());
            sessionBean.setAvailableSites(lEmployerGroups);
            sessionBean.setEmployerGroups(lEmployerGroups);
            newDTOList = true;
        }

        //Pagination code begins here.
        setEmployerGroupSitePagination(modelMap, sessionBean, actionType, newDTOList);
        //Pagination code ends here.
        // EV 54718 - Set the employer Group to empty so that the Sites list displays on the page.
        modelMap.put("employerGroups", new ArrayList<EmployerGroup>());
        modelMap.put("whichList", BUSINESS_PROGRAMS_LIST);

        if (lEmployerGroups.size() <= 0) {
            String message = getMessage("messages.info", new Object[]{"No results found for the given search attribute(s)"});
            List<String> messages = new ArrayList<>();
            messages.add(message);
            modelMap.put("messages", messages);
        }

        sessionBean.setAvailableSites(lEmployerGroups);
        sessionBean.setGroupLookupForm(groupLookupForm);
        if (sessionBean.getEmployerGroups() != null && sessionBean.getEmployerGroups().size() > 0) {
            modelMap.put("groupNameExists", BPMAdminConstants.BPM_ADMIN_TRUE);
        }
    }

    protected void setEmployerGroupSitePagination(ModelMap modelMap, UserSession sessionBean, String actionType, boolean newDTOList) {
        ArrayList<EmployerGroup> lSites = sessionBean.getAvailableSites();
        BPMPagination pagination = sessionBean.getPaginationMap().get(EMPLOYER_GROUP_SITE_LIST);
        PageableEmployerGroup lPEG = null;
        if (pagination == null || newDTOList) {
            lPEG = new PageableEmployerGroup(lSites);
            lPEG.addRowNumber();
            pagination = new BPMPagination(lPEG, new ArrayList<Object>(lSites));
            sessionBean.getPaginationMap().put(EMPLOYER_GROUP_SITE_LIST, pagination);
        }

        ArrayList<EmployerGroup> lEmployerGroupsPerPage = (ArrayList<EmployerGroup>) determineNextOrBackAction(actionType, pagination);
        setAttributesForPaginationOnModel(modelMap, lSites.size(), pagination);
        modelMap.put("groupSites", lEmployerGroupsPerPage);
        sessionBean.setEmployerGroupsPerPage(lEmployerGroupsPerPage);
    }

    protected void backToGroupList(ModelMap modelMap, GroupLookupForm pGroupLookupForm) throws Exception {
        ArrayList<EmployerGroup> lEmployerGroups = getUserSession().getEmployerGroups();
        ArrayList<EmployerGroup> lEmployerGroupsPerPage = getUserSession().getEmployerGroupsPerPage();

        BPMPagination pagination = getUserSession().getPaginationMap().get(EMPLOYER_GROUPS_LIST);
        modelMap.put("employerGroups", lEmployerGroupsPerPage);
        setAttributesForPaginationOnModel(modelMap, lEmployerGroups.size(), pagination);

        modelMap.put("groupNameExists", BPMAdminConstants.BPM_ADMIN_FALSE);
        modelMap.put("whichList", EMPLOYER_GROUPS_LIST);

        getUserSession().setGroupLookupForm(pGroupLookupForm);
        pGroupLookupForm.setGroupName(getUserSession().getGroupName());
    }

    @Override
    public boolean supports(Class<?> clazz) {
        return GroupLookupForm.class.isAssignableFrom(clazz);
    }

    @Override
    public void validate(Object target, Errors errors) {
        GroupLookupForm form = (GroupLookupForm) target;
        String groupNumber = form.getGroupNumber();
        String groupName = form.getGroupName();

        if(StringUtils.isEmpty(groupNumber) && StringUtils.isEmpty(groupName)) {
            String errorMessage = getMessageSource().getMessage("errors.required", new Object[]{"Group Number or Group Name"}, Locale.getDefault());
            errors.rejectValue("groupNumber", REQUIRED, errorMessage);
        }

        if (!StringUtils.isEmpty(groupNumber) && !StringUtils.isEmpty(groupName)) {
            String errorMessage = getMessageSource().getMessage("errors.groupNameOrNumber", null, Locale.getDefault());
            errors.rejectValue("groupNumber", REQUIRED, errorMessage);
        }

        getValidationSupport().validateNotSpecialChar("groupNumber", groupNumber, errors, new Object[]{"Group Number"});
        getValidationSupport().validateNotSpecialChar("groupName", groupName, errors, new Object[]{"Group Name"});
    }
}
