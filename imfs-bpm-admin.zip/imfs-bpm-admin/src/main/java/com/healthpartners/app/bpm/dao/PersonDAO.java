package com.healthpartners.app.bpm.dao;

import com.healthpartners.app.bpm.dto.*;
import com.healthpartners.app.bpm.exception.BPMException;
import com.healthpartners.service.bpm.dto.MemberActivity;
import org.springframework.dao.DataAccessException;

import java.sql.Date;
import java.sql.SQLTimeoutException;
import java.util.ArrayList;
import java.util.Collection;

public interface PersonDAO {
	Collection<PersonActivityContributionPending> getPersonActivityNonEmployerSponsoredContributionsPending(PersonActivityIncentiveSearch lPersonActivityIncentiveSearch)
			throws DataAccessException;
	Collection<PersonActivityContributionPending> getPersonActivityEmployerSponsoredContributionsPending(PersonActivityIncentiveSearch lPersonActivityIncentiveSearch)
			throws DataAccessException;
	int deletePersonProgramActivities(Integer businessProgramID) throws DataAccessException;
	int deletePersonPrograms(Integer businessProgramID) throws DataAccessException;

	Collection<PersonRelationshipCode> getPersonRelationshipCodes() throws DataAccessException;

	int updateMemberStatusByCodeValue(Integer pPersonID, Integer pProgramID, Integer pGroupID, String pNewStatus, String pUserID) throws DataAccessException;

	int deletePersonProgramsByProgramIncentiveOptionID(Integer pProgramIncentiveOptionID) throws DataAccessException;

	boolean isActivityRequirementRegisteredToPersonProgramActivityStatus(Integer programID, Integer activityID) throws BPMException, DataAccessException;

    Integer getPersonID(String memberID) throws DataAccessException;

	MemberDetail getMemberDetail(Integer personID, java.sql.Date qualificationStartDate) throws DataAccessException;

	Collection<MemberProgramDetail> getMemberProgramDetails(Integer personID, java.sql.Date qualificationStartDate) throws DataAccessException, DataAccessException;

	Collection<MemberProgramActivity> getMemberProgramActivities(Integer personID, Integer programID) throws DataAccessException, DataAccessException;

	Collection<MemberProgramActivity> getMemberProgramActivitiesOutsideEnrollment(
			Integer personID, Integer programID) throws DataAccessException,
			DataAccessException;

	Collection<MemberProgramActivity> getMemberProgramActivitiesNoDupsToWaive(Integer personID, Integer programID) throws DataAccessException, DataAccessException;

	Collection<MemberProgramActivity> getMemberProgramActivitiesNoDupsToWaiveOutsideEnrollment(
			Integer personID, Integer programID) throws DataAccessException,
			DataAccessException;

	Collection<MemberActivity> getPersonProgramActivityStatus(Integer personId, Integer programID);

	//Produces warnings during compile time to quickly identify typos or API changes
	Collection<PersonActivityIncentive> selectPersonActivityIncentive(Integer pPersonDemographicsID, Integer pBusinessProgramID);

	Collection<ContractProgramIncentive> selectContractProgramIncentive(Integer pContractNo, Integer pBusinessProgramID);

	Collection<MemberProgramIncentiveTO> getMemberProgramIncentive(Integer pPersonDemographicsID
			, Integer pBusinessProgramID
			, Integer pContractNo)
			throws DataAccessException;

	//Produces warnings during compile time to quickly identify typos or API changes
	Collection<MemberPackage> getMemberPackages(Integer pPersonDemographicsID, Integer pBusinessProgramID, Integer pContractNo) throws DataAccessException;

	Collection<MemberStatusDetail> getMemberStatusDetails(Integer pPersonDemographicsID, Integer pProgramID, Integer pContractNo) throws DataAccessException;

    Collection<String> getMemberIDFromPersonDetails(String firstName, String middleInitial, String lastName, String gender, Date dateOfBirth) throws DataAccessException;

	ArrayList<MemberProgramDetail> selectPersonProgramRelationship(String pMemberID) throws DataAccessException;

	//Produces warnings during compile time to quickly identify typos or API changes
	Collection<MemberDetail> getRelatedMemberDetails(String memberID) throws DataAccessException;

	ArrayList<PersonContractHist> getPersonContractsHistory(
			String memberId, String contractNo, Date programEffectiveDate, String groupNo, String luvContractHistResultCodeValue)
			throws DataAccessException, SQLTimeoutException;

    Collection<CDHPFulfillmentTrackingRecycle> getPersonCDHPFulfillsRecycle(
            String memberId, String groupNo, String contractNo, Date recycleStatusDate, Integer recycleStatusId, String programName)
            throws DataAccessException;

    int updatePersonCDHPFulfillRecycle(CDHPFulfillmentTrackingRecycle lCDHPFulfillmentTrackingRecycle) throws DataAccessException;

	int updateMemberProgramActivityIncentiveModifyDate(Integer personDemographicsID, Integer programID, Integer activityID, String userID) throws DataAccessException;

	CDHPFulfillmentTrackingRecycle getPersonCDHPFulfillRecycle(Integer recycleID) throws DataAccessException;

	MemberDetail getMemberDetail(Integer personID, Integer programID) throws DataAccessException;

	MemberProgramDetail getMemberProgramDetail(Integer personID, Integer programID) throws DataAccessException;

    Collection<PersonContractRecycle> getPersonContractsRecycle(
            String memberId, String groupNo, String contractNo, Date recycleStatusDate, Integer recycleStatusId, String programName)
            throws DataAccessException;

    //Produces warnings during compile time to quickly identify typos or API changes
    int updatePersonContractRecycle(PersonContractRecycle personContractRecycle)
            throws DataAccessException;

	//Produces warnings during compile time to quickly identify typos or API changes
	int updateMemberProgramStatusContractStatusDate(Integer personId, Integer programId) throws DataAccessException;

    PersonContractRecycle getPersonContractRecycle(Integer recycleID) throws DataAccessException;

	public Collection<MemberProgramDetail> getTermedMemberProgramHistoryDetails(
			Integer personID, Date qualificationStartDate)
			throws DataAccessException;

	public int updateMemberStatus(Integer pPersonID, Integer pProgramID, Integer pNewStatus, String pUserID, Integer pProgramIncentiveOptionID)
			throws DataAccessException;

	public int updateParticipationEndDate(Integer pPersonDemographicsID, Integer pProgramID, java.sql.Date pParticipationEndDate)
			throws DataAccessException;
}
