package com.healthpartners.app.bpm.controller;

import com.healthpartners.app.bpm.common.BPMAdminConstants;
import com.healthpartners.app.bpm.dto.*;
import com.healthpartners.app.bpm.exception.BPMException;
import com.healthpartners.app.bpm.form.MemberActivityHistorySearchForm;
import com.healthpartners.app.bpm.form.SaveProgramIncentiveForm;
import com.healthpartners.app.bpm.form.SystemsLookupForm;
import com.healthpartners.app.bpm.iface.BusinessProgramService;
import com.healthpartners.app.bpm.iface.EnvCodeService;
import com.healthpartners.app.bpm.iface.LookUpValueService;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.view.RedirectView;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;

@Controller
public class SystemsLookupController extends BaseController implements Validator {
    private final BusinessProgramService businessProgramService;
    private final LookUpValueService lookUpValueService;
    private final EnvCodeService envCodeService;

    public SystemsLookupController(BusinessProgramService businessProgramService, LookUpValueService lookUpValueService, EnvCodeService envCodeService) {
        this.businessProgramService = businessProgramService;
        this.lookUpValueService = lookUpValueService;
        this.envCodeService = envCodeService;
    }

    @GetMapping("/showSystemsLookup")
    public String loadSearch(ModelMap modelMap) throws BPMException {
        try {
            SystemsLookupForm form = new SystemsLookupForm();
            modelMap.put("systemsLookupForm", form);
        } catch (Exception e) {
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
            modelMap.put("errorMsg", getStackTrace(e));
        }

        return "systemsLookup";
    }

    @PostMapping(value = "/systemsLookup", params = "cancel")
    public RedirectView submitCancelEditProgram(@ModelAttribute("systemsLookupForm") SystemsLookupForm form, RedirectAttributes ra) {
        return new RedirectView("index");
    }

    @PostMapping("/systemsLookup")
    public String submitSearch(@ModelAttribute("systemsLookupForm") SystemsLookupForm form, ModelMap modelMap, BindingResult result) throws Exception {
        try {
            if (StringUtils.isEmpty(form.getActionType())) {
                form.setActionType(ACTION_SEARCH);
            }
            if (ACTION_SEARCH.equals(form.getActionType())) {
                validate(form, result);
                if (!result.hasErrors()) {
                    search(modelMap, form);
                }
            }
        } catch (Exception e) {
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
            // Add error stack trace on the request, to be hidden in html.
            createErrorMessageOnModel(modelMap, getStackTrace(e));
        }

        return "systemsLookup";
    }

    private void search(ModelMap modelMap, SystemsLookupForm form) throws BPMException {
        if (BPMAdminConstants.BPM_ADMIN_ACTIVITY_DEFINITIONS.equalsIgnoreCase(form.getSystemValue())) {
            ArrayList<Activity> lActivities = (ArrayList<Activity>) businessProgramService.selectActivities();
            // Sort the activities on Activity Name
            Collections.sort(lActivities, Comparator.comparing(Activity::getName));
            modelMap.put("activities", lActivities);

        } else if (BPMAdminConstants.BPM_ADMIN_BPM_PROGRAM_DEFINITIONS.equalsIgnoreCase(form.getSystemValue())) {
            ArrayList<ProgramType> lProgramTypes = (ArrayList<ProgramType>) businessProgramService.getProgramTypes();
            modelMap.put("programTypes", lProgramTypes);

        } else if (BPMAdminConstants.BPM_ADMIN_INCENTIVE_OPTIONS.equalsIgnoreCase(form.getSystemValue())) {
            ArrayList<IncentiveOption> lIncentiveOptions = (ArrayList<IncentiveOption>) businessProgramService.getIncentiveOptions();
            modelMap.put("incentiveOptions", lIncentiveOptions);

        } else if (BPMAdminConstants.BPM_ADMIN_LOOKUP_VALUE_CODES.equalsIgnoreCase(form.getSystemValue())) {
            Collection<LookUpValueCode> codes = lookUpValueService.getAllLUVCodes();
            modelMap.put("codes", codes);

        } else if (BPMAdminConstants.BPM_ADMIN_RISK_OUTOMES.equalsIgnoreCase(form.getSystemValue())) {
            ArrayList<Risk> lRisks = (ArrayList<Risk>) businessProgramService.selectRisks();
            modelMap.put("risks", lRisks);

        } else if (BPMAdminConstants.BPM_ADMIN_PACKAGE_DEFINITION.equalsIgnoreCase(form.getSystemValue())) {
            ArrayList<ProgramPackage> lProgramPackages = (ArrayList<ProgramPackage>) businessProgramService.getProgramPackages();
            for (int i = 0; i < lProgramPackages.size(); i++) {
                ArrayList<PackageActivity> lPackageActivities = (ArrayList<PackageActivity>) businessProgramService.getPackageActivities(lProgramPackages.get(i).getPackageID());
                lProgramPackages.get(i).setPackageActivities(lPackageActivities);
            }
            modelMap.put("programPackages", lProgramPackages);

        } else if (BPMAdminConstants.BPM_ADMIN_QUALIFICATION_CHECKMARKS.equalsIgnoreCase(form.getSystemValue())) {
            ArrayList<QualificationCheckmark> lQualificationCheckmarks = (ArrayList<QualificationCheckmark>) businessProgramService.getQualificationCheckmarks();
            for (int i = 0; i < lQualificationCheckmarks.size(); i++) {
                lQualificationCheckmarks.get(i).setCheckmarkRequirements((ArrayList<CheckmarkRequirement>) businessProgramService.getCheckmarkRequirements(lQualificationCheckmarks.get(i).getQualificationCheckmarkID()));
            }
            modelMap.put("qualificationCheckmarks", lQualificationCheckmarks);

        } else if (BPMAdminConstants.BPM_ADMIN_PARTICIPATION_GROUPS.equalsIgnoreCase(form.getSystemValue())) {
            ArrayList<ParticipationGroup> lParticipationGroups = (ArrayList<ParticipationGroup>) businessProgramService.getParticipationGroups();
            for (ParticipationGroup lParticipationGroup : lParticipationGroups) {
                lParticipationGroup.setParticipationGroupRequirements(businessProgramService.getParticipationGroupRequirements(lParticipationGroup.getParticipationGroupID()));
            }
            modelMap.put("participationGroups", lParticipationGroups);

        } else if (BPMAdminConstants.BPM_ADMIN_COLLECTIONS.equalsIgnoreCase(form.getSystemValue())) {
            ArrayList<BPMCollection> lBPMCollections = (ArrayList<BPMCollection>) businessProgramService.getAllCollections();
            for (BPMCollection lBPMCollection : lBPMCollections) {
                lBPMCollection.setCollectionActivities(businessProgramService.getCollectionActivities(lBPMCollection.getCollectionID()));
            }
            modelMap.put("collections", lBPMCollections);
            getUserSession().setCollections(lBPMCollections);

        } else if (BPMAdminConstants.BPM_ADMIN_ENVIRONMENT_CODES.equalsIgnoreCase(form.getSystemValue())) {
            Collection<BPMEnvCode> lEnvCodes = envCodeService.getAllEnvCodes();
            modelMap.put("envCodes", lEnvCodes);

        } else if (BPMAdminConstants.BPM_ADMIN_EXT_EMPLOYER_ACTIVITIES.equalsIgnoreCase(form.getSystemValue())) {
            Collection<ExtEmployerActivity> lExtEmployerActivities = businessProgramService.getExtEmployerActivities();
            modelMap.put("extEmployerActivities", lExtEmployerActivities);
        }
    }


    @Override
    public boolean supports(Class<?> clazz) {
        return SystemsLookupForm.class.isAssignableFrom(clazz);
    }

    @Override
    public void validate(Object target, Errors errors) {
        SystemsLookupForm form = (SystemsLookupForm) target;
        if (StringUtils.isEmpty(form.getSystemValue())) {
            getValidationSupport().addValidationFailureMessage("systemValue", errors, "errors.notselected", new Object[]{"System Value"});
        }
    }
}
