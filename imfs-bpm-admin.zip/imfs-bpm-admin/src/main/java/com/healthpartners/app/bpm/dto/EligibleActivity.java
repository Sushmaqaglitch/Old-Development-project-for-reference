package com.healthpartners.app.bpm.dto;

import java.io.Serializable;

public class EligibleActivity implements Serializable {
    static final long serialVersionUID = 0L;

    private Integer programID;
    private Activity activityDefinition;

    private Integer activityGroupID;
    private String groupName;
    private String siteNo;

    // Eligible ActivityDefinition attributes.
    private String activityCostDescription;
    private String authorizationCode;
    private java.sql.Date qualificationWindowStartDate;
    private java.sql.Date qualificationWindowEndDate;
    private java.sql.Date qualificationWindowEarlyStartDate;
    private java.sql.Date qualificationWindowLateEndDate;
    private java.sql.Date enrollmentDeadlineDate;
    private Integer activityScore;
    private String exclusionOptionFlag;
    private Integer incentiveOverrideCodeID = 0;
    private String incentiveOverrideCode;

    private String activityName;
    private String activityDesc;

    private GenericStatusType eligibleActivityStatus;

    private String customActiveName;
    private String customActiveDescription;

    public EligibleActivity() {
        super();
    }


    public Activity getActivity() {
        return activityDefinition;
    }


    public void setActivity(Activity activityDefinition) {
        this.activityDefinition = activityDefinition;
    }


    public String getActivityCostDescription() {
        return activityCostDescription;
    }


    public void setActivityCostDescription(String activityCostDescription) {
        this.activityCostDescription = activityCostDescription;
    }


    public Integer getActivityGroupID() {
        return activityGroupID;
    }


    public void setActivityGroupID(Integer activityGroupID) {
        this.activityGroupID = activityGroupID;
    }


    public Integer getActivityScore() {
        return activityScore;
    }


    public void setActivityScore(Integer activityScore) {
        this.activityScore = activityScore;
    }


    public String getAuthorizationCode() {
        return authorizationCode;
    }


    public void setAuthorizationCode(String authorizationCode) {
        this.authorizationCode = authorizationCode;
    }


    public java.sql.Date getQualificationWindowEarlyStartDate() {
        return qualificationWindowEarlyStartDate;
    }


    public void setQualificationWindowEarlyStartDate(java.sql.Date qualificationWindowEarlyStartDate) {
        this.qualificationWindowEarlyStartDate = qualificationWindowEarlyStartDate;
    }


    public java.sql.Date getQualificationWindowEndDate() {
        return qualificationWindowEndDate;
    }


    public void setQualificationWindowEndDate(java.sql.Date qualificationWindowEndDate) {
        this.qualificationWindowEndDate = qualificationWindowEndDate;
    }


    public java.sql.Date getQualificationWindowLateEndDate() {
        return qualificationWindowLateEndDate;
    }


    public void setQualificationWindowLateEndDate(java.sql.Date qualificationWindowLateEndDate) {
        this.qualificationWindowLateEndDate = qualificationWindowLateEndDate;
    }


    public java.sql.Date getQualificationWindowStartDate() {
        return qualificationWindowStartDate;
    }


    public void setQualificationWindowStartDate(java.sql.Date qualificationWindowStartDate) {
        this.qualificationWindowStartDate = qualificationWindowStartDate;
    }


    public java.sql.Date getEnrollmentDeadlineDate() {
        return enrollmentDeadlineDate;
    }


    public void setEnrollmentDeadlineDate(java.sql.Date enrollmentDeadlineDate) {
        this.enrollmentDeadlineDate = enrollmentDeadlineDate;
    }


    public Activity getActivityDefinition() {
        return activityDefinition;
    }


    public void setActivityDefinition(Activity activityDefinition) {
        this.activityDefinition = activityDefinition;
    }


    public GenericStatusType getEligibleActivityStatus() {
        return eligibleActivityStatus;
    }


    public void setEligibleActivityStatus(GenericStatusType eligibleActivityStatus) {
        this.eligibleActivityStatus = eligibleActivityStatus;
    }


    public Integer getProgramID() {
        return programID;
    }


    public void setProgramID(Integer programID) {
        this.programID = programID;
    }


    public final String getExclusionOptionFlag() {
        return exclusionOptionFlag;
    }


    public final void setExclusionOptionFlag(String exclusionOptionFlag) {
        this.exclusionOptionFlag = exclusionOptionFlag;
    }


    public String getGroupName() {
        return groupName;
    }


    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }


    public Integer getIncentiveOverrideCodeID() {
        return incentiveOverrideCodeID;
    }


    public void setIncentiveOverrideCodeID(Integer incentiveOverrideCodeID) {
        this.incentiveOverrideCodeID = incentiveOverrideCodeID;
    }


    public String getIncentiveOverrideCode() {
        return incentiveOverrideCode;
    }


    public void setIncentiveOverrideCode(String incentiveOverrideCode) {
        this.incentiveOverrideCode = incentiveOverrideCode;
    }


    public String getActivityName() {
        return activityName;
    }


    public void setActivityName(String activityName) {
        this.activityName = activityName;
    }


    public String getActivityDesc() {
        return activityDesc;
    }


    public void setActivityDesc(String activityDesc) {
        this.activityDesc = activityDesc;
    }


    public String getSiteNo() {
        return siteNo;
    }


    public void setSiteNo(String siteNo) {
        this.siteNo = siteNo;
    }


    public String getCustomActiveName() {
        return customActiveName;
    }


    public void setCustomActiveName(String customActiveName) {
        this.customActiveName = customActiveName;
    }


    public String getCustomActiveDescription() {
        return customActiveDescription;
    }


    public void setCustomActiveDescription(String customActiveDescription) {
        this.customActiveDescription = customActiveDescription;
    }

}
