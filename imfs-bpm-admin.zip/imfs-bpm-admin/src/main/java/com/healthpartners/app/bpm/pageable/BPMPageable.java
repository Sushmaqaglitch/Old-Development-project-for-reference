package com.healthpartners.app.bpm.pageable;

/**
 * Interface for pageable class.
 * All the concrete classes will implement this interface, and need to implement the
 * addRowNumber method.
 *
 * @author jxbourbour
 */
public interface BPMPageable {
    public void addRowNumber();
}
