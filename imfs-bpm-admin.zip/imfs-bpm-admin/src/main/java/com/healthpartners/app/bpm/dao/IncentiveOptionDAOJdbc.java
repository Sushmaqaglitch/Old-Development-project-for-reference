package com.healthpartners.app.bpm.dao;

import com.healthpartners.app.bpm.common.BPMAdminConstants;
import com.healthpartners.app.bpm.dto.IncentiveOption;
import com.healthpartners.app.bpm.dto.ProgramIncentiveOption;
import com.healthpartners.app.bpm.exception.BPMException;
import jakarta.annotation.PostConstruct;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.jdbc.support.incrementer.DataFieldMaxValueIncrementer;
import org.springframework.jdbc.support.incrementer.OracleSequenceMaxValueIncrementer;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Collection;

@Repository
@Transactional(timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
public class IncentiveOptionDAOJdbc extends JdbcDaoSupport implements IncentiveOptionDAO {

    private static final String selectProgramIncentiveOptions = " SELECT\n" +
            " BIZ_PGM_ID\n" +
            ", bpm_io.INCNTV_OPTN_ID\n" +
            ", INCNTV_OPTN_ADDL_INFO\n" +
            ", INCNTV_OPTN_INFO\n" +
            ", INCNTV_OPTN_CREATION_DT\n" +
            ", INCNTV_OPTN_CLOSE_DT\n" +
            ", STAT_CD_ID\n" +
            ", io_stat.lu_val option_stat_val\n" +
            ", io_stat.lu_desc option_stat_desc\n" +
            ", INCNTV_OPTN_EFF_DT\n" +
            ", INCNTV_OPTN_END_DT\n" +
            ", INCNTV_OPTN_ACTV_DT\n" +
            ", INCNTV_OPTN_DLVRY_DT\n" +
            ", INCNTV_OPTN_NM\n" +
            ", INCNTV_OPTN_TP_CD_ID\n" +
            ", io_tp.LU_VAL option_type_val\n" +
            ", io_tp.LU_DESC option_type_desc\n" +
            ", INCNTV_OPTN_DESC\n" +
            ", FULFILLMENT_RTNG_TP_CD_ID\n" +
            ", io_fulfill.LU_VAL fulfill_type_val\n" +
            ", io_fulfill.LU_DESC fulfill_type_desc\n" +
            ", INCNTD_STS_TP_CD_ID\n" +
            ", io_incented_stat.LU_VAL incented_status_type_val\n" +
            ", io_incented_stat.LU_DESC incented_status_type_desc\n" +
            ", PARTICIP_CAP\n" +
            ", FAMILY_CAP\n" +
            ", DELIVERY_INFO\n" +
            ", bpm_io.INCNTV_URL\n" +
            ", bpm_bio.ENROLL_DEADLINE_DT\n" +
            ", bpm_bio.COMPL_DEADLINE_DT\n" +
            ", bpm_bio.INCNTV_RULE_TP_ID\n" +
            ", (SELECT lu_desc FROM luv WHERE lu_id = INCNTV_RULE_TP_ID) INCNTV_RULE_TP_CODE\n" +
            ", bpm_bio.incntv_rpt_desc_id\n" +
            ", (SELECT lu_val FROM luv WHERE lu_id = bpm_bio.incntv_rpt_desc_id) INCNTV_RPT_DESC_CODE\n" +
            ", INCNTV_PART_GRP_ID\n" +
            ", (SELECT INCNTV_PART_GRP_NM FROM incntv_participation_grp ipg WHERE ipg.INCNTV_PART_GRP_ID = bpm_bio.INCNTV_PART_GRP_ID) INCNTV_PART_GRP_NM\n" +
            ", (SELECT INCNTV_PART_GRP_INFO FROM incntv_participation_grp ipg WHERE ipg.INCNTV_PART_GRP_ID = bpm_bio.INCNTV_PART_GRP_ID) INCNTV_PART_GRP_INFO\n" +
            ", INCNTV_OPTN_REWARD_CARD_ID\n" +
            ", RUN_FREQ_ID\n" +
            ", ACTV_CMPLTN_PRD\n" +
            ", BIZ_PGM_INCNTV_OPTN_ID\n" +
            ", NEW_HIRE_DT\n" +
            ", bpm_bio.incntv_cap_tp_cd_id INCNTV_UNIT_TP_CD_ID\n" +
            ", (SELECT lu_desc FROM luv WHERE lu_id = bpm_bio.incntv_cap_tp_cd_id) INCNTV_UNIT_TP_CD_DESC\n" +
            ", bpm_bio.INCNTV_OPTN_PKG_RULE_GRP_ID\n" +
            ", (SELECT ioprg.INCNTV_OPTN_PKG_RULE_GRP_NM FROM incntv_optn_pkg_rule_grp ioprg WHERE ioprg.INCNTV_OPTN_PKG_RULE_GRP_ID = bpm_bio.INCNTV_OPTN_PKG_RULE_GRP_ID) INCNTV_OPTN_PKG_RULE_GRP_NM\n" +
            ", bpm_bio.DELIVERY_INFO_CD_ID\n" +
            ", bpm_bio.sort_ordr\n" +
            ", (SELECT lu_desc FROM luv WHERE lu_id = bpm_bio.DELIVERY_INFO_CD_ID) DELIVERY_INFO_CD_DESC\n" +
            " FROM\n" +
            "  BIZ_PGM_INCENTIVE_OPTION bpm_bio\n" +
            ", INCENTIVE_OPTION bpm_io\n" +
            ", LUV io_tp\n" +
            ", LUV io_stat\n" +
            ", LUV io_fulfill\n" +
            ", LUV io_incented_stat\n" +
            "WHERE\n" +
            " BIZ_PGM_ID = ?\n" +
            "AND bpm_bio.INCNTV_OPTN_ID = bpm_io.INCNTV_OPTN_ID\n" +
            "AND bpm_bio.FULFILLMENT_RTNG_TP_CD_ID = io_fulfill.lu_id\n" +
            "\n" +
            "AND INCNTV_OPTN_TP_CD_ID  = io_tp.lu_id\n" +
            "AND STAT_CD_ID = io_stat.lu_id\n" +
            "AND INCNTD_STS_TP_CD_ID = io_incented_stat.lu_id\n" +
            "AND bpm_io.INCNTV_OPTN_TP_CD_ID  = io_tp.lu_id\n" +
            "AND bpm_bio.STAT_CD_ID = io_stat.lu_id\n" +
            "AND bpm_bio.INCNTD_STS_TP_CD_ID = io_incented_stat.lu_id\n" +
            "AND bpm_io.incntv_optn_close_dt = to_date('01019999', 'MMDDYYYY')";
    
    private static final String deleteProgramIncentiveOption = "DELETE FROM biz_pgm_incentive_option WHERE biz_pgm_incntv_optn_id = ?";
    
    private static final String updateProgramIncentiveOption =
            "UPDATE biz_pgm_incentive_option SET\n" +
                    "INCNTV_OPTN_ADDL_INFO = ?\n" +
                    ", INCNTV_OPTN_INFO = ?\n" +
                    ", STAT_CD_ID  = ?\n" +
                    ", INCNTV_OPTN_EFF_DT = ?\n" +
                    ", INCNTV_OPTN_END_DT = ?\n" +
                    ", INCNTV_OPTN_ACTV_DT = ?\n" +
                    ", INCNTV_OPTN_DLVRY_DT = ?\n" +
                    ", MODIFY_USR = ?\n" +
                    ", MODIFY_TS = SYSDATE\n" +
                    ", FULFILLMENT_RTNG_TP_CD_ID = ?\n" +
                    ", INCNTD_STS_TP_CD_ID = ?\n" +
                    ", PARTICIP_CAP = ?\n" +
                    ", FAMILY_CAP = ?\n" +
                    ", DELIVERY_INFO = ?\n" +
                    ", ENROLL_DEADLINE_DT = ?\n" +
                    ", COMPL_DEADLINE_DT = ?\n" +
                    ", INCNTV_RULE_TP_ID = ?\n" +
                    ", incntv_rpt_desc_id = ?\n" +
                    ", INCNTV_PART_GRP_ID = ?\n" +
                    ", INCNTV_OPTN_REWARD_CARD_ID = ?\n" +
                    ", RUN_FREQ_ID = ?\n" +
                    ", ACTV_CMPLTN_PRD = ?\n" +
                    ", new_hire_dt = ?\n" +
                    ", incntv_cap_tp_cd_id = ?\n" +
                    ", INCNTV_OPTN_PKG_RULE_GRP_ID = ?\n" +
                    ", DELIVERY_INFO_CD_ID = ?\n" +
                    ", SORT_ORDR = ?\n" +
                    "WHERE biz_pgm_id = ? AND INCNTV_OPTN_ID = ?";
    
    private static final String insertProgramIncentiveOption = """
            INSERT INTO biz_pgm_incentive_option
            				(BIZ_PGM_ID
            				, INCNTV_OPTN_ID
            				, INCNTV_OPTN_ADDL_INFO
            				, INCNTV_OPTN_INFO
            				, STAT_CD_ID
            				, INCNTV_OPTN_EFF_DT
            				, INCNTV_OPTN_END_DT
            				, INCNTV_OPTN_ACTV_DT
            				, INCNTV_OPTN_DLVRY_DT
            				, INSERT_USR
            				, INSERT_TS
            				, FULFILLMENT_RTNG_TP_CD_ID
            				, INCNTD_STS_TP_CD_ID
            				, PARTICIP_CAP
            				, FAMILY_CAP
            				, DELIVERY_INFO
            				, ENROLL_DEADLINE_DT
            				, COMPL_DEADLINE_DT
            				, INCNTV_RULE_TP_ID
            				, incntv_rpt_desc_id
            				, INCNTV_PART_GRP_ID
            				, INCNTV_OPTN_REWARD_CARD_ID
            				, RUN_FREQ_ID
            				, ACTV_CMPLTN_PRD
            				, biz_pgm_incntv_optn_ID
            				, new_hire_dt
            				, incntv_cap_tp_cd_id
            				, INCNTV_OPTN_PKG_RULE_GRP_ID
            				, DELIVERY_INFO_CD_ID
            			    , SORT_ORDR
            ) VALUES
            (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, SYSDATE, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """;

    private static final String selectIncentiveOptions = """
            SELECT
              bpm_io.INCNTV_OPTN_ID
            , INCNTV_OPTN_NM
            , INCNTV_OPTN_TP_CD_ID
            , INCNTV_OPTN_DESC
            , INCNTV_URL
            , INCNTV_OPTN_CREATION_DT
            , INCNTV_OPTN_CLOSE_DT
            , io_tp.LU_VAL option_type_val
            , io_tp.LU_DESC option_type_desc
            , INCNTV_UNIT_TP_CD_ID
            , io_unit.LU_VAL option_incentive_unit_val
            , io_unit.LU_DESC option_incentive_unit_desc
            FROM
              INCENTIVE_OPTION bpm_io
            , LUV io_tp
            , LUV io_unit
            WHERE
            INCNTV_OPTN_TP_CD_ID = io_tp.lu_id and
            INCNTV_UNIT_TP_CD_ID = io_unit.lu_id
            """;

    private static final String selectNumberOfProgramIncentives = """
            SELECT COUNT('s') number_of_pio FROM biz_pgm_incentive_option WHERE INCNTV_OPTN_ID = ?
            """;

    private static final String deleteContractProgramIncentiveStatusByID = """
            DELETE FROM contract_pgm_incntv_sts cpis        
            WHERE BIZ_PGM_INCNTV_OPTN_ID = ?
            """;

    private final DataSource dataSource;
    private DataFieldMaxValueIncrementer programIncentiveOptionIDIncrementer;
    private static final String BIZ_PGM_INCNTV_OPTN_SEQ = "biz_pgm_incntv_optn_seq";

    public IncentiveOptionDAOJdbc (DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @PostConstruct
    private void initialize() {
        setDataSource(dataSource);
        programIncentiveOptionIDIncrementer = new OracleSequenceMaxValueIncrementer(dataSource, BIZ_PGM_INCNTV_OPTN_SEQ);
    }
    /**
     * Retrieve the Program Incentive Options for the given programID.
     *
     * @param programID
     * @return
     * @throws DataAccessException
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Override
    public Collection<ProgramIncentiveOption> getProgramIncentiveOptions(Integer programID)
            throws DataAccessException
    {
        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[] { programID };
        int types[] = new int[] { Types.INTEGER };

        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectProgramIncentiveOptions);
        lQuery.append(" ORDER BY SORT_ORDR, biz_pgm_incntv_optn_id");

        final ArrayList<ProgramIncentiveOption> lProgramIncentiveOptions = (ArrayList<ProgramIncentiveOption>)
                template.query(lQuery.toString(), params, types, new programIncentiveOptionMapper());

        return lProgramIncentiveOptions;
    }


        /**
     * Delete all the Program Incentive Options for the given Program ID.
     *
     * @param pProgramIncentiveOptionID
     * @return
     * @throws DataAccessException
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Override
    public int deleteProgramIncentiveOption(Integer pProgramIncentiveOptionID)
            throws DataAccessException, Exception
    {
        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[] { pProgramIncentiveOptionID };
        int types[] = new int[] { Types.INTEGER };

        int rowDeleted = template.update(deleteProgramIncentiveOption, params, types);

        return rowDeleted;
    }

    private static final class programIncentiveOptionMapper implements RowMapper
    {
        public Object mapRow(ResultSet rs, int rowNum) throws SQLException
        {
            ProgramIncentiveOption lProgramIncentiveOption = new ProgramIncentiveOption();
            IncentiveOption lIncentiveOption = new IncentiveOption();

            lProgramIncentiveOption.setIncentiveOption(lIncentiveOption);

            lIncentiveOption.setIncentiveOptionID(rs.getInt("INCNTV_OPTN_ID"));
            lIncentiveOption.setIncentiveOptionName(rs.getString("INCNTV_OPTN_NM"));
            lIncentiveOption.setIncentiveOptionDesc(rs.getString("INCNTV_OPTN_DESC"));
            lIncentiveOption.setIncentiveOptionURL(rs.getString("INCNTV_URL"));
            lIncentiveOption.setIncentiveOptionTypeCodeID(rs.getInt("INCNTV_OPTN_TP_CD_ID"));
            lIncentiveOption.setIncentiveOptionTypeCode(rs.getString("option_type_val"));
            lIncentiveOption.setIncentiveOptionTypeDesc(rs.getString("option_type_desc"));
            lIncentiveOption.setCreationDate(rs.getDate("INCNTV_OPTN_CREATION_DT"));
            lIncentiveOption.setCloseDate(rs.getDate("INCNTV_OPTN_CLOSE_DT"));

            lProgramIncentiveOption.setBusinessProgramID(rs.getInt("BIZ_PGM_ID"));
            lProgramIncentiveOption.setEffectiveDate(rs.getDate("INCNTV_OPTN_EFF_DT"));
            lProgramIncentiveOption.setEndDate(rs.getDate("INCNTV_OPTN_END_DT"));
            lProgramIncentiveOption.setActivationDate(rs.getDate("INCNTV_OPTN_ACTV_DT"));
            lProgramIncentiveOption.setDeliveryDate(rs.getDate("INCNTV_OPTN_DLVRY_DT"));
            lProgramIncentiveOption.setAdditionalInfo(rs.getString("INCNTV_OPTN_ADDL_INFO"));
            lProgramIncentiveOption.setIncentiveOptionInfo(rs.getString("INCNTV_OPTN_INFO"));
            lProgramIncentiveOption.setIncentiveOptionStatusCodeID(rs.getInt("STAT_CD_ID"));
            lProgramIncentiveOption.setIncentiveOptionStatusCode(rs.getString("option_stat_val"));
            lProgramIncentiveOption.setIncentiveOptionStatusCodeDesc(rs.getString("option_stat_desc"));
            lProgramIncentiveOption.setIncentiveFulfillmentRoutingCodeID(rs.getInt("FULFILLMENT_RTNG_TP_CD_ID"));
            lProgramIncentiveOption.setIncentiveFulfillmentCode(rs.getString("fulfill_type_val"));
            lProgramIncentiveOption.setIncentiveOptionStatusCodeDesc(rs.getString("fulfill_type_desc"));
            lProgramIncentiveOption.setIncentedStatusTypeCodeID(rs.getInt("INCNTD_STS_TP_CD_ID"));
            lProgramIncentiveOption.setIncentedStatusTypeCode(rs.getString("incented_status_type_val"));
            lProgramIncentiveOption.setIncentedStatusTypeDesc(rs.getString("incented_status_type_desc"));
            lProgramIncentiveOption.setParticipantCap(rs.getString("PARTICIP_CAP"));
            lProgramIncentiveOption.setFamilyCap(rs.getString("FAMILY_CAP"));
            lProgramIncentiveOption.setDeliveryInfo(rs.getString("DELIVERY_INFO"));
            //lProgramIncentiveOption.setUnitTypeDesc(rs.getString("unit_type_desc"));
            lProgramIncentiveOption.setEnrollmentDeadlineDate(rs.getDate("ENROLL_DEADLINE_DT"));
            lProgramIncentiveOption.setCompletionDeadlineDate(rs.getDate("COMPL_DEADLINE_DT"));

            lProgramIncentiveOption.setIncentiveRuleTypeCodeID(rs.getInt("INCNTV_RULE_TP_ID"));
            lProgramIncentiveOption.setIncentiveRuleTypeCode(rs.getString("INCNTV_RULE_TP_CODE"));
            lProgramIncentiveOption.setIncentiveReportNameCodeID(rs.getInt("incntv_rpt_desc_id"));
            lProgramIncentiveOption.setIncentiveReportNameCode(rs.getString("INCNTV_RPT_DESC_CODE"));

            lProgramIncentiveOption.setParticipationGroupID(rs.getInt("INCNTV_PART_GRP_ID"));
            lProgramIncentiveOption.setParticipationGroupName(rs.getString("INCNTV_PART_GRP_NM"));
            lProgramIncentiveOption.setParticipationGroupInfo(rs.getString("INCNTV_PART_GRP_INFO"));
            lProgramIncentiveOption.setIncentiveOptionRewardCardID(rs.getInt("INCNTV_OPTN_REWARD_CARD_ID"));
            lProgramIncentiveOption.setRunFrequencyID(rs.getInt("RUN_FREQ_ID"));

            if(rs.getInt("ACTV_CMPLTN_PRD") > 0)
            {
                lProgramIncentiveOption.setActivityCompletionPeriod(String.valueOf(rs.getInt("ACTV_CMPLTN_PRD")));
            }


            if (lProgramIncentiveOption.getIncentiveFulfillmentCode().equals(BPMAdminConstants.BPM_VAL_FLFLMNT_RTNG_TP_SND_TO_INTELISPEND)) {
                lProgramIncentiveOption.setFulfillRoutingTypeIntelispend(true);
            } else {
                lProgramIncentiveOption.setFulfillRoutingTypeIntelispend(false);
            }

            lProgramIncentiveOption.setProgramIncentiveOptionID(rs.getInt("BIZ_PGM_INCNTV_OPTN_ID"));
            lProgramIncentiveOption.setNewHireDate(rs.getDate("NEW_HIRE_DT"));
            lProgramIncentiveOption.setUnitTypeCodeID(rs.getInt("INCNTV_UNIT_TP_CD_ID"));
            lProgramIncentiveOption.setUnitTypeDesc(rs.getString("INCNTV_UNIT_TP_CD_DESC"));
            lProgramIncentiveOption.setPackageRuleGroupID(rs.getInt("INCNTV_OPTN_PKG_RULE_GRP_ID"));
            lProgramIncentiveOption.setPackageRuleGroupName(rs.getString("INCNTV_OPTN_PKG_RULE_GRP_NM"));
            lProgramIncentiveOption.setDeliveryInfoID(rs.getInt("DELIVERY_INFO_CD_ID"));
            lProgramIncentiveOption.setDeliveryInfoValue(rs.getString("DELIVERY_INFO_CD_DESC"));
            lProgramIncentiveOption.setSortOrder(rs.getInt("SORT_ORDR"));


            return lProgramIncentiveOption;
        }
    }

    /**
     * First checks to see if the Program Incentive Option exists. If not, calls Insert.
     * Otherwise updates.
     *
     * @param pProgramIncentiveOption
     * @param pUserID
     * @return
     * @throws DataAccessException
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Override
    public int updateProgramIncentiveOption(ProgramIncentiveOption pProgramIncentiveOption, String pUserID) throws DataAccessException {
        ArrayList<ProgramIncentiveOption> lProgramIncentiveOptions = (ArrayList<ProgramIncentiveOption>)
                getProgramIncentiveOption(pProgramIncentiveOption.getBusinessProgramID(), pProgramIncentiveOption.getIncentiveOption().getIncentiveOptionID());

        // The Program Incentive Option for this programID - Incentive ID doesn't exist.
        // Call insert.
        if (lProgramIncentiveOptions == null || lProgramIncentiveOptions.size() < 1) {
            return insertProgramIncentiveOption(pProgramIncentiveOption, pUserID);
        }

        Integer paticipantCap = null;
        Integer familyCap = null;

        if (pProgramIncentiveOption.getParticipantCap() != null && pProgramIncentiveOption.getParticipantCap().length() > 0) {
            paticipantCap = Integer.valueOf(pProgramIncentiveOption.getParticipantCap().trim());
        }
        if (pProgramIncentiveOption.getFamilyCap() != null && pProgramIncentiveOption.getFamilyCap().length() > 0) {
            familyCap = Integer.valueOf(pProgramIncentiveOption.getFamilyCap().trim());
        }

        // Otherwise, the Program Incentive Option exists, update it.
        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{
                pProgramIncentiveOption.getAdditionalInfo(),
                pProgramIncentiveOption.getIncentiveOptionInfo()
                , pProgramIncentiveOption.getIncentiveOptionStatusCodeID()
                , pProgramIncentiveOption.getEffectiveDate()
                , pProgramIncentiveOption.getEndDate()
                , pProgramIncentiveOption.getActivationDate()
                , pProgramIncentiveOption.getDeliveryDate()
                , pUserID
                , pProgramIncentiveOption.getIncentiveFulfillmentRoutingCodeID()
                , pProgramIncentiveOption.getIncentedStatusTypeCodeID()
                , paticipantCap
                , familyCap
                , pProgramIncentiveOption.getDeliveryInfo()
                , pProgramIncentiveOption.getEnrollmentDeadlineDate()
                , pProgramIncentiveOption.getCompletionDeadlineDate()
                , pProgramIncentiveOption.getIncentiveRuleTypeCodeID()
                , pProgramIncentiveOption.getIncentiveReportNameCodeID()
                , pProgramIncentiveOption.getParticipationGroupID()
                , pProgramIncentiveOption.getIncentiveOptionRewardCardID()
                , pProgramIncentiveOption.getRunFrequencyID()
                , (pProgramIncentiveOption.getActivityCompletionPeriod() != null && pProgramIncentiveOption.getActivityCompletionPeriod().length() > 0)
                ? Integer.parseInt(pProgramIncentiveOption.getActivityCompletionPeriod())
                : null
                , pProgramIncentiveOption.getNewHireDate()
                , pProgramIncentiveOption.getUnitTypeCodeID()
                , pProgramIncentiveOption.getPackageRuleGroupID()
                , pProgramIncentiveOption.getDeliveryInfoID()
                , pProgramIncentiveOption.getSortOrder()
                , pProgramIncentiveOption.getBusinessProgramID()
                , pProgramIncentiveOption.getIncentiveOption().getIncentiveOptionID()
        };

        int types[] = new int[]{
                Types.VARCHAR, Types.VARCHAR,
                Types.INTEGER,
                Types.DATE, Types.DATE, Types.DATE, Types.DATE,
                Types.VARCHAR
                , Types.INTEGER, Types.INTEGER  // getIncentiveFulfillmentRoutingCodeID,  getIncentedStatusTypeCodeID
                , Types.INTEGER, Types.INTEGER, Types.VARCHAR  // paticipantCap, familyCap, getDeliveryInfo
                , Types.DATE, Types.DATE
                , Types.INTEGER, Types.INTEGER, Types.INTEGER
                , Types.INTEGER, Types.INTEGER, Types.INTEGER
                , Types.DATE
                , Types.INTEGER
                , Types.INTEGER  // getPackageRuleGroupID
                , Types.INTEGER  // deliveryInfoID
                , Types.INTEGER
                , Types.INTEGER
                , Types.INTEGER  //Sort Order
        };

        int rowInserted = template.update(updateProgramIncentiveOption, params, types);

        return rowInserted;
    }

    /**
     * Retrieve the one Program Incentive Option for the given programID and Incentive ID.
     *
     * @param programID
     * @param pIncentiveOptionID
     * @return
     * @throws DataAccessException
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Override
    public Collection<ProgramIncentiveOption> getProgramIncentiveOption(Integer programID, Integer pIncentiveOptionID)
            throws DataAccessException {
        JdbcTemplate template = getJdbcTemplate();

        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectProgramIncentiveOptions);
        lQuery.append(" AND bpm_bio.INCNTV_OPTN_ID = ? ");

        Object params[] = new Object[]{programID, pIncentiveOptionID};
        int types[] = new int[]{Types.INTEGER, Types.INTEGER};

        final ArrayList<ProgramIncentiveOption> lProgramIncentiveOptions = (ArrayList<ProgramIncentiveOption>)
                template.query(lQuery.toString(), params, types, new programIncentiveOptionMapper());

        return lProgramIncentiveOptions;
    }

    @Override
    public int insertProgramIncentiveOption(ProgramIncentiveOption pProgramIncentiveOption, String pUserID)
            throws DataAccessException {
        Integer paticipantCap = null;
        Integer familyCap = null;
        Integer activityCompletionPeriod = null;

        Integer lProgramIncentiveOptionID = programIncentiveOptionIDIncrementer.nextIntValue();

        if (pProgramIncentiveOption.getParticipantCap() != null && pProgramIncentiveOption.getParticipantCap().length() > 0) {
            paticipantCap = Integer.valueOf(pProgramIncentiveOption.getParticipantCap());
        }
        if (pProgramIncentiveOption.getFamilyCap() != null && pProgramIncentiveOption.getFamilyCap().length() > 0) {
            familyCap = Integer.valueOf(pProgramIncentiveOption.getFamilyCap());
        }
        if (pProgramIncentiveOption.getActivityCompletionPeriod() != null && pProgramIncentiveOption.getActivityCompletionPeriod().length() > 0) {
            activityCompletionPeriod = Integer.valueOf(pProgramIncentiveOption.getActivityCompletionPeriod());
        }

        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{pProgramIncentiveOption.getBusinessProgramID()
                , pProgramIncentiveOption.getIncentiveOption().getIncentiveOptionID()
                , pProgramIncentiveOption.getAdditionalInfo(), pProgramIncentiveOption.getIncentiveOptionInfo()
                , pProgramIncentiveOption.getIncentiveOptionStatusCodeID()
                , pProgramIncentiveOption.getEffectiveDate()
                , pProgramIncentiveOption.getEndDate()
                , pProgramIncentiveOption.getActivationDate()
                , pProgramIncentiveOption.getDeliveryDate()
                , pUserID
                , pProgramIncentiveOption.getIncentiveFulfillmentRoutingCodeID()
                , pProgramIncentiveOption.getIncentedStatusTypeCodeID()
                , paticipantCap
                , familyCap
                , pProgramIncentiveOption.getDeliveryInfo()
                , pProgramIncentiveOption.getEnrollmentDeadlineDate()
                , pProgramIncentiveOption.getCompletionDeadlineDate()
                , pProgramIncentiveOption.getIncentiveRuleTypeCodeID()
                , pProgramIncentiveOption.getIncentiveReportNameCodeID()
                , pProgramIncentiveOption.getParticipationGroupID()
                , pProgramIncentiveOption.getIncentiveOptionRewardCardID()
                , pProgramIncentiveOption.getRunFrequencyID()
                , activityCompletionPeriod
                , lProgramIncentiveOptionID
                , pProgramIncentiveOption.getNewHireDate()
                , pProgramIncentiveOption.getUnitTypeCodeID()
                , pProgramIncentiveOption.getPackageRuleGroupID()
                , pProgramIncentiveOption.getDeliveryInfoID()
                , pProgramIncentiveOption.getSortOrder()
        };
        int types[] = new int[]{Types.INTEGER, Types.INTEGER,
                Types.VARCHAR, Types.VARCHAR,
                Types.INTEGER,
                Types.DATE, Types.DATE, Types.DATE, Types.DATE,
                Types.VARCHAR,
                Types.INTEGER,
                Types.INTEGER,
                Types.INTEGER,
                Types.INTEGER,
                Types.VARCHAR,
                Types.DATE,
                Types.DATE,
                Types.INTEGER,
                Types.INTEGER,
                Types.INTEGER,
                Types.INTEGER,
                Types.INTEGER,
                Types.INTEGER,
                Types.INTEGER,
                Types.DATE,
                Types.INTEGER,
                Types.INTEGER,
                Types.INTEGER,
                Types.INTEGER
        };

        int rowInserted = template.update(insertProgramIncentiveOption, params, types);

        return rowInserted;
    }

    @Override
    public Collection<IncentiveOption> getIncentiveOptions() throws DataAccessException {
        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{};
        int types[] = new int[]{};

        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectIncentiveOptions);

        final ArrayList<IncentiveOption> lIncentiveOptions = (ArrayList<IncentiveOption>) template.query(lQuery.toString(), params, types, new incentiveOptionMapper());

        // For each Incentive Option, find out if there are any Business Programs that have this
        // Incentive Option.
        for (int i = 0; i < lIncentiveOptions.size(); i++) {
            ArrayList<Integer> lNumberOfPrograms = (ArrayList<Integer>) selectNumberOfProgramIncentives(lIncentiveOptions.get(i).getIncentiveOptionID());
            if (lNumberOfPrograms.size() > 0) {
                if (lNumberOfPrograms.get(0).intValue() > 0) {
                    lIncentiveOptions.get(i).setHasProgram(true);
                } else {
                    lIncentiveOptions.get(i).setHasProgram(false);
                }
            }
        }

        return lIncentiveOptions;
    }

    /**
     * Get number of Business Program Incentive Options for the given Incentive Option.
     *
     * @param pIncentiveOptionID
     * @return
     */
    @Override
    public Collection<Integer> selectNumberOfProgramIncentives(Integer pIncentiveOptionID) {
        final ArrayList<Integer> lNumberOfMembers = new ArrayList<Integer>();
        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{pIncentiveOptionID};
        int types[] = new int[]{Types.INTEGER};

        template.query(selectNumberOfProgramIncentives, params, types, new RowCallbackHandler() {
            public void processRow(ResultSet rs) throws SQLException {
                Integer lMemberCount = Integer.valueOf(rs.getInt("number_of_pio"));

                lNumberOfMembers.add(lMemberCount);
            }
        });

        return lNumberOfMembers;
    }

    private static final class incentiveOptionMapper implements RowMapper {
        public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
            IncentiveOption lIncentiveOption = new IncentiveOption();

            lIncentiveOption.setIncentiveOptionID(rs.getInt("INCNTV_OPTN_ID"));
            lIncentiveOption.setIncentiveOptionName(rs.getString("INCNTV_OPTN_NM"));
            lIncentiveOption.setIncentiveOptionDesc(rs.getString("INCNTV_OPTN_DESC"));
            lIncentiveOption.setIncentiveOptionURL(rs.getString("INCNTV_URL"));
            lIncentiveOption.setIncentiveOptionTypeCodeID(rs.getInt("INCNTV_OPTN_TP_CD_ID"));
            lIncentiveOption.setIncentiveOptionTypeCode(rs.getString("option_type_val"));
            lIncentiveOption.setIncentiveOptionTypeDesc(rs.getString("option_type_desc"));
            lIncentiveOption.setIncentiveOptionUnitCodeID(rs.getInt("INCNTV_UNIT_TP_CD_ID"));
            lIncentiveOption.setIncentiveOptionUnitCode(rs.getString("option_incentive_unit_val"));
            lIncentiveOption.setIncentiveOptionUnitDesc(rs.getString("option_incentive_unit_desc"));
            lIncentiveOption.setCreationDate(rs.getDate("INCNTV_OPTN_CREATION_DT"));
            lIncentiveOption.setCloseDate(rs.getDate("INCNTV_OPTN_CLOSE_DT"));

            return lIncentiveOption;
        }
    }

    @Override
    public Collection<IncentiveOption> getActiveIncentiveOptions() throws DataAccessException {
        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{};
        int types[] = new int[]{};

        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectIncentiveOptions);
        lQuery.append(" and\n" +
                "bpm_io.incntv_optn_close_dt = to_date('01019999', 'MMDDYYYY')");
        lQuery.append("order by bpm_io.incntv_optn_close_dt asc, bpm_io.incntv_optn_nm asc");

        final ArrayList<IncentiveOption> lIncentiveOptions = (ArrayList<IncentiveOption>)
                template.query(lQuery.toString(), params, types, new incentiveOptionMapper());

        // For each Incentive Option, find out if there are any Business Programs that have this
        // Incentive Option.
        for (int i = 0; i < lIncentiveOptions.size(); i++) {
            ArrayList<Integer> lNumberOfPrograms = (ArrayList<Integer>)
                    selectNumberOfProgramIncentives(lIncentiveOptions.get(i).getIncentiveOptionID());
            if (lNumberOfPrograms.size() > 0) {
                if (lNumberOfPrograms.get(0).intValue() > 0) {
                    lIncentiveOptions.get(i).setHasProgram(true);
                } else {
                    lIncentiveOptions.get(i).setHasProgram(false);
                }
            }
        }

        return lIncentiveOptions;
    }

    @Override
    public int deleteContractProgramIncentiveStatusByID(Integer pProgramIncentiveOptionID) {
        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{pProgramIncentiveOptionID};
        int types[] = new int[]{Types.INTEGER};

        int rowDeleted = template.update(deleteContractProgramIncentiveStatusByID, params, types);

        return rowDeleted;
    }
}
