package com.healthpartners.app.bpm.controller;

import com.healthpartners.app.bpm.common.BPMAdminConstants;
import com.healthpartners.app.bpm.common.BPMAdminUtils;
import com.healthpartners.app.bpm.common.BPMPagination;
import com.healthpartners.app.bpm.dto.*;
import com.healthpartners.app.bpm.exception.BPMException;
import com.healthpartners.app.bpm.form.PersonContractRecycleSearchForm;
import com.healthpartners.app.bpm.form.PersonEmployerActivityRecycleSearchForm;
import com.healthpartners.app.bpm.iface.BusinessProgramService;
import com.healthpartners.app.bpm.iface.MemberService;
import com.healthpartners.service.bpm.common.BPMConstants;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import java.text.ParseException;
import java.util.ArrayList;

@Controller
public class PersonEmployerActivityRecycleSearchController extends BaseController implements Validator {

    private final BusinessProgramService businessProgramService;
    private final MemberService memberService;
    public PersonEmployerActivityRecycleSearchController(BusinessProgramService businessProgramService, MemberService memberService) {
        this.businessProgramService = businessProgramService;
        this.memberService = memberService;
    }

    @GetMapping("/showPersonEmployerActivityRecycleSearch")
    public String load(ModelMap modelMap) throws BPMException {
        PersonEmployerActivityRecycleSearchForm form = new PersonEmployerActivityRecycleSearchForm();
        modelMap.put("personEmployerActivityRecycleSearchForm", form);

        try {
            form.setActionType(ACTION_SEARCH);
            loadInitial(modelMap);

        } catch (Exception e) {
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
            modelMap.put("errorMsg", getStackTrace(e));
        }

        return "personEmployerActivityRecycleSearch";
    }

    @PostMapping(value = "/personEmployerActivityRecycleSearch", params = "next")
    public String submitNext(@ModelAttribute("personEmployerActivityRecycleSearchForm") PersonEmployerActivityRecycleSearchForm form, ModelMap modelMap, HttpServletRequest request) throws Exception {
        return performPaginationAction(form, modelMap, request);
    }

    @PostMapping(value = "/personEmployerActivityRecycleSearch", params = "back")
    public String submitBack(@ModelAttribute("personEmployerActivityRecycleSearchForm") PersonEmployerActivityRecycleSearchForm form, ModelMap modelMap, HttpServletRequest request) throws Exception {
        return performPaginationAction(form, modelMap, request);
    }

    @PostMapping("/personEmployerActivityRecycleSearch")
    public String submit(@ModelAttribute("personEmployerActivityRecycleSearchForm") PersonEmployerActivityRecycleSearchForm form, ModelMap modelMap, BindingResult result, HttpServletRequest request) throws Exception {
        try {
            populateSelects(modelMap);
            if (ACTION_SEARCH.equals(form.getActionType())) {
                validate(form, result);
                if (!result.hasErrors()) {
                    search(modelMap,form);
                }
            }
        } catch (Exception e) {
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
            // Add error stack trace on the request, to be hidden in html.
            modelMap.put("errorMsg", getStackTrace(e));
        }

        return "personEmployerActivityRecycleSearch";
    }

    @GetMapping("/personEmployerActivityRecycleSearch")
    public String loadSearchFromBackButtonAction(@ModelAttribute("personEmployerActivityRecycleSearchForm") PersonEmployerActivityRecycleSearchForm form, ModelMap modelMap, BindingResult result) throws Exception {
        try {
            getUserSession().reset();
            EmployerActivityRecycleSearchCriteria activityRecycleSearchCriteria = getUserSession().getEmployerActivityRecycleSearchCriteria();
            form.setActionType(ACTION_SEARCH);
            form.setActivityName(activityRecycleSearchCriteria.getActivityName());
            form.setFirstName(activityRecycleSearchCriteria.getFirstName());
            form.setLastName(activityRecycleSearchCriteria.getLastName());
            form.setActivityDate(activityRecycleSearchCriteria.getActivityDate());
            form.setRecycleStatusId(activityRecycleSearchCriteria.getRecycleStatusID());
            form.setRecycleStatusDate(activityRecycleSearchCriteria.getRecycleStatusDateString());

            populateSelects(modelMap);

            search(modelMap, form);

        } catch (Exception e) {
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
            // Add error stack trace on the request, to be hidden in html.
            modelMap.put("errorMsg", getStackTrace(e));
        }
        return "personEmployerActivityRecycleSearch";
    }

    private void loadInitial(ModelMap modelMap) throws BPMException {
        getUserSession().reset();

        populateSelects(modelMap);

        BPMPagination pagination = new BPMPagination();
        pagination.setBackPageFlag(BPMAdminConstants.BPM_ADMIN_PAGINATION_END);
        pagination.setNextPageFlag(BPMAdminConstants.BPM_ADMIN_PAGINATION_END);
        modelMap.put("backPageFlag", pagination.getBackPageFlag());
        modelMap.put("nextPageFlag", pagination.getNextPageFlag());
    }

    private void populateSelects(ModelMap modelMap) throws BPMException {
        if (CollectionUtils.isEmpty(getUserSession().getRecycleStatusCodes())) {
            ArrayList<LookUpValueCode> lLuvRecycleStatusCodes = (ArrayList<LookUpValueCode>) memberService.getLUVCodesByGroup(BPMConstants.BPM_TYPE_EMPL_RECYCLE_STATUS);
            getUserSession().setRecycleStatusCodes(lLuvRecycleStatusCodes);
        }
        if (CollectionUtils.isEmpty(getUserSession().getActivitySponsoredCodes())){
            ArrayList<Activity> lActivitySponsoredCodes = (ArrayList<Activity>)memberService.getEmployerAdminsterdActivities();
            getUserSession().setActivitySponsoredCodes(lActivitySponsoredCodes);
        }
        modelMap.put("recycleStatusCodes", getUserSession().getRecycleStatusCodes());
        modelMap.put("activitySponsoredCodes", getUserSession().getActivitySponsoredCodes());
    }
    private void search(ModelMap modelMap, PersonEmployerActivityRecycleSearchForm form) throws BPMException, ParseException {
        boolean newDTOList = false;
        ArrayList<LookUpValueCode> lLuvRecycleStatusCodes = getUserSession().getRecycleStatusCodes();
        ArrayList<Activity> lActivitySponsoredCodes = getUserSession().getActivitySponsoredCodes();
        String actionType = form.getActionType();

        ArrayList<RejectedPerson> lPersonEmployerActivitiesRecycle = null;

        String lActivityId  = form.getActivityId();
        String lActivityDateString  = form.getActivityDate();
        String lFirstName  = form.getFirstName();
        String lLastName  = form.getLastName();
        String lRecycleStatusId  = form.getRecycleStatusId();
        String lRecycleStatusDateString  = form.getRecycleStatusDate();

        EmployerActivityRecycleSearchCriteria searchCriteria = new EmployerActivityRecycleSearchCriteria();
        searchCriteria.setActivityName(form.getActivityName());
        searchCriteria.setActivityDate(lActivityDateString);
        searchCriteria.setFirstName(lFirstName);
        searchCriteria.setLastName(lLastName);
        searchCriteria.setRecycleStatusID(lRecycleStatusId);
        searchCriteria.setRecycleStatusDateString(lRecycleStatusDateString);
        getUserSession().setEmployerActivityRecycleSearchCriteria(searchCriteria);

        java.util.Date lActivityDate = null;
        java.sql.Date lActivitySearchDate = null;
        java.util.Date lRecycleStatusDate = null;
        java.sql.Date lRecycleStatusSearchDate = null;


        if(lActivityDateString!= null && lActivityDateString.length() > 0)
        {
            lActivityDate = getFmt().parse(lActivityDateString);
            lActivitySearchDate = new java.sql.Date(lActivityDate.getTime());
        }
        if(lRecycleStatusDateString!= null && lRecycleStatusDateString.length() > 0)
        {
            lRecycleStatusDate = getFmt().parse(lRecycleStatusDateString);
            lRecycleStatusSearchDate = new java.sql.Date(lRecycleStatusDate.getTime());
        }
        Integer lRecycleStatusIdInt = 0;
        if (lRecycleStatusId != null && BPMAdminUtils.isValueInteger(lRecycleStatusId)) {
            lRecycleStatusIdInt = Integer.valueOf(lRecycleStatusId);
        }

        Integer lActivityIdInt = 0;
        if (lActivityId != null && BPMAdminUtils.isValueInteger(lActivityId)) {
            lActivityIdInt = Integer.valueOf(lActivityId);
        }

        lPersonEmployerActivitiesRecycle = getUserSession().getPersonEmployerActivitiesRecycle();

        if (lPersonEmployerActivitiesRecycle == null || actionType.equals(ACTION_SEARCH)) {
            lPersonEmployerActivitiesRecycle = (ArrayList<RejectedPerson>)businessProgramService.getEmployerRecycle(lActivityIdInt, lFirstName, lLastName, lActivitySearchDate, lRecycleStatusSearchDate, lRecycleStatusIdInt);
            getUserSession().setPersonEmployerActivitiesRecycle(lPersonEmployerActivitiesRecycle);
            newDTOList=true;
        }

        if(lPersonEmployerActivitiesRecycle.size() < 1)
        {
            createNoResultsFoundMessageOnModel(modelMap);
        }

        setPersonEmployerActivityRecyclePagination(modelMap, getUserSession(), form.getActionType(), newDTOList);

    }
    @Override
    public boolean supports(Class<?> clazz) {
        return false;
    }

    @Override
    public void validate(Object target, Errors errors) {
        PersonEmployerActivityRecycleSearchForm form = (PersonEmployerActivityRecycleSearchForm) target;

        if (form.getRecycleStatusId().equals("select")) {
                form.setRecycleStatusId("");
            }

            getValidationSupport().validateNotNull("recycleStatusId", form.getRecycleStatusId(), errors, new Object[]{"Recycle Status"});

            if (form.getRecycleStatusDate().length() > 0) {
                getValidationSupport().validateNotDate("recycleStatusDate", form.getRecycleStatusDate(), errors, new Object[]{"Recycle Status Date "});
            }

            if (form.getActivityId().equals("select")) {
                form.setActivityId("");
            }


    }
    private String performPaginationAction(PersonEmployerActivityRecycleSearchForm form, ModelMap modelMap, HttpServletRequest request) throws BPMException, ParseException {
        setPersonEmployerActivityRecyclePagination(modelMap, getUserSession(), form.getActionType(), false);
        populateSelects(modelMap);

        EmployerActivityRecycleSearchCriteria recycleSearchCriteria = getUserSession().getEmployerActivityRecycleSearchCriteria();
        getUserSession().setRecycleStatusDate(getUserSession().getRecycleStatusDate());
        getUserSession().setRecycleStatusId(Integer.valueOf(recycleSearchCriteria.getRecycleStatusID()));
        getUserSession().setLastName(recycleSearchCriteria.getLastName());
        getUserSession().setFirstName(recycleSearchCriteria.getFirstName());
        getUserSession().setActivityDate(BPMAdminUtils.convertStringToSqlDate(recycleSearchCriteria.getActivityDate(), "MM/dd/yyyy"));
        getUserSession().setActivitySponsoredCodes(getUserSession().getActivitySponsoredCodes());
        getUserSession().setRecycleStatusCodes(getUserSession().getRecycleStatusCodes());
        getUserSession().setPersonEmployerActivitiesRecycle(getUserSession().getPersonEmployerActivitiesRecycle());
        getUserSession().setPersonEmployerActivityRecycleSearchForm(form);
        return "personEmployerActivityRecycleSearch";
    }
}
