package com.healthpartners.app.bpm.dto;

public class ControlGroupIOFileDirSetup {

    private Integer controlGroupIOID;
    private String groupNo;
    private String groupName;
    private String inputFileLocPreprocess;
    private String inputFileLocProcessed;

    private String fileNamePrefix1;
    private String fileNamePrefix2;
    private String processedOutputFilePathLoc1;
    private String processedOutputFilePathLoc2;

    private Integer routingTypeID;


    public ControlGroupIOFileDirSetup() {
        super();
    }


    public Integer getControlGroupIOID() {
        return controlGroupIOID;
    }


    public void setControlGroupIOID(Integer controlGroupIOID) {
        this.controlGroupIOID = controlGroupIOID;
    }


    public String getGroupNo() {
        return groupNo;
    }


    public void setGroupNo(String groupNo) {
        this.groupNo = groupNo;
    }


    public String getGroupName() {
        return groupName;
    }


    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }


    public String getInputFileLocPreprocess() {
        return inputFileLocPreprocess;
    }


    public void setInputFileLocPreprocess(String inputFileLocPreprocess) {
        this.inputFileLocPreprocess = inputFileLocPreprocess;
    }


    public String getInputFileLocProcessed() {
        return inputFileLocProcessed;
    }


    public void setInputFileLocProcessed(String inputFileLocProcessed) {
        this.inputFileLocProcessed = inputFileLocProcessed;
    }


    public String getFileNamePrefix1() {
        return fileNamePrefix1;
    }


    public void setFileNamePrefix1(String fileNamePrefix1) {
        this.fileNamePrefix1 = fileNamePrefix1;
    }


    public String getFileNamePrefix2() {
        return fileNamePrefix2;
    }


    public void setFileNamePrefix2(String fileNamePrefix2) {
        this.fileNamePrefix2 = fileNamePrefix2;
    }


    public String getProcessedOutputFilePathLoc1() {
        return processedOutputFilePathLoc1;
    }


    public void setProcessedOutputFilePathLoc1(String processedOutputFilePathLoc1) {
        this.processedOutputFilePathLoc1 = processedOutputFilePathLoc1;
    }


    public String getProcessedOutputFilePathLoc2() {
        return processedOutputFilePathLoc2;
    }


    public void setProcessedOutputFilePathLoc2(String processedOutputFilePathLoc2) {
        this.processedOutputFilePathLoc2 = processedOutputFilePathLoc2;
    }


    public Integer getRoutingTypeID() {
        return routingTypeID;
    }


    public void setRoutingTypeID(Integer routingTypeID) {
        this.routingTypeID = routingTypeID;
    }


}
