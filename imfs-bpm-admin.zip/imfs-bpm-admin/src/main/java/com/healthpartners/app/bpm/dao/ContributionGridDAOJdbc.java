/* $Id: ContributionGridDAOJdbc.java 207938 2013-06-07 17:49:24Z tjquist $ */

package com.healthpartners.app.bpm.dao;

import com.healthpartners.app.bpm.dto.ContributionGridBenefitContractTypeRelationship;
import com.healthpartners.app.bpm.dto.ProgramContributionGrid;
import com.healthpartners.app.bpm.exception.BPMException;
import jakarta.annotation.PostConstruct;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Collection;

@Repository
@Transactional(timeout = 300, rollbackFor = {DataAccessException.class, BPMException.class})
public class ContributionGridDAOJdbc extends JdbcDaoSupport implements ContributionGridDAO {

    // @formatter:off
    private static final String selectProgramContributionGrids =
            "select t.contrib_grid_id,\n" +
                    "t.biz_pgm_incntv_optn_id,\n" +
                    "t.ben_contr_tp_lu_id,\n" +
                    "(select l.lu_desc from luv l where l.lu_id = t.ben_contr_tp_lu_id) ben_con_typ_desc,\n" +
                    "(select p.rlshp_txt from pes_rel_ds p where p.rlshp_cd = t.rel_cd) rel_desc,\n" +
                    "t.rel_cd,\n" +
                    "t.contrib_amt\n" +
                    ", bpio.incntv_optn_id\n" +
                    "from  program_contrib_grid t\n" +
                    ", biz_pgm_incentive_option bpio\n" +
                    "where t.biz_pgm_incntv_optn_id = ? \n" +
                    "and t.biz_pgm_incntv_optn_id = bpio.biz_pgm_incntv_optn_id  ";
    private static final String determineParentRelationshipToIncentedTables =
            "SELECT DISTINCT isadc.contrib_grid_id \n" +
                    "FROM \n" +
                    "   pgm_mem_incntv_status t,\n" +
                    "   incntv_sts_actv_dtl isad,\n" +
                    "   incntv_sts_actv_dtl_contrib isadc \n" +
                    "WHERE\n" +
                    "   t.pgm_mem_incntv_stat_id = isad.pgm_mem_inctv_stat_id and\n" +
                    "   isad.inctv_sts_actv_dtl_id = isadc.inctv_sts_actv_dtl_id and\n" +
                    "   t.biz_pgm_incntv_optn_id = ? and\n" +
                    "   isadc.contrib_grid_id = ?\n" +
                    "UNION\n" +
                    "SELECT DISTINCT isadc.contrib_grid_id\n" +
                    "FROM \n" +
                    "   contract_pgm_incntv_sts t,\n" +
                    "   incntv_sts_actv_dtl isad,\n" +
                    "   incntv_sts_actv_dtl_contrib isadc \n" +
                    "WHERE\n" +
                    "   t.cntr_pgm_stat_id = isad.cntr_pgm_stat_id and\n" +
                    "   isad.inctv_sts_actv_dtl_id = isadc.inctv_sts_actv_dtl_id and\n" +
                    "   t.biz_pgm_incntv_optn_id = ? and\n" +
                    "   isadc.contrib_grid_id = ? ";

    private static final String insertProgramContributionGrid =
            "insert into program_contrib_grid t\n" +
                    "\n" +
                    "   (t.contrib_grid_id,\n" +
                    "   t.biz_pgm_incntv_optn_id,\n" +
                    "   t.ben_contr_tp_lu_id,\n" +
                    "   t.rel_cd,\n" +
                    "   t.contrib_amt,\n" +
                    "   insert_usr,\n" +
                    "   insert_ts)\n" +
                    "values (contrib_grid_id_seq.nextval,\n" +
                    "   ?,\n" +
                    "   ?,\n" +
                    "   ?,\n" +
                    "   ?,\n" +
                    "   ?,\n" +
                    "   SYSDATE)";

    private static final String updateProgramContributionGrid =
            "UPDATE program_contrib_grid t\n" +
                    "SET  t.ben_contr_tp_lu_id = ?,\n" +
                    "   t.rel_cd = ?,\n" +
                    "   t.contrib_amt = ?,\n" +
                    "   MODIFY_TS = SYSDATE, \n" +
                    "   MODIFY_USR = ?  \n" +
                    "WHERE t.contrib_grid_id = ?";

    // @formatter:on

    private static final String selectContributionGridBenefitContractTypeRelationships =
        """
        select t.ben_con_type_rel_id,
            t.ben_con_type_id,
            t.rlshp_cd,
            pr.rlshp_txt,
            t.eff_dt,
            t.end_dt
        from BENEFIT_CONTRACT_TYPE_REL t,
            pes_rel_ds pr
        where pr.rlshp_cd = t.rlshp_cd and
            sysdate between t.eff_dt and t.end_dt and
           t.ben_con_type_id = ?
        """;

    private static final String deleteProgramContributionGridByUID =
            """
            delete program_contrib_grid t where t.contrib_grid_id = ?
            """;

    private static final String deleteProgramContributionGrids =
            """
            delete program_contrib_grid t where t.BIZ_PGM_INCNTV_OPTN_ID = ? 
            """;

    private final DataSource dataSource;


    public ContributionGridDAOJdbc (DataSource dataSource) {
        this.dataSource = dataSource;
    }


    @PostConstruct
    private void initialize() {
        setDataSource(dataSource);
    }

    @Override
    public ArrayList<ProgramContributionGrid> getProgramContributionGrids(Integer programIncentiveOptionID) throws DataAccessException {
        final ArrayList<ProgramContributionGrid> results = new ArrayList<ProgramContributionGrid>();

        JdbcTemplate template = getJdbcTemplate();
        Object[] params = new Object[]{programIncentiveOptionID};
        int[] types = new int[]{Types.INTEGER};
        template.query(selectProgramContributionGrids, params, types, new RowCallbackHandler() {
            Integer rowIDCtr = 1;

            public void processRow(ResultSet rs) throws SQLException {
                ProgramContributionGrid lProgramContributionGrid = new ProgramContributionGrid();

                lProgramContributionGrid.setContributionGridID(rs.getInt("contrib_grid_id"));
                lProgramContributionGrid.setProgramIncentiveOptionID(rs.getInt("biz_pgm_incntv_optn_id"));
                lProgramContributionGrid.setBenefitContractTypeID(rs.getInt("ben_contr_tp_lu_id"));
                lProgramContributionGrid.setBenefitContractTypeDesc(rs.getString("ben_con_typ_desc"));
                lProgramContributionGrid.setRelationshipCodeID(rs.getInt("rel_cd"));
                lProgramContributionGrid.setRelationshipCode(rs.getString("rel_desc"));
                lProgramContributionGrid.setContributionAmount(rs.getInt("contrib_amt"));
                lProgramContributionGrid.setIncentiveOptionID(rs.getInt("INCNTV_OPTN_ID"));
                lProgramContributionGrid.setRowID(rowIDCtr++);

                results.add(lProgramContributionGrid);
            }
        });

        // Determine if program contribution id has a foreign key relationship to
        // tier_contribution table. If so, then
        // set flag to not allow a delete of the record.
        if (results.size() > 0) {
            for (ProgramContributionGrid lProgramContributionGrid : results) {
                boolean isUsed = determineParentRelationshipToIncentedTables(lProgramContributionGrid.getProgramIncentiveOptionID(), lProgramContributionGrid.getContributionGridID());
                lProgramContributionGrid.setUsed(isUsed);
            }
        }

        return results;
    }

    /*
     * Determine if program contribution id has a foreign key relationship to
     * contract or member incented tables. If so,
     * then set flag to not allow "remove" link to appear with the assigned
     * Benefit Contract Types.
     */
    private boolean determineParentRelationshipToIncentedTables(Integer programIncentiveOptionID, Integer programContributionGridID) throws DataAccessException {

        final ArrayList<Integer> results = new ArrayList<Integer>();
        JdbcTemplate template = getJdbcTemplate();

        StringBuffer lQuery = new StringBuffer();
        lQuery.append(determineParentRelationshipToIncentedTables);

        ArrayList<Object> lParameters = new ArrayList<Object>();
        ArrayList<Integer> lTypes = new ArrayList<Integer>();

        lParameters.add(programIncentiveOptionID);
        lTypes.add(Integer.valueOf(Types.INTEGER));
        lParameters.add(programContributionGridID);
        lTypes.add(Integer.valueOf(Types.INTEGER));

        lParameters.add(programIncentiveOptionID);
        lTypes.add(Integer.valueOf(Types.INTEGER));
        lParameters.add(programContributionGridID);
        lTypes.add(Integer.valueOf(Types.INTEGER));

        // Convert the parameter arraylists to arrays.
        Object[] params = new Object[lParameters.size()];
        lParameters.toArray(params);

        int[] types = new int[lTypes.size()];

        for (int j = 0; j < lTypes.size(); j++) {
            types[j] = lTypes.get(j).intValue();
        }

        template.query(lQuery.toString(), params, types, new RowCallbackHandler() {
            public void processRow(ResultSet rs) throws SQLException {
                results.add(rs.getInt("contrib_grid_id"));
            }
        });

        boolean parentChildRelationship = results.size() > 0;

        return parentChildRelationship;
    }

    @Override
    public int updateProgramContributionGrid(ProgramContributionGrid pProgramContributionGrid, String pModifyUserID) throws BPMException, DataAccessException {
        JdbcTemplate template = getJdbcTemplate();
        int rowInserted = 0;

        if (pProgramContributionGrid.getContributionGridID() == null) {
            rowInserted = this.insertProgramContributionGrid(pProgramContributionGrid,
                    pModifyUserID);
        } else {
            Object params[] = new Object[] {
                    pProgramContributionGrid.getBenefitContractTypeID(),
                    pProgramContributionGrid.getRelationshipCodeID(),
                    pProgramContributionGrid.getContributionAmount(),
                    pModifyUserID,
                    pProgramContributionGrid.getContributionGridID() };

            int types[] = new int[] { Types.VARCHAR, Types.VARCHAR,
                    Types.VARCHAR, Types.VARCHAR, Types.INTEGER };

            rowInserted = template
                    .update(updateProgramContributionGrid, params, types);
        }

        return rowInserted;
    }

    @Override
    public Collection<ContributionGridBenefitContractTypeRelationship> getContributionGridBenefitContractTypeRelationships(Integer benefitContractTypeID) throws DataAccessException {
        final ArrayList<ContributionGridBenefitContractTypeRelationship> lContributionGridBenefitContractTypeRelationships = new ArrayList<ContributionGridBenefitContractTypeRelationship>();

        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[] {benefitContractTypeID};
        int types[] = new int[] {Types.INTEGER};
        template.query(selectContributionGridBenefitContractTypeRelationships, params, types,
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        ContributionGridBenefitContractTypeRelationship lContributionGridBenefitContractTypeRelationship = new ContributionGridBenefitContractTypeRelationship();
                        lContributionGridBenefitContractTypeRelationship.setUid(rs.getInt("ben_con_type_rel_id"));
                        lContributionGridBenefitContractTypeRelationship.setBenefitContractTypeID(rs.getInt("ben_con_type_id"));
                        lContributionGridBenefitContractTypeRelationship.setRelationshipCode(rs.getInt("rlshp_cd"));
                        lContributionGridBenefitContractTypeRelationship.setRelationshipDesc(rs.getString("rlshp_txt"));
                        lContributionGridBenefitContractTypeRelationship.setEffectiveDate(rs.getDate("eff_dt"));
                        lContributionGridBenefitContractTypeRelationship.setEndDate(rs.getDate("end_dt"));

                        lContributionGridBenefitContractTypeRelationships.add(lContributionGridBenefitContractTypeRelationship);
                    }
                });

        return lContributionGridBenefitContractTypeRelationships;
    }

    @Override
    public int deleteProgramContributionGridByUID(Integer lGridContributionID) throws BPMException, DataAccessException {
        JdbcTemplate template = getJdbcTemplate();
        int rowInserted = 0;

        Object params[] = new Object[] { lGridContributionID };

        int types[] = new int[] { Types.INTEGER };

        rowInserted = template.update(deleteProgramContributionGridByUID, params, types);

        return rowInserted;
    }

    @Override
    public int deleteProgramContributionGrids(Integer lProgramIncentiveOptionID) throws BPMException, DataAccessException {
        JdbcTemplate template = getJdbcTemplate();
        int rowInserted = 0;
        Object params[] = new Object[] {lProgramIncentiveOptionID };
        int types[] = new int[] { Types.INTEGER };

        rowInserted = template.update(deleteProgramContributionGrids, params, types);

        return rowInserted;
    }

    /*
     *
     * @param pContributionGrid
     *
     * @param pModifyUserID
     *
     * @return
     *
     * @throws BPMException, DataAccessException
     */

    private int insertProgramContributionGrid(ProgramContributionGrid pProgramContributionGrid, String pInsertUserID) throws BPMException, DataAccessException {
        JdbcTemplate template = getJdbcTemplate();

        Object params[] = new Object[] { pProgramContributionGrid.getProgramIncentiveOptionID(),
                pProgramContributionGrid.getBenefitContractTypeID(),
                pProgramContributionGrid.getRelationshipCodeID(),
                pProgramContributionGrid.getContributionAmount(),
                pInsertUserID };

        int types[] = new int[] { Types.INTEGER, Types.INTEGER, Types.INTEGER,
                Types.INTEGER, Types.VARCHAR };

        int rowInserted = template.update(insertProgramContributionGrid, params, types);

        return rowInserted;
    }
}
