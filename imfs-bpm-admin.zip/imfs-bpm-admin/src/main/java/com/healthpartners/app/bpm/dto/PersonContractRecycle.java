package com.healthpartners.app.bpm.dto;

import com.healthpartners.service.bpm.dto.BaseDTO;

import java.sql.Date;

/**
 * @author tjquist
 */
public class PersonContractRecycle extends BaseDTO {

    static final long serialVersionUID = 0L;

    private Integer rowNumber;
    private Integer recycleId;
    private Integer contractNumber;
    private Integer personNumber;
    private String memberId;
    private String groupNumber;
    private Integer programId;
    private String programName;
    private Integer contractStatusPrevId;
    private Integer contractStatusCurrentId;
    private String contractStatusPrev;
    private String contractStatusCurrent;
    private String recycleStatus;
    private Integer recycleStatusId;
    private Date insertDate;
    private Date modifyDate;
    private Date recycleStatDate;
    private Date programEffDate;
    private String reasonDesc;
    private String approverUserId;
    private String insertUser;
    private String modifyUser;

    public Integer getContractNumber() {
        return contractNumber;
    }

    public void setContractNumber(Integer contractNumber) {
        this.contractNumber = contractNumber;
    }

    public Integer getPersonNumber() {
        return personNumber;
    }

    public void setPersonNumber(Integer personNumber) {
        this.personNumber = personNumber;
    }

    public Integer getProgramId() {
        return programId;
    }

    public void setProgramId(Integer programId) {
        this.programId = programId;
    }

    public String getRecycleStatus() {
        return recycleStatus;
    }

    public void setRecycleStatus(String recycleStatus) {
        this.recycleStatus = recycleStatus;
    }

    public Date getInsertDate() {
        return insertDate;
    }

    public void setInsertDate(Date insertDate) {
        this.insertDate = insertDate;
    }

    public Date getModifyDate() {
        return modifyDate;
    }

    public void setModifyDate(Date modifyDate) {
        this.modifyDate = modifyDate;
    }

    public Date getRecycleStatDate() {
        return recycleStatDate;
    }

    public void setRecycleStatDate(Date recycleStatDate) {
        this.recycleStatDate = recycleStatDate;
    }

    public String getReasonDesc() {
        return reasonDesc;
    }

    public void setReasonDesc(String reasonDesc) {
        this.reasonDesc = reasonDesc;
    }

    public String getApproverUserId() {
        return approverUserId;
    }

    public void setApproverUserId(String approverUserId) {
        this.approverUserId = approverUserId;
    }

    public String getInsertUser() {
        return insertUser;
    }

    public void setInsertUser(String insertUser) {
        this.insertUser = insertUser;
    }

    public String getModifyUser() {
        return modifyUser;
    }

    public void setModifyUser(String modifyUser) {
        this.modifyUser = modifyUser;
    }

    public Integer getRecycleStatusId() {
        return recycleStatusId;
    }

    public void setRecycleStatusId(Integer recycleStatusId) {
        this.recycleStatusId = recycleStatusId;
    }

    public Integer getRecycleId() {
        return recycleId;
    }

    public void setRecycleId(Integer recycleId) {
        this.recycleId = recycleId;
    }

    public Integer getContractStatusPrevId() {
        return contractStatusPrevId;
    }

    public void setContractStatusPrevId(Integer contractStatusPrevId) {
        this.contractStatusPrevId = contractStatusPrevId;
    }

    public Integer getContractStatusCurrentId() {
        return contractStatusCurrentId;
    }

    public void setContractStatusCurrentId(Integer contractStatusCurrentId) {
        this.contractStatusCurrentId = contractStatusCurrentId;
    }

    public String getContractStatusPrev() {
        return contractStatusPrev;
    }

    public void setContractStatusPrev(String contractStatusPrev) {
        this.contractStatusPrev = contractStatusPrev;
    }

    public String getContractStatusCurrent() {
        return contractStatusCurrent;
    }

    public void setContractStatusCurrent(String contractStatusCurrent) {
        this.contractStatusCurrent = contractStatusCurrent;
    }

    public String getProgramName() {
        return programName;
    }

    public void setProgramName(String programName) {
        this.programName = programName;
    }

    public Date getProgramEffDate() {
        return programEffDate;
    }

    public void setProgramEffDate(Date programEffDate) {
        this.programEffDate = programEffDate;
    }

    public String getMemberId() {
        return memberId;
    }

    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }

    public String getGroupNumber() {
        return groupNumber;
    }

    public void setGroupNumber(String groupNumber) {
        this.groupNumber = groupNumber;
    }

    public Integer getRowNumber() {
        return rowNumber;
    }

    public void setRowNumber(Integer rowNumber) {
        this.rowNumber = rowNumber;
    }


}
