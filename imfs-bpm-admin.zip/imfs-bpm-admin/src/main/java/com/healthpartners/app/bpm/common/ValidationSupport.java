package com.healthpartners.app.bpm.common;

import org.apache.commons.lang.StringUtils;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;
import org.springframework.validation.Errors;

import java.text.SimpleDateFormat;
import java.util.Locale;

@Component
public class ValidationSupport {

    private static final String REQUIRED = "required";
    private final MessageSource messageSource;

    public ValidationSupport(MessageSource messageSource) {
        this.messageSource = messageSource;
    }

    public void addValidationFailureMessage(String fieldName, Errors errors, String messageCode, Object[] messages) {
        String errorMessage = messageSource.getMessage(messageCode, messages, Locale.getDefault());
        errors.rejectValue(fieldName, REQUIRED, errorMessage);
    }

    public boolean validateRequiredFieldIsNotEmpty(String fieldName, Object fieldValue, Errors errors, Object[] messages) {
        boolean isValid = true;
        if (ObjectUtils.isEmpty(fieldValue)) {
            isValid = false;
            String errorMessage = messageSource.getMessage("errors.required", messages, Locale.getDefault());
            errors.rejectValue(fieldName, REQUIRED, errorMessage);
        }
        return isValid;
    }

    public boolean validateRequiredFieldIsNotEmptyOrZero(String fieldName, Object fieldValue, Errors errors, Object[] messages) {
        boolean isValid = true;
        if (ObjectUtils.isEmpty(fieldValue) || "0".equals(fieldValue)) {
            isValid = false;
            String errorMessage = messageSource.getMessage("errors.required", messages, Locale.getDefault());
            errors.rejectValue(fieldName, REQUIRED, errorMessage);
        }
        return isValid;
    }

    public boolean validateOneRequiredFieldIsSelected(String fieldName, Object fieldValue, Errors errors, Object[] messages) {
        boolean isValid = true;
        if (ObjectUtils.isEmpty(fieldValue)) {
            isValid = false;
            String errorMessage = messageSource.getMessage("errors.noselect", messages, Locale.getDefault());
            errors.rejectValue(fieldName, REQUIRED, errorMessage);
        }
        return isValid;
    }

    public boolean validateNotSpecialChar(String fieldName, String fieldValue, Errors errors, Object[] messages) {
        boolean isValid = true;
        if (StringUtils.isNotEmpty(fieldValue)) {
            if (fieldValue.contains("'")) {
                isValid = false;
                String errorMessage = messageSource.getMessage("errors.specialchar", messages, Locale.getDefault());
                errors.rejectValue(fieldName, REQUIRED, errorMessage);
            }
        }
        return isValid;
    }

    public boolean validateDateFormat(String fieldName, String fieldValue, Errors errors, Object[] messages) {
        boolean isValid = true;
        if (StringUtils.isNotEmpty(fieldValue)) {
            try {
                SimpleDateFormat fmt = new SimpleDateFormat(BPMAdminConstants.HP_BPM_ADMIN_UI_COMMON_DATE_FORMAT);
                java.util.Date lGroupStartDate = fmt.parse(fieldValue.trim());
                isValid = BPMAdminUtils.isDateValid(fieldValue.trim());
            } catch (Exception ne) {
                isValid = false;
            }
        }
            else {
                isValid = false;
            }
        if(!isValid){
            String errorMessage = messageSource.getMessage("errors.date", messages, Locale.getDefault());
            errors.rejectValue(fieldName, REQUIRED, errorMessage);
        }
        return isValid;
    }

    public boolean validateNotInteger(String fieldName, String fieldValue, Errors errors, Object[] messages) {
        boolean isValid = true;
        if (StringUtils.isNotEmpty(fieldValue)) {
            try {
                Integer integerValue = Integer.valueOf(fieldValue.trim());
            } catch (NumberFormatException ne) {
                isValid = false;
                String errorMessage = messageSource.getMessage("errors.integer", messages, Locale.getDefault());
                errors.rejectValue(fieldName, REQUIRED, errorMessage);
            }
        }
        return isValid;
    }

    public boolean validateNotZero(String fieldName, String fieldValue, Errors errors, Object[] messages) {
        boolean result = true;
        if (fieldValue != null && !fieldValue.equalsIgnoreCase("null")) {
            if (fieldValue.equalsIgnoreCase("")) {
                fieldValue = "0";
            }
            try {
                if (Integer.parseInt(fieldValue) <= 0) {
                    result = false;
                    String errorMessage = messageSource.getMessage("errors.required", messages, Locale.getDefault());
                    errors.rejectValue(fieldName, REQUIRED, errorMessage);
                }
            } catch (NumberFormatException e) {
                System.out.println("BaseForm: NumberFormatException error: check for double");
                if (Double.parseDouble(fieldValue) <= 0) {
                    result = false;
                    String errorMessage = messageSource.getMessage("errors.required", messages, Locale.getDefault());
                    errors.rejectValue(fieldName, REQUIRED, errorMessage);
                }
            }
        }
        return result;
    }

    public boolean validateOnlyNumericsInDate(String fieldName, String fieldValue, Errors errors, Object[] messages) {
        if (fieldValue == null) {
            return false;
        }

        char c;
        boolean validDate = true;
        for (int i = 0; i < fieldValue.length(); i++) {
            c = fieldValue.charAt(i);
            if (Character.isDigit(c)) {

            } else if (c != '/') {
                validDate = false;
                break;
            }
        }
        if (!validDate) {
            String errorMessage = messageSource.getMessage("errors.nonnumeric", messages, Locale.getDefault());
            errors.rejectValue(fieldName, REQUIRED, errorMessage);
        }
        return validDate;
    }

    public boolean validateOnlyNumericForInteger(String fieldName, String fieldValue, Errors errors, Object[] messages) {
        boolean result = true;

        try {
            Integer integerValue = Integer.valueOf(fieldValue.trim());
        } catch (NumberFormatException ne) {
            String errorMessage = messageSource.getMessage("errors.integer", messages, Locale.getDefault());
            errors.rejectValue(fieldName, REQUIRED, errorMessage);
            result = false;
        }

        return result;
    }

    public boolean validateNotNull(String fieldName,
                                      String fieldValue,  Errors errors, Object[] messages) {
        boolean result = true;
        if (fieldValue == null  || fieldValue.equalsIgnoreCase("null") || fieldValue.trim().length() <= 0) {
            String errorMessage = messageSource.getMessage("errors.required", messages, Locale.getDefault());
            errors.rejectValue(fieldName, REQUIRED, errorMessage);
            result = false;
        }
        return result;
    }

    public boolean validateAfter(String fieldName, String fieldValue, String referenceDate, Errors errors, Object[] messages) {
        boolean validDate = false;
        try {
            SimpleDateFormat fmt = new SimpleDateFormat(BPMAdminConstants.HP_BPM_ADMIN_UI_COMMON_DATE_FORMAT);
            java.util.Date lActivityStatusDate = fmt.parse(fieldValue.trim());
            java.util.Date lReferenceDate = fmt.parse(referenceDate.trim());
            if (lActivityStatusDate.after(lReferenceDate) || lActivityStatusDate.equals(lReferenceDate)) {
                validDate = true;
            } else {
                validDate = false;
            }
        } catch (Exception ne) {
            String errorMessage = messageSource.getMessage("errors.afterthisdate", messages, Locale.getDefault());
            errors.rejectValue(fieldName, REQUIRED, errorMessage);
            validDate = false;
        }

        if (!validDate) {
            String errorMessage = messageSource.getMessage("errors.afterthisdate", messages, Locale.getDefault());
            errors.rejectValue(fieldName, REQUIRED, errorMessage);
        }
        return validDate;
    }

    public boolean validateBeforeOrEqual(String fieldName, String fieldValue, String referenceDate, String referenceDateName, Errors errors, Object[] messages) {
        boolean validDate = false;
        try {
            SimpleDateFormat fmt = new SimpleDateFormat(BPMAdminConstants.HP_BPM_ADMIN_UI_COMMON_DATE_FORMAT);
            java.util.Date lActivityStatusDate = fmt.parse(fieldValue.trim());
            java.util.Date lReferenceDate = fmt.parse(referenceDate.trim());
            if (lActivityStatusDate.before(lReferenceDate) || lActivityStatusDate.equals(lReferenceDate)) {
                validDate = true;
            } else {
                validDate = false;
            }
        } catch (Exception ne) {
            validDate = false;
            String errorMessage = messageSource.getMessage("errors.beforethisdate", messages, Locale.getDefault());
            errors.rejectValue(referenceDateName, REQUIRED, errorMessage);
        }

        if (!validDate) {
            String errorMessage = messageSource.getMessage("errors.beforethisdate", messages, Locale.getDefault());
            errors.rejectValue(referenceDateName, REQUIRED, errorMessage);
        }
        return validDate;
    }

    public boolean validateBeforeOnly(String fieldName,
                                      String fieldValue, String referenceDate, String referenceDateName,Errors errors, Object[] messages)
    {
        boolean validDate = false;
        try
        {
            SimpleDateFormat fmt = new SimpleDateFormat(
                    BPMAdminConstants.HP_BPM_ADMIN_UI_COMMON_DATE_FORMAT);
            java.util.Date lActivityStatusDate = null;
            java.util.Date lReferenceDate = null;
            if(!fieldValue.isEmpty()){
              lActivityStatusDate =  fmt.parse(fieldValue.trim());
            }
            if(fieldValue.isEmpty()) {
               String errorMessage = messageSource.getMessage("errors.required", messages, Locale.getDefault());
               errors.rejectValue(referenceDateName, REQUIRED, errorMessage);

            }
            if(referenceDate.isEmpty()) {
                String errorMessage = messageSource.getMessage("errors.required", messages, Locale.getDefault());
                errors.rejectValue(referenceDateName, REQUIRED, errorMessage);

            }

            if(!referenceDate.isEmpty()){
               lReferenceDate = fmt.parse(referenceDate.trim());
            }
            if(!fieldValue.isEmpty() && !referenceDate.isEmpty()) {
                    if (lActivityStatusDate.before(lReferenceDate)) {
                        validDate = true;
                    } else {
                        validDate = false;
                    }
                }
        } catch (Exception ne) {

            validDate = false;
            String errorMessage = messageSource.getMessage("errors.beforethisdateNotEqual", messages, Locale.getDefault());
            errors.rejectValue(referenceDateName, REQUIRED, errorMessage);
        }

        if (!validDate) {
            String errorMessage = messageSource.getMessage("errors.beforethisdateNotEqual", messages, Locale.getDefault());
            errors.rejectValue(referenceDateName, REQUIRED, errorMessage);
        }
        return validDate;

    }


    public boolean validateNotOutsideDateRange(String fieldName, String fieldValue, String startDate, String endDate, Errors errors, Object[] messages) {
        boolean validDate = true;

        try {
            SimpleDateFormat fmt = new SimpleDateFormat(BPMAdminConstants.HP_BPM_ADMIN_UI_COMMON_DATE_FORMAT);
            java.util.Date lFieldValueDate = fmt.parse(fieldValue.trim());
            java.util.Date lStartDate = fmt.parse(startDate.trim());
            java.util.Date lEndDate = fmt.parse(endDate.trim());
            if (lFieldValueDate.before(lStartDate) || lFieldValueDate.after(lEndDate)) {
                validDate = false;
            }
        } catch (Exception ne) {
            String errorMessage = messageSource.getMessage("errors.date", messages, Locale.getDefault());
            errors.rejectValue(fieldName, REQUIRED, errorMessage);
            validDate = false;
            ne.printStackTrace();
        }

        if (!validDate) {
            String errorMessage = messageSource.getMessage("errors.outsideDateRange", messages, Locale.getDefault());
            errors.rejectValue(fieldName, REQUIRED, errorMessage);
        }
        return validDate;
    }

    public boolean validateProgramDateChangeNotAllowedIfMembersExist(String fieldName, String beforeDate, String afterDate, String numberOfMembers, Errors errors, Object[] messages) {
        boolean dateChangeNotAllowed = false;

        try {
            SimpleDateFormat fmt = new SimpleDateFormat(BPMAdminConstants.HP_BPM_ADMIN_UI_COMMON_DATE_FORMAT);

            //Allow date change when before date null.  Usually the result of a copy performed off of another business program.
            //In this case, there is no before date to compare against when detecting a date change.
            if (beforeDate == null) {
                return dateChangeNotAllowed;
            }

            java.util.Date lBeforeDate = fmt.parse(beforeDate.trim());
            java.util.Date lAfterDate = fmt.parse(afterDate.trim());

            //if participants exist and date change detected, do not allow the program date change.
            if (Integer.parseInt(numberOfMembers) > 0) {
                if (!lBeforeDate.equals(lAfterDate)) {
                    dateChangeNotAllowed = true;
                }
            }
        } catch (Exception ne) {
            String errorMessage = messageSource.getMessage("errors.participantsenrolled", messages, Locale.getDefault());
            errors.rejectValue(fieldName, REQUIRED, errorMessage);

        }

        //if date change
        if (dateChangeNotAllowed) {
            String errorMessage = messageSource.getMessage("errors.participantsenrolled", messages, Locale.getDefault());
            errors.rejectValue(fieldName, REQUIRED, errorMessage);
        }
        return dateChangeNotAllowed;
    }

    public boolean validateNotSelected(String fieldName, String fieldValue, Errors errors, Object[] messages) {
        boolean result = true;

        if (fieldValue.isEmpty() || fieldValue.equals("0")) {
            String errorMessage = messageSource.getMessage("errors.notselected", messages, Locale.getDefault());
            errors.rejectValue(fieldName, REQUIRED, errorMessage);
            result = false;
        }
        return result;
    }

    public boolean validateAtleastOneSelection(String fieldName,
                                               String fieldValues, Errors errors, Object[] messages) {
        boolean result = true;
        if (fieldValues == null || fieldValues.isEmpty()) {
            String errorMessage = messageSource.getMessage("errors.noselect", messages, Locale.getDefault());
            errors.rejectValue(fieldName, REQUIRED, errorMessage);
            result = false;
        }
        return result;
    }

    public boolean validateBothNotNull(String fieldElement, String fieldValue, String fieldValue2, String message, Errors errors) {
        boolean result = true;
        if (fieldValue == null || fieldValue.trim().length() <= 0) {
            if(fieldValue2 == null || fieldValue2.trim().length() <= 0) {
                String errorMessage = messageSource.getMessage("errors.required", new Object[]{message}, Locale.getDefault());
                errors.rejectValue(fieldElement, REQUIRED, errorMessage);
                result = false;
            }
        }
        return result;
    }

    public boolean validateNotDate(java.lang.String fieldElement,
                                   java.lang.String fieldValue, Errors errors, Object[] messages) {
        boolean result = true;

        if (validateNotNull(fieldElement, fieldValue, errors, messages)) {
            try {
                SimpleDateFormat fmt = new SimpleDateFormat(
                        BPMAdminConstants.HP_BPM_ADMIN_UI_COMMON_DATE_FORMAT);
                java.util.Date lParsedDateDate = fmt.parse(fieldValue.trim());
                // If was successfully parsed. So check the day and month ranges.
                result = BPMAdminUtils.isDateValid(fieldValue.trim());

            } catch (Exception ne)
            {
                result = false;
            }
        } else {
            result = false;
        }

        if(result == false)
        {
            if (fieldValue.isEmpty()) {
                fieldValue = "Empty string";
            }

            String errorMessage = messageSource.getMessage("errors.date", messages, Locale.getDefault());
            errors.rejectValue(fieldElement, REQUIRED, errorMessage);
        }
        return result;
    }


}
