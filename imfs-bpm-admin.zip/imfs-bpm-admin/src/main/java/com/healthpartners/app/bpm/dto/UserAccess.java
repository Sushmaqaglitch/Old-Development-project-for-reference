package com.healthpartners.app.bpm.dto;

import java.io.Serializable;
import java.util.Collection;

public class UserAccess implements Serializable
{	
	static final long serialVersionUID = 0L;

    public UserAccess()
    {
    	super();
    }

    private String userName;
    private String userFullName;
	
    Collection<LookUpValueCode> userEnvironments;

	public Collection<LookUpValueCode> getUserEnvironments() {
		return userEnvironments;
	}

	public void setUserEnvironments(Collection<LookUpValueCode> userEnvironments) {
		this.userEnvironments = userEnvironments;
	}

	public String getUserFullName() {
		return userFullName;
	}

	public void setUserFullName(String userFullName) {
		this.userFullName = userFullName;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}
	
    
}
