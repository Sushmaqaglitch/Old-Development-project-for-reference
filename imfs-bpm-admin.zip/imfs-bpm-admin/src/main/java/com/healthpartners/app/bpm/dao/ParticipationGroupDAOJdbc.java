package com.healthpartners.app.bpm.dao;

import com.healthpartners.app.bpm.dto.ParticipationGroup;
import com.healthpartners.app.bpm.dto.ParticipationGroupDetail;
import com.healthpartners.app.bpm.dto.ParticipationGroupRequirement;
import com.healthpartners.app.bpm.exception.BPMException;
import jakarta.annotation.PostConstruct;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * 
 * @author jxbourbour
 * 
 */
@Repository
@Transactional(timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
public class ParticipationGroupDAOJdbc extends JdbcDaoSupport implements ParticipationGroupDAO {
	// @formatter:off
	private static final String selectParticipationGroups =
		"SELECT INCNTV_PART_GRP_ID, INCNTV_PART_GRP_NM, INCNTV_PART_GRP_INFO, INCNTV_PART_GRP_DESC, EFF_DT, END_DT,\n" +
				"CASE WHEN EXISTS (SELECT pgc.INCNTV_PART_GRP_ID FROM program_checkmark pgc WHERE pgc.INCNTV_PART_GRP_ID = ipg.INCNTV_PART_GRP_ID) THEN 'Y'\n" +
				"ELSE 'N' END as used_flg\n" +
				"FROM incntv_participation_grp ipg order by INCNTV_PART_GRP_NM asc ";

	private static final String selectParticipationGroupRequirement = """
					SELECT INCNTV_PART_REQ_ID, INCNTV_PART_GRP_ID
					FROM incntv_participation_grp_req
					WHERE INCNTV_PART_GRP_ID = ?
			""";
	private static final String selectParticipationGroupDetail = """
				SELECT INCNTV_PART_GRP_DTL_ID, INCNTV_PART_REQ_ID, INCNTV_PART_GRP_ID,
				INCNTV_PART_CD_ID
				, (SELECT lu_desc FROM luv WHERE lu_id=INCNTV_PART_CD_ID) INCNTV_PART_CD
				, SRCE_CD	       
				FROM
				  incntv_participation_grp_dtl
				WHERE
				  INCNTV_PART_GRP_ID = ? AND INCNTV_PART_REQ_ID = ?
			""";
	// @formatter:on

	private final DataSource dataSource;


	public ParticipationGroupDAOJdbc(DataSource dataSource) {
		this.dataSource = dataSource;
	}

	@PostConstruct
	private void initialize() {
		setDataSource(dataSource);
	}


	/**
	 * Retrieve a list of all the participation group definitions.
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Override
	public Collection<ParticipationGroup> getParticipationGroups() throws BPMException, DataAccessException {
		final ArrayList<ParticipationGroup> lParticipationGroupList = new ArrayList<ParticipationGroup>();

		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[] {};
		int types[] = new int[] {};

		template.query(selectParticipationGroups, params, types, new RowCallbackHandler() {
			public void processRow(ResultSet rs) throws SQLException {
				ParticipationGroup lParticipationGroup = new ParticipationGroup();

				lParticipationGroup.setParticipationGroupID(rs.getInt("INCNTV_PART_GRP_ID"));
				lParticipationGroup.setParticipationGroupName(rs.getString("INCNTV_PART_GRP_NM"));
				lParticipationGroup.setParticipationGroupInfo(rs.getString("INCNTV_PART_GRP_INFO"));
				lParticipationGroup.setParticipationGroupDesc(rs.getString("INCNTV_PART_GRP_DESC"));
				lParticipationGroup.setEffectiveDate(rs.getDate("EFF_DT"));
				lParticipationGroup.setEndDate(rs.getDate("END_DT"));
				lParticipationGroup.setUsed("Y".equals(rs.getString("used_flg")));

				lParticipationGroupList.add(lParticipationGroup);
			}
		});

		return lParticipationGroupList;
	}

	/**
	 *
	 * @param lParticipationGroupID
	 * @return
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	@Override
	public List<ParticipationGroupRequirement> getParticipationGroupRequirements(Integer lParticipationGroupID)
			throws BPMException, DataAccessException {
		final ArrayList<ParticipationGroupRequirement> lParticipationGroupRequirements = new ArrayList<ParticipationGroupRequirement>();

		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[]{lParticipationGroupID};
		int types[] = new int[]{Types.INTEGER};

		template.query(selectParticipationGroupRequirement, params, types, new RowCallbackHandler() {
			public void processRow(ResultSet rs) throws SQLException {
				ParticipationGroupRequirement lParticipationGroupRequirement = new ParticipationGroupRequirement();
				lParticipationGroupRequirement.setParticipationGroupID(rs.getInt("INCNTV_PART_GRP_ID"));
				lParticipationGroupRequirement.setParticipationGroupRequirementID(rs.getInt("INCNTV_PART_REQ_ID"));

				lParticipationGroupRequirements.add(lParticipationGroupRequirement);
			}
		});

		// Now for each ParticipationGroupRequirement, retrieve the Details.
		for (ParticipationGroupRequirement requirement : lParticipationGroupRequirements) {
			ArrayList<ParticipationGroupDetail> participationGroupDetails = getParticipationGroupDetails(requirement);
			requirement.setParticipationGroupDetails(participationGroupDetails);
		}

		return lParticipationGroupRequirements;
	}

	/**
	 *
	 * @param requirement
	 * @return
	 * @throws BPMException
	 * @throws DataAccessException
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Override
	public ArrayList<ParticipationGroupDetail> getParticipationGroupDetails(ParticipationGroupRequirement requirement) throws BPMException, DataAccessException {
		final ArrayList<ParticipationGroupDetail> lParticipationGroupDetailList = new ArrayList<ParticipationGroupDetail>();

		JdbcTemplate template = getJdbcTemplate();
		Object params[] = new Object[]{requirement.getParticipationGroupID(),
				requirement.getParticipationGroupRequirementID()};
		int types[] = new int[]{Types.INTEGER, Types.INTEGER};

		template.query(selectParticipationGroupDetail, params, types, new RowCallbackHandler() {
			public void processRow(ResultSet rs) throws SQLException {
				ParticipationGroupDetail lParticipationGroupDetail = new ParticipationGroupDetail();
				lParticipationGroupDetail.setParticipationGroupID(rs.getInt("INCNTV_PART_GRP_ID"));
				lParticipationGroupDetail.setParticipationGroupDetailID(rs.getInt("INCNTV_PART_GRP_DTL_ID"));
				lParticipationGroupDetail.setParticipationGroupRequirementID(rs.getInt("INCNTV_PART_REQ_ID"));
				lParticipationGroupDetail.setParticipationCodeID(rs.getInt("INCNTV_PART_CD_ID"));
				lParticipationGroupDetail.setParticipationGroupDetailCode(rs.getString("INCNTV_PART_CD"));
				lParticipationGroupDetail.setSourceCode(rs.getString("SRCE_CD"));

				lParticipationGroupDetailList.add(lParticipationGroupDetail);
			}
		});

		return lParticipationGroupDetailList;
	}

}
