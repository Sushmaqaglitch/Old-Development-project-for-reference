package com.healthpartners.app.bpm.dto;

import com.healthpartners.service.bpm.dto.BaseDTO;

import java.sql.Date;

/**
 * @author tjquist
 */
public class CDHPFulfillmentTrackingRecycle extends BaseDTO {

    static final long serialVersionUID = 0L;

    private Integer cdhpRecycleId;
    private Integer programId;
    private String groupNumber;
    private Integer personDemographicsID;
    private String memberNumber;
    private Integer contractNumber;
    private String recycleStatus;
    private Integer recycleStatusId;
    private Integer activityId;
    private Integer activityName;
    private Date activityStatusIncentiveDate;
    private String packageSubTypeName;
    private Date recycleStatDate;
    private String reasonDesc;
    private String reasonTollgateRule;
    private String programName;
    private Date programEffDate;
    private String approverUserId;

    private Date insertDate;
    private Date modifyDate;
    private String insertUser;
    private String modifyUser;

    private int rowNumber;

    public Integer getCdhpRecycleId() {
        return cdhpRecycleId;
    }

    public void setCdhpRecycleId(Integer cdhpRecycleId) {
        this.cdhpRecycleId = cdhpRecycleId;
    }

    public Integer getProgramId() {
        return programId;
    }

    public void setProgramId(Integer programId) {
        this.programId = programId;
    }


    public String getGroupNumber() {
        return groupNumber;
    }

    public void setGroupNumber(String groupNumber) {
        this.groupNumber = groupNumber;
    }

    public Integer getPersonDemographicsID() {
        return personDemographicsID;
    }

    public void setPersonDemographicsID(Integer personDemographicsID) {
        this.personDemographicsID = personDemographicsID;
    }


    public String getMemberNumber() {
        return memberNumber;
    }

    public void setMemberNumber(String memberNumber) {
        this.memberNumber = memberNumber;
    }

    public Integer getContractNumber() {
        return contractNumber;
    }

    public void setContractNumber(Integer contractNumber) {
        this.contractNumber = contractNumber;
    }

    public String getRecycleStatus() {
        return recycleStatus;
    }

    public void setRecycleStatus(String recycleStatus) {
        this.recycleStatus = recycleStatus;
    }

    public Integer getRecycleStatusId() {
        return recycleStatusId;
    }

    public void setRecycleStatusId(Integer recycleStatusId) {
        this.recycleStatusId = recycleStatusId;
    }

    public Integer getActivityId() {
        return activityId;
    }

    public void setActivityId(Integer activityId) {
        this.activityId = activityId;
    }

    public Integer getActivityName() {
        return activityName;
    }

    public void setActivityName(Integer activityName) {
        this.activityName = activityName;
    }

    public Date getActivityStatusIncentiveDate() {
        return activityStatusIncentiveDate;
    }

    public void setActivityStatusIncentiveDate(Date activityStatusIncentiveDate) {
        this.activityStatusIncentiveDate = activityStatusIncentiveDate;
    }

    public String getPackageSubTypeName() {
        return packageSubTypeName;
    }

    public void setPackageSubTypeName(String packageSubTypeName) {
        this.packageSubTypeName = packageSubTypeName;
    }

    public Date getRecycleStatDate() {
        return recycleStatDate;
    }

    public void setRecycleStatDate(Date recycleStatDate) {
        this.recycleStatDate = recycleStatDate;
    }

    public String getReasonDesc() {
        return reasonDesc;
    }

    public void setReasonDesc(String reasonDesc) {
        this.reasonDesc = reasonDesc;
    }

    public String getReasonTollgateRule() {
        return reasonTollgateRule;
    }

    public void setReasonTollgateRule(String reasonTollgateRule) {
        this.reasonTollgateRule = reasonTollgateRule;
    }


    public String getProgramName() {
        return programName;
    }

    public void setProgramName(String programName) {
        this.programName = programName;
    }


    public Date getProgramEffDate() {
        return programEffDate;
    }

    public void setProgramEffDate(Date programEffDate) {
        this.programEffDate = programEffDate;
    }

    public String getApproverUserId() {
        return approverUserId;
    }

    public void setApproverUserId(String approverUserId) {
        this.approverUserId = approverUserId;
    }

    public Date getInsertDate() {
        return insertDate;
    }

    public void setInsertDate(Date insertDate) {
        this.insertDate = insertDate;
    }

    public Date getModifyDate() {
        return modifyDate;
    }

    public void setModifyDate(Date modifyDate) {
        this.modifyDate = modifyDate;
    }

    public String getInsertUser() {
        return insertUser;
    }

    public void setInsertUser(String insertUser) {
        this.insertUser = insertUser;
    }

    public String getModifyUser() {
        return modifyUser;
    }

    public void setModifyUser(String modifyUser) {
        this.modifyUser = modifyUser;
    }

    public int getRowNumber() {
        return rowNumber;
    }

    public void setRowNumber(int rowNumber) {
        this.rowNumber = rowNumber;
    }


}
