
package com.healthpartners.app.bpm.dao;

import com.healthpartners.app.bpm.exception.BPMException;
import jakarta.annotation.PostConstruct;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.sql.DataSource;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Collection;



/**
 * @author mxthoutam
 *
 */
@Service
@Transactional(timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
public class ActivityEventLogDAOJdbc extends JdbcDaoSupport implements
		ActivityEventLogDAO {
	
	private String selectCountActivityEventLog = """
			select count('s') to_be_processed_count from activity_event_log where prcsng_stat_val = ?
			""";

	private static final String updateFilteredActivities = """
	UPDATE ACTIVITY_EVENT_LOG actvlog SET actvlog.PRCSNG_STAT_VAL = 'PENDING' WHERE 1 = 1 
  """;
	private final DataSource dataSource;


	public ActivityEventLogDAOJdbc(DataSource dataSource) {
		this.dataSource = dataSource;
	}

	@PostConstruct
	private void initialize() {
		setDataSource(dataSource);
	}

	//Produces warnings during compile time to quickly identify typos or API changes
		@Override
	public Collection<Integer> getNumberOfActivityEventLog(String pProcessingStatus)
	{
		final ArrayList<Integer> lNumberOfPending = new ArrayList<Integer>();
		JdbcTemplate template = getJdbcTemplate();
	    Object params[] = new Object[] { pProcessingStatus };
	    int types[] = new int[] { Types.VARCHAR };

	    StringBuffer lQuery = new StringBuffer();
	    lQuery.append(selectCountActivityEventLog);	    
	    
	    template.query(lQuery.toString(), params, types, new RowCallbackHandler() {
			public void processRow(ResultSet rs) throws SQLException {
				Integer lToBeProcessedCount = Integer.valueOf(rs.getInt("to_be_processed_count"));
								
				lNumberOfPending.add(lToBeProcessedCount);
			}
		});
	    
	    return lNumberOfPending;
	}
	/**
	 * Update the Filtered-Out activities in the activity_event_log to a status of PENDING so
	 * they can get picked up by the Pending Activities batch job.
	 *
	 * @param pMemberID
	 * @param pInsertDate
	 * @return
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
	@Override
	public int updateFilteredActivities(String pMemberID, Date pInsertDate, Integer pGroupID, Integer pActivityID, String pActivityStatusToProcess, String pProcessingStatus)
	{
		JdbcTemplate template = getJdbcTemplate();
		StringBuffer lQuery = new StringBuffer();
		lQuery.append(updateFilteredActivities);
		int updatedRows = 0;

		ArrayList<Object> lParameters = new ArrayList<Object>();
		ArrayList<Integer> lTypes = new ArrayList<Integer>();

		lQuery.append(" AND actvlog.stat_cd IN (" + pActivityStatusToProcess + ")");


		if(pMemberID != null && pMemberID.length() > 0)
		{
			lParameters.add(pMemberID);
			lTypes.add(Integer.valueOf(Types.VARCHAR));
			lQuery.append(" AND actvlog.hp_mem_id = ?");
		}

		if(pInsertDate != null)
		{
			lParameters.add(pInsertDate);
			lTypes.add(Integer.valueOf(Types.DATE));
			lQuery.append(" AND actvlog.stat_eff_dt >= ?");
		}

		if(pActivityID != null)
		{
			lParameters.add(pActivityID);
			lTypes.add(Integer.valueOf(Types.INTEGER));
			lQuery.append(" AND actvlog.actv_id = (SELECT srce_actv_id FROM activity WHERE actv_id = ?)");
		}

		if(pProcessingStatus != null)
		{
			lParameters.add(pProcessingStatus);
			lTypes.add(Integer.valueOf(Types.VARCHAR));
			lQuery.append(" AND actvlog.PRCSNG_STAT_VAL = ?");
		}

		if(pGroupID != null)
		{
			lParameters.add(pGroupID);
			lTypes.add(Integer.valueOf(Types.INTEGER));
			lQuery.append(" AND actvlog.hp_mem_id IN ");
			lQuery.append(" (SELECT distinct person.hp_mem_id ");
			lQuery.append(" FROM  ");
			lQuery.append(" activity_event_log alog ");
			lQuery.append(" , prsn_demographics person ");
			lQuery.append(" , person_program_status stat ");
			lQuery.append(" , business_program biz ");
			lQuery.append(" WHERE ");
			lQuery.append(" biz.grp_id = ? ");
			lQuery.append(" AND trunc(SYSDATE) <= trunc(biz.STAT_CALC_END_DT) ");
			lQuery.append(" AND biz.biz_pgm_id = stat.biz_pgm_id ");
			lQuery.append(" AND stat.PRSN_DMGRPHCS_ID = person.PRSN_DMGRPHCS_ID ");
			lQuery.append(" AND person.hp_mem_id = alog.hp_mem_id) ");

		}

		// Convert the parameter and types ArrayLists to arrays of primitive types.
		Object params[] = new Object[lParameters.size()];
		lParameters.toArray(params);

		int types[] = new int[lTypes.size()];
		for(int j = 0; j < lTypes.size(); j++)
		{
			types[j] = ((Integer)lTypes.get(j)).intValue();
		}

		updatedRows = template.update(lQuery.toString(), params, types);
		return updatedRows;
	}


}
