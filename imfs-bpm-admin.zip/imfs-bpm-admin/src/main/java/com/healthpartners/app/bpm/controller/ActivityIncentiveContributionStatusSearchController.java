package com.healthpartners.app.bpm.controller;

import com.healthpartners.app.bpm.common.BPMAdminConstants;
import com.healthpartners.app.bpm.common.BPMAdminUtils;
import com.healthpartners.app.bpm.common.BPMPagination;
import com.healthpartners.app.bpm.dto.EmployerGroup;
import com.healthpartners.app.bpm.dto.LookUpValueCode;
import com.healthpartners.app.bpm.dto.PersonActivityContributionPending;
import com.healthpartners.app.bpm.dto.PersonActivityIncentiveSearch;
import com.healthpartners.app.bpm.exception.BPMException;
import com.healthpartners.app.bpm.form.ActivityIncentiveContributionStatusSearchForm;
import com.healthpartners.app.bpm.iface.BusinessProgramService;
import com.healthpartners.app.bpm.iface.LookUpValueService;
import com.healthpartners.app.bpm.iface.MemberService;
import com.healthpartners.app.bpm.pageable.PageablePersonActivityContributionPending;
import com.healthpartners.app.bpm.session.UserSession;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;

@Controller
public class ActivityIncentiveContributionStatusSearchController extends BaseController implements Validator {

    private static final String delimiter = ",";

    private final LookUpValueService lookUpValueService;
    private final BusinessProgramService businessProgramService;
    private final MemberService memberService;

    public ActivityIncentiveContributionStatusSearchController(LookUpValueService lookUpValueService, BusinessProgramService businessProgramService, MemberService memberService) {
        this.lookUpValueService = lookUpValueService;
        this.businessProgramService = businessProgramService;
        this.memberService = memberService;
    }

    @GetMapping("/activityIncentiveContributionStatusSearch")
    public String loadActivityIncentiveContributionStatusSearch(ModelMap modelMap) throws BPMException {
        ActivityIncentiveContributionStatusSearchForm form = new ActivityIncentiveContributionStatusSearchForm();
        form.setActionType(ACTION_SEARCH);
        if (!CollectionUtils.isEmpty(getUserSession().getPersonActivityContributionPendingList())) {
            getUserSession().getPersonActivityContributionPendingList().clear();
        }
        loadFormSelects(form);
        setAttributesBackAndNextButtonsOnModel(modelMap, null);
        modelMap.put("activityIncentiveContributionStatusSearchForm", form);
        return "activityIncentiveContributionStatusSearch";
    }

    @PostMapping("/activityIncentiveContributionStatusSearch")
    public String search(@ModelAttribute("activityIncentiveContributionStatusSearchForm") ActivityIncentiveContributionStatusSearchForm form, ModelMap modelMap, BindingResult result) throws Exception {
        form.setActionType(ACTION_SEARCH);
        loadFormSelects(form);
        if (BPMAdminConstants.REPORT_TYPE_PENDING_EMPLOYER.equals(form.getReportType())) {
            createActionMessagesOnModel(modelMap, "messages.info", new Object[]{BPMAdminConstants.REPORT_TYPE_PENDING_EMPLOYER + " search not supported"});
            return "activityIncentiveContributionStatusSearch";
        }
        validate(form, result);
        if (!result.hasErrors()) {
            performSearch(form, modelMap);
        }
        return "activityIncentiveContributionStatusSearch";
    }

    @PostMapping(value = "/activityIncentiveContributionStatusSearch", params = "next")
    public String submitNext(@ModelAttribute("activityIncentiveContributionStatusSearchForm") ActivityIncentiveContributionStatusSearchForm form, ModelMap modelMap) throws Exception {
        form.setActionType(ACTION_PAGE_FORWARD);
        loadFormSelects(form);
        handlePaginationActions(form, modelMap);
        return "activityIncentiveContributionStatusSearch";
    }

    @PostMapping(value = "/activityIncentiveContributionStatusSearch", params = "back")
    public String submitBack(@ModelAttribute("activityIncentiveContributionStatusSearchForm") ActivityIncentiveContributionStatusSearchForm form, ModelMap modelMap) throws Exception {
        form.setActionType(ACTION_PAGE_BACK);
        loadFormSelects(form);
        handlePaginationActions(form, modelMap);
        return "activityIncentiveContributionStatusSearch";
    }

    @PostMapping(value = "/activityIncentiveContributionStatusSearch", params = "download")
    public String submitDownload(@ModelAttribute("activityIncentiveContributionStatusSearchForm") ActivityIncentiveContributionStatusSearchForm form, ModelMap modelMap, HttpServletResponse response) throws Exception {
        form.setActionType(ACTION_DOWNLOAD_CONTRIBUTIONS_PAGE);
        handleDownload(form, modelMap, response);
        loadFormSelects(form);
        return "activityIncentiveContributionStatusSearch";
    }

    private void loadFormSelects(ActivityIncentiveContributionStatusSearchForm form) throws BPMException {
        if (CollectionUtils.isEmpty(getUserSession().getReportTypes()) || CollectionUtils.isEmpty(getUserSession().getProductTypes())) {
            ArrayList<LookUpValueCode> luvReportTypes = (ArrayList<LookUpValueCode>) lookUpValueService.getLUVCodesByGroup(BPMAdminConstants.REPORT_TYPE);
            ArrayList<LookUpValueCode> luvProductTypeHRA = (ArrayList<LookUpValueCode>) lookUpValueService.getLUVCodesByGroupAndName(BPMAdminConstants.GROUP_PRODUCT_TYPE, BPMAdminConstants.GROUP_PRODUCT_TYPE_HRA);
            ArrayList<LookUpValueCode> luvProductTypeHSA = (ArrayList<LookUpValueCode>) lookUpValueService.getLUVCodesByGroupAndName(BPMAdminConstants.GROUP_PRODUCT_TYPE, BPMAdminConstants.GROUP_PRODUCT_TYPE_HSA);
            ArrayList<LookUpValueCode> luvProductTypes = new ArrayList<>();
            luvProductTypes.add(luvProductTypeHRA.get(0));
            luvProductTypes.add(luvProductTypeHSA.get(0));
            getUserSession().setReportTypes(luvReportTypes);
            getUserSession().setProductTypes(luvProductTypes);
        }

        form.setLuvReportTypes(getUserSession().getReportTypes());
        form.setLuvProductTypes(getUserSession().getProductTypes());
    }

    private void performSearch(ActivityIncentiveContributionStatusSearchForm form, ModelMap modelMap) throws Exception {
        if (StringUtils.isNotEmpty(form.getGroupName()) || EMPLOYER_GROUPS_LIST.equals(form.getWhichList())) {
            searchByGroupName(modelMap, form);
        } else {
            search(modelMap, form);
        }
    }

    protected void search(ModelMap modelMap, ActivityIncentiveContributionStatusSearchForm lActivityIncentiveContributionStatusSearchForm) throws Exception {
        boolean newDTOList = false;
        String actionType = lActivityIncentiveContributionStatusSearchForm.getActionType();

        ArrayList<PersonActivityContributionPending> lPersonActivityContributionPendingList = getUserSession().getPersonActivityContributionPendingList();

        if (CollectionUtils.isEmpty(lPersonActivityContributionPendingList) || actionType.equals(ACTION_SEARCH) || actionType.equals(ACTION_SITE_SEARCH)) {
            PersonActivityIncentiveSearch lPersonActivityIncentiveSearch = getPersonActivityIncentiveSearch(lActivityIncentiveContributionStatusSearchForm);
            if (lActivityIncentiveContributionStatusSearchForm.getReportType().equals(BPMAdminConstants.REPORT_TYPE_PENDING_EMPLOYER)) {
                lPersonActivityContributionPendingList = (ArrayList<PersonActivityContributionPending>) memberService.getPersonActivityEmployerSponsoredContributionsPending(lPersonActivityIncentiveSearch);
            } else {
                lPersonActivityContributionPendingList = (ArrayList<PersonActivityContributionPending>) memberService.getPersonActivityNonEmployerSponsoredContributionsPending(lPersonActivityIncentiveSearch);
            }

            getUserSession().setPersonActivityContributionPendingList(lPersonActivityContributionPendingList);
            newDTOList = true;
        }

        //Pagination code begins here.
        String lWhichList = null;
        String lRequestAttribute = null;
        if (lActivityIncentiveContributionStatusSearchForm.getReportType().equals(BPMAdminConstants.REPORT_TYPE_PENDING_EMPLOYER)) {
            lWhichList = REPORT_TYPE_PENDING_EMPLOYER_SPONSORED_ACTIVITY;
            lRequestAttribute = "pendingEmployerSponsoredActivities";
        } else {
            lWhichList = REPORT_TYPE_PENDING_NON_EMPLOYER_SPONSORED_ACTIVITY;
            lRequestAttribute = "pendingNonEmployerSponsoredActivities";
        }

        if (actionType.equals(ACTION_SITE_SEARCH)) {
            actionType = ACTION_SEARCH;
        }

        setPersonActivityContributionPendingPagination(modelMap, getUserSession(), actionType, newDTOList, lWhichList, lRequestAttribute);
        //Pagination code ends here.

        if (lPersonActivityContributionPendingList.size() <= 0) {
            createActionMessagesOnModel(modelMap, "messages.info", new Object[]{"No results found for the given search attribute(s)"});
        }

        getUserSession().setActivityIncentiveContributionStatusSearchForm(lActivityIncentiveContributionStatusSearchForm);
        if (getUserSession().getEmployerGroups() != null && getUserSession().getEmployerGroups().size() > 0) {
            modelMap.put("groupNameExists", BPMAdminConstants.BPM_ADMIN_TRUE);
        }
    }

    protected void searchByGroupName(ModelMap modelMap, ActivityIncentiveContributionStatusSearchForm lActivityIncentiveContributionStatusSearchForm) throws Exception {
        boolean newDTOList = false;
        String actionType = lActivityIncentiveContributionStatusSearchForm.getActionType();

        ArrayList<EmployerGroup> lEmployerGroupsPerPage = null;

        ArrayList<EmployerGroup> lEmployerGroups = getUserSession().getEmployerGroups();
        if (lEmployerGroups == null || actionType.equals(ACTION_SEARCH)) {
            lEmployerGroups = (ArrayList<EmployerGroup>) businessProgramService.getGroupsByName(lActivityIncentiveContributionStatusSearchForm.getGroupName());
            getUserSession().setEmployerGroups(lEmployerGroups);
            newDTOList = true;
        }

        //Pagination code begins here.
        setEmployerGroupPaginationOnModel(modelMap, getUserSession(), actionType, newDTOList);
        //Pagination code ends here.

        getUserSession().setEmployerGroups(lEmployerGroups);
        getUserSession().setEmployerGroupsPerPage(lEmployerGroupsPerPage);
        getUserSession().setActivityIncentiveContributionStatusSearchForm(lActivityIncentiveContributionStatusSearchForm);
        getUserSession().setGroupName(lActivityIncentiveContributionStatusSearchForm.getGroupName());
        lActivityIncentiveContributionStatusSearchForm.setGroupName(getUserSession().getGroupName());

        if (lEmployerGroups.size() <= 0) {
            createActionMessagesOnModel(modelMap, "messages.info", new Object[]{"No results found for the given search attribute(s)"});
        }
    }


    private PersonActivityIncentiveSearch getPersonActivityIncentiveSearch(ActivityIncentiveContributionStatusSearchForm lActivityIncentiveContributionStatusSearchForm) {
        PersonActivityIncentiveSearch lPersonActivityIncentiveSearch = new PersonActivityIncentiveSearch();
        lPersonActivityIncentiveSearch.setContractNo(lActivityIncentiveContributionStatusSearchForm.getContractNumber());
        lPersonActivityIncentiveSearch.setGroupName(lActivityIncentiveContributionStatusSearchForm.getGroupName());
        lPersonActivityIncentiveSearch.setGroupNo(lActivityIncentiveContributionStatusSearchForm.getGroupNumber());
        lPersonActivityIncentiveSearch.setMemberNo(lActivityIncentiveContributionStatusSearchForm.getMemberNumber());
        lPersonActivityIncentiveSearch.setProductType(lActivityIncentiveContributionStatusSearchForm.getProductType());
        lPersonActivityIncentiveSearch.setSiteNo(lActivityIncentiveContributionStatusSearchForm.getSiteNumber());
        lPersonActivityIncentiveSearch.setReportType(lActivityIncentiveContributionStatusSearchForm.getReportType());
        lPersonActivityIncentiveSearch.setIncentedDate(BPMAdminUtils.convertStringToSqlDate(lActivityIncentiveContributionStatusSearchForm.getIncentedDate(), BPMAdminConstants.HP_BPM_ADMIN_UI_COMMON_DATE_FORMAT));
        lPersonActivityIncentiveSearch.setProgramStartDate(BPMAdminUtils.convertStringToSqlDate(lActivityIncentiveContributionStatusSearchForm.getEffectiveDate(), BPMAdminConstants.HP_BPM_ADMIN_UI_COMMON_DATE_FORMAT));

        return lPersonActivityIncentiveSearch;
    }

    protected void setPersonActivityContributionPendingPagination(ModelMap modelMap, UserSession sessionBean, String actionType, boolean newDTOList, String pWhichList, String pRequestAttribute) {

        ArrayList<PersonActivityContributionPending> lPersonActivityContributionPendingList = sessionBean.getPersonActivityContributionPendingList();
        BPMPagination pagination = sessionBean.getPaginationMap().get(pWhichList);

        PageablePersonActivityContributionPending lPCFTR = null;
        if (pagination == null || newDTOList) {
            lPCFTR = new PageablePersonActivityContributionPending(lPersonActivityContributionPendingList);
            lPCFTR.addRowNumber();
            pagination = new BPMPagination(lPCFTR, new ArrayList<Object>(lPersonActivityContributionPendingList));
            sessionBean.getPaginationMap().put(pWhichList, pagination);
        }

        ArrayList<PersonActivityContributionPending> lPersonActivityContributionPendingPerPage = (ArrayList<PersonActivityContributionPending>) determineNextOrBackAction(actionType, pagination);
        setAttributesForPaginationOnModel(modelMap, lPersonActivityContributionPendingList.size(), pagination);
        modelMap.put(pRequestAttribute, lPersonActivityContributionPendingPerPage);
        sessionBean.setPersonActivityContributionPendingList(lPersonActivityContributionPendingList);
        sessionBean.setPersonActivityContributionPendingPerPage(lPersonActivityContributionPendingPerPage);
    }

    private void handlePaginationActions(ActivityIncentiveContributionStatusSearchForm form, ModelMap modelMap) {
        ArrayList<PersonActivityContributionPending> lPersonActivityContributionPendingList = getUserSession().getPersonActivityContributionPendingList();
        ArrayList<PersonActivityContributionPending> lPersonActivityContributionPendingPerPage = null;
        boolean newDTOList = false;
        //Pagination code begins here.

        /**
         * Page through Activity Incentive Contribution Employer Sponsored list.
         */
        if (REPORT_TYPE_PENDING_EMPLOYER_SPONSORED_ACTIVITY.equals(form.getWhichList())) {
            getUserSession().setPersonActivityContributionPendingList(lPersonActivityContributionPendingList);
            setPersonActivityContributionPendingPagination(modelMap, getUserSession(), form.getActionType(), newDTOList, form.getWhichList(), "pendingEmployerSponsoredActivities");
            getUserSession().setPersonActivityContributionPendingPerPage(null);
        }

        /**
         * Page through non employer sponsored activity list.
         */
        if (REPORT_TYPE_PENDING_NON_EMPLOYER_SPONSORED_ACTIVITY.equals(form.getWhichList())) {
            getUserSession().setPersonActivityContributionPendingList(lPersonActivityContributionPendingList);
            setPersonActivityContributionPendingPagination(modelMap, getUserSession(), form.getActionType(), newDTOList, form.getWhichList(), "pendingNonEmployerSponsoredActivities");
            getUserSession().setPersonActivityContributionPendingPerPage(lPersonActivityContributionPendingPerPage);
        }
        /**
         * Page through the Employer Groups list.
         */
        if (EMPLOYER_GROUPS_LIST.equals(form.getWhichList())) {
            setEmployerGroupPaginationOnModel(modelMap, getUserSession(), form.getActionType(), newDTOList);
            getUserSession().setGroupName(form.getGroupName());
            form.setGroupName(getUserSession().getGroupName());
        }

        getUserSession().setActivityIncentiveContributionStatusSearchForm(form);
        getUserSession().setGroupNo(form.getGroupNumber());

        if (!CollectionUtils.isEmpty(getUserSession().getEmployerGroups())
                && REPORT_TYPE_PENDING_EMPLOYER_SPONSORED_ACTIVITY.equals(form.getWhichList())) {
            modelMap.put("groupNameExists", BPMAdminConstants.BPM_ADMIN_TRUE);
        }
    }

    private void handleDownload(ActivityIncentiveContributionStatusSearchForm form, ModelMap modelMap, HttpServletResponse response) throws IOException {
        if (!CollectionUtils.isEmpty(getUserSession().getPersonActivityContributionPendingList())) {
            ArrayList<PersonActivityContributionPending> lPersonActivityContributionPending = getUserSession().getPersonActivityContributionPendingList();
            response.setHeader("Content-Type", "text/csv");
            response.setHeader("Content-Disposition", "attachment;filename=\"report.csv\"");
            writeCsv(lPersonActivityContributionPending, response.getOutputStream(), form.getReportType());
        } else {
            createActionMessagesOnModel(modelMap, "errors.download", null);
        }
    }

    private void writeCsv(Collection<PersonActivityContributionPending> csv, OutputStream output, String reportType) throws IOException {
        BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(output, StandardCharsets.UTF_8));

        if (reportType.equals(BPMAdminConstants.REPORT_TYPE_PENDING_EMPLOYER)) {
            formatPendingEmployerSponsoredHeaderNWrite(writer);
        } else {
            formatPendingNonEmployerSponsoredHeaderNWrite(writer);
        }

        Iterator<PersonActivityContributionPending> iter = csv.iterator();
        while (iter.hasNext()) {
            PersonActivityContributionPending lPersonActivityContributionPending = iter.next();
            if (reportType.equals(BPMAdminConstants.REPORT_TYPE_PENDING_EMPLOYER)) {
                formatPendingEmployerSponsoredDetailNWrite(writer, lPersonActivityContributionPending);
            } else {
                formatPendingNonEmployerSponsoredDetailNWrite(writer, lPersonActivityContributionPending);
            }
        }

        closeFileWriter(writer);
    }

    public void closeFileWriter(BufferedWriter writer) {
        try {
            writer.flush();
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void formatPendingEmployerSponsoredHeaderNWrite(BufferedWriter writer) throws IOException {
        writer.append("No");
        writer.append(delimiter);

        writer.append("Incented Date");
        writer.append(delimiter);

        writer.append("Group No");
        writer.append(delimiter);

        writer.append("Site No");
        writer.append(delimiter);

        writer.append("Member No");
        writer.append(delimiter);

        writer.append("Last Name");
        writer.append(delimiter);

        writer.append("First Name");
        writer.append(delimiter);

        writer.append("Contract No");
        writer.append(delimiter);

        writer.append("Activity Name");
        writer.append(delimiter);

        writer.append("Contribution Amount");
        writer.append(delimiter);

        writer.append("Contribution Date");
        writer.append(delimiter);

        writer.append("Product Type");
        writer.append(delimiter);

        writer.newLine();

    }

    private void formatPendingNonEmployerSponsoredHeaderNWrite(BufferedWriter writer) throws IOException {
        writer.append("No");
        writer.append(delimiter);

        writer.append("Incented Date");
        writer.append(delimiter);

        writer.append("Group No");
        writer.append(delimiter);

        writer.append("Site No");
        writer.append(delimiter);

        writer.append("Member No");
        writer.append(delimiter);

        writer.append("Last Name");
        writer.append(delimiter);

        writer.append("First Name");
        writer.append(delimiter);

        writer.append("Contract No");
        writer.append(delimiter);

        writer.append("Activity Name");
        writer.append(delimiter);

        writer.append("Contribution Amount");
        writer.append(delimiter);

        writer.append("Contribution Date");
        writer.append(delimiter);

        writer.append("Product Type");
        writer.append(delimiter);

        writer.newLine();
    }

    private void formatPendingEmployerSponsoredDetailNWrite(BufferedWriter writer, PersonActivityContributionPending lPersonActivityContributionPending) throws IOException {
        writer.append(Integer.toString(lPersonActivityContributionPending.getRowNumber()));
        writer.append(delimiter);

        writer.append(BPMAdminUtils.formatDateMMddyyyy(lPersonActivityContributionPending.getIncentedDate()));
        writer.append(delimiter);

        writer.append(lPersonActivityContributionPending.getGroupNo());
        writer.append(delimiter);

        writer.append(lPersonActivityContributionPending.getSiteNo());
        writer.append(delimiter);

        writer.append(lPersonActivityContributionPending.getMemberNo());
        writer.append(delimiter);

        writer.append(lPersonActivityContributionPending.getLastName());
        writer.append(delimiter);

        writer.append(lPersonActivityContributionPending.getFirstName());
        writer.append(delimiter);

        writer.append(Integer.toString(lPersonActivityContributionPending.getContractNo()));
        writer.append(delimiter);

        writer.append(lPersonActivityContributionPending.getActivityName().replaceAll(",", ""));
        writer.append(delimiter);

        writer.append(Integer.toString(lPersonActivityContributionPending.getContributionAmt()));
        writer.append(delimiter);

        writer.append(BPMAdminUtils.formatDateMMddyyyy(lPersonActivityContributionPending.getContributionDate()));
        writer.append(delimiter);

        writer.append(lPersonActivityContributionPending.getPackageSubTypeName());

        writer.newLine();
    }

    private void formatPendingNonEmployerSponsoredDetailNWrite(BufferedWriter writer, PersonActivityContributionPending lPersonActivityContributionPending) throws IOException {
        writer.append(Integer.toString(lPersonActivityContributionPending.getRowNumber()));
        writer.append(delimiter);

        writer.append(BPMAdminUtils.formatDateMMddyyyy(lPersonActivityContributionPending.getIncentedDate()));
        writer.append(delimiter);

        writer.append(lPersonActivityContributionPending.getGroupNo());
        writer.append(delimiter);

        writer.append(lPersonActivityContributionPending.getSiteNo());
        writer.append(delimiter);

        writer.append(lPersonActivityContributionPending.getMemberNo());
        writer.append(delimiter);

        writer.append(lPersonActivityContributionPending.getLastName());
        writer.append(delimiter);

        writer.append(lPersonActivityContributionPending.getFirstName());
        writer.append(delimiter);

        writer.append(Integer.toString(lPersonActivityContributionPending.getContractNo()));
        writer.append(delimiter);

        writer.append(lPersonActivityContributionPending.getActivityName().replaceAll(",", ""));
        writer.append(delimiter);

        writer.append(Integer.toString(lPersonActivityContributionPending.getContributionAmt()));
        writer.append(delimiter);

        writer.append(BPMAdminUtils.formatDateMMddyyyy(lPersonActivityContributionPending.getContributionDate()));
        writer.append(delimiter);

        writer.append(lPersonActivityContributionPending.getPackageSubTypeName());

        writer.newLine();
    }


    @Override
    public boolean supports(Class<?> clazz) {
        return ActivityIncentiveContributionStatusSearchForm.class.isAssignableFrom(clazz);
    }

    @Override
    public void validate(Object target, Errors errors) {
        ActivityIncentiveContributionStatusSearchForm form = (ActivityIncentiveContributionStatusSearchForm) target;
        getValidationSupport().validateRequiredFieldIsNotEmpty("reportType", form.getReportType(), errors, new Object[]{"Report Type"});
        getValidationSupport().validateRequiredFieldIsNotEmpty("incentedDate", form.getIncentedDate(), errors, new Object[]{"Incented Date"});
        getValidationSupport().validateRequiredFieldIsNotEmpty("productType", form.getProductType(), errors, new Object[]{"Product Type"});
        getValidationSupport().validateDateFormat("effectiveDate", form.getEffectiveDate(), errors, new Object[]{"Program Year Effective Date"});
        getValidationSupport().validateDateFormat("incentedDate", form.getIncentedDate(), errors, new Object[]{"Incented Date"});
        getValidationSupport().validateNotSpecialChar("groupNumber", form.getGroupNumber(), errors, new Object[]{"Group No"});
        getValidationSupport().validateNotSpecialChar("groupName", form.getGroupName(), errors, new Object[]{"Group Name"});
        getValidationSupport().validateNotSpecialChar("siteNumber", form.getSiteNumber(), errors, new Object[]{"Site No"});
        getValidationSupport().validateNotInteger("contractNumber", form.getContractNumber(), errors, new Object[]{"Contract No"});
    }
}
