/**
 * 
 */
package com.healthpartners.app.bpm.form;

import com.healthpartners.app.bpm.dto.LookUpValueCode;
import java.util.ArrayList;

/**
 * @author f5929
 *
 */
public class SavePersonEmployerActivityRecycleForm extends BaseForm {

	static final long serialVersionUID = 0L;
	
	private String actionType;
	
	private String employerRecycleID;
	
	private String recycleStatusDate;

	private String recycleStatusCode;
	private ArrayList<LookUpValueCode> recycleStatusCodes;
	
	private String reason;
	private String approver;


	public SavePersonEmployerActivityRecycleForm() {
		super();
	}

	public String getRecycleStatusDate() {
		return recycleStatusDate;
	}


	public void setRecycleStatusDate(String recycleStatusDate) {
		this.recycleStatusDate = recycleStatusDate;
	}


	

	public String getReason() {
		return reason;
	}


	public void setReason(String reason) {
		this.reason = reason;
	}


	public String getApprover() {
		return approver;
	}


	public void setApprover(String approver) {
		this.approver = approver;
	}


	

	public String getRecycleStatusCode() {
		return recycleStatusCode;
	}


	public void setRecycleStatusCode(String recycleStatusCode) {
		this.recycleStatusCode = recycleStatusCode;
	}


	public String getActionType() {
		return actionType;
	}


	public void setActionType(String actionType) {
		this.actionType = actionType;
	}


	public String getEmployerRecycleID() {
		return employerRecycleID;
	}

	public void setEmployerRecycleID(String employerRecycleID) {
		this.employerRecycleID = employerRecycleID;
	}

	public ArrayList<LookUpValueCode> getRecycleStatusCodes() {
		return recycleStatusCodes;
	}


	public void setRecycleStatusCodes(ArrayList<LookUpValueCode> recycleStatusCodes) {
		this.recycleStatusCodes = recycleStatusCodes;
	}
	
}
