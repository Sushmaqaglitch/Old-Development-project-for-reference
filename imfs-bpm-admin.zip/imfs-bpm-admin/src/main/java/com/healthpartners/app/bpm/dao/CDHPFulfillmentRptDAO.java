package com.healthpartners.app.bpm.dao;

import com.healthpartners.app.bpm.dto.CDHPFulfillmentSearch;
import com.healthpartners.app.bpm.dto.CDHPFulfillmentTrackingReportHist;
import org.springframework.dao.DataAccessException;

import java.util.Collection;

public interface CDHPFulfillmentRptDAO 
{

	public Collection<CDHPFulfillmentTrackingReportHist> getCDHPFulfillmentTrackingReportHist(CDHPFulfillmentSearch lCDHPFulfillmentSearch)
			throws DataAccessException; 
	
	public Collection<CDHPFulfillmentTrackingReportHist> getCDHPFulfillmentTrackingReport(CDHPFulfillmentSearch lCDHPFulfillmentSearch)
			throws DataAccessException;
				
	
}
