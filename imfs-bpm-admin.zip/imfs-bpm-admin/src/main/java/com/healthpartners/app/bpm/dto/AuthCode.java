/**
 *
 */
package com.healthpartners.app.bpm.dto;

import java.io.Serializable;

/**
 * @author jxbourbour
 *
 */
public class AuthCode implements Serializable {
    static final long serialVersionUID = 0L;

    private Integer businessProgramID;
    private String authCode;
    private Integer authCodeTypeCodeID;
    private String authCodeTypeCode;
    private java.sql.Date effectiveDate;
    private java.sql.Date endDate;

    /**
     *
     */
    public AuthCode() {
        super();
    }

    public final Integer getBusinessProgramID() {
        return businessProgramID;
    }

    public final void setBusinessProgramID(Integer businessProgramID) {
        this.businessProgramID = businessProgramID;
    }

    public final String getAuthCode() {
        return authCode;
    }

    public final void setAuthCode(String authCode) {
        this.authCode = authCode;
    }

    public final String getAuthCodeTypeCode() {
        return authCodeTypeCode;
    }

    public final void setAuthCodeTypeCode(String authCodeTypeCode) {
        this.authCodeTypeCode = authCodeTypeCode;
    }

    public final java.sql.Date getEffectiveDate() {
        return effectiveDate;
    }

    public final void setEffectiveDate(java.sql.Date effectiveDate) {
        this.effectiveDate = effectiveDate;
    }

    public final java.sql.Date getEndDate() {
        return endDate;
    }

    public final void setEndDate(java.sql.Date endDate) {
        this.endDate = endDate;
    }

    public final Integer getAuthCodeTypeCodeID() {
        return authCodeTypeCodeID;
    }

    public final void setAuthCodeTypeCodeID(Integer authCodeTypeCodeID) {
        this.authCodeTypeCodeID = authCodeTypeCodeID;
    }


}
