package com.healthpartners.app.bpm.form;

/**
 * @author jxbourbour
 */
public class MemberActivityHistorySearchForm extends BaseForm {

    static final long serialVersionUID = 0L;

    private String operationType;

    private String memberID;

    private String qualificationStartDate;

    private String personID;

    private String searchedMemberID;

    public MemberActivityHistorySearchForm() {
        super();
    }

    public String getMemberID() {
        if (memberID != null) {
            return memberID.trim();
        }
        return memberID;
    }

    public void setMemberID(String memberID) {
        this.memberID = memberID;
    }

    public String getOperationType() {
        return operationType;
    }

    public void setOperationType(String operationType) {
        this.operationType = operationType;
    }

    public String getQualificationStartDate() {
        return qualificationStartDate;
    }

    public void setQualificationStartDate(String qualificationStartDate) {
        this.qualificationStartDate = qualificationStartDate;
    }

    public String getPersonID() {
        return personID;
    }

    public void setPersonID(String personID) {
        this.personID = personID;
    }

    public String getSearchedMemberID() {
        return searchedMemberID;
    }

    public void setSearchedMemberID(String searchedMemberID) {
        this.searchedMemberID = searchedMemberID;
    }

}
