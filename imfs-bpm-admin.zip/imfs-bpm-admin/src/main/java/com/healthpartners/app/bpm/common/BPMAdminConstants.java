package com.healthpartners.app.bpm.common;

public interface BPMAdminConstants 
{
	public static final String HP_BPM_ADMIN_UI_COMMON_DATE_FORMAT = "MM/dd/yyyy";
	public static final String HP_BPM_ADMIN_UI_DATE_FORMAT_yyyy_MM_dd = "yyyy-MM-dd";
	
	 //Control Group IO File Direcory Setup Routing type group
    public static final String CNTRL_GRP_RT_TYPE = "CNTRL_GRP_RT_TYPE";
    public static final String UPL_EMPLOYER_SPONSORED = "UPL_EMPLOYER_SPONSORED";
	
	public static final String ACTIVATE_STATUS = "ACTIVE";
	
	public static final String BPM_LUV_PARTICIPATION_REQ = "BPM_PARTICIP_REQ";
	
	public static final String BPM_LUV_ACTIVITY_TYPE = "BPM_ACTIVITY_TP";
	public static final String BPM_LUV_ACTIVITY_STATUS = "BPM_ACTIVITY_STATUS";
	
	public static final String BPM_LUV_REPORT_INDICATOR_TYPE = "BPM_REPORT_TP";
		
	public static final String RESULT_SUCCESS = "SUCCESS";
	public static final String RESULT_FAILURE = "FAILURE";
	
	public static final String BPM_LUV_RISK_GROUP = "BPM_RISK_GROUP";
	public static final String BPM_LUV_INCENTIVE_TYPE = "BPM_INCNTV_TP";
	public static final String BPM_LUV_INCENTIVE_OPTN_UNIT_TYPE = "INCNTV_OPTN_UNITS_TP";
	public static final String BPM_LUV_INCENTIVE_STATUS = "BPM_INCNTV_STS";
	public static final String BPM_LUV_RECYCLE_STATUS = "BPM_RECYCLE_STATUS";
	public static final String BPM_LUV_RECYCLE_STATUS_RELEASED = "RELEASED";
	public static final String BPM_LUV_FULFILLMENT_RTNG_TYPE = "FLFLMNT_RTNG_TP";

	//Url rest endpoints for kicking off batch services hosted on Openshift.
    public static final String OS_REST_URL_COMMAND = "OS_REST_URL_COMMAND";
    public static final String OS_URL_KS_PENDING_ACTIVITY = "OS_URL_KS_PENDING_ACTIVITY";
    public static final String OS_URL_KS_MEMBER_UPD_QUEUE = "OS_URL_KS_MEMBER_UPD_QUEUE";
    public static final String OS_URL_KS_MEMBERSHIP_UPDATE = "OS_URL_KS_MEMBERSHIP_UPDATE";
    public static final String OS_URL_KS_MEMBERSTATUS_RECALC = "OS_URL_KS_MEMBERSTATUS_RECALC";
    public static final String OS_URL_KS_ETL_MEMBERSHIP_UPDATE = "OS_URL_KS_ETL_MEMBERSHIP_UPD";
    public static final String OS_URL_KS_MISSING_ACTIVITIES = "OS_URL_KS_MISSING_ACTIVITIES";
    public static final String OS_URL_KS_ETL_CONTRACT_RECON = "OS_URL_KS_CONTRACT_RECON";
    public static final String OS_URL_KS_ETL_MISSING_PERSON = "OS_URL_KS_MISSING_PERSON";
    public static final String OS_URL_KS_MEMBERSHIP_PREM_BILLING = "OS_URL_KS_MEMBERSHIP_PREM_BILLING";
    public static final String OS_URL_KS_EMPLOYER_BASELINE_SETUP = "OS_URL_KS_EMPLOYER_BASELINE";
    public static final String OS_URL_KS_EMPLOYER_GRP_SITE_SETUP = "OS_URL_KS_EMPLOYER_GRP_SITE";
    public static final String OS_URL_KS_DELETE_TERMED_PART_BY_GRP = "DELETE_TERMED_BY_GRP";




	
	 //Incentive Option Unit Types
    public static String BPM_IO_UNIT_TYPE_DOLLAR = "DOLLARS";
    public static String BPM_IO_UNIT_TYPE_UNITS = "UNITS";
    public static String BPM_IO_UNIT_TYPE_NONE = "NONE";
    
    public static String BPM_INCENTIVE_PACKAGE_RULE_GROUP_TYPE = "INCNTV_PKG_RULE_GRP";
	
	public static final String BPM_LUV_INCENTIVE_OPTION_ID_CD = "INCNTV_OPTN_ID_CD";
	public static final String BPM_LUV_INCENTIVE_OPTION_UNITS_TYPE = "INCNTV_OPTN_UNITS_TYP";
	public static final String BPM_LUV_INCENTED_STATUS = "BPM_INCENTED_STATUS";
	public static final String BPM_LUV_INCENTED_BASED = "BPM_INCENTED_BASED";
	public static final String BPM_LUV_ACTIVITY_INCENTIVE_TYPE_CODE = "ACTV_INCNTV_TYP_CD";
	public static final String BPM_LUV_INCENTIVE_ENROLLMENT_RULE_CODE = "INCNTV_RULE_TP";
	
	public static final String BPM_LUV_INCENTIVE_STATUS_MULTI_ACTIVITY = "MULTI_ACTIVITY";
	public static final String BPM_LUV_INCENTIVE_STATUS_ACTIVITY_PKGE_BASED = "ACTIVITY_PKGE_BASED";
	
	public static final String BPM_INCENTED_STATUS_TYPE_CONTRACT_BASED = "CONTRACT_BASED";
	public static final String BPM_INCENTED_STATUS_TYPE_MEMBER_BASED = "MEMBER_BASED";
	
	public static final String BPM_INCENTED_STATUS_TYPE_ACTIVITY_BASED = "ACTIVITY_BASED";

	public static final String BPM_LUV_INCNTV_PART_GRP = "BPM_INCNTV_PART_GRP";
	
	public static final String BPM_LUV_QUALIFICATION_STATUS_CODES = "CHKMRK_QUAL_STATUS";
	public static final String BPM_LUV_LOGICAL_OPERATORS = "BPM_LOGIC_OPERATOR";
	
	public static final String BPM_ADMIN_USER = "BPM_ADMIN";
	
	public static final int BPM_ADMIN_DEFAULT_GROUP_HIRE_MONTH = 6;

    public static final int BPM_ADMIN_DEFAULT_NEW_HIRE_MONTH = 1;

	// 8 months added to the month of the effective date. For ex. Jan (month 1) + 8
	public static final int BPM_ADMIN_DEFAULT_QUAL_END_MONTH = 8;
	// 11 months added to the month of the effective date. For ex. Jan (month 1) + 11
	public static final int BPM_ADMIN_DEFAULT_GROUP_END_MONTH = 11;
	
	public static final int BPM_ADMIN_DEFAULT_GROUP_END_DAY = 28;
	
	public static final Integer PROCESSING_STATUS_LOG_PROCESS_ID = Integer.valueOf(1);
	
	public static final String BPM_ADMIN_DB_ENV = "BPM_ADMIN_DB_ENV";
	
	public static final String BPM_ADMIN_ACTION_CANCEL = "cancel";
    public static final String BPM_ADMIN_ACTION_CANCEL_BACK_TO_MEMBER_DETAIL = "cancelBackToMemberDetail";

	public static final String BPM_ADMIN_ACTION_ADD = "Add";
	
		
	public static final int BPM_ADMIN_MEMBERSHIP_UPDATE_PRCS_ID = 10;
	public static final int BPM_ADMIN_MEMBERS_RECALCULATION_PRCS_ID = 11;
	public static final int BPM_ADMIN_MEMBERSHIP_UPDATE_ONLY_PRCS_ID = 12;
	
	public static final String EMPLOYER_ACTIVITY_STATUS_COMPLETED = "Y";
	
	public static final String EMPLOYER_ACTIVITY_SOURCESYSTEM_ID_BPMADMIN = "0";
	public static final String EMPLOYER_ACTIVITY_SOURCESYSTEM_NAME_BPMADMIN = "BPM_ADMIN";
	public static final String EMPLOYER_ACTIVITY_DATAFILE_DELEMETER = "\\|";
	
	public static final String BPM_ADMIN_MEMBERSHIP_FLAG_TRUE = "Y";
	
	public static final int BPM_ADMIN_EXEMPTION_REASON_LENGTH = 200;
	public static final int BPM_ADMIN_ACTIVITY_OVERRIDE_REASON_LENGTH = 200;
	public static final int BPM_ACTIVITY_DESCRIPTION_LENGTH = 1000;
	
	public static final int BPM_GROUPOVRD_DESCRIPTION_LENGTH = 200;
	
	public static final String BPM_ADMIN_CONTRACT_STATUS_QUALIFIED = "QUALIFIED";
	public static final String BPM_ADMIN_CONTRACT_STATUS_DID_NOT_QUALIFIY = "DID_NOT_QUALIFY";
	public static final String BPM_ADMIN_MEMBER_STATUS_QUALIFIED = "QUALIFIED";
	public static final String BPM_ADMIN_MEMBER_STATUS_EXEMPT = "EXEMPT";
	
	public static final String BPM_ADMIN_EMAIL_FROM_ADDR = "BPM_EMAIL_FROM_ADDR";
	public static final String BPM_ADMIN_EMAIL_TO_ADDR = "BPM_EMAIL_TO_ADDR";
	public static final String BPM_ADMIN_EMAIL_HOST_SRVR = "BPM_EMAIL_HOST_SRVR";
	public static final String BPM_ADMIN_MEMBERSHIP_DISTRIBUTION_EMAIL = "BPM_MBRSHP_TO_ADDR";
	
	public static final String BPM_ADMIN_OVERRIDE_SOURCE_SYSTEM_ID = "9";
	
	public static final String BPM_ADMIN_PROGRAM_TYPE_CODE_HEALTY_BENEFITS = "1";
	public static final String BPM_ADMIN_PROGRAM_TYPE_CODE_SMART_STEPS = "2";
	public static final String BPM_ADMIN_PROGRAM_TYPE_CODE_JOURNEYWELL = "4";
	public static final String BPM_ADMIN_PROGRAM_TYPE_CODE_NEWJOURNEYWELL = "5";
	public static final String BPM_ADMIN_PROGRAM_TYPE_CODE_JOURNEYWELL4 = "6";
	public static final String BPM_ADMIN_PROGRAM_TYPE_CODE_OTHERWELLNESS = "7";

    public static final String BPM_ADMIN_PROGRAM_TYPE_CODE_OCTAVIUS = "22";
    public static final String BPM_ADMIN_PROGRAM_TYPE_CODE_ISR = "23";
	
	public static final String BPM_ADMIN_ACTIVITY_TYPE_HA = "HA";
	public static final String BPM_ADMIN_SS_HA_AUTH_CODE_PREFIX = "SSHA";
	public static final String BPM_ADMIN_SS_PROMO_CODE_PREFIX = "SSPR";
	
	public static final String BPM_ADMIN_PARTICIP_REQ_ALL_18_PLUS = "ALL_18_PLUS";
	
	public static final String BPM_ADMIN_ACTIVITY_STATUS_COMPLETE = "COMPLETE";
	public static final String BPM_ADMIN_ACTIVITY_STATUS_WAIVE = "WAIVE";
	public static final String BPM_ADMIN_ACTIVITY_STATUS_DELETE = "DELETE";
	public static final String BPM_ADMIN_ACTIVITY_STATUS_CANCEL = "CANCEL";
	public static final String BPM_ADMIN_ACTIVITY_STATUS_EXEMPT = "ACTV_EXMPT";
	public static final String BPM_ADMIN_ACTIVITY_STATUS_MET = "MET";
	public static final String BPM_ADMIN_ACTIVITY_STATUS_NOT_MET = "NOT_MET";
	
	public static final String BPM_ADMIN_MEMBER_STATUS = "BPM_MEMBER_STATUS";
	public static final String BPM_ADMIN_CONTRACT_STATUS = "BPM_CONTRACT_STATUS";
	
	public static final String BPM_LUV_BPM_ACTVTN_STATUS = "BPM_ACTVTN_STATUS";
	public static final String BPM_LUV_AUTH_CD_TP = "BPM_AUTH_CD_TP";
	public static final String BPM_LUV_INCENVIVE_OVERRIDE_CD_TP = "INCENTIVE_OVRD_TP";
	
	public static final String BPM_LUV_INCNTV_RPT_DESC_TP = "INCNTV_RPT_DESC";
	
	public static final String BPM_LUV_BEN_CONTRACT_TP = "BEN_CONTRACT_TYPE";
	
	public static final String BPM_ADMIN_HAS_ACCESS_TO_ENV = "hasAccessToEnvironment";
	
	public static final String BPM_ADMIN_GROUP_VIEW_EDIT_ACCESS = "GroupViewAndEditAccess";
	public static final String BPM_ADMIN_GROUP_VIEW_AND_EDIT = "GroupViewAndEdit";
	public static final String BPM_ADMIN_GROUP_VIEW_ONLY = "GroupViewOnly";
	public static final String BPM_SUPER_USER = "SuperUser";
	public static final String BPM_ADMIN_PRINTER_FRIENDLY_ACCESS = "PrinterFriendlyPageAccess";
	
	public static final String BPM_ADMIN_ACTIVITY_DEFINITIONS = "ActivityDefinitions";
    public static final String BPM_ADMIN_ACTIVITY_DEFINITIONS_SORT = "ActivityDefinitionsSort";
    public static final String BPM_ADMIN_BPM_PROGRAM_DEFINITIONS = "BPMProgramDefinitions";
    public static final String BPM_ADMIN_INCENTIVE_OPTIONS = "IncentiveOptionDefinitions";
    public static final String BPM_ADMIN_LOOKUP_VALUE_CODES = "LookupValueCodes";
    public static final String BPM_ADMIN_RISK_OUTOMES = "RiskOutcomes";
    public static final String BPM_ADMIN_PACKAGE_DEFINITION = "PackageDefinition";
    public static final String BPM_ADMIN_QUALIFICATION_CHECKMARKS = "QualificationCheckmarks";
    public static final String BPM_ADMIN_PARTICIPATION_GROUPS = "ParticipationGroups";
    public static final String BPM_ADMIN_COLLECTIONS = "Collections";
    public static final String BPM_ADMIN_ENVIRONMENT_CODES = "EnvironmentCodes";
    public static final String BPM_ADMIN_EXT_EMPLOYER_ACTIVITIES = "ExtEmployerActivities";
    
    

    public static final int BPM_ADMIN_INCENTIVE_ACTIVATION_DAYS = 15;
    public static final String BPM_LUV_ENVIRONMENTS = "BPM_LUV_ENVIRONMENTS";
    public static final String BPM_ADMIN_ADD_USER_ACCESS = "addUserAccess";
    public static final String BPM_ADMIN_EDIT_USER_ACCESS = "editUserAccess";
    public static final String BPM_ADMIN_DELETE_USER_ACCESS = "deleteUserAccess";
    
    public static final String BPM_LUV_GROUP_SITE_EXCEPT_TYPES = "BPM_GRP_EXEMPT_TYPE";
    
    public static final String BPM_ADMIN_TRUE = "true";
    public static final String BPM_ADMIN_FALSE = "false";
    
    public static final int BPM_ADMIN_DEFAULT_STATUS_CALC_END_MONTH = 3;
    
    public static final String BPM_ADMIN_PAGINATION_BEGIN  = "BEGIN";
    public static final String BPM_ADMIN_PAGINATION_END  = "END";
    
//Business Program status ACTIVE, WITHDRAWN, ect.
	
	public static final String BUS_PROGRAM_ACTVTN_ACTIVE = "ACTIVE";
	public static final String BUS_PROGRAM_ACTVTN_INACTIVE = "INACTIVE";
	public static final String BUS_PROGRAM_ACTVTN_WITHDRAWN = "WITHDRAWN";
	public static final String BUS_PROGRAM_ACTVTN_THIRD_PARTY = "THIRD_PARTY";

	// Program Additional Info types, Fixed, vs Free Form
    public static final String BPM_ADMIN_ADDL_INFO_FIXED = "ADDL_INFO_FIXED";
    public static final String BPM_ADMIN_ADDL_INFO_FREE_FORM = "ADDL_INFO_FREE_FORM";
    public static final String BPM_ADMIN_ADDL_INFO_NMS = "ADDL_INFO_NMS";
    
    public static final String BPM_MEMBER_SERVICES_ADMIN_ROLE = "MemberServicesAdmin";
    public static final String BPM_ADMIN_ADMIN_VIEW = "AdminView";
    public static final String BPM_ADMIN_GROUP_SETUP = "GroupSetup";
    
    public static final String BPM_EXEMPTION_TYPE_CODE = "BPM_OVRD_TP";
    public static final String BPM_EXEMPTION_TYPE_ALL = "ALL";
    public static final int BPM_EXEMPTION_DEFAULT_MAX_RECORDS = 200;
    public static final int BPM_DEFAULT_MAX_RECORDS = 200;
    
    public static final String BPM_FILTERED_ACTIVITIES_ALL = "ALL";

    public static final String BPM_ACTIVITY_EVENT_PENDING = "PENDING";
    public static final String BPM_ACTIVITY_EVENT_IN_PROCESS = "IN_PROCESS";
    
    public static final String BPM_ADMIN_EMPL_RECYC_STATUS_ON_HOLD = "ON_HOLD";
    public static final String BPM_ADMIN_EMPL_RECYC_STATUS_NO_MATCH = "NO_MATCH";
    
 // BPM system user
	public static final String BPM_USER_SYSTEM = "BPM";
    
    //Employer Activity Recycle Status
    public static final String BPM_EMPL_RECYCLE_STATUS_ON_HOLD = "ON_HOLD";
    public static final String BPM_EMPL_RECYCLE_STATUS_PROCESSED = "PROCESSED";
    public static final String BPM_EMPL_RECYCLE_STATUS_NO_MATCH = "NO_MATCH";
    public static final String BPM_EMPL_RECYCLE_STATUS_REJECTED = "REJECTED";
    
    public static final String BPM_RECYCLE_STATUS_APPROVED = "APPROVED";
    
    // Enrollment Date Rules
    public static String BPM_ADMIN_INCENTIVE_ENROLL_COMMUNICATE = "COMMUNICATED";
    public static String BPM_ADMIN_INCENTIVE_ENROLL_ENROLL_BY = "ENROLL_BY";
    public static String BPM_ADMIN_INCENTIVE_ENROLL_COMPLETE_BY = "COMPLETE_BY";
    public static String BPM_ADMIN_INCENTIVE_COVERAGE_EFFECTIVE_DATE = "COVERAGE_EFF_DT";
    
    //Employer Member Contribution Incented Activity For Dropdown
    public static String GROUP_CONTRIB_UPLOAD = "GROUP_CONTRIB_UPLOAD";
    
  //CDHP Fulfillment Product Type (HRA or HSA) For Dropdown
    public static String GROUP_PRODUCT_TYPE = "GROUP_PRODUCT_TYPE";
    public static String GROUP_PRODUCT_TYPE_HRA = "GROUP - HRA";
    public static String GROUP_PRODUCT_TYPE_HSA = "GROUP - HSA";
    public static String GROUP_PRODUCT_TYPE_ALL = "GROUP - ALL";
    
  //CDHP Table Type for drowdown
    public static String CDHP_TABLE_TYPE_FULFILL = "CDHP_TABLE_TYPE";
    public static String CDHP_TABLE_TYPE_FULFILL_HIST = "FULFILL DETAIL";
    public static String CDHP_TABLE_TYPE_FULFILL_CONTRACT = "FULFILL CONTRACT";
    
  //Activity Status Contribution Report Types
    public static String REPORT_TYPE = "CDHP_REPORT_TYPE";
    public static String REPORT_TYPE_PENDING_EMPLOYER = "PENDING (EMPLOYER)";
    public static String REPORT_TYPE_PENDING_SYSTEM = "PENDING (SYSTEM)";
    public static String REPORT_TYPE_PENDING_WAITING = "WAITING";
    public static String REPORT_TYPE_PENDING_PROCESSED = "PROCESSED";
    
    public static String BPM_COLLECTION_TP = "BPM_COLLECTION_TP";

    public static String BPM_DEFAULT_FIRST_ITEM_IN_DROPDOWN = "Select...";
    public static String BPM_DEFAULT_SELECT_IN_DROPDOWN = "select";
    
    public static java.sql.Date BPM_DEFAULT_BASELINE_HISTORY_PROCESS_DATE = java.sql.Date.valueOf("1900-01-01");
    
    public static Integer BPM_ADMIN_COLLECTION_NAME_SIZE = 30;
    public static Integer BPM_ADMIN_COLLECTION_DESC_SIZE = 200;
    
    public static Integer BPM_ADMIN_CONTRIBUTION_DESC_SIZE = 30;
    public static Integer BPM_ADMIN_CONTRIBUTION_INFO_SIZE = 200;
 
    public static String REWARD_STATUS_NOT_FOUND = "STATUS_NOT_FOUND";
    
  //Reward Card Fulfillment Tracking Status - Reward Card Status ID 
    //Luv Group level
    public static String REWARD_CARD_STATUS_TP = "REWARD_CARD_STAT_TP";
    
    //Luv Value level
    public static String AWAITING_ADDRESS = "AWAITING_ADDRESS";
    public static String ADDRESS_VERIFIED = "ADDRESS_VERIFIED";
    public static String ORDERED = "ORDERED";
    public static String ACCEPTED = "ACCEPTED";
    public static String REJECTED = "REJECTED";
    public static String SHIPPED = "SHIPPED";
    
    public static String BPM_ADMIN_EMBOSSED_LINE_TYPES = "EMBOSSED_LINE_TP_CD";
    public static String BPM_ADMIN_REWARD_VENDOR_TYPES = "REWARD_VENDOR_TP";
    
    public static final String REWARD_RUN_FREQUENCY = "REWARD_FRQNCY_ID";
    
    public static final String INCENTIVE_OVRD_TP = "INCENTIVE_OVRD_TP";
    public static final String INCENT_TYPE_PRE_ENROLLMENT = "PRE_ENROLLMENT";
    public static final String INCENT_TYPE_POST_ENROLLMENT = "POST_ENROLLMENT";
    
    
  //Fulfillment routing type
  	public static final String BPM_VAL_FLFLMNT_RTNG_TP_SND_TO_INTELISPEND = "SND_TO_INTELISPEND";
	public static final String BPM_VAL_FLFLMNT_RTNG_TP_SND_TO_CDHP = "SND_TO_CDHP";
	public static final String BPM_VAL_FLFLMNT_RTNG_TP_SND_TO_HPDIT = "SND_TO_HPDIT";
	public static final String BPM_VAL_FLFLMNT_RTNG_TP_SND_TO_EMP_PORTAL = "SND_EMP_PORTAL";
  	
    public static final String REWARD_FULFILL_MANUAL = "MANUAL(N/A)";
    
    public static final String BPM_ADMIN_PROMO_CODE_PREFIX = "PN";
   
    public static final String ACTION_SAVE = "save";
    
    public static final String CONTRIBUTION_AMT_LIMIT = "CNTRBTN_LMT";   
    
    //Benefit Contract Type All under group BEN_CONTRACT_TYPE
    public static final String BEN_CON_ALL = "BEN_CON_ALL";
    
    public static final String MARKET_INDICATOR_DETAIL_TYPE = "BPM_MKT_IND_TP";
    public static final Integer MARKET_INDICATOR_DESC_LENGTH = 200;
    public static final String AUTH_PROMO_SETUP_TYPE = "BPM_AUTH_PROMO_TP";
    public static final String PROGRAM_TYPE_ACTIVATION_STATUS_TYPE = "BPM_PGM_TP_ACTVTN";    
    
    
    public static final Integer BPM_NUMBER_OF_MONTH_CEILING = 24;
    public static final Integer BPM_DAYS_OF_MONTH_CEILING = 31;
    public static final String BPM_BIZ_PROGRAM_STATUS_TEMPLATE = "TEMPLATE";
    public static final String BPM_PART_GROUP_DEFAULT_ALL = "DEFAULT_FOR_ALL";
    
    public static final String ACTIVITY_EVENT_ACTIVE = "ACTIVE";
    public static final String ACTIVITY_EVENT_COMPLETE = "COMPLETE";
    public static final String ACTIVITY_EVENT_FILTERED = "FILTERD_OUT";
    
    public static final String BPM_ADMIN_SITES_SELECTED = "sitesSelected";
    
    public static final String BPM_ADMIN_STATUS_ELIGIBLE = "ELIGIBLE";
    public static final String BPM_ADMIN_CONTRACT_INCENTIVE_STATUS = "BPM_CNTR_INCTV_STS";
    public static final String BPM_ADMIN_INCENTIVE_NOT_ACHIEVED = "INCTV_NOT_ACHIEVED";
    

    public static final String BPM_ADMIN_BUSGODS_REPORT_HANDLING = "BPM_SPC_HNDLR_TP_ID";
    public static final String BPM_ADMIN_REPORT_TYPE_BUSG = "BUSG";
    public static final String BPM_ADMIN_REPORT_TYPE_NONE = "NONE";
    public static final String BPM_ADMIN_DELIVERY_INFO = "DELIVERY_INFO";
    
    public static final String BPM_ADMIN_REPORT_IND_INCLUDE  = "INCL_RPT";
    public static final String BPM_ADMIN_REPORT_IND_EXCLUDE  = "EXCL_RPT";
    
    public static final Integer BPM_ADMIN_MAX_DESCRIPTION_LENGTH = 2000;
    public static final String BPM_ADMIN_DEFAULT_END_DATE = "01/01/9999";
    public static final String BPM_PURCHASER_SUB_TYPES = "PURCH_SUB_TP";
    
    public static final String BPM_ADMIN_ACTV_TP_EMPLOYER_PGM = "EMPLOYER_PGM";
    
    public static final Integer BPM_ADMIN_BIZ_PGM_NO_OF_YEARS_TO_QUERY = 0;
    public static final Integer BPM_ADMIN_BIZ_PGM_NO_OF_DAYS_YEAR = 366;

    public static final String CAREPARTNER_SERVICE_WSDL="CAREPARTNER_WSDL";
    
    public static final Integer PROGRAM_CHANGE_LOG_TEXT_LENGTH = 2000;
    public static final Integer PROGRAM_ENV_CODE_LENGTH = 50;
    public static final Integer PROGRAM_ENV_CODE_VALUE_LENGTH = 200;
    public static final Integer PROGRAM_ENV_CODE_DESC_LENGTH = 300;
    public static final Integer EXTERNAL_EMPLOYER_ACTIVITY_NAME_LENGTH = 100;
    
    public static final String BPM_ADMIN_GRP_NO_FOR_TEMPLATE = "-1";
    public static final String BPM_ADMIN_SITE_NO_FOR_TEMPLATE = "-1";
    
    public static final Integer BPM_ADMIN_ACTIVITY_REPROCESSING_DAYS_LIMIT = 732;
    
    public static final String LUV_GRP_OPTUM = "CNTRL_OPTUM_RPT";
	public static final String GROUP_NAME_WELLSFARGO = "WELLS FARGO & COMPANY";
	public static final String GROUP_NAME_TARGET = "TARGET CORPORATION";	
	public static final String TARGET_FILE_NAME_PREFIX = "hptc";
	public static final String WELLSFARGO_FILE_NAME_PREFIX = "hpwf";
}
