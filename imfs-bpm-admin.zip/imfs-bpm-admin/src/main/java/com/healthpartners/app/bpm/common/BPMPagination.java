package com.healthpartners.app.bpm.common;

import jakarta.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.List;


/**
 * @author tjquist
 * The pagination class supports paging in jsp's where more than "max records per page" of results are returned through a search.  When
 * instantiated, the object stores the resultset of a DTO.  Keeps track of row range and total count of rows in a DTO Arraylist.
 * Back and Next attributes provide a flag that drives how the back and next buttons should appear on a page (ie disabled or enabled).
 * Methods pageback and pagenext control navigation through the DTO arraylist.
 */
public class BPMPagination {
    Integer maxRecsPerPage = 20;
    Integer startPageCt = 0;
    Integer endPageCt = 0;
    String backPageFlag;
    String nextPageFlag;
    String actionType;
    Object objectTypeClass;
    ArrayList<Object> pageList;
    Object pageableObject;

    int startRowNumber = 1;


    public BPMPagination() {
        super();
    }

    /*
     * Constructor for establishing the DTO being used, defaulting page counters, and the disabling of the back button.
     */
	/*
	public BPMPagination(ArrayList<Object> arrayPageList, Object objectTypeClass) {
		
		setObjectTypeClass(objectTypeClass);
		setPageList(arrayPageList);
		setStartPageCt(Integer.valueOf(0));
		setEndPageCt(Integer.valueOf(0));
		disableBackButton();
		
	}
	*/

    public BPMPagination(Object pPageableObject, ArrayList<Object> arrayPageList) {
        pageableObject = pPageableObject;
        setPageList(arrayPageList);
        setStartPageCt(Integer.valueOf(0));
        setEndPageCt(Integer.valueOf(0));
        disableBackButton();
    }

    public BPMPagination(Object pPageableObject, ArrayList<Object> arrayPageList, Integer maxRecsPerPage) {
       this(pPageableObject, arrayPageList);
        this.maxRecsPerPage = maxRecsPerPage;
    }

    public void enableAndDisableButtons() {
        disableBackButtonIfNoMore(getStartPageCt());
        enableBackButtonIfMore(getStartPageCt());

        enableNextButtonIfMore(getEndPageCt());
        disableNextButtonIfNoMore(getEndPageCt());
    }

    /*
     * Enable the back and next flags that is triggered in the jsp.
     */
    public void enableBackNextButtons() {
        setBackPageFlag(BPMAdminConstants.BPM_ADMIN_PAGINATION_BEGIN);
        setNextPageFlag(BPMAdminConstants.BPM_ADMIN_PAGINATION_BEGIN);
    }

    /*
     * Disable the back and next flags that is triggered in the jsp.
     */
    public void disableBackNextButtons() {
        setBackPageFlag(BPMAdminConstants.BPM_ADMIN_PAGINATION_END);
        setNextPageFlag(BPMAdminConstants.BPM_ADMIN_PAGINATION_END);
    }

    /*
     * Disable the next flag that is triggered in the jsp.
     */
    public void disableNextButton() {
        setNextPageFlag(BPMAdminConstants.BPM_ADMIN_PAGINATION_END);
    }

    /*
     * Enable the next flag that is triggered in the jsp.
     */
    public void enableNextButton() {
        setNextPageFlag(BPMAdminConstants.BPM_ADMIN_PAGINATION_BEGIN);
    }

    /*
     * Disable the back flag that is triggered in the jsp.
     */
    public void disableBackButton() {
        setBackPageFlag(BPMAdminConstants.BPM_ADMIN_PAGINATION_END);
    }

    /*
     * Enable the back flag that is triggered in the jsp.
     */
    public void enableBackButton() {
        setBackPageFlag(BPMAdminConstants.BPM_ADMIN_PAGINATION_BEGIN);
    }

    public List moveNext() {
        return this.pageNext();
    }

    public List moveBack() {
        return this.pageBack();
    }

    public List addRowNumbers() {
        //return this.determClassObjectThenAddRowNumbers();
        return null;
    }

    /*
     * Algorithm that navigates BACK through a dto arraylist keeping track of where it begins and ends
     * through the list.
     */
    private List pageBack() {
        ArrayList<Object> arrayListPage = new ArrayList<Object>();

        Integer startPageCtTemp = getStartPageCt();
        Integer endPageCtTemp = getEndPageCt();

        if (startPageCtTemp <= maxRecsPerPage) {
            endPageCtTemp = startPageCtTemp;
            startPageCtTemp = 0;
        } else {
            Integer offset = endPageCtTemp - startPageCtTemp;
            endPageCtTemp = endPageCtTemp - offset;
            startPageCtTemp = startPageCtTemp - maxRecsPerPage;
        }

        setStartPageCt(startPageCtTemp);

        setEndPageCt(endPageCtTemp - 1);

        disableBackButtonIfNoMore(getStartPageCt());
        enableNextButtonIfMore(getEndPageCt());

        //When navigating back through the list, take into account the offset of the list by subtracting
        //a value of 1.  Ex.  If 20 rows per page, represented from 19 to 0.
        while (startPageCtTemp < endPageCtTemp) {
            Object objectRec = pageList.get(startPageCtTemp - 1); //Take into account offset of 1.
            arrayListPage.add(objectRec);
            startPageCtTemp++;

        }
        return arrayListPage;
    }

    /*
     * Algorithm that navigates NEXT through a dto arraylist keeping track of where it begins and ends
     * through the list.
     */
    private List pageNext() {
        ArrayList<Object> arrayListPage = new ArrayList<Object>();

        if (getEndPageCt() != null) {
            setStartPageCt(getEndPageCt());
        }

        Integer endPageCtTemp = null;
        Integer startPageCtTemp = getStartPageCt();

        //Increment by 1 to accomodate for offset which will display to the page the
        //correct starting page value in the detail range.
        setStartPageCt(getStartPageCt() + 1);

        //Determine what the end counter should be to determine where to stop when navigating
        //forward through the list.
        if ((startPageCtTemp + maxRecsPerPage) > this.pageList.size()) {
            endPageCtTemp = this.pageList.size();
        } else {
            endPageCtTemp = startPageCtTemp + maxRecsPerPage;
        }

        //Navigate forward through the list.
        while (startPageCtTemp < endPageCtTemp) {
            Object objectRec = this.pageList.get(startPageCtTemp);
            arrayListPage.add(objectRec);
            startPageCtTemp++;
        }

        setEndPageCt(endPageCtTemp);

        List objectListPage = (List) arrayListPage;

        enableBackButtonIfMore(startPageCtTemp);
        disableNextButtonIfNoMore(getEndPageCt());

        return objectListPage;
    }


    public void setAttributesBackAndNextButtons(HttpServletRequest request) {
        request.setAttribute("backPageFlag", getBackPageFlag());
        request.setAttribute("nextPageFlag", getNextPageFlag());
    }

    public void clear() {
        startPageCt = 0;

        endPageCt = null;
        nextPageFlag = null;
        backPageFlag = null;
    }

    private void disableBackButtonIfNoMore(Integer startPageCt) {
        if (startPageCt == 1) {
            disableBackButton();
        }
    }

    private void enableBackButtonIfMore(Integer startPageCt) {
        if (startPageCt != null && startPageCt > this.maxRecsPerPage) {
            enableBackButton();
        }

    }

    private void disableNextButtonIfNoMore(Integer nextPageCt) {
        if (this.pageList != null && nextPageCt >= this.pageList.size()) {
            disableNextButton();
        }

    }

    private void enableNextButtonIfMore(Integer nextPageCt) {
        if (this.pageList != null && nextPageCt < this.pageList.size()) {
            enableNextButton();
        }

    }

    public Integer getStartPageCt() {

        return startPageCt;
    }

    public void setStartPageCt(Integer startPageCt) {
        this.startPageCt = startPageCt;
    }

    public Integer getEndPageCt() {
        return endPageCt;
    }

    public void setEndPageCt(Integer endPageCt) {
        this.endPageCt = endPageCt;
    }

    public String getBackPageFlag() {
        return backPageFlag;
    }

    public void setBackPageFlag(String backPageFlag) {
        this.backPageFlag = backPageFlag;
    }

    public String getNextPageFlag() {
        return nextPageFlag;
    }

    public void setNextPageFlag(String nextPageFlag) {
        this.nextPageFlag = nextPageFlag;
    }

    public String getActionType() {
        return actionType;
    }

    public void setActionType(String actionType) {
        this.actionType = actionType;
    }


    public ArrayList<Object> getPageList() {
        return pageList;
    }

    public void setPageList(ArrayList<Object> pageList) {
        this.pageList = pageList;
    }


    public Object getObjectTypeClass() {
        return objectTypeClass;
    }

    public void setObjectTypeClass(Object objectTypeClass) {
        this.objectTypeClass = objectTypeClass;
    }
}
