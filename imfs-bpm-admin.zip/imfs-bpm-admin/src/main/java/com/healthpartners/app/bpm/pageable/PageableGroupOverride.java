package com.healthpartners.app.bpm.pageable;

import com.healthpartners.app.bpm.dto.GroupOverride;

import java.util.ArrayList;
import java.util.Iterator;

/**
 * The pageable class serves as a wrapper for the array list of objects, and
 * operations that are performed on those objects. For ex. adding a row number
 * for display.
 * The BPMPagination then has a pointer to an instance of this class.
 *
 * @author jxbourbour
 */
public class PageableGroupOverride implements BPMPageable {
    ArrayList<GroupOverride> groupOverrides;

    public PageableGroupOverride() {
        super();
    }

    public PageableGroupOverride(ArrayList<GroupOverride> pGroupOverrides) {
        groupOverrides = pGroupOverrides;
    }

    public ArrayList<GroupOverride> getGroupOverrides() {
        return groupOverrides;
    }

    public void setGroupOverrides(ArrayList<GroupOverride> groupOverrides) {
        this.groupOverrides = groupOverrides;
    }

    public void addRowNumber() {
        int startRowNumber = 1;
        Iterator<GroupOverride> iter = (Iterator<GroupOverride>) groupOverrides.iterator();
        while (iter.hasNext()) {
            GroupOverride groupSiteException = (GroupOverride) iter.next();
            groupSiteException.setRowNumber(startRowNumber);
            startRowNumber++;
        }
    }
}
