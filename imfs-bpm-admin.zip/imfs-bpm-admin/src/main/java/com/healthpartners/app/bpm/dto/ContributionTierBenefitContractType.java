package com.healthpartners.app.bpm.dto;

import java.io.Serializable;
import java.util.Collection;

public class ContributionTierBenefitContractType implements Serializable {
    static final long serialVersionUID = 0L;
    Collection<ContributionTierBenefitContractTypeRelationship> contributionTierBenefitContractTypeRelationships;
    Collection<ContributionTierBenefitContractTypeRelationship> availableContributionTierBenefitContractTypeRelationships;
    private Integer tierValueID;
    private Integer tierTypeID;
    private Integer benefitContractTypeID;
    private String luvGroup;
    private String luvValue;
    private String luvDesc;
    private boolean used;


    public ContributionTierBenefitContractType() {
        super();
    }


    public Integer getTierValueID() {
        return tierValueID;
    }


    public void setTierValueID(Integer tierValueID) {
        this.tierValueID = tierValueID;
    }


    public Integer getTierTypeID() {
        return tierTypeID;
    }


    public void setTierTypeID(Integer tierTypeID) {
        this.tierTypeID = tierTypeID;
    }


    public Integer getBenefitContractTypeID() {
        return benefitContractTypeID;
    }


    public void setBenefitContractTypeID(Integer benefitContractTypeID) {
        this.benefitContractTypeID = benefitContractTypeID;
    }


    public String getLuvGroup() {
        return luvGroup;
    }


    public void setLuvGroup(String luvGroup) {
        this.luvGroup = luvGroup;
    }


    public String getLuvValue() {
        return luvValue;
    }


    public void setLuvValue(String luvValue) {
        this.luvValue = luvValue;
    }


    public String getLuvDesc() {
        return luvDesc;
    }


    public void setLuvDesc(String luvDesc) {
        this.luvDesc = luvDesc;
    }


    public boolean isUsed() {
        return used;
    }


    public void setUsed(boolean used) {
        this.used = used;
    }


    public Collection<ContributionTierBenefitContractTypeRelationship> getContributionTierBenefitContractTypeRelationships() {
        return contributionTierBenefitContractTypeRelationships;
    }


    public void setContributionTierBenefitContractTypeRelationships(
            Collection<ContributionTierBenefitContractTypeRelationship> contributionTierBenefitContractTypeRelationships) {
        this.contributionTierBenefitContractTypeRelationships = contributionTierBenefitContractTypeRelationships;
    }


    public Collection<ContributionTierBenefitContractTypeRelationship> getAvailableContributionTierBenefitContractTypeRelationships() {
        return availableContributionTierBenefitContractTypeRelationships;
    }


    public void setAvailableContributionTierBenefitContractTypeRelationships(
            Collection<ContributionTierBenefitContractTypeRelationship> availableContributionTierBenefitContractTypeRelationships) {
        this.availableContributionTierBenefitContractTypeRelationships = availableContributionTierBenefitContractTypeRelationships;
    }


}
