package com.healthpartners.app.bpm.form;


/**
 * @author jxbourbour
 */
public class SaveProgramCheckmarksForm extends BaseForm {

    private String actionType;
    private Integer programID;
    private Integer[] checkmarkIDs;
    private String[] checkmarkNames;
    private String[] checkmarkInfos;
    private String[] effectiveDates;
    private String[] endDates;
    private String recalculate;
    private Integer[] participationGroupIDs;
    private Integer programCheckmarkAddRemove;
    private Integer[] programIncentiveOptionIDs;
    private Integer[] programCheckmarkIDs;

    private Integer groupID;
    private Integer subGroupID;
    private String programTypeCodeID;
    private String groupNumber;
    private String groupName;
    private String siteNumber;
    private String siteName;

    private Integer activityID;

    private Integer qualificationCheckmarkID;

    public SaveProgramCheckmarksForm() {
        super();
    }


    public String getActionType() {
        return actionType;
    }


    public void setActionType(String actionType) {
        this.actionType = actionType;
    }


    public Integer getProgramID() {
        return programID;
    }


    public void setProgramID(Integer programID) {
        this.programID = programID;
    }


    public Integer[] getCheckmarkIDs() {
        return checkmarkIDs;
    }


    public void setCheckmarkIDs(Integer[] checkmarkIDs) {
        this.checkmarkIDs = checkmarkIDs;
    }


    public String getRecalculate() {
        return recalculate;
    }


    public void setRecalculate(String recalculate) {
        this.recalculate = recalculate;
    }


    public String[] getEffectiveDates() {
        return effectiveDates;
    }


    public void setEffectiveDates(String[] effectiveDates) {
        this.effectiveDates = effectiveDates;
    }


    public String[] getEndDates() {
        return endDates;
    }


    public void setEndDates(String[] endDates) {
        this.endDates = endDates;
    }

    public final String[] getCheckmarkNames() {
        return checkmarkNames;
    }


    public final void setCheckmarkNames(String[] checkmarkNames) {
        this.checkmarkNames = checkmarkNames;
    }


    public final Integer[] getParticipationGroupIDs() {
        return participationGroupIDs;
    }


    public final void setParticipationGroupIDs(Integer[] participationGroupIDs) {
        this.participationGroupIDs = participationGroupIDs;
    }


    public Integer getProgramCheckmarkAddRemove() {
        return programCheckmarkAddRemove;
    }

    public void setProgramCheckmarkAddRemove(Integer programCheckmarkAddRemove) {
        this.programCheckmarkAddRemove = programCheckmarkAddRemove;
    }

    public String[] getCheckmarkInfos() {
        return checkmarkInfos;
    }

    public void setCheckmarkInfos(String[] checkmarkInfos) {
        this.checkmarkInfos = checkmarkInfos;
    }

    public Integer getGroupID() {
        return groupID;
    }

    public void setGroupID(Integer groupID) {
        this.groupID = groupID;
    }


    public Integer[] getProgramIncentiveOptionIDs() {
        return programIncentiveOptionIDs;
    }


    public void setProgramIncentiveOptionIDs(Integer[] programIncentiveOptionIDs) {
        this.programIncentiveOptionIDs = programIncentiveOptionIDs;
    }


    public Integer[] getProgramCheckmarkIDs() {
        return programCheckmarkIDs;
    }


    public void setProgramCheckmarkIDs(Integer[] programCheckmarkIDs) {
        this.programCheckmarkIDs = programCheckmarkIDs;
    }

    public Integer getSubGroupID() {
        return subGroupID;
    }

    public void setSubGroupID(Integer subGroupID) {
        this.subGroupID = subGroupID;
    }

    public String getProgramTypeCodeID() {
        return programTypeCodeID;
    }

    public void setProgramTypeCodeID(String programTypeCodeID) {
        this.programTypeCodeID = programTypeCodeID;
    }

    public String getGroupNumber() {
        return groupNumber;
    }

    public void setGroupNumber(String groupNumber) {
        this.groupNumber = groupNumber;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public String getSiteNumber() {
        return siteNumber;
    }

    public void setSiteNumber(String siteNumber) {
        this.siteNumber = siteNumber;
    }

    public String getSiteName() {
        return siteName;
    }

    public void setSiteName(String siteName) {
        this.siteName = siteName;
    }

    public Integer getActivityID() {
        return activityID;
    }

    public void setActivityID(Integer activityID) {
        this.activityID = activityID;
    }

    public Integer getQualificationCheckmarkID() {
        return qualificationCheckmarkID;
    }

    public void setQualificationCheckmarkID(Integer qualificationCheckmarkID) {
        this.qualificationCheckmarkID = qualificationCheckmarkID;
    }
}
