package com.healthpartners.app.bpm.controller;

import com.healthpartners.app.bpm.common.BPMAdminConstants;
import com.healthpartners.app.bpm.common.BPMAdminUtils;
import com.healthpartners.app.bpm.dto.BaselineHistory;
import com.healthpartners.app.bpm.exception.BPMException;
import com.healthpartners.app.bpm.form.BaselineHistorySearchForm;
import com.healthpartners.app.bpm.iface.BusinessProgramService;
import com.healthpartners.app.bpm.iface.LookUpValueService;
import com.healthpartners.app.bpm.iface.MemberService;
import org.apache.commons.lang.StringUtils;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.ArrayList;
import java.util.Collection;

@Controller
public class BaselineHistoryController extends BaseController implements Validator {

    private final LookUpValueService lookUpValueService;
    private final BusinessProgramService businessProgramService;
    private final MemberService memberService;

    public BaselineHistoryController(LookUpValueService lookUpValueService, BusinessProgramService businessProgramService, MemberService memberService) {
        this.lookUpValueService = lookUpValueService;
        this.businessProgramService = businessProgramService;
        this.memberService = memberService;
    }

    @GetMapping("/baselineHistorySearch")
    public String loadSearch(ModelMap modelMap) {
        BaselineHistorySearchForm baselineHistorySearchForm = new BaselineHistorySearchForm();
        modelMap.put("baselineHistorySearchForm", baselineHistorySearchForm);
        return "baselineHistorySearch";
    }

    @PostMapping("/baselineHistorySearch")
    public String submitSearch(@ModelAttribute("baselineHistorySearchForm") BaselineHistorySearchForm form, ModelMap modelMap, BindingResult result) throws Exception {
        try {
            if (StringUtils.isEmpty(form.getActionType())) {
                form.setActionType(ACTION_SEARCH);
            }
            if (ACTION_SEARCH.equals(form.getActionType())) {
                validate(form, result);
            }
            if (!result.hasErrors()) {
                return searchAndRefreshActivityHistory(form, modelMap);
            }
        } catch (Exception e) {
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
            // Add error stack trace on the request, to be hidden in html.
            createErrorMessageOnModel(modelMap, getStackTrace(e));
        }

        return "baselineHistorySearch";
    }

    private String searchAndRefreshActivityHistory(BaselineHistorySearchForm form, ModelMap modelMap) throws BPMException, DataAccessException {
        refreshSearchResults(form, modelMap);
        return "baselineHistory";
    }

    private void refreshSearchResults(BaselineHistorySearchForm form, ModelMap modelMap) throws BPMException, DataAccessException {
        try {
            String memberID = form.getMemberID();
            Integer contractNo = form.getContractNo();

            String programEffectiveDate = form.getProgramEffectiveDate();
            String lEligibilityHistoryResults = form.getEligibilityHistoryResults();
            java.sql.Date lProgramEffetiveDate = null;

            if (programEffectiveDate != null) {
                lProgramEffetiveDate = BPMAdminUtils.convertStringToSqlDate(programEffectiveDate, BPMAdminConstants.HP_BPM_ADMIN_UI_COMMON_DATE_FORMAT);
            }

            Collection<BaselineHistory> lBaselineHistoryList = memberService.getBaselineHistory(memberID, contractNo, lProgramEffetiveDate, lEligibilityHistoryResults);

            if (lBaselineHistoryList == null) {
                createActionMessagesOnModel(modelMap, "messages.nosearchresults", null);
            } else {
                if (lBaselineHistoryList.size() > 0) {
                    BaselineHistory memberBaselineHistory = lBaselineHistoryList.iterator().next();
                    modelMap.put("memberID", memberBaselineHistory.getMemberID());
                    modelMap.put("displayName", memberBaselineHistory.getFirstName() + " " + memberBaselineHistory.getLastName());
                    modelMap.put("birthDate", getFmt().format(memberBaselineHistory.getBirthDate()));
                }
            }

            modelMap.put("baselineHistoryList", lBaselineHistoryList);

        } catch (Exception e) {
            throw new BPMException(e);
        }
    }

    @Override
    public boolean supports(Class<?> clazz) {
        return BaselineHistorySearchForm.class.isAssignableFrom(clazz);
    }

    @Override
    public void validate(Object target, Errors errors) {
        BaselineHistorySearchForm form = (BaselineHistorySearchForm) target;

        if ((form.getMemberID() == null || form.getMemberID().length() <= 0) && (form.getContractNo() == null || form.getContractNo() <= 0)) {
            getValidationSupport().validateOneRequiredFieldIsSelected("memberID", form.getMemberID(), errors, new Object[]{"search parameter"});
        }

        if (form.getProgramEffectiveDate() != null && form.getProgramEffectiveDate().trim().length() > 0) {
            getValidationSupport().validateDateFormat("programEffectiveDate", form.getProgramEffectiveDate(), errors, new Object[]{"Program Effective Date"});
        }
    }
}
