package com.healthpartners.app.bpm.dto;

import java.io.Serializable;
import java.sql.Date;

/**
 * Represents an Employer Group. 
 */
public class EmployerGroup implements Serializable
{	
	static final long serialVersionUID = 0L;

	private Integer groupID;
	private Integer subgroupID;
	
	private String groupNumber;
	private String groupName;
	
	private String siteNumber;
	private String siteName;
	
	private String packageNumber;
	private String packageName;		
	private Date newHireDate;
	
	private Date qualificationStartDate;
	private Date effectiveDate;
	
	private String groupReportName;
	private String groupAbbreviatedName;
	
	private String siteReportName;
	private String siteAbbreviatedName;
	
	private Integer rowNumber;
	private String hasProgram;
	private Integer programID;
	private String businessProgramName;

	public EmployerGroup() 
	{
		super();
	}

	public String getGroupName() {
		return groupName;
	}


	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}


	public String getGroupNumber() {
		return groupNumber;
	}


	public void setGroupNumber(String groupNumber) {
		this.groupNumber = groupNumber;
	}


	public String getPackageName() {
		return packageName;
	}


	public void setPackageName(String packageName) {
		this.packageName = packageName;
	}


	public String getPackageNumber() {
		return packageNumber;
	}


	public void setPackageNumber(String packageNumber) {
		this.packageNumber = packageNumber;
	}


	public String getSiteName() {
		return siteName;
	}


	public void setSiteName(String siteName) {
		this.siteName = siteName;
	}


	public String getSiteNumber() {
		return siteNumber;
	}


	public void setSiteNumber(String siteNumber) {
		this.siteNumber = siteNumber;
	}

	public Date getNewHireDate() {
		return newHireDate;
	}

	public void setNewHireDate(Date newHireDate) {
		this.newHireDate = newHireDate;
	}

	public Integer getGroupID() {
		return groupID;
	}

	public void setGroupID(Integer groupID) {
		this.groupID = groupID;
	}

	public Integer getSubgroupID() {
		return subgroupID;
	}

	public void setSubgroupID(Integer subgroupID) {
		this.subgroupID = subgroupID;
	}

	public Date getQualificationStartDate() {
		return qualificationStartDate;
	}

	public void setQualificationStartDate(Date qualificationStartDate) {
		this.qualificationStartDate = qualificationStartDate;
	}

	public String getGroupAbbreviatedName() {
		return groupAbbreviatedName;
	}

	public void setGroupAbbreviatedName(String groupAbbreviatedName) {
		this.groupAbbreviatedName = groupAbbreviatedName;
	}

	public String getGroupReportName() {
		return groupReportName;
	}

	public void setGroupReportName(String groupReportName) {
		this.groupReportName = groupReportName;
	}

	public String getSiteAbbreviatedName() {
		return siteAbbreviatedName;
	}

	public void setSiteAbbreviatedName(String siteAbbreviatedName) {
		this.siteAbbreviatedName = siteAbbreviatedName;
	}

	public String getSiteReportName() {
		return siteReportName;
	}

	public void setSiteReportName(String siteReportName) {
		this.siteReportName = siteReportName;
	}
	public Integer getRowNumber() {
		return rowNumber;
	}

	public void setRowNumber(Integer rowNumber) {
		this.rowNumber = rowNumber;
	}

	public final String getHasProgram() {
		return hasProgram;
	}

	public final void setHasProgram(String hasProgram) {
		this.hasProgram = hasProgram;
	}

	public Date getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public String getBusinessProgramName() {
		return businessProgramName;
	}

	public void setBusinessProgramName(String businessProgramName) {
		this.businessProgramName = businessProgramName;
	}

	public Integer getProgramID() {
		return programID;
	}

	public void setProgramID(Integer programID) {
		this.programID = programID;
	}

	
}
