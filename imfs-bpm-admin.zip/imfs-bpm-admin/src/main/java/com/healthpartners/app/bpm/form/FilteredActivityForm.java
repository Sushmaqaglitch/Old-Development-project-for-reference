package com.healthpartners.app.bpm.form;


/**
 * @author f5929
 * 
 */
public class FilteredActivityForm extends BaseForm {

	static final long serialVersionUID = 0L;	

	private String memberID;
	private String insertDate;
	private String operationType;
	private Integer groupID;
	private String filteredOutOnly;
	private Integer activityID;
	private String statusToProcess;
	private int[] programIDs;

	private int[] currentMemberStatuses;
	private String[] newMemberStatuses;

	private int[] currentContractStatuses;
	private String[] newContractStatuses;

	private boolean[] memberStatusCalcDatePassed;
	private boolean[] contractStatusCalcDatePassed;

	private String[] participationEndDates;

	public FilteredActivityForm() {
		super();
	}

	public String getMemberID() {
		if(memberID != null)
		{
			return memberID.trim();
		}
		return memberID;
	}

	public void setMemberID(String memberID) {
		this.memberID = memberID;
	}

	public String getInsertDate() {
		return insertDate;
	}

	public void setInsertDate(String insertDate) {
		this.insertDate = insertDate;
	}

	public String getOperationType() {
		return operationType;
	}

	public void setOperationType(String operationType) {
		this.operationType = operationType;
	}

	public final Integer getGroupID() {
		return groupID;
	}

	public final void setGroupID(Integer groupID) {
		this.groupID = groupID;
	}

	public final String getFilteredOutOnly() {
		return filteredOutOnly;
	}

	public final void setFilteredOutOnly(String filteredOutOnly) {
		this.filteredOutOnly = filteredOutOnly;
	}

	public Integer getActivityID() {
		return activityID;
	}

	public void setActivityID(Integer activityID) {
		this.activityID = activityID;
	}

	public String getStatusToProcess() {
		return statusToProcess;
	}

	public void setStatusToProcess(String statusToProcess) {
		this.statusToProcess = statusToProcess;
	}

	public int[] getProgramIDs() {
		return programIDs;
	}

	public void setProgramIDs(int[] programIDs) {
		this.programIDs = programIDs;
	}

	public int[] getCurrentMemberStatuses() {
		return currentMemberStatuses;
	}

	public void setCurrentMemberStatuses(int[] currentMemberStatuses) {
		this.currentMemberStatuses = currentMemberStatuses;
	}

	public String[] getNewMemberStatuses() {
		return newMemberStatuses;
	}

	public void setNewMemberStatuses(String[] newMemberStatuses) {
		this.newMemberStatuses = newMemberStatuses;
	}

	public int[] getCurrentContractStatuses() {
		return currentContractStatuses;
	}

	public void setCurrentContractStatuses(int[] currentContractStatuses) {
		this.currentContractStatuses = currentContractStatuses;
	}

	public String[] getNewContractStatuses() {
		return newContractStatuses;
	}

	public void setNewContractStatuses(String[] newContractStatuses) {
		this.newContractStatuses = newContractStatuses;
	}

	public boolean[] getMemberStatusCalcDatePassed() {
		return memberStatusCalcDatePassed;
	}

	public void setMemberStatusCalcDatePassed(boolean[] memberStatusCalcDatePassed) {
		this.memberStatusCalcDatePassed = memberStatusCalcDatePassed;
	}

	public boolean[] getContractStatusCalcDatePassed() {
		return contractStatusCalcDatePassed;
	}

	public void setContractStatusCalcDatePassed(boolean[] contractStatusCalcDatePassed) {
		this.contractStatusCalcDatePassed = contractStatusCalcDatePassed;
	}

	public String[] getParticipationEndDates() {
		return participationEndDates;
	}

	public void setParticipationEndDates(String[] participationEndDates) {
		this.participationEndDates = participationEndDates;
	}

	public void reset() {
		this.memberID = null;
		this.insertDate = null;
		this.operationType = null;
	}
}
