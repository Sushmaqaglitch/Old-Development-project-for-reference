package com.healthpartners.app.bpm.controller;

import com.healthpartners.app.bpm.common.BPMAdminConstants;
import com.healthpartners.app.bpm.dto.EmployerGroup;
import com.healthpartners.app.bpm.dto.ProgramChangeLog;
import com.healthpartners.app.bpm.exception.BPMException;
import com.healthpartners.app.bpm.form.ProgramChangeLogForm;
import com.healthpartners.app.bpm.form.SaveProgramActivitySiteForm;
import com.healthpartners.app.bpm.iface.BusinessProgramService;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.view.RedirectView;

import java.util.ArrayList;
import java.util.Collection;

import static org.apache.commons.lang.exception.ExceptionUtils.getStackTrace;

@Controller
public class ProgramChangeLogController extends BaseController implements Validator {

    private static final String ACTION_SAVE = "save";
    private static final String ACTION_SAVE_TO_ALL_SITES = "saveToAllSites";
    private static final String ACTION_SAVE_TO_SELECTED = "saveToSelected";

    private final Log logger = LogFactory.getLog(getClass());

    private final BusinessProgramService businessProgramService;


    public ProgramChangeLogController(BusinessProgramService businessProgramService) {
        this.businessProgramService = businessProgramService;
    }

    @PostMapping(value = "/saveProgramChangeLog", params = "cancel")
    public RedirectView submitCancelChangeLog(@ModelAttribute("programChangeLogForm") ProgramChangeLogForm form, RedirectAttributes ra) {
        ra.addFlashAttribute("groupNumber", getUserSession().getGroupNo());
        String url = "viewProgram?programID=" + form.getProgramID();
        return new RedirectView(url);
    }

    @PostMapping(value = "/saveProgramChangeLog")
    public String submitChangeLog(@ModelAttribute("programChangeLogForm") ProgramChangeLogForm form, ModelMap modelMap, BindingResult result, RedirectAttributes ra) {
        try {
            if (ACTION_SAVE.equals(form.getActionType()) || ACTION_SAVE_TO_ALL_SITES.equals(form.getActionType()) || ACTION_SAVE_TO_SELECTED.equals(form.getActionType())) {
                validate(form, result);
                if (result.hasErrors()) {
                    populateRequest(modelMap);
                    return "programChangeLog";
                } else {
                    return performSave(modelMap, ra, form);
                }
            }

        } catch (Exception e) {
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
            createErrorMessageOnModel(modelMap, getStackTrace(e));
        }

        return "programChangeLog";
    }

    private void populateRequest(ModelMap modelMap) {
        modelMap.put("programID", getUserSession().getBusinessProgram().getProgramID());
        modelMap.put("businessProgram", getUserSession().getBusinessProgram());
        modelMap.put("changeLogList", businessProgramService.getBusinessProgramChangeLog(getUserSession().getBusinessProgram().getProgramID()));
    }

    private String performSave(ModelMap modelMap, RedirectAttributes ra, ProgramChangeLogForm form) throws Exception {
        String userID = getUserSessionSupport().getAuthenticatedUsername();

        populateRequest(modelMap);

        if (ACTION_SAVE.equals(form.getActionType())) {
            saveChangeLog(form, userID);

        } else if (ACTION_SAVE_TO_ALL_SITES.equals(form.getActionType())) {
            saveToAllSites(form, userID);

        } else if (ACTION_SAVE_TO_SELECTED.equals(form.getActionType())) {
            saveToSelectedSites(modelMap, form, userID);
            return "programActivitySites";
        }

        // Redirect back to the viewProgram screen upon successful process of saves
        ra.addFlashAttribute("groupNumber", form.getGroupNumber());
        String url = "viewProgram?programID=" + form.getProgramID();
        return "redirect:" + url;
    }

    private void saveChangeLog(ProgramChangeLogForm form, String pUserID) throws Exception {
        ProgramChangeLog lProgramChangeLog = new ProgramChangeLog();
        lProgramChangeLog.setProgramID(form.getProgramID());
        lProgramChangeLog.setChangeText(form.getChangeText());
        businessProgramService.insertProgramChangeLog(lProgramChangeLog, pUserID);
    }

    private void saveToAllSites(ProgramChangeLogForm form, String pUserID) throws Exception {
        businessProgramService.saveChangeLogToAllSites(getUserSession().getBusinessProgram(), form.getChangeText(), pUserID);
    }

    private void saveToSelectedSites(ModelMap modelMap, ProgramChangeLogForm form, String pUserID) throws BPMException {
        if (getUserSession().getAvailableSites() != null) {
            getUserSession().getAvailableSites().clear();
        }

        if (getUserSession().getEmployerSubGroups() != null) {
            getUserSession().getEmployerSubGroups().clear();
        }

        getUserSession().setChangeLogText(form.getChangeText());

        Collection<EmployerGroup> lSubGroups = businessProgramService.getBusinessProgramInSameYear(getUserSession().getBusinessProgram().getProgramID());

        SaveProgramActivitySiteForm saveProgramActivitySiteForm = new SaveProgramActivitySiteForm();
        saveProgramActivitySiteForm.setSubGroupID(((ArrayList<EmployerGroup>) lSubGroups).get(0).getSubgroupID());
        modelMap.put("saveProgramActivitySiteForm", saveProgramActivitySiteForm);

        modelMap.put("selectedSubGroups", lSubGroups);
        modelMap.put("changeLogText", form.getChangeText());
        getUserSession().setChangeLogText(form.getChangeText());

        getUserSession().setEmployerSubGroups((ArrayList<EmployerGroup>) lSubGroups);
        getUserSession().setWhichSaveSelectedSite(WHICH_SAVE_SELECTED_SITES_CHANGE_LOG);
    }

    @Override
    public boolean supports(Class<?> clazz) {
        return ProgramChangeLogForm.class.isAssignableFrom(clazz);
    }

    @Override
    public void validate(Object target, Errors errors) {
        ProgramChangeLogForm form = (ProgramChangeLogForm) target;

        if (form.getChangeText() != null && form.getChangeText().length() > 0) {
            if (form.getChangeText().trim().length() > BPMAdminConstants.PROGRAM_CHANGE_LOG_TEXT_LENGTH) {
                getValidationSupport().addValidationFailureMessage("changeText", errors, "errors.maxlength", new Object[]{"Change Text", BPMAdminConstants.PROGRAM_CHANGE_LOG_TEXT_LENGTH});
            }
        } else {
            getValidationSupport().validateRequiredFieldIsNotEmpty("changeText", form.getChangeText(), errors, new Object[]{"Change Text"});
        }
    }

}
