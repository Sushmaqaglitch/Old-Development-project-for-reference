package com.healthpartners.app.bpm.dao;

import com.healthpartners.app.bpm.dto.*;
import com.healthpartners.app.bpm.exception.BPMException;
import org.springframework.dao.DataAccessException;

import java.sql.Date;
import java.util.Collection;

public interface BusinessProgramDAO {
	Collection<String> getAllStartDates() throws BPMException, DataAccessException;

	Collection<EmployerGroup> getGroupsByName(String pGroupName) throws DataAccessException;

	Collection<EmployerGroup> getAllGroupSites(String pGroupNo) throws DataAccessException;

	Collection<ExemptionHistory> getExemptionHistory(String pGroupNo
			, java.sql.Date pProgramEffectiveDate
			, String pSiteNo
			, String pExemptionTypeCode
			, String pContractNo
			, String pMemberNo
			, java.sql.Date pExemptionFromDate
			, java.sql.Date pExemptionToDate) throws DataAccessException;

	Collection<BusinessProgram> getActiveNWithdrawnBusinessPrograms(
			Date pTargetQualificationDate,
			String pGroupNo,
			String SiteIDNo, Integer pGroupID);

	Collection<Integer> getNumberOfMembers(Integer pProgramID) throws BPMException, DataAccessException;

	Collection<EmployerGroup> getGroups(String pGroupNumber) throws DataAccessException;

	Collection<EmployerGroup> getSubGroups(Integer pGroupID);

	Collection<ProgramType> getProgramTypes();

	BusinessProgram getBusinessProgram(Integer pProgramID, boolean all);

	int insertBusinessProgram(BusinessProgram pBusinessProgram, String lUserID);
	int updateBusinessProgram(BusinessProgram pBusinessProgram, String lUserID);

	int updateGroupNames(BusinessProgram pBusinessProgram, String lUserID) throws DataAccessException;

	int updateSiteNames(BusinessProgram pBusinessProgram, String lUserID) throws DataAccessException;

	Collection<EmployerGroup> getParticipatingSubGroups(Integer pGroupID);

	int deleteEmptyBusinessProgram(Integer pProgramID);

	Collection<BusinessProgram> getBusinessProgramsActive(
			Date pTargetQualificationDate,
			String pGroupNo,
			String SiteIDNo);

	Collection<Integer> getNumberOfTerminatedMembers(Integer pProgramID)
			throws BPMException, DataAccessException;

	int updateAllGroupSiteMembers(Integer pProcessID, Integer pProgramID) throws BPMException, DataAccessException;

	Collection<BusinessProgram> getProgramTemplates(Integer pProgramID) throws BPMException, DataAccessException;

	Collection<BenefitPackage> getBenefitPackages(Integer pProgramID) throws DataAccessException;

	Collection<ProgramChangeLog> getBusinessProgramChangeLog(Integer pProgramID) throws DataAccessException;

	Collection<BusinessProgram> getBusinessPrograms(Integer pGroupID, Integer pSubgroupID) throws BPMException, DataAccessException;

	Collection<BusinessProgram> getBusinessPrograms(Date pTargetQualificationDate, Integer pGroupID, Integer pSubgroupID) throws BPMException, DataAccessException;

	Collection<EmployerGroup> getBusinessProgramInSameYear(Integer pBusinessProgramID) throws DataAccessException;

	int updatePackageID(BusinessProgram pBusinessProgram, String lUserID);

	int insertProgramChangeLog(ProgramChangeLog pProgramChangeLog, String pUserID) throws DataAccessException;;

    Collection<EmployerGroup> getAllBPMGroups();
	Collection<EmployerGroup> getBPMGroupsForMemberAndTransactionDate(String memberId, Date transactionDate)
			throws BPMException, DataAccessException;
}
