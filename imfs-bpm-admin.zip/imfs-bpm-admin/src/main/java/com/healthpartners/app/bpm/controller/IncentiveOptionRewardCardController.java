package com.healthpartners.app.bpm.controller;

import com.healthpartners.app.bpm.common.BPMAdminConstants;
import com.healthpartners.app.bpm.dto.*;
import com.healthpartners.app.bpm.exception.BPMException;
import com.healthpartners.app.bpm.form.AddInctvOptionRewardCardForm;
import com.healthpartners.app.bpm.form.SaveInctvOptionRewardCardForm;
import com.healthpartners.app.bpm.iface.RewardCardService;
import com.healthpartners.app.bpm.session.UserSession;
import jakarta.servlet.http.HttpServletRequest;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.view.RedirectView;

import java.util.ArrayList;
import java.util.Collection;

import static com.healthpartners.app.bpm.common.BPMAdminConstants.ACTION_SAVE;
import static com.healthpartners.app.bpm.common.BPMAdminUtils.convertStringToSqlDate;

@Controller
public class IncentiveOptionRewardCardController extends BaseController implements Validator {

    private RewardCardService rewardCardService;

    protected final Log logger = LogFactory.getLog(this.getClass());

    public IncentiveOptionRewardCardController(RewardCardService rewardCardService) {
        this.rewardCardService = rewardCardService;
    }


    @GetMapping("/showIncentiveOptionRewardCards")
    public String load(ModelMap modelMap,  HttpServletRequest request) throws Exception {
        AddInctvOptionRewardCardForm form = new AddInctvOptionRewardCardForm();
        Collection<IncentiveOptionRewardCard> lIncentiveOptionRewardCards =
                rewardCardService.getIncentiveOptionRewardCardTypes();

        getUserSession().setIncentiveOptionRewardCardTypes((ArrayList<IncentiveOptionRewardCard>)lIncentiveOptionRewardCards);

        modelMap.put("inctvOptionRewardCards", getUserSession().getIncentiveOptionRewardCardTypes());
        modelMap.put("addInctvOptionRewardCardForm", form);
        populateRequest(request);
        return "inctvOptionRewardCardList";
    }
    @PostMapping("/addInctvOptionRewardCard")
    public String addIncentive(@ModelAttribute("addInctvOptionRewardCardForm") AddInctvOptionRewardCardForm form,
                               ModelMap modelMap, HttpServletRequest request) throws  Exception {
        IncentiveOptionRewardCard lIncentiveOptionRewardCard = null;
        if (StringUtils.isEmpty(form.getActionType())) {
            form.setActionType(ACTION_ADD);
        }
        if (ACTION_ADD.equals(form.getActionType())) {
            lIncentiveOptionRewardCard = new IncentiveOptionRewardCard();
            // Set the ID of the new object to 0. An ID will be assigned using a
            // database sequence upon Insert.
            lIncentiveOptionRewardCard.setIncentiveOptionRewardCardID(0);

        }


        modelMap.put("inctvOptionRewardCard", lIncentiveOptionRewardCard);
        populateRequestForRewardCard(request, getUserSession(), modelMap);
        SaveInctvOptionRewardCardForm saveInctvOptionRewardCardForm = new SaveInctvOptionRewardCardForm();
        modelMap.put("saveInctvOptionRewardCardForm", saveInctvOptionRewardCardForm);
        return "editInctvOptionRewardCard";
    }


    @GetMapping("/addInctvOptionRewardCard")
    public String editOrDeleteInctvOptionReward(@ModelAttribute("saveInctvOptionRewardCardForm") SaveInctvOptionRewardCardForm form,
                                              ModelMap modelMap, HttpServletRequest request,
                                              @RequestParam(name = "actionType") String actionType,
                                              @RequestParam(name = "ID") Integer id ) {
        IncentiveOptionRewardCard lIncentiveOptionRewardCard = null;
        try {
            form.setActionType(actionType);
            if(ACTION_EDIT.equalsIgnoreCase(form.getActionType()))
            {
                lIncentiveOptionRewardCard = editAction(id);
                form.setPreviousActionType("edit");
                form.setIncentiveOptionRewardCardName(lIncentiveOptionRewardCard.getIncentiveOptionRewardCardName());
                form.setIncentiveOptionRewardCardDesc(lIncentiveOptionRewardCard.getIncentiveOptionRewardCardDesc());
                form.setEffectiveDate(getFmt().format(lIncentiveOptionRewardCard.getEffectiveDate()));
                form.setEndDate(getFmt().format(lIncentiveOptionRewardCard.getEndDate()));
                modelMap.put("inctvOptionRewardCard", lIncentiveOptionRewardCard);
                populateRequestForRewardCard(request, getUserSession(), modelMap);
                modelMap.put("saveInctvOptionRewardCardForm", form);
                return "editInctvOptionRewardCard";
            }
            else if(ACTION_DELETE.equalsIgnoreCase(form.getActionType()))
            {
                deleteAction(id);
                modelMap.put("inctvOptionRewardCards", getUserSession().getIncentiveOptionRewardCardTypes());
                modelMap.put("inctvOptionRewardCard", lIncentiveOptionRewardCard);
                populateRequestForRewardCard(request, getUserSession(), modelMap);
                modelMap.put("saveInctvOptionRewardCardForm", form);
                return "redirect: showIncentiveOptionRewardCards";
            }
        } catch (Exception e) {
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
            createErrorMessageOnModel(modelMap, getStackTrace(e));
        }
        return null;
    }
    @PostMapping(value = "/saveInctvOptionRewardCard")
    public String submitIncntvOptionRewardCard(@ModelAttribute("saveInctvOptionRewardCardForm") SaveInctvOptionRewardCardForm form, ModelMap modelMap, BindingResult result, HttpServletRequest request, RedirectAttributes ra) {
        try {
            if (ACTION_SAVE.equals(form.getActionType())) {
                validate(form, result);
                if (result.hasErrors()) {
                    clearAllData(form);
                    populateRequest(request);
                    return "editInctvOptionRewardCard";
                } else {
                    return performSave(modelMap, form, result, request, ra);
                }
            }
        } catch (Exception e) {
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
            createErrorMessageOnModel(modelMap, getStackTrace(e));
        }

        // Add package also forwards to the same jsp.
        return "inctvOptionRewardCardList";
    }

    @PostMapping(value = "/saveInctvOptionRewardCard", params = "cancel")
    public RedirectView submitCancelInctvOptionRewardCard(@ModelAttribute("saveInctvOptionRewardCardForm") SaveInctvOptionRewardCardForm form, ModelMap modelMap) {
        try {

                modelMap.put("inctvOptionRewardCards", getUserSession().getIncentiveOptionRewardCardTypes());
                clearAllData(form);

        } catch (Exception e) {
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
        }

        String url = "showIncentiveOptionRewardCards";
        return new RedirectView(url);
    }

    @Override
    public boolean supports(Class<?> clazz) {
        return false;
    }

    @Override
    public void validate(Object target, Errors errors) {
        SaveInctvOptionRewardCardForm form = (SaveInctvOptionRewardCardForm) target;
            boolean lEffectiveDateValid = getValidationSupport().validateDateFormat("effectiveDate", form.getEffectiveDate(), errors, new Object[]{"Effective Date"});
            boolean lEndDateValid = getValidationSupport().validateDateFormat("endDate", form.getEndDate(), errors, new Object[]{"End Date"});

            if(lEffectiveDateValid && lEndDateValid)
            {
                getValidationSupport().validateBeforeOnly("effectiveDate", form.getEffectiveDate(), form.getEndDate(), "effectiveDate", errors, new Object[]{"Effective Date","End Date"});
            }

            getValidationSupport().validateNotNull("incentiveOptionRewardCardName", form.getIncentiveOptionRewardCardName(), errors, new Object[]{"Incentive Option Reward Card Name"});

            getValidationSupport().validateNotNull("rewardCardID", String.valueOf(form.getRewardCardID()), errors, new Object[]{"Reward Card"});
        getValidationSupport().validateNotNull("rewardCardFeeID", String.valueOf(form.getRewardCardFeeID()), errors, new Object[]{"Reward Card Fee"});
        getValidationSupport().validateNotNull("rewardEmbossedLineID", String.valueOf(form.getRewardEmbossedLineID()), errors, new Object[]{"Reward Card Embossed Line"});
        getValidationSupport().validateNotNull("rewardCarrierMessageID", String.valueOf(form.getRewardCarrierMessageID()), errors, new Object[]{"Reward Card Carrier Message"});
        getValidationSupport().validateNotNull("rewardTransactionMessageID", String.valueOf(form.getRewardTransactionMessageID()), errors, new Object[]{"Reward Card Transaction Message"});
        getValidationSupport().validateNotNull("rewardCardClientContactID", String.valueOf(form.getRewardCardClientContactID()), errors, new Object[]{"Reward Card Client Contact"});

        }

    public static void populateRequestForRewardCard(HttpServletRequest request, UserSession userSession, ModelMap modelMap)
    {
        modelMap.put("rewardCards", userSession.getRewardCardTypes());
        modelMap.put("rewardCardFees", userSession.getRewardCardFees());
        modelMap.put("rewardEmbossedLines", userSession.getRewardEmbossedLines());
        modelMap.put("rewardCarrierMessages", userSession.getRewardCarrierMessages());
        modelMap.put("rewardTransactionMessages", userSession.getRewardTransactionMessages());
        modelMap.put("rewardCardClientDataList", userSession.getRewardCardClientDataList());
    }
    protected void populateRequest(HttpServletRequest request)
    {
        getUserSession().reset();

        ArrayList<RewardCard> lRewardCards = (ArrayList<RewardCard>)
                rewardCardService.getRewardCardTypes();

        ArrayList<RewardCardFee> lRewardCardFees = (ArrayList<RewardCardFee>)
                rewardCardService.getRewardCardFeeTypes();

        ArrayList<RewardEmbossedLine> lRewardEmbossedLineTypes = (ArrayList<RewardEmbossedLine>)
                rewardCardService.getRewardCardEmbossedLineTypes();

        ArrayList<RewardCarrierMessage> lRewardCarrierMessageTypes = (ArrayList<RewardCarrierMessage>)
                rewardCardService.getRewardCardCarrierMessageTypes();

        ArrayList<RewardTransactionMessage> lRewardTransactionMessageTypes = (ArrayList<RewardTransactionMessage>)
                rewardCardService.getRewardCardTransMsgTypes();

        ArrayList<RewardCardClientData> lRewardCardClientDataList = (ArrayList<RewardCardClientData>)
                rewardCardService.getRewardCardClientInfo();


        getUserSession().setRewardCardTypes(lRewardCards);
        getUserSession().setRewardCardFees(lRewardCardFees);
        getUserSession().setRewardEmbossedLines(lRewardEmbossedLineTypes);
        getUserSession().setRewardCarrierMessages(lRewardCarrierMessageTypes);
        getUserSession().setRewardTransactionMessages(lRewardTransactionMessageTypes);
        getUserSession().setRewardCardClientDataList(lRewardCardClientDataList);

        request.setAttribute("rewardCards", lRewardCards);
        request.setAttribute("rewardCardFees", lRewardCardFees);
        request.setAttribute("rewardEmbossedLines", lRewardEmbossedLineTypes);
        request.setAttribute("rewardCarrierMessages", lRewardCarrierMessageTypes);
        request.setAttribute("rewardTransactionMessages", lRewardTransactionMessageTypes);
        request.setAttribute("rewardCardClientDataList", lRewardCardClientDataList);
    }

    private String performSave(ModelMap modelMap, SaveInctvOptionRewardCardForm lSaveInctvOptionRewardCardForm, BindingResult result, HttpServletRequest request, RedirectAttributes ra) throws Exception {
        String lUserID = getUserSessionSupport().getAuthenticatedUsername();

        String actionType = lSaveInctvOptionRewardCardForm.getActionType();

        IncentiveOptionRewardCard lIncentiveOptionRewardCard = new IncentiveOptionRewardCard();

        lIncentiveOptionRewardCard.setIncentiveOptionRewardCardID(lSaveInctvOptionRewardCardForm.getIncentiveOptionRewardCardID());
        lIncentiveOptionRewardCard.setIncentiveOptionRewardCardName(lSaveInctvOptionRewardCardForm.getIncentiveOptionRewardCardName());
        lIncentiveOptionRewardCard.setIncentiveOptionRewardCardDesc(lSaveInctvOptionRewardCardForm.getIncentiveOptionRewardCardDesc());

        lIncentiveOptionRewardCard.setRewardCardFeeID(lSaveInctvOptionRewardCardForm.getRewardCardFeeID());
        lIncentiveOptionRewardCard.setRewardCardID(lSaveInctvOptionRewardCardForm.getRewardCardID());
        lIncentiveOptionRewardCard.setRewardEmbossedLineID(lSaveInctvOptionRewardCardForm.getRewardEmbossedLineID());
        lIncentiveOptionRewardCard.setRewardCarrierMessageID(lSaveInctvOptionRewardCardForm.getRewardCarrierMessageID());
        lIncentiveOptionRewardCard.setRewardTransactionMessageID(lSaveInctvOptionRewardCardForm.getRewardTransactionMessageID());
        lIncentiveOptionRewardCard.setRewardCardClientContactID(lSaveInctvOptionRewardCardForm.getRewardCardClientContactID());

        lIncentiveOptionRewardCard.setEffectiveDate(convertStringToSqlDate(lSaveInctvOptionRewardCardForm.getEffectiveDate()
                , BPMAdminConstants.HP_BPM_ADMIN_UI_COMMON_DATE_FORMAT));
        lIncentiveOptionRewardCard.setEndDate(convertStringToSqlDate(lSaveInctvOptionRewardCardForm.getEndDate()
                , BPMAdminConstants.HP_BPM_ADMIN_UI_COMMON_DATE_FORMAT));

        //validate(lSaveInctvOptionRewardCardForm,result);

        if (!result.hasErrors()) {
            modelMap.put("inctvOptionRewardCard", lIncentiveOptionRewardCard);
            populateRequest(request);
        }

        // Dates have been validated
        lIncentiveOptionRewardCard.setEffectiveDate(new java.sql.Date(getFmt().parse(lSaveInctvOptionRewardCardForm.getEffectiveDate()).getTime()));
        lIncentiveOptionRewardCard.setEndDate(new java.sql.Date(getFmt().parse(lSaveInctvOptionRewardCardForm.getEndDate()).getTime()));

        // Save here (update will check for insert or update in the DAO)
        rewardCardService.updateIncentiveOptionRewardCard(lIncentiveOptionRewardCard, lUserID);

        // After save, fetch a list from the database.
        Collection<IncentiveOptionRewardCard> lIncentiveOptionRewardCards =
                rewardCardService.getIncentiveOptionRewardCardTypes();

        getUserSession().setIncentiveOptionRewardCardTypes((ArrayList<IncentiveOptionRewardCard>)lIncentiveOptionRewardCards);

        modelMap.put("inctvOptionRewardCards", getUserSession().getIncentiveOptionRewardCardTypes());

        clearAllData(lSaveInctvOptionRewardCardForm);

        populateRequest(request);
        return "redirect: showIncentiveOptionRewardCards";
    }

    protected void clearAllData(SaveInctvOptionRewardCardForm pSaveInctvOptionRewardCardForm)
    {
        clearFormParameters(pSaveInctvOptionRewardCardForm);
    }
    protected void clearFormParameters(SaveInctvOptionRewardCardForm pSaveInctvOptionRewardCardForm)
    {
        pSaveInctvOptionRewardCardForm.setActionType(null);
    }
    protected IncentiveOptionRewardCard editAction(Integer id)
    {
        ArrayList<IncentiveOptionRewardCard> lIncentiveOptionRewardCards = (ArrayList<IncentiveOptionRewardCard>) getUserSession().getIncentiveOptionRewardCardTypes();

        for(IncentiveOptionRewardCard lIncentiveOptionRewardCard : lIncentiveOptionRewardCards)
        {
            if(lIncentiveOptionRewardCard.getIncentiveOptionRewardCardID().intValue() == id.intValue())
            {
                return lIncentiveOptionRewardCard;
            }
        }

        return null;
    }

    protected void deleteAction(Integer id)
            throws BPMException
    {
        ArrayList<IncentiveOptionRewardCard> lIncentiveOptionRewardCards = (ArrayList<IncentiveOptionRewardCard>) getUserSession().getIncentiveOptionRewardCardTypes();

        for(IncentiveOptionRewardCard lIncentiveOptionRewardCard : lIncentiveOptionRewardCards)
        {
            if(lIncentiveOptionRewardCard.getIncentiveOptionRewardCardID().intValue() == id.intValue())
            {
                rewardCardService.deleteIncentiveOptionRewardCard(id);
                break;
            }
        }

        if(getUserSession().getIncentiveOptionRewardCardTypes() != null)
        {
            getUserSession().getIncentiveOptionRewardCardTypes().clear();
        }
        getUserSession().setIncentiveOptionRewardCardTypes((ArrayList<IncentiveOptionRewardCard>)rewardCardService.getIncentiveOptionRewardCardTypes());
    }

}
