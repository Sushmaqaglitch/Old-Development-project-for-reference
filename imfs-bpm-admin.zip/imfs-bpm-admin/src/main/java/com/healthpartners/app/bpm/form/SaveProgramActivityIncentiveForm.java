/**
 * 
 */
package com.healthpartners.app.bpm.form;

/**
 * @author tjquist
 *
 */
public class SaveProgramActivityIncentiveForm extends BaseForm {

	static final long serialVersionUID = 0L;

	private Integer[] rowIDs;
	
	private Integer programID;	
	private Integer incentiveOptionID;
	private Integer requirementID;
	private Integer rowID;
	private Integer activityRowID;
	private Integer relRowID;
	private Integer activityIncentiveID;
	
	private String[] incentiveOptionIDs;
	private String[] programIncentiveOptionStatusIDs;
	private Integer[] groupRequirementIDs;
	
	
	private String[] activityTypeCodeIDs;
	private String[] activityIDs;
	private String[]  collectionIDs;
	
	private String[][] relationshipIDs;
	private String[] activityIncentiveTypeIDs;
	private String[] activityIncentedStatusIDs;
	private String[] requiredQuantities;
	private String[][] incentiveQuantities;
 		
    private Integer groupID;
       	
	public SaveProgramActivityIncentiveForm() {
		super();
	}

	public String[] getIncentiveOptionIDs() {
		return incentiveOptionIDs;
	}

	public void setIncentiveOptionIDs(String[] incentiveOptionIDs) {
		this.incentiveOptionIDs = incentiveOptionIDs;
	}

	public String[] getProgramIncentiveOptionStatusIDs() {
		return programIncentiveOptionStatusIDs;
	}

	public void setProgramIncentiveOptionStatusIDs(
			String[] programIncentiveOptionStatusIDs) {
		this.programIncentiveOptionStatusIDs = programIncentiveOptionStatusIDs;
	}

	public String[] getActivityTypeCodeIDs() {
		return activityTypeCodeIDs;
	}

	public void setActivityTypeCodeIDs(String[] activityTypeCodeIDs) {
		this.activityTypeCodeIDs = activityTypeCodeIDs;
	}

	public String[] getActivityIDs() {
		return activityIDs;
	}

	public void setActivityIDs(String[] activityIDs) {
		this.activityIDs = activityIDs;
	}

	public String[][] getRelationshipIDs() {
		return relationshipIDs;
	}

	public void setRelationshipIDs(String[][] relationshipIDs) {
		this.relationshipIDs = relationshipIDs;
	}

	public String[] getActivityIncentiveTypeIDs() {
		return activityIncentiveTypeIDs;
	}

	public void setActivityIncentiveTypeIDs(String[] activityIncentiveTypeIDs) {
		this.activityIncentiveTypeIDs = activityIncentiveTypeIDs;
	}

	

	public String[] getActivityIncentedStatusIDs() {
		return activityIncentedStatusIDs;
	}

	public void setActivityIncentedStatusIDs(String[] activityIncentedStatusIDs) {
		this.activityIncentedStatusIDs = activityIncentedStatusIDs;
	}

	public String[][] getIncentiveQuantities() {
		return incentiveQuantities;
	}

	public void setIncentiveQuantities(String[][] incentiveQuantities) {
		this.incentiveQuantities = incentiveQuantities;
	}

	public Integer[] getGroupRequirementIDs() {
		return groupRequirementIDs;
	}

	public void setGroupRequirementIDs(Integer[] groupRequirementIDs) {
		this.groupRequirementIDs = groupRequirementIDs;
	}

	public Integer getIncentiveOptionID() {
		return incentiveOptionID;
	}

	public void setIncentiveOptionID(Integer incentiveOptionID) {
		this.incentiveOptionID = incentiveOptionID;
	}

	public Integer getProgramID() {
		return programID;
	}

	public void setProgramID(Integer programID) {
		this.programID = programID;
	}

	public Integer getRequirementID() {
		return requirementID;
	}

	public void setRequirementID(Integer requirementID) {
		this.requirementID = requirementID;
	}

	public Integer[] getRowIDs() {
		return rowIDs;
	}

	public void setRowIDs(Integer[] rowIDs) {
		this.rowIDs = rowIDs;
	}

	public Integer getRowID() {
		return rowID;
	}

	public void setRowID(Integer rowID) {
		this.rowID = rowID;
	}

	public Integer getActivityIncentiveID() {
		return activityIncentiveID;
	}

	public void setActivityIncentiveID(Integer activityIncentiveID) {
		this.activityIncentiveID = activityIncentiveID;
	}

	public Integer getRelRowID() {
		return relRowID;
	}

	public void setRelRowID(Integer relRowID) {
		this.relRowID = relRowID;
	}

	public Integer getActivityRowID() {
		return activityRowID;
	}

	public void setActivityRowID(Integer activityRowID) {
		this.activityRowID = activityRowID;
	}

	public String[] getRequiredQuantities() {
		return requiredQuantities;
	}

	public void setRequiredQuantities(String[] requiredQuantities) {
		this.requiredQuantities = requiredQuantities;
	}

	public final String[] getCollectionIDs() {
		return collectionIDs;
	}

	public final void setCollectionIDs(String[] collectionIDs) {
		this.collectionIDs = collectionIDs;
	}

	public Integer getGroupID() {
		return groupID;
	}

	public void setGroupID(Integer groupID) {
		this.groupID = groupID;
	}

	
	
	
}
