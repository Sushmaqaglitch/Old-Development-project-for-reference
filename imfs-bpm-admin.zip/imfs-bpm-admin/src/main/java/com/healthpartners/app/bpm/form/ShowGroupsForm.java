package com.healthpartners.app.bpm.form;

/**
 * @author jxbourbour
 *
 */
public class ShowGroupsForm extends BaseForm {
	private String groupNumber;
	private String groupName;
	private String groupID;
	
//	public ActionMessages validateForGroupSearch(ActionMapping mapping,
//			HttpServletRequest request)
//	{
//		if(groupName == null || groupName.trim().length() <= 0)
//		{
//			validateBothNotNull("groupNumber", groupNumber, groupName, "Group Number and Group ID");
//		}
//
//		if(groupName != null && groupNumber != null
//				&& groupName.trim().length() > 0
//				&& groupNumber.trim().length() > 0)
//		{
//			getActionMessages().add("groupNumber", new ActionError(
//					"errors.groupNameOrNumber", ""));
//		}
//
//		validateNotSpecialChar("groupNumber", groupNumber, "Group Number");
//		validateNotSpecialChar("groupName", groupName, "Group Name ");
//
//		return getActionMessages();
//	}

	public ShowGroupsForm() {
		super();
	}

	public String getGroupNumber() {
		return groupNumber;
	}

	public void setGroupNumber(String groupNumber) {
		this.groupNumber = groupNumber;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public String getGroupID() {
		return groupID;
	}

	public void setGroupID(String groupID) {
		this.groupID = groupID;
	}
}
