package com.healthpartners.app.bpm.dto;

import java.io.Serializable;

public class MemberPackage implements Serializable
{	
	static final long serialVersionUID = 0L;
	
	private Integer businessProgramID;
	private Integer packageID;
	private String packageCode;
	private String packageName;
	private String packageType;
	private String purchaserSubTypeName;
	private java.sql.Date effectiveDate;
	private java.sql.Date endDate;
	
	
	public MemberPackage()
	{
		super();
	}


	public Integer getBusinessProgramID() {
		return businessProgramID;
	}


	public void setBusinessProgramID(Integer businessProgramID) {
		this.businessProgramID = businessProgramID;
	}


	public Integer getPackageID() {
		return packageID;
	}


	public void setPackageID(Integer packageID) {
		this.packageID = packageID;
	}


	public String getPackageCode() {
		return packageCode;
	}


	public void setPackageCode(String packageCode) {
		this.packageCode = packageCode;
	}


	public String getPurchaserSubTypeName() {
		return purchaserSubTypeName;
	}


	public void setPurchaserSubTypeName(String purchaserSubTypeName) {
		this.purchaserSubTypeName = purchaserSubTypeName;
	}


	public java.sql.Date getEffectiveDate() {
		return effectiveDate;
	}


	public void setEffectiveDate(java.sql.Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}


	public java.sql.Date getEndDate() {
		return endDate;
	}


	public void setEndDate(java.sql.Date endDate) {
		this.endDate = endDate;
	}


	public String getPackageName() {
		return packageName;
	}


	public void setPackageName(String packageName) {
		this.packageName = packageName;
	}


	public String getPackageType() {
		return packageType;
	}


	public void setPackageType(String packageType) {
		this.packageType = packageType;
	}


	
}
