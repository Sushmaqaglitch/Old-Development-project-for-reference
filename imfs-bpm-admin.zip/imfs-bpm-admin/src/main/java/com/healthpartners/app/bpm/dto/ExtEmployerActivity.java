package com.healthpartners.app.bpm.dto;

import java.io.Serializable;

public class ExtEmployerActivity implements Serializable {
    static final long serialVersionUID = 0L;

    private Integer groupID;
    private String groupNo;
    private Integer activityID;
    private String sourceActivityID;
    private String externalActivityName;
    private java.sql.Date effectiveDate;
    private java.sql.Date endDate;

    public ExtEmployerActivity() {
        super();
    }

    public Integer getGroupID() {
        return groupID;
    }

    public void setGroupID(Integer groupID) {
        this.groupID = groupID;
    }

    public String getGroupNo() {
        return groupNo;
    }

    public void setGroupNo(String groupNo) {
        this.groupNo = groupNo;
    }

    public Integer getActivityID() {
        return activityID;
    }

    public void setActivityID(Integer activityID) {
        this.activityID = activityID;
    }

    public String getSourceActivityID() {
        return sourceActivityID;
    }

    public void setSourceActivityID(String sourceActivityID) {
        this.sourceActivityID = sourceActivityID;
    }

    public String getExternalActivityName() {
        return externalActivityName;
    }

    public void setExternalActivityName(String externalActivityName) {
        this.externalActivityName = externalActivityName;
    }

    public java.sql.Date getEffectiveDate() {
        return effectiveDate;
    }

    public void setEffectiveDate(java.sql.Date effectiveDate) {
        this.effectiveDate = effectiveDate;
    }

    public java.sql.Date getEndDate() {
        return endDate;
    }

    public void setEndDate(java.sql.Date endDate) {
        this.endDate = endDate;
    }


}
