/* $Id$ */

package com.healthpartners.app.bpm.dao;

import com.healthpartners.app.bpm.dto.BPMAuditRecord;
import com.healthpartners.app.bpm.exception.BPMException;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.jdbc.support.incrementer.DataFieldMaxValueIncrementer;
import org.springframework.jdbc.support.incrementer.OracleSequenceMaxValueIncrementer;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import jakarta.annotation.PostConstruct;
import javax.sql.DataSource;
import java.sql.Types;
import java.util.Date;

@Repository
@Transactional(timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
public class AuditLogDAOJdbc extends JdbcDaoSupport implements AuditLogDAO {

	/*
	 * Audit Log SQL statements
	 */
	
	private static final String insertAuditLog = "INSERT INTO AUDIT_LOG (AUDIT_LOG_ID, INSERT_TS, MODIFY_TS, APPLICATION_ID, APPLICATION_EVENT_ID, APPLICATION_EVENT_RESULT_ID, PARM_1_ID, PARM_2_ID, PARM_3_ID, PARM_4_ID) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

	private static final String SEQUENCE = "audit_log_seq";
	/*
	 * SQL sequences
	 */
	
	private DataFieldMaxValueIncrementer auditLogIdIncrementer;

	private final DataSource dataSource;

	public AuditLogDAOJdbc (DataSource dataSource) {
		this.dataSource = dataSource;
	}


	@PostConstruct
	private void initialize() {
		setDataSource(dataSource);
		auditLogIdIncrementer = new OracleSequenceMaxValueIncrementer(dataSource, SEQUENCE);
	}

	/**
	 * @see AuditLogDAO#insertAuditLog(BPMAuditRecord)
	 */
	//Produces warnings during compile time to quickly identify typos or API changes
		@Override
	public Integer insertAuditLog(BPMAuditRecord bpmAuditRecord)
			throws DataAccessException {
		// Retrieve the next sequence number for the audit log entry.
		Integer auditLogId = Integer.valueOf(auditLogIdIncrementer.nextIntValue());

		// Persist the audit log entry.
		JdbcTemplate template = getJdbcTemplate();
		Date logDate = new Date();
		Object params[] = new Object[] {
				auditLogId,
				logDate, // Insert date/time stamp
				logDate, // Modify date/time stamp
				bpmAuditRecord.getApplicationId(),
				bpmAuditRecord.getApplicationEvent(),
				bpmAuditRecord.getEventResult(), bpmAuditRecord.getParam1(),
				bpmAuditRecord.getParam2(), bpmAuditRecord.getParam3(),
				bpmAuditRecord.getParam4() };
		int types[] = new int[] { Types.INTEGER, Types.TIMESTAMP,
				Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR,
				Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR };
		template.update(insertAuditLog, params, types);

		return auditLogId;
	}
}
