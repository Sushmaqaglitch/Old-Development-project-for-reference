package com.healthpartners.app.bpm.pageable;

import com.healthpartners.app.bpm.dto.PersonContractRecycle;

import java.util.ArrayList;
import java.util.Iterator;

/**
 * The pageable class serves as a wrapper for the array list of objects, and
 * operations that are performed on those objects. For ex. adding a row number
 * for display.
 * The BPMPagination then has a pointer to an instance of this class.
 *
 * @author jxbourbour
 */
public class PageablePersonContractRecycle implements BPMPageable {
    ArrayList<PersonContractRecycle> personContractRecycles;

    public PageablePersonContractRecycle() {
        super();
    }

    public PageablePersonContractRecycle(ArrayList<PersonContractRecycle> pPersonContractRecycles) {
        personContractRecycles = pPersonContractRecycles;
    }

    public ArrayList<PersonContractRecycle> getPersonContractRecycles() {
        return personContractRecycles;
    }

    public void setPersonContractRecycles(
            ArrayList<PersonContractRecycle> personContractRecycles) {
        this.personContractRecycles = personContractRecycles;
    }

    public void addRowNumber() {
        int startRowNumber = 1;
        Iterator<PersonContractRecycle> iter = (Iterator<PersonContractRecycle>) personContractRecycles.iterator();
        while (iter.hasNext()) {
            PersonContractRecycle personContractRecycle = (PersonContractRecycle) iter.next();
            personContractRecycle.setRowNumber(startRowNumber);
            startRowNumber++;
        }
    }

}
