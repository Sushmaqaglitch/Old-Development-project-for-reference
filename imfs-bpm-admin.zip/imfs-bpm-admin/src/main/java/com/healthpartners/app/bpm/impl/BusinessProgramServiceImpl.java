package com.healthpartners.app.bpm.impl;

import com.healthpartners.app.bpm.common.BPMAdminConstants;
import com.healthpartners.app.bpm.common.BPMAdminEmailUtility;
import com.healthpartners.app.bpm.common.BPMAdminUtils;
import com.healthpartners.app.bpm.dao.*;
import com.healthpartners.app.bpm.dto.*;
import com.healthpartners.app.bpm.exception.BPMException;
import com.healthpartners.app.bpm.iface.BusinessProgramService;
import com.healthpartners.app.bpm.iface.MemberService;
import com.healthpartners.app.bpm.iface.RewardCardService;
import com.healthpartners.service.bpm.rules.StatusCalculationCommand;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.DefaultTransactionDefinition;

import java.io.IOException;
import java.sql.Date;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.*;

@Service
public class BusinessProgramServiceImpl implements BusinessProgramService {
    protected final Log logger = LogFactory.getLog(getClass());

    private final ActivityDAO activityDAO;
    private final UserAccessDAO userAccessDAO;

    private final LookUpValueDAO lookUpValueDAO;

    private final BusinessProgramDAO businessProgramDAO;

    private final QualificationCheckmarkDAO qualificationCheckmarkDAO;

    private final ContributionTierDAO contributionTierDAO;

    private final QualificationOverrideDAO qualificationOverrideDAO;

    private final PersonDAO personDAO;

    private final ContractDAO contractDAO;

    private final IncentiveOptionDAO incentiveOptionDAO;

    private final AdditionalInfoDAO additionalInfoDAO;

    private final ActivityIncentiveDAO activityIncentiveDAO;
    private final ContributionGridDAO contributionGridDAO;
    private final RewardCardService rewardCardService;
    private final RewardCardDAO rewardCardDAO;
    private final MemberService memberService;
    private final BPMAdminEmailUtility bpmAdminEmailUtility;
    private final ParticipationGroupDAO participationGroupDAO;
    private final IncentivePackageRuleDAO incentivePackageRuleDAO;
    private final ProgramPackageDAO programPackageDAO;
    private final CollectionDAO collectionDAO;
    private final RiskDAO riskDAO;
    private final GroupOverrideDAO groupOverrideDAO;
    private final EmployerRecycleDAO employerRecycleDAO;
    private final DataSourceTransactionManager txManager;

    public BusinessProgramServiceImpl(ActivityDAO activityDAO, UserAccessDAO userAccessDAO, LookUpValueDAO lookUpValueDAO, BusinessProgramDAO businessProgramDAO, QualificationCheckmarkDAO qualificationCheckmarkDAO, DataSourceTransactionManager txManager,
    ContributionTierDAO contributionTierDAO, QualificationOverrideDAO qualificationOverrideDAO, PersonDAO personDAO, ContractDAO contractDAO, IncentiveOptionDAO incentiveOptionDAO, AdditionalInfoDAO additionalInfoDAO, ActivityIncentiveDAO activityIncentiveDAO, ContributionGridDAO contributionGridDAO,
                                      RewardCardService rewardCardService, RewardCardDAO rewardCardDAO, MemberService memberService, BPMAdminEmailUtility bpmAdminEmailUtility,
                                      ParticipationGroupDAO participationGroupDAO, IncentivePackageRuleDAO incentivePackageRuleDAO, ProgramPackageDAO programPackageDAO, CollectionDAO collectionDAO, RiskDAO riskDAO, GroupOverrideDAO groupOverrideDAO, EmployerRecycleDAO employerRecycleDAO) {
        this.activityDAO = activityDAO;
        this.userAccessDAO = userAccessDAO;
        this.lookUpValueDAO = lookUpValueDAO;
        this.businessProgramDAO = businessProgramDAO;
        this.qualificationCheckmarkDAO = qualificationCheckmarkDAO;
        this.contributionTierDAO = contributionTierDAO;
        this.qualificationOverrideDAO = qualificationOverrideDAO;
        this.personDAO = personDAO;
        this.contractDAO = contractDAO;
        this.incentiveOptionDAO = incentiveOptionDAO;
        this.additionalInfoDAO = additionalInfoDAO;
        this.activityIncentiveDAO  = activityIncentiveDAO;
        this.contributionGridDAO = contributionGridDAO;
        this.txManager = txManager;
        this.rewardCardService = rewardCardService;
        this.rewardCardDAO = rewardCardDAO;
        this.memberService = memberService;
        this.bpmAdminEmailUtility = bpmAdminEmailUtility;
        this.participationGroupDAO = participationGroupDAO;
        this.incentivePackageRuleDAO = incentivePackageRuleDAO;
        this.programPackageDAO = programPackageDAO;
        this.collectionDAO = collectionDAO;
        this.riskDAO = riskDAO;
        this.groupOverrideDAO = groupOverrideDAO;
        this.employerRecycleDAO = employerRecycleDAO;
    }

    public Collection<Activity> selectActivities() throws BPMException,
            DataAccessException {
        return getActivityDAO().selectActivities();
    }

    public Collection<Activity> selectAllActivities() throws BPMException,
            DataAccessException {
        return getActivityDAO().selectAllActivities();
    }

    public Collection<Activity> selectExpiredActivities() throws BPMException,
            DataAccessException {
        return getActivityDAO().selectExpiredActivities();
    }

    public Collection<UserAccess> getUserAccessList(String lUserName)
            throws BPMException, DataAccessException {
        return userAccessDAO.getUserAccessList(lUserName);
    }

    public LookUpValueCode getDatabaseEnvironment() throws BPMException,
            DataAccessException {
        ArrayList<LookUpValueCode> results = (ArrayList<LookUpValueCode>) lookUpValueDAO
                .getLUVCodesByGroup(BPMAdminConstants.BPM_ADMIN_DB_ENV);

        LookUpValueCode lLookUpValueCode = (LookUpValueCode) results.get(0);
        return lLookUpValueCode;
    }

    public Activity selectActivity(int activityId) throws BPMException,
            DataAccessException {
        return getActivityDAO().selectActivity(activityId);
    }

    public int deleteActivity(int activityId) throws BPMException, DataAccessException {
        DefaultTransactionDefinition def = new DefaultTransactionDefinition();
        def.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRED);
        TransactionStatus status = txManager.getTransaction(def);
        int lNumberDeleted = 0;
        try {
            lNumberDeleted = activityDAO.deleteActivity(activityId);
            txManager.commit(status);

        } catch (DataAccessException dae) {
            // Rollback the transaction on error.
            txManager.rollback(status);
            logger.error("An unexpected error has occured: " + dae.getMessage(), dae);
            throw dae;

        } catch (Exception e) {
            // Rollback the transaction on error.
            txManager.rollback(status);
            logger.error("An unexpected error has occured: " + e.getMessage(), e);
            throw new BPMException(e);
        }

        return lNumberDeleted;
    }

    public Collection<LookUpValueCode> getActivityTypeCodes()
            throws BPMException, DataAccessException {
        ArrayList<LookUpValueCode> results = (ArrayList<LookUpValueCode>) lookUpValueDAO
                .getLUVCodesByGroup(BPMAdminConstants.BPM_LUV_ACTIVITY_TYPE);

        return results;
    }

    public LookUpValueCode getActivityTypeCodeById(Integer id)
            throws BPMException, DataAccessException {
        LookUpValueCode results = lookUpValueDAO.getLUVCodeById(id);

        return results;
    }

    public int updateActivity(Activity activity) throws BPMException,
            DataAccessException {
        DefaultTransactionDefinition def = new DefaultTransactionDefinition();
        def.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRED);
        TransactionStatus status = txManager.getTransaction(def);
        int lNumberUpdated = 0;
        try {
            lNumberUpdated = activityDAO.updateActivity(activity);

            txManager.commit(status);
        } catch (DataAccessException dae) {
            // Rollback the transaction on error.
            txManager.rollback(status);
            logger
                    .error("An unexpected error has occured: "
                            + dae.getMessage(), dae);
            throw dae;
        } catch (Exception e) {
            // Rollback the transaction on error.
            txManager.rollback(status);
            logger.error("An unexpected error has occured: " + e.getMessage(),
                    e);
            throw new BPMException(e);
        }

        return lNumberUpdated;
    }

    public Collection<Activity> getActivities() throws BPMException, DataAccessException {
        return getActivityDAO().selectActivities();
    }

    public Collection<String> getAllStartDates() throws BPMException, DataAccessException {
        return businessProgramDAO.getAllStartDates();
    }

    public Collection<EmployerGroup> getGroupsByName(String pGroupName) throws BPMException, DataAccessException {
        return businessProgramDAO.getGroupsByName(pGroupName);
    }

    public Collection<EmployerGroup> getAllGroupSites(String pGroupNo) throws BPMException, DataAccessException {
        return businessProgramDAO.getAllGroupSites(pGroupNo);
    }

    public Collection<LookUpValueCode> getExemptionTypeCodes() throws BPMException, DataAccessException {
         return lookUpValueDAO.getLUVCodesByGroup(BPMAdminConstants.BPM_EXEMPTION_TYPE_CODE);
    }

    public Collection<ExemptionHistory> getExemptionHistory(String pGroupNo,
                                                            java.sql.Date pProgramEffectiveDate, String pSiteNo,
                                                            String pExemptionTypeCode, String pContractNo, String pMemberNo,
                                                            java.sql.Date pExemptionFromDate, java.sql.Date pExemptionToDate)
            throws BPMException, DataAccessException {
        return businessProgramDAO.getExemptionHistory(pGroupNo,
                pProgramEffectiveDate, pSiteNo, pExemptionTypeCode,
                pContractNo, pMemberNo,
                pExemptionFromDate, pExemptionToDate);
    }

    public Collection<BusinessProgram> getActiveNWithdrawnBusinessPrograms(String pGroupNo, String pSiteNo, Integer pGroupID, Date pQualificationStartDate) throws BPMException, DataAccessException {
        ArrayList<BusinessProgram> lBusinessPrograms = (ArrayList<BusinessProgram>) businessProgramDAO.getActiveNWithdrawnBusinessPrograms(pQualificationStartDate, pGroupNo, null, pGroupID);

        Calendar lToday = Calendar.getInstance();
        Calendar lEffectiveDate = Calendar.getInstance();

        for (int i = 0; i < lBusinessPrograms.size(); i++) {
            BusinessProgram lBusinessProgram = (BusinessProgram) lBusinessPrograms
                    .get(i);
            lBusinessProgram.setHasMembers(false);

            lEffectiveDate.setTime(lBusinessProgram.getEffectiveDate());

            if (BPMAdminUtils.getDaysBetweenDates(lEffectiveDate, lToday) <= BPMAdminConstants.BPM_ADMIN_BIZ_PGM_NO_OF_DAYS_YEAR) {
                ArrayList<Integer> lNumberOfMembers = (ArrayList<Integer>) businessProgramDAO.getNumberOfMembers(lBusinessProgram.getProgramID());

                if (lNumberOfMembers.size() > 0) {
                    Integer lMemberCount = (Integer) lNumberOfMembers.get(0);
                    if (lMemberCount > 0) {
                        lBusinessProgram.setHasMembers(true);
                    }
                    lBusinessProgram.setNumberOfMembers(lMemberCount);
                }
            } else {
                lBusinessProgram.setHasMembers(true);
            }
        }

        return lBusinessPrograms;
    }

    @Override
    public boolean isEligibleActivityUsedByParticipant(EligibleActivity pEligibleActivity) throws BPMException, DataAccessException {
        return activityDAO.isEligibleActivityUsedByParticipant(pEligibleActivity);
    }

    public Collection<EmployerGroup> getGroups(String pGroupNumber) throws BPMException, DataAccessException {
        return businessProgramDAO.getGroups(pGroupNumber);
    }

    public Collection<EmployerGroup> getSubGroups(Integer pGroupID) throws BPMException, DataAccessException {
        return businessProgramDAO.getSubGroups(pGroupID);
    }

    public Collection<ProgramType> getProgramTypes() throws BPMException, DataAccessException {
        return businessProgramDAO.getProgramTypes();
    }

    public ProgramType getProgramTypeByTypeID(String programTypeCode) throws BPMException,
            DataAccessException {
        ArrayList<ProgramType> lProgramTypes = (ArrayList<ProgramType>) businessProgramDAO.getProgramTypes();

        for (ProgramType lProgramType : lProgramTypes) {
            if (programTypeCode.equals(lProgramType.getProgramTypeCode())) {
                return lProgramType;
            }
        }

        return null;
    }

    public Collection<LookUpValueCode> getProgramSpecialReportHandlingCodes() throws BPMException, DataAccessException {
        ArrayList<LookUpValueCode> results = (ArrayList<LookUpValueCode>) lookUpValueDAO.getLUVCodesByGroup(BPMAdminConstants.BPM_ADMIN_BUSGODS_REPORT_HANDLING);
        return results;
    }

    public Collection<LookUpValueCode> getParticipationCodes() throws BPMException, DataAccessException {
        ArrayList<LookUpValueCode> results = (ArrayList<LookUpValueCode>) lookUpValueDAO.getLUVCodesByGroup(BPMAdminConstants.BPM_LUV_PARTICIPATION_REQ);
        return results;
    }

    public Collection<EligibleActivity> getEligibleActivities(Integer programID) throws BPMException, DataAccessException {
        return getActivityDAO().getEligibleActivities(programID);
    }

    public Collection<Activity> getAvailableActivities(Integer programID) throws BPMException, DataAccessException {
        return getActivityDAO().getAvailableActivities(programID);
    }

    public Collection<LookUpValueCode> getProgramActivationCodes() throws BPMException, DataAccessException {
        ArrayList<LookUpValueCode> results = (ArrayList<LookUpValueCode>) lookUpValueDAO.getLUVCodesByGroup(BPMAdminConstants.BPM_LUV_BPM_ACTVTN_STATUS);
        return results;
    }

    public Collection<QualificationCheckmark> getQualificationCheckmarks() throws BPMException, DataAccessException {
        return qualificationCheckmarkDAO.getActiveQualificationCheckmarks();
    }

    @Transactional(timeout = 60, rollbackFor = { DataAccessException.class, Exception.class })
    public int updateBusinessProgram(BusinessProgram pBusinessProgram, String lUserID) throws BPMException, DataAccessException {
        int lNumberOfRowsUpdated = 0;
        try {
            // Update will check for existing business program.
            // If does not exists, it will call insert.
            lNumberOfRowsUpdated = businessProgramDAO.updateBusinessProgram(pBusinessProgram, lUserID);
        } catch (DataAccessException dae) {
            // Rollback the transaction on error.
            logger.error("An unexpected error has occured: " + dae.getMessage(), dae);
            throw dae;
        } catch (Exception e) {
            // Rollback the transaction on error.
            logger.error("An unexpected error has occured: " + e.getMessage(), e);
            throw new BPMException(e);
        }

        return lNumberOfRowsUpdated;
    }

    /**
     *
     * @param pBusinessProgram
     * @param lUserID
     * @throws BPMException
     * @throws DataAccessException
     */
    @Transactional(timeout = 60, rollbackFor = { DataAccessException.class, BPMException.class })
    public void updateEmployerGroupSite(BusinessProgram pBusinessProgram, String lUserID) {
        try {
            businessProgramDAO.updateGroupNames(pBusinessProgram, lUserID);
            businessProgramDAO.updateSiteNames(pBusinessProgram, lUserID);
        } catch (Exception e) {
            // Rollback the transaction on error.
            logger.error("An unexpected error has occured: " + e.getMessage(), e);
        }
    }

    /**
     *
     * @param pProgramID
     */
    @Transactional(timeout = 60, rollbackFor = { DataAccessException.class,
            BPMException.class, SQLIntegrityConstraintViolationException.class  })
    public void deleteEmptyBusinessProgram(Integer pProgramID) throws SQLIntegrityConstraintViolationException  {
        DefaultTransactionDefinition def = new DefaultTransactionDefinition();
        def.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRED);
        TransactionStatus status = txManager.getTransaction(def);
        try {
            contributionTierDAO.deleteProgramContributionIncentiveTierByProgramID(pProgramID);

                qualificationOverrideDAO.deleteExemptionsForBizProgram(pProgramID);

                personDAO.deletePersonPrograms(pProgramID);
                personDAO.deletePersonProgramActivities(pProgramID);

                contractDAO.deleteContractPrograms(pProgramID);
                activityDAO.deleteProgramCheckmark(pProgramID);

                // First delete the eligible activities for this program.
                activityDAO.deleteEligibleActivities(pProgramID);

                ArrayList<ProgramIncentiveOption> lProgramIncentiveOptions = (ArrayList<ProgramIncentiveOption>)
                        incentiveOptionDAO.getProgramIncentiveOptions(pProgramID);

                if (lProgramIncentiveOptions != null) {
                    for (ProgramIncentiveOption lProgramIncentiveOption : lProgramIncentiveOptions) {
                        // Delete the Program Incentive Options.
                        incentiveOptionDAO.deleteProgramIncentiveOption(lProgramIncentiveOption.getProgramIncentiveOptionID());
                    }
            }


            // Delete the Program Additional Infos
            additionalInfoDAO.deleteAdditionalInfos(pProgramID);
            businessProgramDAO.deleteEmptyBusinessProgram(pProgramID);
            txManager.commit(status);
        } catch (SQLIntegrityConstraintViolationException scve) {
            txManager.rollback(status);
            logger.error("Database integrity error: " + scve.getMessage(),
                    scve);
            throw scve;
        } catch (Exception e) {
            txManager.rollback(status);
            // Rollback the transaction on error.
            logger.error("An unexpected error has occured: " + e.getMessage(),
                    e);
        }
    }

    @Override
    public Collection<BusinessProgram> getActiveBusinessPrograms(String pGroupNo, Date pQualificationStartDate) throws BPMException, DataAccessException {
        return getActiveBusinessPrograms(pGroupNo, null,
                pQualificationStartDate);
    }

    /*
     * (non-Javadoc)
     *
     * @seecom.healthpartners.app.bpm.iface.BusinessProgramService#
     * getActiveBusinessPrograms(java.lang.String, java.lang.String,
     * java.sql.Date) Even though the method suggests it returns Active Biz
     * programs it does not. Use getBusinessProgramsActive to retrieve Active
     * only biz programs.
     */
    public Collection<BusinessProgram> getActiveBusinessPrograms(
            String pGroupNo, String pSiteNo, Date pQualificationStartDate)
            throws BPMException, DataAccessException {
        ArrayList<BusinessProgram> lBusinessPrograms = (ArrayList<BusinessProgram>) businessProgramDAO
                .getBusinessProgramsActive(pQualificationStartDate, pGroupNo, pSiteNo);

        for (int i = 0; i < lBusinessPrograms.size(); i++) {
            BusinessProgram lBusinessProgram = (BusinessProgram) lBusinessPrograms
                    .get(i);
            lBusinessProgram.setHasMembers(false);

            ArrayList<Integer> lNumberOfMembers = (ArrayList<Integer>) businessProgramDAO
                    .getNumberOfMembers(lBusinessProgram.getProgramID());

            if (lNumberOfMembers.size() > 0) {
                Integer lMemberCount = (Integer) lNumberOfMembers.get(0);
                if (lMemberCount > 0) {
                    lBusinessProgram.setHasMembers(true);
                }
                lBusinessProgram.setNumberOfMembers(lMemberCount);
            }

            ArrayList<Integer> lNumberOfTerminatedMembers = (ArrayList<Integer>) businessProgramDAO
                    .getNumberOfTerminatedMembers(lBusinessProgram
                            .getProgramID());

            if (lNumberOfTerminatedMembers.size() > 0) {
                Integer lTerminatedMemberCount = (Integer) lNumberOfTerminatedMembers
                        .get(0);
                if (lTerminatedMemberCount > 0) {
                    lBusinessProgram.setHasMembers(true);
                }
                lBusinessProgram
                        .setNumberOfTerminatedMembers(lTerminatedMemberCount);
            }
        }

        return lBusinessPrograms;
    }

    public BusinessProgram getBusinessProgram(Integer pProgramID, boolean all) throws BPMException, DataAccessException {
        return businessProgramDAO.getBusinessProgram(pProgramID, all);
    }

    public Collection<EmployerGroup> getParticipatingSubGroups(Integer pGroupID) throws BPMException, DataAccessException {
        return businessProgramDAO.getParticipatingSubGroups(pGroupID);
    }

    public void insertEligibleActivities(ArrayList<EligibleActivity> pEligibleActivities, String lUserID) throws BPMException, DataAccessException {
        DefaultTransactionDefinition def = new DefaultTransactionDefinition();
        def.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRED);
        TransactionStatus status = txManager.getTransaction(def);
        try {
            for (int i = 0; i < pEligibleActivities.size(); i++) {
                EligibleActivity lEligibleActivity = (EligibleActivity) pEligibleActivities.get(i);
                getActivityDAO().insertEligibleActivity(lEligibleActivity, lUserID);
            }

            txManager.commit(status);
        } catch (DataAccessException dae) {
            // Rollback the transaction on error.
            txManager.rollback(status);
            logger.error("An unexpected error has occurred: " + dae.getMessage(), dae);
            throw dae;
        } catch (Exception e) {
            // Rollback the transaction on error.
            txManager.rollback(status);
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
            throw new BPMException(e);
        }

        return;
    }

    public Collection<ProgramIncentiveOption> getProgramIncentiveOptions(Integer programID) throws BPMException, DataAccessException {
        ArrayList<ProgramIncentiveOption> lProgramIncentiveOptions = (ArrayList<ProgramIncentiveOption>) this.incentiveOptionDAO.getProgramIncentiveOptions(programID);

        for (int i = 0; i < lProgramIncentiveOptions.size(); i++) {
            lProgramIncentiveOptions.get(i).setActivityIncentiveRequirements((ArrayList<ActivityIncentiveRequirement>)
                    getProgramActivityIncentiveRequirements(lProgramIncentiveOptions.get(i).getBusinessProgramID()
                            , lProgramIncentiveOptions.get(i).getIncentiveOption().getIncentiveOptionID()));

            ArrayList<ProgramContributionTier> lProgramContributionTiers = getProgramContributionIncentiveTiers(lProgramIncentiveOptions.get(i).getBusinessProgramID()
                    , lProgramIncentiveOptions.get(i).getIncentiveOption().getIncentiveOptionID(), lProgramIncentiveOptions.get(i).getIncentedStatusTypeCode());
            lProgramIncentiveOptions.get(i).setProgramContributionTiers(lProgramContributionTiers);
            if (lProgramContributionTiers != null && lProgramContributionTiers.size() > 0) {
                lProgramIncentiveOptions.get(i).setProgramContributionTier(lProgramContributionTiers.get(0));
            }

            for (ProgramContributionTier ProgramContributionTier : lProgramContributionTiers) {
                lProgramIncentiveOptions.get(i).setProgramContributionTierUsed(false);
                if (ProgramContributionTier.isUsed()) {
                    lProgramIncentiveOptions.get(i).setProgramContributionTierUsed(true);
                    break;
                }
            }

            Integer programIncentiveOptionID = lProgramIncentiveOptions.get(i).getProgramIncentiveOptionID();

            ArrayList<ProgramContributionGrid> lProgramContributionGrids = getProgramContributionGrids(programIncentiveOptionID);
            lProgramIncentiveOptions.get(i).setProgramContributionGrids(lProgramContributionGrids);

            for (ProgramContributionGrid lProgramContributionGrid : lProgramContributionGrids) {
                lProgramIncentiveOptions.get(i).setProgramContributionGridUsed(false);
                if (lProgramContributionGrid.isUsed()) {
                    lProgramIncentiveOptions.get(i).setProgramContributionGridUsed(true);
                    break;
                }
            }

        }

        determineSupportingRewardCardAttributes(lProgramIncentiveOptions);

        return lProgramIncentiveOptions;
    }

    @Override
    public ArrayList<ProgramContributionTier> getProgramContributionIncentiveTiers(Integer programID, Integer incentiveOptionID, String incentedStatusTypeCode) throws BPMException, DataAccessException {
        return this.contributionTierDAO.getProgramContributionIncentiveTiers(programID, incentiveOptionID, incentedStatusTypeCode);
    }

    public ArrayList<ContributionTierBenefitContractType> getAssignedContributionTierBenefitContractTypes(Integer pTierTypeID, boolean isAllowRelationshipSelfOnly) throws BPMException, DataAccessException {
        return this.contributionTierDAO.getAssignedContributionTierBenefitContractTypes(pTierTypeID, isAllowRelationshipSelfOnly);
    }

    public Collection<ActivityIncentiveRequirement> getProgramActivityIncentiveRequirements(Integer programID, Integer incentiveOptionID) throws BPMException, DataAccessException {
        return getActivityIncentiveDAO().getProgramActivityIncentiveRequirements(programID, incentiveOptionID);
    }

    public ArrayList<ProgramContributionGrid> getProgramContributionGrids(Integer programIncentiveOptionID) throws BPMException, DataAccessException {
        return this.contributionGridDAO.getProgramContributionGrids(programIncentiveOptionID);
    }

    /*
     * If incentive option reward card assigned, then find io reward card name and run frequency name.  Attributes assigned are
     * "pass by reference".
     */
    protected void determineSupportingRewardCardAttributes(Collection<ProgramIncentiveOption> lProgramIncentiveOptions) {
        for (ProgramIncentiveOption lProgramIncentiveOption : lProgramIncentiveOptions) {
            if (lProgramIncentiveOption.getIncentiveOptionRewardCardID() == null || lProgramIncentiveOption.getIncentiveOptionRewardCardID() == 0) {

            } else {
                lProgramIncentiveOption = rewardCardService.getProgramIncentiveOptionSupportingRewardCardAttributes(lProgramIncentiveOption);
            }
        }

    }

    /**
     * @param pProgramIncentiveOptions
     * @param pUserID
     * @return
     * @throws BPMException
     * @throws DataAccessException
     */
    public int updateProgramIncentiveOption(ArrayList<ProgramIncentiveOption> pProgramIncentiveOptions, Integer pBusinessProgramID, String pUserID) throws BPMException, DataAccessException {
        int lNumberUpdated = 0;
        try {

            for (int i = 0; i < pProgramIncentiveOptions.size(); i++) {
                pProgramIncentiveOptions.get(i).setBusinessProgramID(pBusinessProgramID);

                lNumberUpdated += incentiveOptionDAO
                        .updateProgramIncentiveOption(
                                (ProgramIncentiveOption) pProgramIncentiveOptions.get(i), pUserID);

                // If the Program Incentive is being created for the first time, there are no
                // Requirements yet.
                if (pProgramIncentiveOptions.get(i).getActivityIncentiveRequirements() != null) {
                    for (int j = 0; j < pProgramIncentiveOptions.get(i).getActivityIncentiveRequirements().size(); j++) {
                        updateActivityIncentiveRequirement(pProgramIncentiveOptions
                                .get(i).getActivityIncentiveRequirements().get(j), pUserID);
                    }
                }

                //TJQ - If reward card type with run time frequency selected, then add a Reward Card Program Control record
                //and tracker record.  The effective dates on the tracker record will be set to the business program effective date.

                if (pProgramIncentiveOptions.get(i).getIncentiveOptionRewardCardID() != null &&
                        pProgramIncentiveOptions.get(i).getIncentiveOptionRewardCardID() != 0) {
                    RewardCard rewardCard = getRewardCardDAO().getRewardCardDef(pProgramIncentiveOptions.get(i).getIncentiveOptionRewardCardID());
                    pProgramIncentiveOptions.get(i).setRewardCardID(rewardCard.getRewardCardID());
                    updateProgramRewardControllerForBatchProcessing(pProgramIncentiveOptions.get(i));
                }
            }

            // 08-15-2014 Commenting out this line (even with the delete query corrected) to eliminate
            // any possibility of contract-incentives being deleted.
            // Any orphan contract-incentives will need to be deleted after careful investigation via
            // a script in the database.
            // EV 81544 - If any contract-based program incentives were removed delete the contract program
            // incentive status record.
            // incentiveOptionDAO.deleteContractProgramIncentiveStatus(pBusinessProgramID);
            // 08-15-2014 Commenting out this line


        } catch (DataAccessException dae) {
            // Rollback the transaction on error.
            logger.error("An unexpected error has occured: "
                    + dae.getMessage(), dae);
            throw dae;
        } catch (Exception e) {
            // Rollback the transaction on error.
            logger.error("An unexpected error has occured: " + e.getMessage(), e);
            throw new BPMException(e);
        }

        return lNumberUpdated;
    }

    /**
     *
     * @param pActivityIncentiveRequirement
     * @return
     */
    public int updateActivityIncentiveRequirement(ActivityIncentiveRequirement pActivityIncentiveRequirement, String pUserID) throws BPMException, DataAccessException {
        // Insert ActivityIncentiveRequirement and get the Requirement ID from
        // the database sequence.
        Integer lActivityIncentiveGroupID = activityIncentiveDAO
                .insertIncentiveRequirement(pActivityIncentiveRequirement,
                        pUserID);

        for (int incDetail = 0; incDetail < pActivityIncentiveRequirement
                .getActivityIncentiveDetails().size(); incDetail++) {
            ActivityIncentiveDetail lActivityIncentiveDetail = pActivityIncentiveRequirement
                    .getActivityIncentiveDetails().get(incDetail);
            // Set the Requirement ID in the ActivityDetail, to the Requirement
            // ID that was generated by
            // the database sequence.
            lActivityIncentiveDetail.setGroupID(lActivityIncentiveGroupID);
            lActivityIncentiveDetail
                    .setGroupRequiredID(pActivityIncentiveRequirement
                            .getGroupRequirementID());
            Integer lActivityIncentiveDetailID = activityIncentiveDAO
                    .insertActivityIncentiveDetail(lActivityIncentiveDetail,
                            pUserID);

            // Now set the Activity Incentive Detail ID in the relationships and
            // insert the relationships.

            for (int rel = 0; rel < lActivityIncentiveDetail
                    .getIncentiveParticipantRelationships().size(); rel++) {
                IncentiveParticipantRelationship lIncentiveParticipantRelationship = lActivityIncentiveDetail
                        .getIncentiveParticipantRelationships().get(rel);

                lIncentiveParticipantRelationship
                        .setActivityIncentiveID(lActivityIncentiveDetailID);

                activityIncentiveDAO.insertIncentiveParticipant(
                        lIncentiveParticipantRelationship, pUserID);
            }
        }

        return 0;
    }

    public int updateProgramRewardControllerForBatchProcessing(ProgramIncentiveOption lProgramIncentiveOption)  throws BPMException, DataAccessException {
        Integer programID = lProgramIncentiveOption.getBusinessProgramID();
        Integer incentiveOptionID = lProgramIncentiveOption.getIncentiveOption().getIncentiveOptionID();
        Integer rewardCardID = lProgramIncentiveOption.getRewardCardID();
        Integer runFreqID = lProgramIncentiveOption.getRunFrequencyID();
        Date programEffDate = lProgramIncentiveOption.getEffectiveDate();

        int returnCode = rewardCardService.updateProgramRewardControllerForBatchProcessing(programID, incentiveOptionID, rewardCardID, runFreqID, programEffDate, BPMAdminConstants.BPM_USER_SYSTEM);

        return returnCode;
    }

    @Override
    public int updateProgramContributionGrid(ProgramContributionGrid lProgramContributionGrid, String pModifyUserID)
            throws BPMException, DataAccessException {
        DefaultTransactionDefinition def = new DefaultTransactionDefinition();
        def.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRED);
        TransactionStatus status = txManager.getTransaction(def);
        int lNumberUpdated = 0;
        try {
            lNumberUpdated = contributionGridDAO
                    .updateProgramContributionGrid(lProgramContributionGrid, pModifyUserID);

            txManager.commit(status);
        } catch (DataAccessException dae) {
            // Rollback the transaction on error.
            txManager.rollback(status);
            logger
                    .error("An unexpected error has occured: "
                            + dae.getMessage(), dae);
            throw dae;
        } catch (Exception e) {
            // Rollback the transaction on error.
            txManager.rollback(status);
            logger.error("An unexpected error has occured: " + e.getMessage(),
                    e);
            throw new BPMException(e);
        }

        return lNumberUpdated;
    }

    public Collection<AdditionalInformation> getAdditionalInfos(Integer programID) throws BPMException, DataAccessException {
        return getAdditionalInfoDAO().getAdditionalInformation(programID);
    }

    public void deleteInsertAdditionalInfos(ArrayList<AdditionalInformation> pAdditionalInfos, String pUserID) throws BPMException, DataAccessException {
        DefaultTransactionDefinition def = new DefaultTransactionDefinition();
        def.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRED);
        TransactionStatus status = txManager.getTransaction(def);

        try {
            // Following the pattern of Program-Activities, additional info
            // records will be removed and added
            // back to the table with new and existing updated records.
            AdditionalInformation additionalInfo = (AdditionalInformation) pAdditionalInfos
                    .get(0);
            additionalInfoDAO.deleteAdditionalInfos(additionalInfo
                    .getAdditionalProgramID());

            // check for valid id. Null value indicates no records to update.
            // pAdditionalInfos object was initialized with program ID with
            // intent to delete all additional info records.
            if (additionalInfo.getAdditionalInfoID() != null) {
                for (int i = 0; i < pAdditionalInfos.size(); i++) {
                    additionalInfoDAO.updateAdditionalInformation((AdditionalInformation) pAdditionalInfos.get(i), pUserID);
                }
            }

            txManager.commit(status);
        } catch (DataAccessException dae) {
            // Rollback the transaction on error.
            txManager.rollback(status);
            logger.error("An unexpected error has occured: " + dae.getMessage(), dae);
            throw dae;
        } catch (Exception e) {
            // Rollback the transaction on error.
            txManager.rollback(status);
            logger.error("An unexpected error has occured: " + e.getMessage(), e);
            throw new BPMException(e);
        }
    }

    @Override
    public Collection<AuthCode> getExtendedAuthCodes(Integer pProgramID) {
        return activityDAO.selectExtendedAuthCodes(pProgramID);
    }

    @Override
    public void updateExtendedAuthCode(AuthCode pAuthCode, String pUserID) {
        activityDAO.updateExtendedAuthCode(pAuthCode, pUserID);
    }

    @Override
    public ArrayList<ProgramCheckmark> getProgramCheckmarks(Integer pProgramID) throws BPMException, DataAccessException {
        return qualificationCheckmarkDAO.getProgramCheckmarks(pProgramID);
    }

    /**
     * Update program checkmarks.
     * Once there are activities (checkmark details) selected, make sure the
     * activities are also part of the eligible_program_activity table.
     */
    public int updateProgramCheckmarks(ArrayList<ProgramCheckmark> pProgramCheckmarks, Integer pBusinessProgramID, String pModifyUserID) throws BPMException, DataAccessException {
        for (ProgramCheckmark lProgramCheckmark : pProgramCheckmarks) {
            qualificationCheckmarkDAO.updateProgramCheckmark(lProgramCheckmark, pModifyUserID);
            updateEligibleActivitiesFromCheckmark(pBusinessProgramID, lProgramCheckmark.getQualificationCheckmarkID(), pModifyUserID);
        }

        return 1;
    }

    /**
     * @param pProgramID
     * @param pQualificationCheckmarkID
     * @param pModifyUserID
     * @throws BPMException
     */
    public void updateEligibleActivitiesFromCheckmark(Integer pProgramID, Integer pQualificationCheckmarkID, String pModifyUserID)
            throws BPMException {
        StringBuffer pEmailBody = new StringBuffer();
        pEmailBody.append("<tr><td>Eligible Activities Updated with Qualification Checkmark Activities for </td></tr>");
        pEmailBody.append("<tr><td>&nbsp;</td></tr>");

        // the false flag gets only the ACTIVE business programs.
        BusinessProgram lBusinessProgram = getBusinessProgram(pProgramID, false);

        if (lBusinessProgram == null || lBusinessProgram.getEmployerGroup() == null) {
            return;
        }

        pEmailBody.append("<tr><td>" + lBusinessProgram.getEmployerGroup().getGroupNumber()
                + " - "
                + lBusinessProgram.getEmployerGroup().getGroupName()
                + ", Site "
                + lBusinessProgram.getEmployerGroup().getSiteNumber()
                + " - "
                + lBusinessProgram.getEmployerGroup().getSiteName()
                + ", Year:  "
                + BPMAdminUtils.formatDateMMddyyyy(lBusinessProgram.getEffectiveDate())
                + " - "
                + BPMAdminUtils.formatDateMMddyyyy(lBusinessProgram.getEndDate())
                + "</td></tr>");

        ArrayList<EligibleActivity> lEligibleActivities = (ArrayList<EligibleActivity>)
                activityDAO.getEligibleActivities(pProgramID);

        if (lEligibleActivities != null && lEligibleActivities.size() > 0) {
            EligibleActivity lEligibleActivity = lEligibleActivities.get(0);

            if (BPMAdminConstants.BPM_ADMIN_ACTIVITY_TYPE_HA.equalsIgnoreCase(lEligibleActivity.getActivity().getActivityTypeValue())) {
                lEligibleActivity.setAuthorizationCode(BPMAdminConstants.BPM_ADMIN_PROMO_CODE_PREFIX + lEligibleActivity.getAuthorizationCode());
            }

            // Get the checkmark activity IDs, that are missing from the eligible program activity table.
            ArrayList<Integer> lActivityIDList =
                    activityDAO.getCheckmarkEligibleActivities(pQualificationCheckmarkID, pProgramID);

            // Insert the eligible activities that are part of the checkmark, and not in the
            // eligible program activity table.
            for (Integer lActivityID : lActivityIDList) {
                lEligibleActivities.get(0).setActivity(activityDAO.selectActivity(lActivityID));
                lEligibleActivities.get(0).setActivityName(lEligibleActivities.get(0).getActivity().getName());
                lEligibleActivities.get(0).setActivityDesc(lEligibleActivities.get(0).getActivity().getDescription());
                activityDAO.insertEligibleActivity(lEligibleActivities.get(0), pModifyUserID);
            }

            if (lActivityIDList != null && lActivityIDList.size() > 0) {
                prepareAndSendSummaryEmail("Program Eligible Activities Updated", pEmailBody.toString());
            }
        }
    }

    @Override
    public ArrayList<ContributionTier> getAllContributionTiers() throws BPMException, DataAccessException {
        return this.contributionTierDAO.getAllContributionTiers();
    }

    @Override
    public int deleteProgramContributionTiers(Collection<ProgramContributionTier> lremovedProgramContributionTiers) throws BPMException, DataAccessException {
        DefaultTransactionDefinition def = new DefaultTransactionDefinition();
        def.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRED);
        TransactionStatus status = txManager.getTransaction(def);

        int lNumberDeleted = 0;

        try {
            for (ProgramContributionTier lremovedProgramContributionTier : lremovedProgramContributionTiers) {
                lNumberDeleted = contributionTierDAO.deleteProgramContributionTier(lremovedProgramContributionTier.getTierContributionID());

                if (lNumberDeleted > 0) {
                    contributionTierDAO.deleteProgramContributionIncentiveTier(lremovedProgramContributionTier.getTierContributionID());
                }
            }
            txManager.commit(status);
        } catch (DataAccessException dae) {
            // Rollback the transaction on error.
            txManager.rollback(status);
            logger
                    .error("An unexpected error has occured: "
                            + dae.getMessage(), dae);
            throw dae;
        } catch (Exception e) {
            // Rollback the transaction on error.
            txManager.rollback(status);
            logger.error("An unexpected error has occured: " + e.getMessage(),
                    e);
            throw new BPMException(e);
        }

        return lNumberDeleted;
    }

    @Override
    public int updateProgramContributionTier(Integer activityIncentiveID, Integer groupID, Integer groupRequiredID, Integer qualificationCheckmarkDetailID, ProgramContributionTier lProgramContributionTier, String pModifyUserID) throws BPMException, DataAccessException {
        DefaultTransactionDefinition def = new DefaultTransactionDefinition();
        def.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRED);
        TransactionStatus status = txManager.getTransaction(def);
        int lNumberUpdated = 0;
        try {
            lNumberUpdated = contributionTierDAO.updateProgramContributionTier(activityIncentiveID, groupID, groupRequiredID, qualificationCheckmarkDetailID, lProgramContributionTier, pModifyUserID);
            txManager.commit(status);
        } catch (DataAccessException dae) {
            // Rollback the transaction on error.
            txManager.rollback(status);
            logger
                    .error("An unexpected error has occured: "
                            + dae.getMessage(), dae);
            throw dae;
        } catch (Exception e) {
            // Rollback the transaction on error.
            txManager.rollback(status);
            logger.error("An unexpected error has occured: " + e.getMessage(),
                    e);
            throw new BPMException(e);
        }

        return lNumberUpdated;
    }

    @Override
    public void saveProgramContributionGridsToSites(BusinessProgram pBusinessProgramSource
            , ProgramIncentiveOption pProgramIncentiveOptionSource
            , Collection<EmployerGroup> pEmployerGroups
            , ArrayList<ProgramContributionGrid> pProgramContributionGridsSource
            , String pUserID)
            throws BPMException, DataAccessException {

        Integer incentiveOptionIDSource = pProgramIncentiveOptionSource.getIncentiveOption().getIncentiveOptionID();

        for (EmployerGroup pEmployerGroup : pEmployerGroups) {
            ArrayList<BusinessProgram> lBusinessPrograms = (ArrayList<BusinessProgram>)
                    getBusinessPrograms(pBusinessProgramSource.getEffectiveDate()
                            , pBusinessProgramSource.getEmployerGroup().getGroupID()
                            , pEmployerGroup.getSubgroupID());

            for (BusinessProgram lBusinessProgram : lBusinessPrograms) {
                Collection<ProgramIncentiveOption> lProgramIncentiveOptions = this.getProgramIncentiveOptions(lBusinessProgram.getProgramID());
                for (ProgramIncentiveOption lProgramIncentiveOption : lProgramIncentiveOptions) {
                    if (lProgramIncentiveOption.getIncentiveOption().getIncentiveOptionID().equals(incentiveOptionIDSource)) {
                        if (lProgramIncentiveOption.getProgramContributionGrids().size() > 0) {
                            deleteProgramContributionGrids(lProgramIncentiveOption.getProgramIncentiveOptionID());
                        }

                        for (ProgramContributionGrid pProgramContributionGridSource : pProgramContributionGridsSource) {
                            pProgramContributionGridSource.setProgramIncentiveOptionID(lProgramIncentiveOption.getProgramIncentiveOptionID());
                            pProgramContributionGridSource.setContributionGridID(null);
                            updateProgramContributionGrid(pProgramContributionGridSource, pUserID);
                        }
                    }
                }
            }
        }
    }

    @Override
    public Collection<LookUpValueCode> getExtendedAuthCodeTypes() throws BPMException, DataAccessException {
        ArrayList<LookUpValueCode> results = (ArrayList<LookUpValueCode>) lookUpValueDAO.getLUVCodesByGroup(BPMAdminConstants.BPM_LUV_AUTH_CD_TP);
        return results;
    }

    public int deleteProgramContributionGrids(Integer pProgramIncentiveOptionID) throws BPMException, DataAccessException {
        contributionGridDAO.deleteProgramContributionGrids(pProgramIncentiveOptionID);
        return 0;
    }

    public void deleteExtendedAuthCodes(Integer pProgramID) {
        activityDAO.deleteExtendedAuthCodes(pProgramID);
    }

    @Override
    public void saveExtendedAuthCodesToAllSites(BusinessProgram pBusinessProgram, Collection<AuthCode> pAuthCodes, String pUserID) throws BPMException, DataAccessException {
        Collection<EmployerGroup> lEmployerGroups = getBusinessProgramInSameYear(pBusinessProgram.getProgramID());
        saveExtendedAuthCodesToSites(pBusinessProgram, pAuthCodes, lEmployerGroups, pUserID);
    }

    @Override
    public void saveExtendedAuthCodesToSites(BusinessProgram pBusinessProgram, Collection<AuthCode> pAuthCodes, Collection<EmployerGroup> pEmployerGroups, String pUserID) throws BPMException, DataAccessException {
        for (EmployerGroup lEmployerGroup : pEmployerGroups) {
            ArrayList<BusinessProgram> lBusinessPrograms = (ArrayList<BusinessProgram>)
                    getBusinessPrograms(pBusinessProgram.getEffectiveDate()
                            , pBusinessProgram.getEmployerGroup().getGroupID()
                            , lEmployerGroup.getSubgroupID());

            for (BusinessProgram lBusinessProgram : lBusinessPrograms) {
                deleteExtendedAuthCodes(lBusinessProgram.getProgramID());

                for (AuthCode lAuthCode : pAuthCodes) {
                    lAuthCode.setBusinessProgramID(lBusinessProgram.getProgramID());
                    this.updateExtendedAuthCode(lAuthCode, pUserID);
                }
            }
        }
    }

    @Override
    public int insertProgramChangeLog(ProgramChangeLog pProgramChangeLog, String pUserID) throws DataAccessException {
        return businessProgramDAO.insertProgramChangeLog(pProgramChangeLog, pUserID);
    }

    private void prepareAndSendSummaryEmail(String pSubjectLine, String pEmailBody) {
        String emailServerHost = null;
        String emailFromAddress = null;
        String dbEnvirnment = "";
        List<String> emailToAddress = new ArrayList<String>();
        StringBuffer emailContent = new StringBuffer();
        StringBuffer emailSubject = new StringBuffer();

        try {
            Collection<LookUpValueCode> serverHost = memberService
                    .getLUVCodesByGroup(BPMAdminConstants.BPM_ADMIN_EMAIL_HOST_SRVR);
            Collection<LookUpValueCode> fromAddress = memberService
                    .getLUVCodesByGroup(BPMAdminConstants.BPM_ADMIN_EMAIL_FROM_ADDR);
            Collection<LookUpValueCode> toAddress = memberService
                    .getLUVCodesByGroup(BPMAdminConstants.BPM_ADMIN_EMAIL_TO_ADDR);
            Collection<LookUpValueCode> dbEnvirnments = memberService
                    .getLUVCodesByGroup(BPMAdminConstants.BPM_ADMIN_DB_ENV);

            // email server host
            Iterator<LookUpValueCode> itrHost = serverHost.iterator();
            if (itrHost.hasNext()) {
                LookUpValueCode lvalue = itrHost.next();
                emailServerHost = lvalue.getLuvDesc();
            }

            // from address
            Iterator<LookUpValueCode> itrTo = fromAddress.iterator();
            if (itrTo.hasNext()) {
                LookUpValueCode lvalue = itrTo.next();
                emailFromAddress = lvalue.getLuvDesc();
            }

            // to address
            Iterator<LookUpValueCode> itr = toAddress.iterator();
            while (itr.hasNext()) {
                LookUpValueCode lvalue = itr.next();
                emailToAddress.add(lvalue.getLuvDesc());
            }

            Iterator<LookUpValueCode> itrEnv = dbEnvirnments.iterator();
            while (itrEnv.hasNext()) {
                LookUpValueCode lvalue = itrEnv.next();
                dbEnvirnment = lvalue.getLuvDesc();
                break;
            }

            // prepare summary email body
            emailSubject.append(pSubjectLine);


            emailContent.append("\nProgram Eligible Activities Updated");
            emailContent.append("<table>");
            emailContent.append("<tr><td>Database Environment:</td>");
            emailContent.append("<td>" + dbEnvirnment + "</td></tr>");
            emailContent.append("</table>");

            // valid activities processed
            emailContent.append("<br><br><table>");
            emailContent
                    .append("<tr><td>***************************************************************************</td></tr>");
            emailContent
                    .append("<tr><td>Program Eligible Activities Updated");
            emailContent
                    .append("<tr><td>***************************************************************************</td></tr>");

            emailContent.append("<tr><td></td></tr>");
            emailContent.append("<tr><td></td></tr>");
            emailContent.append(pEmailBody);

            emailContent.append("<tr><td>&nbsp;</td></tr>");
            emailContent.append("<tr><td>Please note that the final Qualified/Not-Qualified contract counts "
                    + " may change as Member Eligibility Changes, Exemptions, Dispute Resolutions, and retroactive activity statuses are processed."
                    + "</td></tr>");

            emailContent.append("</table>");

            bpmAdminEmailUtility.sendEmail(emailServerHost, emailFromAddress,
                    emailToAddress, emailSubject.toString(), emailContent
                            .toString(),
                    bpmAdminEmailUtility.EMAIL_CONTENT_TYPE_HTML, null);

        } catch (Exception e) {
            logger.error(
                    "Error occurred sending Program Eligible Activities Updated email: "
                            + e.getMessage(), e);
            logger.error("  emailToAddress=" + emailToAddress);
            logger.error("  emailFromAddress=" + emailFromAddress);
            logger.error("  emailSubject=" + emailSubject.toString());
            logger.error("  emailContent=" + emailContent.toString());
        }
    }

    @Override
    public void saveChangeLogToAllSites(BusinessProgram pBusinessProgram, String pChangeLogText, String pUserID) throws BPMException, DataAccessException {
        Collection<EmployerGroup> lEmployerGroups =
                getBusinessProgramInSameYear(pBusinessProgram.getProgramID());

        saveChangeLogToSites(pBusinessProgram,
                pChangeLogText,
                lEmployerGroups,
                pUserID);

        return;
    }

    public void saveChangeLogToSites(BusinessProgram pBusinessProgram,
                                     String pChangeLogText,
                                     Collection<EmployerGroup> pEmployerGroups,
                                     String pUserID) throws BPMException, DataAccessException {
        for (EmployerGroup lEmployerGroup : pEmployerGroups) {
            ArrayList<BusinessProgram> lBusinessPrograms = (ArrayList<BusinessProgram>)
                    getBusinessPrograms(pBusinessProgram.getEffectiveDate()
                            , pBusinessProgram.getEmployerGroup().getGroupID()
                            , lEmployerGroup.getSubgroupID());

            for (BusinessProgram lBusinessProgram : lBusinessPrograms) {
                ProgramChangeLog lProgramChangeLog = new ProgramChangeLog();
                lProgramChangeLog.setProgramID(lBusinessProgram.getProgramID());
                lProgramChangeLog.setChangeText(pChangeLogText);

                insertProgramChangeLog(lProgramChangeLog, pUserID);
            }
        }
    }


    @Override
    public int updateAllGroupSiteMembers(Integer pProcessID, Integer pProgramID) throws BPMException, DataAccessException, IOException {
        DefaultTransactionDefinition def = new DefaultTransactionDefinition();
        def.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRED);
        TransactionStatus status = txManager.getTransaction(def);
        int lNumberUpdated = 0;
        Integer batchSize = Integer.valueOf(100);
        try {
            // Mark all the members for this group-site-year program for
            // membership update, because for example in case the biz program
            // participation requirement
            // changed from PH and Spouse, we want the spouses to be marked as
            // non-participating.
            // (Inserts a row in the processing_status log with a Null
            // completion date)
            businessProgramDAO.updateAllGroupSiteMembers(pProcessID, pProgramID);

            // Put a message in the message-queue in order for the Status
            // Re-calc batch
            // job to be run.
            StatusCalculationCommand calculationCommand = new StatusCalculationCommand();
            calculationCommand.setEtlMembershipUpdateCommand();
            calculationCommand.setProcessIDForEtlMembershipUpdateCommand(pProcessID);
            calculationCommand.setBatchSizeCommand(batchSize);
            String userId = getAuthenticatedUsername();
            calculationCommand.setUserID(userId);
            //memberService.sendJMSCommand(calculationCommand);
            LookUpValueCode luvRestEndpoint = null;
            if (pProcessID.equals(BPMAdminConstants.BPM_ADMIN_MEMBERS_RECALCULATION_PRCS_ID)) {
                luvRestEndpoint = (LookUpValueCode)
                        memberService.getLUVCodeByGroupNValue(BPMAdminConstants.OS_REST_URL_COMMAND, BPMAdminConstants.OS_URL_KS_MEMBERSTATUS_RECALC);
            } else if (pProcessID.equals(BPMAdminConstants.BPM_ADMIN_MEMBERSHIP_UPDATE_PRCS_ID)) {
                luvRestEndpoint = (LookUpValueCode)
                        memberService.getLUVCodeByGroupNValue(BPMAdminConstants.OS_REST_URL_COMMAND, BPMAdminConstants.OS_URL_KS_MEMBERSHIP_UPDATE);

            }

            String urlRestEndpointCommand = luvRestEndpoint.getLuvDesc();

            memberService.kickStartBatchProcessOnOpenshift(urlRestEndpointCommand);
            txManager.commit(status);

        } catch (DataAccessException dae) {
            // Rollback the transaction on error.
            logger.error("An unexpected error has occurred: " + dae.getMessage(), dae);
            txManager.rollback(status);
            throw dae;
        } catch (Exception e) {
            // Rollback the transaction on error.
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
            txManager.rollback(status);
            throw new BPMException(e);
        }

        return lNumberUpdated;
    }

    private String getAuthenticatedUsername() {
        String userName = null;
        Authentication auth = SecurityContextHolder.getContext()
                .getAuthentication();
        if (auth != null) {
            userName = auth.getName();
        }

        return userName;
    }

    @Override
    public Collection<BusinessProgram> getProgramTemplates(Integer pProgramID) throws BPMException, DataAccessException {
        return businessProgramDAO.getProgramTemplates(pProgramID);
    }

    @Override
    public Collection<ProgramActivityIncentiveSummary> getProgramActivityIncentivesSummaryWithRequirements(Integer programID) throws BPMException, DataAccessException {
        return getActivityIncentiveDAO().getProgramActivityIncentiveSummaryWithRequirements(programID);
    }

    @Override
    public Collection<CheckmarkRequirement> getCheckmarkRequirements(Integer pQualificationCheckmarkID) throws BPMException, DataAccessException {
        return this.qualificationCheckmarkDAO.getCheckmarkRequirements(pQualificationCheckmarkID);
    }

    /**
     * Retrieve a list of all the participation group definitions.
     */
    @Override
    public Collection<ParticipationGroup> getParticipationGroups() throws BPMException, DataAccessException {
        return participationGroupDAO.getParticipationGroups();
    }

    @Override
    public Collection<IncentivePackageRuleGroup> getIncentivePackageRuleGroups(Integer pProgramID) throws BPMException, DataAccessException {
        return incentivePackageRuleDAO.getIncentivePackageRuleGroups(pProgramID);
    }

    @Override
    public Collection<BenefitPackage> getBenefitPackages(Integer pBusinessProgramID) throws DataAccessException {
        return businessProgramDAO.getBenefitPackages(pBusinessProgramID);
    }

    /**
     * @param pProgramID
     * @return
     * @throws DataAccessException
     */
    @Override
    public Collection<ProgramChangeLog> getBusinessProgramChangeLog(Integer pProgramID) throws DataAccessException {
        return businessProgramDAO.getBusinessProgramChangeLog(pProgramID);
    }

    @Override
    public Collection<ProgramPackage> getProgramPackages() throws BPMException, DataAccessException {
        return programPackageDAO.getProgramPackages();
    }

    @Override
    public Integer getContractStatusCount(String pContractStatus, Integer pBusinessProgramID) throws DataAccessException {
        return contractDAO.getContractStatusCount(pContractStatus, pBusinessProgramID);
    }

    /**
     * Retrieve Business Programs by Group ID, and Subgroup
     * ID.
     *
     * @param pGroupID
     * @param pSubgroupID
     * @return
     */
    @Override
    public Collection<BusinessProgram> getBusinessPrograms(Integer pGroupID, Integer pSubgroupID) throws BPMException, DataAccessException {
        return businessProgramDAO.getBusinessPrograms(pGroupID, pSubgroupID);
    }

    /**
     * Retrieve Business Programs by Qualification Date, Group ID, and Subgroup
     * ID.
     *
     * @param pEffectiveDate
     * @param pGroupID
     * @param pSubgroupID
     * @return
     */
    @Override
    public Collection<BusinessProgram> getBusinessPrograms(Date pEffectiveDate, Integer pGroupID, Integer pSubgroupID) throws BPMException, DataAccessException {
        return businessProgramDAO.getBusinessPrograms(pEffectiveDate, pGroupID, pSubgroupID);
    }

    @Override
    public Collection<EmployerGroup> getBusinessProgramInSameYear(Integer pBusinessProgramID) throws DataAccessException {
        return businessProgramDAO.getBusinessProgramInSameYear(pBusinessProgramID);
    }

    /**
     * @param pBusinessProgram
     * @param pEligibleActivities
     * @param pUserID
     * @param pEmployerGroups
     * @throws BPMException
     * @throws DataAccessException
     */
    public void saveEligibleActivitiesToSites(BusinessProgram pBusinessProgram, ArrayList<EligibleActivity> pEligibleActivities, String pUserID, Collection<EmployerGroup> pEmployerGroups) throws BPMException, DataAccessException {
        for (EmployerGroup lEmployerGroup : pEmployerGroups) {
            ArrayList<BusinessProgram> lBusinessPrograms = (ArrayList<BusinessProgram>) getBusinessPrograms(pBusinessProgram.getEffectiveDate(), pBusinessProgram.getEmployerGroup().getGroupID(), lEmployerGroup.getSubgroupID());

            for (BusinessProgram lBusinessProgram : lBusinessPrograms) {
                if (lBusinessProgram.getPackageID().intValue() == pBusinessProgram.getPackageID().intValue()) {
                    //bypass package id update
                } else {
                    lBusinessProgram.setPackageID(pBusinessProgram.getPackageID());
                    businessProgramDAO.updatePackageID(lBusinessProgram, pUserID);
                }
                activityDAO.deleteEligibleActivities(lBusinessProgram.getProgramID());

                for (EligibleActivity lEligibleActivity : pEligibleActivities) {
                    lEligibleActivity.setProgramID(lBusinessProgram.getProgramID());
                    activityDAO.updateEligibleActivity(lEligibleActivity, pUserID);
                }
            }
        }

        return;
    }

    @Override
    public Collection<LookUpValueCode> getIncentiveOverrideCodeTypes() throws BPMException, DataAccessException {
        ArrayList<LookUpValueCode> results = (ArrayList<LookUpValueCode>) lookUpValueDAO.getLUVCodesByGroup(BPMAdminConstants.BPM_LUV_INCENVIVE_OVERRIDE_CD_TP);
        return results;
    }

    @Override
    public Collection<PackageActivity> getPackageActivities(Integer pPackageID) throws BPMException, DataAccessException {
        return programPackageDAO.getPackageActivities(pPackageID);
    }

    @Override
    public int deleteEligibleActivityByStartDate(EligibleActivity pEligibleActivity)
            throws BPMException, DataAccessException {
        DefaultTransactionDefinition def = new DefaultTransactionDefinition();
        def.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRED);
        TransactionStatus status = txManager.getTransaction(def);
        int deleteCt;
        try {

            deleteCt = activityDAO.deleteEligibleActivityByStartDate(pEligibleActivity.getProgramID(), pEligibleActivity.getActivity().getActivityID(), pEligibleActivity.getQualificationWindowEarlyStartDate());

            txManager.commit(status);
        } catch (DataAccessException dae) {
            // Rollback the transaction on error.
            txManager.rollback(status);
            logger
                    .error("An unexpected error has occured: "
                            + dae.getMessage(), dae);
            throw dae;
        } catch (Exception e) {
            // Rollback the transaction on error.
            txManager.rollback(status);
            logger.error("An unexpected error has occured: " + e.getMessage(),
                    e);
            throw new BPMException(e);
        }

        return deleteCt;
    }

    @Override
    public void deleteInsertEligibleActivity(Integer lBusinessProgramID, ArrayList<EligibleActivity> pEligibleActivities, String pUserID) throws BPMException, DataAccessException {
        DefaultTransactionDefinition def = new DefaultTransactionDefinition();
        def.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRED);
        TransactionStatus status = txManager.getTransaction(def);

        try {
            // We don't know how many Program-Activities were removed from the
            // web page.
            // Remove all of them. This way the Update will insert all the
            // assigned ones.
            activityDAO.deleteEligibleActivities(lBusinessProgramID);
            for (int i = 0; i < pEligibleActivities.size(); i++) {
                activityDAO.updateEligibleActivity(
                        (EligibleActivity) pEligibleActivities.get(i), pUserID);
            }

            txManager.commit(status);
        } catch (DataAccessException dae) {
            // Rollback the transaction on error.
            txManager.rollback(status);
            logger
                    .error("An unexpected error has occured: "
                            + dae.getMessage(), dae);
            throw dae;
        } catch (Exception e) {
            // Rollback the transaction on error.
            txManager.rollback(status);
            logger.error("An unexpected error has occured: " + e.getMessage(),
                    e);
            throw new BPMException(e);
        }
    }

    /**
     *
     * @param pBusinessProgram
     * @param pEligibleActivities
     * @param pUserID
     * @throws BPMException
     * @throws DataAccessException
     */
    @Override
    public void saveEligibleActivitiesAllSites(BusinessProgram pBusinessProgram, ArrayList<EligibleActivity> pEligibleActivities, String pUserID) throws BPMException, DataAccessException {
        Collection<EmployerGroup> lEmployerGroups = getBusinessProgramInSameYear(pBusinessProgram.getProgramID());
        saveEligibleActivitiesToSites(pBusinessProgram, pEligibleActivities, pUserID, lEmployerGroups);
    }

    @Override
    public Collection<IncentiveOption> getIncentiveOptions() throws BPMException, DataAccessException {
        return this.incentiveOptionDAO.getIncentiveOptions();
    }

    @Override
    public Collection<IncentiveOption> getActiveIncentiveOptions() throws BPMException, DataAccessException {
        return this.incentiveOptionDAO.getActiveIncentiveOptions();
    }

    @Override
    public Collection<LookUpValueCode> getIncentiveOptionStatusCodes() throws BPMException, DataAccessException {
        ArrayList<LookUpValueCode> results = (ArrayList<LookUpValueCode>) lookUpValueDAO.getLUVCodesByGroup(BPMAdminConstants.BPM_LUV_INCENTIVE_STATUS);
        return results;
    }

    @Override
    public Collection<LookUpValueCode> getIncentiveFulfillTypeCodes() throws BPMException, DataAccessException {
        ArrayList<LookUpValueCode> results = (ArrayList<LookUpValueCode>) lookUpValueDAO.getLUVCodesByGroup(BPMAdminConstants.BPM_LUV_FULFILLMENT_RTNG_TYPE);
        return results;
    }

    @Override
    public Collection<LookUpValueCode> getIncentiveReportNameCodeTypes() throws BPMException, DataAccessException {
        ArrayList<LookUpValueCode> results = (ArrayList<LookUpValueCode>) lookUpValueDAO.getLUVCodesByGroup(BPMAdminConstants.BPM_LUV_INCNTV_RPT_DESC_TP);
        return results;
    }

    @Override
    public Collection<LookUpValueCode> getIncentiveStatusCodes() throws BPMException, DataAccessException {
        ArrayList<LookUpValueCode> results = (ArrayList<LookUpValueCode>) lookUpValueDAO.getLUVCodesByGroup(BPMAdminConstants.BPM_LUV_INCENTED_BASED);
        return results;
    }

    @Override
    public Collection<LookUpValueCode> getIncentiveEnrollmentRuleCodes() throws BPMException, DataAccessException {
        ArrayList<LookUpValueCode> results = (ArrayList<LookUpValueCode>) lookUpValueDAO.getLUVCodesByGroup(BPMAdminConstants.BPM_LUV_INCENTIVE_ENROLLMENT_RULE_CODE);
        return results;
    }

    @Override
    public Collection<LookUpValueCode> getRewardRunFrequencyTypes() throws BPMException, DataAccessException {
        ArrayList<LookUpValueCode> results = (ArrayList<LookUpValueCode>) lookUpValueDAO.getLUVCodesByGroup(BPMAdminConstants.REWARD_RUN_FREQUENCY);
        return results;
    }

    @Override
    public Collection<LookUpValueCode> getDeliveryInfoTypes() throws BPMException, DataAccessException {
        ArrayList<LookUpValueCode> results = (ArrayList<LookUpValueCode>) lookUpValueDAO.getLUVCodesByGroup(BPMAdminConstants.BPM_ADMIN_DELIVERY_INFO);
        return results;
    }

    @Override
    public ArrayList<QualificationCheckmark> getAvailableCheckmarks(Integer pProgramID) throws BPMException, DataAccessException {
        return qualificationCheckmarkDAO.getAvailableCheckmarks(pProgramID);
    }


    /**
     * Retrieve PersonRelationship Codes.
     *
     *
     * @return
     */
    @Override
    public Collection<PersonRelationshipCode> getPersonRelationshipCodes() throws BPMException, DataAccessException {
        ArrayList<PersonRelationshipCode> results = (ArrayList<PersonRelationshipCode>) personDAO.getPersonRelationshipCodes();
        PersonRelationshipCode lFirstInTheList = new PersonRelationshipCode();
        lFirstInTheList.setRelationshipCodeID(0);
        lFirstInTheList.setRelationshipName(BPMAdminConstants.BPM_DEFAULT_FIRST_ITEM_IN_DROPDOWN);

        results.add(0, lFirstInTheList);

        return results;
    }

    @Override
    public int deleteProgramCheckmark(Integer pProgramCheckmarkID) throws BPMException, DataAccessException {
        return qualificationCheckmarkDAO.deleteProgramCheckmark(pProgramCheckmarkID);
    }

    /**
     *
     * @param pProgramCheckmarks
     * @param pBusinessProgram
     * @param pModifyUserID
     * @return
     */
    @Override
    public void saveProgramCheckmarksToAllSites(ArrayList<ProgramCheckmark> pProgramCheckmarks, BusinessProgram pBusinessProgram, String pModifyUserID) throws BPMException, DataAccessException {
        // Get all the sites (Subgroups) for this group.
        Collection<EmployerGroup> lEmployerGroups = getBusinessProgramInSameYear(pBusinessProgram.getProgramID());

        // Save program checkmarks to all the sites (Subgroups).
        saveProgramCheckmarksToSites(pBusinessProgram
                , pProgramCheckmarks
                , pModifyUserID
                , lEmployerGroups);
    }

    /**
     * Save program checkmarks to the sites (Subgroups) in the EmployerGroup list.
     *
     * @param pBusinessProgram
     * @param pProgramCheckmarks
     * @param pUserID
     * @param pEmployerGroups
     * @throws BPMException
     * @throws DataAccessException
     */
    @Override
    public void saveProgramCheckmarksToSites(BusinessProgram pBusinessProgram, ArrayList<ProgramCheckmark> pProgramCheckmarks, String pUserID, Collection<EmployerGroup> pEmployerGroups) throws BPMException, DataAccessException {
        for (EmployerGroup lEmployerGroup : pEmployerGroups) {
            ArrayList<BusinessProgram> lBusinessPrograms = (ArrayList<BusinessProgram>)
                    getBusinessPrograms(pBusinessProgram.getEffectiveDate()
                            , pBusinessProgram.getEmployerGroup().getGroupID()
                            , lEmployerGroup.getSubgroupID());

            for (BusinessProgram lBusinessProgram : lBusinessPrograms) {
                ArrayList<ProgramIncentiveOption> lCopyToProgramIncentiveOptions = (ArrayList<ProgramIncentiveOption>)
                        getProgramIncentiveOptions(lBusinessProgram.getProgramID());

                // If the Biz program is not the Copy-From
                if (lBusinessProgram.getProgramID() != pBusinessProgram.getProgramID()) {
                    setOtherSitesProgramIncentiveOptionID(pProgramCheckmarks
                            , lCopyToProgramIncentiveOptions);
                }

                for (ProgramCheckmark lProgramCheckmark : pProgramCheckmarks) {
                    lProgramCheckmark.setBusinessProgramID(lBusinessProgram.getProgramID());
                }
                updateProgramCheckmarks(pProgramCheckmarks
                        , lBusinessProgram.getProgramID()
                        , pUserID);
            }
        }
    }

    /**
     *
     * @param pProgramCheckmarks
     */
    protected void setOtherSitesProgramIncentiveOptionID(ArrayList<ProgramCheckmark> pProgramCheckmarks, ArrayList<ProgramIncentiveOption> pCopyToProgramIncentiveOptions) throws BPMException {
        for (ProgramCheckmark lProgramCheckmark : pProgramCheckmarks) {
            for (ProgramIncentiveOption lCopyToProgramIncentiveOption : pCopyToProgramIncentiveOptions) {
                if (lProgramCheckmark.getIncentiveOptionID().intValue() == lCopyToProgramIncentiveOption.getIncentiveOption().getIncentiveOptionID().intValue()) {
                    lProgramCheckmark.setProgramIncentiveOptionID(lCopyToProgramIncentiveOption.getProgramIncentiveOptionID());
                    break;
                }
            }
        }
    }

    @Override
    @Transactional(timeout = 60, rollbackFor = {DataAccessException.class, BPMException.class, SQLIntegrityConstraintViolationException.class})
    public void deleteProgramIncentiveOption(Integer pProgramIncentiveOptionID) throws BPMException, SQLIntegrityConstraintViolationException, DataAccessException, Exception {
        incentiveOptionDAO.deleteContractProgramIncentiveStatusByID(pProgramIncentiveOptionID);
        personDAO.deletePersonProgramsByProgramIncentiveOptionID(pProgramIncentiveOptionID);
        contractDAO.deleteContractProgramsByProgramIncentiveOptionID(pProgramIncentiveOptionID);
        qualificationOverrideDAO.deleteQualificationOverrideForIncentive(pProgramIncentiveOptionID);

        try {
            incentiveOptionDAO.deleteProgramIncentiveOption(pProgramIncentiveOptionID);
        } catch (Exception e) {
            if (e.getCause() != null) {
                SQLIntegrityConstraintViolationException result = (SQLIntegrityConstraintViolationException) e.getCause();
                throw result;
            } else {
                throw e;
            }
        }
    }

    /**
     * Save the program Incentive Options to all the sites (subgroups)
     * of this group (with the same Effective Date).
     */
    @Override
    public void saveProgramIncentiveOptionsAllSites(BusinessProgram pBusinessProgram, ArrayList<ProgramIncentiveOption> pProgramIncentiveOptions, String pUserID) throws BPMException, DataAccessException {
        Collection<EmployerGroup> lEmployerGroups = getBusinessProgramInSameYear(pBusinessProgram.getProgramID());
        saveProgramIncentiveOptionsToSites(pBusinessProgram, pProgramIncentiveOptions, lEmployerGroups, pUserID);
        return;
    }

    /**
     * Save the program Incentive Options to all the sites (subgroups)
     * in the input list.
     */
    @Override
    @Transactional(timeout = 60, rollbackFor = { DataAccessException.class, Exception.class })
    public void saveProgramIncentiveOptionsToSites(BusinessProgram pBusinessProgram, ArrayList<ProgramIncentiveOption> pProgramIncentiveOptions, Collection<EmployerGroup> pEmployerGroups, String pUserID) throws BPMException, DataAccessException {
        for (EmployerGroup lEmployerGroup : pEmployerGroups) {
            ArrayList<BusinessProgram> lBusinessPrograms = (ArrayList<BusinessProgram>) getBusinessPrograms(pBusinessProgram.getEffectiveDate(), pBusinessProgram.getEmployerGroup().getGroupID(), lEmployerGroup.getSubgroupID());
            for (BusinessProgram lBusinessProgram : lBusinessPrograms) {
                updateProgramIncentiveOption(pProgramIncentiveOptions, lBusinessProgram.getProgramID(), pUserID);
            }
        }
    }

    @Override
    public Collection<LookUpValueCode> getAdditionalInfoFixedNames() throws BPMException, DataAccessException {
        ArrayList<LookUpValueCode> results = (ArrayList<LookUpValueCode>) lookUpValueDAO.getLUVCodesByGroup(BPMAdminConstants.BPM_ADMIN_ADDL_INFO_NMS);
        return results;
    }

    @Override
    public void saveAdditionalInfoToAllSites(BusinessProgram pBusinessProgram, Collection<AdditionalInformation> pAdditionalInfos, String pUserID) throws BPMException, DataAccessException {
        Collection<EmployerGroup> lEmployerGroups = getBusinessProgramInSameYear(pBusinessProgram.getProgramID());
        saveAdditionalInfoToSites(pBusinessProgram, pAdditionalInfos, lEmployerGroups, pUserID);
    }


    @Override
    public void saveAdditionalInfoToSites(BusinessProgram pBusinessProgram, Collection<AdditionalInformation> pAdditionalInfos, Collection<EmployerGroup> pEmployerGroups, String pUserID) throws BPMException, DataAccessException {
        for (EmployerGroup lEmployerGroup : pEmployerGroups) {
            ArrayList<BusinessProgram> lBusinessPrograms = (ArrayList<BusinessProgram>) getBusinessPrograms(pBusinessProgram.getEffectiveDate(), pBusinessProgram.getEmployerGroup().getGroupID(), lEmployerGroup.getSubgroupID());

            for (BusinessProgram lBusinessProgram : lBusinessPrograms) {
                for (int k = 0; k < pAdditionalInfos.size(); k++) {
                    ((ArrayList<AdditionalInformation>) pAdditionalInfos).get(k).setAdditionalProgramID(lBusinessProgram.getProgramID());
                }
                deleteInsertAdditionalInfos((ArrayList<AdditionalInformation>) pAdditionalInfos, pUserID);
            }
        }
    }


    /**
     * Delete all the Additional Information lines for all the sites in a group
     * with the same effective date.
     *
     * @param pBusinessProgram
     * @throws BPMException
     * @throws DataAccessException
     */
    @Override
    public void deleteAdditionalInfosForGroup(BusinessProgram pBusinessProgram) throws BPMException, DataAccessException {
        Collection<EmployerGroup> lEmployerGroups = getSubGroups(pBusinessProgram.getEmployerGroup().getGroupID());

        for (EmployerGroup lEmployerGroup : lEmployerGroups) {
            ArrayList<BusinessProgram> lBusinessPrograms = (ArrayList<BusinessProgram>) getBusinessPrograms(pBusinessProgram.getEffectiveDate(), pBusinessProgram.getEmployerGroup().getGroupID(), lEmployerGroup.getSubgroupID());

            for (BusinessProgram lBusinessProgram : lBusinessPrograms) {
                additionalInfoDAO.deleteAdditionalInfos(lBusinessProgram.getProgramID());
            }
        }
    }

    @Override
    public Collection<LookUpValueCode> getActivityIncentiveTypeCodes() throws BPMException, DataAccessException {
        ArrayList<LookUpValueCode> results = (ArrayList<LookUpValueCode>) lookUpValueDAO.getLUVCodesByGroup(BPMAdminConstants.BPM_LUV_ACTIVITY_INCENTIVE_TYPE_CODE);
        return results;
    }

    @Override
    public Collection<LookUpValueCode> getActivityIncentiveStatusCodes() throws BPMException, DataAccessException {
        ArrayList<LookUpValueCode> results = (ArrayList<LookUpValueCode>) lookUpValueDAO.getLUVCodesByGroup(BPMAdminConstants.BPM_LUV_INCENTED_STATUS);
        return results;
    }

    @Override
    public ArrayList<BPMCollection> getAllCollections() throws BPMException, DataAccessException {
        return collectionDAO.getAllCollections();
    }

    @Override
    public boolean isOneOrMoreRequirementsRegisteredToProgramTierContribution(Integer programID, Integer incentiveOptionID, String incentedStatusTypeCode) throws BPMException, DataAccessException {
        boolean isRegistered = false;
        ArrayList<ProgramContributionTier> lProgramContributionTiers = this.contributionTierDAO.getProgramContributionIncentiveTiers(programID, incentiveOptionID, incentedStatusTypeCode);
        if (lProgramContributionTiers.size() > 0) {
            isRegistered = true;
        }

        return isRegistered;
    }

    /*
     * Check to see if activity requirements defined to incentive option where an activity taken by a participant exists in the
     * person program activity status table.  If it has, the removal of the activity requirement will not be allowed.  Check both existing
     * activity requirements and activity requirements in the process of being removed.
     */
    @Override
    public boolean isOneOrMoreRequirementsRegisteredToPersonProgramStatus(ProgramIncentiveOption lProgramIncentiveOption)
            throws BPMException, DataAccessException {
        boolean isRegistered = false;

        try {
            if (lProgramIncentiveOption.getActivityIncentiveRequirements() != null &&
                    !lProgramIncentiveOption.getActivityIncentiveRequirements().isEmpty()) {
                Collection<ActivityIncentiveRequirement> lActivityIncentiveRequirements = lProgramIncentiveOption.getActivityIncentiveRequirements();
                isRegistered = determineRegisteredToPersonProgramActivityStatus(lActivityIncentiveRequirements);
            }
            if (!isRegistered) {
                if (lProgramIncentiveOption.getActivityIncentiveRequirementsToRemove() != null &&
                        !lProgramIncentiveOption.getActivityIncentiveRequirementsToRemove().isEmpty()) {
                    Collection<ActivityIncentiveRequirement> lActivityIncentiveRequirementsToRemove = lProgramIncentiveOption.getActivityIncentiveRequirementsToRemove();
                    isRegistered = determineRegisteredToPersonProgramActivityStatus(lActivityIncentiveRequirementsToRemove);
                }

            }
        } catch (BPMException e) {
            throw e;
        }

        return isRegistered;
    }

    @Override
    public boolean isActivityRequirementRegisteredToProgramTierContribution(ActivityIncentiveRequirement lActivityIncentiveRequirement) throws BPMException, DataAccessException {

        return this.contributionTierDAO.isActivityRequirementRegisteredToProgramTierContribution(lActivityIncentiveRequirement);
    }

    private boolean determineRegisteredToPersonProgramActivityStatus(Collection<ActivityIncentiveRequirement> lActivityIncentiveRequirements) throws BPMException {
        boolean isRegistered = false;

        try {
            for (ActivityIncentiveRequirement lActivityIncentiveRequirement : lActivityIncentiveRequirements) {
                Collection<ActivityIncentiveDetail> lActivityIncentiveDetails = lActivityIncentiveRequirement.getActivityIncentiveDetails();
                for (ActivityIncentiveDetail lActivityIncentiveDetail : lActivityIncentiveDetails) {
                    if (lActivityIncentiveDetail.getActivityID() != null) {
                        isRegistered = isActivityRequirementRegisteredToPersonProgramActivityStatus(lActivityIncentiveDetail);
                    } else if (lActivityIncentiveDetail.getActivityTypeCodeID() != null) {
                        ArrayList<Activity> lActivityDefinitions = getActivityDefinitionsByType(lActivityIncentiveDetail.getActivityTypeCodeID());
                        lActivityIncentiveDetail.setActivityDefinitions(lActivityDefinitions);
                        isRegistered = isActivityRequirementRegisteredToPersonProgramActivityStatus(lActivityIncentiveDetail);

                    }
                }
            }
        } catch (BPMException e) {
            throw e;
        }

        return isRegistered;
    }

    @Override
    public boolean isActivityRequirementRegisteredToPersonProgramActivityStatus(ActivityIncentiveDetail lActivityIncentiveDetail) throws BPMException, DataAccessException {

        boolean isRegistered = false;
        Integer programID = lActivityIncentiveDetail.getProgramID();
        if (lActivityIncentiveDetail.getActivityID() != null) {
            isRegistered = personDAO.isActivityRequirementRegisteredToPersonProgramActivityStatus(programID, lActivityIncentiveDetail.getActivityID());
        } else {
            Collection<Activity> lActivityDefinitions = lActivityIncentiveDetail.getActivityDefinitions();
            for (Activity lActivityDefinition : lActivityDefinitions) {
                isRegistered = personDAO.isActivityRequirementRegisteredToPersonProgramActivityStatus(programID, lActivityDefinition.getActivityID());
                if (isRegistered) {
                    break;
                }
            }
        }

        return isRegistered;
    }

    @Override
    public ArrayList<Activity>  getActivityDefinitionsByType(int activityTypeID) {
        return activityDAO.getActivityDefinitionsByType(activityTypeID);
    }

    /**
     * Only allow the update if activity incentive id is null indicating it is a new activity being added within the activity incentive requirement.
     * @param pActivityIncentiveRequirement
     * @return
     */
    @Override
    public int updateActivityIncentiveDetailDirectly(ActivityIncentiveRequirement pActivityIncentiveRequirement, String pUserID) throws BPMException, DataAccessException {
        if (pActivityIncentiveRequirement.getActivityIncentiveDetails() != null) {
            ArrayList<ActivityIncentiveDetail> lActivityIncentiveDetails = pActivityIncentiveRequirement.getActivityIncentiveDetails();
            for (ActivityIncentiveDetail lActivityIncentiveDetail : lActivityIncentiveDetails) {
                if (lActivityIncentiveDetail.getActivityIncentiveID() == null) {
                    lActivityIncentiveDetail.setGroupID(pActivityIncentiveRequirement.getGroupID());
                    Integer newActivityIncentiveID = activityIncentiveDAO.updateActivityIncentiveDetailDirectly(lActivityIncentiveDetail, pUserID);

                    if (lActivityIncentiveDetail.getIncentiveParticipantRelationships() != null) {

                        ArrayList<IncentiveParticipantRelationship> lIncentiveParticipantRelationships  = lActivityIncentiveDetail.getIncentiveParticipantRelationships();
                        for (IncentiveParticipantRelationship lIncentiveParticipantRelationship : lIncentiveParticipantRelationships) {
                            //delete and add relationship.
                            lIncentiveParticipantRelationship.setActivityIncentiveID(newActivityIncentiveID);
                            activityIncentiveDAO.updateIncentiveParticipant(lIncentiveParticipantRelationship, pUserID);
                        }
                    }
                }
            }
        }

        return 0;
    }

    @Override
    public int deleteActivityIncentiveRequirement(Integer pProgramID, Integer pIncentiveOptionID) throws BPMException, DataAccessException {
        activityIncentiveDAO.deleteIncentiveParticipant(pProgramID, pIncentiveOptionID);
        activityIncentiveDAO.deleteActivityIncentiveDetail(pProgramID, pIncentiveOptionID);
        activityIncentiveDAO.deleteIncentiveRequirement(pProgramID, pIncentiveOptionID);

        return 0;
    }

    @Override
    public void saveProgramIncentiveActivitiesAllSites(BusinessProgram pBusinessProgram, ProgramIncentiveOption pProgramIncentiveOption, String pUserID) throws BPMException, DataAccessException {
        Collection<EmployerGroup> lEmployerGroups = getBusinessProgramInSameYear(pBusinessProgram.getProgramID());
        saveProgramIncentiveActivitiesToSites(pBusinessProgram, pProgramIncentiveOption, lEmployerGroups, pUserID);
    }

    /**
     * Save ProgramIncentiveActivities to Selected Sites.
     *
     * @param pBusinessProgram
     * @param pProgramIncentiveOption
     * @param pEmployerGroups
     * @param pUserID
     * @throws BPMException
     * @throws DataAccessException
     */
    @Override
    public void saveProgramIncentiveActivitiesToSites(BusinessProgram pBusinessProgram, ProgramIncentiveOption pProgramIncentiveOption, Collection<EmployerGroup> pEmployerGroups, String pUserID) throws BPMException, DataAccessException {
        for (EmployerGroup lEmployerGroup : pEmployerGroups) {
            ArrayList<BusinessProgram> lBusinessPrograms = (ArrayList<BusinessProgram>) getBusinessPrograms(pBusinessProgram.getEffectiveDate(), pBusinessProgram.getEmployerGroup().getGroupID(), lEmployerGroup.getSubgroupID());

            for (BusinessProgram lBusinessProgram : lBusinessPrograms) {
                deleteActivityIncentiveRequirement(lBusinessProgram.getProgramID(), pProgramIncentiveOption.getIncentiveOption().getIncentiveOptionID());

                for (ActivityIncentiveRequirement lActivityIncentiveRequirement : pProgramIncentiveOption.getActivityIncentiveRequirements()) {
                    lActivityIncentiveRequirement.setProgramID(lBusinessProgram.getProgramID());

                    for (ActivityIncentiveDetail lActivityIncentiveDetail : lActivityIncentiveRequirement.getActivityIncentiveDetails()) {
                        lActivityIncentiveDetail.setProgramID(lBusinessProgram.getProgramID());
                    }

                    updateActivityIncentiveRequirement(lActivityIncentiveRequirement, pUserID);
                }
            }
        }
    }

    @Override
    public Collection<LookUpValueCode> getBenefitContractTypes() throws BPMException, DataAccessException {
        ArrayList<LookUpValueCode> results = (ArrayList<LookUpValueCode>) lookUpValueDAO.getLUVCodesByGroup(BPMAdminConstants.BPM_LUV_BEN_CONTRACT_TP);
        for (LookUpValueCode lLookUpValueCode : results) {
            if (lLookUpValueCode.getLuvDesc().equals("UNRESOLVED")) {
                results.remove(lLookUpValueCode);
                break;
            }
        }

        return results;
    }

    public Collection<LookUpValueCode> getMemberStatusCodes()
            throws BPMException, DataAccessException {
        ArrayList<LookUpValueCode> results = (ArrayList<LookUpValueCode>) lookUpValueDAO
                .getLUVCodesByGroup(BPMAdminConstants.BPM_ADMIN_MEMBER_STATUS);

        return results;
    }

    @Override
    public Collection<ContributionGridBenefitContractTypeRelationship> getContributionGridBenefitContractTypeRelationships(Integer benefitContractTypeID) throws DataAccessException {
        return this.contributionGridDAO.getContributionGridBenefitContractTypeRelationships(benefitContractTypeID);
    }

    @Override
    public LookUpValueCode getBenefitContractTypeById(Integer id) throws BPMException, DataAccessException {
        LookUpValueCode results = lookUpValueDAO.getLUVCodeById(id);
        return results;
    }

    @Override
    public int deleteProgramContributionGrids(Collection<ProgramContributionGrid> lremovedProgramContributionGrids) throws BPMException, DataAccessException {
        DefaultTransactionDefinition def = new DefaultTransactionDefinition();
        def.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRED);
        TransactionStatus status = txManager.getTransaction(def);

        int lNumberDeleted = 0;

        try {
            for (ProgramContributionGrid lremovedProgramContributionGrid : lremovedProgramContributionGrids) {
                lNumberDeleted = contributionGridDAO.deleteProgramContributionGridByUID(lremovedProgramContributionGrid.getContributionGridID());
            }
            txManager.commit(status);
        } catch (DataAccessException dae) {
            // Rollback the transaction on error.
            txManager.rollback(status);
            logger
                    .error("An unexpected error has occured: "
                            + dae.getMessage(), dae);
            throw dae;
        } catch (Exception e) {
            // Rollback the transaction on error.
            txManager.rollback(status);
            logger.error("An unexpected error has occured: " + e.getMessage(),
                    e);
            throw new BPMException(e);
        }


        return lNumberDeleted;
    }

    @Override
    public LookUpValueCode getContributionAmountLimit(String value) throws BPMException, DataAccessException {
        Collection<LookUpValueCode> results = lookUpValueDAO.getLUVCodesByGroup(value);

        LookUpValueCode result = results.iterator().next();

        return result;
    }

    @Override
    public Collection<Risk> selectRisks() throws BPMException, DataAccessException {
        return riskDAO.getAllRisks();
    }

    @Override
    public List<ParticipationGroupRequirement> getParticipationGroupRequirements(Integer lParticipationGroupID) throws BPMException, DataAccessException {
        return participationGroupDAO.getParticipationGroupRequirements(lParticipationGroupID);
    }

    @Override
    public ArrayList<CollectionActivity> getCollectionActivities(Integer pCollectionID) throws BPMException, DataAccessException {
        return this.collectionDAO.getCollectionActivities(pCollectionID);
    }

    @Override
    public ArrayList<ExtEmployerActivity> getExtEmployerActivities() throws DataAccessException {
        return activityDAO.getExtEmployerActivities();
    }

    @Override
    public Collection<EmployerGroup> getAllBPMGroups() throws BPMException, DataAccessException {
        return businessProgramDAO.getAllBPMGroups();
    }

    @Override
    public ArrayList<GroupOverride> getGroupOverrideByGroupNumber(String groupNumber) throws BPMException {
        return groupOverrideDAO.getGroupOverrideByGroupNumber(groupNumber);
    }

    @Override
    public ArrayList<GroupOverride> getGroupOverrideByGroupID(Integer groupID) throws BPMException {
        return groupOverrideDAO.getGroupOverrideByGroupID(groupID);
    }

    @Override
    public Collection<GroupOverride> getGroupOverridesAll() throws BPMException {
        return groupOverrideDAO.getGroupOverrides();
    }

    @Override
    public ArrayList<GroupOverride> getAssignedSitesForGroupSiteException(String groupNumber) throws BPMException {
        return groupOverrideDAO.getAssignedSitesForGroupSiteException(groupNumber);
    }

    @Override
    public ArrayList<GroupOverride> getAvailableSitesForGroupSiteException(String groupNumber) throws BPMException {
        return groupOverrideDAO.getAvailableSitesForGroupSiteException(groupNumber);
    }

    public Collection<RejectedPerson> getEmployerRecycle(Integer activityId,
                                                         String firstName, String lastName, Date activityDate, Date recycleStatusDate, Integer recycleStatusId)
            throws DataAccessException
    {
        return employerRecycleDAO.getEmployerRecycle(activityId, firstName, lastName, activityDate, recycleStatusDate, recycleStatusId);
    }

    public RejectedPerson getEmployerRecycle(Integer recycleStatusId)
            throws BPMException, DataAccessException
    {
        return employerRecycleDAO.getEmployerRecycle(recycleStatusId);
    }

    public void updateEmployerRecycle(RejectedPerson pRejectedPerson, String pUserID)
            throws BPMException, DataAccessException
    {
        DefaultTransactionDefinition def = new DefaultTransactionDefinition();
        def.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRED);
        TransactionStatus status = txManager.getTransaction(def);
        try {
           employerRecycleDAO.updateEmployerRecycle(pRejectedPerson, pUserID);
            txManager.commit(status);
        } catch (DataAccessException dae) {
        // Rollback the transaction on error.
        txManager.rollback(status);
        logger.error("An unexpected error has occured: " + dae.getMessage(), dae);
        throw dae;

    } catch (Exception e) {
        // Rollback the transaction on error.
        txManager.rollback(status);
        logger.error("An unexpected error has occured: " + e.getMessage(), e);
        throw new BPMException(e);
    }

}
    @Override
    public Collection<QualificationCheckmark> getExpiredQualificationCheckmarks() throws BPMException, DataAccessException {
        return qualificationCheckmarkDAO.getExpiredQualificationCheckmarks();
    }

    @Override
    public int deleteQualificationCheckmark(Integer pQualificationCheckmarkID) throws BPMException, DataAccessException {
        qualificationCheckmarkDAO.deleteCheckmarkDetails(pQualificationCheckmarkID);
        qualificationCheckmarkDAO.deleteCheckmarkRequirements(pQualificationCheckmarkID);
        return this.qualificationCheckmarkDAO.deleteQualificationCheckmark(pQualificationCheckmarkID);
    }

    @Override
    public Collection<LookUpValueCode> getQualificationStatusCodes() throws BPMException, DataAccessException {
        ArrayList<LookUpValueCode> results = (ArrayList<LookUpValueCode>) lookUpValueDAO.getLUVCodesByGroup(BPMAdminConstants.BPM_LUV_QUALIFICATION_STATUS_CODES);
        return results;
    }

    public Collection<Activity> getActivitiesWithMemberAndTransactionDate(String memberId, Date transactionDate) throws BPMException, DataAccessException {
        return getActivityDAO().selectActivitiesWithMemberAndTransactionDate(memberId, transactionDate);
    }

    public Collection<EmployerGroup> getBPMGroupsForMemberAndTransactionDate(String memberId, Date transactionDate) throws BPMException,
            DataAccessException {
        return businessProgramDAO.getBPMGroupsForMemberAndTransactionDate(memberId, transactionDate);
    }

    public Collection<LookUpValueCode> getContractStatusCodes()
            throws BPMException, DataAccessException {
        ArrayList<LookUpValueCode> results = (ArrayList<LookUpValueCode>) lookUpValueDAO
                .getLUVCodesByGroup(BPMAdminConstants.BPM_ADMIN_CONTRACT_STATUS);

        return results;
    }

    @Override
    public int updateQualificationCheckmark(QualificationCheckmark pQualificationCheckmark, String pModifyUserID) throws BPMException, DataAccessException {
        int rowsInserted = 0;

        if (isCheckmarkDetailUsed(pQualificationCheckmark)) {
            rowsInserted = updateQualificationCheckmarkDirectly(pQualificationCheckmark, pModifyUserID);
            return rowsInserted;
        }

        // Users can add or remove Requirements, and within each requirement add
        // or remove activities.
        // So delete the details (activities) and requirements first.
        // Insert or update the Qualification Checkmark.
        // Then insert the Requirements, and the Checkmark details.

        qualificationCheckmarkDAO.deleteCheckmarkDetails(pQualificationCheckmark.getQualificationCheckmarkID());
        qualificationCheckmarkDAO.deleteCheckmarkRequirements(pQualificationCheckmark.getQualificationCheckmarkID());

        // Update method in the DAO will determine whether to insert or to
        // update.
        rowsInserted = qualificationCheckmarkDAO.updateQualificationCheckmark(pQualificationCheckmark, pModifyUserID);

        // Set the ID in the Requirements in case this was an insert and a new
        // ID was generated.
        for (int i = 0; i < pQualificationCheckmark.getCheckmarkRequirements().size(); i++) {
            pQualificationCheckmark.getCheckmarkRequirements().get(i).setQualificationCheckmarkID(pQualificationCheckmark.getQualificationCheckmarkID());
        }

        // Update the requirements (Activities) and also update
        // eligible program activities if they do not have the same activities
        // as the checkmark.
        insertCheckmarkRequirements(pQualificationCheckmark, pModifyUserID);

        return rowsInserted;
    }

    /*
     * Determine if checkmark detail id is registered to the contribution grid;
     */
    public boolean isCheckmarkDetailUsed(QualificationCheckmark pQualificationCheckmark) {

        boolean isUsed = false;

        ArrayList<CheckmarkRequirement> pCheckmarkRequirements = pQualificationCheckmark.getCheckmarkRequirements();

        for (CheckmarkRequirement pCheckmarkRequirement : pCheckmarkRequirements) {
            ArrayList<CheckmarkDetail> pCheckmarkDetails = pCheckmarkRequirement.getCheckmarkDetails();
            for (CheckmarkDetail pCheckmarkDetail : pCheckmarkDetails) {
                if (pCheckmarkDetail.isUsed()) {
                    isUsed = true;
                    break;
                }
            }
            if (isUsed) {
                break;
            }
        }

        return isUsed;
    }

    private void insertCheckmarkRequirements(QualificationCheckmark pQualificationCheckmark, String pModifyUserID) throws BPMException, DataAccessException {
        // Insert the Requirements.
        qualificationCheckmarkDAO.insertCheckmarkRequirements(pQualificationCheckmark.getCheckmarkRequirements(), pModifyUserID);

        // Insert the Details.
        for (int i = 0; i < pQualificationCheckmark.getCheckmarkRequirements().size(); i++) {
            for (int j = 0; j < pQualificationCheckmark.getCheckmarkRequirements().get(i).getCheckmarkDetails().size(); j++) {
                pQualificationCheckmark.getCheckmarkRequirements().get(i)
                        .getCheckmarkDetails().get(j)
                        .setQualificationCheckmarkID(
                                pQualificationCheckmark
                                        .getQualificationCheckmarkID());
            }
            qualificationCheckmarkDAO.insertCheckmarkDetails(pQualificationCheckmark.getCheckmarkRequirements().get(i).getCheckmarkDetails(), pModifyUserID);
        }

        /*
         *
         * Now find all the business programs that have this qualfication
         * checkmark. And make sure that the checkmark activities
         * are part of the program eligible activities.
         */
        ArrayList<Integer> lProgramIDList = qualificationCheckmarkDAO.getProgramsForCheckmark(pQualificationCheckmark.getQualificationCheckmarkID());

        for (Integer lProgramID : lProgramIDList) {
            updateEligibleActivitiesFromCheckmark(lProgramID, pQualificationCheckmark.getQualificationCheckmarkID(), pModifyUserID);
        }
    }

    private int updateQualificationCheckmarkDirectly(QualificationCheckmark pQualificationCheckmark, String pModifyUserID) throws BPMException, DataAccessException {
        try {
            // Insert the Requirements.  Read for record.  If there, bypass if not add it.
            qualificationCheckmarkDAO.updateCheckmarkRequirementsDirectly(
                    pQualificationCheckmark.getCheckmarkRequirements(),
                    pModifyUserID);

            // Insert the Details.
            for (int i = 0; i < pQualificationCheckmark.getCheckmarkRequirements().size(); i++) {
                for (int j = 0; j < pQualificationCheckmark.getCheckmarkRequirements().get(i).getCheckmarkDetails().size(); j++) {
                    pQualificationCheckmark.getCheckmarkRequirements().get(i)
                            .getCheckmarkDetails().get(j)
                            .setQualificationCheckmarkID(
                                    pQualificationCheckmark
                                            .getQualificationCheckmarkID());
                }
                //Read for checkmark detail.  If there, bypass.  If not insert.
                qualificationCheckmarkDAO.updateCheckmarkDetailsDirectly(
                        pQualificationCheckmark.getCheckmarkRequirements().get(i)
                                .getCheckmarkDetails(), pModifyUserID);
            }
        } catch (BPMException e) {
            logger.error("BPMException Error at updateQualificationCheckmarkDirectly. Error is " + e);
            throw e;
        } catch (DataAccessException da) {
            logger.error("DataAccessException Error at updateQualificationCheckmarkDirectly. Error is " + da);
            throw da;
        }

        return 0;
    }


    public ActivityDAO getActivityDAO() {
        return activityDAO;
    }

    public ActivityIncentiveDAO getActivityIncentiveDAO() {
        return activityIncentiveDAO;
    }

    public RewardCardDAO getRewardCardDAO() {
        return rewardCardDAO;
    }

    public AdditionalInfoDAO getAdditionalInfoDAO() {
        return additionalInfoDAO;
    }
}
