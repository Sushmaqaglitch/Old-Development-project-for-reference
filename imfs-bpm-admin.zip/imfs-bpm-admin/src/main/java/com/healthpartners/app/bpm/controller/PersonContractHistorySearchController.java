package com.healthpartners.app.bpm.controller;

import com.healthpartners.app.bpm.common.BPMAdminConstants;
import com.healthpartners.app.bpm.common.BPMAdminUtils;
import com.healthpartners.app.bpm.common.BPMPagination;
import com.healthpartners.app.bpm.dto.LookUpValueCode;
import com.healthpartners.app.bpm.dto.PersonContractHist;
import com.healthpartners.app.bpm.exception.BPMException;
import com.healthpartners.app.bpm.form.*;
import com.healthpartners.app.bpm.iface.MemberService;
import com.healthpartners.app.bpm.pageable.PageablePersonContractHist;
import com.healthpartners.service.bpm.common.BPMConstants;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

@Controller
public class PersonContractHistorySearchController extends BaseController implements Validator {

    protected final Log logger = LogFactory.getLog(this.getClass());
    private MemberService memberService;

    private String delimiter = ",";
    private String space = " ";

    public PersonContractHistorySearchController(MemberService memberService) {
        this.memberService = memberService;
    }

    SimpleDateFormat fmt = new SimpleDateFormat(
            BPMAdminConstants.HP_BPM_ADMIN_UI_COMMON_DATE_FORMAT);

    @GetMapping("/showPersonContractHistorySearch")
    public String loadSearch(ModelMap modelMap) throws Exception {
        PersonContractHistorySearchForm personContractHistorySearchForm = new PersonContractHistorySearchForm();
        personContractHistorySearchForm.setActionType(ACTION_SEARCH);
        load(modelMap, personContractHistorySearchForm);
        modelMap.put("personContractHistorySearchForm", personContractHistorySearchForm);
        return "personContractHistorySearch";
    }

    @PostMapping("/personContractHistorySearch")
    public String submitSearch(@ModelAttribute("personContractHistorySearchForm") PersonContractHistorySearchForm form, ModelMap modelMap, BindingResult result) throws Exception {
        try {
            if (StringUtils.isEmpty(form.getActionType())) {
                form.setActionType(ACTION_SEARCH);
            }
            if (ACTION_SEARCH.equals(form.getActionType())) {
                validate(form, result);
            }

            if (!result.hasErrors()) {
               // clearForm(form);
                search(form, modelMap);
            }
        } catch (Exception e) {
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
            // Add error stack trace on the request, to be hidden in html.
            modelMap.put("errorMsg", getStackTrace(e));
        }

        return "personContractHistorySearch";
    }

    @PostMapping(value = "/personContractHistorySearch", params = "next")
    public String submitNext(@ModelAttribute("personContractHistorySearchForm") PersonContractHistorySearchForm form, ModelMap modelMap) throws Exception {
        form.setActionType(ACTION_PAGE_FORWARD);
        handlePaginationActions(form, modelMap);
        return "personContractHistorySearch";
    }

    @PostMapping(value = "/personContractHistorySearch", params = "back")
    public String submitBack(@ModelAttribute("personContractHistorySearchForm") PersonContractHistorySearchForm form, ModelMap modelMap) throws Exception {
        form.setActionType(ACTION_PAGE_BACK);
        handlePaginationActions(form, modelMap);
        return "personContractHistorySearch";
    }

    @PostMapping(value = "/personContractHistorySearch", params = "download")
    public String submitDownload(@ModelAttribute("personContractHistorySearchForm") PersonContractHistorySearchForm form,
                                 HttpServletRequest request, ModelMap modelMap, HttpServletResponse response) throws Exception {
        form.setActionType(ACTION_DOWNLOAD_PERSON_CONTRACT_HIST_PAGE);
        handleDownload(form, request, modelMap, response);
        return "personContractHistorySearch";
    }


    private void load(ModelMap modelMap, PersonContractHistorySearchForm form) throws BPMException {
        ArrayList<LookUpValueCode> luvContractHistResultCodes = (ArrayList<LookUpValueCode>) memberService.getLUVCodesByGroup(BPMConstants.BPM_CONTRACT_HIST_RESULT);

        //Default list to using Current View.
        for (LookUpValueCode contractHistResultCode : luvContractHistResultCodes) {
            if (contractHistResultCode.getLuvVal().equals(BPMConstants.BPM_CONTRACT_HIST_RESULT_CURRENT)) {
                form.setLuvContractHistResultCodeID(contractHistResultCode.getLuvId());
                form.setLuvContractHistResultCodeValue(contractHistResultCode.getLuvDesc());
                break;
            }
        }

        BPMPagination pagination = new BPMPagination();
        pagination.disableBackNextButtons();
        modelMap.put("backPageFlag", pagination.getBackPageFlag());
        modelMap.put("nextPageFlag", pagination.getNextPageFlag());
        modelMap.put("personContractHistorySearchForm", form);
        modelMap.put("luvContractHistResultCodes", luvContractHistResultCodes);
        getUserSession().setLuvContractHistResultCodes(luvContractHistResultCodes);
        getUserSession().setPagination(pagination);
    }

    private void search(PersonContractHistorySearchForm form, ModelMap modelMap) throws Exception {
        boolean newPaginationList = false;
        try {
            String luvContractHistResultCodeValue = form.getLuvContractHistResultCodeValue();
            java.util.Date lProgramEffectiveDate = null;
            java.sql.Date lSearchProgramEffectiveDate = null;
            if (form.getProgramEffectiveDate() != null && form.getProgramEffectiveDate().length() > 0) {
                lProgramEffectiveDate = fmt.parse(form.getProgramEffectiveDate());
                lSearchProgramEffectiveDate = new java.sql.Date(lProgramEffectiveDate.getTime());
            }
            ArrayList<PersonContractHist> lPersonContractHist = memberService.getMemberContractsHistory(form.getMemberID(), form.getContractNo(), lSearchProgramEffectiveDate, form.getGroupNo(), luvContractHistResultCodeValue);
            getUserSessionSupport().getUserSession().setPersonContractHistory(lPersonContractHist);
            newPaginationList = true;
            setPersonContractHistoryPagination(modelMap, getUserSession(), form.getActionType(), newPaginationList);
            //Pagination code ends here.

            modelMap.put("personContractHistorySearchForm", form);


            modelMap.put("luvContractHistResultCodes", getUserSession().getLuvContractHistResultCodes());
        }
            catch (Exception e) {
                logger.error("An unexpected error has occurred: " + e.getMessage(), e);
                // Add error stack trace on the request, to be hidden in html.
                createErrorMessageOnModel(modelMap, getStackTrace(e));
            }

    }

    @Override
    public boolean supports(Class<?> clazz) {
        return PersonContractHistorySearchForm.class.isAssignableFrom(clazz);
    }

    @Override
    public void validate(Object target, Errors errors) {
        PersonContractHistorySearchForm form = (PersonContractHistorySearchForm) target;
        boolean minimumOneSearchTarget = false;
        String groupNo = form.getGroupNo();
        String contractNo = form.getContractNo();
        String memberID = form.getMemberID();
        String programEffectiveDate = form.getProgramEffectiveDate();
        String luvContractHistResultCodeValue = form.getLuvContractHistResultCodeValue();
        if (groupNo != null && groupNo.length() > 0) {
            getValidationSupport().validateNotInteger("groupNo", groupNo,  errors, new Object[]{"Group Number"});
            minimumOneSearchTarget = true;
        }

        if (contractNo != null && contractNo.length() > 0) {
            getValidationSupport().validateNotInteger("contractNo", contractNo, errors,new Object[]{"Contract Number"});
            minimumOneSearchTarget = true;
        }

        if (memberID != null && memberID.length() > 0) {
            getValidationSupport().validateNotInteger("memberID", memberID, errors,new Object[]{"Member ID"});
            minimumOneSearchTarget = true;
        }


        if (programEffectiveDate != null && programEffectiveDate.length() > 0) {
            getValidationSupport().validateDateFormat("programEffectiveDate", programEffectiveDate.toString(),
                    errors,new Object[]{"Program Effective Date"});
        }

        //this.validateNotNull("Program Effective Date", programEffectiveDate, " Program Effective Date");

        getValidationSupport().validateRequiredFieldIsNotEmpty("Contract History Result", luvContractHistResultCodeValue, errors,new Object[]{" Contract History Result"});

        if (luvContractHistResultCodeValue != null) {
            getValidationSupport().validateNotSelected("luvContractHistResultCodeValue",
                    luvContractHistResultCodeValue, errors,new Object[]{"Contract History Results"});
        }



        if (!minimumOneSearchTarget) {

            getValidationSupport().validateAtleastOneSelection("groupNo",
                    form.getGroupNo(), errors,new Object[]{"field element to search on."});

        }
    }
    protected String getStackTrace(Throwable t) {
        StringWriter stringWritter = new StringWriter();
        PrintWriter printWritter = new PrintWriter(stringWritter, true);
        t.printStackTrace(printWritter);
        printWritter.flush();
        stringWritter.flush();
        return stringWritter.toString();
    }


    private void handlePaginationActions(PersonContractHistorySearchForm form, ModelMap modelMap) {
        ArrayList<PersonContractHist> lPersonContractsHistory = getUserSession().getPersonContractHistory();
        BPMPagination pagination = getUserSession().getPaginationMap().get(PERSON_CONTRACT_HISTORY_LIST);

        PageablePersonContractHist lPCH = null;
        if (pagination == null)
        {
            lPCH = new PageablePersonContractHist(lPersonContractsHistory);
            lPCH.addRowNumber();
            pagination = new BPMPagination(lPCH, new ArrayList<Object>(lPersonContractsHistory));
            getUserSession().getPaginationMap().put(PERSON_CONTRACT_HISTORY_LIST, pagination);
        }

        ArrayList<PersonContractHist> lPersonContractsHistoryPerPage = (ArrayList<PersonContractHist>)
                determineNextOrBackAction(form.getActionType(), pagination);
        setAttributesForPaginationOnModel(modelMap,lPersonContractsHistory.size(), pagination );

        modelMap.put("personContractsHistory", lPersonContractsHistoryPerPage);
        getUserSession().setPersonContractHistory(lPersonContractsHistory);
    }

    protected void setAttributesForPaginationOnModel(ModelMap modelMap, Integer resultSize, BPMPagination pBPMPagination) {
        modelMap.put("resultSize", String.valueOf(resultSize));
        if (pBPMPagination != null) {
            modelMap.put("startPageCt", Integer.toString(pBPMPagination.getStartPageCt()));
            modelMap.put("endPageCt", Integer.toString(pBPMPagination.getEndPageCt()));
        }
        setAttributesBackAndNextButtonsOnModel(modelMap, pBPMPagination);
    }
    protected List determineNextOrBackAction(String actionType
            , BPMPagination pBPMPagination)
    {
        List objectListPage = null;
        if (ACTION_PAGE_BACK.equals(actionType))
        {
            objectListPage = pBPMPagination.moveBack();
        }
        else if (ACTION_PAGE_FORWARD.equals(actionType))
        {
            objectListPage = pBPMPagination.moveNext();
        }
        else
        {
            //objectListPage = pBPMPagination.addRowNumbers();
            objectListPage = pBPMPagination.getPageList();
            ArrayList<Object> arrayPageList = (ArrayList<Object>) objectListPage;
            pBPMPagination.setPageList(arrayPageList);
            objectListPage = pBPMPagination.moveNext();
        }

        return objectListPage;
    }


    private void handleDownload(PersonContractHistorySearchForm form, HttpServletRequest request, ModelMap modelMap, HttpServletResponse response) throws IOException {
        if(ACTION_DOWNLOAD_PERSON_CONTRACT_HIST_PAGE.equals(form.getActionType())) {

            if (getUserSession().getPersonContractHistory() != null && getUserSession().getPersonContractHistory().size() > 0) {
                response.setHeader("Content-Type", "text/csv");
                response.setHeader("Content-Disposition", "attachment;filename=\"report.csv\"");
                writeCsv(getUserSession().getPersonContractHistory(), response.getOutputStream());
            } else {
                String message = getMessage("errors.download", null);
                List<String> messages = new ArrayList<>();
                messages.add(message);
                request.setAttribute("messages", messages);
                modelMap.put("messages", messages);
                // No pagination needed when list is empty.
                request.setAttribute("luvProductTypes", getUserSession().getProductTypes());
                request.setAttribute("luvReportTypes", getUserSession().getReportTypes());

            }
        }
    }

    private void writeCsv (Collection<PersonContractHist> csv, OutputStream output) throws IOException {
        BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(output, "UTF-8"));

        formatForFulfillDetailHeaderNWrite(writer);

        for (PersonContractHist lPersonContractHist : csv) {
            formatForFulfillDetailNWrite(writer, lPersonContractHist);
        }

        closeFileWriter(writer);

    }
    public void closeFileWriter(BufferedWriter writer) {
        try {
            writer.flush();
            writer.close();
        } catch(IOException e)
        {
            e.printStackTrace();
        }
    }


    private void formatForFulfillDetailHeaderNWrite(BufferedWriter writer) throws IOException {

        writer.append("No");
        writer.append(delimiter);

        writer.append("Member ID");
        writer.append(delimiter);

        writer.append("Member Status");
        writer.append(delimiter);

        writer.append("Member Status Date");
        writer.append(delimiter);

        writer.append("Contract No");
        writer.append(delimiter);

        writer.append("Contract Status");
        writer.append(delimiter);

        writer.append("Contract Status Date");
        writer.append(delimiter);

        writer.append("Run Date");
        writer.append(delimiter);

        writer.append("Group No");
        writer.append(delimiter);

        writer.append("Site No");
        writer.append(delimiter);

        writer.append("Group Name");
        writer.append(delimiter);

        writer.append("Site Name");
        writer.append(delimiter);

        writer.append("Qual Start Date");
        writer.append(delimiter);

        writer.append("Qual End Date");
        writer.append(delimiter);

        writer.append("Prog Start Date");
        writer.append(delimiter);

        writer.append("Prog End Date");
        writer.append(delimiter);

        writer.append("Program Name");
        writer.append(delimiter);

        writer.append("Incentive Option");
        writer.append(delimiter);

        writer.append("Activation Status");

        writer.newLine();
    }


    private void formatForFulfillDetailNWrite(BufferedWriter writer, PersonContractHist lPersonContractHist ) throws IOException {

        writer.append(Integer.toString(lPersonContractHist.getRowNumber()));
        writer.append(delimiter);

        if (lPersonContractHist.getMemberID() != null) {
            writer.append(lPersonContractHist.getMemberID());
            writer.append(delimiter);
        } else {
            writer.append(space);
            writer.append(delimiter);
        }

        if (lPersonContractHist.getMemberStatus() != null) {
            writer.append(lPersonContractHist.getMemberStatus());
            writer.append(delimiter);
        } else {
            writer.append(space);
            writer.append(delimiter);
        }

        if (lPersonContractHist.getMemberStatusDate() != null) {
            writer.append(BPMAdminUtils.formatDateMMddyyyy(lPersonContractHist.getMemberStatusDate()));
            writer.append(delimiter);
        } else {
            writer.append(space);
            writer.append(delimiter);
        }

        if (lPersonContractHist.getContractNumber() != null) {
            writer.append(String.valueOf(lPersonContractHist.getContractNumber()));
            writer.append(delimiter);
        } else {
            writer.append(space);
            writer.append(delimiter);
        }


        if (lPersonContractHist.getContractStatus() != null) {
            writer.append(lPersonContractHist.getContractStatus());
            writer.append(delimiter);
        } else {
            writer.append(space);
            writer.append(delimiter);
        }

        if (lPersonContractHist.getContractStatusDate() != null) {
            writer.append(BPMAdminUtils.formatDateMMddyyyy(lPersonContractHist.getContractStatusDate()));
            writer.append(delimiter);
        } else {
            writer.append(space);
            writer.append(delimiter);
        }

        if (lPersonContractHist.getRunDate() != null) {
            writer.append(BPMAdminUtils.formatDateMMddyyyy(lPersonContractHist.getRunDate()));
            writer.append(delimiter);
        } else {
            writer.append(space);
            writer.append(delimiter);
        }

        writer.append(lPersonContractHist.getGroupNumber());
        writer.append(delimiter);

        writer.append(lPersonContractHist.getGroupSiteNumber());
        writer.append(delimiter);

        writer.append(lPersonContractHist.getGroupName());
        writer.append(delimiter);

        writer.append(lPersonContractHist.getGroupSiteName());
        writer.append(delimiter);

        if (lPersonContractHist.getQualificationStartDate() != null) {
            writer.append(BPMAdminUtils.formatDateMMddyyyy(lPersonContractHist.getQualificationStartDate()));
            writer.append(delimiter);
        } else {
            writer.append(space);
            writer.append(delimiter);
        }

        if (lPersonContractHist.getQualificationEndDate() != null) {
            writer.append(BPMAdminUtils.formatDateMMddyyyy(lPersonContractHist.getQualificationEndDate()));
            writer.append(delimiter);
        } else {
            writer.append(space);
            writer.append(delimiter);
        }


        if (lPersonContractHist.getProgramStartDate() != null) {
            writer.append(BPMAdminUtils.formatDateMMddyyyy(lPersonContractHist.getProgramStartDate()));
            writer.append(delimiter);
        } else {
            writer.append(space);
            writer.append(delimiter);
        }

        if (lPersonContractHist.getProgramEndDate() != null) {
            writer.append(BPMAdminUtils.formatDateMMddyyyy(lPersonContractHist.getProgramEndDate()));
            writer.append(delimiter);
        } else {
            writer.append(space);
            writer.append(delimiter);
        }

        writer.append(lPersonContractHist.getProgramName());
        writer.append(delimiter);

        if (lPersonContractHist.getIncentiveOptionName() != null) {
            writer.append(lPersonContractHist.getIncentiveOptionName());
        } else {
            writer.append(space);
            writer.append(delimiter);
        }

        writer.append(delimiter);
        if (lPersonContractHist.getActivationStatusCode() != null) {
            writer.append(lPersonContractHist.getActivationStatusCode());
        } else {
            writer.append(space);
            writer.append(delimiter);
        }
        writer.newLine();
    }
}
