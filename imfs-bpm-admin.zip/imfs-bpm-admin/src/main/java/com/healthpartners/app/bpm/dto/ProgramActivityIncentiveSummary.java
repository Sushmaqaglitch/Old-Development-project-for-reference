package com.healthpartners.app.bpm.dto;

import java.io.Serializable;
import java.util.ArrayList;


public class ProgramActivityIncentiveSummary implements Serializable {
    static final long serialVersionUID = 0L;
    ArrayList<ActivityIncentiveRequirement> activityIncentiveRequirements;
    // Database table ID.
    private Integer rowID;
    private Integer programID;
    private Integer incentiveOptionID;
    private Integer activityIncentiveGroupID;
    private Integer activityIncentiveGroupReqID;
    private Integer activityIncentiveID;
    private String activityTypeDesc;
    private String activityName;
    private String incentiveOptionName;
    private String relationshipName;
    private String incentiveStatus;

    public Integer getRowID() {
        return rowID;
    }

    public void setRowID(Integer rowID) {
        this.rowID = rowID;
    }

    public Integer getProgramID() {
        return programID;
    }

    public void setProgramID(Integer programID) {
        this.programID = programID;
    }

    public Integer getIncentiveOptionID() {
        return incentiveOptionID;
    }

    public void setIncentiveOptionID(Integer incentiveOptionID) {
        this.incentiveOptionID = incentiveOptionID;
    }

    public Integer getActivityIncentiveGroupID() {
        return activityIncentiveGroupID;
    }

    public void setActivityIncentiveGroupID(Integer activityIncentiveGroupID) {
        this.activityIncentiveGroupID = activityIncentiveGroupID;
    }

    public Integer getActivityIncentiveGroupReqID() {
        return activityIncentiveGroupReqID;
    }

    public void setActivityIncentiveGroupReqID(Integer activityIncentiveGroupReqID) {
        this.activityIncentiveGroupReqID = activityIncentiveGroupReqID;
    }

    public String getActivityTypeDesc() {
        return activityTypeDesc;
    }

    public void setActivityTypeDesc(String activityTypeDesc) {
        this.activityTypeDesc = activityTypeDesc;
    }

    public String getActivityName() {
        return activityName;
    }

    public void setActivityName(String activityName) {
        this.activityName = activityName;
    }

    public String getIncentiveOptionName() {
        return incentiveOptionName;
    }

    public void setIncentiveOptionName(String incentiveOptionName) {
        this.incentiveOptionName = incentiveOptionName;
    }

    public String getRelationshipName() {
        return relationshipName;
    }

    public void setRelationshipName(String relationshipName) {
        this.relationshipName = relationshipName;
    }

    public String getIncentiveStatus() {
        return incentiveStatus;
    }

    public void setIncentiveStatus(String incentiveStatus) {
        this.incentiveStatus = incentiveStatus;
    }

    public Integer getActivityIncentiveID() {
        return activityIncentiveID;
    }

    public void setActivityIncentiveID(Integer activityIncentiveID) {
        this.activityIncentiveID = activityIncentiveID;
    }

    public ArrayList<ActivityIncentiveRequirement> getActivityIncentiveRequirements() {
        return activityIncentiveRequirements;
    }

    public void setActivityIncentiveRequirements(ArrayList<ActivityIncentiveRequirement> activityIncentiveRequirements) {
        this.activityIncentiveRequirements = activityIncentiveRequirements;
    }


}
