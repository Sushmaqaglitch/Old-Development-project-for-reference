/**
 * 
 */
package com.healthpartners.app.bpm.form;

/**
 * @author tjquist
 *
 */
public class ActivityDefinitionForm extends BaseForm {

	static final long serialVersionUID = 0L;
	
	private String actionType;

	public ActivityDefinitionForm() {
		super();
	}

	public String getActionType() {
		return actionType;
	}

	public void setActionType(String actionType) {
		this.actionType = actionType;
	}
	
	
		
}
