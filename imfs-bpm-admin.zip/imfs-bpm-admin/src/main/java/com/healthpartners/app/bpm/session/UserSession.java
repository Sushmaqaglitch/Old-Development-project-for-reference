package com.healthpartners.app.bpm.session;

import com.healthpartners.app.bpm.common.BPMPagination;
import com.healthpartners.app.bpm.dto.*;
import com.healthpartners.app.bpm.form.*;

import java.sql.Date;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;

public class UserSession {
    String databaseEnvironment;
    ArrayList<Activity> activities = new ArrayList<>();
    ArrayList<Activity> expiredActivities = new ArrayList<>();
    ArrayList<String> startDates = new ArrayList<>();
    String groupName;
    ArrayList<EmployerGroup> employerGroups = new ArrayList<>();
    GroupLookupForm groupLookupForm = new GroupLookupForm();
    HashMap<String, BPMPagination> paginationMap = new HashMap<String, BPMPagination>();
    ArrayList<EmployerGroup> employerGroupsPerPage = new ArrayList<>();
    ArrayList<EmployerGroup> availableSites = new ArrayList<>();
    String groupNo;
    ArrayList<LookUpValueCode> reportTypes = new ArrayList<>();
    ArrayList<LookUpValueCode> productTypes = new ArrayList<>();
    ArrayList<LookUpValueCode> cdhpTableTypes = new ArrayList<>();
    ArrayList<CDHPFulfillmentTrackingReportHist> cdhpFulfillmentTrackingReportHistList = new ArrayList<>();
    CDHPFulfillmentSearchForm cdhpFulfillmentSearchForm = new CDHPFulfillmentSearchForm();
    ArrayList<CDHPFulfillmentTrackingReportHist> cdhpFulfillmentTrackingReportHistPerPage = new ArrayList<>();
    ArrayList<PersonActivityContributionPending> personActivityContributionPendingList = new ArrayList<>();
    ActivityIncentiveContributionStatusSearchForm ActivityIncentiveContributionStatusSearchForm = new ActivityIncentiveContributionStatusSearchForm();
    ArrayList<PersonActivityContributionPending> personActivityContributionPendingPerPage = new ArrayList<>();
    ArrayList<LookUpValueCode> exemptionTypes = new ArrayList<>();
    ExemptionHistorySearchForm exemptionHistorySearchForm = new ExemptionHistorySearchForm();
    ArrayList<ExemptionHistory> exemptionHistoryList = new ArrayList<>();
    ArrayList<ExemptionHistory> exemptionHistoryPersPage = new ArrayList<>();
    BPMPagination pagination = new BPMPagination();
    ProgramSearchForm programSearchForm = new ProgramSearchForm();
    ArrayList<BusinessProgram> businessPrograms = new ArrayList<>();
    ArrayList<BusinessProgram> businessProgramsPerPage = new ArrayList<>();
    ArrayList<ProgramType> programTypes = new ArrayList<>();
    ArrayList<EmployerGroup> employerSubGroups = new ArrayList<>();
    BusinessProgram businessProgram;
    ArrayList<EligibleActivity> eligibleActivities = new ArrayList<>();
    ArrayList<Activity> availableActivities = new ArrayList<>();
    ArrayList<LookUpValueCode> participationList = new ArrayList<>();
    ArrayList<LookUpValueCode> activationCodes = new ArrayList<>();
    ArrayList<QualificationCheckmark> qualificationCheckmarks = new ArrayList<>();
    ArrayList<LookUpValueCode> programSpecialReportHandlingCodes = new ArrayList<>();
    String memberId;
    ArrayList<ProgramIncentiveOption> programIncentiveOptions = new ArrayList<>();
    ArrayList<AdditionalInformation> additionalInfos = new ArrayList<>();
    ArrayList<AuthCode> extendedAuthCodes = new ArrayList<>();
    ArrayList<ProgramActivityIncentiveSummary> programActivityIncentivesSummary = new ArrayList<>();
    ArrayList<ProgramCheckmark> programCheckmarks = new ArrayList<>();
    Collection<ParticipationGroup> participationGroups = new ArrayList<>();
    ArrayList<IncentivePackageRuleGroup> incentivePackageRuleGroups = new ArrayList<>();
    Collection<BenefitPackage> benefitPackages = new ArrayList<>();
    ArrayList<ProgramChangeLog> programChangeLogList = new ArrayList<>();
    ArrayList<ProgramPackage> programPackages = new ArrayList<>();
    String whichSaveSelectedSite;
    ArrayList<LookUpValueCode> incentiveOverrideCodeTypes;
    ArrayList<EligibleActivity> eligibleActivitiesRemoved;
    Integer programID;
    ArrayList<IncentiveOption> incentiveOptions;
    ArrayList<IncentiveOption> activeIncentiveOptions;
    ArrayList<LookUpValueCode> incentiveOptionStatuses;
    ArrayList<LookUpValueCode> incentiveFulfillTypes;
    ArrayList<LookUpValueCode> incentiveReportNameTypes;
    ArrayList<LookUpValueCode> incentedStatusCodes;
    ArrayList<LookUpValueCode> incentiveEnrollmentRuleCodes;
    ArrayList<LookUpValueCode> rewardRunFrequencyTypes;
    ArrayList<IncentiveOptionRewardCard> incentiveOptionRewardCardTypes;
    ArrayList<LookUpValueCode> unitCodeTypes;
    ArrayList<LookUpValueCode> deliveryInfoTypes;
    String luvIdSendToMembership;
    String luvIdSendToPremiumBilling;
    String luvIdSendToIntelispend;
    String luvIdSendToCDHP;
    String luvIdContractBased;
    String luvIdMemberBased;
    ArrayList<QualificationCheckmark> availableCheckmarks;
    ArrayList<PersonRelationshipCode> personRelationshipCodes;
    ArrayList<ProgramCheckmark> deletedProgramCheckmarks;
    ArrayList<ProgramIncentiveOption> deletedProgramIncentiveOptions;
    TemplateBizProgram templateBizProgram;
    ArrayList<LookUpValueCode> additionalInfoFixedNames;
    ProgramIncentiveOption programIncentiveOption;
    ArrayList<LookUpValueCode> activityTypeCodes;
    ArrayList<LookUpValueCode> activityIncentiveTypeCodes;
    ArrayList<LookUpValueCode> activityIncentiveStatusCodes;
    ArrayList<BPMCollection> collections;
    ArrayList<ProgramContributionGrid> removedProgramContributionGrids;
    Collection<ContributionGridBenefitContractType> contributionGridBenefitContractTypes;
    HashMap<Integer, Collection<ContributionGridBenefitContractTypeRelationship>> benefitContractTypeRelationshipGridHashMap;
    HashMap<Integer, String> benefitContractTypeHashMap;
    ArrayList<ProgramContributionGrid> programContributionGrids;
    ProgramContributionGrid programContributionGrid;
    ArrayList<LookUpValueCode> benefitContractTypes;
    boolean programContributionGridExists;
    ArrayList<LookUpValueCode> incentivePackageRuleGroupTypes;
    ArrayList<ProgramContributionTier> removedProgramContributionTiers;
    Collection<ContributionTierBenefitContractType> contributionTierBenefitContractTypes;
    HashMap<Integer, Collection<ContributionTierBenefitContractTypeRelationship>> benefitContractTypeRelationshipTierHashMap;
    Collection<ContributionTier> allContributionTiers;
    ArrayList<ProgramContributionTier> programContributionTiers;
    ProgramContributionTier programContributionTier;
    Collection<ContributionTierBenefitContractType> assignedContributionTierBenefitContractTypes;
    boolean programContributionTierExists;
    ArrayList<LookUpValueCode> authCodeTypes;
    private String changeLogText;
    ArrayList<MemberDetail> memberDetails;
    MemberDetail memberDetail;
    MemberDetail previousYearMemberDetail;
    ArrayList<MemberDetail> relatedMemberDetailList;
    ArrayList<LookUpValueCode> activityEventFilteredOutReasons;
    ArrayList<MemberDetail> memberDetailsPerPage;
    Collection<RewardCard> rewardCardTypes;
    ArrayList<LookUpValueCode> rewardCardStatusTypes;
    ArrayList<RewardCardFulfillmentTrackingReportHist> rewardCardFulfillmentTrackingReportHistList;
    RewardCardFulfillmentSearchForm rewardCardFulfillmentSearchForm;
    ArrayList<RewardCardFulfillmentTrackingReportHist> rewardCardFulfillmentTrackingReportHistPerPage;

    ArrayList<PersonContractHist> personContractHistory;
    ArrayList<LookUpValueCode> luvContractHistResultCodes;
    ArrayList<GroupOverride> groupSiteExceptions;
    GroupSiteExceptionSearchForm groupSiteExceptionSearchForm;
    ArrayList<GroupOverride> groupSiteExceptionsPerPage;
    ArrayList<LookUpValueCode> rewardCardFulfillRecycleStatusCodes;
    GroupOverride groupSiteException;
    ArrayList<LookUpValueCode> groupSiteExceptionTypes;
    boolean addGroupSiteException;
    boolean groupSiteDisabled;
    boolean copyGroupSiteException;
    ArrayList<GroupOverride> assignedSitesForGroupSiteException;
    ArrayList<GroupOverride> availableSitesForGroupSiteException;
    ArrayList<LookUpValueCode> recycleStatusCodes;
    RecycleSearchCriteria recycleSearchCriteria;
    ArrayList<CDHPFulfillmentTrackingRecycle> personCDHPFulfillsRecycle;
    ArrayList<CDHPFulfillmentTrackingRecycle> personCDHPFulfillsRecyclePerPage;
    String contractNo;
    String programName;
    Integer recycleStatusId;
    java.sql.Date recycleStatusDate;
    CDHPFulfillmentTrackingRecycle personCDHPFulfillRecycle;
    ArrayList<LookUpValueCode> employerUploadTrackingStatusCodes;
    ArrayList<ControlGroupIOFileDirSetup> controlGroupsIOFileDirSetup;


    ArrayList<RewardCardFee> rewardCardFees;
    ArrayList<RewardEmbossedLine> rewardEmbossedLines;
    ArrayList<RewardCarrierMessage> rewardCarrierMessages;
    ArrayList<RewardTransactionMessage> rewardTransactionMessages;
    ArrayList<RewardCardClientData> rewardCardClientDataList;
    ArrayList<PersonContractRecycle> personContractsRecycle;
    ArrayList<PersonContractRecycle> personContractsRecyclePerPage;
    PersonContractRecycle personContractRecycle;
    ArrayList<GroupActivityProgressTracker> groupActivityProgressTrackers;
    Integer trackingStatusId;
    String batchDate;
    String fileName;
    PersonEmployerActivityUploadSearchForm personEmployerActivityUploadSearchForm;
    ArrayList<GroupActivityProgressTracker> groupActivityProgressTrackersPerPage;
    ArrayList<Activity> activitySponsoredCodes;
    ArrayList<RejectedPerson> personEmployerActivitiesRecycle;
    PersonEmployerActivityRecycleSearchForm personEmployerActivityRecycleSearchForm;
    java.sql.Date activityDate;
    String lastName;
    String firstName;
    ArrayList<RejectedPerson> personEmployerActivitiesRecyclePerPage;
    RejectedPerson personEmployerActivityRecycle;

    EmployerActivityRecycleSearchCriteria employerActivityRecycleSearchCriteria;
    ArrayList<QualificationCheckmark> expiredQualificationCheckmarks;
    QualificationCheckmark qualificationCheckmark;
    ArrayList<LookUpValueCode> qualificationStatusCodes;

    public void reset() {
        if (this.activities != null) {
            this.activities.clear();
        }
        if (expiredActivities != null) {
            expiredActivities.clear();
        }
        if (startDates != null) {
            startDates.clear();
        }
        if (employerGroups != null) {
            employerGroups.clear();
        }
        if (paginationMap != null) {
            paginationMap.clear();
        }
        if (employerGroupsPerPage != null) {
            employerGroupsPerPage.clear();
        }
        if (availableSites != null) {
            availableSites.clear();
        }
        if (reportTypes != null) {
            reportTypes.clear();
        }
        if (productTypes != null) {
            productTypes.clear();
        }
        if (cdhpTableTypes != null) {
            cdhpTableTypes.clear();
        }
        if(cdhpFulfillmentTrackingReportHistList != null) {
            cdhpFulfillmentTrackingReportHistList.clear();
        }
        if (cdhpFulfillmentTrackingReportHistPerPage != null) {
            cdhpFulfillmentTrackingReportHistPerPage.clear();
        }
        if (personActivityContributionPendingList != null) {
            personActivityContributionPendingList.clear();
        }
        if (personActivityContributionPendingPerPage != null) {
            personActivityContributionPendingPerPage.clear();
        }
        if (exemptionTypes != null) {
            exemptionTypes.clear();
        }
        if (exemptionHistoryList != null) {
            exemptionHistoryList.clear();
        }
        if(exemptionHistoryPersPage != null) {
            exemptionHistoryPersPage.clear();
        }
        if (this.pagination != null) {
            pagination.clear();
        }
        if(this.businessPrograms != null) {
            businessPrograms.clear();
        }
        if(this.businessProgramsPerPage != null) {
            businessProgramsPerPage.clear();
        }
        if(this.programTypes != null) {
            programTypes.clear();
        }
        if(this.employerSubGroups != null) {
            employerSubGroups.clear();
        }
        if(this.recycleStatusCodes != null) {
            recycleStatusCodes.clear();
        }
        this.activities = new ArrayList<>();
        this.expiredActivities = new ArrayList<>();
        this.startDates = new ArrayList<>();
        this.groupName = null;
        this.employerGroups = new ArrayList<>();
        this.groupLookupForm = new GroupLookupForm();
        this.paginationMap = new HashMap<>();
        this.employerGroupsPerPage = new ArrayList<>();
        this.availableSites = new ArrayList<>();
        this.reportTypes = new ArrayList<>();
        this.productTypes = new ArrayList<>();
        this.cdhpTableTypes = new ArrayList<>();
        this.cdhpFulfillmentTrackingReportHistList = new ArrayList<>();
        this.cdhpFulfillmentTrackingReportHistPerPage = new ArrayList<>();
        this.personActivityContributionPendingList = new ArrayList<>();
        this.personActivityContributionPendingPerPage = new ArrayList<>();
        this.exemptionTypes = new ArrayList<>();
        this.exemptionHistoryList = new ArrayList<>();
        this.exemptionHistoryPersPage = new ArrayList<>();
        this.pagination = new BPMPagination();
        this.programSearchForm = new ProgramSearchForm();
        this.businessPrograms = new ArrayList<>();
        this.businessProgramsPerPage = new ArrayList<>();
        this.programTypes = new ArrayList<>();
        this.employerSubGroups = new ArrayList<>();
        this.personContractHistory = new ArrayList<>();
        this.luvContractHistResultCodes = null;
        this.recycleStatusCodes = new ArrayList<>();
    }

    public String getDatabaseEnvironment() {
        return databaseEnvironment;
    }
    public void setDatabaseEnvironment(String databaseEnvironment) {
        this.databaseEnvironment = databaseEnvironment;
    }

    public ArrayList<Activity> getActivities() {
        return activities;
    }

    public void setActivities(ArrayList<Activity> activities) {
        this.activities = activities;
    }

    public ArrayList<Activity> getExpiredActivities() {
        return expiredActivities;
    }

    public void setExpiredActivities(ArrayList<Activity> expiredActivities) {
        this.expiredActivities = expiredActivities;
    }

    public ArrayList<String> getStartDates() {
        return startDates;
    }

    public void setStartDates(ArrayList<String> startDates) {
        this.startDates = startDates;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public ArrayList<EmployerGroup> getEmployerGroups() {
        return employerGroups;
    }

    public void setEmployerGroups(ArrayList<EmployerGroup> employerGroups) {
        this.employerGroups = employerGroups;
    }

    public GroupLookupForm getGroupLookupForm() {
        return groupLookupForm;
    }

    public void setGroupLookupForm(GroupLookupForm groupLookupForm) {
        this.groupLookupForm = groupLookupForm;
    }

    public HashMap<String, BPMPagination> getPaginationMap() {
        return paginationMap;
    }

    public void setPaginationMap(HashMap<String, BPMPagination> paginationMap) {
        this.paginationMap = paginationMap;
    }

    public ArrayList<EmployerGroup> getEmployerGroupsPerPage() {
        return employerGroupsPerPage;
    }

    public void setEmployerGroupsPerPage(ArrayList<EmployerGroup> employerGroupsPerPage) {
        this.employerGroupsPerPage = employerGroupsPerPage;
    }

    public ArrayList<EmployerGroup> getAvailableSites() {
        return availableSites;
    }

    public void setAvailableSites(ArrayList<EmployerGroup> availableSites) {
        this.availableSites = availableSites;
    }

    public String getGroupNo() {
        return groupNo;
    }

    public void setGroupNo(String groupNo) {
        this.groupNo = groupNo;
    }

    public ArrayList<LookUpValueCode> getReportTypes() {
        return reportTypes;
    }

    public void setReportTypes(ArrayList<LookUpValueCode> reportTypes) {
        this.reportTypes = reportTypes;
    }

    public ArrayList<LookUpValueCode> getProductTypes() {
        return productTypes;
    }

    public void setProductTypes(ArrayList<LookUpValueCode> productTypes) {
        this.productTypes = productTypes;
    }

    public ArrayList<LookUpValueCode> getCdhpTableTypes() {
        return cdhpTableTypes;
    }

    public void setCdhpTableTypes(ArrayList<LookUpValueCode> cdhpTableTypes) {
        this.cdhpTableTypes = cdhpTableTypes;
    }

    public ArrayList<CDHPFulfillmentTrackingReportHist> getCdhpFulfillmentTrackingReportHistList() {
        return cdhpFulfillmentTrackingReportHistList;
    }

    public void setCdhpFulfillmentTrackingReportHistList(ArrayList<CDHPFulfillmentTrackingReportHist> cdhpFulfillmentTrackingReportHistList) {
        this.cdhpFulfillmentTrackingReportHistList = cdhpFulfillmentTrackingReportHistList;
    }

    public CDHPFulfillmentSearchForm getCdhpFulfillmentSearchForm() {
        return cdhpFulfillmentSearchForm;
    }

    public void setCdhpFulfillmentSearchForm(CDHPFulfillmentSearchForm cdhpFulfillmentSearchForm) {
        this.cdhpFulfillmentSearchForm = cdhpFulfillmentSearchForm;
    }

    public ArrayList<CDHPFulfillmentTrackingReportHist> getCdhpFulfillmentTrackingReportHistPerPage() {
        return cdhpFulfillmentTrackingReportHistPerPage;
    }

    public void setCdhpFulfillmentTrackingReportHistPerPage(ArrayList<CDHPFulfillmentTrackingReportHist> cdhpFulfillmentTrackingReportHistPerPage) {
        this.cdhpFulfillmentTrackingReportHistPerPage = cdhpFulfillmentTrackingReportHistPerPage;
    }

    public ArrayList<PersonActivityContributionPending> getPersonActivityContributionPendingList() {
        return personActivityContributionPendingList;
    }

    public void setPersonActivityContributionPendingList(ArrayList<PersonActivityContributionPending> personActivityContributionPendingList) {
        this.personActivityContributionPendingList = personActivityContributionPendingList;
    }

    public com.healthpartners.app.bpm.form.ActivityIncentiveContributionStatusSearchForm getActivityIncentiveContributionStatusSearchForm() {
        return ActivityIncentiveContributionStatusSearchForm;
    }

    public void setActivityIncentiveContributionStatusSearchForm(com.healthpartners.app.bpm.form.ActivityIncentiveContributionStatusSearchForm activityIncentiveContributionStatusSearchForm) {
        ActivityIncentiveContributionStatusSearchForm = activityIncentiveContributionStatusSearchForm;
    }

    public ArrayList<PersonActivityContributionPending> getPersonActivityContributionPendingPerPage() {
        return personActivityContributionPendingPerPage;
    }

    public void setPersonActivityContributionPendingPerPage(ArrayList<PersonActivityContributionPending> personActivityContributionPendingPerPage) {
        this.personActivityContributionPendingPerPage = personActivityContributionPendingPerPage;
    }

    public ArrayList<LookUpValueCode> getExemptionTypes() {
        return exemptionTypes;
    }

    public void setExemptionTypes(ArrayList<LookUpValueCode> exemptionTypes) {
        this.exemptionTypes = exemptionTypes;
    }

    public ExemptionHistorySearchForm getExemptionHistorySearchForm() {
        return exemptionHistorySearchForm;
    }

    public void setExemptionHistorySearchForm(ExemptionHistorySearchForm exemptionHistorySearchForm) {
        this.exemptionHistorySearchForm = exemptionHistorySearchForm;
    }

    public ArrayList<ExemptionHistory> getExemptionHistoryList() {
        return exemptionHistoryList;
    }

    public void setExemptionHistoryList(ArrayList<ExemptionHistory> exemptionHistoryList) {
        this.exemptionHistoryList = exemptionHistoryList;
    }

    public ArrayList<ExemptionHistory> getExemptionHistoryPersPage() {
        return exemptionHistoryPersPage;
    }

    public void setExemptionHistoryPersPage(ArrayList<ExemptionHistory> exemptionHistoryPersPage) {
        this.exemptionHistoryPersPage = exemptionHistoryPersPage;
    }

    public BPMPagination getPagination() {
        return pagination;
    }

    public void setPagination(BPMPagination pagination) {
        this.pagination = pagination;
    }

    public ProgramSearchForm getProgramSearchForm() {
        return programSearchForm;
    }

    public void setProgramSearchForm(ProgramSearchForm programSearchForm) {
        this.programSearchForm = programSearchForm;
    }

    public ArrayList<BusinessProgram> getBusinessPrograms() {
        return businessPrograms;
    }

    public void setBusinessPrograms(ArrayList<BusinessProgram> businessPrograms) {
        this.businessPrograms = businessPrograms;
    }

    public ArrayList<BusinessProgram> getBusinessProgramsPerPage() {
        return businessProgramsPerPage;
    }

    public void setBusinessProgramsPerPage(ArrayList<BusinessProgram> businessProgramsPerPage) {
        this.businessProgramsPerPage = businessProgramsPerPage;
    }

    public ArrayList<ProgramType> getProgramTypes() {
        return programTypes;
    }

    public void setProgramTypes(ArrayList<ProgramType> programTypes) {
        this.programTypes = programTypes;
    }

    public ArrayList<EmployerGroup> getEmployerSubGroups() {
        return employerSubGroups;
    }

    public void setEmployerSubGroups(ArrayList<EmployerGroup> employerSubGroups) {
        this.employerSubGroups = employerSubGroups;
    }

    public BusinessProgram getBusinessProgram() {
        return businessProgram;
    }

    public void setBusinessProgram(BusinessProgram businessProgram) {
        this.businessProgram = businessProgram;
    }

    public ArrayList<EligibleActivity> getEligibleActivities() {
        return eligibleActivities;
    }

    public void setEligibleActivities(ArrayList<EligibleActivity> eligibleActivities) {
        this.eligibleActivities = eligibleActivities;
    }

    public ArrayList<Activity> getAvailableActivities() {
        return availableActivities;
    }

    public void setAvailableActivities(ArrayList<Activity> availableActivities) {
        this.availableActivities = availableActivities;
    }

    public ArrayList<LookUpValueCode> getParticipationList() {
        return participationList;
    }

    public void setParticipationList(ArrayList<LookUpValueCode> participationList) {
        this.participationList = participationList;
    }

    public ArrayList<LookUpValueCode> getActivationCodes() {
        return activationCodes;
    }

    public void setActivationCodes(ArrayList<LookUpValueCode> activationCodes) {
        this.activationCodes = activationCodes;
    }

    public ArrayList<QualificationCheckmark> getQualificationCheckmarks() {
        return qualificationCheckmarks;
    }

    public void setQualificationCheckmarks(ArrayList<QualificationCheckmark> qualificationCheckmarks) {
        this.qualificationCheckmarks = qualificationCheckmarks;
    }

    public ArrayList<LookUpValueCode> getProgramSpecialReportHandlingCodes() {
        return programSpecialReportHandlingCodes;
    }

    public void setProgramSpecialReportHandlingCodes(ArrayList<LookUpValueCode> programSpecialReportHandlingCodes) {
        this.programSpecialReportHandlingCodes = programSpecialReportHandlingCodes;
    }

    public String getMemberId() {
        return memberId;
    }

    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }

    public ArrayList<ProgramIncentiveOption> getProgramIncentiveOptions() {
        return programIncentiveOptions;
    }

    public void setProgramIncentiveOptions(ArrayList<ProgramIncentiveOption> programIncentiveOptions) {
        this.programIncentiveOptions = programIncentiveOptions;
    }

    public ArrayList<AdditionalInformation> getAdditionalInfos() {
        return additionalInfos;
    }

    public void setAdditionalInfos(ArrayList<AdditionalInformation> additionalInfos) {
        this.additionalInfos = additionalInfos;
    }

    public ArrayList<AuthCode> getExtendedAuthCodes() {
        return extendedAuthCodes;
    }

    public void setExtendedAuthCodes(ArrayList<AuthCode> extendedAuthCodes) {
        this.extendedAuthCodes = extendedAuthCodes;
    }

    public ArrayList<ProgramActivityIncentiveSummary> getProgramActivityIncentivesSummary() {
        return programActivityIncentivesSummary;
    }

    public void setProgramActivityIncentivesSummary(ArrayList<ProgramActivityIncentiveSummary> programActivityIncentivesSummary) {
        this.programActivityIncentivesSummary = programActivityIncentivesSummary;
    }

    public ArrayList<ProgramCheckmark> getProgramCheckmarks() {
        return programCheckmarks;
    }

    public void setProgramCheckmarks(ArrayList<ProgramCheckmark> programCheckmarks) {
        this.programCheckmarks = programCheckmarks;
    }

    public Collection<ParticipationGroup> getParticipationGroups() {
        return participationGroups;
    }

    public void setParticipationGroups(Collection<ParticipationGroup> participationGroups) {
        this.participationGroups = participationGroups;
    }

    public ArrayList<IncentivePackageRuleGroup> getIncentivePackageRuleGroups() {
        return incentivePackageRuleGroups;
    }

    public void setIncentivePackageRuleGroups(ArrayList<IncentivePackageRuleGroup> incentivePackageRuleGroups) {
        this.incentivePackageRuleGroups = incentivePackageRuleGroups;
    }

    public Collection<BenefitPackage> getBenefitPackages() {
        return benefitPackages;
    }

    public void setBenefitPackages(Collection<BenefitPackage> benefitPackages) {
        this.benefitPackages = benefitPackages;
    }

    public ArrayList<ProgramChangeLog> getProgramChangeLogList() {
        return programChangeLogList;
    }

    public void setProgramChangeLogList(ArrayList<ProgramChangeLog> programChangeLogList) {
        this.programChangeLogList = programChangeLogList;
    }

    public ArrayList<ProgramPackage> getProgramPackages() {
        return programPackages;
    }

    public void setProgramPackages(ArrayList<ProgramPackage> programPackages) {
        this.programPackages = programPackages;
    }

    public String getWhichSaveSelectedSite() {
        return whichSaveSelectedSite;
    }

    public void setWhichSaveSelectedSite(String whichSaveSelectedSite) {
        this.whichSaveSelectedSite = whichSaveSelectedSite;
    }

    public ArrayList<LookUpValueCode> getIncentiveOverrideCodeTypes() {
        return incentiveOverrideCodeTypes;
    }

    public void setIncentiveOverrideCodeTypes(ArrayList<LookUpValueCode> incentiveOverrideCodeTypes) {
        this.incentiveOverrideCodeTypes = incentiveOverrideCodeTypes;
    }

    public ArrayList<EligibleActivity> getEligibleActivitiesRemoved() {
        return eligibleActivitiesRemoved;
    }

    public void setEligibleActivitiesRemoved(ArrayList<EligibleActivity> eligibleActivitiesRemoved) {
        this.eligibleActivitiesRemoved = eligibleActivitiesRemoved;
    }

    public Integer getProgramID() {
        return programID;
    }

    public void setProgramID(Integer programID) {
        this.programID = programID;
    }

    public ArrayList<IncentiveOption> getIncentiveOptions() {
        return incentiveOptions;
    }

    public void setIncentiveOptions(ArrayList<IncentiveOption> incentiveOptions) {
        this.incentiveOptions = incentiveOptions;
    }

    public ArrayList<IncentiveOption> getActiveIncentiveOptions() {
        return activeIncentiveOptions;
    }

    public void setActiveIncentiveOptions(ArrayList<IncentiveOption> activeIncentiveOptions) {
        this.activeIncentiveOptions = activeIncentiveOptions;
    }

    public ArrayList<LookUpValueCode> getIncentiveOptionStatuses() {
        return incentiveOptionStatuses;
    }

    public void setIncentiveOptionStatuses(ArrayList<LookUpValueCode> incentiveOptionStatuses) {
        this.incentiveOptionStatuses = incentiveOptionStatuses;
    }

    public ArrayList<LookUpValueCode> getIncentiveFulfillTypes() {
        return incentiveFulfillTypes;
    }

    public void setIncentiveFulfillTypes(ArrayList<LookUpValueCode> incentiveFulfillTypes) {
        this.incentiveFulfillTypes = incentiveFulfillTypes;
    }

    public ArrayList<LookUpValueCode> getIncentiveReportNameTypes() {
        return incentiveReportNameTypes;
    }

    public void setIncentiveReportNameTypes(ArrayList<LookUpValueCode> incentiveReportNameTypes) {
        this.incentiveReportNameTypes = incentiveReportNameTypes;
    }

    public ArrayList<LookUpValueCode> getIncentedStatusCodes() {
        return incentedStatusCodes;
    }

    public void setIncentedStatusCodes(ArrayList<LookUpValueCode> incentedStatusCodes) {
        this.incentedStatusCodes = incentedStatusCodes;
    }

    public ArrayList<LookUpValueCode> getIncentiveEnrollmentRuleCodes() {
        return incentiveEnrollmentRuleCodes;
    }

    public void setIncentiveEnrollmentRuleCodes(ArrayList<LookUpValueCode> incentiveEnrollmentRuleCodes) {
        this.incentiveEnrollmentRuleCodes = incentiveEnrollmentRuleCodes;
    }

    public ArrayList<LookUpValueCode> getRewardRunFrequencyTypes() {
        return rewardRunFrequencyTypes;
    }

    public void setRewardRunFrequencyTypes(ArrayList<LookUpValueCode> rewardRunFrequencyTypes) {
        this.rewardRunFrequencyTypes = rewardRunFrequencyTypes;
    }

    public ArrayList<IncentiveOptionRewardCard> getIncentiveOptionRewardCardTypes() {
        return incentiveOptionRewardCardTypes;
    }

    public void setIncentiveOptionRewardCardTypes(ArrayList<IncentiveOptionRewardCard> incentiveOptionRewardCardTypes) {
        this.incentiveOptionRewardCardTypes = incentiveOptionRewardCardTypes;
    }

    public ArrayList<LookUpValueCode> getUnitCodeTypes() {
        return unitCodeTypes;
    }

    public void setUnitCodeTypes(ArrayList<LookUpValueCode> unitCodeTypes) {
        this.unitCodeTypes = unitCodeTypes;
    }

    public ArrayList<LookUpValueCode> getDeliveryInfoTypes() {
        return deliveryInfoTypes;
    }

    public void setDeliveryInfoTypes(ArrayList<LookUpValueCode> deliveryInfoTypes) {
        this.deliveryInfoTypes = deliveryInfoTypes;
    }

    public String getLuvIdSendToMembership() {
        return luvIdSendToMembership;
    }

    public void setLuvIdSendToMembership(String luvIdSendToMembership) {
        this.luvIdSendToMembership = luvIdSendToMembership;
    }

    public String getLuvIdSendToPremiumBilling() {
        return luvIdSendToPremiumBilling;
    }

    public void setLuvIdSendToPremiumBilling(String luvIdSendToPremiumBilling) {
        this.luvIdSendToPremiumBilling = luvIdSendToPremiumBilling;
    }

    public String getLuvIdSendToIntelispend() {
        return luvIdSendToIntelispend;
    }

    public void setLuvIdSendToIntelispend(String luvIdSendToIntelispend) {
        this.luvIdSendToIntelispend = luvIdSendToIntelispend;
    }

    public String getLuvIdSendToCDHP() {
        return luvIdSendToCDHP;
    }

    public void setLuvIdSendToCDHP(String luvIdSendToCDHP) {
        this.luvIdSendToCDHP = luvIdSendToCDHP;
    }

    public String getLuvIdContractBased() {
        return luvIdContractBased;
    }

    public void setLuvIdContractBased(String luvIdContractBased) {
        this.luvIdContractBased = luvIdContractBased;
    }

    public String getLuvIdMemberBased() {
        return luvIdMemberBased;
    }

    public void setLuvIdMemberBased(String luvIdMemberBased) {
        this.luvIdMemberBased = luvIdMemberBased;
    }

    public ArrayList<QualificationCheckmark> getAvailableCheckmarks() {
        return availableCheckmarks;
    }

    public void setAvailableCheckmarks(ArrayList<QualificationCheckmark> availableCheckmarks) {
        this.availableCheckmarks = availableCheckmarks;
    }

    public ArrayList<PersonRelationshipCode> getPersonRelationshipCodes() {
        return personRelationshipCodes;
    }

    public void setPersonRelationshipCodes(ArrayList<PersonRelationshipCode> personRelationshipCodes) {
        this.personRelationshipCodes = personRelationshipCodes;
    }

    public ArrayList<ProgramCheckmark> getDeletedProgramCheckmarks() {
        if (deletedProgramCheckmarks == null) {
            deletedProgramCheckmarks = new ArrayList<ProgramCheckmark>();
        }
        return deletedProgramCheckmarks;
    }

    public ArrayList<ProgramIncentiveOption> getDeletedProgramIncentiveOptions() {
        if (deletedProgramIncentiveOptions == null) {
            deletedProgramIncentiveOptions = new ArrayList<ProgramIncentiveOption>();
        }
        return deletedProgramIncentiveOptions;
    }

    public TemplateBizProgram getTemplateBizProgram() {
        return templateBizProgram;
    }

    public void setTemplateBizProgram(TemplateBizProgram templateBizProgram) {
        this.templateBizProgram = templateBizProgram;
    }

    public ArrayList<LookUpValueCode> getAdditionalInfoFixedNames() {
        return additionalInfoFixedNames;
    }

    public void setAdditionalInfoFixedNames(ArrayList<LookUpValueCode> additionalInfoFixedNames) {
        this.additionalInfoFixedNames = additionalInfoFixedNames;
    }

    public ProgramIncentiveOption getProgramIncentiveOption() {
        return programIncentiveOption;
    }

    public void setProgramIncentiveOption(ProgramIncentiveOption programIncentiveOption) {
        this.programIncentiveOption = programIncentiveOption;
    }

    public void setDeletedProgramCheckmarks(ArrayList<ProgramCheckmark> deletedProgramCheckmarks) {
        this.deletedProgramCheckmarks = deletedProgramCheckmarks;
    }

    public void setDeletedProgramIncentiveOptions(ArrayList<ProgramIncentiveOption> deletedProgramIncentiveOptions) {
        this.deletedProgramIncentiveOptions = deletedProgramIncentiveOptions;
    }

    public ArrayList<LookUpValueCode> getActivityTypeCodes() {
        return activityTypeCodes;
    }

    public void setActivityTypeCodes(ArrayList<LookUpValueCode> activityTypeCodes) {
        this.activityTypeCodes = activityTypeCodes;
    }

    public ArrayList<LookUpValueCode> getActivityIncentiveTypeCodes() {
        return activityIncentiveTypeCodes;
    }

    public void setActivityIncentiveTypeCodes(ArrayList<LookUpValueCode> activityIncentiveTypeCodes) {
        this.activityIncentiveTypeCodes = activityIncentiveTypeCodes;
    }

    public ArrayList<LookUpValueCode> getActivityIncentiveStatusCodes() {
        return activityIncentiveStatusCodes;
    }

    public void setActivityIncentiveStatusCodes(ArrayList<LookUpValueCode> activityIncentiveStatusCodes) {
        this.activityIncentiveStatusCodes = activityIncentiveStatusCodes;
    }

    public ArrayList<BPMCollection> getCollections() {
        return collections;
    }

    public void setCollections(ArrayList<BPMCollection> collections) {
        this.collections = collections;
    }

    public ArrayList<ProgramContributionGrid> getRemovedProgramContributionGrids() {
        return removedProgramContributionGrids;
    }

    public void setRemovedProgramContributionGrids(ArrayList<ProgramContributionGrid> removedProgramContributionGrids) {
        this.removedProgramContributionGrids = removedProgramContributionGrids;
    }

    public Collection<ContributionGridBenefitContractType> getContributionGridBenefitContractTypes() {
        return contributionGridBenefitContractTypes;
    }

    public void setContributionGridBenefitContractTypes(Collection<ContributionGridBenefitContractType> contributionGridBenefitContractTypes) {
        this.contributionGridBenefitContractTypes = contributionGridBenefitContractTypes;
    }

    public HashMap<Integer, Collection<ContributionGridBenefitContractTypeRelationship>> getBenefitContractTypeRelationshipGridHashMap() {
        return benefitContractTypeRelationshipGridHashMap;
    }

    public void setBenefitContractTypeRelationshipGridHashMap(HashMap<Integer, Collection<ContributionGridBenefitContractTypeRelationship>> benefitContractTypeRelationshipGridHashMap) {
        this.benefitContractTypeRelationshipGridHashMap = benefitContractTypeRelationshipGridHashMap;
    }

    public HashMap<Integer, String> getBenefitContractTypeHashMap() {
        return benefitContractTypeHashMap;
    }

    public void setBenefitContractTypeHashMap(HashMap<Integer, String> benefitContractTypeHashMap) {
        this.benefitContractTypeHashMap = benefitContractTypeHashMap;
    }

    public ArrayList<ProgramContributionGrid> getProgramContributionGrids() {
        return programContributionGrids;
    }

    public void setProgramContributionGrids(ArrayList<ProgramContributionGrid> programContributionGrids) {
        this.programContributionGrids = programContributionGrids;
    }

    public ProgramContributionGrid getProgramContributionGrid() {
        return programContributionGrid;
    }

    public void setProgramContributionGrid(ProgramContributionGrid programContributionGrid) {
        this.programContributionGrid = programContributionGrid;
    }

    public ArrayList<LookUpValueCode> getBenefitContractTypes() {
        return benefitContractTypes;
    }

    public void setBenefitContractTypes(ArrayList<LookUpValueCode> benefitContractTypes) {
        this.benefitContractTypes = benefitContractTypes;
    }

    public boolean isProgramContributionGridExists() {
        return programContributionGridExists;
    }

    public void setProgramContributionGridExists(boolean programContributionGridExists) {
        this.programContributionGridExists = programContributionGridExists;
    }

    public ArrayList<LookUpValueCode> getIncentivePackageRuleGroupTypes() {
        return incentivePackageRuleGroupTypes;
    }

    public void setIncentivePackageRuleGroupTypes(ArrayList<LookUpValueCode> incentivePackageRuleGroupTypes) {
        this.incentivePackageRuleGroupTypes = incentivePackageRuleGroupTypes;
    }

    public ArrayList<ProgramContributionTier> getRemovedProgramContributionTiers() {
        return removedProgramContributionTiers;
    }

    public void setRemovedProgramContributionTiers(ArrayList<ProgramContributionTier> removedProgramContributionTiers) {
        this.removedProgramContributionTiers = removedProgramContributionTiers;
    }

    public Collection<ContributionTierBenefitContractType> getContributionTierBenefitContractTypes() {
        return contributionTierBenefitContractTypes;
    }

    public void setContributionTierBenefitContractTypes(Collection<ContributionTierBenefitContractType> contributionTierBenefitContractTypes) {
        this.contributionTierBenefitContractTypes = contributionTierBenefitContractTypes;
    }

    public HashMap<Integer, Collection<ContributionTierBenefitContractTypeRelationship>> getBenefitContractTypeRelationshipTierHashMap() {
        return benefitContractTypeRelationshipTierHashMap;
    }

    public void setBenefitContractTypeRelationshipTierHashMap(HashMap<Integer, Collection<ContributionTierBenefitContractTypeRelationship>> benefitContractTypeRelationshipTierHashMap) {
        this.benefitContractTypeRelationshipTierHashMap = benefitContractTypeRelationshipTierHashMap;
    }

    public Collection<ContributionTier> getAllContributionTiers() {
        return allContributionTiers;
    }

    public void setAllContributionTiers(Collection<ContributionTier> allContributionTiers) {
        this.allContributionTiers = allContributionTiers;
    }

    public ArrayList<ProgramContributionTier> getProgramContributionTiers() {
        return programContributionTiers;
    }

    public void setProgramContributionTiers(ArrayList<ProgramContributionTier> programContributionTiers) {
        this.programContributionTiers = programContributionTiers;
    }

    public ProgramContributionTier getProgramContributionTier() {
        return programContributionTier;
    }

    public void setProgramContributionTier(ProgramContributionTier programContributionTier) {
        this.programContributionTier = programContributionTier;
    }

    public Collection<ContributionTierBenefitContractType> getAssignedContributionTierBenefitContractTypes() {
        return assignedContributionTierBenefitContractTypes;
    }

    public void setAssignedContributionTierBenefitContractTypes(Collection<ContributionTierBenefitContractType> assignedContributionTierBenefitContractTypes) {
        this.assignedContributionTierBenefitContractTypes = assignedContributionTierBenefitContractTypes;
    }

    public boolean isProgramContributionTierExists() {
        return programContributionTierExists;
    }

    public void setProgramContributionTierExists(boolean programContributionTierExists) {
        this.programContributionTierExists = programContributionTierExists;
    }

    public ArrayList<LookUpValueCode> getAuthCodeTypes() {
        return authCodeTypes;
    }

    public void setAuthCodeTypes(ArrayList<LookUpValueCode> authCodeTypes) {
        this.authCodeTypes = authCodeTypes;
    }

    public String getChangeLogText() {
        return changeLogText;
    }

    public void setChangeLogText(String changeLogText) {
        this.changeLogText = changeLogText;
    }

    public ArrayList<MemberDetail> getMemberDetails() {
        return memberDetails;
    }

    public void setMemberDetails(ArrayList<MemberDetail> memberDetails) {
        this.memberDetails = memberDetails;
    }

    public MemberDetail getMemberDetail() {
        return memberDetail;
    }

    public void setMemberDetail(MemberDetail memberDetail) {
        this.memberDetail = memberDetail;
    }

    public MemberDetail getPreviousYearMemberDetail() {
        return previousYearMemberDetail;
    }

    public void setPreviousYearMemberDetail(MemberDetail previousYearMemberDetail) {
        this.previousYearMemberDetail = previousYearMemberDetail;
    }

    public ArrayList<MemberDetail> getRelatedMemberDetailList() {
        return relatedMemberDetailList;
    }

    public void setRelatedMemberDetailList(ArrayList<MemberDetail> relatedMemberDetailList) {
        this.relatedMemberDetailList = relatedMemberDetailList;
    }

    public ArrayList<LookUpValueCode> getActivityEventFilteredOutReasons() {
        return activityEventFilteredOutReasons;
    }

    public void setActivityEventFilteredOutReasons(ArrayList<LookUpValueCode> activityEventFilteredOutReasons) {
        this.activityEventFilteredOutReasons = activityEventFilteredOutReasons;
    }

    public ArrayList<MemberDetail> getMemberDetailsPerPage() {
        return memberDetailsPerPage;
    }

    public void setMemberDetailsPerPage(ArrayList<MemberDetail> memberDetailsPerPage) {
        this.memberDetailsPerPage = memberDetailsPerPage;
    }

    public Collection<RewardCard> getRewardCardTypes() {
        return rewardCardTypes;
    }

    public void setRewardCardTypes(Collection<RewardCard> rewardCardTypes) {
        this.rewardCardTypes = rewardCardTypes;
    }

    public ArrayList<LookUpValueCode> getRewardCardStatusTypes() {
        return rewardCardStatusTypes;
    }

    public void setRewardCardStatusTypes(ArrayList<LookUpValueCode> rewardCardStatusTypes) {
        this.rewardCardStatusTypes = rewardCardStatusTypes;
    }

    public ArrayList<RewardCardFulfillmentTrackingReportHist> getRewardCardFulfillmentTrackingReportHistList() {
        return rewardCardFulfillmentTrackingReportHistList;
    }

    public void setRewardCardFulfillmentTrackingReportHistList(ArrayList<RewardCardFulfillmentTrackingReportHist> rewardCardFulfillmentTrackingReportHistList) {
        this.rewardCardFulfillmentTrackingReportHistList = rewardCardFulfillmentTrackingReportHistList;
    }

    public RewardCardFulfillmentSearchForm getRewardCardFulfillmentSearchForm() {
        return rewardCardFulfillmentSearchForm;
    }

    public void setRewardCardFulfillmentSearchForm(RewardCardFulfillmentSearchForm rewardCardFulfillmentSearchForm) {
        this.rewardCardFulfillmentSearchForm = rewardCardFulfillmentSearchForm;
    }

    public ArrayList<RewardCardFulfillmentTrackingReportHist> getRewardCardFulfillmentTrackingReportHistPerPage() {
        return rewardCardFulfillmentTrackingReportHistPerPage;
    }

    public void setRewardCardFulfillmentTrackingReportHistPerPage(ArrayList<RewardCardFulfillmentTrackingReportHist> rewardCardFulfillmentTrackingReportHistPerPage) {
        this.rewardCardFulfillmentTrackingReportHistPerPage = rewardCardFulfillmentTrackingReportHistPerPage;
    }


    public ArrayList<GroupOverride> getGroupSiteExceptions() {
        return groupSiteExceptions;
    }

    public void setGroupSiteExceptions(ArrayList<GroupOverride> groupSiteExceptions) {
        this.groupSiteExceptions = groupSiteExceptions;
    }

    public GroupSiteExceptionSearchForm getGroupSiteExceptionSearchForm() {
        return groupSiteExceptionSearchForm;
    }

    public void setGroupSiteExceptionSearchForm(GroupSiteExceptionSearchForm groupSiteExceptionSearchForm) {
        this.groupSiteExceptionSearchForm = groupSiteExceptionSearchForm;
    }

    public ArrayList<GroupOverride> getGroupSiteExceptionsPerPage() {
        return groupSiteExceptionsPerPage;
    }

    public void setGroupSiteExceptionsPerPage(ArrayList<GroupOverride> groupSiteExceptionsPerPage) {
        this.groupSiteExceptionsPerPage = groupSiteExceptionsPerPage;
    }

    public ArrayList<LookUpValueCode> getRewardCardFulfillRecycleStatusCodes() {
        return rewardCardFulfillRecycleStatusCodes;
    }

    public void setRewardCardFulfillRecycleStatusCodes(ArrayList<LookUpValueCode> rewardCardFulfillRecycleStatusCodes) {
        this.rewardCardFulfillRecycleStatusCodes = rewardCardFulfillRecycleStatusCodes;
    }

    public GroupOverride getGroupSiteException() {
        return groupSiteException;
    }

    public void setGroupSiteException(GroupOverride groupSiteException) {
        this.groupSiteException = groupSiteException;
    }

    public ArrayList<LookUpValueCode> getGroupSiteExceptionTypes() {
        return groupSiteExceptionTypes;
    }

    public void setGroupSiteExceptionTypes(ArrayList<LookUpValueCode> groupSiteExceptionTypes) {
        this.groupSiteExceptionTypes = groupSiteExceptionTypes;
    }

    public boolean isAddGroupSiteException() {
        return addGroupSiteException;
    }

    public void setAddGroupSiteException(boolean addGroupSiteException) {
        this.addGroupSiteException = addGroupSiteException;
    }


    public boolean isGroupSiteDisabled() {
        return groupSiteDisabled;
    }

    public void setGroupSiteDisabled(boolean groupSiteDisabled) {
        this.groupSiteDisabled = groupSiteDisabled;
    }

    public boolean isCopyGroupSiteException() {
        return copyGroupSiteException;
    }

    public void setCopyGroupSiteException(boolean copyGroupSiteException) {
        this.copyGroupSiteException = copyGroupSiteException;
    }

    public ArrayList<GroupOverride> getAssignedSitesForGroupSiteException() {
        return assignedSitesForGroupSiteException;
    }

    public void setAssignedSitesForGroupSiteException(ArrayList<GroupOverride> assignedSitesForGroupSiteException) {
        this.assignedSitesForGroupSiteException = assignedSitesForGroupSiteException;
    }

    public ArrayList<GroupOverride> getAvailableSitesForGroupSiteException() {
        return availableSitesForGroupSiteException;
    }

    public void setAvailableSitesForGroupSiteException(ArrayList<GroupOverride> availableSitesForGroupSiteException) {
        this.availableSitesForGroupSiteException = availableSitesForGroupSiteException;
    }

    public ArrayList<LookUpValueCode> getRecycleStatusCodes() {
        return recycleStatusCodes;
    }

    public void setRecycleStatusCodes(ArrayList<LookUpValueCode> recycleStatusCodes) {
        this.recycleStatusCodes = recycleStatusCodes;
    }

    public RecycleSearchCriteria getRecycleSearchCriteria() {
        return recycleSearchCriteria;
    }

    public void setRecycleSearchCriteria(RecycleSearchCriteria recycleSearchCriteria) {
        this.recycleSearchCriteria = recycleSearchCriteria;
    }

    public ArrayList<CDHPFulfillmentTrackingRecycle> getPersonCDHPFulfillsRecycle() {
        return personCDHPFulfillsRecycle;
    }

    public void setPersonCDHPFulfillsRecycle(ArrayList<CDHPFulfillmentTrackingRecycle> personCDHPFulfillsRecycle) {
        this.personCDHPFulfillsRecycle = personCDHPFulfillsRecycle;
    }

    public ArrayList<CDHPFulfillmentTrackingRecycle> getPersonCDHPFulfillsRecyclePerPage() {
        return personCDHPFulfillsRecyclePerPage;
    }

    public void setPersonCDHPFulfillsRecyclePerPage(ArrayList<CDHPFulfillmentTrackingRecycle> personCDHPFulfillsRecyclePerPage) {
        this.personCDHPFulfillsRecyclePerPage = personCDHPFulfillsRecyclePerPage;
    }

    public String getContractNo() {
        return contractNo;
    }

    public void setContractNo(String contractNo) {
        this.contractNo = contractNo;
    }

    public String getProgramName() {
        return programName;
    }

    public void setProgramName(String programName) {
        this.programName = programName;
    }

    public Integer getRecycleStatusId() {
        return recycleStatusId;
    }

    public void setRecycleStatusId(Integer recycleStatusId) {
        this.recycleStatusId = recycleStatusId;
    }

    public Date getRecycleStatusDate() {
        return recycleStatusDate;
    }

    public void setRecycleStatusDate(Date recycleStatusDate) {
        this.recycleStatusDate = recycleStatusDate;
    }

    public CDHPFulfillmentTrackingRecycle getPersonCDHPFulfillRecycle() {
        return personCDHPFulfillRecycle;
    }

    public void setPersonCDHPFulfillRecycle(CDHPFulfillmentTrackingRecycle personCDHPFulfillRecycle) {
        this.personCDHPFulfillRecycle = personCDHPFulfillRecycle;
    }

    public ArrayList<PersonContractHist> getPersonContractHistory() {
        return personContractHistory;
    }

    public void setPersonContractHistory(ArrayList<PersonContractHist> personContractHistory) {
        this.personContractHistory = personContractHistory;
    }

    public ArrayList<LookUpValueCode> getLuvContractHistResultCodes() {
        return luvContractHistResultCodes;
    }

    public void setLuvContractHistResultCodes(ArrayList<LookUpValueCode> luvContractHistResultCodes) {
        this.luvContractHistResultCodes = luvContractHistResultCodes;
    }

    public ArrayList<RewardCardFee> getRewardCardFees() {
        return rewardCardFees;
    }

    public void setRewardCardFees(ArrayList<RewardCardFee> rewardCardFees) {
        this.rewardCardFees = rewardCardFees;
    }

    public ArrayList<RewardEmbossedLine> getRewardEmbossedLines() {
        return rewardEmbossedLines;
    }

    public void setRewardEmbossedLines(ArrayList<RewardEmbossedLine> rewardEmbossedLines) {
        this.rewardEmbossedLines = rewardEmbossedLines;
    }

    public ArrayList<RewardCarrierMessage> getRewardCarrierMessages() {
        return rewardCarrierMessages;
    }

    public void setRewardCarrierMessages(ArrayList<RewardCarrierMessage> rewardCarrierMessages) {
        this.rewardCarrierMessages = rewardCarrierMessages;
    }

    public ArrayList<RewardTransactionMessage> getRewardTransactionMessages() {
        return rewardTransactionMessages;
    }

    public void setRewardTransactionMessages(ArrayList<RewardTransactionMessage> rewardTransactionMessages) {
        this.rewardTransactionMessages = rewardTransactionMessages;
    }

    public ArrayList<RewardCardClientData> getRewardCardClientDataList() {
        return rewardCardClientDataList;
    }

    public void setRewardCardClientDataList(ArrayList<RewardCardClientData> rewardCardClientDataList) {
        this.rewardCardClientDataList = rewardCardClientDataList;
    }

    public ArrayList<PersonContractRecycle> getPersonContractsRecycle() {
        return personContractsRecycle;
    }

    public void setPersonContractsRecycle(ArrayList<PersonContractRecycle> personContractsRecycle) {
        this.personContractsRecycle = personContractsRecycle;
    }

    public ArrayList<PersonContractRecycle> getPersonContractsRecyclePerPage() {
        return personContractsRecyclePerPage;
    }

    public void setPersonContractsRecyclePerPage(ArrayList<PersonContractRecycle> personContractsRecyclePerPage) {
        this.personContractsRecyclePerPage = personContractsRecyclePerPage;
    }

    public PersonContractRecycle getPersonContractRecycle() {
        return personContractRecycle;
    }

    public void setPersonContractRecycle(PersonContractRecycle personContractRecycle) {
        this.personContractRecycle = personContractRecycle;
    }

    public ArrayList<GroupActivityProgressTracker> getGroupActivityProgressTrackers() {
        return groupActivityProgressTrackers;
    }

    public void setGroupActivityProgressTrackers(ArrayList<GroupActivityProgressTracker> groupActivityProgressTrackers) {
        this.groupActivityProgressTrackers = groupActivityProgressTrackers;
    }

    public ArrayList<LookUpValueCode> getEmployerUploadTrackingStatusCodes() {
        return employerUploadTrackingStatusCodes;
    }

    public void setEmployerUploadTrackingStatusCodes(ArrayList<LookUpValueCode> employerUploadTrackingStatusCodes) {
        this.employerUploadTrackingStatusCodes = employerUploadTrackingStatusCodes;
    }

    public ArrayList<ControlGroupIOFileDirSetup> getControlGroupsIOFileDirSetup() {
        return controlGroupsIOFileDirSetup;
    }

    public void setControlGroupsIOFileDirSetup(ArrayList<ControlGroupIOFileDirSetup> controlGroupsIOFileDirSetup) {
        this.controlGroupsIOFileDirSetup = controlGroupsIOFileDirSetup;
    }

    public Integer getTrackingStatusId() {
        return trackingStatusId;
    }

    public void setTrackingStatusId(Integer trackingStatusId) {
        this.trackingStatusId = trackingStatusId;
    }

    public String getBatchDate() {
        return batchDate;
    }

    public void setBatchDate(String batchDate) {
        this.batchDate = batchDate;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public PersonEmployerActivityUploadSearchForm getPersonEmployerActivityUploadSearchForm() {
        return personEmployerActivityUploadSearchForm;
    }

    public void setPersonEmployerActivityUploadSearchForm(PersonEmployerActivityUploadSearchForm personEmployerActivityUploadSearchForm) {
        this.personEmployerActivityUploadSearchForm = personEmployerActivityUploadSearchForm;
    }

    public ArrayList<GroupActivityProgressTracker> getGroupActivityProgressTrackersPerPage() {
        return groupActivityProgressTrackersPerPage;
    }

    public void setGroupActivityProgressTrackersPerPage(ArrayList<GroupActivityProgressTracker> groupActivityProgressTrackersPerPage) {
        this.groupActivityProgressTrackersPerPage = groupActivityProgressTrackersPerPage;
    }

    public ArrayList<Activity> getActivitySponsoredCodes() {
        return activitySponsoredCodes;
    }

    public void setActivitySponsoredCodes(ArrayList<Activity> activitySponsoredCodes) {
        this.activitySponsoredCodes = activitySponsoredCodes;
    }

    public ArrayList<RejectedPerson> getPersonEmployerActivitiesRecycle() {
        return personEmployerActivitiesRecycle;
    }

    public void setPersonEmployerActivitiesRecycle(ArrayList<RejectedPerson> personEmployerActivitiesRecycle) {
        this.personEmployerActivitiesRecycle = personEmployerActivitiesRecycle;
    }

    public PersonEmployerActivityRecycleSearchForm getPersonEmployerActivityRecycleSearchForm() {
        return personEmployerActivityRecycleSearchForm;
    }

    public void setPersonEmployerActivityRecycleSearchForm(PersonEmployerActivityRecycleSearchForm personEmployerActivityRecycleSearchForm) {
        this.personEmployerActivityRecycleSearchForm = personEmployerActivityRecycleSearchForm;
    }

    public Date getActivityDate() {
        return activityDate;
    }

    public void setActivityDate(Date activityDate) {
        this.activityDate = activityDate;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getFirstName() {
        return firstName;
    }
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public ArrayList<RejectedPerson> getPersonEmployerActivitiesRecyclePerPage() {
        return personEmployerActivitiesRecyclePerPage;
    }

    public void setPersonEmployerActivitiesRecyclePerPage(ArrayList<RejectedPerson> personEmployerActivitiesRecyclePerPage) {
        this.personEmployerActivitiesRecyclePerPage = personEmployerActivitiesRecyclePerPage;
    }

    public RejectedPerson getPersonEmployerActivityRecycle() {
        return personEmployerActivityRecycle;
    }

    public void setPersonEmployerActivityRecycle(RejectedPerson personEmployerActivityRecycle) {
        this.personEmployerActivityRecycle = personEmployerActivityRecycle;
    }

    public EmployerActivityRecycleSearchCriteria getEmployerActivityRecycleSearchCriteria() {
        return employerActivityRecycleSearchCriteria;
    }

    public void setEmployerActivityRecycleSearchCriteria(EmployerActivityRecycleSearchCriteria employerActivityRecycleSearchCriteria) {
        this.employerActivityRecycleSearchCriteria = employerActivityRecycleSearchCriteria;
    }

    public ArrayList<QualificationCheckmark> getExpiredQualificationCheckmarks() {
        return expiredQualificationCheckmarks;
    }

    public void setExpiredQualificationCheckmarks(ArrayList<QualificationCheckmark> expiredQualificationCheckmarks) {
        this.expiredQualificationCheckmarks = expiredQualificationCheckmarks;
    }

    public QualificationCheckmark getQualificationCheckmark() {
        return qualificationCheckmark;
    }

    public void setQualificationCheckmark(QualificationCheckmark qualificationCheckmark) {
        this.qualificationCheckmark = qualificationCheckmark;
    }

    public ArrayList<LookUpValueCode> getQualificationStatusCodes() {
        return qualificationStatusCodes;
    }

    public void setQualificationStatusCodes(ArrayList<LookUpValueCode> qualificationStatusCodes) {
        this.qualificationStatusCodes = qualificationStatusCodes;
    }
}