package com.healthpartners.app.bpm.pageable;

import com.healthpartners.app.bpm.dto.GroupActivityProgressTracker;

import java.util.ArrayList;
import java.util.Iterator;

/**
 * The pageable class serves as a wrapper for the array list of objects, and
 * operations that are performed on those objects. For ex. adding a row number
 * for display.
 * The BPMPagination then has a pointer to an instance of this class.
 *
 * @author tjquist
 */
public class PageableGroupActivityProgressTracker implements BPMPageable {
    ArrayList<GroupActivityProgressTracker> groupActivityProgressTrackers;

    public PageableGroupActivityProgressTracker() {
        super();
    }

    public PageableGroupActivityProgressTracker(ArrayList<GroupActivityProgressTracker> pGroupActivityProgressTrackers) {
        groupActivityProgressTrackers = pGroupActivityProgressTrackers;
    }

    public ArrayList<GroupActivityProgressTracker> getGroupActivityProgressTrackers() {
        return groupActivityProgressTrackers;
    }

    public void setGroupActivityProgressTrackers(ArrayList<GroupActivityProgressTracker> pGroupActivityProgressTrackers) {
        this.groupActivityProgressTrackers = pGroupActivityProgressTrackers;
    }

    public void addRowNumber() {
        int startRowNumber = 1;
        Iterator<GroupActivityProgressTracker> iter = (Iterator<GroupActivityProgressTracker>) groupActivityProgressTrackers.iterator();
        while (iter.hasNext()) {
            GroupActivityProgressTracker groupActivityProgressTracker = (GroupActivityProgressTracker) iter.next();
            groupActivityProgressTracker.setRowNumber(startRowNumber);
            startRowNumber++;
        }
    }

}
