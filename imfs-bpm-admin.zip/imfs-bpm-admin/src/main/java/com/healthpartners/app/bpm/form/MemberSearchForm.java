package com.healthpartners.app.bpm.form;

/**
 * @author mxthoutam
 */
public class MemberSearchForm extends BaseForm {

    static final long serialVersionUID = 0L;

    private String operationType;

    private String contractNo;
    private String memberID;

    private String qualificationStartDate;

    private String personID;

    private String searchedMemberID;

    private String lastName;
    private String firstName;
    private String dateOfBirth;

    public MemberSearchForm() {
        super();
    }


    public String getMemberID() {
        if (memberID != null) {
            return memberID.trim();
        }
        return memberID;
    }

    public void setMemberID(String memberID) {
        this.memberID = memberID;
    }

    public String getOperationType() {
        return operationType;
    }

    public void setOperationType(String operationType) {
        this.operationType = operationType;
    }

    public String getQualificationStartDate() {
        return qualificationStartDate;
    }

    public void setQualificationStartDate(String qualificationStartDate) {
        this.qualificationStartDate = qualificationStartDate;
    }

    public String getPersonID() {
        return personID;
    }

    public void setPersonID(String personID) {
        this.personID = personID;
    }

    public String getSearchedMemberID() {
        return searchedMemberID;
    }

    public void setSearchedMemberID(String searchedMemberID) {
        this.searchedMemberID = searchedMemberID;
    }

    public final String getDateOfBirth() {
        return dateOfBirth;
    }

    public final void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public final String getFirstName() {
        return firstName;
    }

    public final void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public final String getLastName() {
        return lastName;
    }

    public final void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getContractNo() {
        if (contractNo != null) {
            return contractNo.trim();
        }
        return contractNo;
    }

    public void setContractNo(String contractNo) {
        this.contractNo = contractNo;
    }


}
