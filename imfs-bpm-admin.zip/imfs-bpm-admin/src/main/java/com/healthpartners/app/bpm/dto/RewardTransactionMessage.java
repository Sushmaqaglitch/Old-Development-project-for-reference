package com.healthpartners.app.bpm.dto;


public class RewardTransactionMessage
{	
	
	private Integer rewardTransactionMessageID;
	private String rewardTransactionMessageName;
	private String rewardTransactionMessageDescription;
	private java.sql.Date effectiveDate;
	private java.sql.Date endDate;
	
	private String used;
	
	public Integer getRewardTransactionMessageID() {
		return rewardTransactionMessageID;
	}
	public void setRewardTransactionMessageID(Integer rewardTransactionMessageID) {
		this.rewardTransactionMessageID = rewardTransactionMessageID;
	}
	public String getRewardTransactionMessageName() {
		return rewardTransactionMessageName;
	}
	public void setRewardTransactionMessageName(String rewardTransactionMessageName) {
		this.rewardTransactionMessageName = rewardTransactionMessageName;
	}
	public String getRewardTransactionMessageDescription() {
		return rewardTransactionMessageDescription;
	}
	public void setRewardTransactionMessageDescription(
			String rewardTransactionMessageDescription) {
		this.rewardTransactionMessageDescription = rewardTransactionMessageDescription;
	}
	public java.sql.Date getEffectiveDate() {
		return effectiveDate;
	}
	public void setEffectiveDate(java.sql.Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}
	public java.sql.Date getEndDate() {
		return endDate;
	}
	public void setEndDate(java.sql.Date endDate) {
		this.endDate = endDate;
	}
	public final String getUsed() {
		return used;
	}
	public final void setUsed(String used) {
		this.used = used;
	}
	
	
	
}
