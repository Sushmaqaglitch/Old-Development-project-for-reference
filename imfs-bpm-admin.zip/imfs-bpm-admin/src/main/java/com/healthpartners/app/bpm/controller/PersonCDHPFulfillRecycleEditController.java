package com.healthpartners.app.bpm.controller;

import com.healthpartners.app.bpm.common.BPMAdminConstants;
import com.healthpartners.app.bpm.common.BPMAdminUtils;
import com.healthpartners.app.bpm.common.BPMPagination;
import com.healthpartners.app.bpm.dto.CDHPFulfillmentTrackingRecycle;
import com.healthpartners.app.bpm.dto.LookUpValueCode;
import com.healthpartners.app.bpm.dto.MemberDetail;
import com.healthpartners.app.bpm.dto.RecycleSearchCriteria;
import com.healthpartners.app.bpm.exception.BPMException;
import com.healthpartners.app.bpm.form.PersonCDHPFulfillRecycleSearchForm;
import com.healthpartners.app.bpm.form.SavePersonCDHPFulfillRecycleForm;
import com.healthpartners.app.bpm.iface.MemberService;
import com.healthpartners.app.bpm.pageable.PageablePersonCDHPFulfillRecycle;
import com.healthpartners.app.bpm.session.UserSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.ArrayList;
import java.util.Iterator;

@Controller
public class PersonCDHPFulfillRecycleEditController extends BaseController implements Validator {

    private final MemberService memberService;


    public PersonCDHPFulfillRecycleEditController(MemberService memberService) {
        this.memberService = memberService;
    }

    @GetMapping("/editPersonCDHPFulfillRecycle")
    public String load(@RequestParam(name = "recycleId") String recycleId, @RequestParam(name = "memberId") String memberId, ModelMap modelMap) throws BPMException {
        try {
            populateFormForEdit(modelMap, recycleId, memberId);
        } catch (Exception e) {
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
            modelMap.put("errorMsg", getStackTrace(e));
        }

        return "editPersonCDHPFulfillRecycle";
    }

    @PostMapping("/savePersonCDHPFulfillRecycle")
    public String submitSave(@ModelAttribute("savePersonCDHPFulfillRecycleForm") SavePersonCDHPFulfillRecycleForm form, ModelMap modelMap, BindingResult result, RedirectAttributes ra) throws Exception {
        try {
            validate(form, result);
            boolean isInvalid = isInvalidRecycleRelease(modelMap, form);
            if (result.hasErrors() || isInvalid) {
                modelMap.put("memberDetail", getUserSession().getMemberDetail());
                modelMap.put("relatedMemberDetailList", getUserSession().getRelatedMemberDetailList());
                modelMap.put("personCDHPFulfillRecycle", getUserSession().getPersonCDHPFulfillRecycle());
                modelMap.put("recycleStatusCodes", getUserSession().getRecycleStatusCodes());
            }

            save(form, modelMap);
            return redirectBackToSearch(ra);

        } catch (Exception e) {
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
            // Add error stack trace on the request, to be hidden in html.
            modelMap.put("errorMsg", getStackTrace(e));
        }

        return "editPersonCDHPFulfillRecycle";
    }

    @PostMapping(value = "/savePersonCDHPFulfillRecycle", params = "back")
    public String submitBack(@ModelAttribute("savePersonCDHPFulfillRecycleForm") SavePersonCDHPFulfillRecycleForm form, RedirectAttributes ra) {
        return redirectBackToSearch(ra);
    }

    private String redirectBackToSearch(RedirectAttributes ra) {
        PersonCDHPFulfillRecycleSearchForm personCDHPFulfillRecycleSearchForm = new PersonCDHPFulfillRecycleSearchForm();
        ra.addFlashAttribute("personCDHPFulfillRecycleSearchForm", personCDHPFulfillRecycleSearchForm);
        return "redirect:personCDHPFulfillRecycleSearch";
    }

    private void populateFormForEdit(ModelMap modelMap, String recycleId, String memberId) throws BPMException {
        SavePersonCDHPFulfillRecycleForm form = new SavePersonCDHPFulfillRecycleForm();
        modelMap.put("savePersonCDHPFulfillRecycleForm", form);

        CDHPFulfillmentTrackingRecycle personCDHPFulfillRecycle = memberService.getPersonCDHPFulfillRecycle(Integer.valueOf(recycleId));

        MemberDetail memberDetail = memberService.getMemberDetail(memberId, personCDHPFulfillRecycle.getProgramId());

        ArrayList<MemberDetail> lRelatedMemberDetailList = (ArrayList<MemberDetail>) memberService.getRelatedMemberDetail(memberId);
        if (memberDetail == null) {
            createNoResultsFoundMessageOnModel(modelMap);
        }

        ArrayList<LookUpValueCode> lLuvRecycleStatusCodes = getUserSession().getRecycleStatusCodes();

        //Lookup recycle status id description.
        Iterator<LookUpValueCode> iter = lLuvRecycleStatusCodes.iterator();
        while (iter.hasNext()) {
            LookUpValueCode lookupValueCode = iter.next();
            if (lookupValueCode.getLuvId().equals(personCDHPFulfillRecycle.getRecycleStatusId())) {
                personCDHPFulfillRecycle.setRecycleStatusId(lookupValueCode.getLuvId());
                personCDHPFulfillRecycle.setRecycleStatus(lookupValueCode.getLuvVal());
            }
        }

        getUserSession().setMemberDetail(memberDetail);
        getUserSession().setRelatedMemberDetailList(lRelatedMemberDetailList);
        getUserSession().setPersonCDHPFulfillRecycle(personCDHPFulfillRecycle);

        modelMap.put("memberDetail", memberDetail);
        modelMap.put("relatedMemberDetailList", lRelatedMemberDetailList);
        modelMap.put("personCDHPFulfillRecycle", personCDHPFulfillRecycle);
        modelMap.put("recycleStatusCodes", lLuvRecycleStatusCodes);

        form.setReason(personCDHPFulfillRecycle.getReasonDesc());
    }

    private void save(SavePersonCDHPFulfillRecycleForm lSavePersonCDHPFulfillRecycleForm, ModelMap modelMap) throws BPMException {
        String lUserID = getUserSessionSupport().getAuthenticatedUsername();
        CDHPFulfillmentTrackingRecycle lPersonCDHPFulfillRecycle = getUserSession().getPersonCDHPFulfillRecycle();

        if (lPersonCDHPFulfillRecycle.getRecycleStatusId() != null) {
            lSavePersonCDHPFulfillRecycleForm.setRecycleStatusIdCurrent(String.valueOf(lPersonCDHPFulfillRecycle.getRecycleStatusId()));
        }

        ArrayList<LookUpValueCode> lLuvRecycleStatusCodes = getUserSession().getRecycleStatusCodes();
        lSavePersonCDHPFulfillRecycleForm.setRecycleStatusCodes(lLuvRecycleStatusCodes);

        lPersonCDHPFulfillRecycle.setCdhpRecycleId(Integer.valueOf(lSavePersonCDHPFulfillRecycleForm.getRecycleId()));
        lPersonCDHPFulfillRecycle.setApproverUserId(lUserID);
        lPersonCDHPFulfillRecycle.setApproverUserId(lSavePersonCDHPFulfillRecycleForm.getApprover());
        lPersonCDHPFulfillRecycle.setReasonDesc(lSavePersonCDHPFulfillRecycleForm.getReason());

        if (lSavePersonCDHPFulfillRecycleForm.getRecycleStatusId().length() > 0) {
            lPersonCDHPFulfillRecycle.setRecycleStatusId(Integer.valueOf(lSavePersonCDHPFulfillRecycleForm.getRecycleStatusId()));
        }

        logger.debug("updatePersonCDHPFulfillRecycle ");
        logger.debug("CdhpRecycleId " + lPersonCDHPFulfillRecycle.getCdhpRecycleId());
        logger.debug("Activity ID " + lPersonCDHPFulfillRecycle.getActivityId());

        memberService.updatePersonCDHPFulfillRecycle(lPersonCDHPFulfillRecycle);

        //update member activity incentive modify date with system date so incentive is re-evaluated.
        memberService.updateMemberProgramActivityIncentiveModifyDate(lPersonCDHPFulfillRecycle.getPersonDemographicsID(), lPersonCDHPFulfillRecycle.getProgramId(), lPersonCDHPFulfillRecycle.getActivityId(), lPersonCDHPFulfillRecycle.getModifyUser());

        CDHPFulfillmentTrackingRecycle personCDHPFulfillRecycle = memberService.getPersonCDHPFulfillRecycle(Integer.valueOf(lSavePersonCDHPFulfillRecycleForm.getRecycleId()));
        modelMap.put("personCDHPFulfillRecycle", personCDHPFulfillRecycle);

        getUserSession().setRecycleStatusCodes(lLuvRecycleStatusCodes);

        // After having saved the changes, retrieve a fresh list of recycles using the same criteria that
        // were used before. This way the records that were changed will not re-appear on the screen.
        RecycleSearchCriteria lRecycleSearchCriteria = getUserSession().getRecycleSearchCriteria();
        String lRecycleStatusDateString = lRecycleSearchCriteria.getRecycleStatusDateString();
        java.sql.Date lRecycleDate = null;
        Integer lRecycleStatusIdInt = 0;
        if (lRecycleSearchCriteria.getRecycleStatusID() != null && BPMAdminUtils.isValueInteger(lRecycleSearchCriteria.getRecycleStatusID())) {
            lRecycleStatusIdInt = Integer.valueOf(lRecycleSearchCriteria.getRecycleStatusID());
        }

        if (lRecycleStatusDateString != null && lRecycleStatusDateString.length() > 0) {
            lRecycleDate = BPMAdminUtils.convertStringToSqlDate(lRecycleStatusDateString, BPMAdminConstants.HP_BPM_ADMIN_UI_COMMON_DATE_FORMAT);
        }
        ArrayList<CDHPFulfillmentTrackingRecycle> lPersonCDHPFulfillsRecycle =
                (ArrayList<CDHPFulfillmentTrackingRecycle>) memberService.getPersonCDHPFulfillsRecycle(lRecycleSearchCriteria.getMemberID()
                        , lRecycleSearchCriteria.getGroupNo()
                        , lRecycleSearchCriteria.getContractNo()
                        , lRecycleDate
                        , lRecycleStatusIdInt
                        , lRecycleSearchCriteria.getProgramName());

        getUserSession().setPersonCDHPFulfillsRecycle(lPersonCDHPFulfillsRecycle);
        boolean newDTOList = true;
        // Set actionType to empty string to start pagination from the beginning.
        String actionType = "";
        setPersonCDHPFulfillRecyclePagination(modelMap, getUserSession(), actionType, newDTOList);

        ArrayList<CDHPFulfillmentTrackingRecycle> personCDHPFulfillsRecyclePerPage = getUserSession().getPersonCDHPFulfillsRecyclePerPage();
        ArrayList<CDHPFulfillmentTrackingRecycle> personCDHPFulfillsRecycle = getUserSession().getPersonCDHPFulfillsRecycle();

        modelMap.put("recycleStatusCodes", lLuvRecycleStatusCodes);
        modelMap.put("personCDHPFulfillsRecycle", personCDHPFulfillsRecycle);

        setAttributesForPaginationOnModel(modelMap, personCDHPFulfillsRecycle.size(), getUserSession().getPagination());
    }

    private void setPersonCDHPFulfillRecyclePagination(ModelMap modelMap, UserSession sessionBean, String actionType, boolean newDTOList) {
        ArrayList<CDHPFulfillmentTrackingRecycle> lPersonCDHPFulfillsRecycleList = sessionBean.getPersonCDHPFulfillsRecycle();

        /**
         * Create a Pageable wrapper for the array list.
         * Create a Pagination object and point it to the wrapper.
         */
        BPMPagination pagination = sessionBean.getPaginationMap().get(PERSON_CDHP_FULFILL_RECYCLE_LIST);
        PageablePersonCDHPFulfillRecycle lPPR = null;
        if (pagination == null || newDTOList) {
            lPPR = new PageablePersonCDHPFulfillRecycle(lPersonCDHPFulfillsRecycleList);
            lPPR.addRowNumber();
            pagination = new BPMPagination(lPPR, new ArrayList<Object>(lPersonCDHPFulfillsRecycleList));
            sessionBean.getPaginationMap().put(PERSON_CDHP_FULFILL_RECYCLE_LIST, pagination);
        }

        ArrayList<CDHPFulfillmentTrackingRecycle> lPersonCDHPFulfillsRecyclePerPage =
                (ArrayList<CDHPFulfillmentTrackingRecycle>) determineNextOrBackAction(actionType, pagination);
        setAttributesForPaginationOnModel(modelMap, lPersonCDHPFulfillsRecycleList.size(), pagination);
        sessionBean.setPagination(pagination);

        modelMap.put("personCDHPFulfillsRecycle", lPersonCDHPFulfillsRecyclePerPage);
        sessionBean.setPersonCDHPFulfillsRecyclePerPage(lPersonCDHPFulfillsRecyclePerPage);
    }

    @Override
    public boolean supports(Class<?> clazz) {
        return SavePersonCDHPFulfillRecycleForm.class.isAssignableFrom(clazz);
    }

    @Override
    public void validate(Object target, Errors errors) {
        SavePersonCDHPFulfillRecycleForm form = (SavePersonCDHPFulfillRecycleForm) target;

        getValidationSupport().validateRequiredFieldIsNotEmpty("reason", form.getReason(), errors, new Object[]{"Reason"});
        getValidationSupport().validateRequiredFieldIsNotEmpty("approver", form.getApprover(), errors, new Object[]{"Approver"});

        if (form.getRecycleStatusId() == null || form.getRecycleStatusId().isEmpty() || form.getRecycleStatusId().length() == 0) {
            form.setRecycleStatusId(form.getRecycleStatusIdCurrent());
        }
        getValidationSupport().validateRequiredFieldIsNotEmpty("recycleStatusId", form.getRecycleStatusId(), errors, new Object[]{"Recycle Status Id"});
    }

    protected boolean isInvalidRecycleRelease(ModelMap modelMap, SavePersonCDHPFulfillRecycleForm form) {
        ArrayList<LookUpValueCode> recycleStatusCodes = getUserSession().getRecycleStatusCodes();
        Iterator<LookUpValueCode> iter = recycleStatusCodes.iterator();
        while (iter.hasNext()) {
            LookUpValueCode lookupValueCode = iter.next();
            if (lookupValueCode.getLuvVal().equals(BPMAdminConstants.BPM_LUV_RECYCLE_STATUS_RELEASED)) {
                if (lookupValueCode.getLuvId().equals(Integer.valueOf(form.getRecycleStatusId()))) {
                    String errorMessage = getMessage("errors.releasedNotAllowedForUpdate", null);
                    createErrorMessageOnModel(modelMap, errorMessage);
                    return true;
                }
            }
        }

        return false;
    }

}
