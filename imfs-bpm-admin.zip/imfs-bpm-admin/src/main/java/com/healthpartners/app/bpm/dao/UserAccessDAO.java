package com.healthpartners.app.bpm.dao;

import com.healthpartners.app.bpm.dto.UserAccess;
import com.healthpartners.app.bpm.exception.BPMException;
import org.springframework.dao.DataAccessException;

import java.util.Collection;

public interface UserAccessDAO 
{
	public Collection<UserAccess> getUserAccessList(String lUserName)
	throws BPMException, DataAccessException;
	
	public Collection<UserAccess> getUserAccessList()
	throws BPMException, DataAccessException;
	
	public int insertUserAccess(UserAccess pUserAccess, String pModifyUserID) 
	throws DataAccessException;
	
	public int deleteUserAccess(String pUserLoginName) 
	throws DataAccessException;
	
	public int updateUserAccess(UserAccess pUserAccess, String pModifyUserID) 
	throws DataAccessException;
}
