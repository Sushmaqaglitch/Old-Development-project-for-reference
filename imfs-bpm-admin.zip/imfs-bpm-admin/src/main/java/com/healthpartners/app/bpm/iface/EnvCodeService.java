package com.healthpartners.app.bpm.iface;

import com.healthpartners.app.bpm.dto.BPMEnvCode;
import com.healthpartners.app.bpm.exception.BPMException;
import org.springframework.dao.DataAccessException;

import java.util.Collection;


public interface EnvCodeService {
    int insertEnvCode(BPMEnvCode code) throws BPMException, DataAccessException;

    int updateEnvCode(BPMEnvCode code) throws BPMException, DataAccessException;

    int deleteEnvCode(BPMEnvCode pEnvCode) throws BPMException, DataAccessException;

    Collection<BPMEnvCode> getAllEnvCodes() throws BPMException, DataAccessException;
}
