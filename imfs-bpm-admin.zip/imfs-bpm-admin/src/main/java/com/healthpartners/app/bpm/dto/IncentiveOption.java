package com.healthpartners.app.bpm.dto;

import java.io.Serializable;

public class IncentiveOption implements Serializable
{	
	static final long serialVersionUID = 0L;

    public IncentiveOption()
    {
    	super();
    }

    private Integer incentiveOptionID;    
    private String incentiveOptionName;
    private String incentiveOptionDesc;
    private String incentiveOptionURL;
    private Integer incentiveOptionTypeCodeID;
    private String incentiveOptionTypeCode;
    private String incentiveOptionTypeDesc;
    private Integer incentiveOptionUnitCodeID;
    private String incentiveOptionUnitCode;
	private String incentiveOptionUnitDesc;
    private java.sql.Date creationDate;
    private java.sql.Date closeDate;
    private boolean hasProgram;
    
    
	
	public final Integer getIncentiveOptionID() {
		return incentiveOptionID;
	}
	public final void setIncentiveOptionID(Integer incentiveOptionID) {
		this.incentiveOptionID = incentiveOptionID;
	}
	public final String getIncentiveOptionName() {
		return incentiveOptionName;
	}
	public final void setIncentiveOptionName(String incentiveOptionName) {
		this.incentiveOptionName = incentiveOptionName;
	}
	public final String getIncentiveOptionTypeCode() {
		return incentiveOptionTypeCode;
	}
	public final void setIncentiveOptionTypeCode(String incentiveOptionTypeCode) {
		this.incentiveOptionTypeCode = incentiveOptionTypeCode;
	}
	public final Integer getIncentiveOptionTypeCodeID() {
		return incentiveOptionTypeCodeID;
	}
	public final void setIncentiveOptionTypeCodeID(Integer incentiveOptionTypeCodeID) {
		this.incentiveOptionTypeCodeID = incentiveOptionTypeCodeID;
	}
	public final String getIncentiveOptionTypeDesc() {
		return incentiveOptionTypeDesc;
	}
	public final void setIncentiveOptionTypeDesc(String incentiveOptionTypeDesc) {
		this.incentiveOptionTypeDesc = incentiveOptionTypeDesc;
	}
	public final String getIncentiveOptionDesc() {
		return incentiveOptionDesc;
	}
	public final void setIncentiveOptionDesc(String incentiveOptionDesc) {
		this.incentiveOptionDesc = incentiveOptionDesc;
	}
	public final java.sql.Date getCloseDate() {
		return closeDate;
	}
	public final void setCloseDate(java.sql.Date closeDate) {
		this.closeDate = closeDate;
	}
	public final java.sql.Date getCreationDate() {
		return creationDate;
	}
	public final void setCreationDate(java.sql.Date creationDate) {
		this.creationDate = creationDate;
	}
	public final boolean isHasProgram() {
		return hasProgram;
	}
	public final void setHasProgram(boolean hasProgram) {
		this.hasProgram = hasProgram;
	}
	
	
	public String getIncentiveOptionUnitCode() {
		return incentiveOptionUnitCode;
	}
	public void setIncentiveOptionUnitCode(String incentiveOptionUnitCode) {
		this.incentiveOptionUnitCode = incentiveOptionUnitCode;
	}
	public String getIncentiveOptionUnitDesc() {
		return incentiveOptionUnitDesc;
	}
	public void setIncentiveOptionUnitDesc(String incentiveOptionUnitDesc) {
		this.incentiveOptionUnitDesc = incentiveOptionUnitDesc;
	}
	public Integer getIncentiveOptionUnitCodeID() {
		return incentiveOptionUnitCodeID;
	}
	public void setIncentiveOptionUnitCodeID(Integer incentiveOptionUnitCodeID) {
		this.incentiveOptionUnitCodeID = incentiveOptionUnitCodeID;
	}
	public String getIncentiveOptionURL() {
		return incentiveOptionURL;
	}
	public void setIncentiveOptionURL(String incentiveOptionURL) {
		this.incentiveOptionURL = incentiveOptionURL;
	}
	
	
     
}
