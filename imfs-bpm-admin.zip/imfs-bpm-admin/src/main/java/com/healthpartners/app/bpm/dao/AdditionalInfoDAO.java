package com.healthpartners.app.bpm.dao;

import com.healthpartners.app.bpm.dto.AdditionalInformation;
import org.springframework.dao.DataAccessException;

import java.util.Collection;

public interface AdditionalInfoDAO {

    int deleteAdditionalInfos(Integer pBusinessProgramID) throws DataAccessException;

    Collection<AdditionalInformation> getAdditionalInformation(Integer programID, Integer additionalInfoID);

    void insertAdditionalInformation(AdditionalInformation pAdditionalInformation, String lUserID);

    void updateAdditionalInformation(AdditionalInformation pAdditionalInformation, String lUserID) throws DataAccessException;
    Collection<AdditionalInformation> getAdditionalInformation(Integer programID) throws DataAccessException;
}
