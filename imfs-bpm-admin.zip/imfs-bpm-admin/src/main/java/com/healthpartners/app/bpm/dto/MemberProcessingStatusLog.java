package com.healthpartners.app.bpm.dto;

import java.io.Serializable;

public class MemberProcessingStatusLog implements Serializable {

    static final long serialVersionUID = 0L;

    private Long processLogID;

    private Integer personID;

    private String memberID;

    private String firstName;

    private String lastName;

    private String insertUser;

    private java.sql.Date insertDate;


    public MemberProcessingStatusLog() {
        super();
    }


    public String getFirstName() {
        return firstName;
    }


    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }


    public String getLastName() {
        return lastName;
    }


    public void setLastName(String lastName) {
        this.lastName = lastName;
    }


    public String getMemberID() {
        return memberID;
    }


    public void setMemberID(String memberID) {
        this.memberID = memberID;
    }


    public Integer getPersonID() {
        return personID;
    }


    public void setPersonID(Integer personID) {
        this.personID = personID;
    }


    public java.sql.Date getInsertDate() {
        return insertDate;
    }


    public void setInsertDate(java.sql.Date insertDate) {
        this.insertDate = insertDate;
    }


    public String getInsertUser() {
        return insertUser;
    }


    public void setInsertUser(String insertUser) {
        this.insertUser = insertUser;
    }


    public Long getProcessLogID() {
        return processLogID;
    }


    public void setProcessLogID(Long processLogID) {
        this.processLogID = processLogID;
    }


    public String getDisplayName() {
        StringBuffer sb = new StringBuffer("");

        if (getFirstName() != null) {
            sb.append(getFirstName());
            sb.append(" ");
        }

        if (getLastName() != null) {
            sb.append(getLastName());
        }

        if (sb.length() == 0) {
            sb.append("member");
        }

        return sb.toString();
    }
}
