/**
 * 
 */
package com.healthpartners.app.bpm.form;

import com.healthpartners.app.bpm.dto.EmployerGroup;
import com.healthpartners.app.bpm.dto.LookUpValueCode;

import java.util.ArrayList;

/**
 * @author jxbourbour
 *
 */
public class SaveProgramForm extends BaseForm {

	private Integer programID;
	private String programTypeCodeID;
	private String programName;
	
	private String qualificationWindowStartDate;	
    private String qualificationWindowEndDate;

    private String programWindowEndDate;
    
    private String releaseDate;
    
    private String programWindowEffectiveDateBefore;	
    private String effectiveDate;
    private String programWindowEndDateBefore;	
	private String endDate;
	
	private String newHireDate;
	
	private String membershipActivationDate;
	private boolean membershipActivationFlag;
	
	private String additionalGroupProgramInfo;
	
	private int familyParticipationRequirement;
	
	private Integer groupID;
	private Integer subgroupID;
	
	private String groupNumber;
	private String groupName;
	private String siteNumber;
	private String siteName;		
    
	private String recalculate;
	
	private String groupReportName;
	private String groupAbbreviatedName;
	
	private String siteReportName;
	private String siteAbbreviatedName;
	
	private int programStatusCodeID;
	
	private int qualificationCheckmarkID;
	
	private String statusCalcEndDate;
	
	private String contributionStartDate;
    private String contributionEndDate;
    
    private String numberOfMembers;
    private Integer reportIndicatorID;
	private ArrayList<LookUpValueCode> activationCodes = new ArrayList<>();
	private ArrayList<LookUpValueCode> participationList = new ArrayList<>();
	private ArrayList<LookUpValueCode> reportIndicatorList = new ArrayList<>();

	private Integer reportIndicatorCodeID;
	private String reportIndicatorCodeValue;

	private String familyParticipationValue;
	private String familyParticipationDesc;
	private String programStatusCodeValue;
	private String programStatusCodeDesc;

	private Integer copyFromPogramID;

	private ArrayList<EmployerGroup> availableSites = new ArrayList<>();

	private String constributionEndDate;
	
	public SaveProgramForm() {
		super();
	}
	
	public String getActionType() {
		return actionType;
	}

	public void setActionType(String actionType) {
		this.actionType = actionType;
	}

	public String getAdditionalGroupProgramInfo() {
		return additionalGroupProgramInfo;
	}

	public void setAdditionalGroupProgramInfo(String additionalGroupProgramInfo) {
		this.additionalGroupProgramInfo = additionalGroupProgramInfo;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public int getFamilyParticipationRequirement() {
		return familyParticipationRequirement;
	}

	public void setFamilyParticipationRequirement(int familyParticipationRequirement) {
		this.familyParticipationRequirement = familyParticipationRequirement;
	}

	public String getNewHireDate() {
		return newHireDate;
	}

	public void setNewHireDate(String newHireDate) {
		this.newHireDate = newHireDate;
	}

	public Integer getProgramID() {
		return programID;
	}

	public void setProgramID(Integer programID) {
		this.programID = programID;
	}

	public String getQualificationWindowEndDate() {
		return qualificationWindowEndDate;
	}

	public void setQualificationWindowEndDate(String qualificationWindowEndDate) {
		this.qualificationWindowEndDate = qualificationWindowEndDate;
	}

	public String getQualificationWindowStartDate() {
		return qualificationWindowStartDate;
	}

	public void setQualificationWindowStartDate(String qualificationWindowStartDate) {
		this.qualificationWindowStartDate = qualificationWindowStartDate;
	}

	public String getReleaseDate() {
		return releaseDate;
	}

	public void setReleaseDate(String releaseDate) {
		this.releaseDate = releaseDate;
	}

	public String getProgramTypeCodeID() {
		return programTypeCodeID;
	}

	public void setProgramTypeCodeID(String programTypeCodeID) {
		this.programTypeCodeID = programTypeCodeID;
	}

	public Integer getGroupID() {
		return groupID;
	}

	public void setGroupID(Integer groupID) {
		this.groupID = groupID;
	}

	public Integer getSubgroupID() {
		return subgroupID;
	}

	public void setSubgroupID(Integer subgroupID) {
		this.subgroupID = subgroupID;
	}
	
	public final String getEffectiveDate() {
		return effectiveDate;
	}

	public final void setEffectiveDate(String effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public String getMembershipActivationDate() {
		return membershipActivationDate;
	}

	public void setMembershipActivationDate(String membershipActivationDate) {
		this.membershipActivationDate = membershipActivationDate;
	}

	public boolean isMembershipActivationFlag() {
		return membershipActivationFlag;
	}

	public void setMembershipActivationFlag(boolean membershipActivationFlag) {
		this.membershipActivationFlag = membershipActivationFlag;
	}

	public final String getGroupName() {
		return groupName;
	}

	public final void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public final String getGroupNumber() {
		return groupNumber;
	}

	public final void setGroupNumber(String groupNumber) {
		this.groupNumber = groupNumber;
	}

	public final String getSiteName() {
		return siteName;
	}

	public final void setSiteName(String siteName) {
		this.siteName = siteName;
	}

	public final String getSiteNumber() {
		return siteNumber;
	}

	public final void setSiteNumber(String siteNumber) {
		this.siteNumber = siteNumber;
	}

	public final String getRecalculate() {
		return recalculate;
	}

	public final void setRecalculate(String recalculate) {
		this.recalculate = recalculate;
	}

	public String getGroupAbbreviatedName() {
		return groupAbbreviatedName;
	}

	public void setGroupAbbreviatedName(String groupAbbreviatedName) {
		this.groupAbbreviatedName = groupAbbreviatedName;
	}

	public String getGroupReportName() {
		return groupReportName;
	}

	public void setGroupReportName(String groupReportName) {
		this.groupReportName = groupReportName;
	}

	public String getSiteAbbreviatedName() {
		return siteAbbreviatedName;
	}

	public void setSiteAbbreviatedName(String siteAbbreviatedName) {
		this.siteAbbreviatedName = siteAbbreviatedName;
	}

	public String getSiteReportName() {
		return siteReportName;
	}

	public void setSiteReportName(String siteReportName) {
		this.siteReportName = siteReportName;
	}

	public int getProgramStatusCodeID() {
		return programStatusCodeID;
	}

	public void setProgramStatusCodeID(int programStatusCodeID) {
		this.programStatusCodeID = programStatusCodeID;
	}

	public final int getQualificationCheckmarkID() {
		return qualificationCheckmarkID;
	}

	public final void setQualificationCheckmarkID(int qualificationCheckmarkID) {
		this.qualificationCheckmarkID = qualificationCheckmarkID;
	}

	public final String getStatusCalcEndDate() {
		return statusCalcEndDate;
	}

	public final void setStatusCalcEndDate(String statusCalcEndDate) {
		this.statusCalcEndDate = statusCalcEndDate;
	}

	public String getContributionStartDate() {
		return contributionStartDate;
	}

	public void setContributionStartDate(String contributionStartDate) {
		this.contributionStartDate = contributionStartDate;
	}

	public String getContributionEndDate() {
		return contributionEndDate;
	}

	public void setContributionEndDate(String contributionEndDate) {
		this.contributionEndDate = contributionEndDate;
	}

	public String getNumberOfMembers() {
		return numberOfMembers;
	}

	public void setNumberOfMembers(String numberOfMembers) {
		this.numberOfMembers = numberOfMembers;
	}

	public String getProgramWindowEffectiveDateBefore() {
		return programWindowEffectiveDateBefore;
	}

	public void setProgramWindowEffectiveDateBefore(
			String programWindowEffectiveDateBefore) {
		this.programWindowEffectiveDateBefore = programWindowEffectiveDateBefore;
	}

	
	public String getProgramWindowEndDateBefore() {
		return programWindowEndDateBefore;
	}

	public void setProgramWindowEndDateBefore(String programWindowEndDateBefore) {
		this.programWindowEndDateBefore = programWindowEndDateBefore;
	}

	
	public String getProgramWindowEndDate() {
		return programWindowEndDate;
	}

	public void setProgramWindowEndDate(String programWindowEndDate) {
		this.programWindowEndDate = programWindowEndDate;
	}

	public Integer getReportIndicatorID() {
		return reportIndicatorID;
	}

	public void setReportIndicatorID(Integer reportIndicatorID) {
		this.reportIndicatorID = reportIndicatorID;
	}

	public String getProgramName() {
		return programName;
	}

	public void setProgramName(String programName) {
		this.programName = programName;
	}

	public ArrayList<LookUpValueCode> getActivationCodes() {
		return activationCodes;
	}

	public void setActivationCodes(ArrayList<LookUpValueCode> activationCodes) {
		this.activationCodes = activationCodes;
	}

	public ArrayList<LookUpValueCode> getParticipationList() {
		return participationList;
	}

	public void setParticipationList(ArrayList<LookUpValueCode> participationList) {
		this.participationList = participationList;
	}

	public Integer getReportIndicatorCodeID() {
		return reportIndicatorCodeID;
	}

	public void setReportIndicatorCodeID(Integer reportIndicatorCodeID) {
		this.reportIndicatorCodeID = reportIndicatorCodeID;
	}

	public String getReportIndicatorCodeValue() {
		return reportIndicatorCodeValue;
	}

	public void setReportIndicatorCodeValue(String reportIndicatorCodeValue) {
		this.reportIndicatorCodeValue = reportIndicatorCodeValue;
	}

	public ArrayList<LookUpValueCode> getReportIndicatorList() {
		return reportIndicatorList;
	}

	public void setReportIndicatorList(ArrayList<LookUpValueCode> reportIndicatorList) {
		this.reportIndicatorList = reportIndicatorList;
	}

	public String getFamilyParticipationValue() {
		return familyParticipationValue;
	}

	public void setFamilyParticipationValue(String familyParticipationValue) {
		this.familyParticipationValue = familyParticipationValue;
	}

	public String getFamilyParticipationDesc() {
		return familyParticipationDesc;
	}

	public void setFamilyParticipationDesc(String familyParticipationDesc) {
		this.familyParticipationDesc = familyParticipationDesc;
	}

	public String getProgramStatusCodeValue() {
		return programStatusCodeValue;
	}

	public void setProgramStatusCodeValue(String programStatusCodeValue) {
		this.programStatusCodeValue = programStatusCodeValue;
	}

	public String getProgramStatusCodeDesc() {
		return programStatusCodeDesc;
	}

	public void setProgramStatusCodeDesc(String programStatusCodeDesc) {
		this.programStatusCodeDesc = programStatusCodeDesc;
	}

	public Integer getCopyFromPogramID() {
		return copyFromPogramID;
	}

	public void setCopyFromPogramID(Integer copyFromPogramID) {
		this.copyFromPogramID = copyFromPogramID;
	}

	public ArrayList<EmployerGroup> getAvailableSites() {
		return availableSites;
	}

	public void setAvailableSites(ArrayList<EmployerGroup> availableSites) {
		this.availableSites = availableSites;
	}

	public String getConstributionEndDate() {
		return constributionEndDate;
	}

	public void setConstributionEndDate(String constributionEndDate) {
		this.constributionEndDate = constributionEndDate;
	}
}
