package com.healthpartners.app.bpm.controller;

import com.healthpartners.app.bpm.common.BPMPagination;
import com.healthpartners.app.bpm.dto.LookUpValueCode;
import com.healthpartners.app.bpm.dto.PageableRejectedPerson;
import com.healthpartners.app.bpm.dto.RejectedPerson;
import com.healthpartners.app.bpm.exception.BPMException;
import com.healthpartners.app.bpm.form.PersonEmployerActivityRecycleSearchForm;
import com.healthpartners.app.bpm.form.SavePersonEmployerActivityRecycleForm;
import com.healthpartners.app.bpm.iface.BusinessProgramService;
import com.healthpartners.app.bpm.security.BPMAdminAuthenticationSuccessHandler;
import com.healthpartners.app.bpm.session.UserSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.ArrayList;
import java.util.Iterator;

@Controller
public class PersonEmployerActivityRecycleEditController extends BaseController implements Validator {

    private BusinessProgramService businessProgramService;

    public PersonEmployerActivityRecycleEditController(BusinessProgramService businessProgramService) {
        this.businessProgramService = businessProgramService;
    }

    @GetMapping("/editPersonEmployerActivityRecycle")
    public String load(@RequestParam(name = "employerRecycleID") String employerRecycleID, ModelMap modelMap) throws BPMException {
        try {
            SavePersonEmployerActivityRecycleForm form = new SavePersonEmployerActivityRecycleForm();
            modelMap.put("savePersonEmployerActivityRecycleForm", form);
            RejectedPerson personEmployerActivityRecycle =  populateFormForEdit(modelMap, employerRecycleID);
            form.setEmployerRecycleID(employerRecycleID);
            form.setReason(personEmployerActivityRecycle.getReasonDesc());
            form.setApprover(personEmployerActivityRecycle.getApproverUserID());
        } catch (Exception e) {
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
            modelMap.put("errorMsg", getStackTrace(e));
        }

        return "editPersonEmployerActivityRecycle";
    }

    @PostMapping("/saveEditPersonEmployerActivityRecycle")
    public String submitSave(@ModelAttribute("savePersonEmployerActivityRecycleForm") SavePersonEmployerActivityRecycleForm form, ModelMap modelMap, BindingResult result, RedirectAttributes ra) throws Exception {
        try {
            validate(form, result);
            if (!result.hasErrors()) {
                save(form, modelMap, result);
                return redirectBackToSearch(ra);
            }

            populateFormForEdit(modelMap, form.getEmployerRecycleID());
        } catch (Exception e) {
            logger.error("An unexpected error has occurred: " + e.getMessage(), e);
            // Add error stack trace on the request, to be hidden in html.
            modelMap.put("errorMsg", getStackTrace(e));
        }

        return "editPersonEmployerActivityRecycle";
    }



    @PostMapping(value = "/saveEditPersonEmployerActivityRecycle", params = "back")
    public String submitBack(@ModelAttribute("savePersonEmployerActivityRecycleForm") SavePersonEmployerActivityRecycleForm form, RedirectAttributes ra) throws Exception {
       return redirectBackToSearch(ra);
    }
    private String redirectBackToSearch(RedirectAttributes ra) {
        PersonEmployerActivityRecycleSearchForm personEmployerActivityRecycleSearchForm = new PersonEmployerActivityRecycleSearchForm();
        ra.addFlashAttribute("personEmployerActivityRecycleSearchForm", personEmployerActivityRecycleSearchForm);
        return "redirect:personEmployerActivityRecycleSearch";
    }

    private RejectedPerson populateFormForEdit(ModelMap modelMap, String employerRecycleID) throws BPMException {
        RejectedPerson personEmployerActivityRecycle = businessProgramService.getEmployerRecycle(Integer.valueOf(employerRecycleID));


        ArrayList<LookUpValueCode> lLuvRecycleStatusCodes = getUserSession().getRecycleStatusCodes();

        //Lookup recycle status id description.
        Iterator<LookUpValueCode> iter = lLuvRecycleStatusCodes.iterator();
        while (iter.hasNext()) {
            LookUpValueCode lookupValueCode = (LookUpValueCode) iter.next();
            if (lookupValueCode.getLuvVal().equals(personEmployerActivityRecycle.getRecycleStatusCode())) {
                personEmployerActivityRecycle.setRecycleStatusCodeID(lookupValueCode.getLuvId());
                personEmployerActivityRecycle.setRecycleStatusCode(lookupValueCode.getLuvVal());
                break;
            }
        }

        getUserSession().setPersonEmployerActivityRecycle(personEmployerActivityRecycle);

        modelMap.put("personEmployerActivityRecycle", personEmployerActivityRecycle);
        modelMap.put("recycleStatusCodes", lLuvRecycleStatusCodes);
        return personEmployerActivityRecycle;
    }
    private void save(SavePersonEmployerActivityRecycleForm form, ModelMap modelMap, BindingResult result) throws Exception {
        String lUserID = BPMAdminAuthenticationSuccessHandler.getAuthenticatedUserName();

        ArrayList<LookUpValueCode> lLuvRecycleStatusCodes = getUserSession().getRecycleStatusCodes();
        form.setRecycleStatusCodes(lLuvRecycleStatusCodes);

        RejectedPerson lPersonEmployerActivityRecycle = getUserSession().getPersonEmployerActivityRecycle();
        lPersonEmployerActivityRecycle.setEmployerRecycleID(Integer.valueOf(form.getEmployerRecycleID()));
        lPersonEmployerActivityRecycle.setApproverUserID(form.getApprover());
        lPersonEmployerActivityRecycle.setReasonDesc(form.getReason());
        lPersonEmployerActivityRecycle.setRecycleStatusCode(form.getRecycleStatusCode());


        if (result.hasErrors())
        {
            modelMap.put("personEmployerActivityRecycle", lPersonEmployerActivityRecycle);
            modelMap.put("recycleStatusCodes", lLuvRecycleStatusCodes);

        }


        businessProgramService.updateEmployerRecycle(lPersonEmployerActivityRecycle, lUserID);


        RejectedPerson personEmployerActivityRecycle = businessProgramService.getEmployerRecycle(Integer.valueOf(form.getEmployerRecycleID()));
        modelMap.put("personEmployerActivityRecycle", personEmployerActivityRecycle);

        getUserSession().setRecycleStatusCodes(lLuvRecycleStatusCodes);

        ArrayList<RejectedPerson> personEmployerActivitiesRecyclePerPage = getUserSession().getPersonEmployerActivitiesRecyclePerPage();
        ArrayList<RejectedPerson> personEmployerActivitiesRecycle = getUserSession().getPersonEmployerActivitiesRecycle();


        modelMap.put("recycleStatusCodes", lLuvRecycleStatusCodes);
        modelMap.put("personEmployerActivitiesRecycle", personEmployerActivitiesRecyclePerPage);

        setAttributesForPaginationOnModel(modelMap, personEmployerActivitiesRecycle.size(), getUserSession().getPagination());

    }


    /**
     * Determine the size of the person employer activity recycle array list and the number of person contract recycle rows
     * to be displayed per page.
     *
     * @param modelMap
     * @param sessionBean
     * @param actionType
     * @param newDTOList
     */
    protected void setPersonEmployerActivityRecyclePagination(ModelMap modelMap,
                                                              UserSession sessionBean,
                                                              String actionType,
                                                              boolean newDTOList)
    {
        ArrayList<RejectedPerson> lPersonEmployerActivitiesRecycleList = sessionBean.getPersonEmployerActivitiesRecycle();

        /**
         * Create a Pageable wrapper for the array list.
         * Create a Pagination object and point it to the wrapper.
         */
        BPMPagination pagination = sessionBean.getPaginationMap().get(EMPLOYER_ACTIVITY_RECYCLE_LIST);
        PageableRejectedPerson lPRP = null;
        if (pagination == null || newDTOList)
        {
            lPRP = new PageableRejectedPerson(lPersonEmployerActivitiesRecycleList);
            lPRP.addRowNumber();
            pagination = new BPMPagination(lPRP, new ArrayList<Object>(lPersonEmployerActivitiesRecycleList));
            sessionBean.getPaginationMap().put(EMPLOYER_ACTIVITY_RECYCLE_LIST, pagination);
        }

        ArrayList<RejectedPerson> lPersonEmployerActivitiesRecyclePerPage = (ArrayList<RejectedPerson>) determineNextOrBackAction(actionType, pagination);
        setAttributesForPaginationOnModel(modelMap, lPersonEmployerActivitiesRecycleList.size(), pagination);
        sessionBean.setPagination(pagination);
        modelMap.put("activityDate", sessionBean.getActivityDate());
        modelMap.put("recycleStatusDate", sessionBean.getRecycleStatusDate());
        modelMap.put("personEmployerActivitiesRecycle", lPersonEmployerActivitiesRecyclePerPage);

        sessionBean.setPersonEmployerActivitiesRecyclePerPage(lPersonEmployerActivitiesRecyclePerPage);
        sessionBean.setPersonEmployerActivitiesRecycle(lPersonEmployerActivitiesRecycleList);
    }


    @Override
    public boolean supports(Class<?> clazz) {
        return false;
    }

    @Override
    public void validate(Object target, Errors errors) {
        SavePersonEmployerActivityRecycleForm form = (SavePersonEmployerActivityRecycleForm)target;
        getValidationSupport().validateNotNull("reason", form.getReason(), errors, new Object[]{"Reason"});
        getValidationSupport().validateNotNull("approver", form.getApprover(), errors, new Object[]{"Approver"});
        getValidationSupport().validateNotNull("recycleStatusCode", form.getRecycleStatusCode(), errors, new Object[]{"Recycle Status Code"});
    }
}
