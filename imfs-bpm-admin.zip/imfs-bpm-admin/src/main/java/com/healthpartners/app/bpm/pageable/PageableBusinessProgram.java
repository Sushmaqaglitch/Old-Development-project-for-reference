package com.healthpartners.app.bpm.pageable;

import com.healthpartners.app.bpm.dto.BusinessProgram;

import java.util.ArrayList;
import java.util.Iterator;

/**
 * The pageable class serves as a wrapper for the array list of objects, and
 * operations that are performed on those objects. For ex. adding a row number
 * for display.
 * The BPMPagination then has a pointer to an instance of this class.
 * 
 * @author jxbourbour
 *
 */
public class PageableBusinessProgram implements BPMPageable
{
	ArrayList<BusinessProgram> businessPrograms;
	
	public PageableBusinessProgram()
	{
		super();
	}

	public PageableBusinessProgram(ArrayList<BusinessProgram> pBusinessPrograms)
	{
		businessPrograms = pBusinessPrograms;
	}
		

	public ArrayList<BusinessProgram> getBusinessPrograms() {
		return businessPrograms;
	}

	public void setBusinessPrograms(ArrayList<BusinessProgram> businessPrograms) {
		this.businessPrograms = businessPrograms;
	}
	
	public void addRowNumber()
	{
	    int startRowNumber = 1;
		Iterator<BusinessProgram> iter = (Iterator<BusinessProgram>) businessPrograms.iterator();
		while (iter.hasNext()) {
			BusinessProgram lBusinessProgram = (BusinessProgram) iter.next();
			lBusinessProgram.setRowNumber(startRowNumber);
			startRowNumber++;
		}
	}
}
