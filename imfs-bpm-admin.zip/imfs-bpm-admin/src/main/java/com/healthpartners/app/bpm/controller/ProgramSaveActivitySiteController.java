package com.healthpartners.app.bpm.controller;

import com.healthpartners.app.bpm.common.BPMAdminConstants;
import com.healthpartners.app.bpm.common.BPMAdminEmailUtility;
import com.healthpartners.app.bpm.common.BPMAdminUtils;
import com.healthpartners.app.bpm.dao.AuditLogDAO;
import com.healthpartners.app.bpm.dto.*;
import com.healthpartners.app.bpm.exception.BPMException;
import com.healthpartners.app.bpm.form.SaveProgramActivitySiteForm;
import com.healthpartners.app.bpm.iface.BusinessProgramService;
import com.healthpartners.app.bpm.iface.MemberService;
import com.healthpartners.app.bpm.session.UserSession;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.view.RedirectView;

import jakarta.servlet.http.HttpServletRequest;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

@Controller
public class ProgramSaveActivitySiteController extends BaseController implements Validator {
    private static final String ACTION_ADD = "add";
    private static final String ACTION_REMOVE = "remove";

    private SimpleDateFormat fmt = new SimpleDateFormat(BPMAdminConstants.HP_BPM_ADMIN_UI_COMMON_DATE_FORMAT);
    private final BusinessProgramService businessProgramService;
    private final MemberService memberService;
    private final BPMAdminEmailUtility bpmAdminEmailUtility;
    private final AuditLogDAO auditLogDAO;

    private String hostName = "http://localhost";

    protected final Log logger = LogFactory.getLog(getClass());

    public ProgramSaveActivitySiteController(BusinessProgramService businessProgramService, MemberService memberService, BPMAdminEmailUtility bpmAdminEmailUtility, AuditLogDAO auditLogDAO) {
        this.businessProgramService = businessProgramService;
        this.memberService = memberService;
        this.bpmAdminEmailUtility = bpmAdminEmailUtility;
        this.auditLogDAO = auditLogDAO;
    }


    @PostMapping(value="/saveProgramActivitySite")
    public String submitSaveProgramActivitySiteForm(@ModelAttribute("saveProgramActivitySiteForm") SaveProgramActivitySiteForm form, ModelMap modelMap) throws Exception {
        String actionType = form.getActionType();

        // Add an Activity to the Program Eligible Activities.
        if (ACTION_ADD.equals(actionType)) {
            addSubgroup(form, modelMap, getUserSession());
        }

        // Remove an Activity from the Program Eligible Activities.
        if (ACTION_REMOVE.equals(actionType)) {
            removeSubGroup(form, modelMap, getUserSession());
        }

        return "programActivitySites";
    }

    @PostMapping(value="/saveProgramActivitySite", params="save")
    public String submitSave(@ModelAttribute("saveProgramActivitySiteForm") SaveProgramActivitySiteForm form, RedirectAttributes ra, ModelMap modelMap) throws Exception {
        String lUserID = getUserSessionSupport().getAuthenticatedUsername();
        if (WHICH_SAVE_SELECTED_SITES_BIZ_PROGRAM.equalsIgnoreCase(getUserSession().getWhichSaveSelectedSite())) {
            saveSelectedSitesBizPrograms(ra);
        } else if (WHICH_SAVE_SELECTED_SITES_ACTIVITIES.equalsIgnoreCase(getUserSession().getWhichSaveSelectedSite())) {
            saveSelectedSitesActivities(ra, lUserID);
        } else if (WHICH_SAVE_SELECTED_SITES_CHECKMARKS.equalsIgnoreCase(getUserSession().getWhichSaveSelectedSite())) {
            saveSelectedSitesCheckmarks(ra, modelMap, lUserID);
        } else if (WHICH_SAVE_SELECTED_SITES_INCENTIVES.equals(getUserSession().getWhichSaveSelectedSite())) {
            saveSelectedSitesIncentives(ra, modelMap, lUserID);
        } else if (WHICH_SAVE_SELECTED_SITES_ADD_INFOS.equals(getUserSession().getWhichSaveSelectedSite())) {
            saveSelectedSitesAdditionalInfos(ra, modelMap, lUserID);
        } else if (WHICH_SAVE_SELECTED_SITES_INCENTIVE_ACTIVITIES.equals(getUserSession().getWhichSaveSelectedSite())) {
            saveSelectedSitesIncentiveActivities(ra, modelMap, lUserID);
        } else if (WHICH_SAVE_SELECTED_SITES_PROGRAM_CONTRIBUTION_GRID.equals(getUserSession().getWhichSaveSelectedSite())) {
            saveSelectedSitesProgramContributionGrid(ra, modelMap, lUserID);
        } else if (WHICH_SAVE_SELECTED_SITES_CONTRIBUTION.equals(getUserSession().getWhichSaveSelectedSite())) {
            backToContributionGridPage(ra, modelMap, lUserID);
            // Back to the Contribution Grid Page.
            return "redirect:editProgramContributionTier?actionType=edit&programID="+getUserSession().getBusinessProgram().getProgramID()+
                    "&incentiveOptionID="+getUserSession().getProgramIncentiveOption().getIncentiveOption().getIncentiveOptionID();
        } else if (WHICH_SAVE_SELECTED_SITES_EXTENDED_AUTH_CODES.equals(getUserSession().getWhichSaveSelectedSite())) {
            saveSelectedSitesExtendedAuthCodes(ra, modelMap, lUserID);
        }

        ra.addFlashAttribute("groupNumber", form.getGroupNumber());
        String url = "viewProgram?programID=" + form.getProgramID();
        return "redirect:" + url;
    }

    @PostMapping(value="/saveProgramActivitySite", params="cancel")
    public RedirectView submitCancelEditProgram(@ModelAttribute("saveProgramActivitySiteForm") SaveProgramActivitySiteForm form, RedirectAttributes ra) throws BPMException {
        ArrayList<ProgramIncentiveOption> lProgramIncentiveOptions = (ArrayList<ProgramIncentiveOption>)
                businessProgramService.getProgramIncentiveOptions(getUserSession().getBusinessProgram().getProgramID());
        getUserSession().setProgramIncentiveOptions(lProgramIncentiveOptions);
        ra.addFlashAttribute("groupNumber", form.getGroupNumber());
        String url = "viewProgram?programID=" + form.getProgramID();
        return new RedirectView(url);
    }

    protected void addSubgroup(SaveProgramActivitySiteForm form, ModelMap modelMap, UserSession sessionBean) {
        Integer lSubGroupID = form.getSubGroupID();

        if (sessionBean.getAvailableSites() == null) {
            sessionBean.setAvailableSites(new ArrayList<EmployerGroup>());
        }

        if (sessionBean.getEmployerSubGroups() == null) {
            sessionBean.setEmployerSubGroups(new ArrayList<EmployerGroup>());
        }

        // Find the Program Eligible Activity whose ID matches the one selected.
        for (int i = 0; i < sessionBean.getAvailableSites().size(); i++) {
            EmployerGroup lEmployerGroup = (EmployerGroup) sessionBean.getAvailableSites().get(i);
            // Once the ID is found, remove the Incentive from the Program Incentive Options
            // and add it back to the list of Available Incentives.
            if (lEmployerGroup.getSubgroupID().intValue() == lSubGroupID.intValue()) {
                sessionBean.getEmployerSubGroups().add(sessionBean.getAvailableSites().get(i));
                sessionBean.getAvailableSites().remove(i);
                break;
            }
        }

        modelMap.put("selectedSubGroups", sessionBean.getEmployerSubGroups());
        modelMap.put("availableSubGroups", sessionBean.getAvailableSites());
        modelMap.put("businessProgram", sessionBean.getBusinessProgram());
    }

    private void removeSubGroup(SaveProgramActivitySiteForm form, ModelMap modelMap, UserSession sessionBean) {
        Integer lSubGroupID = form.getSubGroupID();

        if (sessionBean.getAvailableSites() == null) {
            sessionBean.setAvailableSites(new ArrayList<>());
        }

        if (sessionBean.getEmployerSubGroups() == null) {
            sessionBean.setEmployerSubGroups(new ArrayList<>());
        }

        // Find the Program Eligible Activity whose ID matches the one selected.
        for (int i = 0; i < sessionBean.getEmployerSubGroups().size(); i++) {
            EmployerGroup lEmployerGroup = sessionBean.getEmployerSubGroups().get(i);
            // Once the ID is found, remove the Incentive from the Program Incentive Options
            // and add it back to the list of Available Incentives.
            if (lEmployerGroup.getSubgroupID().intValue() == lSubGroupID.intValue()) {
                sessionBean.getAvailableSites().add(sessionBean.getEmployerSubGroups().get(i));
                sessionBean.getEmployerSubGroups().remove(i);
                break;
            }
        }

        modelMap.put("selectedSubGroups", sessionBean.getEmployerSubGroups());
        modelMap.put("availableSubGroups", sessionBean.getAvailableSites());
        modelMap.put("businessProgram", sessionBean.getBusinessProgram());
    }

    protected void saveSelectedSitesBizPrograms(RedirectAttributes ra) throws Exception {
        String userID = getUserSessionSupport().getAuthenticatedUsername();
        ArrayList<EmployerGroup> lSelectedSubGroups = getUserSession().getEmployerSubGroups();

        java.sql.Date lNewHireDate = getUserSession().getBusinessProgram().getEmployerGroup().getNewHireDate();

        for (EmployerGroup lSelectedSubGroup : lSelectedSubGroups) {
            ArrayList<BusinessProgram> lBusinessPrograms = (ArrayList<BusinessProgram>)
                    businessProgramService.getBusinessPrograms(getUserSession().getBusinessProgram().getEffectiveDate()
                            , getUserSession().getBusinessProgram().getEmployerGroup().getGroupID()
                            , lSelectedSubGroup.getSubgroupID());

            for (BusinessProgram lBusinessProgram : lBusinessPrograms) {
                lBusinessProgram.setProgramName(getUserSession().getBusinessProgram().getProgramName());
                lBusinessProgram.setFamilyParticipationRequirement(getUserSession().getBusinessProgram().getFamilyParticipationRequirement());
                lBusinessProgram.setReleaseDate(getUserSession().getBusinessProgram().getReleaseDate());
                lBusinessProgram.setQualificationWindowStartDate(getUserSession().getBusinessProgram().getQualificationWindowStartDate());
                lBusinessProgram.setQualificationWindowEndDate(getUserSession().getBusinessProgram().getQualificationWindowEndDate());
                lBusinessProgram.setStatusCalcEndDate(getUserSession().getBusinessProgram().getStatusCalcEndDate());
                lBusinessProgram.setBenefitYearStartDate(getUserSession().getBusinessProgram().getBenefitYearStartDate());
                lBusinessProgram.setEffectiveDate(getUserSession().getBusinessProgram().getEffectiveDate());
                lBusinessProgram.setEndDate(getUserSession().getBusinessProgram().getEndDate());
                lBusinessProgram.setMembershipProcessDate(getUserSession().getBusinessProgram().getMembershipProcessDate());
                lBusinessProgram.setMembershipProcessFlag(getUserSession().getBusinessProgram().getMembershipProcessFlag());
                lBusinessProgram.setContributionStartDate(getUserSession().getBusinessProgram().getContributionStartDate());
                lBusinessProgram.setContributionEndDate(getUserSession().getBusinessProgram().getContributionEndDate());
                lBusinessProgram.setReportIndicatorCodeID(getUserSession().getBusinessProgram().getReportIndicatorCodeID());
                lBusinessProgram.setProgramStatusCodeID(getUserSession().getBusinessProgram().getProgramStatusCodeID());
                lBusinessProgram.setAdditionalGroupProgramInfo(getUserSession().getBusinessProgram().getAdditionalGroupProgramInfo());

                lSelectedSubGroup.setNewHireDate(lNewHireDate);
                lBusinessProgram.setEmployerGroup(lSelectedSubGroup);
                businessProgramService.updateBusinessProgram(lBusinessProgram, userID);
                businessProgramService.updateAllGroupSiteMembers(BPMAdminConstants.BPM_ADMIN_MEMBERSHIP_UPDATE_PRCS_ID, lBusinessProgram.getProgramID());
                if (lBusinessProgram.getMembershipProcessDate() != null) {
                    // EV 40748 For the email notification, use the attributes of the newly created Business Program.
                    setAndNotifyMembershipDateChange(lBusinessProgram, businessProgramService, memberService
                            , bpmAdminEmailUtility
                            , BPMAdminUtils.formatDateMMddyyyy(lBusinessProgram.getMembershipProcessDate())
                            , hostName);
                }
            }
        }

        ra.addFlashAttribute("businessProgram", getUserSession().getBusinessProgram());

        return;
    }

    private void saveSelectedSitesActivities(RedirectAttributes ra, String pUserID) throws Exception {
        ArrayList<EligibleActivity> lEligibleActivities = getUserSessionSupport().setupUserSession().getEligibleActivities();
        ArrayList<EmployerGroup> lSelectedSubGroups = getUserSessionSupport().setupUserSession().getEmployerSubGroups();

        // Save eligible activities to the selected subgroups.
        businessProgramService.saveEligibleActivitiesToSites(getUserSessionSupport().setupUserSession().getBusinessProgram(), lEligibleActivities, pUserID, lSelectedSubGroups);

        lEligibleActivities.clear();
        // Now that the new eligible activities have been saved, get a fresh list from the database.
        lEligibleActivities = (ArrayList<EligibleActivity>) businessProgramService.getEligibleActivities(getUserSessionSupport().setupUserSession().getBusinessProgram().getProgramID());

        businessProgramService.updateBusinessProgram(getUserSessionSupport().setupUserSession().getBusinessProgram(), pUserID);

        // Boolean indicates all programs and not just ACTIVEs.
        // Just retrieve ACTIVEs.
        BusinessProgram lBusinessProgram = businessProgramService.getBusinessProgram(getUserSessionSupport().setupUserSession().getBusinessProgram().getProgramID(), false);

        getUserSessionSupport().setupUserSession().setBusinessProgram(lBusinessProgram);
        getUserSessionSupport().setupUserSession().setEligibleActivities(lEligibleActivities);

        ra.addFlashAttribute("programIncentiveOptions", getUserSessionSupport().setupUserSession().getProgramIncentiveOptions());
        ra.addFlashAttribute("businessProgram", getUserSessionSupport().setupUserSession().getBusinessProgram());
        ra.addFlashAttribute("eligibleActivities", getUserSessionSupport().setupUserSession().getEligibleActivities());
        ra.addFlashAttribute("additionalInfos", getUserSessionSupport().setupUserSession().getAdditionalInfos());
    }

    protected void setAndNotifyMembershipDateChange(BusinessProgram businessProgram, BusinessProgramService businessProgramService, MemberService memberService, BPMAdminEmailUtility bpmAdminEmailUtility, String pMembershipActivationDate, String hostName) throws Exception {
        if (pMembershipActivationDate != null && pMembershipActivationDate.trim().length() > 0) {
            //This statement moved to main method right before update to Business Program DAO.
            //businessProgram.setMembershipProcessDate(new java.sql.Date(fmt.parse(saveProgramForm.getMembershipActivationDate()).getTime()));

            // If Membership Process Date is within 2 days of Today, send a email notification
            // to Membership.
            Calendar lToday = Calendar.getInstance();
            Calendar lMembershipActivationDate = Calendar.getInstance();
            lMembershipActivationDate.setTime(new java.util.Date(businessProgram.getMembershipProcessDate().getTime()));

            if (BPMAdminUtils.getDaysBetweenDates(lMembershipActivationDate, lToday) <= 1) {
                // Send an email notification
                Integer lNumberOfQualifieds =
                        businessProgramService.getContractStatusCount(BPMAdminConstants.BPM_ADMIN_CONTRACT_STATUS_QUALIFIED, businessProgram.getProgramID());

                Integer lNumberOfNotQualifieds =
                        businessProgramService.getContractStatusCount(BPMAdminConstants.BPM_ADMIN_CONTRACT_STATUS_DID_NOT_QUALIFIY, businessProgram.getProgramID());

                prepareAndSendSummaryEmail(businessProgram
                        , memberService
                        , bpmAdminEmailUtility
                        , lNumberOfQualifieds
                        , lNumberOfNotQualifieds
                        , hostName);
            }
        }
    }

    /**
     * Save this business program checkmarks to all the selected sites
     * in this group.
     *
     * @param ra
     * @param modelMap
     * @param pUserID
     * @return
     * @throws Exception
     */
    private void saveSelectedSitesCheckmarks(RedirectAttributes ra, ModelMap modelMap, String pUserID) throws Exception {
        ArrayList<ProgramCheckmark> lProgramCheckmarks = getUserSession().getProgramCheckmarks();

        ArrayList<EmployerGroup> lSelectedSubGroups = getUserSession().getEmployerSubGroups();

        // Save eligible activities to the selected subgroups.
        businessProgramService.saveProgramCheckmarksToSites(getUserSession().getBusinessProgram(), lProgramCheckmarks, pUserID, lSelectedSubGroups);

        lProgramCheckmarks.clear();
        // Now that the new eligible activities have been saved, get a fresh list from the database.
        lProgramCheckmarks = businessProgramService.getProgramCheckmarks(getUserSession().getBusinessProgram().getProgramID());

        businessProgramService.updateBusinessProgram(getUserSession().getBusinessProgram(), pUserID);

        for (EmployerGroup lEmployerGroup : lSelectedSubGroups) {
            ArrayList<BusinessProgram> lBusinessPrograms = (ArrayList<BusinessProgram>)
                    businessProgramService.getBusinessPrograms(getUserSession().getBusinessProgram().getEffectiveDate()
                            , getUserSession().getBusinessProgram().getEmployerGroup().getGroupID()
                            , lEmployerGroup.getSubgroupID());

            for (BusinessProgram lBusinessProgram : lBusinessPrograms) {
                memberService.updateMemberStatusByCodeValue(null, lBusinessProgram.getProgramID(), null, BPMAdminConstants.BPM_ADMIN_STATUS_ELIGIBLE, pUserID);
                businessProgramService.updateAllGroupSiteMembers(BPMAdminConstants.BPM_ADMIN_MEMBERS_RECALCULATION_PRCS_ID, lBusinessProgram.getProgramID());
            }
        }

        // Boolean indicates all programs and not just ACTIVEs.
        // Just retrieve ACTIVEs.
        BusinessProgram lBusinessProgram = businessProgramService.getBusinessProgram(getUserSession().getBusinessProgram().getProgramID(), false);

        getUserSession().setBusinessProgram(lBusinessProgram);
        getUserSession().setProgramCheckmarks(lProgramCheckmarks);

        modelMap.put("programIncentiveOptions", getUserSession().getProgramIncentiveOptions());
        modelMap.put("businessProgram", getUserSession().getBusinessProgram());
        modelMap.put("programCheckmarks", getUserSession().getProgramCheckmarks());
        modelMap.put("additionalInfos", getUserSession().getAdditionalInfos());

        ra.addFlashAttribute("programIncentiveOptions", getUserSession().getProgramIncentiveOptions());
        ra.addFlashAttribute("businessProgram", getUserSession().getBusinessProgram());
        ra.addFlashAttribute("programCheckmarks", getUserSession().getProgramCheckmarks());
        ra.addFlashAttribute("additionalInfos", getUserSession().getAdditionalInfos());

        return;
    }

    private void saveSelectedSitesIncentives(RedirectAttributes ra, ModelMap modelMap, String pUserID) throws Exception {
        ArrayList<ProgramIncentiveOption> lProgramIncentives = getUserSession().getProgramIncentiveOptions();

        ArrayList<EmployerGroup> lSelectedSubGroups = getUserSession().getEmployerSubGroups();

        // Save eligible activities to the selected subgroups.
        businessProgramService.saveProgramIncentiveOptionsToSites(getUserSession().getBusinessProgram(), lProgramIncentives, lSelectedSubGroups, pUserID);

        lProgramIncentives.clear();
        // Now that the new eligible activities have been saved, get a fresh list from the database.
        lProgramIncentives = (ArrayList<ProgramIncentiveOption>) businessProgramService.getProgramIncentiveOptions(getUserSession().getBusinessProgram().getProgramID());

        businessProgramService.updateBusinessProgram(getUserSession().getBusinessProgram(), pUserID);

        // Boolean indicates all programs and not just ACTIVEs.
        // Just retrieve ACTIVEs.
        BusinessProgram lBusinessProgram = businessProgramService.getBusinessProgram(getUserSession().getBusinessProgram().getProgramID(), false);

        getUserSession().setBusinessProgram(lBusinessProgram);
        getUserSession().setProgramIncentiveOptions(lProgramIncentives);

        ra.addFlashAttribute("programIncentiveOptions", getUserSession().getProgramIncentiveOptions());
        ra.addFlashAttribute("businessProgram", getUserSession().getBusinessProgram());
//        ra.addFlashAttribute("additionalInfos", getUserSession().getAdditionalInfos());
    }

    private void saveSelectedSitesAdditionalInfos(RedirectAttributes ra, ModelMap modelMap, String pUserID) throws Exception {
        ArrayList<AdditionalInformation> lAdditionalInfos = getUserSession().getAdditionalInfos();

        ArrayList<EmployerGroup> lSelectedSubGroups = getUserSession().getEmployerSubGroups();

        // Save eligible activities to the selected subgroups.
        businessProgramService.saveAdditionalInfoToSites(getUserSession().getBusinessProgram(), lAdditionalInfos, lSelectedSubGroups, pUserID);

        lAdditionalInfos.clear();
        // Now that the new eligible activities have been saved, get a fresh list from the database.
        lAdditionalInfos = (ArrayList<AdditionalInformation>) businessProgramService.getAdditionalInfos(getUserSession().getBusinessProgram().getProgramID());

        businessProgramService.updateBusinessProgram(getUserSession().getBusinessProgram(), pUserID);

        // Boolean indicates all programs and not just ACTIVEs.
        // Just retrieve ACTIVEs.
        BusinessProgram lBusinessProgram = businessProgramService.getBusinessProgram(getUserSession().getBusinessProgram().getProgramID(), false);

        getUserSession().setBusinessProgram(lBusinessProgram);
        getUserSession().setAdditionalInfos(lAdditionalInfos);

        ra.addFlashAttribute("businessProgram", getUserSession().getBusinessProgram());
        ra.addFlashAttribute("additionalInfos", getUserSession().getAdditionalInfos());
    }

    private void saveSelectedSitesIncentiveActivities(RedirectAttributes ra, ModelMap modelMap, String pUserID) throws BPMException {
        ArrayList<EmployerGroup> lSelectedSubGroups = getUserSession().getEmployerSubGroups();

        businessProgramService.saveProgramIncentiveActivitiesToSites(getUserSession().getBusinessProgram()
                , getUserSession().getProgramIncentiveOption()
                , lSelectedSubGroups
                , pUserID);

        // Get a new list of Program Incentive Options
        ArrayList<ProgramIncentiveOption> lProgramIncentiveOptions = (ArrayList<ProgramIncentiveOption>)
                businessProgramService.getProgramIncentiveOptions(getUserSession().getBusinessProgram().getProgramID());

        getUserSession().getProgramIncentiveOptions().clear();
        getUserSession().setProgramIncentiveOptions(lProgramIncentiveOptions);

        modelMap.put("businessProgram", getUserSession().getBusinessProgram());
        modelMap.put("programIncentiveOptions", getUserSession().getProgramIncentiveOptions());
        ra.addFlashAttribute("businessProgram", getUserSession().getBusinessProgram());
        ra.addFlashAttribute("programIncentiveOptions", getUserSession().getProgramIncentiveOptions());

    }

    private void saveSelectedSitesProgramContributionGrid(RedirectAttributes ra, ModelMap modelMap, String pUserID) throws BPMException {
        businessProgramService.saveProgramContributionGridsToSites(getUserSession().getBusinessProgram()
                , getUserSession().getProgramIncentiveOption()
                , getUserSession().getEmployerSubGroups()
                , getUserSession().getProgramContributionGrids()
                , pUserID);

        // Get a new list of Program Incentive Options
        ArrayList<ProgramIncentiveOption> lProgramIncentiveOptions = (ArrayList<ProgramIncentiveOption>)
                businessProgramService.getProgramIncentiveOptions(getUserSession().getBusinessProgram().getProgramID());

        //sessionBean.getProgramIncentiveOptions().clear();
        //sessionBean.setProgramIncentiveOptions(lProgramIncentiveOptions);

        modelMap.put("businessProgram", getUserSession().getBusinessProgram());
        modelMap.put("programIncentiveOptions", getUserSession().getProgramIncentiveOptions());
        ra.addFlashAttribute("businessProgram", getUserSession().getBusinessProgram());
        ra.addFlashAttribute("programIncentiveOptions", getUserSession().getProgramIncentiveOptions());
    }

    private void backToContributionGridPage(RedirectAttributes ra, ModelMap modelMap, String pUserID) {
        modelMap.put("businessProgram", getUserSession().getBusinessProgram());
        modelMap.put("programIncentiveOptions", getUserSession().getProgramIncentiveOptions());
        modelMap.put("programContributionTiers", getUserSession().getProgramContributionTiers());
        modelMap.put("programContributionTier", getUserSession().getProgramContributionTier());
        modelMap.put("allContributionTiers", getUserSession().getAllContributionTiers());
        modelMap.put("programIncentiveOption", getUserSession().getProgramIncentiveOption());
        modelMap.put("availableContributionTierBenefitContractTypes", getUserSession().getAssignedContributionTierBenefitContractTypes());
        modelMap.put("benefitContractTypeRelationshipHashMap", getUserSession().getBenefitContractTypeRelationshipTierHashMap());
        modelMap.put("eligibleActivities", getUserSession().getEligibleActivities());
        modelMap.put("contributionTierBenefitContractTypes", getUserSession().getContributionTierBenefitContractTypes());
        modelMap.put("benefitContractTypeRelationshipHashMap", getUserSession().getBenefitContractTypeRelationshipTierHashMap());
        modelMap.put("isProgramContributionRowDisabled", getUserSession().isProgramContributionTierExists());
        modelMap.put("luvActivityTypes", getUserSession().getActivityTypeCodes());
        modelMap.put("luvBenefitContractTypes", getUserSession().getBenefitContractTypes());
        modelMap.put(BPMAdminConstants.BPM_ADMIN_SITES_SELECTED, "true");

        ra.addFlashAttribute("businessProgram", getUserSession().getBusinessProgram());
        ra.addFlashAttribute("programIncentiveOptions", getUserSession().getProgramIncentiveOptions());
        ra.addFlashAttribute("programContributionTiers", getUserSession().getProgramContributionTiers());
        ra.addFlashAttribute("programContributionTier", getUserSession().getProgramContributionTier());
        ra.addFlashAttribute("allContributionTiers", getUserSession().getAllContributionTiers());
        ra.addFlashAttribute("programIncentiveOption", getUserSession().getProgramIncentiveOption());
        ra.addFlashAttribute("availableContributionTierBenefitContractTypes", getUserSession().getAssignedContributionTierBenefitContractTypes());
        ra.addFlashAttribute("benefitContractTypeRelationshipHashMap", getUserSession().getBenefitContractTypeRelationshipTierHashMap());
        ra.addFlashAttribute("eligibleActivities", getUserSession().getEligibleActivities());
        ra.addFlashAttribute("contributionTierBenefitContractTypes", getUserSession().getContributionTierBenefitContractTypes());
        ra.addFlashAttribute("benefitContractTypeRelationshipHashMap", getUserSession().getBenefitContractTypeRelationshipTierHashMap());
        ra.addFlashAttribute("isProgramContributionRowDisabled", getUserSession().isProgramContributionTierExists());
        ra.addFlashAttribute("luvActivityTypes", getUserSession().getActivityTypeCodes());
        ra.addFlashAttribute("luvBenefitContractTypes", getUserSession().getBenefitContractTypes());
        ra.addFlashAttribute(BPMAdminConstants.BPM_ADMIN_SITES_SELECTED, "true");
    }

    private void saveSelectedSitesExtendedAuthCodes(RedirectAttributes ra, ModelMap modelMap, String pUserID) throws Exception {
        ArrayList<AuthCode> lExtendedAuthCodes = getUserSession().getExtendedAuthCodes();

        ArrayList<EmployerGroup> lSelectedSubGroups = getUserSession().getEmployerSubGroups();

        // Save eligible activities to the selected subgroups.
        businessProgramService.saveExtendedAuthCodesToSites(getUserSession().getBusinessProgram(),
                lExtendedAuthCodes,
                lSelectedSubGroups,
                pUserID);

        lExtendedAuthCodes.clear();
        // Now that the new eligible activities have been saved, get a fresh list from the database.
        lExtendedAuthCodes = (ArrayList<AuthCode>)
                businessProgramService.getExtendedAuthCodes(getUserSession().getBusinessProgram().getProgramID());

        businessProgramService.updateBusinessProgram(getUserSession().getBusinessProgram(), pUserID);

        // Boolean indicates all programs and not just ACTIVEs.
        // Just retrieve ACTIVEs.
        BusinessProgram lBusinessProgram = businessProgramService.getBusinessProgram(getUserSession().getBusinessProgram().getProgramID(), false);

        getUserSession().setBusinessProgram(lBusinessProgram);
        getUserSession().setExtendedAuthCodes(lExtendedAuthCodes);

        ra.addFlashAttribute("businessProgram", getUserSession().getBusinessProgram());
        ra.addFlashAttribute("extendedAuthCodes", getUserSession().getExtendedAuthCodes());
    }

    @Override
    public boolean supports(Class<?> clazz) {
        return SaveProgramActivitySiteForm.class.isAssignableFrom(clazz);
    }

    @Override
    public void validate(Object target, Errors errors) {

    }
}
