package com.healthpartners.app.bpm.dao;

import com.healthpartners.app.bpm.dto.GroupActivityProgressTracker;
import com.healthpartners.app.bpm.exception.BPMException;
import jakarta.annotation.PostConstruct;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Collection;


/**
 * @author jxbourbour
 */
@Repository
@Transactional(timeout = 300, rollbackFor = {DataAccessException.class, BPMException.class})
public class GroupActivityProgressTrackerDAOJdbc extends JdbcDaoSupport implements GroupActivityProgressTrackerDAO {
    private static final String selectGroupActivityProgressionTracker = """
			select
				t.empl_grp_apt_id,\s
				t.biz_pgm_id,
				t.batch_dt,
				t.grp_no,
				t.grp_name,
				t.preprocess_ct,
				t.preprocess_amt,
				t.postprocess_ct,
				t.postprocess_amt,
				(select l.lu_val from luv l where l.lu_id = t.tracking_status_id) tracking_status_code,
				t.tracking_status_id,
				t.input_file_name,
				t.tracking_reason
			from EMPL_GRP_ACTV_PROGRESS_TRACKER t
			""";
    private static String updateGroupActivityProgressionTrackerStatus = """
            UPDATE EMPL_GRP_ACTV_PROGRESS_TRACKER
			SET tracking_status_id = ?,
				postprocess_ct = ?,
				postprocess_amt = ?,
				tracking_reason = ?,
				MODIFY_TS = SYSDATE,
				MODIFY_USR = ?
		    WHERE empl_grp_apt_id = ?
            """;

    private final DataSource dataSource;

    public GroupActivityProgressTrackerDAOJdbc(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @PostConstruct
    private void initialize() {
        setDataSource(dataSource);
    }

    @Override
    public Collection<GroupActivityProgressTracker> getGroupActivityProgressionTracker(String pGroupNo, String pInputFileName, java.sql.Date pBatchDate, Integer trackingStatusId) {
        JdbcTemplate template = getJdbcTemplate();
        StringBuffer lQuery = new StringBuffer();
        ArrayList<Object> lParameters = new ArrayList<Object>();
        ArrayList<Integer> lTypes = new ArrayList<Integer>();

        lQuery.append(selectGroupActivityProgressionTracker);


        lParameters.add(trackingStatusId);
        lTypes.add(Types.INTEGER);
        lQuery.append(" Where tracking_status_id = ? ");


        if (pGroupNo != null) {
            lParameters.add(pGroupNo);
            lTypes.add(Types.VARCHAR);
            lQuery.append(" AND grp_no = ? ");
        }

        if (pInputFileName != null && !pInputFileName.isEmpty()) {
            lParameters.add(pInputFileName);
            lTypes.add(Types.VARCHAR);
            lQuery.append(" AND input_file_name = ? ");
        }

        if (pBatchDate != null) {
            lParameters.add(pBatchDate);
            lTypes.add(Types.DATE);
            lQuery.append(" AND batch_dt = ? ");
        }

        lQuery.append(" order by t.grp_name asc, t.batch_dt desc ");
        // Convert the parameter arraylists to arrays.
        Object params[] = new Object[lParameters.size()];
        lParameters.toArray(params);

        int types[] = new int[lTypes.size()];
        for (int j = 0; j < lTypes.size(); j++) {
            types[j] = lTypes.get(j);
        }

        Collection<GroupActivityProgressTracker> lGroupActivityProgressTrackers = (Collection<GroupActivityProgressTracker>) template.query(
                lQuery.toString(), params, types, new groupActivityProgressionTrackerMapper());

        return lGroupActivityProgressTrackers;
    }

    @Override
    public void updateGroupActivityProgressionTrackerStatus(int uid, int pTrackingStatusID, Integer postprocessCount, Integer postprocessAmount, String trackingReason, String pUserID) throws BPMException, DataAccessException {
        JdbcTemplate template = getJdbcTemplate();

        Object params[] = new Object[]
                {
                        pTrackingStatusID,
                        postprocessCount,
                        postprocessAmount,
                        trackingReason,
                        pUserID,
                        uid
                };

        int types[] = new int[]{
                Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.VARCHAR, Types.VARCHAR, Types.INTEGER};

        template.update(updateGroupActivityProgressionTrackerStatus, params, types);

        return;
    }


    private static final class groupActivityProgressionTrackerMapper implements RowMapper {
        public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
            GroupActivityProgressTracker lGroupActivityProgressTracker = new GroupActivityProgressTracker();
            rowNum++;

            lGroupActivityProgressTracker.setUid(rs.getInt("empl_grp_apt_id"));
            lGroupActivityProgressTracker.setProgramID(rs.getInt("biz_pgm_id"));
            lGroupActivityProgressTracker.setGroupNo(rs.getString("grp_no"));
            lGroupActivityProgressTracker.setGroupName(rs.getString("grp_name"));
            lGroupActivityProgressTracker.setBatchDate(rs.getDate("batch_dt"));
            lGroupActivityProgressTracker.setPreprocessCount(rs.getInt("preprocess_ct"));
            lGroupActivityProgressTracker.setPostprocessCount(rs.getInt("postprocess_ct"));
            lGroupActivityProgressTracker.setPreprocessAmount(rs.getInt("preprocess_amt"));
            lGroupActivityProgressTracker.setPostprocessAmount(rs.getInt("postprocess_amt"));
            lGroupActivityProgressTracker.setTrackingStatusCode(rs.getString("tracking_status_code"));
            lGroupActivityProgressTracker.setTrackingStatusID(rs.getInt("tracking_status_id"));
            lGroupActivityProgressTracker.setInputFileName(rs.getString("input_file_name"));
            lGroupActivityProgressTracker.setTrackingReason(rs.getString("tracking_reason"));
            lGroupActivityProgressTracker.setRowNumber(rowNum);


            return lGroupActivityProgressTracker;
        }
    }

}
