package com.healthpartners.app.bpm.dao;

import com.healthpartners.app.bpm.dto.IncentivePackageRuleGroup;
import com.healthpartners.app.bpm.exception.BPMException;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import jakarta.annotation.PostConstruct;
import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;

/**
 * @author jxbourbour
 */
@Repository
@Transactional(timeout = 300, rollbackFor = {DataAccessException.class, BPMException.class})
public class IncentivePackageRuleDAOJdbc extends JdbcDaoSupport implements IncentivePackageRuleDAO {
	// @formatter:off
	private static final String selectIncentivePackageRuleGroups =
			"SELECT INCNTV_OPTN_PKG_RULE_GRP_ID, INCNTV_OPTN_PKG_RULE_GRP_NM, INCNTV_OPTN_PKG_RULE_GRP_INFO, INCNTV_OPTN_PKG_RULE_GRP_DESC, EFF_DT, END_DT \t\t\t\n" +
					"FROM incntv_optn_pkg_rule_grp ipg    \n" +
					"WHERE 1 = 1 ";

	// @formatter:on

	private final DataSource dataSource;

	public IncentivePackageRuleDAOJdbc(DataSource dataSource) {
		this.dataSource = dataSource;
	}

	@PostConstruct
	private void initialize() {
		setDataSource(dataSource);
	}

    /**
     * Retrieve a list of all the participation group definitions.
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Override
    public Collection<IncentivePackageRuleGroup> getIncentivePackageRuleGroups(Integer pProgramID) throws BPMException, DataAccessException {
        final ArrayList<IncentivePackageRuleGroup> lIncentivePackageRuleGroupList = new ArrayList<IncentivePackageRuleGroup>();

        JdbcTemplate template = getJdbcTemplate();
        Object[] params = new Object[]{};
        int[] types = new int[]{};

        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectIncentivePackageRuleGroups);

        if (pProgramID > 0) {
            lQuery.append(" AND ipg.EFF_DT <= (SELECT biz.eff_dt FROM business_program biz WHERE biz.biz_pgm_id = ");
            lQuery.append(pProgramID);
            lQuery.append(" ) ");
            lQuery.append(" AND ipg.END_DT >= (SELECT biz.pgm_end_dt FROM business_program biz WHERE biz.biz_pgm_id = ");
            lQuery.append(pProgramID);
            lQuery.append(" ) ");
        }

        lQuery.append("order by  INCNTV_OPTN_PKG_RULE_GRP_NM asc");

        template.query(lQuery.toString(), params, types, new RowCallbackHandler() {
            public void processRow(ResultSet rs) throws SQLException {
                IncentivePackageRuleGroup lIncentivePackageRuleGroup = new IncentivePackageRuleGroup();

                lIncentivePackageRuleGroup.setIncentivePackageRuleGroupID(rs.getInt("incntv_optn_pkg_rule_grp_id"));
                lIncentivePackageRuleGroup.setIncentivePackageRuleGroupName(rs.getString("incntv_optn_pkg_rule_grp_nm"));
                lIncentivePackageRuleGroup.setIncentivePackageRuleGroupInfo(rs.getString("incntv_optn_pkg_rule_grp_info"));
                lIncentivePackageRuleGroup.setIncentivePackageRuleGroupDesc(rs.getString("incntv_optn_pkg_rule_grp_desc"));
                lIncentivePackageRuleGroup.setEffectiveDate(rs.getDate("EFF_DT"));
                lIncentivePackageRuleGroup.setEndDate(rs.getDate("END_DT"));
                //lIncentivePackageRuleGroup.setUsed("Y".equals(rs.getString("used_flg")));

                lIncentivePackageRuleGroupList.add(lIncentivePackageRuleGroup);
            }
        });

        return lIncentivePackageRuleGroupList;
    }
}
