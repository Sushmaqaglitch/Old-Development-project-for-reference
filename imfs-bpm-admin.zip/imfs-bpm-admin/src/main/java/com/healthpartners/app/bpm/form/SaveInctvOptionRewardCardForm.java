package com.healthpartners.app.bpm.form;

public class SaveInctvOptionRewardCardForm extends BaseForm {

	static final long serialVersionUID = 0L;
	
	private String actionType;
		
	private Integer incentiveOptionRewardCardID;
	private Integer rewardCardID;
	private Integer rewardCardFeeID;	
	private Integer rewardEmbossedLineID;
	private Integer rewardCarrierMessageID;
	private Integer rewardTransactionMessageID;
	private String  incentiveOptionRewardCardName;
	private String  incentiveOptionRewardCardDesc;
	private Integer rewardCardClientContactID;
	private String	effectiveDate;
	private String  endDate;

	private String previousActionType;

	public SaveInctvOptionRewardCardForm() {
		super();
	}

	public String getActionType() {
		return actionType;
	}

	public void setActionType(String actionType) {
		this.actionType = actionType;
	}

	public Integer getIncentiveOptionRewardCardID() {
		return incentiveOptionRewardCardID;
	}

	public void setIncentiveOptionRewardCardID(Integer incentiveOptionRewardCardID) {
		this.incentiveOptionRewardCardID = incentiveOptionRewardCardID;
	}

	public Integer getRewardCardID() {
		return rewardCardID;
	}

	public void setRewardCardID(Integer rewardCardID) {
		this.rewardCardID = rewardCardID;
	}

	public Integer getRewardCardFeeID() {
		return rewardCardFeeID;
	}

	public void setRewardCardFeeID(Integer rewardCardFeeID) {
		this.rewardCardFeeID = rewardCardFeeID;
	}

	public Integer getRewardEmbossedLineID() {
		return rewardEmbossedLineID;
	}

	public void setRewardEmbossedLineID(Integer rewardEmbossedLineID) {
		this.rewardEmbossedLineID = rewardEmbossedLineID;
	}

	public Integer getRewardCarrierMessageID() {
		return rewardCarrierMessageID;
	}

	public void setRewardCarrierMessageID(Integer rewardCarrierMessageID) {
		this.rewardCarrierMessageID = rewardCarrierMessageID;
	}

	public Integer getRewardTransactionMessageID() {
		return rewardTransactionMessageID;
	}

	public void setRewardTransactionMessageID(Integer rewardTransactionMessageID) {
		this.rewardTransactionMessageID = rewardTransactionMessageID;
	}

	public String getIncentiveOptionRewardCardName() {
		return incentiveOptionRewardCardName;
	}

	public void setIncentiveOptionRewardCardName(
			String incentiveOptionRewardCardName) {
		this.incentiveOptionRewardCardName = incentiveOptionRewardCardName;
	}

	public String getIncentiveOptionRewardCardDesc() {
		return incentiveOptionRewardCardDesc;
	}

	public void setIncentiveOptionRewardCardDesc(
			String incentiveOptionRewardCardDesc) {
		this.incentiveOptionRewardCardDesc = incentiveOptionRewardCardDesc;
	}

	public String getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(String effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public final Integer getRewardCardClientContactID() {
		return rewardCardClientContactID;
	}

	public final void setRewardCardClientContactID(Integer rewardCardClientContactID) {
		this.rewardCardClientContactID = rewardCardClientContactID;
	}

	public String getPreviousActionType() {
		return previousActionType;
	}

	public void setPreviousActionType(String previousActionType) {
		this.previousActionType = previousActionType;
	}
}
