package com.healthpartners.app.bpm.dao;

import com.healthpartners.service.bpm.dto.QualificationOverride;
import org.springframework.dao.DataAccessException;

import java.util.Calendar;
import java.util.Collection;

public interface QualificationOverrideDAO {

    int deleteExemptionsForBizProgram(Integer businessProgramID) throws DataAccessException;

    int deleteQualificationOverrideForIncentive(Integer pProgramIncentiveOptionID) throws DataAccessException;

    Collection<QualificationOverride> getAllQualificationOverrides(Integer personID, Integer businessProgramID) throws DataAccessException;

    public long insertManualExemptionForMember(Integer personDemographicsID, Integer personID,
                                               Integer businessProgramID, Integer contractNo, String exemptionReason,
                                               Calendar issueDate, String approverUser, String userId, Integer pProgramIncentiveOptionID)
            throws DataAccessException;
}
