/**
 * 
 */
package com.healthpartners.app.bpm.form;

/**
 * @author jxbourbour
 *
 */
public class GroupLookupForm extends BaseForm {

	private String groupStartDate;
	private String groupNumber;
	private String groupName;
	private Integer groupID;
    private String whichList;
	

	public GroupLookupForm() 
	{
		super();
	}

	public String getGroupNumber() {
		return groupNumber;
	}


	public void setGroupNumber(String groupNumber) {
		this.groupNumber = groupNumber;
	}


	public String getGroupStartDate() {
		return groupStartDate;
	}


	public void setGroupStartDate(String groupStartDate) {
		this.groupStartDate = groupStartDate;
	}


	public final String getGroupName() {
		return groupName;
	}


	public final void setGroupName(String groupName) {
		this.groupName = groupName;
	}


	public final Integer getGroupID() {
		return groupID;
	}


	public final void setGroupID(Integer groupID) {
		this.groupID = groupID;
	}


	public final String getWhichList() {
		return whichList;
	}


	public final void setWhichList(String whichList) {
		this.whichList = whichList;
	}	
}
