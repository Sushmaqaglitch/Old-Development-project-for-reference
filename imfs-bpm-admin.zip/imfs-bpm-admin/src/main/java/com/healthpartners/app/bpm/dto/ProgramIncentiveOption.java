package com.healthpartners.app.bpm.dto;

import java.io.Serializable;
import java.util.ArrayList;

public class ProgramIncentiveOption implements Serializable
{	
	static final long serialVersionUID = 0L;
	
	private IncentiveOption incentiveOption;
	
	private Integer programIncentiveOptionID;
	private Integer businessProgramID;
	private String additionalInfo;
	private String incentiveOptionInfo;
	private Integer incentiveOptionStatusCodeID;
	private String incentiveOptionStatusCode;
	private String incentiveOptionStatusCodeDesc;
	private java.sql.Date effectiveDate;
	private java.sql.Date endDate;
	private java.sql.Date activationDate;
	private java.sql.Date deliveryDate;
	private Integer incentiveReportNameCodeID;
	private String incentiveReportNameCode;
	private String incentiveReportNameCodeDesc;
	private Integer incentiveFulfillmentRoutingCodeID;
	private String incentiveFulfillmentCode;
	private String incentiveFulfillmentCodeDesc;
	private Integer incentedStatusTypeCodeID;
	private String incentedStatusTypeCode;
	private String incentedStatusTypeDesc;
	private String participantCap;
	private String familyCap;
	private String unitTypeDesc;
	private String deliveryInfo;
	private java.sql.Date enrollmentDeadlineDate;
	private java.sql.Date completionDeadlineDate;
	private Integer incentiveRuleTypeCodeID;
	private String incentiveRuleTypeCode;
	private String incentiveRuleTypeCodeDesc;
	
	private Integer participationGroupID;
	private String participationGroupName;
	private String participationGroupInfo;
	
	private Integer packageRuleGroupID;
	private String packageRuleGroupName;
	
	private Integer groupID;
		
	ArrayList<ActivityIncentiveRequirement> activityIncentiveRequirements; 
	ArrayList<ActivityIncentiveRequirement> activityIncentiveRequirementsToRemove; 
	
	ArrayList<ProgramContributionTier> programContributionTiers;
	ProgramContributionTier programContributionTier;
	
	ArrayList<ProgramContributionGrid> programContributionGrids;
	ProgramContributionGrid programContributionGrid;
	
	
	private Integer incentiveOptionRewardCardID;
	private String incentiveOptionRewardCardName;
	private Integer rewardCardID;
	IncentiveOptionRewardCard incentiveOptionRewardCard;

	private Integer runFrequencyID;
	private String runFrequencyValue;
	
	private boolean fulfillRoutingTypeIntelispend;
	
	private Integer tierContributionRequiredLuvID;
	private Integer tierContributionNotRequiredLuvID;
	private String tierContributionRequiredDesc;
	private String tierContributionNotRequiredDesc;
	
	boolean programContributionTierUsed;
	
	boolean programContributionGridUsed;
	
	private String activityCompletionPeriod;
	
	private java.sql.Date newHireDate;
	
	private Integer unitTypeCodeID;
	
	private String unitTypeCodeDesc;
	
	private ArrayList<ProgramCheckmarkIncentiveOption> programCheckmarkIncentiveOptions;
	
	private Integer deliveryInfoID;
	private String deliveryInfoValue;

	private Integer sortOrder;
	
    public ProgramIncentiveOption()
    {
    	super();
    }
    

	public final String getAdditionalInfo() {
		return additionalInfo;
	}

	public final void setAdditionalInfo(String additionalInfo) {
		this.additionalInfo = additionalInfo;
	}

	public final Integer getBusinessProgramID() {
		return businessProgramID;
	}

	public final void setBusinessProgramID(Integer businessProgramID) {
		this.businessProgramID = businessProgramID;
	}		

	public final IncentiveOption getIncentiveOption() {
		return incentiveOption;
	}

	public final void setIncentiveOption(IncentiveOption incentiveOption) {
		this.incentiveOption = incentiveOption;
	}

	public final String getIncentiveOptionInfo() {
		return incentiveOptionInfo;
	}

	public final void setIncentiveOptionInfo(String incentiveOptionInfo) {
		this.incentiveOptionInfo = incentiveOptionInfo;
	}

	public final String getIncentiveOptionStatusCode() {
		return incentiveOptionStatusCode;
	}

	public final void setIncentiveOptionStatusCode(String incentiveOptionStatusCode) {
		this.incentiveOptionStatusCode = incentiveOptionStatusCode;
	}

	public final String getIncentiveOptionStatusCodeDesc() {
		return incentiveOptionStatusCodeDesc;
	}

	public final void setIncentiveOptionStatusCodeDesc(
			String incentiveOptionStatusCodeDesc) {
		this.incentiveOptionStatusCodeDesc = incentiveOptionStatusCodeDesc;
	}

	public final Integer getIncentiveOptionStatusCodeID() {
		return incentiveOptionStatusCodeID;
	}

	public final void setIncentiveOptionStatusCodeID(
			Integer incentiveOptionStatusCodeID) {
		this.incentiveOptionStatusCodeID = incentiveOptionStatusCodeID;
	}

	public final java.sql.Date getActivationDate() {
		return activationDate;
	}

	public final void setActivationDate(java.sql.Date activationDate) {
		this.activationDate = activationDate;
	}

	public final java.sql.Date getDeliveryDate() {
		return deliveryDate;
	}

	public final void setDeliveryDate(java.sql.Date deliveryDate) {
		this.deliveryDate = deliveryDate;
	}
	
	

	public Integer getIncentiveReportNameCodeID() {
		return incentiveReportNameCodeID;
	}


	public void setIncentiveReportNameCodeID(Integer incentiveReportNameCodeID) {
		this.incentiveReportNameCodeID = incentiveReportNameCodeID;
	}


	public String getIncentiveReportNameCode() {
		return incentiveReportNameCode;
	}


	public void setIncentiveReportNameCode(String incentiveReportNameCode) {
		this.incentiveReportNameCode = incentiveReportNameCode;
	}


	public String getIncentiveReportNameCodeDesc() {
		return incentiveReportNameCodeDesc;
	}


	public void setIncentiveReportNameCodeDesc(String incentiveReportNameCodeDesc) {
		this.incentiveReportNameCodeDesc = incentiveReportNameCodeDesc;
	}


	public final java.sql.Date getEffectiveDate() {
		return effectiveDate;
	}

	public final void setEffectiveDate(java.sql.Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public final java.sql.Date getEndDate() {
		return endDate;
	}

	public final void setEndDate(java.sql.Date endDate) {
		this.endDate = endDate;
	}  
	
	
	public String getIncentiveFulfillmentCode() {
		return incentiveFulfillmentCode;
	}


	public void setIncentiveFulfillmentCode(String incentiveFulfillmentCode) {
		this.incentiveFulfillmentCode = incentiveFulfillmentCode;
	}


	public String getIncentiveFulfillmentCodeDesc() {
		return incentiveFulfillmentCodeDesc;
	}


	public void setIncentiveFulfillmentCodeDesc(String incentiveFulfillmentCodeDesc) {
		this.incentiveFulfillmentCodeDesc = incentiveFulfillmentCodeDesc;
	}


	public Integer getIncentiveFulfillmentRoutingCodeID() {
		return incentiveFulfillmentRoutingCodeID;
	}


	public void setIncentiveFulfillmentRoutingCodeID(
			Integer incentiveFulfillmentRoutingCodeID) {
		this.incentiveFulfillmentRoutingCodeID = incentiveFulfillmentRoutingCodeID;
	}


	public Integer getIncentedStatusTypeCodeID() {
		return incentedStatusTypeCodeID;
	}


	public void setIncentedStatusTypeCodeID(Integer incentedStatusTypeCodeID) {
		this.incentedStatusTypeCodeID = incentedStatusTypeCodeID;
	}


	public String getIncentedStatusTypeCode() {
		return incentedStatusTypeCode;
	}


	public void setIncentedStatusTypeCode(String incentedStatusTypeCode) {
		this.incentedStatusTypeCode = incentedStatusTypeCode;
	}


	public String getIncentedStatusTypeDesc() {
		return incentedStatusTypeDesc;
	}


	public void setIncentedStatusTypeDesc(String incentedStatusTypeDesc) {
		this.incentedStatusTypeDesc = incentedStatusTypeDesc;
	}

	

	public String getParticipantCap() {
		return participantCap;
	}


	public void setParticipantCap(String participantCap) {
		this.participantCap = participantCap;
	}


	public String getFamilyCap() {
		return familyCap;
	}


	public void setFamilyCap(String familyCap) {
		this.familyCap = familyCap;
	}


	public ArrayList<ActivityIncentiveRequirement> getActivityIncentiveRequirements() {
		return activityIncentiveRequirements;
	}


	public void setActivityIncentiveRequirements(
			ArrayList<ActivityIncentiveRequirement> activityIncentiveRequirements) {
		this.activityIncentiveRequirements = activityIncentiveRequirements;
	}

	

	public ArrayList<ActivityIncentiveRequirement> getActivityIncentiveRequirementsToRemove() {
		return activityIncentiveRequirementsToRemove;
	}


	public void setActivityIncentiveRequirementsToRemove(
			ArrayList<ActivityIncentiveRequirement> activityIncentiveRequirementsToRemove) {
		this.activityIncentiveRequirementsToRemove = activityIncentiveRequirementsToRemove;
	}

	
	
	public ArrayList<ProgramContributionTier> getProgramContributionTiers() {
		return programContributionTiers;
	}


	public void setProgramContributionTiers(
			ArrayList<ProgramContributionTier> programContributionTiers) {
		this.programContributionTiers = programContributionTiers;
	}

	

	public ProgramContributionTier getProgramContributionTier() {
		return programContributionTier;
	}


	public void setProgramContributionTier(
			ProgramContributionTier programContributionTier) {
		this.programContributionTier = programContributionTier;
	}

	

	public ArrayList<ProgramContributionGrid> getProgramContributionGrids() {
		return programContributionGrids;
	}


	public void setProgramContributionGrids(
			ArrayList<ProgramContributionGrid> programContributionGrids) {
		this.programContributionGrids = programContributionGrids;
	}


	public ProgramContributionGrid getProgramContributionGrid() {
		return programContributionGrid;
	}


	public void setProgramContributionGrid(
			ProgramContributionGrid programContributionGrid) {
		this.programContributionGrid = programContributionGrid;
	}


	public String getUnitTypeDesc() {
		return unitTypeDesc;
	}


	public void setUnitTypeDesc(String unitTypeDesc) {
		this.unitTypeDesc = unitTypeDesc;
	}


	public String getDeliveryInfo() {
		return deliveryInfo;
	}


	public void setDeliveryInfo(String deliveryInfo) {
		this.deliveryInfo = deliveryInfo;
	}


	public java.sql.Date getEnrollmentDeadlineDate() {
		return enrollmentDeadlineDate;
	}


	public void setEnrollmentDeadlineDate(java.sql.Date enrollmentDeadlineDate) {
		this.enrollmentDeadlineDate = enrollmentDeadlineDate;
	}


	public java.sql.Date getCompletionDeadlineDate() {
		return completionDeadlineDate;
	}


	public void setCompletionDeadlineDate(java.sql.Date completionDeadlineDate) {
		this.completionDeadlineDate = completionDeadlineDate;
	}


	public final Integer getIncentiveRuleTypeCodeID() {
		return incentiveRuleTypeCodeID;
	}


	public final void setIncentiveRuleTypeCodeID(Integer incentiveRuleTypeCodeID) {
		this.incentiveRuleTypeCodeID = incentiveRuleTypeCodeID;
	}


	public final String getIncentiveRuleTypeCode() {
		return incentiveRuleTypeCode;
	}


	public final void setIncentiveRuleTypeCode(String incentiveRuleTypeCode) {
		this.incentiveRuleTypeCode = incentiveRuleTypeCode;
	}


	public final String getIncentiveRuleTypeCodeDesc() {
		return incentiveRuleTypeCodeDesc;
	}


	public final void setIncentiveRuleTypeCodeDesc(String incentiveRuleTypeCodeDesc) {
		this.incentiveRuleTypeCodeDesc = incentiveRuleTypeCodeDesc;
	}


	public Integer getParticipationGroupID() {
		return participationGroupID;
	}


	public void setParticipationGroupID(Integer participationGroupID) {
		this.participationGroupID = participationGroupID;
	}


	public String getParticipationGroupName() {
		return participationGroupName;
	}


	public void setParticipationGroupName(String participationGroupName) {
		this.participationGroupName = participationGroupName;
	}


	public Integer getIncentiveOptionRewardCardID() {
		return incentiveOptionRewardCardID;
	}


	public void setIncentiveOptionRewardCardID(Integer incentiveOptionRewardCardID) {
		this.incentiveOptionRewardCardID = incentiveOptionRewardCardID;
	}
	
	

	public String getIncentiveOptionRewardCardName() {
		return incentiveOptionRewardCardName;
	}


	public void setIncentiveOptionRewardCardName(
			String incentiveOptionRewardCardName) {
		this.incentiveOptionRewardCardName = incentiveOptionRewardCardName;
	}
	
	


	public Integer getRewardCardID() {
		return rewardCardID;
	}


	public void setRewardCardID(Integer rewardCardID) {
		this.rewardCardID = rewardCardID;
	}


	public IncentiveOptionRewardCard getIncentiveOptionRewardCard() {
		return incentiveOptionRewardCard;
	}


	public void setIncentiveOptionRewardCard(
			IncentiveOptionRewardCard incentiveOptionRewardCard) {
		this.incentiveOptionRewardCard = incentiveOptionRewardCard;
	}


	public Integer getRunFrequencyID() {
		return runFrequencyID;
	}


	public void setRunFrequencyID(Integer runFrequencyID) {
		this.runFrequencyID = runFrequencyID;
	}


	public String getRunFrequencyValue() {
		return runFrequencyValue;
	}


	public void setRunFrequencyValue(String runFrequencyValue) {
		this.runFrequencyValue = runFrequencyValue;
	}


	public boolean isFulfillRoutingTypeIntelispend() {
		return fulfillRoutingTypeIntelispend;
	}


	public void setFulfillRoutingTypeIntelispend(
			boolean fulfillRoutingTypeIntelispend) {
		this.fulfillRoutingTypeIntelispend = fulfillRoutingTypeIntelispend;
	}


	public Integer getTierContributionRequiredLuvID() {
		return tierContributionRequiredLuvID;
	}


	public void setTierContributionRequiredLuvID(
			Integer tierContributionRequiredLuvID) {
		this.tierContributionRequiredLuvID = tierContributionRequiredLuvID;
	}


	public Integer getTierContributionNotRequiredLuvID() {
		return tierContributionNotRequiredLuvID;
	}


	public void setTierContributionNotRequiredLuvID(
			Integer tierContributionNotRequiredLuvID) {
		this.tierContributionNotRequiredLuvID = tierContributionNotRequiredLuvID;
	}


	public String getTierContributionRequiredDesc() {
		return tierContributionRequiredDesc;
	}


	public void setTierContributionRequiredDesc(String tierContributionRequiredDesc) {
		this.tierContributionRequiredDesc = tierContributionRequiredDesc;
	}


	public String getTierContributionNotRequiredDesc() {
		return tierContributionNotRequiredDesc;
	}


	public void setTierContributionNotRequiredDesc(
			String tierContributionNotRequiredDesc) {
		this.tierContributionNotRequiredDesc = tierContributionNotRequiredDesc;
	}


	public boolean isProgramContributionTierUsed() {
		return programContributionTierUsed;
	}


	public void setProgramContributionTierUsed(boolean programContributionTierUsed) {
		this.programContributionTierUsed = programContributionTierUsed;
	}

	
	
	
	public boolean isProgramContributionGridUsed() {
		return programContributionGridUsed;
	}


	public void setProgramContributionGridUsed(boolean programContributionGridUsed) {
		this.programContributionGridUsed = programContributionGridUsed;
	}


	public Integer getGroupID() {
		return groupID;
	}


	public void setGroupID(Integer groupID) {
		this.groupID = groupID;
	}


	public String getActivityCompletionPeriod() {
		return activityCompletionPeriod;
	}


	public void setActivityCompletionPeriod(String activityCompletionPeriod) {
		this.activityCompletionPeriod = activityCompletionPeriod;
	}
	
	public Integer getProgramIncentiveOptionID() {
		return programIncentiveOptionID;
	}

	public void setProgramIncentiveOptionID(Integer programIncentiveOptionID) {
		this.programIncentiveOptionID = programIncentiveOptionID;
	}


	public ArrayList<ProgramCheckmarkIncentiveOption> getProgramCheckmarkIncentiveOptions() {
		return programCheckmarkIncentiveOptions;
	}


	public void setProgramCheckmarkIncentiveOptions(
			ArrayList<ProgramCheckmarkIncentiveOption> programCheckmarkIncentiveOptions) {
		this.programCheckmarkIncentiveOptions = programCheckmarkIncentiveOptions;
	}


	public java.sql.Date getNewHireDate() {
		return newHireDate;
	}


	public void setNewHireDate(java.sql.Date newHireDate) {
		this.newHireDate = newHireDate;
	}

	


	public Integer getUnitTypeCodeID() {
		return unitTypeCodeID;
	}


	public void setUnitTypeCodeID(Integer unitTypeCodeID) {
		this.unitTypeCodeID = unitTypeCodeID;
	}


	public String getUnitTypeCodeDesc() {
		return unitTypeCodeDesc;
	}


	public void setUnitTypeCodeDesc(String unitTypeCodeDesc) {
		this.unitTypeCodeDesc = unitTypeCodeDesc;
	}


	public final Integer getPackageRuleGroupID() {
		return packageRuleGroupID;
	}


	public final void setPackageRuleGroupID(Integer packageRuleGroupID) {
		this.packageRuleGroupID = packageRuleGroupID;
	}


	public final String getPackageRuleGroupName() {
		return packageRuleGroupName;
	}


	public final void setPackageRuleGroupName(String packageRuleGroupName) {
		this.packageRuleGroupName = packageRuleGroupName;
	}


	public final Integer getDeliveryInfoID() {
		return deliveryInfoID;
	}


	public final void setDeliveryInfoID(Integer deliveryInfoID) {
		this.deliveryInfoID = deliveryInfoID;
	}


	public final String getDeliveryInfoValue() {
		return deliveryInfoValue;
	}


	public final void setDeliveryInfoValue(String deliveryInfoValue) {
		this.deliveryInfoValue = deliveryInfoValue;
	}


	public String getParticipationGroupInfo() {
		return participationGroupInfo;
	}


	public void setParticipationGroupInfo(String participationGroupInfo) {
		this.participationGroupInfo = participationGroupInfo;
	}

	public Integer getSortOrder() {
		return sortOrder;
	}

	public void setSortOrder(Integer sortOrder) {
		this.sortOrder = sortOrder;
	}
}
