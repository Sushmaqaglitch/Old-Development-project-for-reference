package com.healthpartners.app.bpm.form;

public class ProgramChangeLogForm extends BaseForm {
	private Integer programID;
    private Integer groupID;
    private String groupNumber;
    private String changeText;

    public ProgramChangeLogForm() {
        super();
    }


    public Integer getProgramID() {
        return programID;
    }

    public void setProgramID(Integer programID) {
        this.programID = programID;
    }

    public String getChangeText() {
        return changeText;
    }

    public void setChangeText(String changeText) {
        this.changeText = changeText;
    }

    public Integer getGroupID() {
        return groupID;
    }

    public void setGroupID(Integer groupID) {
        this.groupID = groupID;
    }

    public String getGroupNumber() {
        return groupNumber;
    }

    public void setGroupNumber(String groupNumber) {
        this.groupNumber = groupNumber;
    }
}
