package com.healthpartners.app.bpm.dto;

import java.io.Serializable;

public class CollectionActivity implements Serializable {
    static final long serialVersionUID = 0L;

    private Integer collectionID;
    private Integer activityID;
    private Integer activityTypeID;
    private String activityName;
    private String activityTypeCode;
    private String sourceActivityID;

    public CollectionActivity() {
        super();
    }

    public Integer getCollectionID() {
        return collectionID;
    }

    public void setCollectionID(Integer collectionID) {
        this.collectionID = collectionID;
    }

    public Integer getActivityID() {
        return activityID;
    }

    public void setActivityID(Integer activityID) {
        this.activityID = activityID;
    }

    public Integer getActivityTypeID() {
        return activityTypeID;
    }

    public void setActivityTypeID(Integer activityTypeID) {
        this.activityTypeID = activityTypeID;
    }

    public String getActivityName() {
        return activityName;
    }

    public void setActivityName(String activityName) {
        this.activityName = activityName;
    }

    public String getActivityTypeCode() {
        return activityTypeCode;
    }

    public void setActivityTypeCode(String activityTypeName) {
        this.activityTypeCode = activityTypeName;
    }

    public String getSourceActivityID() {
        return sourceActivityID;
    }

    public void setSourceActivityID(String sourceActivityID) {
        this.sourceActivityID = sourceActivityID;
    }

}
