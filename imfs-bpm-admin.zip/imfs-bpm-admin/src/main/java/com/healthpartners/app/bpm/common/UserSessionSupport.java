package com.healthpartners.app.bpm.common;

import com.healthpartners.app.bpm.iface.BusinessProgramService;
import com.healthpartners.app.bpm.session.UserSession;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@Component
public class UserSessionSupport {

    protected final Log logger = LogFactory.getLog(getClass());

    private final BusinessProgramService businessProgramService;

    public UserSessionSupport(BusinessProgramService businessProgramService) {
        this.businessProgramService = businessProgramService;
    }

    public HttpSession getSession() {
        HttpServletRequest request = getCurrentHttpServletRequest();
        HttpSession session = request.getSession(false);
        if (session == null) {
            session = request.getSession(true);
        }

        return session;
    }

    public UserSession getUserSession() {
        HttpServletRequest request = getCurrentHttpServletRequest();
        HttpSession session = getSession();
        UserSession sessionBean = (UserSession) session.getAttribute("scopedTarget.userSession");
        if (sessionBean == null) {
            sessionBean = new UserSession();
            session.setAttribute("scopedTarget.userSession", sessionBean);
        }

        return sessionBean;
    }

    public UserSession setupUserSession() {
        HttpServletRequest request = getCurrentHttpServletRequest();
        UserSession sessionBean = getUserSession();

        try {
            String lDatabaseEnvironment = businessProgramService.getDatabaseEnvironment().getLuvDesc();
            sessionBean.setDatabaseEnvironment(lDatabaseEnvironment);
            request.setAttribute("databaseEnvironment", lDatabaseEnvironment);
        } catch (Exception e) {
            logger.error(e);
        }

        return sessionBean;
    }

    public String getAuthenticatedUsername() {
        String userName = null;
        Authentication auth = SecurityContextHolder.getContext()
                .getAuthentication();
        if (auth != null) {
            userName = auth.getName();
        }

        return userName;
    }

    private HttpServletRequest getCurrentHttpServletRequest() {
        RequestAttributes requestAttributes = RequestContextHolder.currentRequestAttributes();
        if (requestAttributes instanceof ServletRequestAttributes) {
            HttpServletRequest request = ((ServletRequestAttributes)requestAttributes).getRequest();
            return request;
        }
        return null;
    }
}
