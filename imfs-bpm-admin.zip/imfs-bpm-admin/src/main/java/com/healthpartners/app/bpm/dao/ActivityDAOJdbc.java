package com.healthpartners.app.bpm.dao;

import com.healthpartners.app.bpm.common.BPMAdminConstants;
import com.healthpartners.app.bpm.common.BPMAdminUtils;
import com.healthpartners.app.bpm.dto.*;
import com.healthpartners.app.bpm.exception.BPMException;
import jakarta.annotation.PostConstruct;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.jdbc.support.incrementer.DataFieldMaxValueIncrementer;
import org.springframework.jdbc.support.incrementer.OracleSequenceMaxValueIncrementer;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.sql.DataSource;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.text.NumberFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collection;

@Transactional(timeout = 300, rollbackFor = {DataAccessException.class, BPMException.class})
@Repository
public class ActivityDAOJdbc extends JdbcDaoSupport implements ActivityDAO {
    // @formatter:off
    private static final String selectActivities = "SELECT\n" +
            "distinct\n" +
            "count(biz.actv_id) count_used,\n" +
            "types.actv_id,\n" +
            "types.actv_tp_cd_id,\n" +
            "types.host_srce,\n" +
            "types.completion_duration,\n" +
            "types.actv_nm,\n" +
            "types.actv_desc,\n" +
            "types.actv_link,\n" +
            "types.actv_cost,\n" +
            "types.insert_ts,\n" +
            "types.insert_usr,\n" +
            "types.srce_actv_id,\n" +
            "l.lu_val,\n" +
            "l.lu_desc,\n" +
            "types.actv_eff_dt,\n" +
            "types.actv_end_dt,\n" +
            "types.insert_ts,\n" +
            "types.modify_ts,\n" +
            "types.insert_usr,\n" +
            "types.modify_usr\n" +
            "FROM activity types LEFT OUTER JOIN eligible_program_activity biz ON\n" +
            " types.actv_id = biz.actv_id LEFT OUTER JOIN luv l ON types.actv_tp_cd_id = l.lu_id";
    private static final String deleteActivity = "DELETE FROM ACTIVITY WHERE ACTV_ID = ?";
    private static final String insertActivity = "INSERT INTO ACTIVITY (ACTV_ID, ACTV_TP_CD_ID, HOST_SRCE, COMPLETION_DURATION, ACTV_NM, ACTV_DESC, ACTV_LINK, ACTV_COST, ACTV_EFF_DT, ACTV_END_DT, INSERT_TS, INSERT_USR, SRCE_ACTV_ID) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, SYSDATE, ?, ?)";
    private static final String updateActivity = "UPDATE ACTIVITY SET ACTV_TP_CD_ID = ?, HOST_SRCE = ?, COMPLETION_DURATION = ?, ACTV_NM = ?, ACTV_DESC = ?, ACTV_LINK = ?, ACTV_COST = ?, MODIFY_TS = SYSDATE, MODIFY_USR = ?, SRCE_ACTV_ID = ?, ACTV_EFF_DT = ?, ACTV_END_DT = ?  WHERE ACTV_ID = ?";
    private static final String selectEligibleActivities = "SELECT\n" +
            "elig.biz_pgm_id\n" +
            ", act.actv_id\n" +
            ", NVL(elig.cstm_actv_nm, act.actv_nm) actv_nm\n" +
            ", NVL(elig.cstm_actv_desc, act.actv_desc) actv_desc\n" +
            ", (select lu_val from luv where lu_id = act.actv_tp_cd_id) as actv_tp_cd_value\n" +
            ", (select lu_desc from luv where lu_id = act.actv_tp_cd_id) as actv_tp_cd_desc\n" +
            ", elig.auth_cd\n" +
            ", act.completion_duration\n" +
            ", elig.qualfctn_start_dt\n" +
            ", elig.qualfctn_end_dt\n" +
            ", elig.qualfctn_early_start_dt\n" +
            ", elig.qualfctn_late_end_dt\n" +
            ", elig.enroll_deadline_dt\n" +
            ",act.srce_actv_id\n" +
            ", elig.EXCLUSION_OPTN_FLG\n" +
            ", elig.incntv_ovrd_tp_cd_id incentive_override_code_id\n" +
            ", (select l.lu_val from luv l where l.lu_id = elig.incntv_ovrd_tp_cd_id) incentive_override_code\n" +
            ", cstm_actv_nm\n" +
            ", cstm_actv_desc\n" +
            "FROM\n" +
            "eligible_program_activity elig\n" +
            ", activity act\n" +
            ", business_program biz\n" +
            "WHERE elig.actv_id = act.actv_id\n" +
            "AND biz.biz_pgm_id = elig.biz_pgm_id\n" +
            "AND act.ACTV_END_DT >= biz.pgm_end_dt\n";
    private static final String selectAvailableActivities = "SELECT\n" +
            "  act.actv_id\n" +
            ", act.actv_nm\n" +
            ", act.actv_desc\n" +
            ", (select lu_val from luv where lu_id = act.actv_tp_cd_id) as actv_tp_cd_value\n" +
            ", (select lu_desc from luv where lu_id = act.actv_tp_cd_id) as actv_tp_cd_desc\n" +
            ", act.completion_duration\n" +
            ",act.srce_actv_id\n" +
            ", act.actv_tp_cd_id\n" +
            ", act.HOST_SRCE\n" +
            ", act.ACTV_LINK\n" +
            ", act.ACTV_COST\n" +
            ", act.INSERT_USR\n" +
            ", act.ACTV_EFF_DT\n" +
            ", act.ACTV_END_DT\n" +
            "FROM\n" +
            "  activity act\n" +
            "WHERE\n" +
            "trunc(SYSDATE) >= act.ACTV_EFF_DT\n" +
            "AND trunc(SYSDATE) <= act.ACTV_END_DT\n" +
            "--EV58500 not needed\n" +
            "--WHERE\n" +
            "--act.actv_id NOT IN\n" +
            "--(SELECT actv_id FROM\n" +
            "--eligible_program_activity\n" +
            "--WHERE biz_pgm_id=?)\n";
    private static final String deleteEligibleActivities = "delete from eligible_program_activity where biz_pgm_id = ? AND actv_id NOT IN \n" +
            "(SELECT distinct actv_id FROM person_program_activity_status WHERE biz_pgm_id = ? )";
    private static final String deleteProgramCheckmark = "DELETE FROM program_checkmark WHERE ";
    private static final String insertEligibleActivity = "insert into eligible_program_activity \n" +
            "(elig_pgm_actv_id, qualfctn_start_dt, qualfctn_end_dt, qualfctn_early_start_dt, qualfctn_late_end_dt, enroll_deadline_dt, auth_cd\n" +
            " , modify_ts, modify_usr, biz_pgm_id, actv_id, insert_ts, insert_usr, EXCLUSION_OPTN_FLG, incntv_ovrd_tp_cd_id, CSTM_ACTV_NM, CSTM_ACTV_DESC)\n" +
            " VALUES (?, ?, ?, ?, ?, ?, ?, SYSDATE, ?, ?, ?, SYSDATE, ?, ?, ?\n" +
            " , NVL(?, (SELECT actv_nm FROM activity WHERE actv_id = ?))\n" +
            " , NVL(?, (SELECT actv_desc FROM activity WHERE actv_id = ?))\n" +
            " )";
    private static final String selectExtendedAuthCodes =
            "select AUTH_CD, BIZ_PGM_ID, AUTH_CD_TP_ID, lu_val, EFF_DT, END_DT from biz_pgm_auth_code_extended, luv where biz_pgm_id= ? AND lu_id = AUTH_CD_TP_ID ";
    private static final String updateExtendedAuthCode =
            "UPDATE biz_pgm_auth_code_extended SET AUTH_CD = ?, AUTH_CD_TP_ID = ?, EFF_DT = ?, END_DT = ?, MODIFY_USR = ?, MODIFY_TS = SYSDATE WHERE biz_pgm_id= ? AND auth_cd = ? ";
    private static final String insertExtendedAuthCode =
            "INSERT INTO biz_pgm_auth_code_extended (extnd_auth_cd_id, AUTH_CD, BIZ_PGM_ID, AUTH_CD_TP_ID, EFF_DT, END_DT, INSERT_TS, INSERT_USR)\n" +
                    "	VALUES (extnd_auth_cd_seq.nextval, ?, ?, ?, ?, ?, SYSDATE, ?) ";
    private static final String selectCheckmarkEligibleActivities =
            "SELECT DISTINCT activity.actv_id \n" +
                    "FROM qualfctn_chkmrk_detl  checkmark_detail\n" +
                    "	, activity   \n" +
                    "WHERE checkmark_detail.qualfctn_chkmrk_id = ?\n" +
                    "	AND checkmark_detail.actv_id = activity.actv_id\n" +
                    "	AND trunc(SYSDATE) >= activity.ACTV_EFF_DT\n" +
                    "	AND trunc(SYSDATE) <= activity.ACTV_END_DT\n" +
                    "MINUS\n" +
                    "	SELECT actv_id FROM eligible_program_activity WHERE biz_pgm_id = ? ";
    private static final String updateEligibleActivity =
            "update eligible_program_activity \n" +
                    " set qualfctn_start_dt =?, qualfctn_end_dt = ?, qualfctn_early_start_dt=?, qualfctn_late_end_dt=?, enroll_deadline_dt=?,  auth_cd = ?\n" +
                    " , modify_ts=SYSDATE, modify_usr=?, EXCLUSION_OPTN_FLG = ?, incntv_ovrd_tp_cd_id = ?\n" +
                    " , CSTM_ACTV_NM = NVL(?, (SELECT actv_nm FROM activity WHERE actv_id = ?))\n" +
                    " , CSTM_ACTV_DESC = NVL(?, (SELECT actv_desc FROM activity WHERE actv_id = ?))\n" +
                    " WHERE biz_pgm_id=? AND actv_id=? AND qualfctn_early_start_dt = ? ";
    private final static String isEligibleActivityUsedByParticipant = """
             		SELECT distinct actv_id FROM person_program_activity_status WHERE biz_pgm_id = ? and actv_id = ? and actv_stat_dt between ? and ?
            """;
    private final static String deleteEligibleActivityByStartDate = """
            delete from eligible_program_activity where biz_pgm_id = ? and actv_id = ? and qualfctn_start_dt = ?
            """;
    private static final String selectActivitiesByType =
            """
                    			SELECT ACTV_ID, ACTV_TP_CD_ID, HOST_SRCE, COMPLETION_DURATION, ACTV_NM, ACTV_DESC, ACTV_LINK, ACTV_COST, ACTV_EFF_DT, ACTV_END_DT, INSERT_TS, INSERT_USR, SRCE_ACTV_ID FROM ACTIVITY WHERE ACTV_TP_CD_ID = ?
                    """;
    private static final String selectMemberActivityHistory =
            """
                    SELECT DISTINCT
                       	ACTV_EVNT_LOG_ID,
                    	person.PRSN_DMGRPHCS_ID,
                    	activity_def.ACTV_ID,
                    	activity_def.ACTV_NM,
                    	activity_def.SRCE_ACTV_ID,
                    	alog.REGISTRATION_ID,
                    	alog.STAT_CD as activity_stat_val,
                    	alog.STAT_EFF_DT ACTV_STAT_DT,
                    	alog.STAT_OUTCM
                    	, alog.auth_cd
                    	, alog.PRCSNG_STAT_VAL
                    	, alog.MODIFY_TS
                       FROM
                     	ACTIVITY activity_def
                      		, activity_event_log alog
                      		,  prsn_demographics   person
                       WHERE
                    	person.PRSN_DMGRPHCS_ID = ?
                       	AND alog.hp_mem_id = person.hp_mem_id
                      		AND activity_def.SRCE_ACTV_ID = alog.ACTV_ID
                    """;
    private static final String ACTIVITY_EVENT_LOG_SEQ = "ACTIVITY_EVENT_LOG_SEQ";
    private static final String ELIG_PGM_ACTV_SEQ = "elig_pgm_actv_seq";

	private static final String selectExtEmployerActivities = """
             	SELECT DISTINCT eeax.EMPL_GRP_NO, egs.grp_id, eeax.EXT_ACTV_NM, activity.ACTV_ID, activity.srce_actv_id, eeax.EFF_DT, eeax.END_DT
            	FROM ext_empl_activity_xref eeax, activity, empl_grp_site egs
               	WHERE eeax.ACTV_ID = activity.actv_id
            		AND eeax.EMPL_GRP_NO = egs.EMPL_GRP_NO
              	ORDER BY eeax.EMPL_GRP_NO, activity.srce_actv_id, eeax.EXT_ACTV_NM
            """;

    // @formatter:on

    private final DataSource dataSource;
    private String selectActivity = "SELECT ACTV_ID, ACTV_TP_CD_ID " +
            ", (SELECT lu_val FROM luv WHERE lu_id = ACTV_TP_CD_ID) actv_tp_cd_value " +
            ", HOST_SRCE, COMPLETION_DURATION, ACTV_NM, ACTV_DESC, ACTV_LINK, ACTV_COST, ACTV_EFF_DT, ACTV_END_DT, INSERT_TS, INSERT_USR, SRCE_ACTV_ID FROM ACTIVITY WHERE ACTV_ID = ?";
    private String deleteExtendedAuthCodes =
            """
                    			DELETE FROM biz_pgm_auth_code_extended WHERE biz_pgm_id = ?	
                    """;
    private static final String selectEmployerAdminsterdActivities = """
            SELECT
          act.actv_id
        , act.actv_nm
        , act.actv_desc
        , luv.lu_val as actv_tp_cd_value
        , act.completion_duration
        , act.host_srce
        , act.srce_actv_id
        FROM
          activity act, 
          luv luv
        WHERE 
        luv.lu_grp = 'BPM_ACTIVITY_TP' 
        AND luv.lu_val = 'EMPLOYER_PGM'
        AND act.actv_tp_cd_id = luv.lu_id
        AND sysdate between act.actv_eff_dt and act.actv_end_dt
        ORDER BY act.actv_nm 
    """;

    private static final String selectActivitiesWithMemberAndTransactionDate = """
			   SELECT
			   distinct
			   count(biz.actv_id) count_used,
			   ael.hp_mem_id,
			   types.actv_id,
			   types.actv_tp_cd_id,
			   types.host_srce,
			   types.completion_duration,
			   types.actv_nm,
			   types.actv_desc,
			   types.actv_link,
			   types.actv_cost,
			   types.insert_ts,
			   types.insert_usr,
			   types.srce_actv_id,
			   l.lu_val,
			   l.lu_desc,
			   types.actv_eff_dt,
			   types.actv_end_dt,
			   types.insert_ts,
			   types.modify_ts,
			   types.insert_usr,
			   types.modify_usr
			   FROM activity types JOIN activity_event_log ael ON types.srce_actv_id = ael.actv_id
			   LEFT OUTER JOIN eligible_program_activity biz ON types.actv_id = biz.actv_id
			   LEFT OUTER JOIN luv l ON types.actv_tp_cd_id = l.lu_id
			   JOIN business_program bp on bp.biz_pgm_id = biz.biz_pgm_id
			   WHERE trunc(SYSDATE) >= types.ACTV_EFF_DT AND trunc(SYSDATE) <= types.ACTV_END_DT
			   and bp.biz_pgm_stat_cd_id = (select l.lu_id from luv l where l.lu_grp = 'BPM_ACTVTN_STATUS' and l.lu_val = 'ACTIVE')
			   and sysdate between bp.eff_dt and bp.pgm_end_dt
        """;
    private DataFieldMaxValueIncrementer activityIdIncrementer;
    private DataFieldMaxValueIncrementer eligibleProgramActivityIDIncrementer;


    public ActivityDAOJdbc(DataSource dataSource) {
        this.dataSource = dataSource;
    }


    @PostConstruct
    private void initialize() {
        setDataSource(dataSource);
        activityIdIncrementer = new OracleSequenceMaxValueIncrementer(dataSource, ACTIVITY_EVENT_LOG_SEQ);
        eligibleProgramActivityIDIncrementer = new OracleSequenceMaxValueIncrementer(dataSource, ELIG_PGM_ACTV_SEQ);
    }

    /**
     * Return an ArrayList of Activities.
     *
     * @return
     */
    @Override
    public Collection<Activity> selectActivities() {

        final ArrayList<Activity> lActivities = new ArrayList<Activity>();

        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectActivities);
        lQuery.append(" WHERE trunc(SYSDATE) >= types.ACTV_EFF_DT");
        lQuery.append("   AND trunc(SYSDATE) <= types.ACTV_END_DT");
        lQuery.append(" GROUP BY types.actv_id, types.actv_tp_cd_id, types.host_srce, types.completion_duration, types.actv_nm, types.actv_desc, types.actv_nm, types.actv_desc, types.actv_link, types.actv_cost, types.insert_ts, types.insert_usr, types.srce_actv_id, l.lu_val, l.lu_desc,  " +
                " types.actv_eff_dt,  types.actv_end_dt, types.insert_ts, types.modify_ts, types.insert_usr, types.modify_usr");
        lQuery.append(" ORDER BY types.actv_end_dt desc, lower(types.actv_nm) asc");

        JdbcTemplate template = getJdbcTemplate();
        template.query(lQuery.toString(), new RowCallbackHandler() {
            public void processRow(ResultSet rs) throws SQLException {
                Activity lActivity = new Activity();

                lActivity.setUsed(rs.getInt(("COUNT_USED")));
                lActivity
                        .setActivityID(rs.getObject("actv_id") != null ? Integer.valueOf(
                                rs.getInt("actv_id"))
                                : null);
                lActivity.setName(rs.getString("actv_nm"));
                lActivity.setDescription(rs.getString("actv_desc"));
                lActivity.setCost(BPMAdminUtils
                        .convertDoubleToDecimalFormattedString(rs
                                .getDouble("actv_cost")));
                lActivity.setDuration(rs.getInt("completion_duration"));
                lActivity.setSource(rs.getString("host_srce"));
                lActivity.setWebLink(rs.getString("actv_link"));
                lActivity.setSourceActivityID(rs.getString("srce_actv_id"));
                lActivity.setActivityTypeValue(rs.getString("lu_val"));
                lActivity.setActivityTypeDesc(rs.getString("lu_desc"));
                lActivity.setEffectiveDate(rs.getDate("actv_eff_dt"));
                lActivity.setEndDate(rs.getDate("actv_end_dt"));
                lActivity.setInsertDate(rs.getDate("insert_ts"));
                lActivity.setModifyDate(rs.getDate("modify_ts"));
                lActivity.setInsertUser(rs.getString("insert_usr"));
                lActivity.setModifyUser(rs.getString("modify_usr"));
                lActivities.add(lActivity);

            }
        });

        return lActivities;
    }

    /**
     * This query selects all the activity definitions including the ones that have expired.
     * It is called from the activity definition list page.
     *
     * @return
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Override
    public Collection<Activity> selectAllActivities() {

        final ArrayList<Activity> lActivities = new ArrayList<Activity>();

        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectActivities);
        lQuery.append(" WHERE types.actv_end_dt >= trunc(SYSDATE) ");

        lQuery.append(" GROUP BY types.actv_id, types.actv_tp_cd_id, types.host_srce, types.completion_duration, types.actv_nm, types.actv_desc, types.actv_nm, types.actv_desc, types.actv_link, types.actv_cost, types.insert_ts, types.insert_usr, types.srce_actv_id, l.lu_val, l.lu_desc," +
                " types.actv_eff_dt,  types.actv_end_dt, types.insert_ts, types.modify_ts, types.insert_usr, types.modify_usr");

        lQuery.append(" ORDER BY types.actv_end_dt desc, lower(types.actv_nm) asc");

        JdbcTemplate template = getJdbcTemplate();
        template.query(lQuery.toString(), new RowCallbackHandler() {
            public void processRow(ResultSet rs) throws SQLException {
                Activity lActivity = new Activity();
                lActivity.setUsed(rs.getInt(("COUNT_USED")));
                lActivity
                        .setActivityID(rs.getObject("actv_id") != null ? Integer.valueOf(
                                rs.getInt("actv_id"))
                                : null);
                lActivity.setName(rs.getString("actv_nm"));
                lActivity.setDescription(rs.getString("actv_desc"));
                lActivity.setCost(BPMAdminUtils
                        .convertDoubleToDecimalFormattedString(rs
                                .getDouble("actv_cost")));
                lActivity.setDuration(rs.getInt("completion_duration"));
                lActivity.setSource(rs.getString("host_srce"));
                lActivity.setWebLink(rs.getString("actv_link"));
                lActivity.setSourceActivityID(rs.getString("srce_actv_id"));
                lActivity.setActivityTypeValue(rs.getString("lu_val"));
                lActivity.setActivityTypeDesc(rs.getString("lu_desc"));
                lActivity.setEffectiveDate(rs.getDate("actv_eff_dt"));
                lActivity.setEndDate(rs.getDate("actv_end_dt"));
                lActivity.setInsertDate(rs.getDate("insert_ts"));
                lActivity.setModifyDate(rs.getDate("modify_ts"));
                lActivity.setInsertUser(rs.getString("insert_usr"));
                lActivity.setModifyUser(rs.getString("modify_usr"));

                lActivities.add(lActivity);

            }
        });

        return lActivities;
    }

    //Produces warnings during compile time to quickly identify typos or API changes
    @Override
    public Collection<Activity> selectExpiredActivities() {

        final ArrayList<Activity> lActivities = new ArrayList<Activity>();

        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectActivities);
        lQuery.append(" WHERE types.actv_end_dt < trunc(SYSDATE) ");

        lQuery.append(" GROUP BY types.actv_id, types.actv_tp_cd_id, types.host_srce, types.completion_duration, types.actv_nm, types.actv_desc, types.actv_nm, types.actv_desc, types.actv_link, types.actv_cost, types.insert_ts, types.insert_usr, types.srce_actv_id, l.lu_val, l.lu_desc,  " +
                " types.actv_eff_dt,  types.actv_end_dt, types.insert_ts, types.modify_ts, types.insert_usr, types.modify_usr");

        lQuery.append(" ORDER BY types.actv_end_dt desc, lower(types.actv_nm) asc");

        JdbcTemplate template = getJdbcTemplate();
        template.query(lQuery.toString(), new RowCallbackHandler() {
            public void processRow(ResultSet rs) throws SQLException {
                Activity lActivity = new Activity();
                lActivity.setUsed(rs.getInt(("COUNT_USED")));
                lActivity
                        .setActivityID(rs.getObject("actv_id") != null ? Integer.valueOf(
                                rs.getInt("actv_id"))
                                : null);
                lActivity.setName(rs.getString("actv_nm"));
                lActivity.setDescription(rs.getString("actv_desc"));
                lActivity.setCost(BPMAdminUtils
                        .convertDoubleToDecimalFormattedString(rs
                                .getDouble("actv_cost")));
                lActivity.setDuration(rs.getInt("completion_duration"));
                lActivity.setSource(rs.getString("host_srce"));
                lActivity.setWebLink(rs.getString("actv_link"));
                lActivity.setSourceActivityID(rs.getString("srce_actv_id"));
                lActivity.setActivityTypeDesc(rs.getString("lu_val"));
                lActivity.setEffectiveDate(rs.getDate("actv_eff_dt"));
                lActivity.setEndDate(rs.getDate("actv_end_dt"));
                lActivity.setInsertDate(rs.getDate("insert_ts"));
                lActivity.setModifyDate(rs.getDate("modify_ts"));
                lActivity.setInsertUser(rs.getString("insert_usr"));
                lActivity.setModifyUser(rs.getString("modify_usr"));

                lActivities.add(lActivity);

            }
        });

        return lActivities;
    }

    @Override
    public Activity selectActivity(int activityId) {


        ArrayList<Activity> lActivityDefitions = new ArrayList<Activity>();
        Object params[] = new Object[]{activityId};
        JdbcTemplate template = getJdbcTemplate();

        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectActivity);

        int types[] = new int[]{Types.INTEGER};


        lActivityDefitions = (ArrayList<Activity>) template.query(lQuery
                .toString(), params, types, new ActivityDefinitionRowMapper());


        Activity dto = null;
        if (lActivityDefitions.size() > 0) {
            dto = (Activity) lActivityDefitions.get(0);
        }
        return dto;
    }

    @Override
    public int deleteActivity(Integer activityID) throws DataAccessException {
        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{activityID};
        int types[] = new int[]{Types.INTEGER};
        return template.update(deleteActivity, params, types);
    }

    /**
     * private method - internal use
     *
     * @param lActivity
     * @return boolean
     * @throws DataAccessException
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Override
    public int insertActivity(Activity lActivity) throws DataAccessException {
        // userID value temporary until asciegi id is used
        /*
         * SQL sequences
         */
        Long activityIdSeq = Long.valueOf(activityIdIncrementer.nextLongValue());
        lActivity.setActivityID(activityIdSeq.intValue());
        JdbcTemplate template = getJdbcTemplate();

        Double costToDouble = null;
        try {
            NumberFormat numberFM = NumberFormat.getInstance();
            Number number = numberFM.parse(lActivity.getCost());
            costToDouble = number.doubleValue();

        } catch (ParseException e) {
            System.out.println("ParsingException error " + e);
        }

        Object params[] = new Object[]{lActivity.getActivityID(),
                lActivity.getActivityTypeCodeID(), lActivity.getSource(),
                lActivity.getDuration(), lActivity.getName(),
                lActivity.getDescription(), lActivity.getWebLink(),
                costToDouble,
                lActivity.getEffectiveDate(), lActivity.getEndDate(),
                lActivity.getUserId(),
                lActivity.getSourceActivityID()};
        int types[] = new int[]{Types.INTEGER, Types.INTEGER, Types.VARCHAR,
                Types.INTEGER, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR,
                Types.DOUBLE, Types.DATE, Types.DATE, Types.VARCHAR, Types.VARCHAR};
        int rowsInserted = template.update(insertActivity, params, types);

        return rowsInserted;
    }

    @Override
    public int updateActivity(Activity lActivity) throws DataAccessException {
        if (lActivity.getActivityID() == null) {
            return this.insertActivity(lActivity);
        }

        Integer activityTypeCodeID = (lActivity.getActivityTypeCodeID() != null) ? lActivity
                .getActivityTypeCodeID()
                : null;
        String hostSource = (lActivity.getSource() != null) ? lActivity
                .getSource() : null;
        Integer completionDuration = (lActivity.getDuration() != null) ? lActivity
                .getDuration()
                : null;
        String name = (lActivity.getName() != null) ? lActivity.getName()
                : null;
        String description = (lActivity.getDescription() != null) ? lActivity
                .getDescription() : null;
        String webLink = (lActivity.getWebLink() != null) ? lActivity
                .getWebLink() : null;

        Double cost = null;
        try {
            NumberFormat numberFM = NumberFormat.getInstance();
            Number number = numberFM.parse(lActivity.getCost());
            cost = (lActivity.getCost() != null) ? number.doubleValue() : null;
        } catch (ParseException e) {
            System.out.println("ParsingException error " + e);
        }

        String userId = (lActivity.getUserId() != null) ? lActivity.getUserId()
                : null;
        String sourceActivityID = (lActivity.getSourceActivityID() != null) ? lActivity
                .getSourceActivityID()
                : null;

        Date effDate = (lActivity.getEffectiveDate() != null) ? lActivity.getEffectiveDate()
                : null;
        Date endDate = (lActivity.getEndDate() != null) ? lActivity.getEndDate()
                : null;

        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{activityTypeCodeID, hostSource,
                completionDuration, name, description, webLink, cost, userId,
                sourceActivityID, effDate, endDate, lActivity.getActivityID()};
        int types[] = new int[]{Types.INTEGER, Types.VARCHAR, Types.INTEGER,
                Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.DOUBLE,
                Types.VARCHAR, Types.VARCHAR, Types.DATE, Types.DATE, Types.INTEGER};

        int rowInserted = template.update(updateActivity, params, types);
        return rowInserted;
    }

    @Override
    public Collection<EligibleActivity> getEligibleActivities(Integer programID) {
        final ArrayList<EligibleActivity> lEligibleActivities;

        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{programID};
        int types[] = new int[]{Types.INTEGER};
        StringBuffer lQuery = new StringBuffer();

        lQuery.append(selectEligibleActivities);
        //EV58500 - added to the sql script
        lQuery.append(" AND biz.biz_pgm_id = ? ");
        lQuery.append(" ORDER BY act.actv_tp_cd_id, act.srce_actv_id ");

        lEligibleActivities = (ArrayList<EligibleActivity>) template.query(
                lQuery.toString(), params, types,
                new EligibleActivityRowMapper());

        return lEligibleActivities;
    }

    /*
     * EV58500 - return all activities since more than one of the same activity can be assigned
     *           but will carry different auth codes and effective dates.  Program ID is
     *           passed but not be used.
     * (non-Javadoc)
     * @see com.healthpartners.app.bpm.dao.ActivityDAO#getAvailableActivities(java.lang.Integer)
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Override
    public Collection<Activity> getAvailableActivities(Integer programID) {
        final ArrayList<Activity> lAvailableActivities;

        JdbcTemplate template = getJdbcTemplate();
        //Object params[] = new Object[] { programID };
        Object params[] = new Object[]{};
        //int types[] = new int[] { Types.INTEGER };
        int types[] = new int[]{};
        StringBuffer lQuery = new StringBuffer();

        lQuery.append(selectAvailableActivities);
        lQuery.append(" ORDER BY actv_tp_cd_value asc, act.actv_nm asc ");

        lAvailableActivities = (ArrayList<Activity>) template.query(lQuery
                .toString(), params, types, new ActivityRowMapper());

        return lAvailableActivities;
    }

    //Produces warnings during compile time to quickly identify typos or API changes
    @Override
    public int deleteEligibleActivities(Integer programID) throws DataAccessException {
        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{programID, programID};
        int types[] = new int[]{Types.INTEGER, Types.INTEGER};
        int deleteElgAct = template.update(deleteEligibleActivities, params, types);
        return deleteElgAct;

    }


    public int deleteProgramCheckmark(Integer businessProgramID)
            throws DataAccessException {
        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{businessProgramID};
        int types[] = new int[]{Types.INTEGER};

        StringBuffer lQuery = new StringBuffer();
        lQuery.append(deleteProgramCheckmark);
        lQuery.append(" biz_pgm_id = ? ");

        int deletePgmChk = template.update(lQuery.toString(), params, types);
        return deletePgmChk;
    }

    @Override
    public void insertEligibleActivity(EligibleActivity pEligibleActivity, String lUserID) {
        JdbcTemplate template = getJdbcTemplate();
        Long eligibleActivityID = Long.valueOf(eligibleProgramActivityIDIncrementer.nextLongValue());

        Object params[] = new Object[]{

                eligibleActivityID,
                pEligibleActivity.getQualificationWindowStartDate(),
                pEligibleActivity.getQualificationWindowEndDate(),
                pEligibleActivity.getQualificationWindowEarlyStartDate(),
                pEligibleActivity.getQualificationWindowLateEndDate(),
                pEligibleActivity.getEnrollmentDeadlineDate(),
                pEligibleActivity.getAuthorizationCode(), lUserID,
                pEligibleActivity.getProgramID(),
                pEligibleActivity.getActivity().getActivityID(), lUserID
                , pEligibleActivity.getExclusionOptionFlag()
                , pEligibleActivity.getIncentiveOverrideCodeID()
                , pEligibleActivity.getActivityName()
                , pEligibleActivity.getActivity().getActivityID()
                , pEligibleActivity.getActivityDesc()
                , pEligibleActivity.getActivity().getActivityID()
        };

        int types[] = new int[]{Types.INTEGER, Types.DATE, Types.DATE, Types.DATE,
                Types.DATE, Types.DATE, Types.VARCHAR, Types.VARCHAR, Types.INTEGER,
                Types.INTEGER, Types.VARCHAR, Types.VARCHAR, Types.INTEGER,
                Types.VARCHAR, Types.INTEGER, Types.VARCHAR, Types.INTEGER
        };

        template.update(insertEligibleActivity, params, types);
        return;
    }

    @Override
    public Collection<AuthCode> selectExtendedAuthCodes(final Integer pProgramID) {
        final ArrayList<AuthCode> lAuthCodes = new ArrayList<AuthCode>();

        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectExtendedAuthCodes);
        lQuery.append(" ORDER BY auth_cd ");

        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{pProgramID};
        int types[] = new int[]{Types.INTEGER};
        template.query(lQuery.toString(), params, types,
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        AuthCode lAuthCode = new AuthCode();

                        lAuthCode.setBusinessProgramID(rs.getInt("BIZ_PGM_ID"));
                        lAuthCode.setAuthCode(rs.getString("auth_cd"));
                        lAuthCode.setAuthCodeTypeCodeID(rs.getInt("AUTH_CD_TP_ID"));
                        lAuthCode.setAuthCodeTypeCode(rs.getString("lu_val"));
                        lAuthCode.setEffectiveDate(rs.getDate("EFF_DT"));
                        lAuthCode.setEndDate(rs.getDate("END_DT"));

                        lAuthCodes.add(lAuthCode);
                    }
                });
        return lAuthCodes;
    }

    /**
     * @param pAuthCode
     * @param pUserID
     */
    @Override
    public void updateExtendedAuthCode(AuthCode pAuthCode, String pUserID) {
        // If this auth code does not exist, insert. Otherwise update.
        ArrayList<AuthCode> lAuthCodes = (ArrayList<AuthCode>) selectExtendedAuthCode(pAuthCode.getBusinessProgramID(), pAuthCode.getAuthCode());

        if (lAuthCodes.size() <= 0) {
            this.insertExtendedAuthCode(pAuthCode, pUserID);
            return;
        }

        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]
                {
                        pAuthCode.getAuthCode(),
                        pAuthCode.getAuthCodeTypeCodeID(),
                        pAuthCode.getEffectiveDate(),
                        pAuthCode.getEndDate(),
                        pUserID,
                        pAuthCode.getBusinessProgramID(),
                        pAuthCode.getAuthCode()
                };

        int types[] = new int[]{Types.VARCHAR, Types.INTEGER,
                Types.DATE, Types.DATE,
                Types.VARCHAR,
                Types.INTEGER, Types.VARCHAR};

        template.update(updateExtendedAuthCode, params, types);
        return;
    }

    /**
     * Check if for the given programID, the given auth code exists.
     *
     * @param pProgramID
     * @param pAuthCode
     * @return
     */
    @Override
    public Collection<AuthCode> selectExtendedAuthCode(final Integer pProgramID, final String pAuthCode) {
        final ArrayList<AuthCode> lAuthCodes = new ArrayList<AuthCode>();
        StringBuffer lQuery = new StringBuffer();

        lQuery.append(selectExtendedAuthCodes);
        lQuery.append(" AND AUTH_CD = ? ");
        lQuery.append(" ORDER BY AUTH_CD ");

        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{pProgramID, pAuthCode};
        int types[] = new int[]{Types.INTEGER, Types.VARCHAR};

        template.query(lQuery.toString(), params, types,
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        AuthCode lAuthCode = new AuthCode();

                        lAuthCode.setBusinessProgramID(pProgramID);
                        lAuthCode.setAuthCode(rs.getString("auth_cd"));
                        lAuthCode.setAuthCodeTypeCodeID(rs.getInt("AUTH_CD_TP_ID"));
                        lAuthCode.setAuthCodeTypeCode(rs.getString("lu_val"));
                        lAuthCode.setEffectiveDate(rs.getDate("EFF_DT"));
                        lAuthCode.setEndDate(rs.getDate("END_DT"));

                        lAuthCodes.add(lAuthCode);
                    }
                });
        return lAuthCodes;
    }

    /**
     * @param pAuthCode
     * @param pUserID
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Override
    public void insertExtendedAuthCode(AuthCode pAuthCode, String pUserID) {
        JdbcTemplate template = getJdbcTemplate();

        Object params[] = new Object[]
                {
                        pAuthCode.getAuthCode(),
                        pAuthCode.getBusinessProgramID(),
                        pAuthCode.getAuthCodeTypeCodeID(),
                        pAuthCode.getEffectiveDate(),
                        pAuthCode.getEndDate(),
                        pUserID
                };

        int types[] = new int[]{Types.VARCHAR, Types.INTEGER, Types.INTEGER,
                Types.DATE, Types.DATE,
                Types.VARCHAR};

        template.update(insertExtendedAuthCode, params, types);
        return;
    }

    /**
     * @param pQualificationCheckmarkID
     * @param pProgramID
     * @return
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Override
    public ArrayList<Integer> getCheckmarkEligibleActivities(Integer pQualificationCheckmarkID, Integer pProgramID) {
        final ArrayList<Integer> lActivityIDList = new ArrayList<Integer>();
        StringBuffer lQuery = new StringBuffer();

        lQuery.append(selectCheckmarkEligibleActivities);

        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{pQualificationCheckmarkID, pProgramID};
        int types[] = new int[]{Types.INTEGER, Types.INTEGER};

        template.query(lQuery.toString(), params, types,
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        lActivityIDList.add(rs.getInt("actv_id"));
                    }
                });

        return lActivityIDList;
    }

    @Override
    public void updateEligibleActivity(EligibleActivity pEligibleActivity, String lUserID) {
        ArrayList<EligibleActivity> lEligibleActivities = (ArrayList<EligibleActivity>) getEligibleActivity(pEligibleActivity.getProgramID(),
                pEligibleActivity.getActivity().getActivityID(), pEligibleActivity.getQualificationWindowEarlyStartDate());

        if (lEligibleActivities.size() <= 0) {
            this.insertEligibleActivity(pEligibleActivity, lUserID);
            return;
        }

        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{
                pEligibleActivity.getQualificationWindowStartDate(),
                pEligibleActivity.getQualificationWindowEndDate(),
                pEligibleActivity.getQualificationWindowEarlyStartDate(),
                pEligibleActivity.getQualificationWindowLateEndDate(),
                pEligibleActivity.getEnrollmentDeadlineDate(),
                pEligibleActivity.getAuthorizationCode(), lUserID,
                pEligibleActivity.getExclusionOptionFlag(),
                pEligibleActivity.getIncentiveOverrideCodeID(),
                pEligibleActivity.getActivityName(),
                pEligibleActivity.getActivity().getActivityID(),
                pEligibleActivity.getActivityDesc(),
                pEligibleActivity.getActivity().getActivityID(),
                pEligibleActivity.getProgramID(),
                pEligibleActivity.getActivity().getActivityID(),
                pEligibleActivity.getQualificationWindowEarlyStartDate()
        };

        int types[] = new int[]{Types.DATE, Types.DATE, Types.DATE,
                Types.DATE, Types.DATE, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.INTEGER,
                Types.VARCHAR, Types.INTEGER, Types.VARCHAR, Types.INTEGER,  // name, ID, desc, ID
                Types.INTEGER, Types.INTEGER, Types.DATE};

        template.update(updateEligibleActivity, params, types);
        return;
    }

    @Override
    public Collection<EligibleActivity> getEligibleActivity(Integer pProgramID, Integer pActivityID, java.sql.Date qualificationEarlyStartDate) {
        final ArrayList<EligibleActivity> lEligibleActivities;

        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{pProgramID, pActivityID, qualificationEarlyStartDate};
        int types[] = new int[]{Types.INTEGER, Types.INTEGER, Types.DATE};
        StringBuffer lQuery = new StringBuffer();

        lQuery.append(selectEligibleActivities);

        //EV58500 - added to the sql script
        lQuery.append(" AND biz.biz_pgm_id = ? ");
        lQuery.append(" AND act.actv_id = ? ");
        lQuery.append(" AND elig.qualfctn_early_start_dt = ? ");
        lQuery.append(" ORDER BY act.actv_nm ");

        lEligibleActivities = (ArrayList<EligibleActivity>) template.query(lQuery.toString(), params, types, new EligibleActivityRowMapper());

        return lEligibleActivities;
    }

    @Override
    public boolean isEligibleActivityUsedByParticipant(EligibleActivity pEligibleActivity) {
        final ArrayList<Integer> results = new ArrayList<Integer>();
        Object params[] = new Object[]{pEligibleActivity.getProgramID(), pEligibleActivity.getActivity().getActivityID(), pEligibleActivity.getQualificationWindowEarlyStartDate(), pEligibleActivity.getQualificationWindowLateEndDate()};
        JdbcTemplate template = getJdbcTemplate();
        int types[] = new int[]{Types.INTEGER, Types.INTEGER, Types.DATE, Types.DATE};
        template.query(isEligibleActivityUsedByParticipant, params, types, new RowCallbackHandler() {
            public void processRow(ResultSet rs) throws SQLException {

                results.add(Integer.valueOf(
                        rs.getInt("actv_id")));

            }
        });

        Integer activity = null;
        boolean used = false;
        if (results.size() > 0) {
            activity = (Integer) results.get(0);
            if (activity > 0) {
                used = true;
            }
        }
        return used;
    }

    @Override
    public int deleteEligibleActivityByStartDate(Integer programID, Integer activityID, java.sql.Date startDate) {
        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{programID, activityID, startDate};

        int types[] = new int[]{Types.INTEGER, Types.INTEGER, Types.DATE};

        int deleteCt = template.update(deleteEligibleActivityByStartDate, params, types);
        return deleteCt;
    }

    @Override
    public ArrayList<Activity> getActivityDefinitionsByType(int activityTypeID) {

        ArrayList<Activity> lActivityDefitions = new ArrayList<Activity>();
        Object params[] = new Object[]{activityTypeID};
        JdbcTemplate template = getJdbcTemplate();

        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectActivitiesByType);

        int types[] = new int[]{Types.INTEGER};


        lActivityDefitions = (ArrayList<Activity>) template.query(lQuery
                .toString(), params, types, new ActivityDefinitionRowMapper());


        return lActivityDefitions;
    }

    @Override
    public void deleteExtendedAuthCodes(Integer pProgramID) {
        JdbcTemplate template = getJdbcTemplate();

        Object params[] = new Object[]
                {
                        pProgramID
                };

        int types[] = new int[]{Types.INTEGER};

        template.update(deleteExtendedAuthCodes, params, types);
        return;
    }

    @Override
    public Collection<MemberProgramActivity>
    getActivityHistory(Integer personID, Date qualificationStartDate) {
        final ArrayList<MemberProgramActivity> results = new ArrayList<MemberProgramActivity>();
        JdbcTemplate template = getJdbcTemplate();
        Object params[] = null;
        int types[] = null;

        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectMemberActivityHistory);

        if (qualificationStartDate != null) {
            lQuery.append(" AND STAT_EFF_DT >= ?");
            params = new Object[]{personID, qualificationStartDate};
            types = new int[]{Types.INTEGER, Types.DATE};
        } else {
            params = new Object[]{personID};
            types = new int[]{Types.INTEGER};
        }

        lQuery.append(" ORDER BY alog.STAT_EFF_DT DESC ");

        template.query(lQuery.toString(), params, types,
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        MemberProgramActivity activity = new MemberProgramActivity();

                        activity
                                .setPersonID((rs.getObject("PRSN_DMGRPHCS_ID") != null) ? rs.getInt("PRSN_DMGRPHCS_ID")
                                        : null);
                        activity
                                .setActivityID((rs.getObject("ACTV_ID") != null) ? rs.getInt("ACTV_ID")
                                        : null);
                        activity.setActivityName(rs.getString("ACTV_NM"));
                        activity.setSourceActivityID(rs
                                .getString("SRCE_ACTV_ID"));
                        activity.setRegistrationID(rs
                                .getString("REGISTRATION_ID"));
                        activity.setStatusCodeValue(rs
                                .getString("activity_stat_val"));
                        activity.setStatusDate(rs.getDate("ACTV_STAT_DT"));
                        activity.setStatusOutComeValue(rs
                                .getString("STAT_OUTCM"));

                        activity.setAuthCode(rs.getString("auth_cd"));
                        activity.setProcessingStatus(rs.getString("PRCSNG_STAT_VAL"));
                        activity.setModifyDate(new java.sql.Date(rs.getTimestamp("MODIFY_TS").getTime()));

                        results.add(activity);
                    }
                });

        return results;
    }

    @Override
    public ArrayList<ExtEmployerActivity> getExtEmployerActivities() throws DataAccessException {
        final ArrayList<ExtEmployerActivity> lExtEmployerActivities = new ArrayList<ExtEmployerActivity>();

        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{};
        int types[] = new int[]{};

        template.query(selectExtEmployerActivities, params, types,
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        ExtEmployerActivity lExtEmployerActivity = new ExtEmployerActivity();

                        lExtEmployerActivity.setGroupNo(rs.getString("EMPL_GRP_NO"));
                        lExtEmployerActivity.setGroupID(rs.getInt("grp_id"));

                        lExtEmployerActivity.setExternalActivityName(rs.getString("EXT_ACTV_NM"));
                        lExtEmployerActivity.setActivityID(rs.getInt("ACTV_ID"));

                        lExtEmployerActivity.setSourceActivityID(rs.getString("srce_actv_id"));

                        lExtEmployerActivity.setEffectiveDate(rs.getDate("EFF_DT"));
                        lExtEmployerActivity.setEndDate(rs.getDate("END_DT"));

                        lExtEmployerActivities.add(lExtEmployerActivity);
                    }
                });

        return lExtEmployerActivities;
    }

    //Produces warnings during compile time to quickly identify typos or API changes
    @Override
    public Collection<Activity> getEmployerAdminsterdActivities()
            throws DataAccessException {

        final ArrayList<Activity> lActivities = new ArrayList<Activity>();
        JdbcTemplate template = getJdbcTemplate();
        template.query(selectEmployerAdminsterdActivities,
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        Activity lActivity = new Activity();
                        lActivity
                                .setActivityID(rs.getObject("actv_id") != null ? new Integer(
                                        rs.getInt("actv_id"))
                                        : null);
                        lActivity.setName(rs.getString("actv_nm"));
                        lActivity.setDescription(rs.getString("actv_desc"));
                        lActivity.setDuration(rs.getInt("completion_duration"));
                        lActivity.setActivityTypeValue(rs
                                .getString("actv_tp_cd_value"));
                        lActivity.setSource(rs.getString("host_srce"));
                        lActivity.setSourceActivityID(rs
                                .getString("srce_actv_id"));
                        lActivities.add(lActivity);
                    }
                });

        return lActivities;
    }

    /**
     * Return an ArrayList of Activities.
     *
     * @param memberId
     * @return
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Override
    public Collection<Activity> selectActivitiesWithMemberAndTransactionDate(String memberId, Date transactionDate) {

        final ArrayList<Activity> lActivities = new ArrayList<Activity>();

        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectActivitiesWithMemberAndTransactionDate);
        lQuery.append(" AND  ael.hp_mem_id = ?");
        lQuery.append(" AND ael.stat_eff_dt >= ?");
        lQuery.append(" GROUP BY types.actv_id, types.actv_tp_cd_id, types.host_srce, types.completion_duration, types.actv_nm, types.actv_desc, types.actv_nm, types.actv_desc, types.actv_link, types.actv_cost, types.insert_ts, types.insert_usr, types.srce_actv_id, l.lu_val, l.lu_desc, " +
                " types.actv_eff_dt,  types.actv_end_dt, types.insert_ts, types.modify_ts, types.insert_usr, types.modify_usr, ael.hp_mem_id ");
        lQuery.append(" ORDER BY types.actv_end_dt desc, lower(types.actv_nm) asc");

        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[] { memberId, transactionDate };
        ArrayList<Integer> lTypes = new ArrayList<Integer>();
        lTypes.add(new Integer(Types.VARCHAR));
        lTypes.add(new Integer(Types.DATE));

        int types[] = new int[lTypes.size()];
        for(int j = 0; j < lTypes.size(); j++)
        {
            types[j] = ((Integer)lTypes.get(j)).intValue();
        }


        template.query(lQuery.toString(), params, types,
                new RowCallbackHandler() {
                    @Override
                    public void processRow(ResultSet rs) throws SQLException {
                        Activity lActivity = new Activity();

                        lActivity.setUsed(rs.getInt(("COUNT_USED")));
                        lActivity.setMemberId(rs.getString("hp_mem_id"));
                        lActivity
                                .setActivityID(rs.getObject("actv_id") != null ? new Integer(
                                        rs.getInt("actv_id"))
                                        : null);
                        lActivity.setName(rs.getString("actv_nm"));
                        lActivity.setDescription(rs.getString("actv_desc"));
                        lActivity.setCost(BPMAdminUtils
                                .convertDoubleToDecimalFormattedString(rs
                                        .getDouble("actv_cost")));
                        lActivity.setDuration(rs.getInt("completion_duration"));
                        lActivity.setSource(rs.getString("host_srce"));
                        lActivity.setWebLink(rs.getString("actv_link"));
                        lActivity.setSourceActivityID(rs.getString("srce_actv_id"));
                        lActivity.setActivityTypeValue(rs.getString("lu_val"));
                        lActivity.setActivityTypeDesc(rs.getString("lu_desc"));
                        lActivity.setEffectiveDate(rs.getDate("actv_eff_dt"));
                        lActivity.setEndDate(rs.getDate("actv_end_dt"));
                        lActivity.setInsertDate(rs.getDate("insert_ts"));
                        lActivity.setModifyDate(rs.getDate("modify_ts"));
                        lActivity.setInsertUser(rs.getString("insert_usr"));
                        lActivity.setModifyUser(rs.getString("modify_usr"));
                        lActivities.add(lActivity);

                    }
                });

        return lActivities;
    }



    private static final class ActivityDefinitionRowMapper implements RowMapper {
        public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
            Activity lActivity = new Activity();
            lActivity
                    .setActivityID(rs.getObject("actv_id") != null ? Integer.valueOf(
                            rs.getInt("actv_id"))
                            : null);
            lActivity.setActivityTypeCodeID(rs.getInt("actv_tp_cd_id"));
            lActivity.setSource(rs.getString("host_srce"));
            lActivity.setDuration(rs.getInt("completion_duration"));
            lActivity.setName(rs.getString("actv_nm"));
            lActivity.setDescription(rs.getString("actv_desc"));
            lActivity.setWebLink(rs.getString("actv_link"));
            lActivity.setCost(BPMAdminUtils
                    .convertDoubleToDecimalFormattedString(rs
                            .getDouble("actv_cost")));
            lActivity.setUserId(rs.getString("insert_usr"));
            lActivity.setSourceActivityID(rs.getString("srce_actv_id"));
            lActivity.setEffectiveDate(rs.getDate("actv_eff_dt"));
            lActivity.setEndDate(rs.getDate("actv_end_dt"));
            return lActivity;

        }
    }

    private static final class EligibleActivityRowMapper implements RowMapper {
        public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
            EligibleActivity lEligibleActivity = new EligibleActivity();
            Activity lActivity = new Activity();
            lActivity.setActivityID(rs.getInt("actv_id"));
            lActivity.setName(rs.getString("actv_nm"));
            lActivity.setDescription(rs.getString("actv_desc"));
            lActivity.setActivityTypeValue(rs.getString("actv_tp_cd_value"));
            lActivity.setActivityTypeDesc(rs.getString("actv_tp_cd_desc"));
            lActivity.setDuration(rs.getInt("completion_duration"));
            lActivity.setSourceActivityID(rs.getString("srce_actv_id"));
            lEligibleActivity.setActivity(lActivity);

            lEligibleActivity.setProgramID(rs.getInt("biz_pgm_id"));
            lEligibleActivity.setAuthorizationCode(rs.getString("auth_cd"));
            lEligibleActivity.setQualificationWindowStartDate(rs
                    .getDate("qualfctn_start_dt"));
            lEligibleActivity.setQualificationWindowEndDate(rs
                    .getDate("qualfctn_end_dt"));
            lEligibleActivity.setQualificationWindowEarlyStartDate(rs
                    .getDate("qualfctn_early_start_dt"));
            lEligibleActivity.setQualificationWindowLateEndDate(rs
                    .getDate("qualfctn_late_end_dt"));
            lEligibleActivity.setEnrollmentDeadlineDate(rs
                    .getDate("enroll_deadline_dt"));
            lEligibleActivity.setExclusionOptionFlag(rs.getString("EXCLUSION_OPTN_FLG"));

            lEligibleActivity.setActivityName(lActivity.getName());
            lEligibleActivity.setActivityDesc(lActivity.getDescription());


            if (rs.getInt("incentive_override_code_id") == 0) {
                lEligibleActivity.setIncentiveOverrideCode(BPMAdminConstants.BPM_DEFAULT_FIRST_ITEM_IN_DROPDOWN);
            } else {
                lEligibleActivity.setIncentiveOverrideCode(rs.getString("incentive_override_code"));
            }
            lEligibleActivity.setIncentiveOverrideCodeID(rs.getInt("incentive_override_code_id"));

            lEligibleActivity.setCustomActiveName(rs.getString("cstm_actv_nm"));
            lEligibleActivity.setCustomActiveDescription(rs.getString("cstm_actv_desc"));

            return lEligibleActivity;
        }
    }

    private static final class ActivityRowMapper implements RowMapper {
        public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
            Activity lActivity = new Activity();
            lActivity
                    .setActivityID(rs.getObject("actv_id") != null ? Integer.valueOf(
                            rs.getInt("actv_id"))
                            : null);
            lActivity.setName(rs.getString("actv_nm"));
            lActivity.setDescription(rs.getString("actv_desc"));
            lActivity.setActivityTypeValue(rs.getString("actv_tp_cd_value"));
            lActivity.setActivityTypeDesc(rs.getString("actv_tp_cd_desc"));
            lActivity.setDuration(rs.getInt("completion_duration"));
            lActivity.setSourceActivityID(rs.getString("srce_actv_id"));

            return lActivity;
        }
    }
}