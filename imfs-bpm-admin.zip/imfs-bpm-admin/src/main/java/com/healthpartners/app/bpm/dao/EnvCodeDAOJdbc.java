package com.healthpartners.app.bpm.dao;

import com.healthpartners.app.bpm.dto.BPMEnvCode;
import com.healthpartners.app.bpm.exception.BPMException;
import jakarta.annotation.PostConstruct;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.jdbc.support.incrementer.DataFieldMaxValueIncrementer;
import org.springframework.jdbc.support.incrementer.OracleSequenceMaxValueIncrementer;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Collection;

@Repository
@Transactional(timeout = 300, rollbackFor = {DataAccessException.class, BPMException.class})
public class EnvCodeDAOJdbc extends JdbcDaoSupport implements EnvCodeDAO {
    private static final String insertEnvCode = """
            INSERT INTO env_code_value (ENV_CD_VAL_ID, CODE, VALUE, ENV_DESC) VALUES (bpm_env_cd_val_seq.nextval, ?, ?, ?)
            """;

    private static final String updateEnvCode = """
            UPDATE env_code_value SET CODE = ?, VALUE=?, ENV_DESC = ? WHERE ENV_CD_VAL_ID = ?
            """;

    private static final String deleteEnvCode = """
            DELETE FROM LUV env_code_value WHERE ENV_CD_VAL_ID = ?
            """;

    private static final String selectEnvCodes = """
            SELECT ENV_CD_VAL_ID, CODE, VALUE, ENV_DESC FROM env_code_value ORDER BY CODE
            """;

    private final DataSource dataSource;

    public EnvCodeDAOJdbc(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @PostConstruct
    private void initialize() {
        setDataSource(dataSource);
    }

    //Produces warnings during compile time to quickly identify typos or API changes
    @Override
    public int insertEnvCode(BPMEnvCode code) throws DataAccessException {
        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{code.getEnvCode(), code.getEnvCodeValue(), code.getEnvCodeDesc()};
        int types[] = new int[]{Types.VARCHAR, Types.VARCHAR, Types.VARCHAR};

        return template.update(insertEnvCode, params, types);
    }

    //Produces warnings during compile time to quickly identify typos or API changes
    @Override
    public int updateEnvCode(BPMEnvCode code) throws DataAccessException {
        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{code.getEnvCode(), code.getEnvCodeValue(), code.getEnvCodeDesc(), code.getEnvCodeID()};
        int types[] = new int[]{Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.INTEGER};

        return template.update(updateEnvCode, params, types);
    }

    //Produces warnings during compile time to quickly identify typos or API changes
    @Override
    public int deleteEnvCode(BPMEnvCode pEnvCode) throws DataAccessException {
        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{pEnvCode.getEnvCodeID()};
        int types[] = new int[]{Types.INTEGER};

		return template.update(deleteEnvCode, params, types);
    }

    //Produces warnings during compile time to quickly identify typos or API changes
    @Override
    public Collection<BPMEnvCode> getAllEnvCodes() throws DataAccessException {
        final ArrayList<BPMEnvCode> results = new ArrayList<BPMEnvCode>();
        JdbcTemplate template = getJdbcTemplate();
        template.query(selectEnvCodes, new RowCallbackHandler() {
            public void processRow(ResultSet rs) throws SQLException {
                BPMEnvCode lEnvCode = new BPMEnvCode();

                lEnvCode.setEnvCodeID(rs.getInt("ENV_CD_VAL_ID"));
                lEnvCode.setEnvCode(rs.getString("CODE"));
                lEnvCode.setEnvCodeValue(rs.getString("VALUE"));
                lEnvCode.setEnvCodeDesc(rs.getString("ENV_DESC"));

                results.add(lEnvCode);
            }
        });
        return results;
    }
}