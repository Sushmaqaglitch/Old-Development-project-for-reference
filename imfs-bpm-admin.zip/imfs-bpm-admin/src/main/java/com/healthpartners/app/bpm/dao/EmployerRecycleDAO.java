package com.healthpartners.app.bpm.dao;

import com.healthpartners.app.bpm.dto.RejectedPerson;
import com.healthpartners.app.bpm.exception.BPMException;
import org.springframework.dao.DataAccessException;

import java.sql.Date;
import java.util.Collection;

public interface EmployerRecycleDAO {
    Collection<RejectedPerson> getEmployerRecycle(Integer activityId,
                                                         String firstName, String lastName, Date activityDate, Date recycleStatusDate, Integer recycleStatusId)
            throws DataAccessException;

    RejectedPerson getEmployerRecycle(Integer pRecycleStatusId) throws BPMException, DataAccessException;

    void updateEmployerRecycle(RejectedPerson pRejectedPerson, String pUserID) throws BPMException, DataAccessException;
}
