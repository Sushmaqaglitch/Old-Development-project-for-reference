package com.healthpartners.app.bpm.dao;

import com.healthpartners.app.bpm.dto.ContributionGridBenefitContractTypeRelationship;
import com.healthpartners.app.bpm.dto.ProgramContributionGrid;
import com.healthpartners.app.bpm.exception.BPMException;
import org.springframework.dao.DataAccessException;

import java.util.ArrayList;
import java.util.Collection;

public interface ContributionGridDAO {
    public ArrayList<ProgramContributionGrid> getProgramContributionGrids(Integer programIncentiveOptionID) throws DataAccessException;

    int updateProgramContributionGrid(ProgramContributionGrid pProgramContributionGrid, String pModifyUserID) throws BPMException, DataAccessException;

    Collection<ContributionGridBenefitContractTypeRelationship> getContributionGridBenefitContractTypeRelationships(Integer benefitContractTypeID) throws DataAccessException;

    int deleteProgramContributionGridByUID(Integer lGridContributionID) throws BPMException, DataAccessException;;

    int deleteProgramContributionGrids(Integer lProgramIncentiveOptionID) throws BPMException, DataAccessException;
}
