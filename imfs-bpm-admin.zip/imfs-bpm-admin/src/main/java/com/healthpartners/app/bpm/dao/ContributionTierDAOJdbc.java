package com.healthpartners.app.bpm.dao;

import com.healthpartners.app.bpm.common.BPMAdminConstants;
import com.healthpartners.app.bpm.dto.*;
import com.healthpartners.app.bpm.exception.BPMException;
import jakarta.annotation.PostConstruct;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.jdbc.support.incrementer.DataFieldMaxValueIncrementer;
import org.springframework.jdbc.support.incrementer.OracleSequenceMaxValueIncrementer;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;

@Repository
@Transactional(timeout = 300, rollbackFor = { DataAccessException.class, BPMException.class })
public class ContributionTierDAOJdbc extends JdbcDaoSupport implements ContributionTierDAO {


    private static final String deleteProgramContributionIncentiveTierByProgramID = "delete from TIER_INCENTIVE_CONTRIBUTION t where t.biz_pgm_id = ?";

    private static final String deleteProgramContributionTierByProgramID = "delete from TIER_CONTRIBUTION t where t.biz_pgm_id = ?";

    private static final String selectProgramContributionIncentiveTiersActivityLevel =
            "select \n" +
                    "  \n" +
                    "      t.biz_pgm_id,\n" +
                    "      t.incntv_option_id,\n" +
                    "      ai.actv_id,\n" +
                    "      ai.actv_tp_cd_id,\n" +
                    "      (select a.actv_nm from activity a where a.actv_id = ai.actv_id) activity_name,\n" +
                    "      (select l.lu_val from luv l where l.lu_id = ai.actv_tp_cd_id) activity_type,\n" +
                    "      t.tier_contrib_id, \n" +
                    "       t.actv_incntv_id, \n" +
                    "       tc.tier_tp_id,\n" +
                    "       tc.tier_value_id,\n" +
                    "       tc.rel_cd,\n" +
                    "       (select l.rlshp_txt from pes_rel_ds l where l.rlshp_cd = tc.rel_cd) relationshipDesc,\n" +
                    "       tc.contrib_amt,\n" +
                    "       tv.ben_contr_tp_lu_id,\n" +
                    "       (select l.lu_desc from luv l where l.lu_id = tv.ben_contr_tp_lu_id) benefit_contract_type,\n" +
                    "       tp.tier_tp_nm,\n" +
                    "       tp.tier_tp_desc,\n" +
                    "       t.qualfctn_chkmrk_detl_id,\n" +
                    "       aigi.actv_incntv_grp_id,\n" +
                    "       aigi.actv_incntv_grp_req_id\n" +
                    "       \n" +
                    "       from TIER_INCENTIVE_CONTRIBUTION t,\n" +
                    "              TIER_CONTRIBUTION tc,\n" +
                    "              activity_incentive ai,\n" +
                    "              activity_incentive_grp_req aigi,\n" +
                    "              --incentive_particip_rel ipr,\n" +
                    "              tier_type tp,\n" +
                    "              tier_value tv\n" +
                    "         where \n" +
                    "               t.biz_pgm_id = tc.biz_pgm_id\n" +
                    "               and t.tier_contrib_id = tc.tier_contrib_id\n" +
                    "               and t.biz_pgm_id = ai.biz_pgm_id\n" +
                    "               and t.incntv_option_id = ai.incntv_optn_id\n" +
                    "               and t.actv_incntv_id = ai.actv_incntv_id\n" +
                    "               --lineup with group requirement\n" +
                    "               and t.biz_pgm_id = aigi.biz_pgm_id\n" +
                    "               and t.incntv_option_id = aigi.incntv_optn_id\n" +
                    "               and ai.actv_incntv_grp_id = aigi.actv_incntv_grp_id \n" +
                    "               and ai.actv_incntv_grp_req_id = aigi.actv_incntv_grp_req_id\n" +
                    "               -- lineup with relationship\n" +
                    "               --and ai.actv_incntv_id = ipr.actv_incntv_id\n" +
                    "               --and tc.rel_cd = ipr.rel_cd\n" +
                    "               and tc.tier_value_id = tv.tier_value_id\n" +
                    "               and tc.tier_tp_id = tv.tier_tp_id\n" +
                    "               and tv.tier_tp_id = tp.tier_tp_id\n" +
                    "               and t.biz_pgm_id = ? ";


    private static final String determineUsedForContributionTierParentRelationshipToRewardFulfillment =
            "select distinct t.tier_contrib_id from REWARD_FULFILL_RPT_TRCK_HIST t where t.tier_contrib_id = ? ";

    private static final String selectProgramContributionIncentiveTiersContractMemberLevel =
            "select \n" +
                    "  \n" +
                    "   t.biz_pgm_id,\n" +
                    "   t.incntv_option_id,\n" +
                    "   qcd.actv_id,\n" +
                    "   qcd.actv_tp_cd_id,\n" +
                    "   (select a.actv_nm from activity a where a.actv_id = qcd.actv_id) activity_name,\n" +
                    "   (select l.lu_val from luv l where l.lu_id = qcd.actv_tp_cd_id) activity_type,\n" +
                    "   t.tier_contrib_id, \n" +
                    "   t.actv_incntv_id, \n" +
                    "   tc.tier_tp_id,\n" +
                    "   tc.tier_value_id,\n" +
                    "   tc.rel_cd,\n" +
                    "   (select l.rlshp_txt from pes_rel_ds l where l.rlshp_cd = tc.rel_cd) relationshipDesc,\n" +
                    "   tc.contrib_amt,\n" +
                    "   tv.ben_contr_tp_lu_id,\n" +
                    "   (select l.lu_desc from luv l where l.lu_id = tv.ben_contr_tp_lu_id) benefit_contract_type,\n" +
                    "   tp.tier_tp_nm,\n" +
                    "   tp.tier_tp_desc,\n" +
                    "   t.qualfctn_chkmrk_detl_id\n" +
                    "\n" +
                    "\n" +
                    "from TIER_INCENTIVE_CONTRIBUTION t,\n" +
                    "   TIER_CONTRIBUTION tc,\n" +
                    "   QUALFCTN_CHKMRK_DETL qcd,\n" +
                    "   tier_type tp,\n" +
                    "   tier_value tv\n" +
                    "where \n" +
                    "   t.biz_pgm_id = tc.biz_pgm_id\n" +
                    "   and t.tier_contrib_id = tc.tier_contrib_id\n" +
                    "   and t.qualfctn_chkmrk_detl_id = qcd.qualfctn_chkmrk_detl_id\n" +
                    "   and tc.tier_value_id = tv.tier_value_id\n" +
                    "   and tc.tier_tp_id = tv.tier_tp_id\n" +
                    "   and tv.tier_tp_id = tp.tier_tp_id\n" +
                    "   and t.biz_pgm_id = ? ";

    private static final String determineUsedForContributionTierParentRelationshipToCDHPFulfillment =
            "select distinct t.tier_contrib_id from CDHP_FULFILL_RPT_TRACKING_HIST t where t.tier_contrib_id = ? ";

    private static final String countActivityRequirementRegisteredToProgramTierContribution =
            """
            select count(*) ticCount from TIER_INCENTIVE_CONTRIBUTION t
            where t.biz_pgm_id = ?
            and   t.incntv_option_id = ?
            and   t.actv_incntv_grp_id = ?
            and   t.actv_incntv_grp_req_id = ?
            """;

    private static final String selectAssignedContributionTierBenefitContractTypes =
           """
           SELECT bt.lu_id
                ,bt.lu_grp
                ,bt.lu_val
                ,bt.lu_desc\s
                ,t.tier_value_id
           FROM
                tier_value t,
                (select l.lu_id,
                        l.lu_grp,
                        l.lu_val,
                        l.lu_desc from luv l where l.lu_grp = 'BEN_CONTRACT_TYPE') bt
           where
                t.tier_tp_id = ? and t.ben_contr_tp_lu_id = bt.lu_id
           ORDER BY bt.lu_grp, bt.lu_val 
            """;

    private static final String determineUsedForTierValueParentRelationshipToTierContribution =
            """
            select distinct t.tier_tp_id from TIER_VALUE t
            where t.tier_tp_id = ? 
             """;
    private static final String selectContributionTierBenefitContractTypeRelationships =
            """
            select t.tier_value_rel_id,
               t.tier_value_id,
               t.rlshp_cd,
               p.rlshp_txt,
               t.insert_ts,
               t.modify_ts,
               t.insert_usr,
               t.modify_ts,
               t.modify_usr
            from TIER_VALUE_REL t,
               pes_rel_ds p
            where t.tier_value_id = ?
               AND t.rlshp_cd = p.rlshp_cd 
            """;
    private static final String selectContributionTiers =
            """
            SELECT t.tier_tp_id
             , t.tier_tp_nm
             , t.tier_tp_desc
             , t.tier_type_info
            FROM
               tier_type t
            order by t.tier_tp_nm 
            """;
    private static final String deleteProgramContributionTier =
            """
            delete from TIER_CONTRIBUTION t
            where t.tier_contrib_id = ?
            """;
    private static final String deleteProgramContributionIncentiveTier =
            """
            delete from TIER_INCENTIVE_CONTRIBUTION t
            where t.tier_contrib_id = ?
            """;

    private static final String insertProgramContributionTier =
            """
            INSERT INTO tier_contribution t
            (
                 t.tier_contrib_id
                 , t.tier_tp_id
                 , t.tier_value_id
                 , t.biz_pgm_id
                 , t.rel_cd
                 , t.contrib_amt
                 , INSERT_USR
                 , INSERT_TS)
            VALUES (?, \s
                ?,\s
                ?,\s
                ?,\s
                ?,\s
                ?,\s
                ?,
                SYSDATE)
                    """;

    private static final String insertProgramContributionIncentiveTier =
            """
            INSERT INTO tier_incentive_contribution t
                (
                 t.tier_contrib_id
                 , t.actv_incntv_id
                 , t.biz_pgm_id
                 , t.incntv_option_id
                 , t.actv_incntv_grp_id
                 , t.actv_incntv_grp_req_id
                 , t.QUALFCTN_CHKMRK_DETL_ID
                 , INSERT_USR
                 , INSERT_TS)
            VALUES (?, \s
                ?,\s
                ?,\s
                ?,\s
                ?,\s
                ?,
                ?,
                ?,\s
                SYSDATE)
            """;

    private static final String updateProgramContributionTier =
            """
            UPDATE tier_contribution
            SET tier_tp_id = ?,\s
                tier_value_id = ?,\s
                rel_cd = ?,\s
                contrib_amt = ?,\s
                MODIFY_TS = SYSDATE,\s
                MODIFY_USR = ? \s
           WHERE tier_contrib_id = ?
            """;

    private final DataSource dataSource;

    private DataFieldMaxValueIncrementer tierContributionIDIncrementer;
    private static final String TIER_CONTRIB_ID_SEQ = "tier_contrib_id_seq";

    public ContributionTierDAOJdbc (DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @PostConstruct
    private void initialize() {
        setDataSource(dataSource);
        tierContributionIDIncrementer = new OracleSequenceMaxValueIncrementer(dataSource, TIER_CONTRIB_ID_SEQ);
    }

    /**
     *
     * @param lProgramID
     * @return
     * @throws BPMException
     *             , DataAccessException
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Override
    public int deleteProgramContributionIncentiveTierByProgramID(
            Integer lProgramID) throws BPMException,
            DataAccessException {
        JdbcTemplate template = getJdbcTemplate();
        int rowInserted = 0;

        Object params[] = new Object[] { lProgramID };

        int types[] = new int[] { Types.INTEGER };

        rowInserted = template.update(deleteProgramContributionIncentiveTierByProgramID,
                params, types);

        if (rowInserted > 0) {
            rowInserted = this.deleteProgramContributionTierByProgramID(lProgramID);
        }

        return rowInserted;
    }

    /**
     *
     * @param lProgramID
     * @return
     * @throws BPMException
     *             , DataAccessException
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Override
    public int deleteProgramContributionTierByProgramID(Integer lProgramID)
            throws BPMException, DataAccessException {
        JdbcTemplate template = getJdbcTemplate();
        int rowInserted = 0;

        Object params[] = new Object[] { lProgramID };

        int types[] = new int[] { Types.INTEGER };

        rowInserted = template.update(deleteProgramContributionTierByProgramID, params,
                types);

        return rowInserted;
    }

    /**
     *
     * @param programID
     * @param incentiveOptionID
     * @param incentedStatusTypeCode
     * @return
     * @throws BPMException
     * @throws DataAccessException
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Override
    public ArrayList<ProgramContributionTier> getProgramContributionIncentiveTiers(Integer programID, Integer incentiveOptionID, String incentedStatusTypeCode ) throws BPMException, DataAccessException {
        final ArrayList<ProgramContributionTier> lProgramContributionTiers = new ArrayList<ProgramContributionTier>();
        ArrayList<Object> lParameters = new ArrayList<Object>();
        ArrayList<Integer> lTypes = new ArrayList<Integer>();

        if (incentedStatusTypeCode == null || incentedStatusTypeCode.equals(BPMAdminConstants.BPM_INCENTED_STATUS_TYPE_CONTRACT_BASED) ||
                incentedStatusTypeCode.equals(BPMAdminConstants.BPM_INCENTED_STATUS_TYPE_MEMBER_BASED)) {
            ArrayList<ProgramContributionTier> lProgramContributionTiersNotFinal = new ArrayList<ProgramContributionTier>();
            lProgramContributionTiersNotFinal = this.getProgramContributionIncentiveTiersContractMemberLevel(programID, incentiveOptionID);
            if (lProgramContributionTiersNotFinal != null && lProgramContributionTiersNotFinal.size() > 0) {
                return lProgramContributionTiersNotFinal;
            }
        }

        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectProgramContributionIncentiveTiersActivityLevel);

        lParameters.add(programID);
        lTypes.add(Integer.valueOf(Types.INTEGER));

        if (incentiveOptionID != null) {
            lQuery.append(" and t.incntv_option_id = ?");
            lParameters.add(incentiveOptionID);
            lTypes.add(Integer.valueOf(Types.INTEGER));

        }

        // Convert the parameter arraylists to arrays.
        Object params[] = new Object[lParameters.size()];
        lParameters.toArray(params);

        int types[] = new int[lTypes.size()];

        for (int j = 0; j < lTypes.size(); j++) {
            types[j] = ((Integer) lTypes.get(j)).intValue();
        }

        JdbcTemplate template = getJdbcTemplate();

        template.query(lQuery.toString(), params, types,
                new RowCallbackHandler() {
                    Integer rowIDCtr = 1;
                    public void processRow(ResultSet rs) throws SQLException {
                        ProgramContributionTier lProgramContributionTier = new ProgramContributionTier();
                        lProgramContributionTier.setProgramID(rs
                                .getInt("biz_pgm_id"));
                        lProgramContributionTier.setIncentiveOptionID(rs
                                .getInt("incntv_option_id"));
                        lProgramContributionTier.setActivityID(rs
                                .getInt("actv_id"));
                        lProgramContributionTier.setActivityName(rs
                                .getString("activity_name"));
                        lProgramContributionTier.setActivityTypeCodeID(rs
                                .getInt("actv_tp_cd_id"));
                        lProgramContributionTier.setActivityTypeCode(rs
                                .getString("activity_type"));
                        lProgramContributionTier.setTierContributionID(rs
                                .getInt("tier_contrib_id"));
                        lProgramContributionTier.setActivityIncentiveID(rs
                                .getInt("actv_incntv_id"));
                        lProgramContributionTier.setTierTypeID(rs
                                .getInt("tier_tp_id"));
                        lProgramContributionTier.setTierValueID(rs
                                .getInt("tier_value_id"));
                        lProgramContributionTier.setRelationshipCode(rs
                                .getInt("rel_cd"));
                        lProgramContributionTier.setRelationshipDesc(rs
                                .getString("relationshipDesc"));
                        lProgramContributionTier.setContributionAmount(rs
                                .getInt("contrib_amt"));
                        lProgramContributionTier.setBenefitContractTypeID(rs
                                .getInt("ben_contr_tp_lu_id"));
                        lProgramContributionTier.setBenefitContractType(rs
                                .getString("benefit_contract_type"));
                        lProgramContributionTier.setTierTypeName(rs
                                .getString("tier_tp_nm"));
                        lProgramContributionTier.setTierTypeDesc(rs
                                .getString("tier_tp_desc"));
                        lProgramContributionTier.setQualificationCheckmarkDetailID(rs
                                .getInt("qualfctn_chkmrk_detl_id"));
                        lProgramContributionTier.setActivityIncentiveGroupID(rs
                                .getInt("actv_incntv_grp_id"));
                        lProgramContributionTier.setActivityIncentiveGroupReqID(rs
                                .getInt("actv_incntv_grp_req_id"));
                        lProgramContributionTier.setRowID(rowIDCtr++);


                        lProgramContributionTiers.add(lProgramContributionTier);
                    }
                });

        // Determine if tier contribution id has a foreign key relationship from
        // parent to child.  In this case, cdhp fulfillment or reward fulfillment tables. If so, then
        // set flag to not allow a delete of the record.

        for (ProgramContributionTier lProgramContributionTier : lProgramContributionTiers) {
            boolean isUsed = determineUsedForContributionTierParentRelationshipToFulfillment(lProgramContributionTier.getTierContributionID());
            if (isUsed) {
                lProgramContributionTier.setUsed(true);
            } else {
                lProgramContributionTier.setUsed(false);
            }
        }


        return lProgramContributionTiers;
    }

    /*
     * Determine if tier contribution id has a foreign key relationship to
     * the reward fulfillment table using the tier_contrib_id as a search target. If so,
     * then set flag to not allow "remove" link to appear with the assigned
     * Benefit Contract Type Amount.
     */
    private boolean determineUsedForContributionTierParentRelationshipToFulfillment(
            Integer pTierContributionID)
            throws DataAccessException {

        final ArrayList<Integer> results = new ArrayList<Integer>();
        JdbcTemplate template = getJdbcTemplate();

        StringBuffer lQuery = new StringBuffer();
        lQuery.append(determineUsedForContributionTierParentRelationshipToRewardFulfillment);

        ArrayList<Object> lParameters = new ArrayList<Object>();
        ArrayList<Integer> lTypes = new ArrayList<Integer>();

        lParameters.add(pTierContributionID);
        lTypes.add(Integer.valueOf(Types.INTEGER));


        // Convert the parameter arraylists to arrays.
        Object params[] = new Object[lParameters.size()];
        lParameters.toArray(params);

        int types[] = new int[lTypes.size()];

        for (int j = 0; j < lTypes.size(); j++) {
            types[j] = ((Integer) lTypes.get(j)).intValue();
        }

        template.query(lQuery.toString(), params, types,
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        results.add(rs.getInt("tier_contrib_id"));
                    }
                });

        boolean parentChildRelationship = false;
        if (results.size() > 0) {
            parentChildRelationship = true;

        }

        if (parentChildRelationship == false) {
            parentChildRelationship = determineUsedForContributionTierParentRelationshipToCDHPFulfillment(pTierContributionID);
        }

        return parentChildRelationship;

    }

    /**
     *
     * @param programID
     * @param incentiveOptionID
     * @return
     * @throws BPMException
     * @throws DataAccessException
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Override
    public ArrayList<ProgramContributionTier> getProgramContributionIncentiveTiersContractMemberLevel(Integer programID, Integer incentiveOptionID) throws BPMException, DataAccessException {
        final ArrayList<ProgramContributionTier> lProgramContributionTiers = new ArrayList<ProgramContributionTier>();

        ArrayList<Object> lParameters = new ArrayList<Object>();
        ArrayList<Integer> lTypes = new ArrayList<Integer>();

        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectProgramContributionIncentiveTiersContractMemberLevel);

        lParameters.add(programID);
        lTypes.add(Integer.valueOf(Types.INTEGER));

        if (incentiveOptionID != null) {
            lQuery.append(" and t.incntv_option_id = ?");
            lParameters.add(incentiveOptionID);
            lTypes.add(Integer.valueOf(Types.INTEGER));

        }

        // Convert the parameter arraylists to arrays.
        Object params[] = new Object[lParameters.size()];
        lParameters.toArray(params);

        int types[] = new int[lTypes.size()];

        for (int j = 0; j < lTypes.size(); j++) {
            types[j] = ((Integer) lTypes.get(j)).intValue();
        }

        JdbcTemplate template = getJdbcTemplate();


        template.query(lQuery.toString(), params, types,
                new RowCallbackHandler() {
                    Integer rowIDCtr = 1;
                    public void processRow(ResultSet rs) throws SQLException {
                        ProgramContributionTier lProgramContributionTier = new ProgramContributionTier();
                        lProgramContributionTier.setProgramID(rs
                                .getInt("biz_pgm_id"));
                        lProgramContributionTier.setIncentiveOptionID(rs
                                .getInt("incntv_option_id"));
                        lProgramContributionTier.setActivityID(rs
                                .getInt("actv_id"));
                        lProgramContributionTier.setActivityName(rs
                                .getString("activity_name"));
                        lProgramContributionTier.setActivityTypeCodeID(rs
                                .getInt("actv_tp_cd_id"));
                        lProgramContributionTier.setActivityTypeCode(rs
                                .getString("activity_type"));
                        lProgramContributionTier.setTierContributionID(rs
                                .getInt("tier_contrib_id"));
                        lProgramContributionTier.setActivityIncentiveID(rs
                                .getInt("actv_incntv_id"));
                        lProgramContributionTier.setTierTypeID(rs
                                .getInt("tier_tp_id"));
                        lProgramContributionTier.setTierValueID(rs
                                .getInt("tier_value_id"));
                        lProgramContributionTier.setRelationshipCode(rs
                                .getInt("rel_cd"));
                        lProgramContributionTier.setRelationshipDesc(rs
                                .getString("relationshipDesc"));
                        lProgramContributionTier.setContributionAmount(rs
                                .getInt("contrib_amt"));
                        lProgramContributionTier.setBenefitContractTypeID(rs
                                .getInt("ben_contr_tp_lu_id"));
                        lProgramContributionTier.setBenefitContractType(rs
                                .getString("benefit_contract_type"));
                        lProgramContributionTier.setTierTypeName(rs
                                .getString("tier_tp_nm"));
                        lProgramContributionTier.setTierTypeDesc(rs
                                .getString("tier_tp_desc"));
                        lProgramContributionTier.setQualificationCheckmarkDetailID(rs
                                .getInt("qualfctn_chkmrk_detl_id"));
                        lProgramContributionTier.setRowID(rowIDCtr++);


                        lProgramContributionTiers.add(lProgramContributionTier);
                    }
                });

        // Determine if tier contribution id has a foreign key relationship from
        // parent to child.  In this case, cdhp fulfillment or reward fulfillment tables. If so, then
        // set flag to not allow a delete of the record.

        for (ProgramContributionTier lProgramContributionTier : lProgramContributionTiers) {
            boolean isUsed = determineUsedForContributionTierParentRelationshipToFulfillment(
                    lProgramContributionTier.getTierContributionID());
            if (isUsed) {
                lProgramContributionTier.setUsed(true);
            } else {
                lProgramContributionTier.setUsed(false);
            }
        }

        return lProgramContributionTiers;
    }


    /*
     * Determine if Activity Incentive Requirement is being used by the Program Tier Contribution grid.
     */
    @Override
    public boolean isActivityRequirementRegisteredToProgramTierContribution(ActivityIncentiveRequirement lActivityIncentiveRequirement) throws BPMException, DataAccessException {
        boolean isActivityRequirementRegisteredToProgramTierContribution = false;

        final ArrayList<Integer> result = new ArrayList<>();

        Integer programID = lActivityIncentiveRequirement.getProgramID();
        Integer incentiveOptionID = lActivityIncentiveRequirement.getIncentiveOptionID();
        Integer groupID = lActivityIncentiveRequirement.getGroupID();
        Integer groupRequirementID = lActivityIncentiveRequirement.getGroupRequirementID();

        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[]{programID,
                incentiveOptionID,
                groupID,
                groupRequirementID};
        int types[] = new int[]{Types.INTEGER,
                Types.INTEGER,
                Types.INTEGER,
                Types.INTEGER};


        template.query(countActivityRequirementRegisteredToProgramTierContribution, params, types, new RowCallbackHandler() {
            public void processRow(ResultSet rs) throws SQLException {

                result.add(rs.getInt("ticCount"));

            }
        });

        if (result.get(0) > 0) {
            isActivityRequirementRegisteredToProgramTierContribution = true;
        }

        return isActivityRequirementRegisteredToProgramTierContribution;
    }

    @Override
    public ArrayList<ContributionTierBenefitContractType> getAssignedContributionTierBenefitContractTypes(final Integer pTierTypeID, boolean isAllowRelationshipSelfOnly) throws BPMException, DataAccessException {
        final ArrayList<ContributionTierBenefitContractType> lContributionTierBenefitContractTypeList = new ArrayList<ContributionTierBenefitContractType>();

        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[] { pTierTypeID };
        int types[] = new int[] { Types.INTEGER };

        template.query(selectAssignedContributionTierBenefitContractTypes,
                params, types, new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        ContributionTierBenefitContractType lContributionTierBenefitContractType = new ContributionTierBenefitContractType();
                        lContributionTierBenefitContractType
                                .setTierTypeID(pTierTypeID);
                        lContributionTierBenefitContractType.setTierValueID(rs
                                .getInt("tier_value_id"));
                        lContributionTierBenefitContractType
                                .setBenefitContractTypeID(rs.getInt("lu_id"));
                        lContributionTierBenefitContractType.setLuvGroup(rs
                                .getString("lu_grp"));
                        lContributionTierBenefitContractType.setLuvValue(rs
                                .getString("lu_val"));
                        lContributionTierBenefitContractType.setLuvDesc(rs
                                .getString("lu_desc"));
                        lContributionTierBenefitContractTypeList
                                .add(lContributionTierBenefitContractType);
                    }
                });

        // Determine if tier value id has a foreign key relationship to
        // tier_contribution table. If so, then
        // set flag to not allow "remove" link to appear with the assigned
        // Benefit Contract Types.

        for (ContributionTierBenefitContractType lContributionTierBenefitContractType : lContributionTierBenefitContractTypeList) {
            boolean used = determineUsedForTierValueParentRelationshipToTierContribution(
                    pTierTypeID,
                    lContributionTierBenefitContractType
                            .getBenefitContractTypeID());
            lContributionTierBenefitContractType.setUsed(used);
            Integer pTierValueID = lContributionTierBenefitContractType
                    .getTierValueID();
            ArrayList<ContributionTierBenefitContractTypeRelationship> lContributionTierBenefitContractTypeRelationships = getContributionTierBenefitContractTypeRelationships(pTierValueID, isAllowRelationshipSelfOnly);
            lContributionTierBenefitContractType
                    .setContributionTierBenefitContractTypeRelationships(lContributionTierBenefitContractTypeRelationships);
        }

        return lContributionTierBenefitContractTypeList;
    }

    /*
     * Determine if tier value id has a foreign key relationship to
     * tier_contribution table using the tier type id as a search target. If so,
     * then set flag to not allow "remove" link to appear with the assigned
     * Benefit Contract Types. In other words when the tier value row has a
     * parent child relationship to another table, then user of the Contribution
     * Tier definition screen cannot remove the assigned benefit contract type.
     */
    //Produces warnings during compile time to quickly identify typos or API changes
    @Override
    public boolean determineUsedForTierValueParentRelationshipToTierContribution(Integer pTierTypeID, Integer pBenefitContractTypeID) throws DataAccessException {

        final ArrayList<Integer> results = new ArrayList<>();
        JdbcTemplate template = getJdbcTemplate();

        StringBuffer lQuery = new StringBuffer();
        lQuery.append(determineUsedForTierValueParentRelationshipToTierContribution);

        ArrayList<Object> lParameters = new ArrayList<>();
        ArrayList<Integer> lTypes = new ArrayList<>();

        lParameters.add(pTierTypeID);
        lTypes.add(Types.INTEGER);

        if (pBenefitContractTypeID != null) {
            lParameters.add(pBenefitContractTypeID);
            lTypes.add(Types.INTEGER);
            lQuery.append(" and t.ben_contr_tp_lu_id = ? ");
        }

        lQuery.append(" and exists (select * from tier_contribution tc where tc.tier_value_id = t.tier_value_id)");

        // Convert the parameter arraylists to arrays.
        Object params[] = new Object[lParameters.size()];
        lParameters.toArray(params);

        int types[] = new int[lTypes.size()];

        for (int j = 0; j < lTypes.size(); j++) {
            types[j] = ((Integer) lTypes.get(j)).intValue();
        }

        template.query(lQuery.toString(), params, types,
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        results.add(rs.getInt("tier_tp_id"));
                    }
                });

        boolean parentChildRelationship = false;
        if (results.size() > 0) {
            parentChildRelationship = true;

        }

        return parentChildRelationship;

    }

    @Override
    public ArrayList<ContributionTierBenefitContractTypeRelationship> getContributionTierBenefitContractTypeRelationships(final Integer pTierValueID, boolean isAllowRelationshipSelfOnly) throws BPMException, DataAccessException {
        StringBuffer lQuery = new StringBuffer();
        lQuery.append(selectContributionTierBenefitContractTypeRelationships);

        if (isAllowRelationshipSelfOnly) {
            lQuery.append(" AND p.rlshp_txt like '%SELF%' ");
        }


        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[] { pTierValueID };
        int types[] = new int[] { Types.INTEGER };

        final ArrayList<ContributionTierBenefitContractTypeRelationship> lContributionTierBenefitContractTypeRelationships = (ArrayList<ContributionTierBenefitContractTypeRelationship>) template
                .query(lQuery.toString(),
                        params,
                        types,
                        new contributionTierBenefitContractTypeRelationshipMapper());

        return lContributionTierBenefitContractTypeRelationships;
    }

    @Override
    public ArrayList<ContributionTier> getAllContributionTiers()
            throws DataAccessException {
        final ArrayList<ContributionTier> results = new ArrayList<ContributionTier>();

        JdbcTemplate template = getJdbcTemplate();
        Object params[] = new Object[] {};
        int types[] = new int[] {};
        template.query(selectContributionTiers, params, types,
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        ContributionTier lContributionTier = new ContributionTier();

                        lContributionTier.setTierTypeID(rs.getInt("tier_tp_id"));
                        lContributionTier.setTierTypeName(rs
                                .getInt("tier_tp_nm"));
                        lContributionTier.setTierTypeDesc(rs
                                .getString("tier_tp_desc"));
                        lContributionTier.setTierTypeInfo(rs
                                .getString("tier_type_info"));

                        results.add(lContributionTier);
                    }
                });

        // Determine if tier value id has a foreign key relationship to
        // tier_contribution table. If so, then
        // set flag to not allow a delete of the record.
        if (results.size() > 0) {
            for (ContributionTier lContributionTier : results) {
                boolean isUsed = determineUsedForTierValueParentRelationshipToTierContribution(
                        lContributionTier.getTierTypeID(), null);
                if (isUsed) {
                    lContributionTier.setUsed(true);
                } else {
                    lContributionTier.setUsed(false);
                }
            }
        }

        return results;
    }

    @Override
    public int deleteProgramContributionTier(Integer lTierContributionID) throws BPMException, DataAccessException {
        JdbcTemplate template = getJdbcTemplate();
        int rowInserted = 0;

        Object params[] = new Object[]{lTierContributionID};

        int types[] = new int[]{Types.INTEGER};

        rowInserted = template.update(deleteProgramContributionTier, params, types);

        return rowInserted;
    }

    @Override
    public int deleteProgramContributionIncentiveTier(Integer lTierContributionID) throws BPMException, DataAccessException {
        JdbcTemplate template = getJdbcTemplate();
        int rowInserted = 0;

        Object params[] = new Object[] { lTierContributionID };

        int types[] = new int[] { Types.INTEGER };

        rowInserted = template.update(deleteProgramContributionIncentiveTier, params, types);

        return rowInserted;
    }

    /**
     * Method maintains the tier_contribution and tier_incentive_contribution tables for incented contributions.
     */
    @Override
    public int updateProgramContributionTier(
            Integer activityIncentiveID, Integer groupID, Integer groupRequiredID, Integer qualificationCheckmarkDetailID,
            ProgramContributionTier pProgramContributionTier,
            String pModifyUserID) throws BPMException, DataAccessException {

        JdbcTemplate template = getJdbcTemplate();

        Integer rowInserted = 0;

        if (pProgramContributionTier.getTierContributionID() == null) {
            Long tierContribID = this.insertProgramContributionTier(pProgramContributionTier, pModifyUserID);
            rowInserted = this.insertProgramContributionIncentiveTier(tierContribID, activityIncentiveID, groupID, groupRequiredID, qualificationCheckmarkDetailID, pProgramContributionTier, pModifyUserID);
        } else {
            Object params[] = new Object[] {
                    pProgramContributionTier.getTierTypeID(),
                    pProgramContributionTier.getTierValueID(),
                    pProgramContributionTier.getRelationshipCode(),
                    pProgramContributionTier.getContributionAmount(),
                    pModifyUserID,
                    pProgramContributionTier.getTierContributionID() };

            int types[] = new int[] { Types.INTEGER, Types.INTEGER,
                    Types.INTEGER, Types.INTEGER, Types.VARCHAR, Types.INTEGER };

            rowInserted = template.update(updateProgramContributionTier, params, types);
        }

        return rowInserted;
    }

    @Override
    public Long insertProgramContributionTier(ProgramContributionTier pProgramContributionTier, String pInsertUserID) throws BPMException, DataAccessException {
        Long tierContributionID = new Long(tierContributionIDIncrementer.nextLongValue());

        JdbcTemplate template = getJdbcTemplate();
        int rowInserted = 0;

        Object params[] = new Object[] { tierContributionID,
                pProgramContributionTier.getTierTypeID(),
                pProgramContributionTier.getTierValueID(),
                pProgramContributionTier.getProgramID(),
                pProgramContributionTier.getRelationshipCode(),
                pProgramContributionTier.getContributionAmount(), pInsertUserID };

        int types[] = new int[] { Types.INTEGER, Types.INTEGER, Types.INTEGER,
                Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.VARCHAR };

        template.update(insertProgramContributionTier, params, types);

        return tierContributionID;
    }

    @Override
    public int insertProgramContributionIncentiveTier(Long tierContribID,
                                                      Integer activityIncentiveID, Integer groupID, Integer groupRequiredID, Integer qualificationCheckmarkDetailID,
                                                      ProgramContributionTier pProgramContributionTier,
                                                      String pModifyUserID) throws BPMException, DataAccessException {

        JdbcTemplate template = getJdbcTemplate();
        int rowInserted = 0;

        if (activityIncentiveID != null && activityIncentiveID.intValue() <= 0) {
            activityIncentiveID = null;

        }

        Object params[] = new Object[] { tierContribID,
                activityIncentiveID,
                pProgramContributionTier.getProgramID(),
                pProgramContributionTier.getIncentiveOptionID(),
                groupID,
                groupRequiredID, qualificationCheckmarkDetailID, pModifyUserID };

        int types[] = new int[] { Types.INTEGER, Types.INTEGER, Types.INTEGER,
                Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.VARCHAR };

        rowInserted = template.update(insertProgramContributionIncentiveTier, params, types);

        return rowInserted;
    }

    private static final class contributionTierBenefitContractTypeRelationshipMapper implements RowMapper {
        public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
            ContributionTierBenefitContractTypeRelationship lContributionTierBenefitContractTypeRelationship = new ContributionTierBenefitContractTypeRelationship();

            lContributionTierBenefitContractTypeRelationship
                    .setTierValueRelationshipID(rs.getInt("TIER_VALUE_REL_ID"));
            lContributionTierBenefitContractTypeRelationship.setTierValueID(rs
                    .getInt("TIER_VALUE_ID"));
            lContributionTierBenefitContractTypeRelationship
                    .setRelationshipCode(rs.getInt("RLSHP_CD"));
            lContributionTierBenefitContractTypeRelationship
                    .setRelationshipDesc(rs.getString("RLSHP_TXT"));
            lContributionTierBenefitContractTypeRelationship.setInsertDate(rs
                    .getDate("INSERT_TS"));
            lContributionTierBenefitContractTypeRelationship.setModifyDate(rs
                    .getDate("MODIFY_TS"));
            lContributionTierBenefitContractTypeRelationship.setInsertUser(rs
                    .getString("INSERT_USR"));
            lContributionTierBenefitContractTypeRelationship.setModifyUser(rs
                    .getString("MODIFY_USR"));

            return lContributionTierBenefitContractTypeRelationship;
        }
    }

    /*
     * Determine if tier contribution id has a foreign key relationship to
     * the cdhp fulfillment table using the tier_contrib_id as a search target. If so,
     * then set flag to not allow "remove" link to appear with the assigned
     * Benefit Contract Type Amount.
     */
    private boolean determineUsedForContributionTierParentRelationshipToCDHPFulfillment(
            Integer pTierContributionID)
            throws DataAccessException {

        final ArrayList<Integer> results = new ArrayList<Integer>();
        JdbcTemplate template = getJdbcTemplate();

        StringBuffer lQuery = new StringBuffer();
        lQuery.append(determineUsedForContributionTierParentRelationshipToCDHPFulfillment);

        ArrayList<Object> lParameters = new ArrayList<Object>();
        ArrayList<Integer> lTypes = new ArrayList<Integer>();

        lParameters.add(pTierContributionID);
        lTypes.add(Integer.valueOf(Types.INTEGER));


        // Convert the parameter arraylists to arrays.
        Object params[] = new Object[lParameters.size()];
        lParameters.toArray(params);

        int types[] = new int[lTypes.size()];

        for (int j = 0; j < lTypes.size(); j++) {
            types[j] = ((Integer) lTypes.get(j)).intValue();
        }

        template.query(lQuery.toString(), params, types,
                new RowCallbackHandler() {
                    public void processRow(ResultSet rs) throws SQLException {
                        results.add(rs.getInt("tier_contrib_id"));
                    }
                });

        boolean parentChildRelationship = false;
        if (results.size() > 0) {
            parentChildRelationship = true;

        }

        return parentChildRelationship;

    }
}
