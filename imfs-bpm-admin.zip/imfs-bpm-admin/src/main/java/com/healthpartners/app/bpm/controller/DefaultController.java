package com.healthpartners.app.bpm.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import jakarta.servlet.http.HttpServletRequest;

@Controller
public class DefaultController {
    
    @GetMapping("/")
    public String landing(HttpServletRequest request) {
        return "index";
    }

    @GetMapping("/index")
    public String index(HttpServletRequest request, Model model) {
        return "index";
    }
}
