package com.healthpartners.app.bpm.form;


import com.healthpartners.app.bpm.dto.LookUpValueCode;

import java.util.ArrayList;
import java.util.Collection;

/**
 * @author jxbourbour
 *
 */
public class CDHPFulfillmentSearchForm extends BaseForm {

    private String groupNumber;
    private String groupName;
    private String siteNumber;
    private String effectiveDate;
    private String fileSentFromDate;
    private String fileSentToDate;
    private String actionType;
    private String contractNumber;
    private String memberNumber;
    private String productType;
    private String cdhpTableType;


    private String whichList;

    private Integer groupID;

    Collection<LookUpValueCode> luvProductTypes = new ArrayList<>();

    Collection<LookUpValueCode> luvCdhpTableTypes = new ArrayList<>();

    public CDHPFulfillmentSearchForm() {
        super();
    }


//	public ActionMessages validateSearch(ActionMapping mapping,
//			HttpServletRequest request)
//	{
//
//
//	    if (!effectiveDate.isEmpty()) {
//	    	this.validateDateFormat("Program Year Effective Date", effectiveDate, "Program Year Effective Date");
//	    }
//
//
//	    if (!fileSentFromDate.isEmpty()) {
//	    	this.validateDateFormat("File Sent From Date", fileSentFromDate, "File Sent From Date");
//	    }
//	    if (!fileSentToDate.isEmpty()) {
//	    	this.validateDateFormat("File Sent To Date", fileSentToDate, "File Sent To Date");
//	    }
//	    this.validateNotNull("Product Type", productType, " Product Type");
//	    this.validateNotNull("CDHP Table Type", cdhpTableType, " CDHP Table Type");
//
//
//	    validateNotSpecialChar("groupNumber", groupNumber, "Group No");
//	    validateNotSpecialChar("groupName", groupName, "Group Name");
//	    validateNotSpecialChar("siteNumber", siteNumber, "Site No");
//
//		if (!contractNumber.isEmpty()) {
//			validateNotInteger("contractNumber", contractNumber, "Contract No");
//		}
//
//		return getActionMessages();
//	}


    public String getGroupNumber() {
        return groupNumber;
    }


    public void setGroupNumber(String groupNumber) {
        this.groupNumber = groupNumber;
    }

    public String getActionType() {
        return actionType;
    }


    public void setActionType(String actionType) {
        this.actionType = actionType;
    }


    public final String getGroupName() {
        return groupName;
    }


    public final void setGroupName(String groupName) {
        this.groupName = groupName;
    }


    public final String getSiteNumber() {
        return siteNumber;
    }


    public final void setSiteNumber(String siteNumber) {
        this.siteNumber = siteNumber;
    }


    public final String getEffectiveDate() {
        return effectiveDate;
    }


    public final void setEffectiveDate(String effectiveDate) {
        this.effectiveDate = effectiveDate;
    }


    public final String getWhichList() {
        return whichList;
    }


    public final void setWhichList(String whichList) {
        this.whichList = whichList;
    }


    public String getFileSentFromDate() {
        return fileSentFromDate;
    }


    public void setFileSentFromDate(String fileSentFromDate) {
        this.fileSentFromDate = fileSentFromDate;
    }


    public String getFileSentToDate() {
        return fileSentToDate;
    }


    public void setFileSentToDate(String fileSentToDate) {
        this.fileSentToDate = fileSentToDate;
    }


    public String getContractNumber() {
        return contractNumber;
    }


    public void setContractNumber(String contractNumber) {
        this.contractNumber = contractNumber;
    }


    public String getMemberNumber() {
        if (memberNumber != null) {
            return memberNumber.trim();
        }
        return memberNumber;
    }


    public void setMemberNumber(String memberNumber) {
        this.memberNumber = memberNumber;
    }


    public String getProductType() {
        return productType;
    }


    public void setProductType(String productType) {
        this.productType = productType;
    }


    public String getCdhpTableType() {
        return cdhpTableType;
    }


    public void setCdhpTableType(String cdhpTableType) {
        this.cdhpTableType = cdhpTableType;
    }

    public Integer getGroupID() {
        return groupID;
    }

    public void setGroupID(Integer groupID) {
        this.groupID = groupID;
    }

    public Collection<LookUpValueCode> getLuvProductTypes() {
        return luvProductTypes;
    }

    public void setLuvProductTypes(Collection<LookUpValueCode> luvProductTypes) {
        this.luvProductTypes = luvProductTypes;
    }

    public Collection<LookUpValueCode> getLuvCdhpTableTypes() {
        return luvCdhpTableTypes;
    }

    public void setLuvCdhpTableTypes(Collection<LookUpValueCode> luvCdhpTableTypes) {
        this.luvCdhpTableTypes = luvCdhpTableTypes;
    }
}
