package com.healthpartners.app.bpm.dto;

import com.healthpartners.app.bpm.common.BPMAdminConstants;

import java.io.Serializable;
import java.text.SimpleDateFormat;

/**
 * @author jxbourbour
 * 
 */
public class MemberStatusDetail implements Serializable {

	static final long serialVersionUID = 0L;

	private Integer personDemographicsID;
	private String memberID;
	private Integer programID;
	private Integer programIncentiveOptionID;
	private String incentiveOptionName;

	private Integer contractNumber;

	private Integer contractStatusCodeID;
	private String contractStatusCodeValue;

	private Integer memberProgramStatusCodeID;
	private String memberProgramStatusCodeValue;			
	
	private java.sql.Date memberStatusDate;
	private java.sql.Date contractStatusDate;				        
    
	private Integer programCheckmarkID;
    private String qualificationCheckmarkName;
    
    private String programIncentedType;
    private Boolean havingManualExemption;    		
    
	
	SimpleDateFormat fmt = new SimpleDateFormat(
			BPMAdminConstants.HP_BPM_ADMIN_UI_COMMON_DATE_FORMAT);
		

	public MemberStatusDetail() {
		super();
	}
	
	public boolean isHavingManualExemption() {
		return havingManualExemption;
	}
	
	

	public Integer getContractNumber() {
		return contractNumber;
	}

	public void setContractNumber(Integer contractNumber) {
		this.contractNumber = contractNumber;
	}

	public String getContractStatusCodeValue() {
		return contractStatusCodeValue;
	}

	public void setContractStatusCodeValue(String contractStatusCodeValue) {
		this.contractStatusCodeValue = contractStatusCodeValue;
	}

	public Integer getPersonDemographicsID() {
		return personDemographicsID;
	}

	public void setPersonDemographicsID(Integer personDemographicsID) {
		this.personDemographicsID = personDemographicsID;
	}

	public String getMemberID() {
		return memberID;
	}

	public void setMemberID(String memberID) {
		this.memberID = memberID;
	}

	public Integer getProgramID() {
		return programID;
	}

	public void setProgramID(Integer programID) {
		this.programID = programID;
	}

	public Integer getProgramIncentiveOptionID() {
		return programIncentiveOptionID;
	}

	public void setProgramIncentiveOptionID(Integer programIncentiveOptionID) {
		this.programIncentiveOptionID = programIncentiveOptionID;
	}	

	public Integer getContractStatusCodeID() {
		return contractStatusCodeID;
	}

	public void setContractStatusCodeID(Integer contractStatusCodeID) {
		this.contractStatusCodeID = contractStatusCodeID;
	}

	public Integer getMemberProgramStatusCodeID() {
		return memberProgramStatusCodeID;
	}

	public void setMemberProgramStatusCodeID(Integer memberProgramStatusCodeID) {
		this.memberProgramStatusCodeID = memberProgramStatusCodeID;
	}

	public String getMemberProgramStatusCodeValue() {
		return memberProgramStatusCodeValue;
	}

	public void setMemberProgramStatusCodeValue(String memberProgramStatusCodeValue) {
		this.memberProgramStatusCodeValue = memberProgramStatusCodeValue;
	}

	public java.sql.Date getMemberStatusDate() {
		return memberStatusDate;
	}

	public void setMemberStatusDate(java.sql.Date memberStatusDate) {
		this.memberStatusDate = memberStatusDate;
	}

	public java.sql.Date getContractStatusDate() {
		return contractStatusDate;
	}

	public void setContractStatusDate(java.sql.Date contractStatusDate) {
		this.contractStatusDate = contractStatusDate;
	}

	public Integer getProgramCheckmarkID() {
		return programCheckmarkID;
	}

	public void setProgramCheckmarkID(Integer programCheckmarkID) {
		this.programCheckmarkID = programCheckmarkID;
	}

	public String getQualificationCheckmarkName() {
		return qualificationCheckmarkName;
	}

	public void setQualificationCheckmarkName(String qualificationCheckmarkName) {
		this.qualificationCheckmarkName = qualificationCheckmarkName;
	}

	public String getIncentiveOptionName() {
		return incentiveOptionName;
	}

	public void setIncentiveOptionName(String incentiveOptionName) {
		this.incentiveOptionName = incentiveOptionName;
	}

	public String getProgramIncentedType() {
		return programIncentedType;
	}

	public void setProgramIncentedType(String programIncentedType) {
		this.programIncentedType = programIncentedType;
	}

	public Boolean getHavingManualExemption() {
		return havingManualExemption;
	}

	public void setHavingManualExemption(Boolean havingManualExemption) {
		this.havingManualExemption = havingManualExemption;
	}

		
	
}
