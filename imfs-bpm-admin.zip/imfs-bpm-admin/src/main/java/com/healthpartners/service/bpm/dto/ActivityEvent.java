/**
 * 
 */
package com.healthpartners.service.bpm.dto;

/**
 * @author mxthoutam
 * 
 */
public class ActivityEvent extends BaseAuditableDTO {

	static final long serialVersionUID = 0L;

	private Long activityEventLogID;

	private String memberID;
	
	private MemberActivity memberActivity;

	private String sourceSystemID;

	private String processingStatusValue;
	
	
	/**
	 * 
	 */
	public ActivityEvent() {
		super();
	}

	/**
	 * @return the activityDefinition
	 */
	public MemberActivity getMemberActivity() {
		return this.memberActivity;
	}

	/**
	 * @param activityDefinition
	 *            the activityDefinition to set
	 */
	public void setMemberActivity(MemberActivity memberActivity) {
		this.memberActivity = memberActivity;
	}

	/**
	 * @return the activityEventLogID
	 */
	public Long getActivityEventLogID() {
		return activityEventLogID;
	}

	/**
	 * @param activityEventLogID
	 *            the activityEventLogID to set
	 */
	public void setActivityEventLogID(Long activityEventLogID) {
		this.activityEventLogID = activityEventLogID;
	}


	/**
	 * @return the processingStatusValue
	 */
	public String getProcessingStatusValue() {
		return processingStatusValue;
	}

	/**
	 * @param processingStatusValue
	 *            the processingStatusValue to set
	 */
	public void setProcessingStatusValue(String processingStatusValue) {
		this.processingStatusValue = processingStatusValue;
	}

	/**
	 * @return the sourceSystemID
	 */
	public String getSourceSystemID() {
		return sourceSystemID;
	}

	/**
	 * @param sourceSystemID the sourceSystemID to set
	 */
	public void setSourceSystemID(String sourceSystemID) {
		this.sourceSystemID = sourceSystemID;
	}


	public String getMemberID() {
		return memberID;
	}

	public void setMemberID(String memberID) {
		this.memberID = memberID;
	}

}
