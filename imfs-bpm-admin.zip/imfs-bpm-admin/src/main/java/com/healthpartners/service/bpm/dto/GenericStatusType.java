/* $Id$ */

package com.healthpartners.service.bpm.dto;

import java.io.Serializable;

/**
 * Represents a Business status or Member status.
 * 
 * @author pbhenninger
 */
public class GenericStatusType implements Serializable {

	static final long serialVersionUID = 0L;

	private int statusCodeID;

	private String statusCodeValue;

	private String statusCodeDesc;

	private java.util.Date statusEffectiveDate;

	private int statusReasonCodeID;

	private String statusReasonValue;

	private String statusReasonDesc;

	private String statusApprover;

	private String outCome;

	public GenericStatusType() {
		super();
	}

	public String getOutCome() {
		return outCome;
	}

	public void setOutCome(String outCome) {
		this.outCome = outCome;
	}

	public void setOutCome(String[] outComes) {
		if (outComes != null && outComes.length > 0) {
			StringBuffer sb = new StringBuffer();
			for (int i = 0; i < outComes.length; i++) {
				if (i > 0) {
					sb.append(",");
				}
				sb.append(outComes[i].trim());
			}
			this.outCome = sb.toString();
		}
	}

	public String getStatusApprover() {
		return statusApprover;
	}

	public void setStatusApprover(String statusApprover) {
		this.statusApprover = statusApprover;
	}

	public String getStatusCodeDesc() {
		return statusCodeDesc;
	}

	public void setStatusCodeDesc(String statusCodeDesc) {
		this.statusCodeDesc = statusCodeDesc;
	}

	public int getStatusCodeID() {
		return statusCodeID;
	}

	public void setStatusCodeID(int statusCodeID) {
		this.statusCodeID = statusCodeID;
	}

	public String getStatusCodeValue() {
		return statusCodeValue;
	}

	public void setStatusCodeValue(String statusCodeValue) {
		this.statusCodeValue = statusCodeValue;
	}
	

	public int getStatusReasonCodeID() {
		return statusReasonCodeID;
	}

	public void setStatusReasonCodeID(int statusReasonCodeID) {
		this.statusReasonCodeID = statusReasonCodeID;
	}

	public String getStatusReasonDesc() {
		return statusReasonDesc;
	}

	public void setStatusReasonDesc(String statusReasonDesc) {
		this.statusReasonDesc = statusReasonDesc;
	}

	public String getStatusReasonValue() {
		return statusReasonValue;
	}

	public void setStatusReasonValue(String statusReasonValue) {
		this.statusReasonValue = statusReasonValue;
	}

	public final java.util.Date getStatusEffectiveDate() {
		return statusEffectiveDate;
	}

	public final void setStatusEffectiveDate(java.util.Date statusEffectiveDate) {
		this.statusEffectiveDate = statusEffectiveDate;
	}
	
}
