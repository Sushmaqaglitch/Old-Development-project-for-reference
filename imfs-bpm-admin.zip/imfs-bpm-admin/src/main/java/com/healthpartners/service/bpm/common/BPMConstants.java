/* $Id$ */

package com.healthpartners.service.bpm.common;

/**
 * Common constants for the BPM project.
 * 
 * @author pbhenninger
 */

public interface BPMConstants {

	// BPM types/groups in LUV table
	public static final String BPM_TYPE_MEMBER_STATUS = "BPM_MEMBER_STATUS";

	public static final String BPM_TYPE_MEMBER_STATUS_REASON = "BPM_MEMBER_STATUSRSN";

	public static final String BPM_TYPE_CONTRACT_STATUS = "BPM_CONTRACT_STATUS";
	
	public static final String BPM_TYPE_RECYCLE_STATUS = "BPM_RECYCLE_STATUS";
	
	public static final String REWARD_FULFILL_RECYCLE_STATUS = "REWARD_RECYCLE_STAT";
	
	public static final String BPM_CDHP_RECYCLE_STATUS = "CDHP_RECYCLE_STATUS";
	
	//Member Contract History Results
	public static final String BPM_CONTRACT_HIST_RESULT = "CONTRACTHISTRESULT";
	public static final String BPM_CONTRACT_HIST_RESULT_ALL = "ALL";
	public static final String BPM_CONTRACT_HIST_RESULT_CURRENT = "CURRENT";
	
	public static final String BPM_TYPE_EMPL_RECYCLE_STATUS = "EMPL_RECYCLE_STATUS";

	public static final String BPM_TYPE_OVERRIDE = "BPM_OVRD_TP";

	public static final String BPM_TYPE_ACTIVITY_STATUS = "BPM_ACTIVITY_STATUS";

	public static final String BPM_TYPE_ACTIVITY_STATUS_OUTCOME = "BPM_ACT_STS_OUTCOME";

	public static final String BPM_TYPE_ACTIVITY_TYPE = "BPM_ACTIVITY_TP";

	public static final String BPM_TYPE_BPM_PROCESS = "BPM_PROCESS_TP";

	public static final String BPM_TYPE_BPM_PROCESS_STATUS = "BPM_PROCESS_STS_TP";
	
	public static final String BPM_ACTIVITY_EVENT_FILTERD_OUT_RSN = "BPM_FILTERD_OUT_RSN";

	// Activity Event/ Task / processing log  Processing Status
	public static final String PROCESSING_STATUS_PENDING = "PENDING";
	
	public static final String PROCESSING_STATUS_WAIVE = "WAIVE";
	public static final String PROCESSING_STATUS_ACTV_EXMPT = "ACTV_EXMPT";
	

	public static final String PROCESSING_STATUS_INPROCESS = "IN_PROCESS";

	public static final String PROCESSING_STATUS_COMPLETED = "COMPLETED";

	public static final String PROCESSING_STATUS_FILTERD_OUT = "FILTERD_OUT";

	public static final String PROCESSING_STATUS_FILTERD_IN = "FILTERD_IN";

	public static final String ALL_BENEFIT_YEARS = "ALL";

	// Qualification Override
	// This is automatic exemption
	public static final String OVERRIDE_CODE_EXEMPTION = "EXEMPTION";

	public static final String OVERRIDE_CODE_MANUAL_EXEMPTION = "MANUAL_EXEMPTION";
	
	public static final String OVERRIDE_CODE_MANUAL_ACTIVITYSTATUSOVERRIDE = "WAIVE";


	// Member Processing Status
	public static final String MEMBER_PROCESSING_STATUS_INPROCESS = "IN_PROCESS";

	public static final String MEMBER_PROCESSING_STATUS_COMPLETED = "COMPLETED";
	
	//Incentive type statuses
	
	public static final String BPM_INCENTED_STATUS_GROUP = "BPM_INCENTED_BASED";
	public static final String BPM_INCENTED_STATUS_TYPE_CONTRACT_BASED = "CONTRACT_BASED";
	public static final String BPM_INCENTED_STATUS_TYPE_MEMBER_BASED = "MEMBER_BASED";
    public static final String BPM_INCENTED_STATUS_TYPE_ACTIVITY_BASED = "ACTIVITY_BASED";
    public static final String BPM_INCENTED_STATUS_TYPE_ACTIVITY_PACKAGE_BASED = "ACTIVITY_PKGE_BASED";
    public static final String BPM_INCENTED_STATUS_TYPE_MULTI_ACTIVITY = "MULTI_ACTIVITY"; 
    
  //Upload Employer Tracking Status
    public static final String UPL_EMPL_TRACK_STAT_GROUP = "UPL_EMPL_TRACK_STAT";
  	public static final String UPL_EMPL_PREPROCESS_STATUS = "PREPROCESS";
  	public static final String UPL_EMPL_INPROCESS_STATUS = "INPROCESS";
  	public static final String UPL_EMPL_POSTPROCESS_STATUS = "POSTPROCESS";
  	public static final String UPL_EMPL_SUBMITTED_STATUS = "Submitted";
  	public static final String UPL_EMPL_SUBMIT_STATUS = "Submit";

	// Rule Set Names
	public static final String RULESET_NAME_MEMBER_STATUS = "memberStatusRules";

	public static final String RULESET_NAME_CONTRACT_STATUS = "ContractStatusRuleSet";

	public static final String RULESET_NAME_MEMBER_EXEMPTION = "MemberExemptionRuleSet";

	public static final String RULESET_NAME_MEMBER_GOLDPASS = "MemberGoldpassRuleSet";

	// Member Program Statuses
	public static final String MEMBER_STATUS_NEW = "NEW";

	public static final String MEMBER_STATUS_HOLD_FOR_CONTACT = "HOLD_FOR_CONTACT";

	public static final String MEMBER_STATUS_HA_COMPLETED = "HA_COMPLETED";

	public static final String MEMBER_STATUS_ACTIVE = "ACTIVE";

	public static final String MEMBER_STATUS_QUALIFIED = "QUALIFIED";

	public static final String MEMBER_STATUS_DID_NOT_QUALIFY = "DID_NOT_QUALIFY";

	public static final String MEMBER_STATUS_EXEMPT = "EXEMPT";

	public static final String MEMBER_STATUS_NOT_REQUIRED = "NOT_REQUIRED";

	public static final String MEMBER_STATUS_HA_PENDING = "HA_PENDING";

	public static final String MEMBER_STATUS_ELIGIBLE = "ELIGIBLE";

	// Member Status Reasons
	public static final String MEMBER_STATUS_RSN_CONTACT_TIMEOUT = "CONTACT_TIMEOUT";

	public static final String MEMBER_STATUS_RSN_HIGH_RISK = "RISK";

	public static final String MEMBER_STATUS_RSN_NEW_CONTRACT = "NEW_CONTRACT";

	public static final String MEMBER_STATUS_RSN_REINSTATEMENT = "REINSTATEMENT";

	public static final String MEMBER_STATUS_RSN_SERIOUSLY_ILL = "SERIOUSLY_ILL";

	public static final String MEMBER_STATUS_RSN_EMPLOYER_DISCRETION = "EMPLOYER_DISCRETION";

	public static final String MEMBER_STATUS_RSN_APPEAL = "APPEAL";

	public static final String MEMBER_STATUS_RSN_QUAL_WINDOW_CLOSED = "WINDOW_CLOSED";

	public static final String MEMBER_STATUS_RSN_NEW_ON_CONTRACT = "NEW_ON_CONTRACT";

	public static final String MEMBER_STATUS_RSN_CONTRACT_GOLD_PASS = "CONTRACT_GOLD_PASS";

	// Program Participation Requirement
	public static final String BPM_PARTICIP_REQ_PH_ONLY = "PH_ONLY";

	public static final String BPM_PARTICIP_REQ_PH_AND_SPOUSE = "PH_AND_SPOUSE";

	public static final String BPM_PARTICIP_REQ_PH_AND_SPOUSE_OR_DOM = "PH_AND_SPOUSE_OR_DOM";

	// Activities
	public static final String ACTIVITY_HEALTHY_BENEFITS_HA = "Health Assessment";

	// contract status
	public static final String CONTRACT_STATUS_OPEN = "OPEN";

	public static final String CONTRACT_STATUS_QUALIFIED = "QUALIFIED";

	public static final String CONTRACT_STATUS_DID_NOT_QUALIFY = "DID_NOT_QUALIFY";

	public static final String CONTRACT_STATUS_GOLD_PASS = "GOLD_PASS";

	public static final String CONTRACT_STATUS_ELIGIBLE = "ELIGIBLE";

	// contract status reason - none in current requirements

	// Activity status
	public static final String ACTIVITY_STATUS_ACTIVE = "ACTIVE";

	public static final String ACTIVITY_STATUS_INACTIVE = "INACTIVE";

	public static final String ACTIVITY_STATUS_COMPLETE = "COMPLETE";

	public static final String ACTIVITY_STATUS_RECOMMENDED = "RECOMMENDED";

	public static final String ACTIVITY_STATUS_CANCELED = "CANCEL";

	public static final String ACTIVITY_STATUS_PENDING = "PENDING";

	public static final String ACTIVITY_STATUS_DELETE = "DELETE";

	// Activity Status outcome
	public static final String ACTIVITY_STATUS_OUTCOME_HIGH_RISK_DIABETES = "RISK_DIABETES";

	public static final String ACTIVITY_STATUS_OUTCOME_HIGH_RISK_CAD = "RISK_CAD";

	public static final String ACTIVITY_STATUS_OUTCOME_HIGH_RISK_DEPRESS = "RISK_DEPRESSION";

	public static final String ACTIVITY_STATUS_OUTCOME_HIGH_RISK_ALCOHOL = "RISK_ALCOHOL";

	public static final String ACTIVITY_STATUS_OUTCOME_GENERIC_RISK = "RISK";
	
	public static final String RISK_LUV_GROUP = "BPM_RISK_GROUP";
	
	public static final String RISK_GROUP_UNKNOWN = "UNKNOWN";

	// Activity Types
	public static final String ACTIVITY_TYPE_ONLINE_COURSE = "ONLINE";

	public static final String ACTIVITY_TYPE_DISEASE_MGMT = "DISEASE_MGMT";

	public static final String ACTIVITY_TYPE_PHONE_COURSE = "PHONE";

	public static final String ACTIVITY_TYPE_EMPLOYER_PGM = "EMPLOYER_PGM";

	// Relationship Types
	public static final String RELATIONSHIP_TYPE_SELF = "SELF";

	public static final String RELATIONSHIP_TYPE_SPOUSE = "SPOUSE";

	public static final String RELATIONSHIP_TYPE_DOMESTIC_PARTNER = "DOMESTIC PARTNER";

	public static final String RELATIONSHIP_TYPE_EX_SPOUSE = "EX-SPOUSE";

	public static final String BPM_TARGET_QUAL_YEAR_LUV = "BPM_TARGET_QUAL_YEAR";
	
	//Fulfillment routing types
	public static final String BPM_GRP_FLFLMNT_RTNG_TP = "FLFLMNT_RTNG_TP";
	public static final String BPM_VAL_FLFLMNT_RTNG_TP_SND_TO_MBRSHP = "SND_TO_MBRSHP";
	public static final String BPM_VAL_FLFLMNT_RTNG_TP_SND_TO_MBPB = "SND_TO_MBPB";
	public static final String BPM_VAL_FLFLMNT_RTNG_TP_SND_TO_INTELISPEND = "SND_TO_INTELISPEND";
	public static final String BPM_VAL_FLFLMNT_RTNG_TP_SND_TO_CDHP = "SND_TO_CDHP";
	
	
	//Program Types
	public static final String PROGRAM_TYPE_CODE_HEALTY_BENEFITS = "1";
	public static final String PROGRAM_TYPE_CODE_SMART_STEPS = "2";
	public static final String PROGRAM_TYPE_CODE_HIP = "3";
	public static final String PROGRAM_TYPE_CODE_JOURNEYWELL = "4";
	public static final String PROGRAM_TYPE_CODE_NEW_JOURNEYWELL = "5";


	// BPM system user
	public static final String BPM_USER_SYSTEM = "BPM";

	// Task status
	public static final String TASK_STATUS_ACTIVE = "ACTIVE";

	public static final String TASK_STATUS_INACTIVE = "INACTIVE";

	public static final String TASK_STATUS_COMPLETE = "COMPLETE";

	public static final String TASK_STATUS_CANCELED = "CANCELED";

	public static final String TASK_STATUS_DELETE = "DELETE";

	// Task ID
	public static final String TASK_ID_HA_FOLLOWUP_HBG = "FOLUP_HBG";

	public static final String TASK_ID_HA_FOLLOWUP_BHIO = "FOLUP_BHIO";

	// BPM process
	public static final String BPM_PROCESS_ACTIVITY_UPDATE = "ACTV_UPD";

	// BPM process status
	public static final String BPM_PROCESS_STATUS_IN_PROCESS = "IN_PROCESS";

	public static final String BPM_PROCESS_STATUS_COMPLETED = "COMPLETED";

	// Exemption / Gold pass reason
	public static final String BPM_EXEMPTION_REASON_JOINDT_AFTER_GRPNEWHIREDT = "Joined After Group's New Hire Date";
	public static final String BPM_EXEMPTION_REASON_TRANSFER_AFTER_GRPNEWHIREDT = "Site/Package Transfer After Group New Hire Date";

	public static final String BPM_EXEMPTION_REASON_CONTRACT_HAS_GOLDPASS = "Contract has Gold Pass";

	public static final String BPM_EXEMPTION_REASON_CONTRACTDT_AFTER_GRPNEWHIREDT = "Contract Date is After Group's New Hire Date";

	// constants for Timed out days for hold for contacts
	public static final int TASK_TIME_OUT_DAYS_HBG = 35; // 14;

	public static final int TASK_TIME_OUT_DAYS_BHIO = 35; // 21;

	public static final int HA_RISK_OUTCOME_TIME_OUT_DAYS = 7; // 2

	public static final int DISEASE_MGMT_ACTIVITY_COMPLETED_TIME_OUT_MONTHS = 5;

	public static final int DISEASE_MGMT_ACTIVITY_COMPLETED_TIME_OUT_DAYS = 150;

	public static final int DISEASE_MGMT_ACTIVITY_INACTIVE_GRACE_DAYS = 21;


	// elapsed time(time outs - hold for contact etc) sql file name to use for
	// xml and xls
//	public static final String MEMBER_ELAPSED_TIME_FILE_XML = "batchResources/memberElapsedTime.xml";
//
//	public static final String MEMBER_ELAPSED_TIME_FILE_XSL = "batchResources/memberElapsedTime.xsl";

	public static final Integer PERSON_PROCESS_TYPE_DEFULT = Integer.valueOf(1);

	public static final String XML_TRANSFORM_SAXON_IMPLEMENTATION = "net.sf.saxon.TransformerFactoryImpl";

	// emailing

	public static final String BPM_EMAIL_FROM_ADDR = "BPM_EMAIL_FROM_ADDR";
	

	public static final String EMPL_SPONSORED_TO_ADDR = "EMPL_SPNSRED_TO_ADDR";
	
	

	public static final String BPM_EMAIL_HOST_SRVR = "BPM_EMAIL_HOST_SRVR";
	
	public static final String BPM_DB_ENV = "BPM_ADMIN_DB_ENV";
	
	public static final String BPM_HISTORY_CONTRACT = "contract";
	public static final String BPM_HISTORY_SUBGROUP = "subgroup";
	public static final String BPM_HISTORY_PACKAGE = "package";
	
	public static final int ETL_MEMBERSHIP_UPDATE_PRCS_ID = 1;	
	public static final int MEMBERS_RECALCULATION_PRCS_ID = 2;	
	public static final int ETL_MEMBERSHIP_UPDATE_ONLY_PRCS_ID = 12;
	
	// audit
	public static final String RESULT_SUCCESS = "SUCCESS";
	public static final String RESULT_FAILURE = "FAILURE";
	
	public static final String AUDIT_APPEVENT_BPM_WEBSERVICE_GETACTIVEMESSAGECOUNT = "getActiveMessageCount";

	public static final String AUDIT_APPEVENT_BPM_WEBSERVICE_GETACTIVEMESSAGEHEADERS = "getActiveMessageHeaders";

	public static final String AUDIT_APPEVENT_BPM_WEBSERVICE_GETDELIVEREDMESSAGEHEADERS = "getDeliveredMessageHeaders";
	
	//Reward Card related
	//Reward Card Order Freq Definition Group
	public static final String REWARD_CARD_ORDER_FREQ = "REWARD_FRQNCY_ID";
}