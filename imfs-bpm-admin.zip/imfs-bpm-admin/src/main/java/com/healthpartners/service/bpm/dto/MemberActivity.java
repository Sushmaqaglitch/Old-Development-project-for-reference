package com.healthpartners.service.bpm.dto;

import java.io.Serializable;
import java.util.Calendar;

public class MemberActivity implements Serializable
{	
	static final long serialVersionUID = 0L;

	private ActivityDefinition activityDefinition;
	
//	 ActivityDefinition that has been completed or in progress attributes.
	private String registrationID;
	private Calendar registrationDate;
	private Calendar completionDate;
	private String qualificationStatus;
	private Calendar qualificationDate;
	
	private Integer businessProgramID;
	
	private GenericStatusType activityStatus;	
	
	private String authPromoCode;
	
	private GenericStatusType[] statusHistory;
		
	public MemberActivity()
	{
		super();
	}

	public ActivityDefinition getActivity() {
		return activityDefinition;
	}

	public void setActivity(ActivityDefinition activityDefinition) {
		this.activityDefinition = activityDefinition;
	}

	public GenericStatusType getActivityStatus() {
		return activityStatus;
	}


	public void setActivityStatus(GenericStatusType activityStatus) {
		this.activityStatus = activityStatus;
	}


	public Calendar getCompletionDate() {
		return completionDate;
	}


	public void setCompletionDate(Calendar completionDate) {
		this.completionDate = completionDate;
	}


	public Calendar getQualificationDate() {
		return qualificationDate;
	}


	public void setQualificationDate(Calendar qualificationDate) {
		this.qualificationDate = qualificationDate;
	}


	public String getQualificationStatus() {
		return qualificationStatus;
	}


	public void setQualificationStatus(String qualificationStatus) {
		this.qualificationStatus = qualificationStatus;
	}


	public Calendar getRegistrationDate() {
		return registrationDate;
	}


	public void setRegistrationDate(Calendar registrationDate) {
		this.registrationDate = registrationDate;
	}


	public String getRegistrationID() {
		return registrationID;
	}


	public void setRegistrationID(String registrationID) {
		this.registrationID = registrationID;
	}	

	public GenericStatusType[] getStatusHistory() {
		return statusHistory;
	}

	public void setStatusHistory(GenericStatusType[] statusHistory) {
		this.statusHistory = statusHistory;
	}

	public String getAuthPromoCode() {
		return authPromoCode;
	}

	public void setAuthPromoCode(String authPromoCode) {
		this.authPromoCode = authPromoCode;
	}	

	public Integer getBusinessProgramID() {
		return businessProgramID;
	}

	public void setBusinessProgramID(Integer businessProgramID) {
		this.businessProgramID = businessProgramID;
	}	
	
}
