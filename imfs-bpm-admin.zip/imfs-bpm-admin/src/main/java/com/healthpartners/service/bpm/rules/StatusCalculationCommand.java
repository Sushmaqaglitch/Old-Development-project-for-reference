/* $Id$ */

package com.healthpartners.service.bpm.rules;

import com.healthpartners.service.bpm.dto.ActivityEvent;
import com.healthpartners.service.bpm.dto.BaseDTO;
import com.healthpartners.service.bpm.dto.TaskEvent;

import java.util.HashMap;
import java.util.Map;

/**
 * @author mxthoutam
 * 
 */
public class StatusCalculationCommand extends BaseDTO {

	static final long serialVersionUID = 0L;

	public static final String ACTIVITY_EVENT = "ACTIVITY_EVENT";

	public static final String TASK_EVENT = "TASK_EVENT";

	public static final String PENDING_ACTIVITY_EVENTS = "PENDING_ACTIVITY_EVENTS";

	public static final String PENDING_TASK_EVENTS = "PENDING_TASK_EVENTS";

	public static final String ETL_MEMBERSHIP_UPDATE = "ETL_MEMBERSHIP_UPDATE";
	public static final String ETL_MEMBERSHIP_UPDATE_QUEUE = "ETL_MEMBERSHIP_UPDATE_QUEUE";
	public static final String ETL_MEMBERSHIP_UPDATE_ONLY = "ETL_MEMBERSHIP_ONLY";

//	public static final String MEMBER_ELAPSED_TIME = "MEMBER_ELAPSED_TIME";

	public static final String PARAM_BATCH_SIZE = "PARAM_BATCH_SIZE";

	public static final String ONE_PERSON = "ONE_PERSON";

	public static final String MEMBERS_RECALCULATION = "MEMBERS_RECALCULATION";

	public static final String MEMBERSHIP_FEED = "MEMBERSHIP_FEED";

	public static final String MEMBERSHIP_PREMIUM_BILLING_FEED = "MEMBERSHIP_PREMIUM_BILLING_FEED";
	
	public static final String CDHP_HRA_FULFILLMENT_REPORTING = "CDHP_HRA_FULFILLMENT";
	
    public static final String PURGE_AUDIT_LOG_TABLE = "PURGE_AUDITLOG_TABLE";
	
	public static final String PURGE_PROCESSLG_TABLE = "PURGE_PROCSTATLOG_TABLE";
	
	public static final String CONTRACT_RECONCILIATION = "CONTRACT_RECONCILIATION";
	
	public static final String EMPLOYER_GROUP_SITE_SETUP = "EMPLOYER_GROUP_SITE_SETUP";
	public static final String EMPLOYER_BASELINE_SETUP = "EMPLOYER_BASELINE_SETUP";
	public static final String AUTO_PROGRAM_NEW_SMARTSTEPS = "AUTO_PROGRAM_NEW_SMARTSTEPS";
	public static final String POPULATE_MISSING_PEOPLE = "POPULATE_MISSING_PEOPLE";
	public static final String UPLOAD_EMPLOYER_ACTIVITY_PREPROCESS = "UPLOAD_EMPLOYER_ACTIVITY_PREPROCESS";
	public static final String UPLOAD_EMPLOYER_ACTIVITY_POSTPROCESS = "UPLOAD_EMPLOYER_ACTIVITY_POSTPROCESS";
	public static final String EMPLOYER_ACTIVITY_PREPROCESS = "PREPROCESS";
	public static final String EMPLOYER_ACTIVITY_INPROCESS = "INPROCESS";
	public static final String DELETE_TERMED_PARTICIPANTS = "DELETE_TERMED_PARTICIPANTS";
	public static final String DELETE_TERMED_PARTICIPANTS_BY_GRP = "DELETE_TERMED_BY_GRP";
	public static final String POPULATE_PACKAGE_BASELINE = "POPULATE_PACKAGE_BASELINE";
	public static final String FILTERED_OUT_ACTIVITY_REPORT = "FILTERED_OUT_ACTIVITY_REPORT";
	public static final String AUTO_POPULATE_AUDIT_REPORT = "AUTO_POPULATE_AUDIT_REPORT";
	public static final String CORRECT_PURCHASER_SUBTYPE = "CORRECT_PURCHASER_SUBTYPE";
	public static final String EMPLOYER_ACTIVITY_END_TO_END_RECON = "EMPLOYER_ACTIVITY_END_TO_END_RECON";
	public static final String REPROCESS_MISSING_ACTIVITES = "REPROCESS_MISSING_ACTIVITES";
	

	// public static final String ALL_BUSINESS_PROGRAMS =
	// "ALL_BUSINESS_PROGRAMS";

	// public static final String ONE_BUSINESS_PROGRAM = "ONE_BUSINESS_PROGRAM";

	// map to store type of command
	private Map<String, Object> parametersMap = new HashMap<String, Object>();

	private String userID;

	private String processName;
	
	private String groupNo;
	
	private String siteNo;
	
	private String memberNo;
	
	private String startDate;

	// type of process - ex memberhip update etl job - 1, re-calculation-2,
	// admin membership update-11, admin re calc-12
	private Map<String, Integer> processIDsMap = new HashMap<String, Integer>();
	
	//used at the time of processing
	private String currentProcessingCommand;
	
	private String currentCommandText;

	public StatusCalculationCommand() { 
		super();
	}

	// / getParametersMap(), setParametersMap() are used in spring configuration
	// for Batch processing
	public Map<String, Object> getParametersMap() {
		return parametersMap;
	}

	public void setParametersMap(Map<String, Object> parametersMap) {
		this.parametersMap = parametersMap;
	}

	public Map<String, Integer> getProcessIDsMap() {
		return processIDsMap;
	}

	public void setProcessIDsMap(Map<String, Integer> processIDsMap) {
		this.processIDsMap = processIDsMap;
	}

	public String getUserID() {
		return userID;
	}

	public void setUserID(String userID) {
		this.userID = userID;
	}
	

	// ////Use public utility methods to set or get in all programs///////////
	public Object getParameter(String paramName) {
		return parametersMap.get(paramName);
	}

	public void setParameter(String paramName, Object value) {
		parametersMap.put(paramName, value);
	}

	private void setProcessID(String paramName, Integer processID) {
		processIDsMap.put(paramName, processID);
	}

	private Integer getProcessID(String paramName) {
		//default to zero
		Integer lProcessID = Integer.valueOf(0);
		if (processIDsMap.get(paramName) != null) {
			lProcessID = processIDsMap.get(paramName);
		}
		return lProcessID;
	}
	
	// /////////ALL Utility Methods///////////
	// 1. activity event
	public boolean isActivityEventCommand() {
		boolean result = parametersMap.containsKey(ACTIVITY_EVENT);
		return result;
	}

	public ActivityEvent getActivityEvent() {
		ActivityEvent activityEvent = null;
		if (isActivityEventCommand()) {
			activityEvent = (ActivityEvent) getParameter(StatusCalculationCommand.ACTIVITY_EVENT);
		}
		return activityEvent;
	}

	public void setActivityEventCommand(ActivityEvent activityEvent) {
		setParameter(ACTIVITY_EVENT, activityEvent);
	}

	// 2. task event
	public boolean isTaskEventCommand() {
		boolean result = parametersMap.containsKey(TASK_EVENT);
		return result;
	}

	public TaskEvent getTaskEvent() {
		TaskEvent taskEvent = null;
		if (isTaskEventCommand()) {
			taskEvent = (TaskEvent) getParameter(StatusCalculationCommand.TASK_EVENT);
		}
		return taskEvent;
	}

	public void setTaskEventCommand(TaskEvent taskEvent) {
		setParameter(TASK_EVENT, taskEvent);
	}

	// 3 pending activity events
	public boolean isPendingActivityEventsCommand() {
		boolean result = parametersMap.containsKey(PENDING_ACTIVITY_EVENTS);
		return result;
	}

	public void setPendingActivityEventsCommand() {
		setParameter(PENDING_ACTIVITY_EVENTS, PENDING_ACTIVITY_EVENTS);
	}

	// 4 pending task events
	public boolean isPendingTaskEventsCommand() {
		boolean result = parametersMap.containsKey(PENDING_TASK_EVENTS);
		return result;
	}

	public void setPendingTaskEventsCommand() {
		setParameter(PENDING_TASK_EVENTS, PENDING_TASK_EVENTS);
	}

	// 5. etl membership update
	public boolean isEtlMembershipUpdateCommand() {
		boolean result = parametersMap.containsKey(ETL_MEMBERSHIP_UPDATE);
		return result;
	}

	public boolean isCurrentProcessingEtlMembershipUpdateCommand() {
		boolean result = false;
		if(ETL_MEMBERSHIP_UPDATE.equalsIgnoreCase(currentProcessingCommand)){
			result = true;
		}
		return result;
	}

	public void setEtlMembershipUpdateCommand() {
		setParameter(ETL_MEMBERSHIP_UPDATE, ETL_MEMBERSHIP_UPDATE);
	}
	
	public void setEtlMembershipUpdateOnlyCommand() {
		setParameter(ETL_MEMBERSHIP_UPDATE_ONLY, ETL_MEMBERSHIP_UPDATE_ONLY);
	}

	public void setProcessIDForEtlMembershipUpdateCommand(Integer pProcessID) {
		setProcessID(ETL_MEMBERSHIP_UPDATE, pProcessID);
	}
	
	public void setProcessIDForEtlMembershipUpdateOnlyCommand(Integer pProcessID) {
		setProcessID(ETL_MEMBERSHIP_UPDATE_ONLY, pProcessID);
	}

	// 5. etl membership update queue
	public boolean isEtlMembershipUpdateQueueCommand() {
		boolean result = parametersMap.containsKey(ETL_MEMBERSHIP_UPDATE_QUEUE);
		return result;
	}

	public void setEtlMembershipUpdateQueueCommand() {
		setParameter(ETL_MEMBERSHIP_UPDATE_QUEUE, ETL_MEMBERSHIP_UPDATE_QUEUE);
	}
	

	// 6. elapsed time
//	public boolean isMemberElapsedTimeCommand() {
//		boolean result = parametersMap.containsKey(MEMBER_ELAPSED_TIME);
//		return result;
//	}

//	public void setMemberElapsedTimeCommand() {
//		setParameter(MEMBER_ELAPSED_TIME,
//				BPMConstants.MEMBER_ELAPSED_TIME_FILE_XML);
//	}

//	public void setProcessIDForMemberElapsedTimeCommand(Integer pProcessID) {
//		setProcessID(MEMBER_ELAPSED_TIME, pProcessID);
//	}
	
	
	public void setAutoProgramNewSmartStepsSetup()
	{
		setParameter(AUTO_PROGRAM_NEW_SMARTSTEPS, AUTO_PROGRAM_NEW_SMARTSTEPS);
	}
	
	public void setEmployerGoupSiteSetup()
	{
		setParameter(EMPLOYER_GROUP_SITE_SETUP, EMPLOYER_GROUP_SITE_SETUP);
	}

    public boolean isEmployerGroupSiteSetup() {
        boolean result = parametersMap.containsKey(EMPLOYER_GROUP_SITE_SETUP);
        return result;
    }
	
	public void setEmployerBaselineSetup()
	{
		setParameter(EMPLOYER_BASELINE_SETUP, EMPLOYER_BASELINE_SETUP);
	}

	public boolean isEmployerBaselineSetup() {
		boolean result = parametersMap.containsKey(EMPLOYER_BASELINE_SETUP);
		return result;
	}
	
	public void setPopulateMissingPeople()
	{
		setParameter(POPULATE_MISSING_PEOPLE, POPULATE_MISSING_PEOPLE);
	}
	public boolean isPopulateMissingPeople() {
		boolean result = parametersMap.containsKey(POPULATE_MISSING_PEOPLE);
		return result;
	}

	public void setUploadEmployerActivityPreprocess()
	{
		setParameter(UPLOAD_EMPLOYER_ACTIVITY_PREPROCESS, UPLOAD_EMPLOYER_ACTIVITY_PREPROCESS);
	}
	
	public boolean isUploadEmployerActivityPreprocess() {
		boolean result = parametersMap.containsKey(UPLOAD_EMPLOYER_ACTIVITY_PREPROCESS);
		return result;
	}
	
	public void setUploadEmployerActivityPostprocess()
	{
		setParameter(UPLOAD_EMPLOYER_ACTIVITY_POSTPROCESS, UPLOAD_EMPLOYER_ACTIVITY_POSTPROCESS);
	}

	public boolean isUploadEmployerActivityPostprocess() {
		boolean result = parametersMap.containsKey(UPLOAD_EMPLOYER_ACTIVITY_POSTPROCESS);
		return result;
	}
	
	public void setDeleteTermedParticipants()
	{
		setParameter(DELETE_TERMED_PARTICIPANTS, DELETE_TERMED_PARTICIPANTS);
	}
	public void setDeleteTermedByGroup()
	{
		setParameter(DELETE_TERMED_PARTICIPANTS_BY_GRP, DELETE_TERMED_PARTICIPANTS_BY_GRP);
	}
	public void setPopulatePackageBaseline()
	{
		setParameter(POPULATE_PACKAGE_BASELINE, POPULATE_PACKAGE_BASELINE);
	}

	public void setFilteredOutActivityReport()
	{
		setParameter(FILTERED_OUT_ACTIVITY_REPORT, FILTERED_OUT_ACTIVITY_REPORT);
	}
	
	public void setAutoPopulateAuditReport()
	{
		setParameter(AUTO_POPULATE_AUDIT_REPORT, AUTO_POPULATE_AUDIT_REPORT);
	}
	
	public void setCorrectPurchaserSubType()
	{
		setParameter(CORRECT_PURCHASER_SUBTYPE, CORRECT_PURCHASER_SUBTYPE);
	}
	
	// 7. one member
	public boolean isOnePersonCommand() {
		boolean result = parametersMap.containsKey(ONE_PERSON);
		return result;
	}

	public Integer getOnePersonID() {
		Integer personID = null;
		if (isOnePersonCommand()) {
			personID = (Integer) getParameter(StatusCalculationCommand.ONE_PERSON);
		}
		return personID;
	}

	public void setOnePersonCommand(Integer onePersonID) {
		setParameter(ONE_PERSON, onePersonID);
	}

	
	// 8. batch size
	public boolean isBatchSizeCommandSet() {
		boolean result = parametersMap.containsKey(PARAM_BATCH_SIZE);
		return result;
	}

	public Integer getBatchSize() {
		Integer batchSize = null;
		if (isBatchSizeCommandSet()) {
			batchSize = (Integer) getParameter(StatusCalculationCommand.PARAM_BATCH_SIZE);
		}
		return batchSize;
	}

	public void setBatchSizeCommand(Integer batchSize) {
		setParameter(PARAM_BATCH_SIZE, batchSize);
	}

	// 9 members recalculation commad \
	public boolean isMembersReCalculationCommand() {
		boolean result = parametersMap.containsKey(MEMBERS_RECALCULATION);
		return result;
	}

	public void setMembersReCalculationCommand() {
		setParameter(MEMBERS_RECALCULATION, MEMBERS_RECALCULATION);
	}

	public void setProcessIDForMembersReCalculationCommand(Integer pProcessID) {
		setProcessID(MEMBERS_RECALCULATION, pProcessID);
	}
	

	// 10 membership feed
	public boolean isMbrShipFeedCommand() {
		boolean result = parametersMap.containsKey(MEMBERSHIP_FEED);
		return result;
	}

	public void setMbrShipFeedCommand() {
		setParameter(MEMBERSHIP_FEED, MEMBERSHIP_FEED);
	}
	
	// 10 membership feed
	public boolean isMbrShipPremiumBillingFeedCommand() {
		boolean result = parametersMap.containsKey(MEMBERSHIP_PREMIUM_BILLING_FEED);
		return result;
	}

	public void setMbrShipPremiumBillingFeedCommand() {
		setParameter(MEMBERSHIP_PREMIUM_BILLING_FEED, MEMBERSHIP_PREMIUM_BILLING_FEED);
	}
	
	
	public boolean isHraFeedCommand() {
		boolean result = parametersMap.containsKey(CDHP_HRA_FULFILLMENT_REPORTING);
		return result;
	}
	
	public void setHraFulfillmentFeedCommand() {
		setParameter(CDHP_HRA_FULFILLMENT_REPORTING, CDHP_HRA_FULFILLMENT_REPORTING);
	}
	
	public boolean isPurgeAuditLogTableCommand()
	{
		
		boolean result = parametersMap.containsKey(PURGE_AUDIT_LOG_TABLE);
		return result;
	}
	
	public void setPurgeAuditLogTableCommand() {
		setParameter(PURGE_AUDIT_LOG_TABLE,
				PURGE_AUDIT_LOG_TABLE);
	}
	
	
	public boolean isPurgeProcessStatLogTableCommand()
	{		
		
		boolean result = parametersMap.containsKey(PURGE_PROCESSLG_TABLE);

		return result;
	}
	
	public void setPurgeProcessStatLogTableCommand() {
		setParameter(PURGE_PROCESSLG_TABLE,
				PURGE_PROCESSLG_TABLE);
	}
	
	
	public void setPersonContractHistReconciliationCommand() {
		setParameter(CONTRACT_RECONCILIATION,
				CONTRACT_RECONCILIATION);
	}

	// End to end activity reconciliation

	public void setEndToEndReconReportCommand() {
		setParameter(EMPLOYER_ACTIVITY_END_TO_END_RECON, EMPLOYER_ACTIVITY_END_TO_END_RECON);
	}

	public boolean isReprocessMissingActivitiesCommand() {
		boolean result = parametersMap.containsKey(REPROCESS_MISSING_ACTIVITES);
		return result;
	}
	
	public void setReprocessMissingActivities()
	{
		setParameter(REPROCESS_MISSING_ACTIVITES, REPROCESS_MISSING_ACTIVITES);
	}
	

	/**
	 * is it not batch commad?
	 * 
	 * @return boolean
	 */
	public boolean isNotABatchCommand() {
		// add any more types
		return (isActivityEventCommand() || isTaskEventCommand() || isOnePersonCommand());
	}

	/**
	 * is it batch commad?
	 * 
	 * @return boolean
	 */
	public boolean isBatchCommand() {
		// || isAllMembersCommand()
		// || isOneBusinessProgramCommand() || isAllBusinessProgramsCommand());
		return (isEtlMembershipUpdateCommand()
//				|| isMemberElapsedTimeCommand()
				|| isPendingActivityEventsCommand()
				|| isPendingTaskEventsCommand()
				|| isMembersReCalculationCommand() 
//				|| isMbrShipFeedCommand()
				|| isPurgeProcessStatLogTableCommand()
				|| isPurgeAuditLogTableCommand());
	}


	public String getProcessName() {
		return processName;
	}

	public void setProcessName(String processName) {
		this.processName = processName;
	}

	public String getCurrentProcessingCommand() {
		return currentProcessingCommand;
	}

	public void setCurrentProcessingCommand(String currentProcessingCommand) {
		this.currentProcessingCommand = currentProcessingCommand;
	}
	
	public void resetCurrentProcessingCommand() {
		this.currentProcessingCommand = null;
	}

	public Integer getProcessIDForCurrentProcessingCommand(){
		//default to zero
		Integer lProcessID = Integer.valueOf(0);
		if (currentProcessingCommand != null && processIDsMap.get(currentProcessingCommand) != null) {
			lProcessID = getProcessID(currentProcessingCommand);
		}
		return lProcessID;
	}
	
	public String getCurrentCommandText() {
		return currentCommandText;
	}

	public void setCurrentCommandText(String currentCommandText) {
		this.currentCommandText = currentCommandText;
	}

	public String getGroupNo() {
		return groupNo;
	}

	public void setGroupNo(String groupNo) {
		this.groupNo = groupNo;
	}

	public String getSiteNo() {
		return siteNo;
	}

	public void setSiteNo(String siteNo) {
		this.siteNo = siteNo;
	}

	public String getMemberNo() {
		return memberNo;
	}

	public void setMemberNo(String memberNo) {
		this.memberNo = memberNo;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	
	
	
	
	/*
	 * // 5. all programs commad public boolean isAllBusinessProgramsCommand() {
	 * boolean result = parametersMap.containsKey(ALL_BUSINESS_PROGRAMS); return
	 * result; } public void setAllBusinessProgramsCommand() {
	 * setParameter(ALL_BUSINESS_PROGRAMS, ALL_BUSINESS_PROGRAMS); } // 7. one
	 * program public boolean isOneBusinessProgramCommand() { boolean result =
	 * parametersMap.containsKey(ONE_BUSINESS_PROGRAM); return result; }
	 * 
	 * public Integer getOneBusinessProgramID() { Integer programID = null; if
	 * (isOneBusinessProgramCommand()) { programID = (Integer)
	 * getParameter(StatusCalculationCommand.ONE_BUSINESS_PROGRAM); } return
	 * programID; }
	 * 
	 * public void setOneBusinessProgramCommand(Integer oneProgramID) {
	 * setParameter(ONE_BUSINESS_PROGRAM, oneProgramID); }
	 */
}
