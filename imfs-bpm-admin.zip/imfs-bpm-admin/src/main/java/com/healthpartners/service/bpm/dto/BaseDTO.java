package com.healthpartners.service.bpm.dto;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import java.io.Serializable;

/**
 * Base DTO.
 * 
 */
public class BaseDTO implements Serializable {

	static final long serialVersionUID = 0L;
	
	public static final String ACTIVATE_STATUS = "ACTIVE";

	public BaseDTO() {
		super();
	}

	/**
	 * Overridden toString method.
	 * 
	 * @return A reflexively built string representation of this bean.
	 */
	public String toString() {
		return ReflectionToStringBuilder.reflectionToString(this,
				ToStringStyle.DEFAULT_STYLE); 
	}
}
