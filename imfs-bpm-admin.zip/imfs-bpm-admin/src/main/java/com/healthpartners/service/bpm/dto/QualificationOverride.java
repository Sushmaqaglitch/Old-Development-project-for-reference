/**
 * 
 */
package com.healthpartners.service.bpm.dto;

import java.util.Calendar;

/**
 * Used for member exemptions
 * @author mxthoutam
 * 
 */
public class QualificationOverride extends BaseAuditableDTO {

	static final long serialVersionUID = 0L;

	private Integer personID;

	private Integer programID;

	private String overrideType; // {BPM_TYPE_OVERRIDE,

	private String overrideCode; // BPMConstants.OVERRIDE_CODE_EXEMPTION,BPMConstants.OVERRIDE_CODE_GOLDPASS,

	private String reasonCode;

	private Calendar issueDate;
	
	private Integer contractNo;
	
	private java.sql.Date insertDate;
	private java.sql.Date modifyDate;
	private String insertUserId;
	private String modifyUserId;
	
	private Integer programIncentiveOptionID;
	private String incentiveOptionName;


	private Long id; // database id

	/**
	 * 
	 */
	public QualificationOverride() {
		super();
	}

	/**
	 * @param personID
	 * @param programID
	 * @param overrideType
	 * @param overrideCode
	 * @param reasonCode
	 */
	public QualificationOverride(Integer personID, Integer programID,
                                 String overrideType, String overrideCode, String reasonCode) {
		super();
		this.personID = personID;
		this.programID = programID;
		this.overrideType = overrideType;
		this.overrideCode = overrideCode;
		this.reasonCode = reasonCode;
		this.issueDate = Calendar.getInstance();
	}

	/**
	 * @param personID
	 * @param programID
	 * @param overrideType
	 * @param overrideCode
	 * @param reasonCode
	 * @param issueDate
	 */
	public QualificationOverride(Integer personID, Integer programID,
                                 String overrideType, String overrideCode, String reasonCode,
                                 Calendar issueDate) {
		super();
		this.personID = personID;
		this.programID = programID;
		this.overrideType = overrideType;
		this.overrideCode = overrideCode;
		this.reasonCode = reasonCode;
		this.issueDate = issueDate;
	}


	/**
	 * @return the overrideType
	 */
	public String getOverrideType() {
		return overrideType;
	}

	/**
	 * @param overrideType
	 *            the overrideType to set
	 */
	public void setOverrideType(String overrideType) {
		this.overrideType = overrideType;
	}

	/**
	 * @return the personID
	 */
	public Integer getPersonID() {
		return personID;
	}

	/**
	 * @param personID
	 *            the personID to set
	 */
	public void setPersonID(Integer personID) {
		this.personID = personID;
	}

	/**
	 * @return the programID
	 */
	public Integer getProgramID() {
		return programID;
	}

	/**
	 * @param programID
	 *            the programID to set
	 */
	public void setProgramID(Integer programID) {
		this.programID = programID;
	}

	/**
	 * @return the reasonCode
	 */
	public String getReasonCode() {
		return reasonCode;
	}

	/**
	 * @param reasonCode
	 *            the reasonCode to set
	 */
	public void setReasonCode(String reasonCode) {
		this.reasonCode = reasonCode;
	}

	/**
	 * @return the overrideCode
	 */
	public String getOverrideCode() {
		return overrideCode;
	}

	/**
	 * @param overrideCode
	 *            the overrideCode to set
	 */
	public void setOverrideCode(String overrideCode) {
		this.overrideCode = overrideCode;
	}

	/**
	 * @return the issueDate
	 */
	public Calendar getIssueDate() {
		return issueDate;
	}

	/**
	 * @param issueDate
	 *            the issueDate to set
	 */
	public void setIssueDate(Calendar issueDate) {
		this.issueDate = issueDate;
	}


	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	public final Integer getContractNo() {
		return contractNo;
	}

	public final void setContractNo(Integer contractNo) {
		this.contractNo = contractNo;
	}

	public final java.sql.Date getInsertDate() {
		return insertDate;
	}

	public final void setInsertDate(java.sql.Date insertDate) {
		this.insertDate = insertDate;
	}

	
	
	public java.sql.Date getModifyDate() {
		return modifyDate;
	}

	public void setModifyDate(java.sql.Date modifyDate) {
		this.modifyDate = modifyDate;
	}

	public String getInsertUserId() {
		return insertUserId;
	}

	public void setInsertUserId(String insertUserId) {
		this.insertUserId = insertUserId;
	}

	public String getModifyUserId() {
		return modifyUserId;
	}

	public void setModifyUserId(String modifyUserId) {
		this.modifyUserId = modifyUserId;
	}

	public Integer getProgramIncentiveOptionID() {
		return programIncentiveOptionID;
	}

	public void setProgramIncentiveOptionID(Integer programIncentiveOptionID) {
		this.programIncentiveOptionID = programIncentiveOptionID;
	}

	public String getIncentiveOptionName() {
		return incentiveOptionName;
	}

	public void setIncentiveOptionName(String incentiveOptionName) {
		this.incentiveOptionName = incentiveOptionName;
	}

	
}
