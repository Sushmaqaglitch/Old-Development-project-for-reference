package com.healthpartners;

//import com.healthpartners.boot.web.EnableRocketWebApplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.actuate.autoconfigure.endpoint.jmx.JmxEndpointAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.web.WebApplicationInitializer;

@SpringBootApplication(exclude = JmxEndpointAutoConfiguration.class, scanBasePackages = "com.healthpartners")
@EnableConfigurationProperties
//@EnableRocketWebApplication
public class ImfsBpmAdminApplication extends SpringBootServletInitializer implements WebApplicationInitializer {

	public static void main(String[] args) {
		SpringApplication.run(ImfsBpmAdminApplication.class, args);
	}
}
