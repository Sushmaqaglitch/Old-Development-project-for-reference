package com.healthpartners.app.bpm.controller;

import com.healthpartners.app.bpm.common.UserSessionSupport;
import com.healthpartners.app.bpm.common.ValidationSupport;
import com.healthpartners.app.bpm.iface.BusinessProgramService;
import com.healthpartners.app.bpm.session.UserSession;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.util.ArrayList;

import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.model;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(GroupLookupController.class)
public class GroupLookupControllerTest {
    @Autowired
    MockMvc mvc;

    @Mock
    private HttpServletRequest request;

    @Mock
    private HttpServletResponse response;

    @Mock
    private UserSession userSession = new UserSession();

    @MockBean
    private BusinessProgramService businessProgramService;

    @MockBean
    private UserSessionSupport userSessionSupport;

    @MockBean
    private ValidationSupport validationSupport;

    @Test
    @WithMockUser(roles = {"BPM BUSINESS USERS"})
    public void showGroupLookupShouldLoad() throws Exception {
        ArrayList<String> startDates = new ArrayList<>();
        startDates.add("1/1/2023");
        given(userSessionSupport.getUserSession())
                .willReturn(userSession);
        given(businessProgramService.getAllStartDates())
                .willReturn(startDates);

        mvc.perform(MockMvcRequestBuilders
                .get("/showGroupLookup")
                .accept(MediaType.TEXT_HTML)
                        .with(request -> request))
        .andDo(print())
        .andExpect(status().isOk())
        .andExpect(model().attributeExists(("groupLookupForm")));

        verify(userSession, times(1)).setStartDates(startDates);
    }
}
