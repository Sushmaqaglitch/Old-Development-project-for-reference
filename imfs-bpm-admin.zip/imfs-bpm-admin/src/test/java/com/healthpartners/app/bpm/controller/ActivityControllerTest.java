package com.healthpartners.app.bpm.controller;

import com.healthpartners.app.bpm.common.UserSessionSupport;
import com.healthpartners.app.bpm.common.ValidationSupport;
import com.healthpartners.app.bpm.dto.Activity;
import com.healthpartners.app.bpm.iface.BusinessProgramService;
import com.healthpartners.app.bpm.session.UserSession;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.util.ArrayList;
import java.util.Arrays;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(ActivityController.class)
public class ActivityControllerTest {
    @Autowired
    MockMvc mvc;

    @Mock
    private HttpServletRequest request;

    @Mock
    private HttpServletResponse response;

    @Mock
    private UserSession userSession = new UserSession();

    @MockBean
    private BusinessProgramService businessProgramService;

    @MockBean
    private UserSessionSupport userSessionSupport;

    @MockBean
    private ValidationSupport validationSupport;

    @Test
    @WithMockUser(roles = {"BPM BUSINESS USERS"})
    public void defineActivityShouldLoadWhenUserHasValidRole() throws Exception {
        ArrayList<Activity> activities = new ArrayList<>();
        activities.add(new Activity());
        ArrayList<Activity> expiredActivities = new ArrayList<>();
        expiredActivities.add(new Activity());

        given(businessProgramService.selectAllActivities())
                .willReturn(activities);
        given(businessProgramService.selectExpiredActivities())
                .willReturn(expiredActivities);
        given(userSessionSupport.getUserSession())
                .willReturn(userSession);

        mvc.perform(MockMvcRequestBuilders
                .get("/defineActivity")
                .accept(MediaType.TEXT_HTML)
                        .with(request -> request))
        .andDo(print())
        .andExpect(status().isOk())
        .andExpect(model().attributeExists(("activities")))
        .andExpect(model().attributeExists(("expiredActivities")))
        .andExpect(view().name("defineActivity"));

        verify(userSession, times(1)).setActivities(activities);
    }

    @Test
    public void defineActivityShouldRedirectToLoginWhenUserHasInvalidRole() throws Exception {
        given(businessProgramService.selectAllActivities())
                .willReturn(Arrays.asList(new Activity()));

        given(businessProgramService.selectExpiredActivities())
                .willReturn(Arrays.asList(new Activity()));

        mvc.perform(MockMvcRequestBuilders
                        .get("/defineActivity")
                        .accept(MediaType.TEXT_HTML))
                .andDo(print())
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("http://localhost/login"));
    }

    @Test
    @WithMockUser(roles = {"BPM BUSINESS USERS"})
    public void downloadActivityListShouldOutputAReport() throws Exception {
        ArrayList<Activity> activities = new ArrayList<>();
        activities.add(new Activity());
        ArrayList<Activity> expiredActivities = new ArrayList<>();
        activities.add(new Activity());

        given(userSessionSupport.getUserSession())
                .willReturn(userSession);
        given(businessProgramService.selectAllActivities())
                .willReturn(activities);
        given(businessProgramService.selectExpiredActivities())
                .willReturn(expiredActivities);

        MvcResult result =
                mvc.perform(MockMvcRequestBuilders
                                .get("/downloadActivityList")
                                .accept(MediaType.TEXT_HTML)
                                .with(request -> request))
                        .andDo(print())
                        .andExpect(status().isOk())
                        .andReturn();

        assertThat(result.getResponse().getHeader("Content-Type"))
                .isEqualTo("text/csv");
        assertThat(result.getResponse().getHeader("Content-Disposition"))
                .isEqualTo("attachment;filename=\"report.csv\"");

        verify(userSession, times(2)).getActivities();
    }
}
